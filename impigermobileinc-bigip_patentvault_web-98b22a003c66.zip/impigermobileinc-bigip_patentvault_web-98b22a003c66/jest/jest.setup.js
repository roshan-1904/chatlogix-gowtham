import '@testing-library/jest-dom';

// Suppress JSDOM CSS parsing errors
const originalConsoleError = console.error;
const jsDomCssError = 'Error: Could not parse CSS stylesheet';

console.error = (...params) => {
    if (params.some((p) => p.toString().includes(jsDomCssError))) {
        return;
    }
    originalConsoleError(...params);
};

// Mock MSAL to prevent `crypto_nonexistent` error
jest.mock('@azure/msal-browser', () => ({
    PublicClientApplication: jest.fn().mockImplementation(() => ({
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'mockToken' }),
        acquireTokenPopup: jest.fn().mockResolvedValue({ accessToken: 'mockToken' }),
        loginPopup: jest.fn().mockResolvedValue({}),
        logout: jest.fn()
    }))
}));

// Mock Quill to prevent import errors in Jest
jest.mock('quill', () => {
    return jest.fn();
});

// Ensure MSAL React is mocked correctly
jest.mock('@azure/msal-react', () => ({
    useMsal: () => ({
        instance: {
            logoutRedirect: jest.fn()
        }
    })
}));

// Fix ES Module issues when running Jest
jest.mock('primereact/editor', () => ({
    Editor: jest.fn(() => null)
}));

// Ensure crypto is available
if (!global.crypto) {
    global.crypto = require('crypto');
}
