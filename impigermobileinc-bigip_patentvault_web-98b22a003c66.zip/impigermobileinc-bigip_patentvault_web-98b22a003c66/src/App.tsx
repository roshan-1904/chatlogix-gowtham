import './App.css';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import { router } from 'core/routes';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from 'core/configs/msalConfig';
import React, { useEffect, useRef, useMemo } from 'react';
import { getToken } from 'core/interceptor/api.handler';

const PageHasBeenForceRefreshed = 'page-has-been-force-refreshed';

const retryPageLoading = () => {
    const pageHasAlreadyBeenForceRefreshed = JSON.parse(
        window.localStorage.getItem(PageHasBeenForceRefreshed) ?? 'false'
    ) as boolean;

    if (!pageHasAlreadyBeenForceRefreshed) {
        window.localStorage.setItem(PageHasBeenForceRefreshed, 'true');
        return window.location.reload();
    } else {
        window.localStorage.setItem(PageHasBeenForceRefreshed, 'false');
    }
};

interface ErrorBoundaryProps {
    children: React.ReactNode;
}
export class ErrorBoundary extends React.Component<ErrorBoundaryProps, { hasError: boolean }> {
    constructor(props: Readonly<ErrorBoundaryProps>) {
        super(props);
        this.state = { hasError: false };
    }
    componentDidCatch(error: unknown, info: unknown) {
        retryPageLoading();
        this.setState({ hasError: true });
        console.error(error);
        console.error(info);
    }
    render() {
        if (this.state.hasError) {
            return <>Your error component</>;
        }
        return this.props.children;
    }
}

function App() {
    // ✅ Create once, even under StrictMode
    const msalInstance = useMemo(() => new PublicClientApplication(msalConfig), []);
    const routerConfig = useMemo(() => createBrowserRouter(router), []);

    // ✅ Prevent duplicate interval setup
    const intervalRef = useRef<NodeJS.Timeout | null>(null);
    const initializedRef = useRef(false);

    useEffect(() => {
        if (initializedRef.current) return;
        initializedRef.current = true;
        intervalRef.current = setInterval(
            () => {
                getToken().then((_response) => {
                    // Token refreshed successfully
                });
            },
            1000 * 60 * 1
        );

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, []);

    return (
        <MsalProvider instance={msalInstance}>
            <div>
                <ErrorBoundary>
                    <RouterProvider
                        router={routerConfig}
                        fallbackElement={<p>Initial Load...</p>}
                    />
                </ErrorBoundary>
            </div>
        </MsalProvider>
    );
}

export default App;
