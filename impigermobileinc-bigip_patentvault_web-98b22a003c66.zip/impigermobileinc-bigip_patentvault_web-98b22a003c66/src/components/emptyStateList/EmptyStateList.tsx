import React from 'react';
import icon from 'assets/images/tasks-icon.png';
interface EmptyStateListProps {
    title: string;
    description: string;
    imageSrc?: string;
    imageAlt?: string;
    buttonLabel: string;
    buttonAction: () => void;
}

const EmptyStateList: React.FC<EmptyStateListProps> = ({
    title,
    description,
    imageSrc,
    imageAlt,
    buttonLabel,
    buttonAction
}) => {
    return (
        <div>
            <div className="bg-white rounded-lg m-4 mx-6 p-4">
                <div className="min-h-[calc(100vh-150px)] flex flex-col align-middle justify-center">
                    <div className="text-center">
                        <img
                            className="inline-block py-6 cursor-pointer"
                            src={imageSrc ?? icon}
                            alt={imageAlt ?? 'Create a new list data'}
                        />
                        <h1 className="text-xl my-2 font-bold" data-testid="title">
                            {title}
                        </h1>
                        <p className="text-sm my-3 text-slate-700" data-testid="description">
                            {description}
                        </p>

                        <button
                            onClick={buttonAction}
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    buttonAction();
                                }
                            }}
                            className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                            <i className="pi pi-plus-circle"></i>
                            {buttonLabel}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmptyStateList;
