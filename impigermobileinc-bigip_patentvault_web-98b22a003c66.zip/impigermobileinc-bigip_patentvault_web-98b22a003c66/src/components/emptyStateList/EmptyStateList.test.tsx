import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // for additional matchers
import EmptyStateList from './EmptyStateList'; // adjust the path based on your file structure

describe('EmptyStateList Component', () => {
    const mockButtonAction = jest.fn();

    const defaultProps = {
        title: 'No Tasks',
        description: 'You have no tasks to show.',
        imageSrc: 'https://via.placeholder.com/150',
        imageAlt: 'Placeholder image',
        buttonLabel: 'Create Task',
        buttonAction: mockButtonAction
    };

    test('renders correctly with provided props', () => {
        render(<EmptyStateList {...defaultProps} />);

        waitFor(() => {
            expect(screen.getByTestId('title')).toHaveTextContent('No Tasks');
            expect(screen.getByTestId('description')).toHaveTextContent(
                'You have no tasks to show.'
            );
            expect(screen.getByAltText('Placeholder image')).toBeInTheDocument();
            expect(screen.getByRole('button', { name: /create task/i })).toBeInTheDocument();
        });
    });

    test('uses default image if imageSrc is not provided', () => {
        const { container } = render(
            <EmptyStateList {...defaultProps} imageSrc={undefined} imageAlt="Default image" />
        );
        const imgElement = container.querySelector('img');
        waitFor(() => {
            expect(imgElement).toHaveAttribute('src', 'assets/images/tasks-icon.png');
            expect(screen.getByAltText('Default image')).toBeInTheDocument();
        });
    });

    test('button click triggers buttonAction', () => {
        render(<EmptyStateList {...defaultProps} />);

        const button = screen.getByRole('button', { name: /create task/i });
        fireEvent.click(button);
        waitFor(() => {
            expect(mockButtonAction).toHaveBeenCalledTimes(1);
        });
    });
});
