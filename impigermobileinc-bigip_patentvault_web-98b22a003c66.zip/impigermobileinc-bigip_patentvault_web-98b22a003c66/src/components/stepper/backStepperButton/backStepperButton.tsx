import { FC, useLayoutEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate } from 'react-router-dom';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import { replaceLastSegment } from 'core/utils/utils';

interface BackButtonProps {
    pathsForStepper: { [key: number]: string };
}

const BackStepperButton: FC<BackButtonProps> = ({ pathsForStepper }) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [stepper, setStepper] = useState<STEPPER_STATE>(stepperStore.initialState);
    const location = useLocation();
    const pathname = location?.pathname || '';
    const redirectToPreviousPage = () => {
        try {
            if (!stepper?.stepperInfo?.currStep || !stepper?.stepperList) return;

            let pageRedirection: number = 1; // default value
            let updatedCurrStepId: number;
            let updatedCurrStep: STEPPER_DATA_TYPE;

            /** for previous page - remove the last item from the 'completedStepsIds'.
             and, set that removed item as 'currStepId' */
            const completedPages: number[] = stepper?.stepperInfo?.completedStepsIds;
            if (completedPages && completedPages.length > 0) {
                updatedCurrStepId = completedPages[completedPages?.length - 1];
                updatedCurrStep = stepper.stepperList.find(
                    (step) => step.stepperId === updatedCurrStepId
                ) as STEPPER_DATA_TYPE;

                const updatedCompletedStepsIds: number[] = completedPages?.slice(0, -1);

                // update store with new data for upcoming page
                const updatedStepperInfo: STEPPER_INFO = {
                    currStep: updatedCurrStep,
                    completedStepsIds: updatedCompletedStepsIds
                };
                if (updatedStepperInfo) {
                    stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
                }

                pageRedirection = updatedCurrStep?.stepperId;
            }
            /* when a user clicks the 'back' button on the 'service-type' page, 
                they will return to the 'orders-quotes' list page. */

            const redirectTo = replaceLastSegment(pathname, pathsForStepper[pageRedirection]);
            // redirect to the previous page
            navigate(redirectTo);
        } catch (error) {
            console.error('Error on redirectToPreviousPage:', error);
        }
    };

    useLayoutEffect(() => {
        const subscription = stepperStore.subscribe(setStepper);
        stepperStore.init();
        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    return (
        <button
            onClick={redirectToPreviousPage}
            onKeyDown={(event) => {
                if (event.key === 'Enter') {
                    redirectToPreviousPage();
                }
            }}
            className="btn font-medium rounded-md min-h-0 h-10 button-neutral">
            <i className="pi pi-chevron-left"></i>
            <span className="font-medium">{t('COMMON.BACK')}</span>
        </button>
    );
};

export default BackStepperButton;
