import { render, fireEvent, waitFor } from '@testing-library/react';
import { useNavigate, useLocation } from 'react-router-dom';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import BackStepperButton from './backStepperButton';

// Mock necessary hooks and modules
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: jest.fn((key) => key)
    })
}));

jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn(),
    useLocation: jest.fn()
}));

jest.mock('core/store/stepperStore/progressStepper.store', () => ({
    initialState: {
        stepperInfo: {
            currStep: { stepperId: 2 },
            completedStepsIds: [1, 2]
        },
        stepperList: [
            { stepperId: 1, name: 'Step 1' },
            { stepperId: 2, name: 'Step 2' }
        ]
    },
    subscribe: jest.fn(() => ({
        unsubscribe: jest.fn()
    })),
    init: jest.fn(),
    updateStepper: jest.fn()
}));

jest.mock('core/utils/utils', () => ({
    replaceLastSegment: jest.fn((pathname, segment) => `${pathname}/${segment}`)
}));

describe('BackStepperButton', () => {
    const pathsForStepper = {
        1: 'step-1-path',
        2: 'step-1-path' // Update the path for stepperId 2 to 'step-1-path'
    };

    const navigateMock = jest.fn();
    (useNavigate as jest.Mock).mockReturnValue(navigateMock);
    (useLocation as jest.Mock).mockReturnValue({ pathname: '/current-path' });

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the back button and triggers navigation on click', () => {
        const { getByRole } = render(<BackStepperButton pathsForStepper={pathsForStepper} />);
        const button = getByRole('button', { name: 'COMMON.BACK' });
        expect(button).toBeInTheDocument();

        fireEvent.click(button);

        // Check if navigation was triggered with the correct path
        waitFor(() => {
            expect(navigateMock).toHaveBeenCalledWith('/current-path/step-2-path');
            fireEvent.click(button);
            expect(stepperStore.updateStepper).toHaveBeenCalledWith({
                stepperInfo: {
                    currStep: { stepperId: 1, name: 'Step 1' },
                    completedStepsIds: [1]
                }
            });
        });
    });

    test('unsubscribes from the store on unmount', () => {
        const { unmount } = render(<BackStepperButton pathsForStepper={pathsForStepper} />);
        unmount();
        waitFor(() => {
            expect(stepperStore.subscribe).toHaveBeenCalled();
            const unsubscribeMock = (stepperStore.subscribe as jest.Mock).mock.results[0].value
                .unsubscribe;
            expect(unsubscribeMock).toHaveBeenCalled();
        });
    });
});
