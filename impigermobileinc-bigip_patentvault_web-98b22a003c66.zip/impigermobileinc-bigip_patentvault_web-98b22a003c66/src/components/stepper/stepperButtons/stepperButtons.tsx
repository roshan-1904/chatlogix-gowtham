import React, { useEffect, useLayoutEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { focusOnFirstError, penTestSecurityUtils, replaceLastSegment } from 'core/utils/utils';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import { ButtonKey, StepperButtonsProps } from './stepperButton.types';
import { BUTTON_KEYS, isFormValid } from './stepperButton.constant';

/**
 * StepperButtons component for navigating through a multi-step form.
 *
 * @component
 * @param {Object} props - The component props.
 * @param {Step[]} props.steps - Array of step objects defining paths, buttons, and actions.
 * @param {StepperStoreState} props.stepperModuleStore - The store state for the stepper module.
 * @param {Function} [props.onCreate] - Callback function for the create action.
 * @param {Function} [props.onEdit] - Callback function for the edit action.
 * @param {Function} [props.onBackToList] - Callback function for the backToList action.
 * @returns {JSX.Element} The StepperButtons component.
 */
const StepperButtons: React.FC<StepperButtonsProps<{ [key: string]: any }>> = ({
    steps,
    stepperModuleStore,
    onCreate,
    onEdit,
    saveDraft,
    onBackToList,
    onUpdate,
    saveAndContinue,
    updateAndContinue,
    checkPrimaryValidation
}) => {
    const navigate = useNavigate();
    const location = useLocation();
    const pathname = location?.pathname || '';
    const isFromView: boolean = pathname?.includes('view');

    const [stepper, setStepper] = useState<STEPPER_STATE>(stepperStore.initialState);
    const [currentStep, setCurrentStep] = useState(0);

    useLayoutEffect(() => {
        const subscription = stepperStore.subscribe(setStepper);
        stepperStore.init();
        return () => subscription?.unsubscribe();
    }, []);

    useEffect(() => {
        const currentStepId = stepper?.stepperInfo?.currStep?.stepperId;
        if (currentStepId) {
            setCurrentStep(currentStepId - 1);
            const redirectPath = replaceLastSegment(pathname, steps[currentStepId - 1].path) ?? '';
            navigate(redirectPath);
        }
    }, [stepper, steps, pathname, navigate]);

    /**
     * Handles the next step in the stepper by validating the form and redirecting.
     *
     * @param {string} currentPath - The current path of the step.
     */
    const handleNext = async (currentPath: string) => {
        try {
            focusOnFirstError();
            // Check if the current step is the last step
            if (currentStep >= steps.length - 1) return;

            // Redirect to the next page if coming from view mode
            if (isFromView) {
                redirectToNextPage();
                return;
            }

            // Validate form and then redirect to the next page
            const formIsValid = await isFormValid(currentPath, stepperModuleStore);
            if (formIsValid) {
                redirectToNextPage();
            }
        } catch (error) {
            // Handle any errors that occur during form validation or redirection
            console.error('Error handling next step:', error);
        }
    };

    /**
     * Handles the back action in the stepper.
     */
    const handleBack = () => {
        if (currentStep > 0) {
            redirectToPreviousPage();
        }
    };

    /**
     * Redirects to the next page in the stepper.
     */
    const redirectToNextPage = () => {
        try {
            const updatedStepperInfo =
                progressStepperServices.updateStepperStoreForNextPage(stepper);
            if (updatedStepperInfo) stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
        } catch (error) {
            console.error('Error while redirecting to the next page:', error);
        }
    };
    const updateStepperStoreForPreviousPage = (stepperState: STEPPER_STATE) => {
        let updatedCurrStepId: number;
        let updatedCurrStep: STEPPER_DATA_TYPE;

        /** for previous page - remove the last item from the 'completedStepsIds'.
         and, set that removed item as 'currStepId' */
        const currentPage: number = stepperState?.stepperInfo?.currStep?.stepperId ?? 0;
        if (currentPage && currentPage > 0 && stepperState?.stepperList) {
            updatedCurrStepId = currentPage - 1;
            updatedCurrStep = stepperState?.stepperList.find(
                (step) => step.stepperId === updatedCurrStepId
            ) as STEPPER_DATA_TYPE;
            const updatedStepperInfo: STEPPER_INFO = {
                currStep: updatedCurrStep,
                completedStepsIds: stepperState?.stepperInfo?.completedStepsIds
            };
            return updatedStepperInfo;
        }
    };
    /**
     * Redirects to the previous page in the stepper.
     */
    const redirectToPreviousPage = () => {
        try {
            const updatedStepperInfo = updateStepperStoreForPreviousPage(stepper);
            if (updatedStepperInfo) stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
        } catch (error) {
            console.error('Error while redirecting to the previous page:', error);
        }
    };

    /**
     * Handles the final action for the stepper based on the provided action key.
     *
     * @param {Object} [action] - The action object containing a key and a name.
     * @param {Key} action.key - The key representing the action to perform. Can be one of the following:
     * @param {string} action.name - The name of the action.
     */
    const handleFinish = async (
        currentPath: string,
        action: { key: ButtonKey; name: string },
        stepperState?: STEPPER_STATE
    ) => {
        penTestSecurityUtils(stepperModuleStore?.getData()?.formData);
        const executeAction = () => {
            switch (action?.key) {
                case BUTTON_KEYS.CREATE:
                    onCreate?.();
                    break;
                case BUTTON_KEYS.EDIT:
                    onEdit?.();
                    break;
                case BUTTON_KEYS.UPDATE:
                    onUpdate?.();
                    break;
                case BUTTON_KEYS.BACK_TO_LIST:
                    onBackToList?.();
                    break;
                case BUTTON_KEYS.SAVE_DRAFT:
                    if (currentPath && saveDraft && stepperState) {
                        saveDraft(stepperState);
                    }
                    break;
                case BUTTON_KEYS.SAVE_AND_CONTINUE:
                    if (currentPath && saveAndContinue && stepperState) {
                        return saveAndContinue(stepperState);
                    }
                    break;
                case BUTTON_KEYS.UPDATE_AND_CONTINUE:
                    if (currentPath && updateAndContinue && stepperState) {
                        return updateAndContinue(stepperState);
                    }
                    break;
                case BUTTON_KEYS.CHECK_PRIMARY_VALIDATION:
                    if (currentPath && checkPrimaryValidation && stepperState) {
                        return checkPrimaryValidation(stepperState);
                    }
                    break;
                default:
                    console.warn('Unknown action key:', action?.key);
            }
        };

        if (isFromView || (await isFormValid(currentPath, stepperModuleStore))) {
            executeAction();
        }
    };

    const handleSaveAndContinue = (buttons: any[], path: string) => {
        const actionButton = buttons.find(
            (button: { key: string }) =>
                button.key === BUTTON_KEYS.SAVE_AND_CONTINUE ||
                button.key === BUTTON_KEYS.UPDATE_AND_CONTINUE
        );
        if (actionButton) {
            handleFinish(
                path,
                {
                    key: actionButton.key,
                    name: actionButton.name
                },
                stepper
            );
        }
    };

    /**
     * Renders the stepper buttons based on the current step.
     *
     * @returns {JSX.Element} The rendered buttons.
     */
    const renderButtons = () => {
        const { buttons, finalAction, optionalAction, path } = steps[currentStep];
        return (
            <div className="justify-between flex items-center px-6 py-2 mx-2 md:mx-3 border bg-white border-neutral-100/50">
                <div>
                    {buttons.some((button) => button.key === BUTTON_KEYS.BACK) && (
                        <button
                            id={`step-btn-${BUTTON_KEYS.BACK}`}
                            className="btn font-medium rounded-md h-10 min-h-10 button-neutral"
                            onClick={handleBack}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            disabled={currentStep === 0}>
                            <i className="pi pi-chevron-left"></i>
                            <span className="font-medium">
                                {' '}
                                {buttons.find((button) => button.key === BUTTON_KEYS.BACK)?.name ??
                                    'Back'}
                            </span>
                        </button>
                    )}
                </div>
                <div className="flex justify-end gap-3">
                    {optionalAction && (
                        <button
                            id={`step-btn-${optionalAction.key}`}
                            className="btn button-primary-outline rounded-md h-10 min-h-10"
                            onClick={() => {
                                handleFinish(path, optionalAction);
                            }}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                            {optionalAction.name}
                        </button>
                    )}
                    {buttons.some((button) => button.key === BUTTON_KEYS.CONTINUE) &&
                        currentStep < steps.length - 1 && (
                            <button
                                id={`step-btn-${BUTTON_KEYS.CONTINUE}`}
                                className="btn button-primary font-medium rounded-md  h-10 min-h-10"
                                onClick={() => {
                                    handleNext(path);
                                }}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                                <span className="font-medium">
                                    {' '}
                                    {buttons.find((button) => button.key === BUTTON_KEYS.CONTINUE)
                                        ?.name ?? 'Continue'}
                                </span>
                                <i className="pi pi-chevron-right"></i>
                            </button>
                        )}
                    {buttons.some((button) => button.key === BUTTON_KEYS.SAVE_DRAFT) &&
                        currentStep < steps.length - 1 && (
                            <button
                                id={`step-btn-${BUTTON_KEYS.SAVE_DRAFT}`}
                                className="btn button-primary font-medium rounded-md h-10 min-h-10"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    handleFinish(
                                        path,
                                        {
                                            key: BUTTON_KEYS.SAVE_DRAFT,
                                            name: 'Continue'
                                        },
                                        stepper
                                    );
                                }}>
                                <span className="font-medium">
                                    {' '}
                                    {buttons.find((button) => button.key === BUTTON_KEYS.SAVE_DRAFT)
                                        ?.name ?? 'save Draft'}
                                </span>
                                <i className="pi pi-chevron-right"></i>
                            </button>
                        )}
                    {buttons.some(
                        (button) =>
                            button.key === BUTTON_KEYS.SAVE_AND_CONTINUE ||
                            button.key === BUTTON_KEYS.UPDATE_AND_CONTINUE
                    ) &&
                        currentStep < steps.length - 1 && (
                            <button
                                id={`step-btn-${
                                    buttons.find(
                                        (button) =>
                                            button.key === BUTTON_KEYS.SAVE_AND_CONTINUE ||
                                            button.key === BUTTON_KEYS.UPDATE_AND_CONTINUE
                                    )?.key
                                }`}
                                className="btn button-primary font-medium rounded-md h-10 min-h-10"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    handleSaveAndContinue(buttons, path);
                                }}>
                                <span className="font-medium">
                                    {buttons.find(
                                        (button) =>
                                            button.key === BUTTON_KEYS.SAVE_AND_CONTINUE ||
                                            button.key === BUTTON_KEYS.UPDATE_AND_CONTINUE
                                    )?.name ?? 'Save & Continue'}
                                </span>
                                <i className="pi pi-chevron-right"></i>
                            </button>
                        )}
                    {buttons.some(
                        (button) => button.key === BUTTON_KEYS.CHECK_PRIMARY_VALIDATION
                    ) &&
                        currentStep < steps.length - 1 && (
                            <button
                                id={`step-btn-${BUTTON_KEYS.CHECK_PRIMARY_VALIDATION}`}
                                className="btn button-primary font-medium rounded-md  h-10 min-h-10"
                                onClick={() => {
                                    const actionButton = buttons.find(
                                        (button) =>
                                            button.key === BUTTON_KEYS.CHECK_PRIMARY_VALIDATION
                                    );
                                    if (actionButton) {
                                        handleFinish(
                                            path,
                                            {
                                                key: actionButton.key,
                                                name: actionButton.name
                                            },
                                            stepper
                                        );
                                    }
                                }}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                                <span className="font-medium">
                                    {' '}
                                    {buttons.find(
                                        (button) =>
                                            button.key === BUTTON_KEYS.CHECK_PRIMARY_VALIDATION
                                    )?.name ?? ''}
                                </span>
                                <i className="pi pi-chevron-right"></i>
                            </button>
                        )}
                    {finalAction && currentStep === steps.length - 1 && (
                        <button
                            id={`step-btn-${finalAction.key}`}
                            className="btn button-primary rounded-md h-10 min-h-10 text-base"
                            onClick={() => {
                                handleFinish(path, finalAction);
                            }}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                            <span className="font-medium">{finalAction.name}</span>
                        </button>
                    )}
                </div>
            </div>
        );
    };

    return <div id="stepper-button-container">{renderButtons()}</div>;
};

export default StepperButtons;
