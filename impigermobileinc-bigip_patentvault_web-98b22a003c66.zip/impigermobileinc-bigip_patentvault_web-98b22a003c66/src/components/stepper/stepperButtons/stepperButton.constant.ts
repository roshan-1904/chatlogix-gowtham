import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';

export const BUTTON_KEYS = {
    BACK: 'back' as const,
    CONTINUE: 'continue' as const,
    SAVE_DRAFT: 'saveDraft' as const,
    CREATE: 'create' as const,
    EDIT: 'edit' as const,
    BACK_TO_LIST: 'backToList' as const,
    UPDATE: 'update' as const,
    SAVE_AND_CONTINUE: 'saveAndContinue' as const,
    UPDATE_AND_CONTINUE: 'updateAndContinue' as const,
    CHECK_PRIMARY_VALIDATION: 'checkPrimaryValidation' as const
};
/**
 * Validates the form for the current step.
 *
 * @param {string} currentPath - The current path of the step.
 * @returns {Promise<boolean>} True if the form is valid, false otherwise.
 */
export const isFormValid = async (
    currentPath: string,
    stepperModuleStore: StepperStoreState<any>
): Promise<boolean> => {
    document.getElementById(`submit-${currentPath}`)?.click();
    await new Promise((r) => setTimeout(r, 100));
    const updatedStepperModuleStore = stepperModuleStore.getData();
    return updatedStepperModuleStore.isFormValid[currentPath] ?? false;
};
