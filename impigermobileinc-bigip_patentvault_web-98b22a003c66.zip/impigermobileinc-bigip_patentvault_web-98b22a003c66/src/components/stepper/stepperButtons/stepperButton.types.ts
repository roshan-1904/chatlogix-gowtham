import {
    STEPPER_STATE,
    StepperStoreState
} from 'pages/components/progressStepper/types/progressStepper.type';
import { BUTTON_KEYS } from './stepperButton.constant';

export interface Step {
    path: string;
    buttons: { key: ButtonKey; name: string }[];
    optionalAction?: { key: ButtonKey; name: string };
    finalAction?: { key: ButtonKey; name: string };
}

export interface StepperButtonsProps<T> {
    steps: Step[];
    stepperModuleStore: StepperStoreState<T>;
    onCreate?: () => void;
    onEdit?: () => void;
    saveDraft?: (stepperState: STEPPER_STATE) => void;
    onBackToList?: () => void;
    onUpdate?: () => void;
    saveAndContinue?: (stepperState: STEPPER_STATE) => void;
    updateAndContinue?: (stepperState: STEPPER_STATE) => void;
    checkPrimaryValidation?: (stepperState: STEPPER_STATE) => void;
}
export type ButtonKey = (typeof BUTTON_KEYS)[keyof typeof BUTTON_KEYS];
