import { FC, useEffect, useLayoutEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { PATHS } from 'constants/routes.constant';
import {
    STEPPER_INFO,
    STEPPER_STATE,
    StepperStoreState
} from 'pages/components/progressStepper/types/progressStepper.type';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import { focusOnFirstError, replaceLastSegment } from 'core/utils/utils';

interface ContinueButtonProps<T> {
    pathsForStepper: { [key: number]: string }; // Pass PATHS_FOR_STEPPER as a prop
    stepperModuleStore: StepperStoreState<T>;
    showContinue?: boolean;
    isSaveDraft?: boolean;
    onHandleDraft?: () => void;
}

const ContinueStepperButton: FC<ContinueButtonProps<{ [key: string]: any }>> = ({
    pathsForStepper,
    stepperModuleStore,
    showContinue = true,
    onHandleDraft,
    isSaveDraft
}) => {
    const navigate = useNavigate();
    const { t } = useTranslation();

    const location = useLocation();
    const { pathname } = location;
    const isFromView: boolean = pathname?.includes('view');

    const [stepper, setStepper] = useState<STEPPER_STATE>();

    const [currentPage, setCurrentPage] = useState<string>('');

    const pageNavigation = async () => {
        document.getElementById(`submit-${currentPage}`)?.click();
        await new Promise((r) => setTimeout(r, 100));
        focusOnFirstError();
        const updatedStepperModuleStore = stepperModuleStore.getData();
        if (isFromView) {
            redirectToNextPage();
        }
        if (updatedStepperModuleStore.isFormValid[currentPage]) {
            if (onHandleDraft && isSaveDraft) {
                onHandleDraft();
            }
            redirectToNextPage();
        }
    };

    const redirectToNextPage = () => {
        try {
            if (!stepper?.stepperInfo) return;
            focusOnFirstError();
            // update stepperInfo on store
            /** set default value for the first page 'service-type'.
                 because once selected the service category after that we fetch stepper data,
                 and assign that first value of index as stepperInfo.
                 otherwise go with regular functionality */
            const updatedStepperInfo: STEPPER_INFO | undefined =
                currentPage !== PATHS.SERVICE_TYPE
                    ? progressStepperServices?.updateStepperStoreForNextPage(stepper)
                    : stepper.stepperInfo;

            if (updatedStepperInfo?.currStep) {
                const currStep = updatedStepperInfo?.currStep;
                const redirectTo = pathsForStepper[currStep?.stepperId];

                stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
                setCurrentPage(redirectTo);
                const redirectPath = replaceLastSegment(pathname, redirectTo);
                navigate(redirectPath);
            }
        } catch (error) {
            console.error('Error while retrieving metadata:', error);
        }
    };

    useEffect(() => {
        const pathNameList = pathname.split('/');
        const currentPageUrl = pathNameList[pathNameList.length - 1];
        if (currentPageUrl) {
            setCurrentPage(currentPageUrl);
        }
    }, [pathname]);

    useLayoutEffect(() => {
        const subscriptionStepper = stepperStore.subscribe(setStepper);
        stepperStore.init();
        stepperModuleStore.init();
        return () => {
            subscriptionStepper?.unsubscribe();
        };
    }, []);

    return (
        <>
            {showContinue && (
                <button
                    onClick={() => {
                        void pageNavigation();
                    }}
                    onKeyDown={(event) => {
                        if (event.key === 'Enter') {
                            void pageNavigation();
                        }
                    }}
                    className="btn button-primary font-medium rounded-md min-h-10 h-10">
                    <span className="font-medium">{t('COMMON.CONTINUE')}</span>
                    <i className="pi pi-chevron-right"></i>
                </button>
            )}
        </>
    );
};

export default ContinueStepperButton;
