import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import ContinueStepperButton from './continueStepperButton';

jest.mock('core/store/stepperStore/progressStepper.store');
jest.mock('react-i18next', () => ({}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: jest.fn((key) => key)
    })
}));
jest.mock('pages/components/progressStepper/services/progressStepper.service', () => ({
    updateStepperStoreForNextPage: jest.fn()
}));

jest.mock('core/utils/utils', () => ({
    focusOnFirstError: jest.fn(),
    replaceLastSegment: jest.fn((pathname, segment) => `${pathname}/${segment}`)
}));

describe('ContinueStepperButton', () => {
    const setup = (props = {}) => {
        return render(
            <MemoryRouter initialEntries={['/some-path']}>
                <Routes>
                    <Route
                        path="*"
                        element={
                            <ContinueStepperButton
                                pathsForStepper={{}}
                                stepperModuleStore={{
                                    init: jest.fn(),
                                    subscribe: jest.fn(),
                                    updatePage: jest.fn(),
                                    getData: jest.fn(),
                                    resetStepperModuleStore: jest.fn(),
                                    initialState: {
                                        isFormValid: {},
                                        formData: {}
                                    } /* add any other required properties here */
                                }}
                                {...props}
                            />
                        }
                    />
                </Routes>
            </MemoryRouter>
        );
    };
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the continue button', () => {
        setup({
            pathsForStepper: { 1: '/next-page' },
            stepperModuleStore: {
                getData: jest.fn().mockReturnValue({
                    isFormValid: { 'some-path': true }
                }),
                init: jest.fn()
            }
        });

        const button = screen.getByRole('button', { name: 'COMMON.CONTINUE' });
        waitFor(() => {
            expect(button).toBeInTheDocument();
        });
    });

    test('calls pageNavigation when the button is clicked', () => {
        const mockNavigate = jest.fn();
        const mockOnHandleDraft = jest.fn();

        const props = {
            pathsForStepper: { 1: '/next-page' },
            stepperModuleStore: {
                getData: jest.fn().mockReturnValue({
                    isFormValid: { 'some-path': true }
                }),
                init: jest.fn()
            },
            showContinue: true,
            onHandleDraft: mockOnHandleDraft,
            isSaveDraft: true
        };
        setup(props);
        const button = screen.getByRole('button', { name: 'COMMON.CONTINUE' });
        fireEvent.click(button);
        waitFor(() => {
            expect(mockNavigate).toHaveBeenCalledWith('/some-path//next-page');
            expect(mockOnHandleDraft).toHaveBeenCalled();
        });
    });

    test('does not render the button if showContinue is false', () => {
        setup({
            pathsForStepper: { 1: '/next-page' },
            stepperModuleStore: {
                getData: jest.fn().mockReturnValue({
                    isFormValid: { 'some-path': true }
                }),
                init: jest.fn()
            },
            showContinue: false
        });

        const button = screen.queryByRole('button', { name: 'COMMON.CONTINUE' });
        expect(button).not.toBeInTheDocument();
    });
});
