import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import CreateStepperButton from './createStepperButton';
import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';

describe('CreateStepperButton', () => {
    const mockStepperModuleStore = {
        getData: jest.fn().mockReturnValue({
            isFormValid: {
                test: true
            }
        })
    } as unknown as StepperStoreState<{ [key: string]: any }>;

    const mockOnClickCreate = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the button with correct text', () => {
        render(
            <MemoryRouter initialEntries={['/create/test']}>
                <CreateStepperButton
                    stepperModuleStore={mockStepperModuleStore}
                    showCreate={true}
                    onClickCreate={mockOnClickCreate}
                    submitButtonText="Create"
                />
            </MemoryRouter>
        );

        expect(screen.getByText('Create')).toBeInTheDocument();
    });

    test('does not render the button if showCreate is false', () => {
        render(
            <MemoryRouter initialEntries={['/create/test']}>
                <CreateStepperButton
                    stepperModuleStore={mockStepperModuleStore}
                    showCreate={false}
                    onClickCreate={mockOnClickCreate}
                    submitButtonText="Create"
                />
            </MemoryRouter>
        );

        expect(screen.queryByText('Create')).not.toBeInTheDocument();
    });

    test('triggers the onClickCreate handler when the button is clicked and form is valid', async () => {
        render(
            <MemoryRouter initialEntries={['/create/test']}>
                <CreateStepperButton
                    stepperModuleStore={mockStepperModuleStore}
                    showCreate={true}
                    onClickCreate={mockOnClickCreate}
                    submitButtonText="Create"
                />
            </MemoryRouter>
        );

        const button = screen.getByText('Create');
        fireEvent.click(button);

        // Wait for the async operations
        await new Promise((r) => setTimeout(r, 200));
        waitFor(() => {
            expect(mockStepperModuleStore.getData).toHaveBeenCalled();
            expect(mockOnClickCreate).toHaveBeenCalledWith(false);
        });
    });

    test('identifies if the current page is from edit mode', () => {
        render(
            <MemoryRouter initialEntries={['/edit/test']}>
                <CreateStepperButton
                    stepperModuleStore={mockStepperModuleStore}
                    showCreate={true}
                    onClickCreate={mockOnClickCreate}
                    submitButtonText="Update"
                />
            </MemoryRouter>
        );

        const button = screen.getByText('Update');
        fireEvent.click(button);
        waitFor(() => {
            expect(mockOnClickCreate).toHaveBeenCalledWith(true);
        });
    });
});
