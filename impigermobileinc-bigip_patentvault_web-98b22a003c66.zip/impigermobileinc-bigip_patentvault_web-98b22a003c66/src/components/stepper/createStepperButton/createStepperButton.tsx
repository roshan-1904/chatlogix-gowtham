import { FC, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';

interface CreateButtonProps<T> {
    stepperModuleStore: StepperStoreState<T>;
    showCreate: boolean;
    onClickCreate: (isFromEdit?: boolean) => void;
    submitButtonText: string;
}

const CreateStepperButton: FC<CreateButtonProps<{ [key: string]: any }>> = ({
    stepperModuleStore,
    showCreate = false,
    onClickCreate,
    submitButtonText
}) => {
    const location = useLocation();
    const { pathname } = location;
    const isFromEdit: boolean = pathname?.includes('edit');
    const [currentPage, setCurrentPage] = useState<string>('');

    const onCreate = async () => {
        document.getElementById(`submit-${currentPage}`)?.click();
        await new Promise((r) => setTimeout(r, 100));
        const updatedStepperModuleStore = stepperModuleStore.getData();
        if (updatedStepperModuleStore?.isFormValid[currentPage]) {
            if (onClickCreate) onClickCreate(isFromEdit);
        }
    };

    useEffect(() => {
        const pathNameList = pathname.split('/');
        const currentPageUrl = pathNameList[pathNameList.length - 1];
        if (currentPageUrl) {
            setCurrentPage(currentPageUrl);
        }
    }, [pathname]);

    return (
        <>
            {showCreate && (
                <button
                    className="btn button-primary-outline rounded-md min-h-0 h-10"
                    onClick={() => void onCreate()}
                    onKeyDown={(event) => {
                        if (event.key === 'Enter') {
                            onCreate();
                        }
                    }}>
                    {submitButtonText}
                </button>
            )}
        </>
    );
};

export default CreateStepperButton;
