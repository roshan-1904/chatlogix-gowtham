import { useTranslation } from 'react-i18next';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { useLocation } from 'react-router-dom';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';

interface StepperNavigationProps {
    visible: boolean;
    popupId: string;
    onConfirm: () => void;
    onCancel: () => void;
    onKeyDown: () => void; // Added dynamic onKeyDown prop
    description?: string;
    showEdit?: boolean;
    onClickEdit?: () => void;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    steps: {
        module?: 'COMPANY' | 'USER';
        labelName?: string;
        label: string;
        isCurrent: boolean;
        isPrevious: boolean;
        navigationPath?: string;
        onClick?: () => void;
        isCopyable?: boolean;
    }[];
}
const StepperNavigation: React.FC<StepperNavigationProps> = ({
    visible,
    popupId,
    description = null,
    onKeyDown,
    onConfirm,
    onCancel,
    showEdit = false,
    onClickEdit,
    primaryButtonText = null,
    secondaryButtonText = null,
    steps = []
}) => {
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;
    const isCreateView: boolean = pathname?.includes('create');

    return (
        <div className="h-[2.87rem] bg-white border-b-2 border-b-primary pl-3 flex items-center justify-between">
            <div className="flex items-center ml-1">
                {steps.map((step, index) => (
                    <button
                        key={step.label}
                        title={step.isPrevious ? 'Redirect to ' + step.label : ''}
                        className={`group flex items-center text-lg ${step.isCurrent ? 'text-black !font-semibold cursor-text' : 'text-black/60 hover:text-primary !font-medium'}`}
                        onClick={() => {
                            if (step.isCurrent) return;
                            onKeyDown();
                        }}
                        onKeyDown={(event) => {
                            if (step.isCurrent) return;
                            if (event.key === 'Enter') {
                                onKeyDown();
                            }
                        }}>
                        {step.labelName && !isCreateView && (
                            <p className="text-[0.90rem] leading-none px-1.5 py-1 border rounded flex items-center gap-1 mr-2 mt-[0.1875rem] text-black/70 select-none">
                                {(() => {
                                    let iconClass = '';
                                    if (step.module === 'COMPANY') {
                                        iconClass = 'pi-building';
                                    } else if (step.module === 'USER') {
                                        iconClass = 'pi-user';
                                    }
                                    return (
                                        <i
                                            className={`${iconClass} pi text-sm !text-[0.80rem]`}></i>
                                    );
                                })()}
                                {step.labelName}
                            </p>
                        )}
                        {step.label}
                        {step.isCopyable && (
                            <button
                                title={t('COMMON.COPY_TO_CLIPBOARD')}
                                className="pi pi-copy text-sm px-1.5 !cursor-pointer text-black/50 !font-normal invisible group-hover:visible bg-transparent border-none outline-none"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    navigator.clipboard.writeText(step.label);
                                    showToastMessage({
                                        message: t('COMMON.COPY_SUCCESS'),
                                        type: ToastType.SUCCESS
                                    });
                                }}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' || e.key === ' ') {
                                        e.preventDefault();
                                        e.currentTarget.click();
                                    }
                                }}
                            />
                        )}
                        {index < steps.length - 1 && (
                            <i className="pi pi-angle-right text-lg pt-0.5 px-1 !text-black/60 !no-underline" />
                        )}
                    </button>
                ))}
            </div>

            {showEdit && (
                <button
                    data-testid={`step-btn-edit`}
                    id={`step-btn-edit`}
                    className="btn button-primary-outline rounded-md min-h-7 h-7 mr-3"
                    onClick={() => {
                        onClickEdit && onClickEdit();
                    }}
                    onKeyDown={(event) => {
                        if (event.key === 'Enter') {
                            onClickEdit && onClickEdit();
                        }
                    }}>
                    <img src="/images/svgs/i-edit-blue-icon.svg" className="h-3 w-3" />
                    {t('COMMON.EDIT')}
                </button>
            )}
            {visible && (
                <ConfirmationPopup
                    onConfirm={onConfirm}
                    onCancel={onCancel}
                    visible={visible}
                    headerText={t('COMMON.CONFIRMATION')}
                    description={
                        description ?? t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')
                    }
                    acceptLabel={primaryButtonText ?? t('COMMON.YES_DISCARD')}
                    rejectLabel={secondaryButtonText ?? t('COMMON.NO_DON_T')}
                    rejectClassName={'!bg-error !px-6 !text-white'}
                    acceptClassName={'!bg-neutral-50 !px-5 !text-black !border-neutral-100'}
                    popupID={popupId}
                />
            )}
        </div>
    );
};

export default StepperNavigation;
