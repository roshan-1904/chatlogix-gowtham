import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import FileUploadController from './fileUploadController';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
// import fileUploadService from './services/fileUpload.service';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('core/store/uploadedFile.store/uploadedFile.store', () => ({
    initialState: {
        files: []
    },
    subscribe: jest.fn(),
    handleFileUploadComplete: jest.fn()
}));

jest.mock('./services/fileUpload.service', () => ({
    replaceExistingFormalDocument: jest.fn(),
    formalDocument: jest.fn(),
    documentUpload: jest.fn()
}));
jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('FileUploadController', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders without crashing', () => {
        render(
            <MemoryRouter>
                <FileUploadController />
            </MemoryRouter>
        );
        waitFor(() => {
            expect(screen.getByRole('button')).toBeInTheDocument();
        });
    });

    it('toggles the popup visibility when the button is clicked', () => {
        render(
            <MemoryRouter>
                <FileUploadController />
            </MemoryRouter>
        );

        waitFor(() => {
            const button = screen.getByRole('button');
            fireEvent.click(button);
            expect(button).toHaveClass('hidden');
            fireEvent.click(button);
            expect(button).not.toHaveClass('hidden');
        });
    });

    it('subscribes to UploadedFileStore on mount and unsubscribes on unmount', () => {
        const unsubscribeMock = jest.fn();
        (UploadedFileStore.subscribe as jest.Mock).mockReturnValue({
            unsubscribe: unsubscribeMock
        });

        const { unmount } = render(
            <MemoryRouter>
                <FileUploadController />
            </MemoryRouter>
        );

        expect(UploadedFileStore.subscribe).toHaveBeenCalled();
        unmount();
        expect(unsubscribeMock).toHaveBeenCalled();
    });
});
