// Function to remove file from input element data
export function removeFileInInputElementData(fileName: string) {
    const input = document.getElementById('fileInput') as HTMLInputElement;
    const fileList = Array.from(input.files ?? []);
    const index = fileList.findIndex((file) => file.name === fileName);
    if (index !== -1) {
        fileList.splice(index, 1);
        const newFileList = new DataTransfer();
        fileList.forEach((file) => newFileList.items.add(file));
        input.files = newFileList.files;
    } else {
        console.error('File not found:', fileName);
    }
}
