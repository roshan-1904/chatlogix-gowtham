import HttpService from 'core/interceptor/api.handler';

import fileUploadService from './fileUpload.service';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getDocumentTypes', () => {
        const getDocumentTypesApiUrl = '/documentTypes';
        it('should fetch getDocumentTypes successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await fileUploadService.getDocumentTypes(getDocumentTypesApiUrl);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                fileUploadService.getDocumentTypes(getDocumentTypesApiUrl)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getUploadedDocumentList', () => {
        const getFileListApiUrl = '/fileList';
        it('should fetch getUploadedDocumentList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await fileUploadService.getUploadedDocumentList(getFileListApiUrl);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                fileUploadService.getUploadedDocumentList(getFileListApiUrl)
            ).rejects.toThrow(mockError);
        });
    });

    describe('isFileTypeUpdate', () => {
        const updateDocumentTypeApiUrl = '/updateDocumentType';
        const documentId = 123;
        const fileId = 456;
        const documentTypeId = 1;
        it('should fetch isFileTypeUpdate successfully', async () => {
            jest.spyOn(HttpService.prototype, 'put').mockResolvedValue({});
            const result = await fileUploadService.isFileTypeUpdate(
                updateDocumentTypeApiUrl,
                documentId,
                fileId,
                documentTypeId
            );
            expect(result).toEqual({});
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'put').mockRejectedValueOnce(mockError);
            await expect(
                fileUploadService.isFileTypeUpdate(
                    updateDocumentTypeApiUrl,
                    documentId,
                    fileId,
                    documentTypeId
                )
            ).rejects.toThrow(mockError);
        });
    });

    describe('deleteTheDocument', () => {
        const deleteApiUrl = '/deleteDocument';
        const documentId = 134;
        const fileId = 12;

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'delete').mockRejectedValueOnce(mockError);
            await expect(
                fileUploadService.deleteTheDocument(deleteApiUrl, documentId, fileId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('documentUpload', () => {
        const data_payload = {
            fileName: 'test.pdf',
            fileType: 'application/pdf',
            fileSize: '1000',
            blobFileName: 'test.pdf',
            documentType: 1
        };
        const postURL = '/documentUpload';
        it('should fetch getDocumentTypes successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await fileUploadService.documentUpload(data_payload, postURL);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(fileUploadService.documentUpload(data_payload, postURL)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('replaceExistingFormalDocument', () => {
        const data_payload = {
            fileName: 'test.pdf',
            fileType: 'application/pdf',
            fileSize: '1000',
            blobFileName: 'test.pdf',
            documentType: 1,
            replaceFormalDocumentURL: '/replaceFormalDocument',
            expectedDeliveryDate: '2021-09-01',
            hardCopy: true
        };
        const postURL = '/documentUpload';
        it('should fetch getDocumentTypes successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await fileUploadService.replaceExistingFormalDocument(
                data_payload,
                postURL
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                fileUploadService.replaceExistingFormalDocument(data_payload, postURL)
            ).rejects.toThrow(mockError);
        });
    });
});
