import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import UploadingFileStatus, { formatFileSize } from './uploadingFileStatus';
import UploadedFileStore from '../../../core/store/uploadedFile.store/uploadedFile.store';
import { cancelFileUpload } from '../services/azureStorage.service';
// import { subscribe } from 'diagnostics_channel';

// Mocking necessary external dependencies
jest.mock('../../../core/store/uploadedFile.store/uploadedFile.store');
jest.mock('../services/azureStorage.service');
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key // Simple mock for translation function
    })
}));
jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});
jest.mock('../../../core/store/uploadedFile.store/uploadedFile.store', () => ({
    subscribe: jest.fn()
}));
describe('UploadingFileStatus Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    const mockUploadedFiles = [
        { name: 'file1.txt', size: 1024, type: 'text/plain', progress: 50, moduleName: 'module1' },
        { name: 'file2.png', size: 2048, type: 'image/png', progress: 100, moduleName: 'module1' }
    ];

    it('should render correctly when files are uploading', () => {
        // Mocking the initial state with files
        UploadedFileStore.initialState = {
            files: mockUploadedFiles
        };
        render(<UploadingFileStatus moduleName="module1" />);

        // Check if "UPLOADING" message is displayed for file in progress
        expect(screen.getByText('File_UPLOAD.UPLOADING 1 File_UPLOAD.FILES')).toBeInTheDocument();
        // Check the file name being uploaded is displayed
        expect(screen.getByText('file1.txt')).toBeInTheDocument();
        // Verify progress bar is rendered
        // expect(screen.getByRole('progressbar')).toBeInTheDocument();
    });

    it('should display "Uploaded" when files are fully uploaded', () => {
        UploadedFileStore.initialState = {
            files: [
                {
                    name: 'file2.png',
                    size: 2048,
                    type: 'image/png',
                    progress: 100,
                    moduleName: 'module1'
                }
            ]
        };
        render(<UploadingFileStatus moduleName="module1" />);

        // Check if "Uploaded" message is displayed
        expect(screen.getByText('Uploaded 1 File_UPLOAD.FILES')).toBeInTheDocument();
    });

    it('should call cancelFileUpload when cancel icon is clicked', () => {
        UploadedFileStore.initialState = {
            files: mockUploadedFiles
        };

        render(<UploadingFileStatus moduleName="module1" />);

        // Get the cancel button
        // const cancelButton = screen.getByRole('button', { hidden: true, name: /cancel/i });
        // fireEvent.click(cancelButton);

        // Check if cancelFileUpload was called with the correct file name
        waitFor(() => {
            expect(cancelFileUpload).toHaveBeenCalledWith('file1.txt');
        });
    });

    it('should display correct file size using formatFileSize function', () => {
        // Test file size formatting
        expect(formatFileSize(1023)).toBe('1023 bytes');
        expect(formatFileSize(2048)).toBe('2.00 KB');
        expect(formatFileSize(5 * 1024 * 1024)).toBe('5.00 MB');
        expect(formatFileSize(3 * 1024 * 1024 * 1024)).toBe('3.00 GB');
    });
});
