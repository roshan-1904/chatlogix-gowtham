import React, { ChangeEvent, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { useTranslation } from 'react-i18next';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import UploadingFileStatus from './uploadingFileStatus/uploadingFileStatus';
import UploadedFileStore from '../../core/store/uploadedFile.store/uploadedFile.store';
import { getSasUrl, isSasUrlExpired } from './services/azureStorage.service';
import fileUploadService from './services/fileUpload.service';
import { Dialog } from 'primereact/dialog';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { dropDownStyle, previewDialogPopup } from 'constants/styles.constant';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import { FileUploadProps, ResponseDocumentType } from './types/fileUpload.types';
import { Tooltip } from 'primereact/tooltip';
import { PATHS } from 'constants/routes.constant';
import { removeFileInInputElementData } from './constant/fileUpload.constant';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { DOCUMENT_TYPE, MODULE_TYPE } from 'constants/app.constant';
import { fileTypeIcon } from './constant/fileTypeIcon';
import utils, { getWindowSize, isStaffUser, isVendorUser } from 'core/utils/utils';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS_FOR_STEPPER, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { useNavigate } from 'react-router-dom';
// import { QuoteOrderModuleStoreFormData } from 'core/store/orderQuoteStore/orderQuote.type.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';

const FileUpload: React.FC<FileUploadProps<{ [key: string]: any }>> = (props) => {
    const {
        moduleType,
        primaryId,
        uploadFileApiUrl,
        getFileListApiUrl,
        deleteFileApiUrl,
        getDocumentTypeApiUrl,
        updateDocumentTypeApiUrl,
        stepperModuleStore,
        documentUploadRequired = false,
        documentUploadTitle = true, // Default to true
        documentUploadOptionalText = true, // Default to true
        uploadingStatusSection = true, // Default to true
        uploadedDocumentListTable = true, // Default to true
        isNotClassified = true,
        childDropDown = null,
        sourceReferenceDocumentType = true,
        className = '',
        ifFormalDocumentUpload = { isFormalDoc: false, isExistingDocReplace: false },
        ifFiledDocumentUpload = { isFiledDoc: false, isExistingDocReplace: false },
        ifStandardDocumentUpload = {
            isStandardDoc: false,
            documentType: 1,
            stdGroupId: 0,
            notesForUploadedFiles: '',
            storeFilesAgainstGroup() {}
        },
        formalDocumentFields = null,
        filedDocumentFields = null,
        extraFields = null,
        handleSelectedDocumentType,
        multipleFiles = true,
        acceptedFileTypes = [],
        documentTypeId = null,
        documentTypeFlag = true,
        singleFileUploadIndication,
        isViewOnly = false,
        moduleName = '',
        triggerFileInputClick,
        isValidateRequiredFields = false,
        fillRequiredFieldsAreValid = isValidateRequiredFields ? false : true,
        hideColumns = [],
        ifExecuteFormalDocumentUpload = { isExecutingDoc: false, isExistingDocReplace: false },
        executeFormalDocumentFields = null,
        titleForUploadSection,
        triggerHandleFiles,
        isEpUPCOptOut = false,
        replaceFileId = null
    } = props;

    // Ref for file input element
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Expose method to trigger file input click from parent component
    React.useEffect(() => {
        if (triggerFileInputClick) {
            triggerFileInputClick(() => fileInputRef.current?.click());
        }
    }, [triggerFileInputClick]);

    const { t } = useTranslation();
    const navigate = useNavigate();
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [fileTypes, setFileTypes] = useState<any>([]);
    const [uploadedDocumentList, setUploadedDocumentList] = useState<any>();
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const [toggleRowData, setToggleRowData] = useState<any>();
    const [showFileDeletePopup, setShowFileDeletePopup] = useState({
        visible: false,
        header: '',
        description: ''
    });
    const [documentTypeValue, setDocumentTypeValue] = useState<any>();
    const [selectedDocumentType, setSelectedDocumentType] = useState<any>();

    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isEditFlow = quoteOrderModuleStore.getData().info.isEditFlow === true;
    const selectedService = quoteOrderModuleStore.getData().info.selectedService;
    const isStandardFlow = selectedService?.serviceTypeId === SERVICE_TYPE_ID.other_translations;

    const handleDocumentTypeChange = async (rowData: any, updateValue: number) => {
        if (!updateDocumentTypeApiUrl) return;
        const documentTypeUpdate = await fileUploadService.isFileTypeUpdate(
            updateDocumentTypeApiUrl,
            rowData.documentId as number,
            rowData.fileId as number,
            updateValue
        );

        if (documentTypeUpdate) {
            fetchDocumentListForTableData();
        }
    };

    const tableSelectedDocumentType = (selectedId: any) => {
        const selectedItems = fileTypes.find((option: { id: number }) => option.id === selectedId);
        return selectedItems;
    };

    const getFallbackDocumentTypeName = (selectedId: number) => {
        const fallbackItem = Object.values(DOCUMENT_TYPE).find(
            (option: { id: number }) => option.id === selectedId
        );
        return fallbackItem ? fallbackItem.name : null;
    };

    const HoverDropdownTemplate = (rowData: any) => {
        const selectedData = tableSelectedDocumentType(rowData.documentType);
        const selectedDataName =
            selectedData || getFallbackDocumentTypeName(rowData.documentType as number);
        let content;
        if (isViewOnly) {
            content = <>{selectedData?.name}</>;
        } else if (selectedData) {
            content = (
                <div className="flex items-center gap-3">
                    <Dropdown
                        disabled={isViewOnly}
                        data-testid="dataTable-hoverDropDown-format"
                        value={selectedDataName}
                        onChange={(e: DropdownChangeEvent) => {
                            handleDocumentTypeChange(rowData, e.value.id as number);
                        }}
                        options={fileTypes}
                        optionLabel="name"
                        placeholder="Select Document type"
                        pt={{
                            root: {
                                className:
                                    'hover:border-primary font-medium border-0 hover:border bg-inherit h-8 flex items-center'
                            },
                            item: {
                                className: 'hover:bg-primary-50'
                            },
                            input: {
                                className: '!block p-2 text-base'
                            }
                        }}
                    />
                    {rowData.documentType === DOCUMENT_TYPE.NOT_CLASSIFIED.id ? (
                        <div>
                            <Tooltip target=".custom-target-icon" />
                            <i
                                className="custom-target-icon pi pi-info-circle text-secondary text-[0.90rem] font-semibold"
                                data-pr-tooltip={t('File_UPLOAD.DOCUMENT_TYPE_TOOLTIP')}
                                data-pr-position="right"
                                data-pr-at="right+5 top+7"
                                data-pr-my="left center-2"
                            />
                        </div>
                    ) : (
                        <div></div>
                    )}
                </div>
            );
        } else {
            content = <p className="font-medium text-base p-2">{selectedDataName}</p>;
        }

        return content;
    };

    const filePreviewTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileId + ' flex gap-2'}>
                    {fileTypeIcon(rowData.fileType as string)}
                    <button
                        className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56 cursor-pointer bg-transparent border-none p-0"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                handlePreviewDocument(rowData);
                            }
                        }}>
                        {rowData.fileName}
                    </button>
                </div>
            </div>
        );
    };

    // Column definitions for the data table
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'fileName',
            header: 'Document Name',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            body: filePreviewTemplate
        },
        {
            field: 'documentType',
            header: 'Document Type',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            columnNumber: 2,
            visibility: true,
            body: HoverDropdownTemplate
        },
        {
            field: 'fileSize',
            header: 'Document Size',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded by',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'action',
            header: 'Action',
            filter: false,
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.DeleteIcon,
            columnNumber: 5,
            className: 'w-[8%]',
            visibility: true
        }
    ];

    // Fetching data on component mount
    useEffect(() => {
        const fetchAPIData = async () => {
            await new Promise((r) => setTimeout(r, 100));

            getSasUrlApi();
            const fetchData = async () => {
                await fetchDocumentTypes();
            };
            fetchData().then(() => {
                getFileListApiUrl && fetchDocumentListForTableData();
            });
        };
        if (primaryId) {
            fetchAPIData();
        }
    }, [primaryId]);

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription.unsubscribe();
        };
    }, []);

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);
    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));
                getFileListApiUrl && fetchDocumentListForTableData();
                UploadedFileStore.fileArrayEmpty();
            }
        };
        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    // Showing toast message
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    useEffect(() => {
        // Check if any file in the list has a documentType of not classified
        const isNotClassifiedType = uploadedDocumentList?.some(
            (file: { documentType: number }) =>
                file.documentType === DOCUMENT_TYPE.NOT_CLASSIFIED.id
        );
        // Update the state accordingly
        UploadedFileStore.initialState.notClassifiedType = !isNotClassifiedType;
    }, [uploadedDocumentList]);

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        const hideLoader: boolean = isEpUPCOptOut;
        try {
            const response = await getSasUrl(hideLoader);
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    // Fetching document types
    const fetchDocumentTypes = async () => {
        if (!getDocumentTypeApiUrl) return;
        let response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        const filterConditions = (item: { id: number }) => {
            if (sourceReferenceDocumentType) {
                return isNotClassified || item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id;
            }
            return isNotClassified
                ? item.id === DOCUMENT_TYPE.NOT_CLASSIFIED.id ||
                      (item.id !== DOCUMENT_TYPE.SOURCE.id &&
                          item.id !== DOCUMENT_TYPE.REFERENCE.id)
                : item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id &&
                      item.id !== DOCUMENT_TYPE.SOURCE.id &&
                      item.id !== DOCUMENT_TYPE.REFERENCE.id;
        };

        response = response.filter(filterConditions);

        if (moduleType.moduleId === MODULE_TYPE.FILED_DOCUMENT_MODULE.moduleId) {
            response = response.filter((item: ResponseDocumentType) => {
                return (
                    item.id !== DOCUMENT_TYPE.EXECUTED_POA_DOCUMENT.id &&
                    item.id !== DOCUMENT_TYPE.EXECUTED_ASSIGNMENT_DOCUMENT.id
                );
            });
        }

        setFileTypes(response);
    };

    // Handling selected document type
    const updateFileType = (value: any) => {
        setSelectedDocumentType(value);
    };

    // Fetching document list
    const fetchDocumentListForTableData = async () => {
        if (!getFileListApiUrl) return;
        let updatedResponse = [];
        const response: any = await fileUploadService.getUploadedDocumentList(getFileListApiUrl);
        if (response) {
            updatedResponse = response.documentReturnsModel.map((item: any) => ({
                ...item,
                isdisabled: false
            }));
            setUploadedDocumentList(updatedResponse);
            setBlobURL(response.blobUri);
        }
    };

    // Deleting file via API
    const handleDeleteFileApi = async (documentId: number, fileId: number) => {
        if (!deleteFileApiUrl) return;
        try {
            const deletionSuccess = await fileUploadService.deleteTheDocument(
                deleteFileApiUrl,
                documentId,
                fileId
            );
            if (deletionSuccess) {
                // If deletion was successful, fetch the updated document list
                getFileListApiUrl && (await fetchDocumentListForTableData());
                showToastMessage(t('File_UPLOAD.DELETE_SUCCESS_TOAST'), ToastType.SUCCESS);

                // we have to delete the same line item in language selection table only in STD flow
                // isStandardFlow && deleteSTDLanguageSelection(fileId);
            } else {
                // If deletion failed, show an error message
                showToastMessage(t('File_UPLOAD.DELETE_ERROR_TOAST'), ToastType.ERROR);
            }
        } catch (error) {
            console.error('Error deleting file:', error);
            // Handle error, if necessary
        }
    };
    // const deleteSTDLanguageSelection = (fileId: number) => {
    //     const formData = quoteOrderModuleStore.getData().formData;
    //     if (
    //         !formData.languageSelectionPage ||
    //         !formData.languageSelectionPage?.tableData ||
    //         formData.languageSelectionPage?.tableData?.length === 0
    //     )
    //         return;

    //     const languageSelectionList = formData.languageSelectionPage?.tableData;
    //     const updatedLanguageSelectionList = languageSelectionList.filter(
    //         (item: any) => item.fileId !== fileId
    //     );
    //     const updatedFormData: QuoteOrderModuleStoreFormData = {
    //         ...formData,
    //         languageSelectionPage: {
    //             ...formData.languageSelectionPage,
    //             tableData: updatedLanguageSelectionList
    //         }
    //     };
    //     quoteOrderModuleStore.updatePage('formData', updatedFormData);
    // };

    // Handling file input change for regular input
    const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files) {
            handleFiles(
                files,
                !ifFormalDocumentUpload.isExistingDocReplace &&
                    !ifFiledDocumentUpload.isExistingDocReplace &&
                    !ifStandardDocumentUpload.isStandardDoc
                    ? selectedDocumentType
                    : false
            );
        }
        singleFileUploadIndication?.(true);
    };

    // Handling uploaded files
    /**
    1. Selected File are send to store (validate the file type/size support) -> upload in azure blob -> then file details given to DB
    2. After upload API Success return Document List
    3. return Document List set to table list
     */

    const formatBlobFileName = (DocName: string) => {
        const currentDate = new Date();
        const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}${(currentDate.getMonth() + 1).toString().padStart(2, '0')}${currentDate.getFullYear()}${currentDate.getHours().toString().padStart(2, '0')}${currentDate.getMinutes().toString().padStart(2, '0')}${currentDate.getSeconds().toString().padStart(2, '0')}${currentDate.getMilliseconds().toString().padStart(3, '0')}`;
        const fileName = DocName.split('.').slice(0, -1).join('.');
        const fileExtension = DocName.split('.').pop();
        return `${fileName}_${formattedDate}.${fileExtension}`;
    };

    const handleFiles = async (files: FileList, DocumentType?: any) => {
        const newFiles = Array.from(files).map((file) => ({
            name: file.name,
            size: file.size,
            type: file.type || 'unknown/unknown',
            progress: 0,
            file,
            documentType:
                !ifFormalDocumentUpload.isExistingDocReplace &&
                !ifFiledDocumentUpload.isExistingDocReplace &&
                !ifStandardDocumentUpload.isStandardDoc
                    ? DocumentType
                        ? DocumentType.id
                        : documentTypeId || fileTypes[0].id
                    : ifStandardDocumentUpload.isStandardDoc
                      ? ifStandardDocumentUpload.documentType
                      : ifFormalDocumentUpload.isExistingDocReplace
                        ? formalDocumentFields?.documentType
                        : filedDocumentFields?.documentType,
            azureBlobFolderPath: `${moduleType.azureFolderName}/${String(primaryId).padStart(4, '0')}`,
            azureBlobFileName: formatBlobFileName(file.name),
            uploadFileApiUrl,
            ifFormalDocumentUpload,
            formalDocumentFields,
            primaryId,
            moduleName,
            ifFiledDocumentUpload,
            filedDocumentFields,
            ifExecuteFormalDocumentUpload,
            executeFormalDocumentFields,
            stdGroupId: ifStandardDocumentUpload?.stdGroupId ?? null,
            notesForUploadedFiles: ifStandardDocumentUpload?.notesForUploadedFiles,
            storeFilesAgainstGroup: ifStandardDocumentUpload?.storeFilesAgainstGroup,
            fileId: replaceFileId
        }));

        // Remove file from input element data
        newFiles.forEach((file: { name: string }) => removeFileInInputElementData(file.name));

        // Define the post URL for uploading files
        try {
            await UploadedFileStore.updateData(newFiles);
        } catch (error) {
            console.error('Error occurred while uploading files:', error);
        }
    };

    // Handling deletion confirmation
    const handleDeleteRecord = (data: any) => {
        setToggleRowData(data);
        setShowFileDeletePopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t(
                `${(isThisStaffUser || isThisVendorUser) && isStandardFlow ? 'File_UPLOAD.DELETE_CONFIRMATION_STD' : 'File_UPLOAD.DELETE_CONFIRMATION'}`
            )
        });
    };
    const handleDeleteFile = async (data: any) => {
        try {
            await handleDeleteFileApi(data.documentId as number, data.fileId as number);
            removeFileInInputElementData(data.fileName as string);
        } catch (error) {
            console.error('Error occurred while deleting file:', error);
        }
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;

        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    // Function to render hover message
    const hoverMessage = () => {
        return (
            <p className="bg-warning/40 w-fit my-3 py-0.5 px-2 rounded border-2 border-warning text-sm text-neutral-700 flex gap-1 items-center font-medium">
                <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                {t(`File_UPLOAD.HOVER_DOCUMENT_TYPE_MESSAGE`)}
            </p>
        );
    };

    // Table definition
    const customizedColumns = (): ColumnDefinition[] => {
        const determineVisibility = (field: string): boolean => {
            /** if we have to do not show particular columns,
             *  then pass those column-names in this hideColumns[] prop as string  */
            return (isViewOnly ? field !== 'action' : true) && !hideColumns.includes(field);
        };

        return columnSchema.map((column) => ({
            ...column,
            visibility: determineVisibility(column.field)
        }));
    };

    const tableDefinition: DataTableDefinition = {
        title: `Uploaded Documents${
            uploadedDocumentList && uploadedDocumentList.length > 0
                ? ` (${uploadedDocumentList?.length})`
                : ''
        }`,
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.FILE_UPLOAD_TABLE,
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.FILE_UPLOAD_COLUMN_ORDERS,
        renderChildrenAlone: true,
        tableCustomStyle: 'p-0',
        buttonChildren: !isViewOnly && hoverMessage(),
        showFilter: false,
        columns: customizedColumns(),
        customTableHeight: false
    };
    // Confirming file deletion
    const handleConfirm = () => {
        if (toggleRowData) {
            handleDeleteFile(toggleRowData);
            setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
        }
    };

    // Canceling file deletion
    const handleCancel = () => {
        setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
    };

    const onSubmit = () => {
        if (stepperModuleStore) {
            const updateStepperModuleStore = stepperModuleStore.getData();
            // Determine if document upload is valid
            const isDocumentUploadValid =
                uploadedDocumentList?.length > 0
                    ? UploadedFileStore?.initialState?.notClassifiedType
                    : !documentUploadRequired;

            const updatedStepperModuleStoreIsFormValid = {
                ...updateStepperModuleStore.isFormValid,
                [PATHS.FILE_UPLOAD]: isDocumentUploadValid
            };

            stepperModuleStore.updatePage('isFormValid', updatedStepperModuleStoreIsFormValid);

            if (isStandardFlow && isDocumentUploadValid) {
                navigationProcess();
            } else {
                // Show warnings if document upload is not valid
                if (documentUploadRequired && uploadedDocumentList?.length === 0) {
                    showToastMessage(t('File_UPLOAD.DOCUMENT_REQUIRED'), ToastType.WARNING);
                } else if (!UploadedFileStore?.initialState?.notClassifiedType) {
                    showToastMessage(
                        t('File_UPLOAD.DOCUMENT_TYPE_NOT_CLASSIFIED'),
                        ToastType.WARNING
                    );
                }
            }

            // Disable submit action if conditions are not met
            return;
        }
    };

    const navigationProcess = () => {
        try {
            const updatedStepperInfo = orderQuoteModuleService.stepperNavigation();

            if (!updatedStepperInfo?.currStep) throw new Error();
            const currStep = updatedStepperInfo?.currStep;
            const redirectTo = PATHS_FOR_STEPPER[currStep?.stepperId];
            navigate(
                `/${PATHS.ORDER_QUOTE}/${isEditFlow ? PATHS.EDIT : PATHS.CREATE}/${redirectTo}`
            );
        } catch (error) {
            console.error('Error in navigationProcess(): ', error);
        }
    };

    const handleDocumentType = (data: any) => {
        updateFileType(data);
        handleSelectedDocumentType?.(data?.id as number);
    };

    useEffect(() => {
        const data = !selectedDocumentType && fileTypes ? fileTypes[0] : selectedDocumentType;
        setDocumentTypeValue(data);
        handleDocumentType(data);
    }, [selectedDocumentType, fileTypes]);

    useEffect(() => {
        if (triggerHandleFiles) {
            triggerHandleFiles((files: File[]) => {
                handleFiles(files as unknown as FileList);
            });
        }
    }, [triggerHandleFiles]);

    return (
        <div data-testid="FileUpload" className={className}>
            {showFileDeletePopup.visible ? (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleConfirm();
                    }}
                    onCancel={() => {
                        handleCancel();
                    }}
                    visible={showFileDeletePopup.visible}
                    headerText={showFileDeletePopup.header}
                    description={showFileDeletePopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    popupID={'deleteFileConfirmationPopup'}
                />
            ) : null}
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    utils.handleDownloadPngSvg(previewImage, previewImageName);
                                }
                            }}
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <div className="p-3 pt-2 customStyle">
                {!isViewOnly && (
                    <>
                        {documentUploadTitle && (
                            <h4 className="font-semibold mb-3">
                                {' '}
                                {t('File_UPLOAD.DOCUMENTS_UPLOAD')}
                            </h4>
                        )}

                        {documentUploadOptionalText && (
                            <p className="bg-warning/40 w-fit py-0.5 px-2 rounded border-2 border-warning text-sm text-neutral-700 flex gap-1 items-center font-medium">
                                <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                                {documentUploadRequired
                                    ? t('File_UPLOAD.UPLOADING_MANDATORY_MESSAGE')
                                    : t('File_UPLOAD.UPLOADING_OPTIONAL_MESSAGE')}
                            </p>
                        )}

                        <div className="p-4 border-2 border-neutral-100/25 bg-neutral rounded-lg mt-3 documentSection">
                            {documentTypeFlag && (
                                <div className="md:grid md:grid-cols-2 gap-5">
                                    {childDropDown && <>{childDropDown}</>}
                                    <div>
                                        <label className="text-base font-medium text-neutral-200 flex flex-col gap-1 w-full">
                                            {t('File_UPLOAD.DOCUMENT_TYPE')}
                                            <Dropdown
                                                data-testid="selected-file-type"
                                                value={documentTypeValue}
                                                filter={true}
                                                onChange={(e) => {
                                                    handleDocumentType(e.value);
                                                }}
                                                options={fileTypes}
                                                optionLabel="name"
                                                placeholder={t('File_UPLOAD.SELECT_DOCUMENT_TYPE')}
                                                pt={{
                                                    ...dropDownStyle,
                                                    root: {
                                                        className:
                                                            'hover:border-primary font-medium border border-neutral-100 md:w-60 lg:w-72 4xl:w-96 documentTypeDropdownStyle'
                                                    },
                                                    item: { className: 'hover:bg-primary-50' },
                                                    input: {
                                                        className: 'p-2'
                                                    }
                                                }}
                                            />
                                        </label>
                                    </div>
                                </div>
                            )}

                            <div>{extraFields}</div>
                            <div className="text-base font-medium text-neutral-200 flex flex-col gap-1 my-3 w-full documentUploadSection">
                                <div className="flex items-center justify-between">
                                    {titleForUploadSection ?? (
                                        <div>{t('File_UPLOAD.UPLOAD_DOCUMENTS')}</div>
                                    )}

                                    {!fillRequiredFieldsAreValid && (
                                        <p className="bg-warning/40 w-fit my-3 py-1 px-2 rounded border-2 border-warning text-3xs text-neutral-700 flex gap-1 items-center font-medium">
                                            <i className="pi pi-info-circle text-warning-700 text-3xs font-semibold"></i>
                                            Please fill in all required fields before uploading your
                                            files.
                                        </p>
                                    )}
                                </div>

                                <div className="md:flex gap-6">
                                    <div
                                        className={`${fillRequiredFieldsAreValid ? 'cursor-pointer' : 'cursor-not-allowed opacity-30'} py-4 px-2  bg-primary-50 border-[0.12rem] border-primary/75 border-dashed w-full lg:w-7/12 rounded-lg flex flex-col items-center justify-center uploadSection`}>
                                        <div className="relative w-full">
                                            <div className="text-base text-black flex flex-col md:flex-row items-center justify-center md:gap-2">
                                                <div className="flex items-center gap-2">
                                                    <img src={uploadIcon} className="h-5" />
                                                    {t('File_UPLOAD.DRAG_AND_DROP_MESSAGE')}
                                                </div>
                                                <label className="text-base text-primary underline">
                                                    {t('File_UPLOAD.CHOOSE_FILE_MESSAGE')}
                                                    <input
                                                        disabled={!fillRequiredFieldsAreValid}
                                                        ref={fileInputRef}
                                                        type="file"
                                                        id="fileInput"
                                                        name="fileInput"
                                                        multiple={multipleFiles}
                                                        className={`absolute opacity-0 w-full top-0 left-0 h-full ${fillRequiredFieldsAreValid ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                                                        onChange={handleInputChange}
                                                        accept={
                                                            acceptedFileTypes.join(',') ||
                                                            '.pdf,.doc,.docx,.xls,.xlsx,.png,.svg,.zip,.csv'
                                                        }
                                                    />
                                                </label>
                                            </div>
                                            <p className="text-center text-sm text-neutral-700">
                                                <span className="text-secondary font-semibold text-xl">
                                                    *
                                                </span>
                                                {t('File_UPLOAD.FILE_SIZE_LIMIT')}
                                            </p>
                                            <p className="text-center text-sm text-neutral-700">
                                                <span className="text-secondary font-semibold text-xl leading-3">
                                                    *
                                                </span>
                                                {t('File_UPLOAD.FILE_TYPE_EXTENSION')} : .pdf, .doc,
                                                .docx, .xls, .xlsx, .png, .svg, .zip & .csv
                                            </p>
                                        </div>
                                        {uploadingStatusSection && (
                                            <UploadingFileStatus moduleName={moduleName} />
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </>
                )}
                {uploadedDocumentListTable && (
                    <div className="tableSecondColumnPadding">
                        <DataTableComponent
                            tableData={uploadedDocumentList}
                            tableDefinition={tableDefinition}
                            tableRequestBodyData={null}
                            toggleRowData={() => {}}
                            deleteRecord={handleDeleteRecord}
                            previewDocument={handlePreviewDocument}
                            showPagination={false}
                        />
                    </div>
                )}
            </div>
            <button
                type="button"
                id={`submit-${PATHS.FILE_UPLOAD}`}
                className="hidden"
                onClick={onSubmit}
                onKeyDown={(event) => {
                    if (event.key === 'Enter') {
                        onSubmit();
                    }
                }}
            />
        </div>
    );
};

export default FileUpload;
