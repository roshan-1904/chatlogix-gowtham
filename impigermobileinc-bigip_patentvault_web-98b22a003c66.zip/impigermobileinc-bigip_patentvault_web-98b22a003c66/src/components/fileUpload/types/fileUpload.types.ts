import {
    StepperQuoteStoreState,
    StepperStoreState
} from 'pages/components/progressStepper/types/progressStepper.type';

// Props interface for FileUpload component
export interface FileUploadProps<T> {
    moduleType: { moduleId: number; azureFolderName: string };
    primaryId: number;
    uploadFileApiUrl: string | null;
    getFileListApiUrl?: string;
    deleteFileApiUrl: string | null;
    getDocumentTypeApiUrl: string | null;
    updateDocumentTypeApiUrl: string | null;
    stepperModuleStore?: StepperStoreState<T> | StepperQuoteStoreState;
    documentUploadRequired?: boolean;
    documentUploadTitle?: boolean;
    documentUploadOptionalText?: boolean;
    uploadingStatusSection?: boolean;
    uploadedDocumentListTable?: boolean;
    isNotClassified?: boolean;
    handleReturnUploadedStatus?: (status: boolean) => void;
    childDropDown?: React.ReactNode;
    sourceReferenceDocumentType?: boolean;
    className?: string;
    ifFormalDocumentUpload?: { isFormalDoc: boolean; isExistingDocReplace?: boolean };
    ifFiledDocumentUpload?: { isFiledDoc: boolean; isExistingDocReplace?: boolean };
    formalDocumentFields?: FormalDocumentUploadType['formalDocumentFields'] | null;
    filedDocumentFields?: FiledDocumentUploadType | null;
    extraFields?: React.ReactNode;
    handleSelectedDocumentType?: (documentType: number) => void;
    multipleFiles?: boolean;
    acceptedFileTypes?: string[];
    documentTypeId?: number | null;
    documentTypeFlag?: boolean;
    singleFileUploadIndication?: (status: boolean) => void;
    isViewOnly?: boolean;
    moduleName: string;
    triggerFileInputClick?: (trigger: () => void) => void;
    isValidateRequiredFields?: boolean;
    fillRequiredFieldsAreValid?: boolean;
    hideColumns?: string[];
    additionParams?: { [key: string]: any };
    ifExecuteFormalDocumentUpload?: { isExecutingDoc: boolean; isExistingDocReplace?: boolean };
    executeFormalDocumentFields?: ExecuteFormalDocumentType['targetCountryId'] | null;
    titleForUploadSection?: JSX.Element | null;
    ifStandardDocumentUpload?: {
        isStandardDoc: boolean;
        documentType: number;
        stdGroupId: number;
        notesForUploadedFiles: string;
        storeFilesAgainstGroup: (files: TransformedObject[]) => void;
    };
    triggerHandleFiles?: (handleFiles: (files: File[]) => void) => void;
    isEpUPCOptOut?: boolean;
    replaceFileId?: number | null;
}
export interface DocumentInfo {
    fileId: number;
    taskId: number;
    fileName: string;
    blobFileName: string;
    documentType: number;
    fileSize: string;
    isActive: boolean;
    fileType: string;
    uploadedDate: string;
    uploadedBy: number;
    uploadedByName: string;
}

export interface ResponseDocumentType {
    id: number;
    name: string;
    moduleType: number;
    labelName: string;
    displayOrder: number;
}

export interface SavedDocumentResponse {
    documentId: number;
    moduleType: number;
    documentInfo: DocumentInfo[];
    isActive: boolean;
    createdAt: string;
    updatedAt: string | null;
    createdBy: number;
    updatedBy: string;
}

export interface UploadedDocumentInfo {
    fileName: string;
    fileType: string;
    fileSize: string;
    blobFileName: string;
    documentType: number;
    fileId: number;
    documentId: number;
    uploadedBy: string;
    disabled?: boolean;
}

export interface GetUploadedDocumentListResponse {
    blobUri: string;
    documentReturnsModel: UploadedDocumentInfo[];
}

export interface DocumentUploadType {
    fileName: string;
    fileType: string;
    fileSize: string;
    blobFileName: string;
    documentType: number;
}

export interface ReplaceExistingDocumentType {
    fileName: string;
    fileType: string;
    fileSize: string;
    blobFileName: string;
    documentType: number;
    replaceFormalDocumentURL: string;
    expectedDeliveryDate: string;
    hardCopy: boolean;
    vendorInvoiceNumber?: string | null;
}

export interface FormalDocumentUploadType {
    fileName?: string;
    fileType?: string;
    fileSize?: string;
    blobFileName?: string;
    documentType?: number;
    postURL?: string;
    formalDocumentFields?: {
        targetCountryId?: number;
        hardCopy?: boolean;
        expectedDeliveryDate?: string;
        vendorName?: string;
        vendorPhoneNumber?: string;
        vendorEmail?: string;
        disPatchAddress?: string;
        documentType?: number;
    };
}

export interface FiledDocumentUploadType {
    fileName?: string;
    fileType?: string;
    fileSize?: string;
    blobFileName?: string;
    documentType?: number;
    postURL?: string;
}

export interface ExecuteFormalDocumentType {
    fileName?: string;
    fileType?: string;
    fileSize?: string;
    blobFileName?: string;
    documentType?: number;
    postURL?: string;
    targetCountryId?: number;
}

export interface FilePayload {
    name: string;
    size: number;
    type: string;
    progress: string;
    file: object;
    documentType: number;
    azureBlobFolderPath: string;
    azureBlobFileName: string;
    moduleName: string;
    ifFormalDocumentUpload: {
        isFormalDoc: boolean;
        isExistingDocReplace: boolean;
    };
    formalDocumentFields: any;
    ifFiledDocumentUpload: {
        isFiledDoc: boolean;
        isExistingDocReplace: boolean;
    };
    filedDocumentFields: any;
    ifExecutingDocumentUpload?: {
        isExecutingDoc: boolean;
        isExistingDocReplace: boolean;
    };
    executeFormalDocumentFields: any;
    fileId?: number | null;

    // STD (optional)
    fileUniqueId?: number;
    fileNotes?: string;
    wordCount?: number;
}

export interface OriginalFileObject {
    name: string;
    size: number;
    type: string;
    progress: string;
    file: object;
    documentType: number;
    azureBlobFolderPath: string;
    azureBlobFileName: string;
    moduleName: string;
    uploadFileApiUrl: string;
    uploadedSuccessfully: boolean;
    ifFormalDocumentUpload: {
        isFormalDoc: boolean;
        isExistingDocReplace: boolean;
    };
    formalDocumentFields: any;
    primaryId: number;
    ifFiledDocumentUpload: {
        isFiledDoc: boolean;
        isExistingDocReplace: boolean;
    };
    filedDocumentFields: any;
    ifExecuteFormalDocumentUpload: {
        isExecutingDoc: boolean;
        isExistingDocReplace: boolean;
    };
    executeFormalDocumentFields: any;
    fileId?: number | null;

    // STD (optional)
    stdGroupId?: number;
    notesForUploadedFiles: string;
    storeFilesAgainstGroup?: (files: TransformedObject[]) => void;
}

export interface TransformedObject {
    primaryId: number;
    postURL: string | null;
    filePayload: FilePayload;

    // STD (optional)
    stdGroupId?: number;
    notesForUploadedFiles: string;
    storeFilesAgainstGroup?: (files: TransformedObject[]) => void;
}

// Define the type for groupedByPrimaryIdAndPostURL
export type GroupedByPrimaryIdAndPostURL = {
    [primaryId: string]: {
        [postURL: string]: TransformedObject[];
    };
};
