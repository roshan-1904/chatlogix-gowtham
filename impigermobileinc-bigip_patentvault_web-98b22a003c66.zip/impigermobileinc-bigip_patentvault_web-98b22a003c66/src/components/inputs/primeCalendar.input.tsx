const PrimeCalendar = () => {
    return <div>PrimeCalendar</div>;
};

export default PrimeCalendar;
