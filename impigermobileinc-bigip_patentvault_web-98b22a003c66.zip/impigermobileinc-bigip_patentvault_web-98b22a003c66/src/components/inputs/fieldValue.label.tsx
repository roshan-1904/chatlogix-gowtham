import { FC } from 'react';
import { ChipsModal } from 'components/reuseComponents/constructField';
import { convertToValidNumber } from 'core/utils/utils';
import { Tooltip } from 'primereact/tooltip';

type FieldValueLabelTemplateModal = {
    value: string | string[] | number | { id: number; value: string }[] | null | JSX.Element;
    fieldLabelName?: string | null;
    renderAs: 'string' | 'number';
    decimalLength?: number | null;
    currency?: string | null;
    chips?: ChipsModal;
    tooltipContent?: string | null;
    customClass?: { wrapper?: string; field?: string };
    testId?: string;
    nextToValueTemplate?: JSX.Element | null;
    isPercentage?: boolean;
};

const FieldValue: FC<FieldValueLabelTemplateModal> = ({
    value,
    fieldLabelName,
    renderAs,
    decimalLength,
    currency,
    chips,
    tooltipContent = null,
    customClass,
    testId,
    nextToValueTemplate = null,
    isPercentage = false
}) => {
    const updatedFieldLabelName = String(fieldLabelName).replace(/[^a-zA-Z0-9]/g, '');
    const isProceedTooltip =
        updatedFieldLabelName &&
        tooltipContent &&
        (typeof tooltipContent === 'string' || typeof tooltipContent === 'number');
    const isBindTooltipOnDOM = isProceedTooltip && tooltipContent !== '';
    const tooltipUniqueData = isProceedTooltip ? updatedFieldLabelName : null;

    /** this template used for to show field value as label. pls declare decimal info properly while using. */
    const chipsTemplateStyle =
        'flex h-6 w-fit rounded-lg whitespace-nowrap text-center items-center justify-center bg-primary-50 font-medium border border-primary-500 p-3';
    let fieldValue = value ?? null;

    if (
        (value || value === 0) &&
        (currency || decimalLength) &&
        (typeof value === 'number' || typeof value === 'string')
    ) {
        fieldValue = convertToValidNumber({
            value,
            decimalLength: decimalLength ?? 0,
            renderAs
        });
    } else if (chips?.isTemplateChips && Array.isArray(chips.chipsContent)) {
        fieldValue = chips.chipsContent.length ? chips.chipsContent : null;
    }

    return (
        <div className={`${customClass?.wrapper ?? ''}`}>
            {isBindTooltipOnDOM && (
                <Tooltip
                    position="bottom"
                    target={'.labelFor' + tooltipUniqueData}
                    content={tooltipContent}
                    pt={{
                        root: {
                            className: 'max-w-96 shadow-none'
                        }
                    }}
                />
            )}
            {chips?.isTemplateChips && Array.isArray(fieldValue) ? (
                <div
                    id="fieldValueChipsWrapper"
                    data-testId={testId}
                    className="flex flex-wrap gap-2.5 overflow-y-auto max-h-24">
                    {fieldValue.map((chipData, index) => (
                        <div
                            key={index + 1}
                            className={`${chipsTemplateStyle} flex gap-2 items-center justify-center`}
                            style={{ fontSize: '0.8rem' }}>
                            <span>{`${typeof chipData === 'object' ? chipData.value : chipData}`}</span>
                            {chips?.isChipsDeletable && (
                                <i
                                    className="pi pi-times cursor-pointer"
                                    onClick={() => {
                                        chips?.action?.(
                                            typeof chipData === 'object' ? chipData.id : chipData
                                        );
                                    }}
                                />
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <span
                    id="field"
                    className={`flex gap-1 leading-5 items-center ${customClass?.field ?? ''}`}>
                    {isPercentage !== true && currency && <p>{currency}</p>}
                    <p
                        data-testId={testId}
                        className={`${isBindTooltipOnDOM ? 'labelFor' + tooltipUniqueData : ''} truncate leading-normal`}>
                        {fieldValue?.toString() || '-'}
                    </p>
                    {nextToValueTemplate}
                    {isPercentage === true && <p>%</p>}
                </span>
            )}
        </div>
    );
};

export default FieldValue;
