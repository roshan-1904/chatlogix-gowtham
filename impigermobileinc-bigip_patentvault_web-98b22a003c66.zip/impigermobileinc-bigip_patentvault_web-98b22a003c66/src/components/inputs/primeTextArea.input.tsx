import { FC } from 'react';
import { InputTextarea, InputTextareaProps } from 'primereact/inputtextarea';
import { classNames } from 'primereact/utils';
import LabelName from './labelName';
import { inputStyleText } from 'constants/styles.constant';

interface PrimeTextModel extends Omit<InputTextareaProps, 'onChange' | 'value'> {
    fieldLabelName?: string | JSX.Element | null;
    value: string;
    testId: string;
    placeholder?: string;
    disabled?: boolean;
    invalid?: boolean;
    onChange: (value: string) => void;
    showInputLabelName?: boolean; // if true, it will not render the label name
    customClass?: { wrapper?: string; field?: string };
}

const PrimeTextArea: FC<PrimeTextModel> = ({
    fieldLabelName = 'Label Name N/A',
    value,
    testId,
    placeholder = '',
    disabled = false,
    invalid = false,
    onChange,
    showInputLabelName = false,
    customClass,
    ...rest
}) => {
    const getClassName = (type: 'wrapper' | 'field') => {
        if (type === 'wrapper') {
            return classNames('flex flex-col gap-1 w-full', customClass?.wrapper);
        } else if (type === 'field') {
            return classNames('resize-none', customClass?.field, {
                'is-invalid': invalid,
                'is-disabled': disabled
            });
        }
        return '';
    };

    return (
        <div data-testid={testId} className={getClassName('wrapper')}>
            {showInputLabelName && <LabelName name={fieldLabelName} />}
            <InputTextarea
                value={value}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => onChange(e.target.value)}
                disabled={disabled}
                invalid={invalid}
                rows={5}
                cols={30}
                pt={inputStyleText}
                {...rest}
            />
        </div>
    );
};

export default PrimeTextArea;
