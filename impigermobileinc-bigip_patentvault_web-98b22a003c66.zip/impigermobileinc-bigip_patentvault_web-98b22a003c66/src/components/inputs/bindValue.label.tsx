const BindValue = () => {
    return <div>BindValue</div>;
};

export default BindValue;
