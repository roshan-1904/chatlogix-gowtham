import { FC } from 'react';
import { classNames } from 'primereact/utils';
import { InputText, InputTextProps } from 'primereact/inputtext';
import { KeyFilterType } from 'primereact/keyfilter';
import LabelName from './labelName';
import { inputStyleText } from 'constants/styles.constant';

interface PrimeTextModel extends Omit<InputTextProps, 'onChange' | 'value'> {
    fieldLabelName?: string | JSX.Element | null;
    value: string;
    placeholder?: string;
    disabled?: boolean;
    invalid?: boolean;
    onChange: (value: string) => void;
    keyfilter?: KeyFilterType;
    showInputLabelName?: boolean; // if true, it will not render the label name
    customClass?: { wrapper?: string; inputField?: string };
    testId?: { label?: string; field?: string };
}

const PrimeText: FC<PrimeTextModel> = ({
    fieldLabelName = 'Label Name N/A',
    value,
    placeholder = '',
    disabled = false,
    invalid = false,
    onChange,
    keyfilter = /.*?/,
    showInputLabelName = false,
    customClass,
    testId,
    ...rest
}) => {
    const getClassName = (type: 'wrapper' | 'field') => {
        if (type === 'wrapper') {
            return classNames('flex flex-col gap-1 w-full', customClass?.wrapper);
        } else if (type === 'field') {
            return classNames('!text-black', customClass?.inputField, {
                'is-invalid': invalid,
                'is-disabled': disabled
            });
        }
        return '';
    };

    return (
        <div className={getClassName('wrapper')}>
            {showInputLabelName && <LabelName testId={testId?.label} name={fieldLabelName} />}
            <InputText
                value={value}
                className={getClassName('field')}
                data-testid={testId?.field}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => onChange(e.target.value)}
                placeholder={placeholder}
                disabled={disabled}
                invalid={invalid}
                pt={inputStyleText}
                keyfilter={keyfilter}
                {...rest}
            />
        </div>
    );
};

export default PrimeText;
