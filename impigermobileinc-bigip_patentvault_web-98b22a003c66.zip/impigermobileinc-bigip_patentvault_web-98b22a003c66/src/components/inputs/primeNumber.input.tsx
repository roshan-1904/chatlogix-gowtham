import { FC } from 'react';
import { InputNumber, InputNumberChangeEvent, InputNumberProps } from 'primereact/inputnumber';
import { convertToValidNumber } from 'core/utils/utils';
import { classNames } from 'primereact/utils';
import LabelName from './labelName';
import { inputStyleNumber } from 'constants/styles.constant';

interface PrimeNumberModel extends Omit<InputNumberProps, 'onChange' | 'value'> {
    fieldLabelName?: string | JSX.Element | null;
    value: number;
    testId: string;
    isDecimal?: boolean;
    decimalLength?: number;
    placeholder?: string;
    disabled?: boolean;
    invalid?: boolean;
    onChange: (value: number | null) => void;
    showInputLabelName?: boolean; // if true, it will not render the label name
    customClass?: { wrapper?: string; field?: string };
}

const PrimeNumber: FC<PrimeNumberModel> = ({
    fieldLabelName = 'Label Name N/A',
    value,
    testId,
    placeholder = '',
    disabled = false,
    invalid = false,
    isDecimal = false,
    decimalLength,
    onChange,
    showInputLabelName: renderInputWithLabelName = false,
    customClass,
    ...rest
}) => {
    const getDecimalLength = () => {
        const length = isDecimal ? (decimalLength ?? 4) : 0;
        return length;
    };
    const getValue = () => {
        const convertedValue = convertToValidNumber({
            value,
            decimalLength: getDecimalLength(),
            renderAs: 'number'
        });
        if (typeof convertedValue === 'number' && !isNaN(convertedValue)) {
            return convertedValue;
        }
        return null;
    };
    const getClassName = (type: 'wrapper' | 'field') => {
        if (type === 'wrapper') {
            return classNames('flex flex-col gap-1', customClass?.wrapper);
        } else if (type === 'field') {
            return classNames(customClass?.field, {
                'is-invalid': invalid,
                'is-disabled': disabled
            });
        }
        return '';
    };

    return (
        <div data-testid={testId} className={getClassName('wrapper')}>
            {renderInputWithLabelName && <LabelName name={fieldLabelName} />}
            <InputNumber
                value={getValue()}
                className={getClassName('field')}
                onChange={(e: InputNumberChangeEvent) => onChange(e.value)}
                disabled={disabled}
                placeholder={placeholder}
                minFractionDigits={0}
                maxFractionDigits={getDecimalLength()}
                pt={{
                    ...inputStyleNumber,
                    input: {
                        root: {
                            className: inputStyleNumber.input.root.className + ' !text-black'
                        }
                    }
                }}
                {...rest}
            />
        </div>
    );
};

export default PrimeNumber;
