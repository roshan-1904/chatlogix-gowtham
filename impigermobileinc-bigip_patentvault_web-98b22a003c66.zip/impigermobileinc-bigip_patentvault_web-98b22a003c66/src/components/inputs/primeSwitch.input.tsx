const PrimeSwitch = () => {
    return <div>PrimeSwitch</div>;
};

export default PrimeSwitch;
