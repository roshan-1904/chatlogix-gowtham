import React, { ReactNode } from 'react';

export type LabelNameProps = {
    name?: ReactNode;
    description?: ReactNode;
    required?: boolean;
    testId?: string;
    customStyle?: {
        descriptionStyle?: string;
        nameStyle?: string;
    };
};

const LabelName: React.FC<LabelNameProps> = ({
    name,
    description = null,
    required = false,
    testId = '',
    customStyle
}) => {
    if (!name) return null;

    return (
        <div data-testId={testId} className="flex gap-1.5 font-medium items-center justify-start">
            <label
                className={`flex gap-1 text-neutral-700 truncate leading-6 ${customStyle?.nameStyle}`}>
                {name}
                {required && <span className="text-secondary">*</span>}
            </label>
            {description && (
                <p className={`text-secondary leading-6 ${customStyle?.descriptionStyle}`}>
                    {description}
                </p>
            )}
        </div>
    );
};
export default LabelName;
