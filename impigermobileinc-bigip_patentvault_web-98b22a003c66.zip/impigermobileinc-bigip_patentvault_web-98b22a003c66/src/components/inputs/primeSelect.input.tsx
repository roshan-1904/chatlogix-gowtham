import { FC } from 'react';
import { classNames } from 'primereact/utils';
import { MultiSelect, MultiSelectChangeEvent, MultiSelectProps } from 'primereact/multiselect';
import LabelName from './labelName';
import { multiSelectFilterStyles } from 'shared/dataTable/constant/dataTable.styles';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import { Dropdown, DropdownChangeEvent, DropdownProps } from 'primereact/dropdown';

interface PrimeSelectModel<T = any>
    extends Omit<MultiSelectProps & DropdownProps, 'onChange' | 'value' | 'options'> {
    fieldLabelName?: string | JSX.Element | null;
    value: T[] | T;
    options: T[];
    optionLabel: string;
    optionValue: string;
    testId: string;
    placeholder?: string;
    disabled?: boolean;
    invalid?: boolean;
    required?: boolean;
    onChange: (value: number | number[]) => void;
    showInputLabelName?: boolean; // if true, it will not render the label name
    isMultiSelect?: boolean; // if true, it will render as a multi-select component
    tooltip?: string;
    loading?: boolean;
    isFilterEnabled?: boolean;
    isClearEnabled?: boolean;
    isRenderAsChip?: boolean;
    errorMsg?: string;
    customClass?: { wrapper?: string; field?: string };
}

const PrimeSelect: FC<PrimeSelectModel> = ({
    fieldLabelName = 'Label Name N/A',
    value,
    options,
    optionLabel,
    optionValue,
    testId,
    placeholder = '',
    disabled = false,
    invalid = false,
    required = false,
    onChange,
    showInputLabelName = false,
    isMultiSelect = true,
    tooltip = '',
    loading = false,
    isFilterEnabled = false,
    isClearEnabled = false,
    isRenderAsChip = false,
    errorMsg = 'Required',
    customClass,
    ...rest
}) => {
    const getValue = () => {
        let updateValue;
        if (isMultiSelect) {
            updateValue = value;
        } else {
            updateValue = Array.isArray(value) ? value[0] : value;
        }

        return updateValue;
    };
    const getClassName = (type: 'wrapper' | 'field') => {
        if (type === 'wrapper') {
            return classNames('flex flex-col gap-1 w-full', customClass?.wrapper);
        } else if (type === 'field') {
            return classNames('!w-full', customClass?.field, {
                'is-invalid': invalid,
                'is-disabled': disabled
            });
        }
        return '';
    };
    const getPTStyles = () => {
        return {
            ...multiSelectFilterStyles,
            root: {
                className: `${multiSelectFilterStyles.root.className} h-10`
            },
            clearIcon: {
                ...multiSelectFilterStyles.clearIcon,
                className: 'h-4 w-4'
            },
            label: { className: 'max-w-[90%]' }
        };
    };

    return (
        <div data-testid={testId} className={getClassName('wrapper')}>
            {showInputLabelName && <LabelName name={fieldLabelName} />}
            {isMultiSelect ? (
                <MultiSelect
                    value={getValue()}
                    options={options}
                    optionLabel={optionLabel}
                    optionValue={optionValue}
                    placeholder={placeholder}
                    disabled={disabled}
                    invalid={invalid}
                    filter={isFilterEnabled}
                    showClear={isClearEnabled}
                    display={isRenderAsChip ? 'chip' : 'comma'}
                    selectionLimit={undefined}
                    tooltip={tooltip}
                    loading={loading}
                    onChange={(e: MultiSelectChangeEvent) => onChange(e.value as number[])}
                    className={getClassName('field')}
                    pt={getPTStyles()}
                    {...rest}
                />
            ) : (
                <Dropdown
                    value={getValue()}
                    options={options}
                    optionLabel={optionLabel}
                    optionValue={optionValue}
                    placeholder={placeholder}
                    disabled={disabled}
                    filter={isFilterEnabled}
                    showClear={isClearEnabled}
                    tooltip={tooltip}
                    loading={loading}
                    onChange={(e: DropdownChangeEvent) => onChange(e.value as number)}
                    className={getClassName('field')}
                    pt={getPTStyles()}
                    {...rest}
                />
            )}
            {invalid && <ErrorLabel message={errorMsg} customStyle="flex w-full justify-end" />}
        </div>
    );
};

export default PrimeSelect;
