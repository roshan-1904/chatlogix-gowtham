import { render, screen, fireEvent } from '@testing-library/react';
import { PrimeRadioGroup } from './primeRadio.input';

describe('PrimeRadioGroup Component', () => {
    const mockOnChange = jest.fn();
    const options = [
        { key: 1, name: 'Option 1' },
        { key: 2, name: 'Option 2' }
    ];
    const defaultProps = {
        labelName: 'Select an option',
        options,
        selectedValue: 1,
        groupName: 'testGroup',
        actions: { onChange: mockOnChange }
    };

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders correctly with label and options', () => {
        render(<PrimeRadioGroup {...defaultProps} />);

        expect(screen.getByText('Select an option')).toBeInTheDocument();
        expect(screen.getByLabelText('Option 1')).toBeInTheDocument();
        expect(screen.getByLabelText('Option 2')).toBeInTheDocument();
    });

    test('calls onChange when an option is clicked', () => {
        render(<PrimeRadioGroup {...defaultProps} />);
        const option2 = screen.getByLabelText('Option 2');
        fireEvent.click(option2);

        expect(mockOnChange).toHaveBeenCalledWith(2);
    });

    test('applies custom class names if provided', () => {
        const customProps = {
            ...defaultProps,
            customClass: {
                fieldWrapper: 'custom-wrapper',
                label: 'custom-label',
                radioWrapper: 'custom-radio'
            }
        };
        render(<PrimeRadioGroup {...customProps} />);

        expect(screen.getByText('Select an option')).toHaveClass('custom-label');
        expect(screen.getByTestId('fieldWrapper')).toHaveClass('custom-wrapper');
    });

    test('disables radio buttons when disabled prop is true', () => {
        render(<PrimeRadioGroup {...defaultProps} disabled={true} />);
        const option1 = screen.getByLabelText('Option 1');
        const option2 = screen.getByLabelText('Option 2');

        expect(option1).toBeDisabled();
        expect(option2).toBeDisabled();
    });

    test('shows required indicator when required prop is true', () => {
        render(<PrimeRadioGroup {...defaultProps} required={true} />);
        expect(screen.getByText('*')).toBeInTheDocument();
    });
});
