import { RadioButton, RadioButtonProps } from 'primereact/radiobutton';

interface PrimeRadioGroupModel extends RadioButtonProps {
    labelName: string;
    options: { key: number; name: string }[];
    selectedValue: number;
    groupName: string;
    required?: boolean;
    disabled?: boolean;
    invalid?: boolean;
    customClass?: { fieldWrapper?: string; label?: string; radioWrapper?: string };
    actions: { onChange: (value: number) => void };
}
export const PrimeRadioGroup = ({
    labelName,
    options,
    selectedValue,
    groupName,
    required = false,
    disabled = false,
    invalid = false,
    customClass,
    actions
}: PrimeRadioGroupModel) => {
    return (
        <div
            id={'fieldWrapper'}
            data-testid="fieldWrapper"
            className={`${customClass?.fieldWrapper ?? ''}`}>
            <label className={`flex gap-1 my-2 ${customClass?.label ?? ''}`}>
                {labelName}
                {required && <span className="text-secondary font-medium">*</span>}
            </label>
            <div className={`flex flex-row gap-3 ${customClass?.radioWrapper ?? ''}`}>
                {options.map((option) => {
                    return (
                        <div key={option.key} className="flex align-items-center">
                            <RadioButton
                                inputId={`radio-${option.key}`}
                                name={groupName}
                                value={option.key}
                                onChange={(e: { value: number }) => actions.onChange(e.value)}
                                checked={selectedValue === option.key}
                                disabled={disabled}
                                invalid={invalid}
                            />
                            <label htmlFor={`radio-${option.key}`} className="ml-2 cursor-pointer">
                                {option.name}
                            </label>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
