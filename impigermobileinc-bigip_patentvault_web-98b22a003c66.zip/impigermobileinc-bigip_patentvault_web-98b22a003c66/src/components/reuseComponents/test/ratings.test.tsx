import { render, screen, fireEvent } from '@testing-library/react';
import Ratings from '../ratings';
import '@testing-library/jest-dom/extend-expect';

describe('Ratings Component', () => {
    const setRatingValue = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should render the rating component with custom icons', () => {
        const ratingValue = 3;
        render(<Ratings ratingValue={ratingValue} setRatingValue={setRatingValue} />);

        // Check if the component renders the correct number of stars
        const ratingStars = screen.getAllByTestId('rating-star');
        expect(ratingStars.length).toBe(5); // Assuming the Rating component has 5 stars

        // Check if the custom images are rendered correctly
        const filledStars = screen.getAllByAltText('custom-image-active');
        expect(filledStars.length).toBe(ratingValue); // The number of filled stars should match the rating value

        const emptyStars = screen.getAllByAltText('custom-image');
        expect(emptyStars.length).toBe(5 - ratingValue); // The number of empty stars should be the remaining stars
    });

    it('should call setRatingValue when a star is clicked', () => {
        const ratingValue = 2;
        render(<Ratings ratingValue={ratingValue} setRatingValue={setRatingValue} />);

        // Find all the stars
        const ratingStars = screen.getAllByTestId('rating-star');

        // Simulate clicking on the fourth star
        fireEvent.click(ratingStars[3]);

        // Ensure that setRatingValue was called with the correct value (4 in this case)
        expect(setRatingValue).toHaveBeenCalledWith(4);
    });

    it('should handle clicking on different stars and update the rating value accordingly', () => {
        const ratingValue = 1;
        render(<Ratings ratingValue={ratingValue} setRatingValue={setRatingValue} />);

        // Simulate clicking on the first star (index 0), then click on the second star
        const ratingStars = screen.getAllByTestId('rating-star');

        fireEvent.click(ratingStars[0]); // First click should set it to 1

        // Ensure that setRatingValue was called with the correct value
        expect(setRatingValue).toHaveBeenCalledWith(1);

        fireEvent.click(ratingStars[1]); // Second click should set it to 2
        expect(setRatingValue).toHaveBeenCalledWith(2);
    });
});
