/* eslint-disable @typescript-eslint/no-redundant-type-constituents */
import edit from 'assets/images/editGrey.svg';
import tick from 'assets/svgs/tick.svg';
import close from 'assets/svgs/close-icon.svg';
import { inputSwitchPT } from 'constants/styles.constant';
import {
    calendarStyles,
    multiSelectFilterStyles
} from 'shared/dataTable/constant/dataTable.styles';
import { Chips } from 'primereact/chips';
import ErrorLabel from './errorLabel';
import { FC } from 'react';
import { InputSwitch } from 'primereact/inputswitch';
import { Calendar } from 'primereact/calendar';
import { Nullable } from 'primereact/ts-helpers';
import LabelName from 'components/inputs/labelName';
import PrimeText from 'components/inputs/primeText.input';
import { classNames } from 'primereact/utils';
import PrimeNumber from 'components/inputs/primeNumber.input';
import PrimeTextArea from 'components/inputs/primeTextArea.input';
import PrimeSelect from 'components/inputs/primeSelect.input';
import FieldValue from 'components/inputs/fieldValue.label';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';

type FieldType = 'input' | 'dropdown' | 'toggle' | 'calendar' | 'chips' | undefined;
export interface CustomClassModal {
    mainWrapper?: string;
    wrapperRow1?: string;
    wrapperRow2?: string;
    // fieldValueChipsWrapper?: string;
    fieldValueLabel?: string;
    /** typical class name for input fields wrapper element. this is not against the input. */
    fieldWrapperClass?: string;
    fieldLabel?: string;
    inputField?: string;
}
export interface ChipsModal {
    /** grouped data format for both "Chips component" & "Chips styled UI list while non-editable mode". */

    // non-editable mode - to show as Chips styles labels
    isTemplateChips?: boolean; // is field value show as Chips in non-editable mode?
    chipsContent?: string[] | { id: number; value: string }[]; // converted API data as string array for chips
    isChipsDeletable?: boolean;
    action?: (selectedChips: number | string) => void;

    // editable mode - error data for React Chips component
    // isChipsError?: boolean; // is user typed invalid chips data?
    // chipsErrorMessage?: string;
}
interface InputTypeModal {
    type:
        | 'text'
        | 'textarea'
        | 'email'
        | 'number'
        | 'select'
        | 'multiselect'
        | 'calendar'
        | 'others'
        | undefined; // others - chips / toggle
    renderAs?: 'string' | 'number';
    isDecimal?: boolean;
    decimalLength?: number;
}
interface SelectModal {
    options: any[];
    optionLabel: string;
    optionValue: string;
    isFilterEnabled?: boolean;
}
interface CalendarModal {
    minDate?: Date;
    maxDate?: Date;
    dateFormat?: string;
    showIcon?: boolean;
    selectionMode?: 'single' | 'range' | 'multiple';
    locale?: string;
    readOnlyInput?: boolean;
    showButtonBar?: boolean;
}
interface ActionsModal {
    edit?: () => void; // icon
    update?: () => void; // icon
    cancel?: () => void; // icon
    reset?: () => void; // reset field value to API response value
    onChange?: (value: any) => void; // for input field
    onClick?: (value: any) => void; // for dropdown, toggle, date
}
interface IconTemplateModal {
    iconType: 'pencil' | 'tick' | 'cancel' | 'others';
    imgSource: string;
    alterText: string;
    action?: (value?: any, value2?: any) => void;
}
interface InputFieldModal {
    fieldType: FieldType;
    inputType: InputTypeModal;
    fieldValue:
        | string
        | string[]
        | number[]
        | number
        | boolean
        | null
        | Nullable<Date>
        | Nullable<Date[]>; // input value - API response
    value:
        | string
        | string[]
        | number[]
        | number
        | boolean
        | null
        | Nullable<Date>
        | Nullable<Date[]>; // input value - current (state)
    required?: boolean;
    disabled?: boolean;
    invalid?: boolean;
    errorMessage?: string;
    onChange?: (value?: any) => void;
    fieldLabelName: JSX.Element | string | null; // as translation string key
    moreInputInfo?: {
        select?: SelectModal; // dropdown
        calendar?: CalendarModal;
        chips?: ChipsModal;
    };
    placeholder?: string | null;
    customClass?: CustomClassModal;
    /** 'getFieldAlone' is used for, each input field has own label name tag. 
    while we construct the field as own template then set this as true to omit the that field label. */
    getFieldAlone?: boolean;
    testId?: { label?: string; field?: string };
    onkeyDown?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
}
interface FieldTemplateDetailsModal {
    isFieldHasEditability?: boolean; // field editable permission
    isFieldInEditMode?: boolean; // to find field is in edit mode or not
    isFieldHasResetAbility?: boolean; // field reset permission
    fieldType?: FieldType;
    inputType?: InputTypeModal;
    fieldValue: any; // input value - API response
    // fieldValue: string | number | null | Date; // input value - API response
    state?: any; // input value - current (state)
    fieldLabelName: JSX.Element | string | null; // as translation string key
    fieldLabelDesc?: JSX.Element | string | null; // label beside description
    nextToValueTemplate?: JSX.Element | null; // next to field value template
    tooltip?: {
        content: string | null;
        customClass?: string;
    };
    moreInputInfo?: {
        select?: SelectModal; // dropdown
        calendar?: CalendarModal;
        chips?: ChipsModal; // chips data
    };
    required?: boolean;
    disabled?: boolean;
    invalid?: boolean;
    errorMessage?: string;
    actions?: ActionsModal; // onClick actions
    placeholder?: string | null;
    currency?: string | null; // send this if field is currency type
    customClass?: CustomClassModal;
    testId?: { label?: string; field?: string };
    hidden?: boolean; // to hide the field
}

export const IconTemplate: FC<{ data: IconTemplateModal }> = ({ data }) => {
    let iconStyle = 'h-3 cursor-pointer';
    const iconWrapperStyle =
        'h-7 w-7 shadow-md shadow-gray-200 rounded-lg flex items-center justify-center cursor-pointer';
    if (data.iconType === 'pencil') iconStyle += ' p-0 mx-3 my-1';

    const icon = (
        <img
            alt={data.alterText}
            src={data.imgSource}
            className={iconStyle}
            onClick={data.action}
            onKeyDown={(e) => e.key === 'Enter' && data.action && data.action()}
        />
    );

    return data.iconType === 'pencil' ? icon : <div className={iconWrapperStyle}>{icon}</div>;
};
export const InputFieldTemplate: FC<{ data: InputFieldModal }> = ({ data }) => {
    // custom attributes
    /** const customAttributes = {
         ...(data.inputType.isDecimal && {
             minFractionDigits: 0,
             maxFractionDigits: data?.inputType?.decimalLength ?? 0
         })
     }; */

    const defaultFieldErrorMessage = 'Field is invalid.';

    const getValue = () => {
        const { fieldType, value, fieldValue } = data;

        const finalValue = value ?? fieldValue;

        if (fieldType === 'chips') {
            // return as array
            return finalValue ?? [];
        } else if (fieldType === 'calendar') {
            // return as date
            if (finalValue) {
                if (typeof finalValue === 'string') return new Date(finalValue);
                else return finalValue;
            } else {
                return undefined;
            }
        } else {
            // return as string (default)
            return (finalValue ?? '').toString();
        }
    };
    const errorLabelTemplate = (fieldLabelName?: string | null, errorMessage?: string) => {
        const errMsg =
            errorMessage ||
            (fieldLabelName ? `${fieldLabelName} is required` : defaultFieldErrorMessage);
        return (
            <ErrorLabel
                message={errMsg}
                customStyle="flex w-full justify-end [&>span]:text-[0.865rem]"
            />
        );
    };
    // const getDecimalLength = () =>
    //     data.inputType.isDecimal ? (data?.inputType?.decimalLength ?? 4) : 0; // 0 means, no decimal accepted as default

    return (
        <>
            {data.fieldType === 'input' && (
                <>
                    {data.inputType.type === 'text' && (
                        <div className="w-full relative">
                            <PrimeText
                                fieldLabelName={data.fieldLabelName}
                                value={(data.value ?? data.fieldValue) as string}
                                testId={{ label: data.testId?.label, field: data.testId?.field }}
                                placeholder={data.placeholder ?? ''}
                                disabled={data.disabled}
                                invalid={data.invalid}
                                onChange={(e) => data.onChange && data.onChange(e)}
                                showInputLabelName={!data.getFieldAlone}
                                customClass={{
                                    wrapper: classNames(
                                        'w-full',
                                        data.customClass?.fieldWrapperClass
                                    ),
                                    inputField: classNames(data.customClass?.inputField)
                                }}
                            />
                            <span className="absolute right-0 mt-0.5">
                                {data.invalid && errorLabelTemplate(undefined, data.errorMessage)}
                            </span>
                        </div>
                    )}
                    {data.inputType.type === 'number' && (
                        <PrimeNumber
                            fieldLabelName={data.fieldLabelName}
                            value={
                                data.value === undefined
                                    ? (data.fieldValue as number)
                                    : (data.value as number)
                            }
                            testId="primeNumber"
                            placeholder={data.placeholder ?? ''}
                            disabled={data.disabled}
                            invalid={data.invalid}
                            isDecimal={data.inputType.isDecimal ?? true}
                            onChange={(e) => data.onChange && data.onChange(e)}
                            onKeyDown={data.onkeyDown}
                            showInputLabelName={!data.getFieldAlone}
                            customClass={{
                                wrapper: classNames('w-full', data.customClass?.fieldWrapperClass)
                            }}
                        />
                    )}
                    {data.inputType.type === 'textarea' && (
                        <PrimeTextArea
                            fieldLabelName={data.fieldLabelName}
                            value={(data.value ?? data.fieldValue) as string}
                            testId="primeTextArea"
                            placeholder={data.placeholder ?? ''}
                            disabled={data.disabled}
                            invalid={data.invalid}
                            onChange={(e) => data.onChange && data.onChange(e)}
                            showInputLabelName={!data.getFieldAlone}
                            customClass={{
                                wrapper: classNames('w-full', data.customClass?.fieldWrapperClass)
                            }}
                        />
                    )}
                </>
            )}
            {data.fieldType === 'chips' && (
                <div
                    className={`flex flex-wrap w-full gap-1.5 ${data.customClass?.fieldWrapperClass ?? ''}`}>
                    {!data.getFieldAlone && <LabelName name={data.fieldLabelName} />}
                    <Chips
                        addOnBlur
                        className="w-full"
                        value={getValue() ? (getValue() as string[]) : []}
                        onChange={(e: any) => data.onChange && data.onChange(e.target.value)}
                    />
                    {data.invalid && errorLabelTemplate()}
                </div>
            )}
            {data.fieldType === 'toggle' && (
                <div className={`flex  ${data.customClass?.fieldWrapperClass ?? ''}`}>
                    {/**  ${defaultFieldMargin} */}
                    {!data.getFieldAlone && <LabelName name={data.fieldLabelName} />}
                    <InputSwitch
                        className={``}
                        checked={Boolean(data.value ?? data.fieldValue)}
                        invalid={data.invalid}
                        onChange={(e) => data.onChange && data.onChange(e.value)}
                        pt={inputSwitchPT}
                    />
                    {data.invalid && errorLabelTemplate()}
                </div>
            )}
            {data.fieldType === 'dropdown' && (
                <PrimeSelect
                    testId={'primeSelect'}
                    fieldLabelName={data.fieldLabelName}
                    value={data.value ?? data.fieldValue}
                    options={data.moreInputInfo?.select?.options as any[]} // ###
                    optionLabel={data.moreInputInfo?.select?.optionLabel as string} // ###
                    optionValue={data.moreInputInfo?.select?.optionValue as string} // ###
                    placeholder={data.placeholder ?? ''}
                    required={data.required ?? false}
                    disabled={data.disabled ?? false}
                    invalid={data.invalid ?? false}
                    showInputLabelName={!data.getFieldAlone}
                    isMultiSelect={data.inputType.type === 'multiselect'}
                    isFilterEnabled={true}
                    isClearEnabled={true}
                    isRenderAsChip={false}
                    errorMsg={'Required'}
                    customClass={{
                        wrapper: classNames(
                            'flex flex-col w-full',
                            data.customClass?.fieldWrapperClass
                        )
                    }}
                    onChange={(selectedValue) => data.onChange && data.onChange(selectedValue)}
                    pt={{
                        ...multiSelectFilterStyles,
                        root: {
                            className: `${multiSelectFilterStyles.root.className} h-10 !w-full`
                        },
                        clearIcon: {
                            ...multiSelectFilterStyles.clearIcon,
                            className: 'h-4 w-4'
                        },
                        label: { className: 'max-w-[90%]' }
                    }}
                />
            )}
            {data.fieldType === 'calendar' &&
                data.moreInputInfo?.calendar?.selectionMode === 'single' && (
                    <Calendar
                        value={(getValue() as Date) ?? undefined}
                        onChange={(e: any) => data.onChange && data.onChange(e.value)}
                        // state
                        disabled={data.disabled ?? false}
                        invalid={data.invalid ?? false}
                        // configuration
                        selectionMode="single"
                        dateFormat={data.moreInputInfo?.calendar?.dateFormat ?? 'M dd,yy'}
                        minDate={data.moreInputInfo?.calendar?.minDate}
                        maxDate={data.moreInputInfo?.calendar?.maxDate}
                        locale={data.moreInputInfo?.calendar?.locale ?? 'en'}
                        // UI/functionality options
                        className={`calender-input input px-2 rounded 
            input-bordered h-8 border-[0.02rem] focus-within:outline-none 
            border-neutral-100  flex items-center gap-2 w-48`}
                        showIcon={data.moreInputInfo?.calendar?.showIcon ?? false}
                        showButtonBar={data.moreInputInfo?.calendar?.showButtonBar ?? false}
                        readOnlyInput={data.moreInputInfo?.calendar?.readOnlyInput ?? false}
                        pt={{ ...calendarStyles }}
                    />
                )}
        </>
    );
};

// template constructor
const ConstructField = ({ data }: { data: FieldTemplateDetailsModal }) => {
    return (
        <div
            id="mainWrapper"
            className={`flex flex-col ${data.customClass?.mainWrapper ?? ''} ${data.hidden ? 'hidden' : ''}`}>
            <div
                id="wrapperRow1"
                className={`flex items-center justify-start ${data.customClass?.wrapperRow1 ?? ''}`}>
                {/* Field Title Label */}

                {data.fieldLabelName && (
                    <LabelName
                        testId={data.testId?.label}
                        name={data.fieldLabelName}
                        customStyle={{ nameStyle: data.customClass?.fieldLabel ?? '' }}
                        description={data.fieldLabelDesc}
                    />
                )}
                {/* Icon - Edit */}
                {data.isFieldHasEditability && !data.isFieldInEditMode && (
                    <IconTemplate
                        data={{
                            iconType: 'pencil',
                            imgSource: edit,
                            alterText: 'edit',
                            action: data?.actions?.edit
                        }}
                    />
                )}
                {data.isFieldHasResetAbility && !data.isFieldInEditMode && (
                    <i
                        className="pi pi-refresh  hover:text-blue-500 cursor-pointer"
                        onClick={data?.actions?.reset}></i>
                )}
            </div>

            <div id="wrapperRow2" className={data.customClass?.wrapperRow2 ?? ''}>
                {!data.isFieldInEditMode ? (
                    <FieldValue
                        value={data.fieldValue}
                        fieldLabelName={data.fieldLabelName as string}
                        renderAs={'string'}
                        decimalLength={data.inputType?.decimalLength ?? null}
                        currency={data.currency ?? null}
                        chips={data?.moreInputInfo?.chips}
                        tooltipContent={data.tooltip?.content ?? null}
                        customClass={{
                            wrapper: data.customClass?.fieldWrapperClass,
                            field: data.customClass?.fieldValueLabel
                        }}
                        testId={data.testId?.field}
                        nextToValueTemplate={data.nextToValueTemplate}
                    />
                ) : (
                    // Field Value Input (editable mode)
                    <div className="flex items-center justify-between w-full gap-2.5">
                        {/* input field */}
                        <InputFieldTemplate
                            data={{
                                fieldType: data.fieldType,
                                inputType: data.inputType ?? { type: undefined },
                                value: data.state,
                                fieldValue: data.fieldValue,
                                fieldLabelName: data.fieldLabelName,
                                onChange: data.actions?.onChange,
                                moreInputInfo: {
                                    select: data.moreInputInfo?.select,
                                    calendar: data.moreInputInfo?.calendar,
                                    chips: data.moreInputInfo?.chips
                                },
                                required: data.required,
                                disabled: data.disabled,
                                placeholder: data.placeholder,
                                invalid: data.invalid,
                                errorMessage: data.errorMessage,
                                getFieldAlone: true,
                                customClass: data.customClass,
                                testId: { label: data.testId?.label, field: data.testId?.field }
                            }}
                        />
                        <div className="flex justify-end">
                            {/* update icon (tick) */}
                            <div className="flex gap-1.5 justify-center items-center">
                                <IconTemplate
                                    data={{
                                        iconType: 'tick',
                                        imgSource: tick,
                                        alterText: 'tick',
                                        action: data?.invalid
                                            ? () => {
                                                  showToastMessage({
                                                      message:
                                                          data.errorMessage || 'Field is invalid.',
                                                      type: ToastType.ERROR
                                                  });
                                              }
                                            : data?.actions?.update
                                    }}
                                />
                                {/* cancel icon (cross) */}
                                <IconTemplate
                                    data={{
                                        iconType: 'cancel',
                                        imgSource: close,
                                        alterText: 'close',
                                        action: data?.actions?.cancel
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
export default ConstructField;
