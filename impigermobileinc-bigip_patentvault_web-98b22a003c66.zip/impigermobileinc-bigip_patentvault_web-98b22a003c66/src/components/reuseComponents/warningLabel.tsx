import { FC } from 'react';

interface WarningLabelModal {
    content: string;
    className?: { wrapperComponent?: string; wrapperContent?: string };
}

const WarningLabel: FC<WarningLabelModal> = ({ content, className }) => {
    return (
        <div className={className?.wrapperComponent ?? ''}>
            <div
                className={`${className?.wrapperContent ?? ''} flex justify-start items-center gap-2 px-2 py-1 w-fit rounded-md bg-warning/50 border-2 border-warning`}>
                <i className="pi pi-exclamation-circle text-warning-700"></i>
                <p className="md:whitespace-nowrap">{content}</p>
            </div>
        </div>
    );
};

export default WarningLabel;
