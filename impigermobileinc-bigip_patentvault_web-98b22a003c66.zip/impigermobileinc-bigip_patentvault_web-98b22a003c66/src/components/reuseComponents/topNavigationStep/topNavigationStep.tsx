import { useLocation, useNavigate } from 'react-router-dom';
import checkListPng from 'assets/images/checklist.png';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { t } from 'i18next';

export interface TopNavigationStepProps {
    backNavigationPath?: string;
    onBackClick?: () => void;
    steps: {
        labelName?: string;
        module?:
            | 'BILL'
            | 'INVOICE'
            | 'PAYMENT'
            | 'COMPANY'
            | 'USER'
            | 'ADJUSTMENT'
            | 'ADVANCE'
            | 'TASK'
            | 'ORDER_QUOTE';
        label: string;
        isCurrent: boolean;
        isPrevious: boolean;
        navigationPath?: string;
        navigationPathName?: string;
        isCopyable?: boolean;
        onClick?: () => void;
    }[];
}

const TopNavigationStep = ({ backNavigationPath, steps, onBackClick }: TopNavigationStepProps) => {
    const navigate = useNavigate();
    const includeThisModule = steps.some((step) => step.module);
    const location = useLocation();
    const { pathname } = location;
    const isCreateView: boolean = pathname?.includes('create');

    const handleBackClick =
        onBackClick ??
        (backNavigationPath ? () => navigate(backNavigationPath) : () => window.history.back());

    return (
        <div className="h-[2.87rem] bg-white border-b-2 border-b-primary px-4 flex items-center">
            {/* Back Button - hidden if need future case */}
            <button
                className="!hidden bg-black/10 hover:bg-black/20 rounded py-1 px-2 text-black/60 hover:text-black mr-4"
                title="Back"
                onClick={handleBackClick}>
                <i className="pi pi-arrow-left" />
            </button>

            {steps.map((step, index) => (
                <button
                    key={step.label}
                    title={
                        step.isPrevious
                            ? 'Redirect to ' + (step?.navigationPathName ?? step.label)
                            : ''
                    }
                    className={`group flex items-center text-lg ${step.isCurrent ? 'text-black !font-semibold cursor-text' : 'text-black/60 hover:text-primary !font-medium'}`}
                    onClick={() => {
                        if (step.onClick) {
                            step.onClick();
                        } else if (step.navigationPath) {
                            navigate(step.navigationPath);
                        }
                    }}>
                    {step.labelName && includeThisModule && !isCreateView && (
                        <p className="text-[0.90rem] leading-none px-1.5 py-1 border rounded flex items-center gap-1 mr-2 mt-[0.1875rem] text-black/70 select-none">
                            {step.module === 'TASK' ? (
                                <img src={checkListPng} alt="checklist" className="w-4 h-3.5" />
                            ) : (
                                <i
                                    className={`pi ${step.module === 'ORDER_QUOTE' ? 'pi-list' : 'pi-wallet'} text-sm !text-[0.80rem]`}></i>
                            )}
                            {step.labelName}
                        </p>
                    )}
                    {step.label}
                    {step.isCopyable && (
                        <button
                            title={t('COMMON.COPY_TO_CLIPBOARD')}
                            className="pi pi-copy text-sm px-1.5 !cursor-pointer text-black/50 hover:text-black/70 !font-normal invisible group-hover:visible bg-transparent border-none outline-none"
                            onClick={(e) => {
                                e.stopPropagation();
                                navigator.clipboard.writeText(step.label);
                                showToastMessage({
                                    message: t('COMMON.COPY_SUCCESS'),
                                    type: ToastType.SUCCESS
                                });
                            }}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    e.currentTarget.click();
                                }
                            }}
                        />
                    )}
                    {index < steps.length - 1 && (
                        <i className="pi pi-angle-right text-lg pt-0.5 px-1 !text-black/60 !no-underline" />
                    )}
                </button>
            ))}
        </div>
    );
};

export default TopNavigationStep;
