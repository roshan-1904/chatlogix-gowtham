import { FC } from 'react';

interface ErrorLabelProps {
    message: string;
    warningIcon?: boolean; // optional
    customStyle?: string; // optional
}

const ErrorLabel: FC<ErrorLabelProps> = (props: ErrorLabelProps) => {
    const { message, warningIcon = false, customStyle } = props;

    return (
        <p className={`custom-error-label ${customStyle ?? ''}`}>
            {warningIcon && <i className="pi pi-exclamation-triangle form-text error"></i>}
            <span className="form-text error !leading-4">{message ?? 'Input field error'}</span>
        </p>
    );
};

export default ErrorLabel;
