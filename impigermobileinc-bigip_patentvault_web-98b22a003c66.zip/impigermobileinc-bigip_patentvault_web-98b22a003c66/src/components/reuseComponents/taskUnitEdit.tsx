import { useEffect, useState } from 'react';
import { hoverDropdownStyle } from 'constants/styles.constant';
import viewOrderQuoteServices from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { Dropdown } from 'primereact/dropdown';
import { showToastMessage } from 'core/utils/utils';
import { t } from 'i18next';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { TASK_UNIT_EDIT } from 'constants/app.constant';

const TaskUnitEdit = (props: {
    parentModule: 'BILLS_TASKS' | 'TASK_DETAILS' | 'INVOICE_TASKS';
    taskUnitId: number;
    unitName: string;
    billID?: number;
    catchUp?: () => void;
    borderedDropdown?: boolean;
    handleParent?: {
        isFromParent: boolean;
        handleUpdate?: (unitId: number) => void;
        dropdownOptions?: { label: string; value: number }[];
    };
    isEditable: boolean;
}) => {
    const [unitOptions, setUnitOptions] = useState<{ label: string; value: number }[]>([]);
    const initialConfirmationState = { visible: false, unitId: 0, header: '', description: <></> };
    const [showConfirmation, setShowConfirmation] = useState(initialConfirmationState);

    const handleUpdate = (unitId: number) => {
        if (props.handleParent?.handleUpdate) {
            props.handleParent.handleUpdate(unitId);
            return;
        }
        viewOrderQuoteServices
            .updateBillsEditDetails(props.billID || 0, unitId)
            .then(() => {
                if (props.catchUp) props.catchUp();
            })
            .catch(() => {
                showToastMessage({
                    message: t(`QUOTE_AND_ORDER.ERROR_MESSAGE.UNIT_UPDATE_FAILED`),
                    type: ToastType.ERROR
                });
            });
    };

    const popupDescription = (unitId: number) => {
        const isUpdateCondition = unitId === TASK_UNIT_EDIT.PER_WORD.id;
        let warningKey = '';
        if (isUpdateCondition && props.parentModule === 'INVOICE_TASKS') {
            warningKey = 'QUOTE_AND_ORDER.WARNING.UNIT_UPDATE_WARNING';
        } else {
            warningKey = 'QUOTE_AND_ORDER.WARNING.UNIT_RESET_WARNING';
        }

        return (
            <div className="flex flex-col gap-2">
                <p>{t(warningKey)}</p>
                <p>{t('COMMON.CONFIRMATION_MESSAGE_FOR_CONTINUE')}</p>
            </div>
        );
    };

    useEffect(() => {
        if (props.handleParent?.dropdownOptions) {
            setUnitOptions(props.handleParent.dropdownOptions);
        }
    }, [props.handleParent?.dropdownOptions]);

    return (
        <div>
            {showConfirmation.visible && (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleUpdate(showConfirmation.unitId);
                        setShowConfirmation({ ...initialConfirmationState, visible: false });
                    }}
                    onCancel={() =>
                        setShowConfirmation({ ...initialConfirmationState, visible: false })
                    }
                    visible={showConfirmation.visible}
                    headerText={showConfirmation.header}
                    description={showConfirmation.description}
                />
            )}
            {props.isEditable ? (
                <Dropdown
                    value={props.taskUnitId}
                    valueTemplate={(option) => option?.label || props.unitName}
                    options={unitOptions}
                    onChange={(e) => {
                        setShowConfirmation({
                            visible: true,
                            unitId: e.value,
                            header: t('COMMON.CONFIRMATION'),
                            description: popupDescription(e.value as number)
                        });
                    }}
                    pt={{
                        ...hoverDropdownStyle,
                        item: {
                            className: hoverDropdownStyle.item.className + ' py-2'
                        },
                        input: {
                            className:
                                hoverDropdownStyle.input.className +
                                `${props.parentModule === 'TASK_DETAILS' ? ' ' : ' font-normal'}`
                        },
                        root: {
                            className: props.borderedDropdown
                                ? hoverDropdownStyle.root.className + ' outline outline-black/30'
                                : hoverDropdownStyle.root.className
                        }
                    }}
                />
            ) : (
                <span
                    className={`${props.parentModule === 'TASK_DETAILS' ? 'font-medium' : 'pl-2'}`}>
                    {props.unitName || '-'}
                </span>
            )}
        </div>
    );
};

export default TaskUnitEdit;
