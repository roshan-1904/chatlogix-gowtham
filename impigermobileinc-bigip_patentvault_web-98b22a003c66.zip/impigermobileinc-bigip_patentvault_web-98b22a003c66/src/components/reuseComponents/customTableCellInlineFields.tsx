import { FC, useState } from 'react';
import editBlueIcon from 'assets/images/editBlue.svg';
import { DOCUMENT_TYPE } from 'constants/app.constant';
import PrimeNumber from 'components/inputs/primeNumber.input';
import PrimeText from 'components/inputs/primeText.input';
import { PrimeDialogBox } from 'components/dialog/primeDialogBox';
import PrimeTextArea from 'components/inputs/primeTextArea.input';
import { Tooltip } from 'primereact/tooltip';
import FieldValue from 'components/inputs/fieldValue.label';

type RowData = { [key: string]: string | boolean | number | null };
interface CustomTableCellInlineFieldsModel {
    moduleName: 'std-details';
    fieldType: 'text' | 'number' | 'toggle';
    fieldLabelName?: string;
    fieldName: string;
    rowData: any;
    quoteStatuses?: { [key: string]: boolean };
    handleCellInlineEditValueChange: (
        documentId: number,
        fieldName: string,
        updatedValue: string | number | boolean
    ) => void;
    getInputFromPopup?: boolean;
}
const CustomTableCellInlineFields: FC<CustomTableCellInlineFieldsModel> = ({
    moduleName,
    fieldType,
    fieldLabelName,
    fieldName,
    rowData,
    quoteStatuses,
    handleCellInlineEditValueChange,
    getInputFromPopup = false
}) => {
    const getCurrentFieldValue = () => (rowData[fieldName] ?? null) as RowData[keyof RowData];
    const documentId = rowData?.documentId as number;
    const [isDialogShow, setIsDialogShow] = useState<boolean>(false);
    const [isEditing, setIsEditing] = useState<boolean>(false);
    const [value, setValue] = useState<string | number | boolean | null>(getCurrentFieldValue);
    const tooltipClassForNotes =
        fieldName === 'notes' ? `std-document-notes-label-${documentId}` : '';

    // handlers
    const onEditSave = () => {
        setIsEditing(false);
        value && handleCellInlineEditValueChange(documentId, fieldName, value);
        setValue(null);
    };
    const onEditCancel = () => {
        setIsEditing(false);
        setValue(getCurrentFieldValue);
    };

    // templates
    const renderInlineField = () => {
        try {
            return (
                <>
                    {fieldType === 'number' && (
                        <PrimeNumber
                            value={value ?? rowData[fieldName] ?? null}
                            testId={'primeNumber'}
                            placeholder={rowData.header}
                            disabled={false}
                            invalid={false}
                            isDecimal={false}
                            showInputLabelName={false}
                            customClass={{}}
                            onChange={(updatedValue: number | null) => {
                                setValue(updatedValue);
                            }}
                        />
                    )}
                    {fieldType === 'text' && (
                        <PrimeText
                            value={value ?? rowData[fieldName] ?? null}
                            testId={value ?? rowData[fieldName]}
                            placeholder={rowData.header}
                            disabled={false}
                            invalid={false}
                            showInputLabelName={false}
                            customClass={{}}
                            onChange={(updatedValue: string | null) => {
                                setValue(updatedValue);
                            }}
                        />
                    )}
                </>
            );
        } catch (error) {
            console.error('Error in STD listing page table renderInlineField(): ', error);
        }
    };

    // helpers
    const isFieldEditable = () => {
        let isEditable = true;

        // STD
        if (moduleName === 'std-details') {
            const isCompletedORInvoiced = quoteStatuses?.isCompleted || quoteStatuses?.isInvoiced;
            if (
                isCompletedORInvoiced ||
                (fieldName === 'wordCount' && rowData.documentType === DOCUMENT_TYPE.REFERENCE.id)
            ) {
                isEditable = false;
            }
        }

        return isEditable;
    };
    const handleEditClick = () => {
        if (getInputFromPopup) {
            setIsDialogShow(true);
        } else {
            setIsEditing(true);
        }
    };
    const bodyContent = () => {
        return (
            <PrimeTextArea
                fieldLabelName={fieldLabelName}
                value={value ?? rowData[fieldName] ?? null}
                testId={'std-document-notes-dialog'}
                placeholder={rowData.header}
                disabled={false}
                invalid={false}
                showInputLabelName={true}
                customClass={{}}
                onChange={(updatedValue: string | null) => {
                    setValue(updatedValue);
                }}
            />
        );
    };

    return (
        <>
            <Tooltip
                target={tooltipClassForNotes ? `.${tooltipClassForNotes}` : ''}
                mouseTrack={false}
                position="top"
                content={rowData[fieldName]}
                pt={{
                    root: { className: 'shadow-none ' },
                    text: { className: 'text-xs' }
                }}
            />
            <PrimeDialogBox
                isShowDialog={isDialogShow}
                header={'Update Notes'}
                body={<>{bodyContent()}</>}
                buttonName={{ primary: 'update' }}
                actions={{
                    onClose() {
                        setIsDialogShow(false);
                        onEditCancel();
                    },
                    onDialogClear: () => setValue(''),
                    onDialogSubmit() {
                        setIsDialogShow(false);
                        onEditSave();
                    }
                }}
            />
            {!isEditing ? (
                <div
                    className={`${tooltipClassForNotes} group flex items-center justify-start gap-2`}>
                    <FieldValue
                        value={rowData[fieldName]}
                        renderAs={'string'}
                        customClass={{
                            wrapper: 'max-w-44',
                            field: '!font-normal'
                        }}
                    />
                    {isFieldEditable() && (
                        <img
                            className="hidden group-hover:flex h-4 w-4 cursor-pointer mx-2"
                            src={editBlueIcon}
                            onClick={handleEditClick}
                            alt="edit-blue-icon"
                        />
                    )}
                </div>
            ) : (
                <div className="flex items-center justify-center gap-2 w-48">
                    {renderInlineField()}
                    <span
                        role="button"
                        className="pi pi-times text-error cursor-pointer mx-1"
                        onClick={() => onEditCancel()}
                        tabIndex={0}
                    />
                    <span
                        role="button"
                        tabIndex={0}
                        className="pi pi-check text-primary cursor-pointer mx-1"
                        onClick={() => onEditSave()}
                    />
                </div>
            )}
        </>
    );
};

export default CustomTableCellInlineFields;
