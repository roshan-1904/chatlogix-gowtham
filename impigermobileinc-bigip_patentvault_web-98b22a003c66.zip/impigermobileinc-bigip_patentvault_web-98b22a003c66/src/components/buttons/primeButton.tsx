import { FC } from 'react';
import { Button } from 'primereact/button';

interface PrimeButtonModal {
    testid?: string;
    label: string;
    type?: 'primary' | 'neutral' | 'secondary';
    className?: string;
    size?: 'medium' | 'large'; // popup - medium / other places - large
    icon?: string;
    onClick: () => void;
    loading?: boolean;
    disabled?: boolean;
    rounded?: boolean;
    raised?: boolean;
    text?: boolean;
    outlined?: boolean;
    link?: boolean;
    iconPos?: 'top' | 'bottom' | 'left' | 'right';
    loadingIcon?: string;
}

const PrimeButton: FC<PrimeButtonModal> = ({
    testid = '',
    label = 'Text',
    type = 'primary',
    className = '',
    size = 'medium',
    icon = '',
    onClick,
    loading = false,
    disabled = false,
    rounded = false,
    raised = false,
    text = false,
    outlined = false,
    link = false,
    iconPos = 'left',
    loadingIcon = ''
}) => {
    const getButtonStyles = (key: string) => {
        // neutral / outline yet to configure. primary only configured for now.
        const getRootClass = () => {
            const rootClasses = {
                primary: `${outlined ? 'bg-transparent hover:bg-primary-50' : 'bg-primary hover:bg-primary-200'}`,
                neutral: `${outlined ? 'bg-transparent hover:bg-neutral-50' : 'bg-neutral-100/50 border-neutral-100 hover:bg-neutral-100 hover:border-neutral'}`,
                secondary: 'bg-primary hover:bg-primary-200'
            };
            return rootClasses[type] || '';
        };
        const getLabelClass = () => {
            const labelClasses = {
                primary: `${outlined ? 'text-primary-200' : 'text-white'}`,
                neutral: 'text-neutral-200',
                secondary: 'text-white'
            };
            return labelClasses[type] || '';
        };
        const getSizeClass = () => {
            const sizeClasses = {
                large: 'h-10 min-h-10',
                medium: 'h-9 min-h-9'
            };
            return sizeClasses[size] || '';
        };

        switch (key) {
            case 'root':
                return `${getRootClass()} ${getSizeClass()}`;
            case 'label':
                return getLabelClass();
            case 'icon':
                return icon ? '' : 'hidden';
            default:
                return '';
        }
    };

    // button PT styles
    const buttonStyles = {
        root: { className: `px-2.5 focus:shadow-none cursor-pointer ${getButtonStyles('root')}` },
        label: { className: `!font-medium ${getButtonStyles('label')}` },
        icon: { className: `hidden ${getButtonStyles('icon')}` }
    };

    return (
        <Button
            data-testid={testid}
            label={label}
            className={className}
            icon={icon}
            onClick={onClick}
            loading={loading}
            disabled={disabled}
            iconPos={iconPos}
            loadingIcon={loadingIcon}
            rounded={rounded}
            raised={raised}
            text={text}
            outlined={outlined}
            link={link}
            pt={{ ...buttonStyles }}
        />
    );
};

export default PrimeButton;
