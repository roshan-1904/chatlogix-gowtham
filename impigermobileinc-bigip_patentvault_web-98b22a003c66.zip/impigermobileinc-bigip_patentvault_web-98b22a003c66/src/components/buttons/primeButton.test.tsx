import { render, screen, fireEvent } from '@testing-library/react';
import PrimeButton from './primeButton';

describe('PrimeButton Component', () => {
    it('should render with the provided className', () => {
        const className = 'custom-class';
        render(<PrimeButton label="Test Button" className={className} onClick={() => {}} />);

        const buttonElement = screen.getByText('Test Button');
        expect(buttonElement).toHaveClass(className);
    });

    it('should render without a className if none is provided', () => {
        render(<PrimeButton label="Test Button" onClick={() => {}} />);

        const buttonElement = screen.getByText('Test Button');
        expect(buttonElement).not.toHaveClass();
    });

    it('should call onClick when clicked', () => {
        const handleClick = jest.fn();
        render(<PrimeButton label="Test Button" className="custom-class" onClick={handleClick} />);

        const buttonElement = screen.getByText('Test Button');
        fireEvent.click(buttonElement);
        expect(handleClick).toHaveBeenCalledTimes(1);
    });
});
