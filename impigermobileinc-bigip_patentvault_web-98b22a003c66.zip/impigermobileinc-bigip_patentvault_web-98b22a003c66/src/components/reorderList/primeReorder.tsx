import { OrderList } from 'primereact/orderlist';

type PrimeOrderModel<T> = {
    reorderList: T[];
    onChange: (value: T[]) => void;
    itemTemplate: (item: T) => JSX.Element;
};

const PrimeReorder = <T,>({ reorderList, onChange, itemTemplate }: PrimeOrderModel<T>) => {
    const primeOrderPtStyle = {
        list: { className: '!p-0 !border-none !bg-transparent' },
        controls: { className: 'hidden' },
        header: { className: 'hidden' },
        item: {
            className:
                'border-2 border-solid border-neutral-50 bg-white rounded-lg hover:bg-primary-100 p-0'
        },
        droppoint: { className: 'h-3 data-[p-orderlist-droppoint-highlight=true]:bg-primary-100' }
    };

    return (
        <div className="card xl:flex xl:justify-content-center">
            <OrderList
                dataKey="taskId"
                value={reorderList}
                onChange={(e: { value: T[] }) => onChange(e.value)}
                itemTemplate={itemTemplate}
                dragdrop
                pt={primeOrderPtStyle}
            />
        </div>
    );
};

export default PrimeReorder;
