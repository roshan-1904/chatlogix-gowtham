import { render, fireEvent } from '@testing-library/react';
import ConfirmationPopup, { ConfirmationPopupProps } from './confirmationPopup';

describe('ConfirmationPopup Component', () => {
    const props: ConfirmationPopupProps = {
        visible: false,
        onConfirm: jest.fn(),
        onCancel: jest.fn(),
        subHeaderText: 'Sub Header',
        description: 'Description',
        headerText: 'Header',
        acceptLabel: 'Yes',
        rejectLabel: 'No',
        alertImage: 'confirmation-popup-icon.svg'
    };

    test('renders ConfirmationPopup when visible is true', () => {
        const { getByTestId } = render(<ConfirmationPopup {...props} visible={true} />);
        expect(getByTestId('ConfirmationPopup')).toBeInTheDocument();
    });

    test('does not render ConfirmationPopup when visible is false', () => {
        const { queryByTestId } = render(<ConfirmationPopup {...props} visible={false} />);
        expect(queryByTestId('ConfirmationPopup')).toBeNull();
    });

    test('calls onConfirm when Accept button is clicked', () => {
        const { getByText } = render(<ConfirmationPopup {...props} visible={true} />);
        fireEvent.click(getByText('Yes'));
        expect(props.onConfirm).toHaveBeenCalledTimes(1);
    });

    test('calls onCancel when Reject button is clicked', () => {
        const { getByText } = render(<ConfirmationPopup {...props} visible={true} />);
        fireEvent.click(getByText('No'));
        expect(props.onCancel).toHaveBeenCalledTimes(1);
    });
});
