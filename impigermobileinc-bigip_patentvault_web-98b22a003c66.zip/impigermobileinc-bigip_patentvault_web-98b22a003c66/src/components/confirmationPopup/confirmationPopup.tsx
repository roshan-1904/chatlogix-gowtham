import { FC, SyntheticEvent, useEffect } from 'react';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import confirmationPopupAlertIcon from 'assets/images/confirmation-popup-icon.svg';
import { ContentPropsMessage } from 'primereact/dialog';

export interface ConfirmationPopupProps {
    onConfirm?: () => void;
    onCancel?: () => void;
    visible: boolean;
    popupID?: string;
    subHeaderText?: string;
    description?: string | JSX.Element;
    headerText?: string | JSX.Element;
    acceptLabel?: string;
    rejectLabel?: string;
    alertImage?: string;
    className?: string;
    image?: string;
    acceptClassName?: string;
    rejectClassName?: string;
    isShowAcceptButton?: boolean;
    isShowRejectButton?: boolean;
    closeIcon?: {
        isTopCloseIcon: boolean;
        isOnClickClose: () => void;
    };
    customWidth?: string;
    acceptButtonDisabled?: boolean;
}

const ConfirmationPopup: FC<ConfirmationPopupProps> = ({
    onConfirm = () => {},
    onCancel = () => {},
    visible,
    alertImage = confirmationPopupAlertIcon,
    description = 'description',
    headerText = 'Header',
    acceptLabel = 'Yes',
    rejectLabel = 'No',
    popupID = 'ConfirmationPopup',
    subHeaderText,
    className,
    image,
    rejectClassName,
    acceptClassName,
    isShowAcceptButton = true,
    isShowRejectButton = true,
    closeIcon: { isTopCloseIcon = false, isOnClickClose = () => {} } = {},
    customWidth = '',
    acceptButtonDisabled = false
}) => {
    useEffect(() => {
        if (visible) {
            showTemplate();
        }
    }, [visible]);

    const showTemplate = () => {
        confirmDialog({
            message: (
                <div className="flex flex-col  gap-2 items-center justify-center p-6">
                    <div className="h-9">
                        <img className="h-full " src={image ?? alertImage} alt="Confirmation" />
                    </div>
                    <div>
                        <h4 className="font-medium text-secondary text-center">{headerText}</h4>
                        {subHeaderText && (
                            <h6 className="font-medium text-primary text-center">
                                {subHeaderText}
                            </h6>
                        )}
                    </div>
                </div>
            )
        });
    };

    const renderContent = (hide: (e: SyntheticEvent) => void, message: ContentPropsMessage) => {
        return (
            <div className={className} data-testid="confirmation-popup">
                {isTopCloseIcon && (
                    <button
                        key={`close-button-${popupID}`}
                        title="Close"
                        onClick={(event) => {
                            hide(event);
                            isOnClickClose();
                        }}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                isOnClickClose();
                            }
                        }}
                        className="absolute top-2.5 right-2.5 rounded-full hover:bg-black/20 w-7 h-7">
                        <i className="pi pi-times text-black text-[0.875rem]" />
                    </button>
                )}
                {message.message}
                <div className="flex flex-col items-center justify-center gap-5 p-6 border-t-2 border-t-neutral-100 bg-neutral rounded-b-lg">
                    {description && description !== '' && (
                        <p className="descriptionConfirmationPopup text-base font-normal text-center">
                            {typeof description === 'string' ? (
                                // innerHtml -> while element come as string.
                                <span dangerouslySetInnerHTML={{ __html: description }} />
                            ) : (
                                // in some case, we sent the element as well.
                                description
                            )}
                        </p>
                    )}
                    <div className="flex items-center justify-center gap-4">
                        <button
                            onClick={(event) => {
                                hide(event);
                                onCancel();
                            }}
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    hide(event);
                                    onCancel();
                                }
                            }}
                            className={`noButton btn button-neutral min-h-10 h-10 min-w-16  font-medium  rounded-lg px-3 focus:outline-none ${acceptClassName} ${isShowRejectButton ? 'block' : 'hidden'}`}>
                            {rejectLabel}
                        </button>
                        <button
                            disabled={acceptButtonDisabled}
                            onClick={(event) => {
                                hide(event);
                                onConfirm();
                            }}
                            data-testid="accept-label"
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    hide(event);
                                    onConfirm();
                                }
                            }}
                            className={`yesButton btn button-primary min-h-10 h-10 min-w-16 font-medium rounded-lg px-3 bg-neutral-800 focus:outline-none ${rejectClassName} ${isShowAcceptButton ? 'block' : 'hidden'}`}>
                            {acceptLabel}
                        </button>
                    </div>
                </div>
            </div>
        );
    };
    return (
        <ConfirmDialog
            closeOnEscape={false}
            data-testid={'ConfirmationPopup'}
            key={popupID}
            content={({ hide, message }) => renderContent(hide, message)}
            pt={{
                root: {
                    className: 'w-10/12 md:w-5/12 lg:w-1/4 bg-white ' + customWidth
                },
                content: {
                    className: 'flex justify-center p-4 rounded-t-lg'
                },
                message: {
                    className: 'ml-0'
                },
                header: {
                    className: 'hidden'
                },
                closeButton: {
                    className: 'hidden'
                }
            }}
        />
    );
};

export default ConfirmationPopup;
