import { render, screen } from '@testing-library/react';
import ToastAlert from './toastAlert';
import NotificationStore from 'core/store/notificationStore/notificationStore';

export const ToastType = {
    SUCCESS: 'success',
    ERROR: 'error',
    WARNING: 'warning'
};

// Mock NotificationStore
jest.mock('core/store/notificationStore/notificationStore', () => ({
    __esModule: true,
    default: {
        init: jest.fn(),
        subscribe: jest.fn(),
        showAlert: jest.fn(),
        initialState: { data: null, hasError: true }
    }
}));

describe('ToastAlert', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders Toast component', () => {
        render(<ToastAlert />);
        const toastElement = screen.getByTestId('Toast');
        expect(toastElement).toBeInTheDocument();
    });

    it('subscribes to NotificationStore on mount', () => {
        render(<ToastAlert />);
        expect(NotificationStore.subscribe).toHaveBeenCalledTimes(1);
    });

    it('displays success toast with correct icon and message', () => {
        render(<ToastAlert />);
        // const mockNotification: notificationModel = {
        //     message: 'Success message',
        //     type: ToastType.SUCCESS
        // };

        // // Trigger a notification
        // const mockSubscribe = NotificationStore.subscribe as jest.Mock;
        // mockSubscribe.mock.calls[0][0](mockNotification);

        // Check if toast with success icon and message is displayed
        const toastElement = screen.getByTestId('Toast');
        expect(toastElement).toBeInTheDocument();
    });

    it('displays error toast with correct icon and message', () => {
        render(<ToastAlert />);
        // const mockNotification: notificationModel = {
        //     message: 'Success message',
        //     type: ToastType.SUCCESS
        // };

        // Trigger a notification
        // const mockSubscribe = NotificationStore.subscribe as jest.Mock;
        // mockSubscribe.mock.calls[0][0](mockNotification);

        // Check if toast with success icon and message is displayed
        const toastElement = screen.getByTestId('Toast');
        expect(toastElement).toBeInTheDocument();
    });
});
