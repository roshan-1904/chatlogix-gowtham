import { FC } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
import { v4 as uuidv4 } from 'uuid';

import { DropdownSelection } from 'constants/app.constant';
import { multiSelectFilterStyles } from 'shared/dataTable/constant/dataTable.styles';
import { dropDownStyle } from 'constants/styles.constant';

interface DropdownInlineProps {
    selectedValue?: number | number[];
    options: any[];
    optionValue?: string;
    optionLabel?: string;
    onChange: (value: number | number[]) => void;
    selectionType?: DropdownSelection;
    disabled?: boolean;
    showClear?: boolean;
    isError?: boolean;
}

const DropdownInline: FC<DropdownInlineProps> = ({
    selectedValue,
    options,
    optionValue = 'id',
    optionLabel = 'name',
    onChange,
    selectionType,
    disabled = false,
    showClear = true,
    isError = false
}) => {
    let renderDropdown = null;

    // handlers
    const handleSingleSelectChange = (value: number) => {
        onChange(value);
    };
    const handleMultiSelectChange = (value: number[]) => {
        onChange(value ?? []);
    };

    if (selectionType === 'singleSelect') {
        renderDropdown = (
            <Dropdown
                key={uuidv4()}
                data-testid={'DropdownInline'}
                value={selectedValue}
                onChange={(e: any) => handleSingleSelectChange(e.value as number)}
                options={options}
                optionLabel={optionLabel}
                optionValue={optionValue}
                filter={true}
                placeholder="Select"
                disabled={disabled}
                showClear={showClear}
                className={`${isError ? '!border-red-500' : ''}`}
                pt={{
                    ...dropDownStyle,
                    root: {
                        ...dropDownStyle.root,
                        className: `${dropDownStyle.root.className} md:w-80 h-8`
                    },
                    clearIcon: {
                        ...dropDownStyle.clearIcon,
                        className: 'h-4 w-4'
                    }
                }}
            />
        );
    } else if (selectionType === 'multiSelect') {
        renderDropdown = (
            <MultiSelect
                // key={uuidv4()} // commented out to avoid re-rendering
                data-testid={'MultiSelectInline'}
                value={selectedValue}
                onChange={(e: any) => handleMultiSelectChange(e.value as number[])}
                options={options}
                filter
                optionLabel={optionLabel}
                optionValue={optionValue}
                placeholder="Select"
                showClear={showClear}
                disabled={disabled}
                className={`${isError ? '!border-red-500' : ''} w-full `}
                pt={{
                    ...multiSelectFilterStyles,
                    clearIcon: {
                        ...dropDownStyle.clearIcon,
                        className: 'h-4 w-4'
                    }
                }}
            />
        );
    }

    return (
        <div className="flex items-center gap-3" data-testid="DropdownInline">
            {renderDropdown}
        </div>
    );
};

export default DropdownInline;
