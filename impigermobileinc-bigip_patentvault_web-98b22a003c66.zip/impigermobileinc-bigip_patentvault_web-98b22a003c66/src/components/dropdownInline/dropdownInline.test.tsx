import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import DropdownInline from './dropdownInline';

// Mock options
const mockOptions = [
    { id: '1', name: 'Option 1' },
    { id: '2', name: 'Option 2' }
];

describe('DropdownInline component', () => {
    test('should render single select dropdown and handle change event', () => {
        const mockOnChange = jest.fn();
        render(
            <DropdownInline
                options={mockOptions}
                // selectionType={DropdownSelection.SINGLE_SELECT}
                onChange={mockOnChange}
                // value="1"
            />
        );

        waitFor(() => {
            const dropdown = screen.getByTestId('DropdownInline');
            expect(dropdown).toBeInTheDocument();
            fireEvent.change(dropdown, { target: { value: '2' } });
            expect(mockOnChange).toHaveBeenCalledWith('2');
        });

        // Simulate a change in dropdown selection

        // Expect that the onChange handler is called with correct value
    });

    test('should render multi select dropdown and handle change event', () => {
        const mockOnChange = jest.fn();
        render(
            <DropdownInline
                options={mockOptions}
                // selectionType={DropdownSelection.MULTI_SELECT}
                onChange={mockOnChange}
            />
        );

        waitFor(() => {
            const multiSelect = screen.getByTestId('MultiSelectInline');
            expect(multiSelect).toBeInTheDocument();

            // Simulate a change in multi-select values
            fireEvent.change(multiSelect, { target: { value: ['1', '2'] } });

            // Expect that the onChange handler is called with correct values
            expect(mockOnChange).toHaveBeenCalledWith(['1', '2']);
        });
    });

    test('should show the correct placeholder for single select', () => {
        render(<DropdownInline options={mockOptions} onChange={jest.fn()} />);
        waitFor(() => {
            const dropdown = screen.getByTestId('DropdownInline');
            expect(dropdown).toHaveAttribute('placeholder', 'Select');
        });
    });

    test('should show the correct placeholder for multi select', () => {
        render(<DropdownInline options={mockOptions} onChange={jest.fn()} />);
        waitFor(() => {
            const multiSelect = screen.getByTestId('MultiSelectInline');
            expect(multiSelect).toHaveAttribute('placeholder', 'Select');
        });
    });

    test('should render the clear button for single select', () => {
        render(
            <DropdownInline
                options={mockOptions}
                onChange={jest.fn()}
                // value="1"
            />
        );

        waitFor(() => {
            const dropdown = screen.getByTestId('DropdownInline');
            expect(dropdown).toBeInTheDocument();
            expect(screen.getByText('Clear')).toBeInTheDocument();
        });
    });

    test('should render the clear button for multi select', () => {
        render(<DropdownInline options={mockOptions} onChange={jest.fn()} />);

        waitFor(() => {
            const multiSelect = screen.getByTestId('MultiSelectInline');
            expect(multiSelect).toBeInTheDocument();
            expect(screen.getByText('Clear')).toBeInTheDocument();
        });
    });
});
