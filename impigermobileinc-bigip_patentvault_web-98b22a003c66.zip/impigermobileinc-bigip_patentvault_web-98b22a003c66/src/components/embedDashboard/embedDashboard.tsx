import { useEffect, forwardRef, Ref } from 'react';
import { embedDashboard } from '@superset-ui/embedded-sdk';
interface EmbedDashboardProps {
    dashBoardId: string;
    guestToken: string;
    containerName: string;
}

const superSetURL = process.env.REACT_APP_SUPER_SET_URL;

const EmbedDashboard = (
    { dashBoardId, guestToken, containerName }: EmbedDashboardProps,
    ref: Ref<HTMLDivElement>
) => {
    useEffect(() => {
        if (guestToken && dashBoardId) {
            const mountPoint = document.getElementById(containerName);

            if (!mountPoint) {
                console.error(`Container with ID '${containerName}' not found.`);
                return;
            }

            embedDashboard({
                id: dashBoardId,
                supersetDomain: superSetURL as string,
                mountPoint,
                fetchGuestToken: () => Promise.resolve(guestToken),
                dashboardUiConfig: {
                    hideTitle: true,
                    filters: {
                        expanded: false
                    }
                }
            });

            if (mountPoint.children[0]) {
                mountPoint.children[0].setAttribute('width', '100%');
                mountPoint.children[0].setAttribute('style', 'height:calc(100vh - 80px)');
            }
        }
    }, [guestToken, dashBoardId, containerName]);

    return <div ref={ref} id={containerName} style={{ height: 'calc(100vh - 80px)' }}></div>;
};

export default forwardRef(EmbedDashboard);
