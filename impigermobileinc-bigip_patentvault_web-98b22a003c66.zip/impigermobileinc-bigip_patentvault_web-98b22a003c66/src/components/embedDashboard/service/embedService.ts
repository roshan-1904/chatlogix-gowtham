import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';

// Define the base URL from environment variable
const quoteBaseURL = process.env.REACT_APP_API_BASE_URL;
const _httpService = new HttpService();

/**
 * getToken and DashbordId
 
 */
const fetchGuestTokenAndId = async <T>(): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.DASHBOARD.GETTOKEN}`;
    try {
        const response = await _httpService.get<T>(apiUrl, { data: { hideLoader: true } });
        return response;
    } catch (error) {
        console.error('Error fetching to get Dashboard Data:', error);
        throw error;
    }
};

const embedService = {
    fetchGuestTokenAndId
};

export default embedService;
