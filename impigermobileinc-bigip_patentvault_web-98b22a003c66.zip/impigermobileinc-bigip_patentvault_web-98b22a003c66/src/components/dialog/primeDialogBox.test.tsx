import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { PrimeDialogBox, PrimeDialogModal } from './primeDialogBox';

describe('PrimeDialogBox Component', () => {
    const mockOnHide = jest.fn();

    const defaultParams: PrimeDialogModal = {
        isShowDialog: true,
        header: <div>Test Header</div>,
        body: <div>Test Body</div>,
        actions: {
            onClose: mockOnHide,
            onDialogClear: jest.fn(),
            onDialogSubmit: jest.fn()
        }
    };

    it('should render the dialog with the provided header, body, and footer', () => {
        render(
            <PrimeDialogBox
                isShowDialog={defaultParams.isShowDialog}
                header={defaultParams.header}
                body={defaultParams.body}
                actions={defaultParams.actions}
            />
        );

        expect(screen.getByText('Test Header')).toBeInTheDocument();
        expect(screen.getByText('Test Body')).toBeInTheDocument();
        expect(screen.getByText('Test Footer')).toBeInTheDocument();
    });

    it('should call onHide when the dialog is closed', () => {
        render(
            <PrimeDialogBox
                isShowDialog={defaultParams.isShowDialog}
                header={defaultParams.header}
                body={defaultParams.body}
                actions={defaultParams.actions}
            />
        );
        const closeButton = screen.getByRole('button', { name: /close/i });

        userEvent.click(closeButton);

        expect(mockOnHide).toHaveBeenCalledTimes(1);
    });

    it('should not render the dialog when isShowDialog is false', () => {
        render(
            <PrimeDialogBox
                isShowDialog={false}
                header={defaultParams.header}
                body={defaultParams.body}
                actions={defaultParams.actions}
            />
        );

        expect(screen.queryByText('Test Header')).not.toBeInTheDocument();
        expect(screen.queryByText('Test Body')).not.toBeInTheDocument();
        expect(screen.queryByText('Test Footer')).not.toBeInTheDocument();
    });
});
