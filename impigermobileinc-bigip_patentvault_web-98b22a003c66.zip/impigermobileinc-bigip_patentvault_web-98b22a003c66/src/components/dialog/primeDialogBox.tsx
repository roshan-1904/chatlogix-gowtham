import { FC, useEffect, useState } from 'react';
import { Dialog } from 'primereact/dialog';
import PrimeButton from 'components/buttons/primeButton';

export interface PrimeDialogModal {
    isShowDialog: boolean;
    header: string | JSX.Element;
    body: JSX.Element;
    buttonName?: { primary?: string; secondary?: string };
    actions: {
        onClose: () => void;
        onDialogClear?: () => void;
        onDialogSubmit?: () => void;
    };
    visibility?: { primary?: boolean; secondary?: boolean };
    customClass?: { dialogWidth?: string };
}

export const PrimeDialogBox: FC<PrimeDialogModal> = ({
    isShowDialog = false,
    header = 'Header Name',
    body = <></>,
    buttonName,
    actions,
    // secondary button act as clear/close
    visibility = { primary: true, secondary: true },
    customClass = { dialogWidth: '45vw' }
}) => {
    const [visible, setVisible] = useState(isShowDialog);

    // components
    const getHeader = () => {
        return typeof header === 'string' ? (
            <div className="flex gap-5 items-center justify-between">
                <p className="text-primary-200 font-semibold text-lg">{header}</p>
            </div>
        ) : (
            <>{header}</>
        );
    };
    const getFooter = () => {
        return (
            <>
                {visibility.secondary && (
                    <PrimeButton
                        label={buttonName?.secondary ?? 'Clear'}
                        type="neutral"
                        onClick={() => actions?.onDialogClear?.()}
                    />
                )}
                {visibility.primary && (
                    <PrimeButton
                        label={buttonName?.primary ?? 'Add'}
                        type="primary"
                        onClick={() => actions?.onDialogSubmit?.()}
                    />
                )}
            </>
        );
    };

    // side effects
    useEffect(() => {
        setVisible(isShowDialog);
    }, [isShowDialog]);

    return (
        <div className="card flex justify-content-center">
            <Dialog
                header={getHeader()}
                visible={visible}
                style={{ width: customClass?.dialogWidth }}
                onHide={() => {
                    if (!visible) return;
                    setVisible(false);
                    actions.onClose();
                }}
                breakpoints={{ '960px': '75vw', '641px': '100vw' }}
                footer={getFooter()}
                draggable={false}
                pt={{
                    headerTitle: { className: '!font-medium' },
                    header: { className: 'px-6 py-3 font-medium' },
                    content: { className: 'px-6 py-3 bg-neutral-bg max-h-[31rem]' },
                    footer: { className: 'px-6 py-3' }
                    // mask: { className: '!fixed !z-[3333]' }
                }}>
                {body}
            </Dialog>
        </div>
    );
};
