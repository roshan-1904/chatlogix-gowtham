import { FeedbackFormUpdate } from '../service/feedbackFormService';
import HttpService from 'core/interceptor/api.handler';
import { FeedbackFormPayload } from '../types/feedbackForm.types';
import { END_POINT } from 'constants/endPoint';

jest.mock('core/interceptor/api.handler');

const mockedHttpService = HttpService as jest.MockedClass<typeof HttpService>;

describe('FeedbackFormUpdate', () => {
    const payload: FeedbackFormPayload = {
        userId: 1,
        firstName: 'John',
        lastName: 'Doe',
        emailId: 'johndoe@mailinator.com',
        rating: 3,
        pageName: 'Test Page',
        notes: 'Test Notes'
    };

    const baseURL = process.env.REACT_APP_API_BASE_URL ?? '';
    const apiUrl = `${baseURL}${END_POINT.USER_FEEDBACK}`;

    beforeEach(() => {
        mockedHttpService.mockClear();
    });

    it('should successfully update user feedback', async () => {
        const mockResponse = { success: true };
        mockedHttpService.prototype.post.mockResolvedValue(mockResponse);

        const result = await FeedbackFormUpdate<typeof mockResponse>(payload);

        expect(mockedHttpService.prototype.post).toHaveBeenCalledWith(apiUrl, payload);
        expect(result).toEqual(mockResponse);
    });

    it('should handle errors when updating user feedback', async () => {
        const mockError = new Error('Network Error');
        mockedHttpService.prototype.post.mockRejectedValue(mockError);

        await expect(FeedbackFormUpdate(payload)).rejects.toThrow(mockError);
        expect(mockedHttpService.prototype.post).toHaveBeenCalledWith(apiUrl, payload);
    });
});
