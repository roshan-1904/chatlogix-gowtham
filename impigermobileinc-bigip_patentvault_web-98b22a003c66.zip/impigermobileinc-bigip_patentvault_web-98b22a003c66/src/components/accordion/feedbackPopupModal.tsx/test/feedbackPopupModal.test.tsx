import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import FeedbackPopupModal from '../feedbackPopupModal';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import AuthStore from 'core/store/authStore/authStore';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { FeedbackFormUpdate } from '../service/feedbackFormService';

// Mock the dependencies
jest.mock('core/store/formIoStore/formIoStore');
jest.mock('core/store/authStore/authStore');
jest.mock('../service/feedbackFormService');
jest.mock('core/utils/utils', () => ({
    ...jest.requireActual('core/utils/utils'),
    deepEqualValuesOnly: jest.fn(),
    focusOnFirstError: jest.fn(),
    isContactUser: jest.fn(),
    showToastMessage: jest.fn()
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({
        pathname: '/collaborate-partner'
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

describe('FeedbackPopupModal', () => {
    const mockOnHide = jest.fn();
    const mockUpdateFormData = jest.fn();
    const mockClearFormData = jest.fn();
    const mockFeedbackFormUpdate = FeedbackFormUpdate as jest.Mock;
    const mockUserInfo = {
        signinName: 'test@example.com',
        userId: 'user123',
        firstName: 'John',
        lastName: 'Doe'
    };

    beforeEach(() => {
        jest.clearAllMocks();
        (formStatusStore.getFormData as jest.Mock).mockReturnValue({ data: {} });
        formStatusStore.subscribe = jest.fn();
        formStatusStore.updateFormData = mockUpdateFormData;
        formStatusStore.clearFormData = mockClearFormData;
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({ userInfo: mockUserInfo });
    });

    it('renders the modal with header and form', async () => {
        render(
            <FeedbackPopupModal
                visible={true}
                pages={[]}
                header="Test Header"
                onHide={mockOnHide}
            />
        );
        await waitFor(() => {
            expect(screen.getByText('Test Header')).toBeInTheDocument();
            expect(screen.getByText('How satisfied are you with IPVault?')).toBeInTheDocument();

            const ratingStars = screen.getAllByTestId('rating-star');
            ratingStars.forEach((star) => {
                expect(star).toBeInTheDocument();
            });
        });
    });

    it('hides the modal when onHide is called', () => {
        render(<FeedbackPopupModal visible={true} pages={[]} onHide={mockOnHide} />);
        fireEvent.click(screen.getByTestId('feedback-cancel-button'));
        expect(mockOnHide).toHaveBeenCalledTimes(1);
        expect(mockClearFormData).toHaveBeenCalledTimes(1);
    });

    it('updates form data on form change', () => {
        render(<FeedbackPopupModal visible={true} pages={[]} />);

        // Assuming you've already rendered the component that contains the textarea
        fireEvent.change(screen.getByPlaceholderText("We'd love to hear your feedback"), {
            target: { value: 'feedback content' }
        });

        expect(screen.getByPlaceholderText("We'd love to hear your feedback")).toHaveValue(
            'feedback content'
        );
    });

    it('disables submit button when form is incomplete', () => {
        render(<FeedbackPopupModal visible={true} pages={[]} />);

        const submitButton = screen.getByTestId('feedback-submit-button');
        expect(submitButton).toBeDisabled();
    });

    it('enables submit button when form is complete', () => {
        (formStatusStore.getFormData as jest.Mock).mockReturnValue({
            data: { feedback: 'Test feedback' }
        });

        render(<FeedbackPopupModal visible={true} pages={[]} />);

        const ratingStars = screen.getAllByTestId('rating-star');
        fireEvent.click(ratingStars[0]);

        const submitButton = screen.getByTestId('feedback-submit-button');
        expect(submitButton).not.toBeDisabled();
    });

    it('submits the feedback form successfully with complete data', async () => {
        mockFeedbackFormUpdate.mockResolvedValue(true);
        const formStoreMock = formStatusStore.getFormData as jest.Mock;
        const hideMock = jest.fn();
        // Mock the form data to ensure it's complete
        formStoreMock.mockReturnValue({
            data: {
                feedback: 'Test feedback',
                selectedPage: 'All'
            }
        });

        render(<FeedbackPopupModal visible={true} pages={[]} onHide={hideMock} />);

        // Click on a rating star to ensure ratingValue is set
        fireEvent.click(screen.getAllByTestId('rating-star')[0]);

        // Click submit
        fireEvent.click(screen.getByTestId('feedback-submit-button'));

        await waitFor(() => {
            expect(showToastMessage).toHaveBeenCalledWith({
                type: ToastType.SUCCESS,
                message: 'COMMON.FEEDBACK_SUBMISSION.SUCCESS'
            });

            expect(hideMock).toHaveBeenCalled();
            expect(formStatusStore.clearFormData).toHaveBeenCalled();
        });
    });

    it('shows error toast when form submission fails', async () => {
        const sampleAPIError = new Error('Submission failed');
        const formStoreMock = formStatusStore.getFormData as jest.Mock;
        formStoreMock.mockReturnValue({
            data: {
                feedback: 'Test feedback',
                selectedPage: 'All'
            }
        });
        mockFeedbackFormUpdate.mockRejectedValue(sampleAPIError);
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

        render(<FeedbackPopupModal visible={true} pages={[]} />);
        fireEvent.click(screen.getAllByTestId('rating-star')[0]);

        fireEvent.click(screen.getByTestId('feedback-submit-button'));

        await waitFor(() => {
            expect(showToastMessage).toHaveBeenCalledWith({
                type: ToastType.ERROR,
                message: 'COMMON.FEEDBACK_SUBMISSION.FAILED'
            });
            // Check if console.error is called with the correct message
            expect(consoleErrorSpy).toHaveBeenCalledWith(
                'Error in updating user feedback:',
                sampleAPIError
            );
        });
    });

    it('transforms pages correctly', () => {
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);

        const pages = [
            { id: 1, menu: 'Dashboard', path: '/dashboard' },
            { id: 2, menu: 'Settings', path: '/settings' }
        ];

        render(<FeedbackPopupModal visible={true} pages={pages} />);

        // Expected transformation logic can be asserted here if needed.
        expect(AuthStore.hasPermission).toHaveBeenCalled();
    });
});
