export interface FeedbackFormPayload {
    userId: number;
    firstName: string;
    lastName: string;
    emailId: string;
    rating: number;
    pageName: string;
    notes: string;
}
