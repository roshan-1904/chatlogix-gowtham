import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import CustomAccordion from './accordion';

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn()
}));

const mockTabs = [
    {
        id: 1,
        header: { name: 'Tab 1' },
        content: <div>Tab 1 Content</div>,
        accordionType: 'EP'
    },
    {
        id: 2,
        header: { name: 'Tab 2' },
        content: <div>Tab 2 Content</div>,
        accordionType: 'UP'
    }
];

const mockSetSummary = jest.fn();

describe('CustomAccordion', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the CustomAccordion component and displays tabs', () => {
        render(<CustomAccordion tabs={mockTabs} setSummary={mockSetSummary}></CustomAccordion>);

        waitFor(() => {
            expect(screen.getByText('Tab 1 Content')).toBeInTheDocument();
            expect(screen.getByText('Tab 2')).toBeInTheDocument();
        });
    });

    test('changes tab when clicked and updates summary', () => {
        render(<CustomAccordion tabs={mockTabs} setSummary={mockSetSummary}></CustomAccordion>);

        waitFor(() => {
            expect(screen.getByText('Tab 1 Content')).toBeVisible();
            fireEvent.click(screen.getByText('Tab 2'));
            expect(screen.getByText('Tab 2 Content')).toBeVisible();
            expect(mockSetSummary).toHaveBeenCalled();
        });
    });

    test('selectAccordionBasedOnCondition sets the correct active index', () => {
        render(<CustomAccordion tabs={mockTabs} setSummary={mockSetSummary}></CustomAccordion>);
        waitFor(() => {
            expect(screen.getByText('Tab 1 Content')).toBeVisible();
        });
    });
});
