import { Accordion, AccordionTab } from 'primereact/accordion';
import CustomAccordionHeader from './header.accordion';
import { useEffect, useState } from 'react';
import { accordionType } from './accordion.type';
import { DisclaimerList } from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import orderQuoteDetailsService from 'pages/createOrderAndQuote/components/standard/orderQuoteDetails/services/orderQuoteDetails.service';

const CustomAccordion = ({ tabs, summary, setSummary }: any) => {
    const getHeaderActionClass = (index: any) => {
        if (accordionType.BOTH_UP_EP === index) {
            return 'bg-neutral-100/50 border-neutral-100 focus:shadow-none  rounded-b-lg ';
        } else if (accordionType.EP === index) {
            return '!bg-warning/45 border-warning focus:shadow-none';
        } else {
            return '!bg-primary-100/50 border-primary-100 focus:shadow-none';
        }
    };

    const getHeaderClass = (index: any) => {
        const baseClass =
            "before:content-[''] before:h-[2.2rem] before:rounded-r-[100px] before:mt-4 before:w-[0.3rem] before:absolute before:z-10";

        if (accordionType.BOTH_UP_EP === index) {
            return `before:bg-neutral-200 ${baseClass}`;
        } else if (accordionType.EP === index) {
            return `before:bg-warning-200 ${baseClass}`;
        } else {
            return `before:bg-primary ${baseClass}`;
        }
    };

    const ptForHeader = (index: any) => ({
        content: {
            className: `${index === accordionType.BOTH_UP_EP ? '!border-0' : ''} !p-0`
        },
        headerTitle: { className: 'w-full' },
        headerIcon: {
            className: 'hidden'
        },
        headeraction: {
            className: getHeaderActionClass(index)
        },
        header: {
            className: getHeaderClass(index)
        }
    });
    const quoteOrderData = quoteOrderModuleStore.getData();
    // TODO: const isEditFlow: boolean = quoreOrderData.info?.isEditFlow === true;
    const isUp: boolean = quoteOrderData?.formData?.summaryPage?.flags.IsUp === true;
    const isBothDecideLater: boolean =
        quoteOrderData?.formData?.summaryPage?.flags.isBothDecideLater === true;
    const selectCountryPageForEP = quoteOrderData?.formData?.selectCountryPageForEP;
    const isUPCountrySelected = selectCountryPageForEP?.countryList?.some(
        (country) => country.data.up === true && country.isUpSelected === true
    );

    // function for to find selected service category is ep recordal or renewals
    const isEPRecordalOrRenewals = (): boolean => {
        const selectedCategoryId = quoteOrderData?.info?.selectedCategory
            ?.patentCategoryId as number;
        return (
            selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].Renewals ||
            selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal
        );
    };
    const selectAccordionBasedOnCondition = () => {
        let activeIndex;
        if (isBothDecideLater && isUPCountrySelected) {
            activeIndex = 2;
        } else {
            const shouldSelectZero = isEPRecordalOrRenewals() || !isUPCountrySelected || !!isUp;
            activeIndex = shouldSelectZero ? 0 : 1;
        }
        setActiveIndex(activeIndex);
    };
    const [activeIndex, setActiveIndex] = useState<number | number[] | null>(0);
    const onTabChange = (e: number | number[] | null) => {
        if (e !== null) {
            setActiveIndex(e);
        }
    };

    // use effect call when active index is changed and inside the use effect we are updating the summary flags
    useEffect(() => {
        if (tabs.length > 1) {
            // find tab is select both up and ep
            const isBothDecideLaterIndex = tabs.findIndex(
                (tab: any) => tab.accordionType === accordionType.BOTH_UP_EP
            );

            const updatedQuoteOrderDataFlags = {
                ...quoteOrderData.flags,
                isBothDecideLaterDisableApprove: isBothDecideLaterIndex === activeIndex
            };
            quoteOrderModuleStore.updatePage('flags', updatedQuoteOrderDataFlags);

            const isUPSelected =
                isEPRecordalOrRenewals() || !isUPCountrySelected
                    ? false
                    : activeIndex === 0 || isBothDecideLaterIndex === activeIndex;
            orderQuoteDetailsService
                .getDisclaimers(quoteOrderData.info.primaryId as number, true, isUPSelected)
                .then((disclaimer) => {
                    // update summary flags
                    if (disclaimer && Array.isArray(disclaimer) && disclaimer.length > 0) {
                        const updatedSummary = {
                            ...summary,
                            flags: {
                                ...summary.flags,
                                IsUp: isUPSelected,
                                isBothDecideLater:
                                    activeIndex === isBothDecideLaterIndex && isUPCountrySelected
                                        ? true
                                        : null
                            }
                        };
                        if (updatedSummary?.responseData?.summaryResponse) {
                            updatedSummary.responseData.summaryResponse.disclaimerList =
                                disclaimer as DisclaimerList[];
                        }
                        setSummary(updatedSummary);
                    }
                });
        }
    }, [activeIndex, summary?.flags?.IsUp, summary?.flags?.isBothDecideLater]);

    // useeffect call only once when component is render
    useEffect(() => {
        selectAccordionBasedOnCondition();
    }, []);

    return (
        <div className="card">
            <Accordion activeIndex={activeIndex} onTabChange={(e) => onTabChange(e.index)}>
                {tabs.map((tab: any, index: any) => (
                    <AccordionTab
                        key={tab?.id ?? tab?.header?.name}
                        header={
                            <CustomAccordionHeader
                                header={tab.header}
                                component={tab.component}
                                accordionType={tab.accordionType}
                                {...{ activeIndex, index }}
                            />
                        }
                        pt={ptForHeader(tab.accordionType)}>
                        {/* body */}
                        <>{tab.content}</>
                    </AccordionTab>
                ))}
            </Accordion>
        </div>
    );
};

export default CustomAccordion;
