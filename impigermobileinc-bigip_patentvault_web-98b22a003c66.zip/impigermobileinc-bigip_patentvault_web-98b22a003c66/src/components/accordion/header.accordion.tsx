import { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { AccordionComponents } from './accordion.type';

type AccordionHeader = {
    header: any;
    index: number;
    activeIndex: number | number[] | null;
    component: AccordionComponents;
    accordionType: string;
};

const CustomAccordionHeader: FC<AccordionHeader> = ({
    header,
    index,
    component,
    activeIndex,
    accordionType
}) => {
    const { t } = useTranslation();

    const getRadioButtonStyle = (type: string) => {
        if (type === 'EP') {
            return 'radio-warning';
        } else if (type === 'UP') {
            return 'radio-primary';
        } else {
            return 'checked:bg-neutral-200 border-neutral-200';
        }
    };

    const customHeader = (type: string) => {
        if (component === 'IQSummary') {
            return (
                <div className="flex items-center justify-between font-semibold gap-2 w-full">
                    <div className="flex gap-2 items-center">
                        <input
                            type="radio"
                            className={`radio ${getRadioButtonStyle(type)}`}
                            id={index.toString()}
                            key={index + 1}
                            data-testid={`${header.name}`}
                            checked={index === activeIndex}
                        />
                        <span
                            data-testId="accordianHeader"
                            className="font-bold white-space-nowrap">
                            {header.name}
                        </span>
                    </div>
                    {accordionType !== 'UP_EP' && (
                        <div className="flex flex-row gap-5 justify-center items-center">
                            <label className="text-neutral-400 text-sm font-medium">
                                {t('SUMMARY.GRAND_TOTAL')}
                            </label>
                            <span
                                data-testId="accordianGrantTotal"
                                className="min-w-[5.6rem] text-right">{`${header.currencySymbol} ${header.grandTotal}`}</span>
                        </div>
                    )}
                </div>
            );
        } else {
            return <></>;
        }
    };

    return <>{customHeader(accordionType)}</>;
};

export default CustomAccordionHeader;
