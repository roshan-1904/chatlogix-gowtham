// this type is used to identify the component name for applying specific conditions, generally used for component differentiation.
export type AccordionComponents = 'IQSummary' | '';

export type AccordionHeaderForIQSummary = {
    name: string;
    currencySymbol: string;
    grandTotal: string;
};
export type AccordionMetaData = {
    id: number;
    component: AccordionComponents;
    // in future we can add more header types for other components
    header: AccordionHeaderForIQSummary;
    content: any;
    accordionType: string;
};

export const accordionType = {
    UP: 'UP',
    EP: 'EP',
    BOTH_UP_EP: 'UP_EP'
};
