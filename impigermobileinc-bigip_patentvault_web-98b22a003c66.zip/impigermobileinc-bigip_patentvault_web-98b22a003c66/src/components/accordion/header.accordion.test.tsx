import { render } from '@testing-library/react';
import CustomAccordionHeader from './header.accordion';

describe('CustomAccordionHeader', () => {
    it('renders the header correctly', () => {
        const header = {
            name: 'Test Header',
            currencySymbol: '$',
            grandTotal: 100
        };
        const { getByTestId } = render(
            <CustomAccordionHeader
                header={header}
                index={0}
                component="IQSummary"
                activeIndex={0}
                accordionType="UP"
            />
        );

        expect(getByTestId('Test Header')).toBeInTheDocument();
        expect(getByTestId('accordianHeader')).toHaveTextContent('Test Header');
        expect(getByTestId('accordianGrantTotal')).toHaveTextContent('$ 100');
    });

    it('renders the header EP correctly', () => {
        const header = {
            name: 'Test Header',
            currencySymbol: '$',
            grandTotal: 100
        };
        const { getByTestId } = render(
            <CustomAccordionHeader
                header={header}
                index={0}
                component="IQSummary"
                activeIndex={0}
                accordionType="EP"
            />
        );

        expect(getByTestId('Test Header')).toBeInTheDocument();
        expect(getByTestId('Test Header')).toHaveClass('radio-warning');
        expect(getByTestId('accordianHeader')).toHaveTextContent('Test Header');
        expect(getByTestId('accordianGrantTotal')).toHaveTextContent('$ 100');
    });

    it('does not render the header for non-IQSummary component', () => {
        const header = {
            name: 'Test Header',
            currencySymbol: '$',
            grandTotal: 100
        };
        const { queryByTestId } = render(
            <CustomAccordionHeader
                header={header}
                index={0}
                component=""
                activeIndex={0}
                accordionType="type"
            />
        );

        expect(queryByTestId('accordianHeader')).toBeNull();
    });
});
