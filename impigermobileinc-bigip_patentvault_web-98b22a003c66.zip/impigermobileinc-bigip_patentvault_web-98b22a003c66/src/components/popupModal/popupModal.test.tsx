import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import PopupModal from './popupModal';

// Mock formStatusStore
jest.mock('core/store/formIoStore/formIoStore', () => ({
    // initialState: { hasError: false }, // Mock initial state
    getFormData: jest.fn().mockReturnValue({ data: { id: 1, name: 'test' }, hasError: false }),
    subscribe: jest.fn(), // Mock subscribe function
    init: jest.fn(), // Mock init function
    clearFormData: jest.fn() // Mock clearFormData function
}));

describe('PopupModal Component', () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('renders with provided title', () => {
        const title = 'Test Modal';
        const { getByText } = render(
            <PopupModal
                id="testModal"
                title={title}
                onClose={() => {}}
                createButtonText="Create"
                resetButtonText="Reset"
                isEdit={false}>
                <div>Modal content</div>
            </PopupModal>
        );

        expect(getByText(title)).toBeInTheDocument();
    });

    // Test for rendering and handling the checkbox
    it('renders checkbox for creating another and handles its change event', () => {
        const onChangeCreateAnotherMock = jest.fn();
        const { getByLabelText } = render(
            <PopupModal
                id="testModal"
                title="Test Modal"
                onClose={() => {}}
                createButtonText="Create"
                resetButtonText="Reset"
                isEdit={false}
                createAnotherText="Create Another"
                onChangeCreateAnother={onChangeCreateAnotherMock}>
                <div>Modal content</div>
            </PopupModal>
        );

        // Check if the checkbox is rendered
        const checkbox = getByLabelText('Create Another');
        expect(checkbox).toBeInTheDocument();

        // Simulate changing the checkbox
        fireEvent.click(checkbox);

        // Ensure onChangeCreateAnother is called with the correct value
        expect(onChangeCreateAnotherMock).toHaveBeenCalledWith(true);
    });

    // Test for reset button click
    it('calls closeModal when reset button is clicked in edit mode', () => {
        const onCloseMock = jest.fn();
        const { getByText } = render(
            <PopupModal
                id="testModal"
                title="Test Modal"
                onClose={onCloseMock}
                createButtonText="Create"
                resetButtonText="Reset"
                isEdit={true}>
                <div>Modal content</div>
            </PopupModal>
        );

        fireEvent.click(getByText('Reset'));

        // Ensure closeModal is called in edit mode
        expect(onCloseMock).toHaveBeenCalled();
    });

    // Test for submit button click
    it.skip('calls onSubmit when submit button is clicked and formState has no error', () => {
        const onSubmitMock = jest.fn();
        const { getByText } = render(
            <PopupModal
                id="testModal"
                title="Test Modal"
                onClose={() => {}}
                onSubmit={onSubmitMock}
                createButtonText="Create"
                resetButtonText="Reset"
                isEdit={false}>
                <div>Modal content</div>
            </PopupModal>
        );

        fireEvent.click(getByText('Create'));

        // Ensure onSubmit is called
        expect(onSubmitMock).toHaveBeenCalled();
    });
});
