import formStatusStore from 'core/store/formIoStore/formIoStore';
import { Dispatch, FunctionComponent, SetStateAction } from 'react';
interface PopupModalProps {
    id: string;
    title: JSX.Element | string;
    infoText?: string;
    onClose: () => void;
    onSubmit?: () => void;
    createButtonText?: string;
    resetButtonText: string;
    isEdit: boolean;
    showButtonValidation?: boolean;
    createAnotherText?: string;
    children: React.ReactNode;
    onChangeCreateAnother?: Dispatch<SetStateAction<boolean>>;
    isSubmitHide?: boolean;
    isFormIo?: boolean;
    formDataOnReset?: any;
    disableSubmit?: boolean;
    customReset?: () => void;
    renderCustomBtn?: () => JSX.Element;
    skipValidation?: boolean;
}

const PopupModal: FunctionComponent<PopupModalProps> = ({
    id,
    title,
    onClose,
    onSubmit = () => {},
    createButtonText,
    resetButtonText,
    createAnotherText,
    children,
    showButtonValidation = false,
    isEdit,
    onChangeCreateAnother,
    isSubmitHide = true,
    isFormIo = true,
    formDataOnReset = null,
    disableSubmit,
    customReset,
    infoText,
    skipValidation = false,
    renderCustomBtn
    // data
}) => {
    const closeModal = () => {
        onClose();
    };

    const handleResetButton = () => {
        if (!isFormIo && customReset) customReset();
        else if (isEdit) closeModal();
        else {
            handleReset(id);
        }
    };

    /**
     * Validates the form for the current step.
     *
     * @param {string} popupId - The current path of the step.
     * @returns {Promise<boolean>} True if the form is valid, false otherwise.
     */
    const isFormValid = async (popupId: string): Promise<boolean> => {
        document.getElementById(`submit-${popupId}`)?.click();
        await new Promise((r) => setTimeout(r, 100));
        const updatedFormStatusStore = formStatusStore.getFormData();
        return updatedFormStatusStore.hasError ?? true;
    };
    const handleReset = async (popupId: string) => {
        document.getElementById(`reset-${popupId}`)?.click();
        await new Promise((r) => setTimeout(r, 100));
        formStatusStore.updateFormData(formDataOnReset ? formDataOnReset : null, false);
    };

    const isDisabled = (validation = false) => {
        return showButtonValidation ? validation : false;
    };

    const handleSubmit = async (popupId: string) => {
        if (skipValidation || !(await isFormValid(popupId))) {
            onSubmit();
        }
    };
    return (
        <dialog id={id} className="modal modal-bottom sm:modal-middle">
            <div className="fixed inset-0 flex items-center justify-center z-50">
                <div className="bg-white w-10/12 lg:w-5/12 shadow-lg rounded-md popup-wrapper">
                    {/* Header */}
                    <div className="flex items-center justify-between bg-white drop-shadow p-4 px-6 rounded-t-lg">
                        <h2 className="text-xl font-medium text-primary-200 flex items-center gap-1">
                            {typeof title === 'string' ? (
                                // innerHtml -> while element come as string.
                                <span
                                    className="text-xl"
                                    dangerouslySetInnerHTML={{ __html: title }}
                                />
                            ) : (
                                // in some case, we sent the element as well.
                                title
                            )}
                            {infoText && (
                                <p className="bg-warning/40 w-fit my-3 py-0.5 px-2 rounded border-2 border-warning text-sm text-neutral-700 flex gap-1 items-center">
                                    <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                                    {infoText}
                                </p>
                            )}
                        </h2>

                        <button
                            onClick={closeModal}
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    closeModal();
                                }
                            }}
                            data-testid="PopUp-Close"
                            className="text-gray-500 hover:text-gray-800">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-6 w-6"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                    d="M6 18L18 6M6 6l12 12"
                                />
                            </svg>
                        </button>
                    </div>
                    {/* Content */}
                    <div>{children}</div>
                    {/* Footer */}
                    <div
                        className={`flex items-center bg-white border-t border-gray-300 shadow-md px-6 py-3 rounded-b-lg ${!isEdit || renderCustomBtn ? 'justify-between' : 'justify-end'}`}>
                        {renderCustomBtn?.()}
                        {createAnotherText && onChangeCreateAnother && !isEdit && (
                            <label className="label cursor-pointer flex items-center space-x-2">
                                <input
                                    type="checkbox"
                                    className="form-checkbox"
                                    onChange={(e) => onChangeCreateAnother(e.target.checked)}
                                />
                                <span>{createAnotherText}</span>
                            </label>
                        )}
                        <div className="flex gap-2">
                            <button
                                className="btn btn-sm button-neutral font-medium"
                                onClick={() => {
                                    handleResetButton();
                                }}
                                onKeyDown={(event) => {
                                    if (event.key === 'Enter') {
                                        handleResetButton();
                                    }
                                }}
                                disabled={isDisabled(
                                    isEdit ? false : formStatusStore.getFormData()?.data === null
                                )}>
                                {resetButtonText}
                            </button>
                            {createButtonText && (
                                <button
                                    data-testid={'submit-button-popup'}
                                    className={`btn btn-sm button-primary font-medium ${isSubmitHide ? '' : 'hidden'}`}
                                    onClick={() => {
                                        if (isFormIo) handleSubmit(id);
                                        else if (onSubmit) onSubmit();
                                    }}
                                    onKeyDown={(event) => {
                                        if (event.key === 'Enter') {
                                            handleSubmit(id);
                                        }
                                    }}
                                    disabled={
                                        disableSubmit
                                            ? disableSubmit
                                            : isDisabled(
                                                  isEdit
                                                      ? !formStatusStore.getFormData()?.isChanged
                                                      : false
                                              )
                                    }>
                                    {createButtonText}
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </dialog>
    );
};

export default PopupModal;
