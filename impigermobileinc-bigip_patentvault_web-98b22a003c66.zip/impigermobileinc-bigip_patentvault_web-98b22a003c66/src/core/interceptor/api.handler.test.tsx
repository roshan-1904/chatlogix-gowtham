import '@testing-library/jest-dom/extend-expect';
import HttpService from './api.handler';

test('it should mount', () => {
    expect(HttpService).toBeInstanceOf(Object);
});

describe('<HttpService>', () => {
    let service = new HttpService();

    beforeEach(() => {
        service = new HttpService();
    });

    it('should inject interceptors for request and response', () => {
        // expect(service.get.length).toBe(2);
        // expect(service.post.length).toBe(3);
    });

    test('should return the service instance', () => {
        const config = service;
        expect(config).toBeInstanceOf(Object);
    });

    // test('should return the service get instance', async () => {
    //     const response = await service.get(EHttpMethod.GET, '/test', false);
    //     expect(response).toBeCalled();
    // });

    // test('should return the service post instance', async () => {
    //     const response = await service.post(EHttpMethod.GET, '/test', false);
    //     expect(response).toBeInstanceOf(Promise);
    // });

    // test('should return the service put instance', async () => {
    //     const response = await service.update(EHttpMethod.GET, '/test', false);
    //     expect(response).toBeInstanceOf(Promise);
    // });

    // test('should return the service delete instance', async () => {
    //     const response = await service.delete(EHttpMethod.GET, '/test', false);
    //     expect(response).toBeInstanceOf(Promise);
    // });
});
