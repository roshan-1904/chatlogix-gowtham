import '@testing-library/jest-dom/extend-expect';
import i18n from './i18next';

test('it should mount', () => {
    expect(i18n).toBeInstanceOf(Object);
});
