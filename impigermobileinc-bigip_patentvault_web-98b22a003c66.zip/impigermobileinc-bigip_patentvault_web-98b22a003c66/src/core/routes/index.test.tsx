import { describe, it, expect, jest } from '@jest/globals';
import { router } from './index';
import { PATHS } from 'constants/routes.constant';

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

describe('Router Configuration', () => {
    it('should define the root route', () => {
        const rootRoute = router.find((route) => route.id === 'root');
        expect(rootRoute).toBeDefined();
        expect(rootRoute?.path).toBe('/');
        expect(rootRoute?.Component).toBeDefined();
    });

    it('should define the login route', () => {
        const loginRoute = router.find((route) => route.path === 'login');
        expect(loginRoute).toBeDefined();
    });

    it('should define the orders-quotes route', () => {
        const ordersQuotesRoute = router.find((route) => route.path === 'orders-quotes');
        expect(ordersQuotesRoute).toBeDefined();
        expect(ordersQuotesRoute?.children).toBeUndefined();
    });

    it('should define the create order and quote route with children', () => {
        const createOrderRoute = router.find(
            (route) => route.path === `${PATHS.ORDER_QUOTE}/${PATHS.CREATE}`
        );
        expect(createOrderRoute).toBeDefined();
        expect(createOrderRoute?.children).toBeDefined();
        expect(createOrderRoute?.children?.length).toBeGreaterThan(0);
    });

    it('should define the edit order and quote route with children', () => {
        const editOrderRoute = router.find(
            (route) => route.path === `${PATHS.ORDER_QUOTE}/${PATHS.EDIT}`
        );
        expect(editOrderRoute).toBeDefined();
        expect(editOrderRoute?.children).toBeDefined();
        expect(editOrderRoute?.children?.length).toBeGreaterThan(0);
    });

    it('should define the companies create route with children', () => {
        const createCompanyRoute = router.find(
            (route) => route.path === `${PATHS.COMPANIES}/${PATHS.CREATE}`
        );
        expect(createCompanyRoute).toBeDefined();
        expect(createCompanyRoute?.children).toBeDefined();
        expect(createCompanyRoute?.children?.length).toBeGreaterThan(0);
    });

    it('should define the companies edit route with children', () => {
        const editCompanyRoute = router.find(
            (route) => route.path === `${PATHS.COMPANIES}/${PATHS.EDIT}/:company_id?`
        );
        expect(editCompanyRoute).toBeDefined();
        expect(editCompanyRoute?.children).toBeDefined();
        expect(editCompanyRoute?.children?.length).toBeGreaterThan(0);
    });

    it('should define the users route', () => {
        const usersRoute = router.find((route) => route.path === 'users');
        expect(usersRoute).toBeDefined();
    });

    it('should define the task management route', () => {
        const taskManagementRoute = router.find((route) => route.path === 'task-management');
        expect(taskManagementRoute).toBeDefined();
    });

    it('should define the access-denied route', () => {
        const accessDeniedRoute = router.find((route) => route.path === 'access-denied');
        expect(accessDeniedRoute).toBeDefined();
    });

    it('should register a beforeunload event listener', () => {
        const addEventListenerSpy = jest.spyOn(window, 'addEventListener');
        const callback = jest.fn();

        addEventListener('beforeunload', callback);

        expect(addEventListenerSpy).toHaveBeenCalledWith('beforeunload', expect.any(Function));

        addEventListenerSpy.mockRestore();
    });

    it('should register a beforeunload event listener with an empty callback', () => {
        const addEventListenerSpy = jest.spyOn(window, 'addEventListener');
        const callback = jest.fn();

        addEventListener('beforeunload', callback);

        expect(addEventListenerSpy).toHaveBeenCalledWith('beforeunload', expect.any(Function));

        const registeredCallback = addEventListenerSpy.mock.calls.find(
            (call) => call[0] === 'beforeunload'
        )?.[1];

        expect(registeredCallback).toBeDefined();
        expect(registeredCallback?.toString()).toBe('() => {}');

        addEventListenerSpy.mockRestore();
    });

    it('should unregister the service worker on beforeunload', () => {
        const serviceWorkerRegistration = {
            unregister: jest.fn()
        };

        const unregisterSpy = jest.spyOn(serviceWorkerRegistration, 'unregister');

        const beforeUnloadEvent = new Event('beforeunload');
        window.dispatchEvent(beforeUnloadEvent);

        expect(unregisterSpy).toHaveBeenCalled();

        unregisterSpy.mockRestore();
    });
});
