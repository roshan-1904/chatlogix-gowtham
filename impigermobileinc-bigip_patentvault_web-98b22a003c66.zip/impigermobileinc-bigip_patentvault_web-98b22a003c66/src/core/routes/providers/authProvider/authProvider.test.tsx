import { protectedLoader } from './authProvider';
import AuthStore from 'core/store/authStore/authStore';
import { redirect } from 'react-router-dom';
import { generateHeaderMenu } from 'layouts/headerMenu/headerMenu.constant';

jest.mock('core/store/authStore/authStore');
jest.mock('react-router-dom', () => ({
    redirect: jest.fn()
}));

jest.mock('constants/app.constant', () => ({
    PROTECTED_ROUTES: [
        { route: 'protectedRoute', permission: 'view_protected' },
        { route: 'openRoute' }
    ]
}));

jest.mock('layouts/headerMenu/headerMenu.constant', () => ({
    generateHeaderMenu: jest.fn()
}));

describe('protectedLoader', () => {
    const mockRequest = (url: string) => ({
        request: new Request(url),
        params: {}
    });

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should redirect to login if user is not authenticated', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(false);

        const result = protectedLoader(mockRequest('http://localhost/protectedRoute'));

        expect(localStorage.setItem).toHaveBeenCalledWith('redirectUrl', '/protectedRoute');
        expect(redirect).toHaveBeenCalledWith('/login?from=%2FprotectedRoute');
        expect(result).toEqual(redirect('/login?from=%2FprotectedRoute'));
    });

    it('should redirect to access-denied if user lacks required permissions', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(false);

        const result = protectedLoader(
            mockRequest('http://localhost/protectedRoute'),
            'view_protected'
        );

        expect(redirect).toHaveBeenCalledWith('/access-denied');
        expect(result).toEqual(redirect('/access-denied'));
    });

    it('should allow access if user has required permissions', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);

        const result = protectedLoader(
            mockRequest('http://localhost/protectedRoute'),
            'view_protected'
        );

        expect(result).toBeNull();
    });

    it('should allow access if no permissions are required and user is authenticated', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);

        const result = protectedLoader(mockRequest('http://localhost/openRoute'));

        expect(result).toBeNull();
    });

    it('should redirect to access-denied if user lacks menu permissions', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(false);
        (generateHeaderMenu as jest.Mock).mockReturnValue([
            { path: 'protectedRoute', permission: ['view_protected'] }
        ]);

        const result = protectedLoader(mockRequest('http://localhost/protectedRoute'));

        expect(redirect).toHaveBeenCalledWith('/access-denied');
        expect(result).toEqual(redirect('/access-denied'));
    });

    it('should allow access if user has menu permissions', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockImplementation(
            (permission) => permission === 'view_protected'
        );
        (generateHeaderMenu as jest.Mock).mockReturnValue([
            { path: 'protectedRoute', permission: ['view_protected'] }
        ]);

        const result = protectedLoader(mockRequest('http://localhost/protectedRoute'));

        expect(result).toBeNull();
    });

    it('should check PROTECTED_ROUTES if no menu is found', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockImplementation(
            (permission) => permission === 'view_protected'
        );
        (generateHeaderMenu as jest.Mock).mockReturnValue([]);

        const result = protectedLoader(mockRequest('http://localhost/protectedRoute'));

        expect(result).toBeNull();
    });

    it('should redirect to access-denied if no menu or route permissions are found', () => {
        (AuthStore.isAuthenticated as jest.Mock).mockReturnValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(false);
        (generateHeaderMenu as jest.Mock).mockReturnValue([]);

        const result = protectedLoader(mockRequest('http://localhost/protectedRoute'));

        expect(redirect).toHaveBeenCalledWith('/access-denied');
        expect(result).toEqual(redirect('/access-denied'));
    });
});
