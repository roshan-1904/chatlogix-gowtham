import { Subject } from 'rxjs';
import { PATHS } from 'constants/routes.constant';
import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';
import { CreateTaskFormData } from './createTask.store.type';

export interface TaskStepper {
    isFormValid: any;
    formData: CreateTaskFormData;
}

const initialTaskStepperState = {
    isFormValid: {
        [PATHS.TASK_DETAILS]: null,
        [PATHS.FILE_UPLOAD]: true
    },
    formData: {
        // Keep all page as 'null' to validate while page navigation
        createTaskDetailsPage: null,
        createTaskFileUploadPage: null,
        primaryId: 0,
        manualTaskId: 0,
        isTaskCreationFromBillsInvoicePage: false
    }
} as const;

// type AllowedStaffUserStoreValue = keyof typeof initialUserStepperState;

let state: TaskStepper = initialTaskStepperState;
const subject = new Subject<TaskStepper>();

const taskStepperStore: StepperStoreState<CreateTaskFormData> = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState) => subject.subscribe(setState),
    updatePage(field, value) {
        state = {
            ...state,
            [field]: value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    resetStepperModuleStore() {
        state = initialTaskStepperState;
        subject.next(state);
    },
    initialState: initialTaskStepperState
};

export default taskStepperStore;
