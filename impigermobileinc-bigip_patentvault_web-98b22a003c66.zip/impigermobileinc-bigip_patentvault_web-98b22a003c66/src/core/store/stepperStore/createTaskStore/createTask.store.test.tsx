import taskStepperStore from 'core/store/stepperStore/createTaskStore/createTask.store';
import { PATHS } from 'constants/routes.constant';

describe('taskStepperStore', () => {
    beforeEach(() => {
        taskStepperStore.init();
    });

    afterEach(() => {
        taskStepperStore.resetStepperModuleStore();
    });

    test('should initialize with the correct initial state', () => {
        const initialState = taskStepperStore.getData();
        expect(initialState.isFormValid[PATHS.TASK_DETAILS]).toBeNull();
        expect(initialState.isFormValid[PATHS.FILE_UPLOAD]).toBe(true);
        expect(initialState.formData.createTaskDetailsPage).toBeNull();
        expect(initialState.formData.createTaskFileUploadPage).toBeNull();
        expect(initialState.formData.primaryId).toBe(0);
        expect(initialState.formData.manualTaskId).toBe(0);
    });

    test('should update the state correctly when updatePage is called', () => {
        const newFormData = {
            createTaskDetailsPage: 'details',
            createTaskFileUploadPage: 'file',
            primaryId: 1,
            manualTaskId: 2
        };

        taskStepperStore.updatePage('formData', newFormData);

        const updatedState = taskStepperStore.getData();
        expect(updatedState.formData.createTaskDetailsPage).toBe('details');
        expect(updatedState.formData.createTaskFileUploadPage).toBe('file');
        expect(updatedState.formData.primaryId).toBe(1);
        expect(updatedState.formData.manualTaskId).toBe(2);
    });

    test('should reset the state to the initial state when resetStepperModuleStore is called', () => {
        const newFormData = {
            createTaskDetailsPage: 'details',
            createTaskFileUploadPage: 'file',
            primaryId: 1,
            manualTaskId: 2
        };
        taskStepperStore.updatePage('formData', newFormData);

        taskStepperStore.resetStepperModuleStore();

        const resetState = taskStepperStore.getData();
        expect(resetState.isFormValid[PATHS.TASK_DETAILS]).toBeNull();
        expect(resetState.isFormValid[PATHS.FILE_UPLOAD]).toBe(true);
        expect(resetState.formData.createTaskDetailsPage).toBeNull();
        expect(resetState.formData.createTaskFileUploadPage).toBeNull();
        expect(resetState.formData.primaryId).toBe(0);
        expect(resetState.formData.manualTaskId).toBe(0);
    });
});
