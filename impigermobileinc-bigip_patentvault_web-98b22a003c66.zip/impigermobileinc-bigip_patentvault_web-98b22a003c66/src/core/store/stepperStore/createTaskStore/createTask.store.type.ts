export interface CreateTaskFormData {
    createTaskDetailsPage: any;
    createTaskFileUploadPage: any;
    primaryId: number;
    manualTaskId: number;
}
