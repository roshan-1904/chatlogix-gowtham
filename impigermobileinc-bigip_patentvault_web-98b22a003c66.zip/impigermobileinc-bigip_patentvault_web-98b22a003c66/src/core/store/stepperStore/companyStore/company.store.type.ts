import { BalanceInfo } from 'pages/companies/types/companies.types';

export interface CompanyFormData {
    companyProfilePage: any; // formioData
    billingInfoPage: any;
    contacts: any;
    companyFileUpload: any;
    balanceInformation?: BalanceInfo;
    // rates: any;
}
