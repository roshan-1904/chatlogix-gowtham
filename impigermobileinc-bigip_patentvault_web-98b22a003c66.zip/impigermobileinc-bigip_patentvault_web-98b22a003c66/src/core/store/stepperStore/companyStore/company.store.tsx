import { Subject } from 'rxjs';
import { PATHS } from 'constants/routes.constant';
import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';
import { CompanyFormData } from './company.store.type';

const initialCompanyStepperState = {
    stepperInfo: {
        userType: null,
        primaryId: null,
        documentId: null
    },
    isFormValid: {
        [PATHS.COMPANY_PROFILE]: null,
        [PATHS.BILLING_INFO]: null,
        [PATHS.CONTACTS]: true,
        [PATHS.FILE_UPLOAD]: true,
        [PATHS.RATES]: true
    },
    formData: {
        // Keep all page as 'null' to validate while page navigation
        companyProfilePage: null,
        billingInfoPage: null,
        contacts: null,
        companyFileUpload: null,
        rates: null
    }
} as const;

// type AllowedCompanyStoreValue = keyof typeof initialCompanyStepperState;

let state: typeof initialCompanyStepperState = initialCompanyStepperState;
const subject = new Subject<typeof initialCompanyStepperState>();

const companyStepperStore: StepperStoreState<CompanyFormData> = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState) => subject.subscribe(setState),
    updatePage(field, value) {
        state = {
            ...state,
            [field]: value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    resetStepperModuleStore() {
        state = initialCompanyStepperState;
        subject.next(state);
    },
    initialState: initialCompanyStepperState
};

export default companyStepperStore;
