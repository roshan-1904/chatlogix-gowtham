export interface UserFormData {
    staffUserProfilePage: any;
    staffFileUploadPage: any;

    contactUserProfilePage: any;
    contactBillingInfoPage: any;

    vendorUserProfilePage: any;
    vendorFileUploadPage: any;
    vendorBillingInfoPage: any;
}
