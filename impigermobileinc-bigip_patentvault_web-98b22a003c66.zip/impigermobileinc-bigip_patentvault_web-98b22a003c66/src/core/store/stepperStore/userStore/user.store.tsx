import { Subject } from 'rxjs';
import { PATHS } from 'constants/routes.constant';
import { StepperStoreState } from 'pages/components/progressStepper/types/progressStepper.type';
import { UserFormData } from './user.store.type';

const initialUserStepperState = {
    stepperInfo: {
        userType: null,
        primaryId: null,
        documentId: null
    },
    isFormValid: {
        [PATHS.STAFF_USER_PROFILE]: null,
        [PATHS.FILE_UPLOAD]: true,
        [PATHS.CONTACT_USER_PROFILE]: null,
        [PATHS.CONTACT_BILLING_INFO]: null,
        [PATHS.VENDOR_USER_PROFILE]: null,
        [PATHS.VENDOR_BILLING_INFO]: null,
        [PATHS.VENDOR_RATES]: true,
        [PATHS.VENDOR_MINIMUM_CHARGES]: true
    },
    formData: {
        // Keep all page as 'null' to validate while page navigation

        staffUserProfilePage: null,
        staffFileUploadPage: { isMandatory: false },

        contactUserProfilePage: null,
        contactBillingInfoPage: null,

        vendorUserProfilePage: null,
        vendorFileUploadPage: { isMandatory: true },
        vendorBillingInfoPage: null,
        vendorRatePage: null,
        vendorMinimumPage: null
    }
} as const;

// type AllowedStaffUserStoreValue = keyof typeof initialUserStepperState;

let state: typeof initialUserStepperState = initialUserStepperState;
const subject = new Subject<typeof initialUserStepperState>();

const userStepperStore: StepperStoreState<UserFormData> = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState) => subject.subscribe(setState),
    updatePage(field, value) {
        state = {
            ...state,
            [field]: value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    resetStepperModuleStore() {
        state = initialUserStepperState;
        subject.next(state);
    },
    initialState: initialUserStepperState
};

export default userStepperStore;
