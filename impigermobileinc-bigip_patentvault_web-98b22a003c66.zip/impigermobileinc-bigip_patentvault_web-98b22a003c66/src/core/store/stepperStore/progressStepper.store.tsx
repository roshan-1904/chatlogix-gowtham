import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import { Subject } from 'rxjs';

const subject = new Subject();
// Mock data
// export const initialProgressStepperData: STEPPER_DATA_TYPE[] = [
//     {
//         stepperId: 1,
//         stepperName: 'Select Service',
//         stepperDesc: 'Select Service Type'
//     },
//     {
//         stepperId: 2,
//         stepperName: 'Company & Authentication',
//         stepperDesc: 'Company & Authentication Details'
//     }
// ];

export const initialProgressStepperState: STEPPER_STATE = {
    stepperInfo: {
        currStep: null,
        completedStepsIds: []
    },
    // It will be update based on users selecting the service category */
    stepperList: null
};

let state: STEPPER_STATE = initialProgressStepperState;

const stepperStore = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState: (value: any) => void) => subject.subscribe(setState),
    updateStepper(data: { stepperInfo?: STEPPER_INFO; stepperList?: STEPPER_DATA_TYPE[] | null }) {
        state = {
            ...state,
            ...data
        };
        subject.next(state);
    },
    getStepperData() {
        return state;
    },
    resetStepperStore() {
        state = initialProgressStepperState;
        subject.next(state);
    },
    getIsLastStepper(stepperId: number): boolean {
        const stepperList = state.stepperList;
        if (!stepperList || stepperList.length === 0) return false;
        const lastStepperId = stepperList.at(-1);
        const currStepperId = state.stepperInfo.currStep?.stepperId;
        return lastStepperId?.stepperId === stepperId && currStepperId === stepperId;
    },
    initialState: initialProgressStepperState
};

export default stepperStore;
