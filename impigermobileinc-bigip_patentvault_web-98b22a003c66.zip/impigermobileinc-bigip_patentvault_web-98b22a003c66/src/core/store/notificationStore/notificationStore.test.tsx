import NotificationStore, { notificationModel, ToastType } from './notificationStore';

// Mock Subject from RxJS
jest.mock('rxjs', () => ({
    Subject: jest.fn(() => ({
        next: jest.fn(),
        subscribe: jest.fn()
    }))
}));

describe('NotificationStore', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('init', () => {
        it('should initialize state and emit initial value', () => {
            NotificationStore.init();
            expect(NotificationStore.initialState).toEqual({ data: null, hasError: true });
            // expect(Subject).toHaveBeenCalledTimes(1); // Subject constructor called
            // expect(NotificationStore.subscribe).toHaveBeenCalledTimes(1); // Subscribe called
            // expect(NotificationStore.subscribe).toHaveBeenCalledWith(expect.any(Function));
            // expect(NotificationStore.showAlert).toHaveBeenCalledTimes(1); // Initial state emitted
            // expect(NotificationStore.showAlert).toHaveBeenCalledWith('');
        });
    });

    describe('subscribe', () => {
        it('should subscribe to notification updates', () => {
            const setStateMock = jest.fn();
            NotificationStore.subscribe(setStateMock);
            // expect(NotificationStore.subscribe).toHaveBeenCalledTimes(1); // Subscribe called
            // expect(NotificationStore.subscribe).toHaveBeenCalledWith(setStateMock);
        });
    });

    describe('showAlert', () => {
        it('should update state and emit new value', () => {
            const message: notificationModel = { message: 'Test message', type: ToastType.SUCCESS };
            NotificationStore.showAlert(message);
            // expect(NotificationStore.showAlert).toHaveBeenCalledTimes(1); // showAlert called
            // expect(Subject).toHaveBeenCalledTimes(1); // Subject constructor called
            // expect(NotificationStore.showAlert).toHaveBeenCalledWith(message);
        });
    });
});
