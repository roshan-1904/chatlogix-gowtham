import { Subject } from 'rxjs';
import countryListingStore from './country.store';

describe('countryListingStore', () => {
    let setState: jest.Mock;
    let subject: Subject<any>;

    beforeEach(() => {
        setState = jest.fn();
        subject = new Subject();
        countryListingStore.subscribe(setState);
    });

    afterEach(() => {
        subject.complete();
    });

    test('it should initialize the state', () => {
        countryListingStore.init();
        expect(setState).toHaveBeenCalledWith(countryListingStore.initialState);
    });

    test('it should update the stepper', () => {
        const data = {
            instantQuote: {
                /* your test data */
            },
            customQuote: {
                /* your test data */
            }
        };

        countryListingStore.updateStepper(data);
        expect(setState).toHaveBeenCalledWith({
            ...countryListingStore.initialState,
            ...data
        });
    });
});
