import { Subject } from 'rxjs';
import { SelectCountryData } from 'pages/orders/selectCountry/types/country.type';

const subject = new Subject();

export interface CountryListingStore {
    instantQuote: SelectCountryData[];
    customQuote: SelectCountryData[];
}

const initialQuoteAndOrderState: CountryListingStore = {
    instantQuote: [],
    customQuote: []
};

let state: CountryListingStore = initialQuoteAndOrderState;

const countryListingStore = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState: (value: any) => void) => subject.subscribe(setState),
    updateStepper(data: { instantQuote?: any; customQuote?: any }) {
        state = {
            ...state,
            ...data
        };
        subject.next(state);
    },
    initialState: initialQuoteAndOrderState
};

export default countryListingStore;
