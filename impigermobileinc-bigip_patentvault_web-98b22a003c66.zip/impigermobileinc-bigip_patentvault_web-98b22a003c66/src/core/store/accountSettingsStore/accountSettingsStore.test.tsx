import { AccountInfoFormData } from 'pages/accountSettings/types/accountSettings.types';
import accountInfoStore from './accountSettingsStore';

describe('accountInfoStore', () => {
    let mockSubscriber: jest.Mock;
    let mockSubscriber2: jest.Mock;

    beforeEach(() => {
        // Reset the state before each test
        accountInfoStore.init();
        mockSubscriber = jest.fn();
        mockSubscriber2 = jest.fn();
        accountInfoStore.subscribe(mockSubscriber);
        mockSubscriber(accountInfoStore.getData()); // Manually trigger the initial state
    });

    it('should initialize state correctly', () => {
        const initialState: AccountInfoFormData = accountInfoStore.initialState;
        expect(accountInfoStore.getData()).toEqual(initialState);
    });

    it('should subscribe and receive initial state', () => {
        expect(mockSubscriber).toHaveBeenCalledWith(accountInfoStore.initialState);
    });

    it('should update form data and notify subscribers', () => {
        const newFormData: AccountInfoFormData = {
            firstName: 'John',
            lastName: 'Doe',
            phoneNumber: '1234567890'
        };

        accountInfoStore.updateFormData(newFormData);

        expect(accountInfoStore.getData()).toEqual(newFormData);
        expect(mockSubscriber).toHaveBeenCalledWith(newFormData);
    });

    it('should reset state on init', () => {
        const newFormData: AccountInfoFormData = {
            firstName: 'John',
            lastName: 'Doe',
            phoneNumber: '1234567890'
        };

        accountInfoStore.updateFormData(newFormData);
        expect(accountInfoStore.getData()).toEqual(newFormData);

        accountInfoStore.init();
        expect(accountInfoStore.getData()).toEqual(accountInfoStore.initialState);
        expect(mockSubscriber).toHaveBeenCalledWith(accountInfoStore.initialState);
    });

    it('should allow multiple subscribers', () => {
        accountInfoStore.subscribe(mockSubscriber2);
        mockSubscriber2(accountInfoStore.getData()); // Manually trigger the initial state for the second subscriber

        const newFormData: AccountInfoFormData = {
            firstName: 'Jane',
            lastName: 'Smith',
            phoneNumber: '0987654321'
        };

        accountInfoStore.updateFormData(newFormData);

        expect(mockSubscriber).toHaveBeenCalledWith(newFormData);
        expect(mockSubscriber2).toHaveBeenCalledWith(newFormData);
    });

    it('should allow unsubscribing', () => {
        const subscription = accountInfoStore.subscribe(mockSubscriber2);
        subscription.unsubscribe();

        const newFormData: AccountInfoFormData = {
            firstName: 'Jane',
            lastName: 'Smith',
            phoneNumber: '0987654321'
        };

        accountInfoStore.updateFormData(newFormData);

        expect(mockSubscriber).toHaveBeenCalledWith(newFormData);
        expect(mockSubscriber2).not.toHaveBeenCalledWith(newFormData);
    });
});
