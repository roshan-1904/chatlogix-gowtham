import { Subject } from 'rxjs';
import { Subscription } from 'pages/components/progressStepper/types/progressStepper.type';
import { AccountInfoFormData } from 'pages/accountSettings/types/accountSettings.types';

export interface AccountInfoStoreState {
    init: () => void;
    subscribe: (setState: (value: AccountInfoFormData) => void) => Subscription;
    updateFormData: (value: AccountInfoFormData) => void;
    getData: () => AccountInfoFormData;
    initialState: AccountInfoFormData;
}

export const initialAccountInfoState: AccountInfoFormData = {
    firstName: '',
    lastName: '',
    phoneNumber: ''
};

let state: AccountInfoFormData = initialAccountInfoState;
const subject = new Subject<AccountInfoFormData>();

const accountInfoStore: AccountInfoStoreState = {
    init() {
        state = { ...initialAccountInfoState };
        subject.next(state);
    },
    subscribe: (setState) => subject.subscribe(setState),
    updateFormData(value) {
        state = {
            ...value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    initialState: initialAccountInfoState
};

export default accountInfoStore;
