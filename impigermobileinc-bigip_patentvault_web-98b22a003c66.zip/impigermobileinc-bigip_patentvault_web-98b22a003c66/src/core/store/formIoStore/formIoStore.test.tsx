import formStatusStore, { FormStatus } from './formIoStore';

describe('formStatusStore', () => {
    beforeEach(() => {
        // Reset the form status store to initial state before each test
        formStatusStore.init();
    });

    it('initializes with the correct initial state', () => {
        const initialState: FormStatus = formStatusStore.initialState;
        expect(initialState).toEqual({
            data: null,
            hasError: true,
            isChanged: false
        });
    });

    it('updates form data and error status correctly', () => {
        const message = null;
        const isValid = true;
        const isChanged = false;

        formStatusStore.updateFormData(message, isValid, isChanged);

        const currentState: FormStatus = formStatusStore.initialState;
        expect(currentState).toEqual({
            data: message,
            hasError: isValid,
            isChanged
        });
    });

    it('clears form data and resets to initial state', () => {
        formStatusStore.updateFormData('Sample data', true);
        formStatusStore.clearFormData();

        const currentState: FormStatus = formStatusStore.initialState;
        expect(currentState).toEqual({
            data: null,
            hasError: true,
            isChanged: false
        });
    });

    it('subscribes to form status updates correctly', () => {
        const mockCallback = jest.fn();

        formStatusStore.subscribe(mockCallback);
        formStatusStore.updateFormData('New data', false, true);

        expect(mockCallback).toHaveBeenCalledTimes(1);
        expect(mockCallback).toHaveBeenCalledWith({
            data: 'New data',
            hasError: true,
            isChanged: true
        });

        formStatusStore.clearFormData();
        expect(mockCallback).toHaveBeenCalledTimes(2);
        expect(mockCallback).toHaveBeenCalledWith({
            data: null,
            hasError: true,
            isChanged: false
        });
    });
});
