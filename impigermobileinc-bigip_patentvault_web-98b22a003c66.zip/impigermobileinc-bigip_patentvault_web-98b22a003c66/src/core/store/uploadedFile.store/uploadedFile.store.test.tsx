import { UploadedFileStore, initialFileUpload, UploadedFileStoreProps } from './uploadedFile.store';
import { handleAzureStorageUploadTheFile } from 'components/fileUpload/services/azureStorage.service';
import NotificationStore, { ToastType } from '../notificationStore/notificationStore';
import { waitFor } from '@testing-library/react';

jest.mock('components/fileUpload/services/azureStorage.service');
jest.mock('../notificationStore/notificationStore');

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('UploadedFileStore', () => {
    beforeEach(() => {
        UploadedFileStore.init();
    });

    test('should initialize with initial state', () => {
        expect(UploadedFileStore.initialState).toEqual(initialFileUpload);
    });

    test('should subscribe and update state', () => {
        const setState = jest.fn();
        UploadedFileStore.subscribe(setState);
        UploadedFileStore.init();
        expect(setState).toHaveBeenCalledWith(initialFileUpload);
    });

    test('should update data with valid files', () => {
        const validFile: UploadedFileStoreProps = {
            name: 'test.pdf',
            size: 500,
            type: 'application/pdf',
            progress: 0,
            file: new File([''], 'test.pdf', { type: 'application/pdf' }),
            documentType: 1,
            azureBlobFolderPath: 'folder',
            azureBlobFileName: 'test.pdf'
        };

        (handleAzureStorageUploadTheFile as jest.Mock).mockReturnValue(true);

        UploadedFileStore.updateData([validFile]);
        expect(handleAzureStorageUploadTheFile).toHaveBeenCalled();
    });

    test('should show warning for unsupported files', () => {
        const invalidFile: UploadedFileStoreProps = {
            name: 'test.exe',
            size: 500,
            type: 'application/x-msdownload',
            progress: 0,
            file: new File([''], 'test.exe', { type: 'application/x-msdownload' }),
            documentType: 1,
            azureBlobFolderPath: 'folder',
            azureBlobFileName: 'test.exe'
        };

        (handleAzureStorageUploadTheFile as jest.Mock).mockReturnValue(false);

        UploadedFileStore.updateData([invalidFile]);
        expect(NotificationStore.showAlert).toHaveBeenCalledWith({
            message: '1 unsupported file(s): test.exe',
            type: ToastType.WARNING
        });
    });

    test('should update file upload progress', () => {
        const file: UploadedFileStoreProps = {
            name: 'test.pdf',
            size: 500,
            type: 'application/pdf',
            progress: 0,
            file: new File([''], 'test.pdf', { type: 'application/pdf' }),
            documentType: 1,
            azureBlobFolderPath: 'folder',
            azureBlobFileName: 'test.pdf'
        };

        UploadedFileStore.updateData([file]);
        UploadedFileStore.UploadingFileStatus('test.pdf', '50');
        waitFor(() => {
            expect(UploadedFileStore.initialState.files[0]?.progress).toBe('50');
        });
    });

    test('should delete a file', () => {
        const file: UploadedFileStoreProps = {
            name: 'test.pdf',
            size: 500,
            type: 'application/pdf',
            progress: 0,
            file: new File([''], 'test.pdf', { type: 'application/pdf' }),
            documentType: 1,
            azureBlobFolderPath: 'folder',
            azureBlobFileName: 'test.pdf'
        };

        UploadedFileStore.updateData([file]);
        UploadedFileStore.deleteTheFile('test.pdf');
        expect(UploadedFileStore.initialState.files.length).toBe(0);
    });

    test('should reset file upload', () => {
        UploadedFileStore.resetFileUpload();
        expect(UploadedFileStore.initialState.files.length).toBe(0);
    });

    test('should handle file upload complete', () => {
        UploadedFileStore.handleFileUploadComplete('Upload complete');
        expect(NotificationStore.showAlert).toHaveBeenCalledWith({
            message: 'Upload complete',
            type: ToastType.SUCCESS
        });
    });
});
