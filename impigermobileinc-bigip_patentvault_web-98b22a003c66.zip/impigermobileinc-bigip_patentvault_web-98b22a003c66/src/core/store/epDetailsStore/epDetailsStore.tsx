import { Subject } from 'rxjs';
import { Subscription } from 'pages/components/progressStepper/types/progressStepper.type';
import { EpoInfoFormData } from 'pages/patentDetails/types/EpoInfoFormData';

export interface EPDetailsStoreState {
    init: () => void;
    subscribe: (setState: (value: EpoInfoFormData) => void) => Subscription;
    updateFormData: (value: EpoInfoFormData) => void;
    getData: () => EpoInfoFormData;
    initialState: EpoInfoFormData;
    resetStore: () => void;
}

export const initialEPInfoState: EpoInfoFormData = {
    applicantName: '',
    id: '',
    kind: '',
    patentApplicationNumber: '',
    patentPublicationDate: null,
    patentPublicationNumber: '',
    sourceLanguage: '',
    statutoryDeadline: null,
    title: '',
    titleDe: '',
    titleFr: '',
    validationDeadLine: null,
    validationDeadLineUP: null,
    descriptionWordCount: null,
    numberOfClaims: null,
    claimWordCount: null,
    descriptionPageCount: null,
    claimsPageCount: null,
    drawingsPageCount: null
};

let state: EpoInfoFormData = initialEPInfoState;
const subject = new Subject<EpoInfoFormData>();

const epDetailsStore: EPDetailsStoreState = {
    init() {
        state = { ...initialEPInfoState };
        subject.next(state);
    },
    subscribe: (setState) => subject.subscribe(setState),
    updateFormData(value) {
        state = {
            ...value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    initialState: initialEPInfoState,
    resetStore() {
        state = { ...initialEPInfoState };
        subject.next(state);
    }
};

export default epDetailsStore;
