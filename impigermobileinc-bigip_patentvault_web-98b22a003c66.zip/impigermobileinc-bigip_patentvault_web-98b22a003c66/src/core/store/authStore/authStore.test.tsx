import { AuthResponse } from 'pages/login/login';
import AuthStore, { UserInfoModal } from './authStore';
import { jwtDecode } from 'jwt-decode';
import { Permissions } from 'constants/permissions';

describe('AuthStore', () => {
    beforeEach(() => {
        AuthStore.init(); // Reset state before each test
    });

    afterEach(() => {
        jest.clearAllMocks(); // Clear all mocks after each test
    });

    it('initial state should match', () => {
        expect(AuthStore.getUserInfo()).toEqual(AuthStore.getInitialState());
    });

    it('should set user login information', () => {
        const userInfo: UserInfoModal = {
            userInfo: {
                permissions: ['createquote', 'viewquote'],
                userId: 69,
                userFullName: 'PM 5',
                role: 'Project Manager',
                roleId: 2
            },
            expiresOn: 0,
            authToken: '',
            isAuthenticated: true
        };

        const decoded: AuthResponse = jwtDecode(userInfo.authToken);
        AuthStore.setLogin(userInfo.authToken, decoded);

        expect(AuthStore.isAuthenticated()).toBe(true);
        expect(AuthStore.getUserInfo().userInfo.userFullName).toEqual('PM 5');
    });

    it('should check permission correctly', async () => {
        const userInfo: UserInfoModal = {
            userInfo: {
                permissions: ['editquote', 'createquote', 'viewquote'],
                userId: 123,
                userFullName: 'John Doe',
                role: 'admin',
                roleId: 1
            },
            expiresOn: 0,
            authToken: '',
            isAuthenticated: true
        };

        const decoded: AuthResponse = jwtDecode(userInfo.authToken);
        AuthStore.setLogin(userInfo.authToken, decoded);

        await new Promise((r) => setTimeout(r, 100));
        expect(AuthStore.hasPermission(Permissions.EDIT_QUOTE)).toBe(true);
        expect(AuthStore.hasPermission(Permissions.DELETE_QUOTE)).toBe(false);
    });

    it('should clear state on logout', () => {
        const userInfo: UserInfoModal = {
            userInfo: {
                permissions: ['read', 'write'],
                userId: 123,
                userFullName: 'John Doe',
                role: 'admin',
                roleId: 1
            },
            expiresOn: 0,
            authToken: '',
            isAuthenticated: true
        };
        const decoded: AuthResponse = jwtDecode(userInfo.authToken);
        AuthStore.setLogin(userInfo.authToken, decoded);

        expect(AuthStore.isAuthenticated()).toBe(true);

        AuthStore.logout();

        expect(AuthStore.isAuthenticated()).toBe(false);
        expect(AuthStore.getUserInfo()).toEqual(AuthStore.getInitialState());
    });

    it('should emit state changes to subscribers', () => {
        const mockSubscriber = jest.fn();
        AuthStore.subscribe(mockSubscriber);

        const userInfo: UserInfoModal = {
            userInfo: {
                permissions: ['read', 'write'],
                userId: 123,
                userFullName: 'John Doe',
                role: 'admin',
                roleId: 1
            },
            expiresOn: 0,
            authToken: '',
            isAuthenticated: true
        };

        const decoded: AuthResponse = jwtDecode(userInfo.authToken);
        AuthStore.setLogin(userInfo.authToken, decoded);

        expect(mockSubscriber).toHaveBeenCalledTimes(1);

        AuthStore.logout();

        expect(mockSubscriber).toHaveBeenCalledTimes(2);
        expect(mockSubscriber).toHaveBeenCalledWith(AuthStore.getInitialState());
    });
});
