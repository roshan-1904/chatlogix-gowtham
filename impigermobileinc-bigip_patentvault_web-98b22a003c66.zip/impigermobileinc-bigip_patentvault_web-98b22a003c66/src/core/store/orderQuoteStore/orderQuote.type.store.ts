import {
    CountryConfig,
    EpCountriesData,
    SelectCountryDatasetForEdit
} from 'pages/orders/selectCountry/types/country.type';
import {
    Company,
    CompanyDetailsForm,
    ContactUser,
    PatentDetails
} from 'pages/createOrderAndQuote/components/companyDetails/types/companyDetails.type';
import {
    EditFlowData,
    PatentCategories,
    SelectedServiceDetails,
    ServiceAndCategoryType
} from 'pages/createOrderAndQuote/components/serviceType/types/serviceType.type';
import {
    CurrencyResponse,
    SummaryMetaData
} from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import { UploadedDocumentInfo } from 'components/fileUpload/types/fileUpload.types';
import { LanguageSelectionDataItem } from 'pages/createOrderAndQuote/components/standard/languageSelection/types/languageSelection.type';
import {
    DocumentGroupModel,
    STDPageDataModel
} from 'pages/createOrderAndQuote/components/standard/uploadAndLanguageSelection/types/uploadAndLanguageSelection.type';
import { UpcOptOutFormData } from 'pages/createOrderAndQuote/components/epUpcOptOut/epUpcOptOut.types';

export interface QuoteOrderModuleStore {
    info: QuoteOrderModuleStoreInfo;
    flags: Flags;
    isFormValid: BooleanObject;
    formData: QuoteOrderModuleStoreFormData;
    saveAPIResponseData?: APIResponseData;
    editFlowResponseData?: EditFlowData;
    backupDataToCompare?: BackupDataToCompare;
    refs?: RefFunctions;
}
type RefFunctions = {
    [key: string]: (...args: any[]) => void; // Functions can have any arguments and return void
};
export interface QuoteOrderModuleStoreInfo {
    mode: number | null;
    selectedService: ServiceAndCategoryType | null;
    selectedCategory: PatentCategories | null;
    primaryId: number | null;
    documentId: number | null;
    requestCurrencyId: number | null;
    isEditFlow: boolean | null;
    isSTDFlow: boolean | null;
    isUP: boolean | null;
    approveStatus: number | null;
    statusId: number | null;
    serviceUniqueName?: string | null;
    quoteStatus?: number | null;
    isCountOrCountryChanged?: boolean;
    requestNumber?: string | null;
    stdPreviewType?: string | null;
    previewReferenceId?: number | null;
    isBothDecideLater?: boolean | null;
    summaryTargetLanguageID?: string | null;
}
export interface Flags {
    storeUpdateWithSummaryData: string | null;
    isCountriesSyncedCompletedInEditMode: boolean;
    isSummaryPageTablesInlineEditInProgress: boolean;
    pagesMatchStatusWithBackupData: { [key: string]: boolean };
    isBothDecideLaterDisableApprove?: boolean | null;
}
export interface QuoteOrderModuleStoreFormData {
    serviceTypePage: ServiceTypeData | null;
    companyDetailsPage: CompanyDetailsData | null;
    additionalInfoPage: any; // formioData
    patentDetailsPage: any; // formioData
    selectCountryPage: SelectCountryPageMetaData | null;
    selectCountryPageForEP: SelectCountryEPData | null;
    selectCountryPageEdit: SelectCountryDatasetForEdit | null;
    summaryPage: SummaryMetaData | null;
    orderQuoteDetailsPage: any; // formioData
    languageSelectionPage: LanguageSelectionPageData | null;
    uploadAndLanguageSelectionPage: {
        pageData: STDPageDataModel;
        selectedGroup: DocumentGroupModel;
    } | null;
    upcOptOutPage: UpcOptOutFormData | null;
}

export interface APIResponseData {
    currencyList: CurrencyResponse[];
}

export interface BackupDataToCompare {
    companyName: Company | null;
    languages: { [key: string]: string | null };
    counts: { [key: string]: number | null } | null;
    countries: number[] | null;
    selectedCurrency: CurrencyResponse | null;
}

export interface BooleanObject {
    [key: string]: boolean | null;
}

// pages
export interface ServiceTypeData {
    serviceType: ServiceAndCategoryType[] | null;
    selectedServiceDetails: SelectedServiceDetails | null;
}

export interface OrderQuoteDetailsForEdit {
    companyName?: number | null;
    contactUser?: ContactUser | null;
    contactEmail?: string | null;
    title: string | null;
    requestedDeliveryDate: string | null;
    quoteTargetDateTime: string | null;
    poNumber: string | null;
    referenceNumber: string | null;
    deliverTo: string | null;
    quoteRequired: boolean | null;
    cc: string | null;
    projectManager: string | null;
    salesRep: string | null;
    requestCurrency: number | null;
    requestInvoiceStatus: number | boolean | null;
    instructionByContactUser: string | null;
    instructionByProjectManager: string | null;
}
export interface CompanyDetailsData {
    companyList: Company[] | null;
    contactUserList: ContactUser[] | null;
    selectedCompany: Company | null;
    selectedContact: ContactUser | null;
    publicationNumber: string | null;
    patentDetails: PatentDetails | null;
    isFormSubmitting?: boolean;
    formData?: CompanyDetailsForm | null;
}
export interface SelectCountryPageMetaData {
    instantCountries: CountryConfig[] | null;
    customCountries: CountryConfig[] | null;
    isCheckedSelectAllInstantCheckbox: boolean;
    isCheckedSelectAllCustomCheckbox: boolean;
}

export interface SelectCountryEPData {
    countryList: CountryConfig[] | null;
    selectAllChecked: boolean | null;
    selectUpCountryChecked: boolean | null;
    epTranslationAndValidationData?: EpCountriesData | null;
    epUpGrandTotal?: {
        claimsTotal: number;
        epTotal: number;
        upTotal: number;
    };
}

export interface LanguageSelectionPageData {
    uploadedFilesResData: UploadedDocumentInfo[] | null;
    tableData: LanguageSelectionDataItem[] | null;
    savedFilesReceivedInEditMode?: any;
    savedFilesIdsReceivedInEditMode?: number[] | null;
}
