import { Subject, Subscription } from 'rxjs';
import { QuoteOrderModuleStore } from './orderQuote.type.store';
import { PATHS } from 'constants/routes.constant';

export type AllowedQuoteOrderStoreValue =
    | 'info'
    | 'flags'
    | 'isFormValid'
    | 'formData'
    | 'saveAPIResponseData'
    | 'editFlowResponseData'
    | 'backupDataToCompare'
    | 'refs';

interface QuoteOrderModuleStoreType {
    init: () => void;
    subscribe: (setState: (value: QuoteOrderModuleStore) => void) => Subscription;
    updatePage: (field: AllowedQuoteOrderStoreValue, value: any) => void;
    getData: () => QuoteOrderModuleStore;
    resetQuoteOrderStore: (retainThisData?: { mode?: any }) => void;
    registerFunction: (key: string, fn: (...args: any) => void) => void;
    invokeFunction: (key: string, ...args: any) => void;
    initialState: QuoteOrderModuleStore;
}

export const initialQuoteAndOrderState: QuoteOrderModuleStore = {
    info: {
        mode: null,
        selectedService: null,
        selectedCategory: null,
        primaryId: null,
        requestCurrencyId: null,
        requestNumber: null,
        documentId: null,
        isEditFlow: null,
        isSTDFlow: null,
        isUP: null,
        approveStatus: 0,
        statusId: null,
        stdPreviewType: null,
        previewReferenceId: null
    },
    flags: {
        storeUpdateWithSummaryData: null,
        isCountriesSyncedCompletedInEditMode: false,
        isSummaryPageTablesInlineEditInProgress: false,
        pagesMatchStatusWithBackupData: {
            /** this flags will ensure the current pages data matches with backup data(backupDataToCompare) or not.  */
            isCompanyModified: false,
            isLanguagesModified: false,
            isCountsModified: false,
            isCountriesModified: false
        }
    },
    isFormValid: {
        [PATHS.SERVICE_TYPE]: null,
        [PATHS.COMPANY_DETAILS]: null,
        [PATHS.ADDITIONAL_INFO]: null,
        [PATHS.PATENT_DETAILS]: null,
        [PATHS.SELECT_COUNTRY]: null,
        [PATHS.FILE_UPLOAD]: true,
        [PATHS.SUMMARY]: true,
        [PATHS.UPC_OPT_OUT]: null
    },
    formData: {
        // keep all page as 'null' to validate while page navigation
        serviceTypePage: null,
        companyDetailsPage: null,
        additionalInfoPage: null,
        patentDetailsPage: null,
        selectCountryPage: null,
        selectCountryPageEdit: null,
        selectCountryPageForEP: null,
        summaryPage: null,
        orderQuoteDetailsPage: null,
        uploadAndLanguageSelectionPage: null,
        languageSelectionPage: null,
        upcOptOutPage: null
    },
    refs: {}
};

let state = initialQuoteAndOrderState;
const subject = new Subject<QuoteOrderModuleStore>();

const quoteOrderModuleStore: QuoteOrderModuleStoreType = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (setState: (value: any) => void) => subject.subscribe(setState),
    updatePage(field: AllowedQuoteOrderStoreValue, value: any) {
        state = {
            ...state,
            [field]: value
        };
        subject.next(state);
    },
    registerFunction(key: string, fn: (...args: { key: string; value: any }[]) => void) {
        state = {
            ...state,
            refs: {
                ...state.refs,
                [key]: fn
            }
        };
        subject.next(state);
    },
    invokeFunction(key: string, ...args: { key: string; value: any }[]) {
        const func = state.refs?.[key];
        if (func) {
            func(...args);
        } else {
            console.warn(`Something wrong with the function ${key}`);
        }
    },
    getData() {
        return state;
    },
    resetQuoteOrderStore(retainThisData = { mode: state.info.mode }) {
        // while reset the store, keep some data as it is
        const { mode } = retainThisData;

        state = {
            ...initialQuoteAndOrderState,
            info: {
                ...initialQuoteAndOrderState.info,
                mode
            }
        };
        subject.next(state);
    },
    initialState: initialQuoteAndOrderState
};

export default quoteOrderModuleStore;
