import { useEffect } from 'react';
import { redirect, To, useNavigate } from 'react-router-dom';
import { useMsal } from '@azure/msal-react';
import {
    AccountInfo,
    EventMessage,
    EventType,
    InteractionStatus,
    SilentRequest
} from '@azure/msal-browser';
import { b2cPolicies } from 'core/configs/msalConfig';
import AuthStore from 'core/store/authStore/authStore';
import QueryString from 'qs';
// Imported library for decoding JWT tokens
import { jwtDecode } from 'jwt-decode';
import { ROLE } from 'constants/app.constant';
export interface AuthResponse {
    authresp: string;
    isPasswordReset: boolean;
    isForgotPassword: boolean;
    exp: number;
}

function LoginPage() {
    // Access MSAL instance and authentication state
    const { instance, accounts, inProgress } = useMsal();
    // React Router's navigate function
    const navigate = useNavigate();

    useEffect(() => {
        // Function to fetch data silently when component mounts

        function fetchData() {
            const codeRequest: SilentRequest = {
                // Assumes only one account, adjust if needed
                account: accounts[0],
                // Scopes for token request
                scopes: [],
                // Authority for token request
                authority: b2cPolicies.authorities.signUpSignIn.authority
            };
            instance.acquireTokenSilent(codeRequest).catch((error: string) => {
                if (error && !error.includes('AADB2C90077')) {
                    instance.loginRedirect();
                }
            });
        }

        // Function to initiate login redirect when component mounts
        async function loginRedirect() {
            await instance.loginRedirect();
        }

        // Check authentication status and take action accordingly
        if (
            inProgress !== InteractionStatus?.Startup &&
            inProgress !== InteractionStatus?.HandleRedirect &&
            inProgress !== InteractionStatus?.Login
        ) {
            try {
                const token = localStorage.getItem('JwtToken');
                if (token) {
                    const decoded: AuthResponse = jwtDecode(token);
                    checkForTokenErrors(decoded);
                    AuthStore.setLogin(token, decoded);
                    // Redirect to previous page or default route
                    navigate(getRedirectUrl());
                } else if (accounts.length > 0) {
                    // If accounts exist, fetch data
                    fetchData();
                } else {
                    // If no accounts, initiate login redirect
                    loginRedirect();
                }
            } catch (_error) {
                /* empty */
            }
        }
        // Dependencies for useEffect
    }, [instance, accounts, inProgress]);

    // Function to handle logout
    const handleLogout = () => {
        // Clear local storage
        localStorage.clear();
        // Call logout function from AuthStore
        AuthStore.logout();
        // Initiate logout redirect
        instance.logoutRedirect();
    };

    const checkForTokenErrors = (decoded: AuthResponse) => {
        if (decoded.authresp && decoded.authresp.includes('is not available')) {
            redirect('/access-denied');
        }
    };

    const updateUserInformation = (payload: AccountInfo) => {
        // Decode JWT token to get user information
        const decoded: AuthResponse = jwtDecode(payload?.idToken ? payload.idToken : '');

        if (decoded?.isForgotPassword || decoded?.isPasswordReset) {
            instance.logoutRedirect();
            return;
        }

        // Set user login information in AuthStore
        AuthStore.setLogin(payload.idToken ?? '', decoded);

        // Check for token errors.
        checkForTokenErrors(decoded);
    };

    const getRedirectUrl = () => {
        const from = QueryString.parse(window.location.search)?.['?from'] as To;
        let redirectURL = from ? from : (localStorage.getItem('redirectUrl') ?? '/');
        if (redirectURL === '/') {
            const userInfo = AuthStore.getUserInfo().userInfo;
            if (userInfo.roleId === ROLE.VENDOR_SPECIALIST.roleId) {
                redirectURL = '/task-management';
            } else if (userInfo.roleId === ROLE.HR.roleId) {
                redirectURL = '/users';
            } else if (userInfo.roleId === ROLE.VENDOR_HR.roleId) {
                redirectURL = '/users';
            } else {
                redirectURL = '/orders-quotes';
            }
        }

        return redirectURL;
    };

    useEffect(() => {
        if (!instance?.addEventCallback) {
            console.warn('MSAL instance is missing addEventCallback');
            return;
        }
        // Add event callback to handle MSAL events
        const callbackId = instance.addEventCallback((event: EventMessage) => {
            if (
                (event.eventType === EventType.LOGIN_SUCCESS ||
                    event.eventType === EventType.ACQUIRE_TOKEN_SUCCESS) &&
                event.payload &&
                event.payload
            ) {
                const payload = event.payload as AccountInfo;
                updateUserInformation(payload);
                // Remove 'authInProgress' from local storage
                localStorage.removeItem('authInProgress');
                // Redirect user to the previous page or default route

                // Redirect to previous page or default route
                navigate(getRedirectUrl());
            } else if (
                event.eventType === EventType.LOGIN_FAILURE ||
                event.eventType === EventType.ACQUIRE_TOKEN_FAILURE
            ) {
                if (event?.error) {
                    // If login fails, initiate logout redirect
                    handleLogout();
                }
            } else {
                // Handle other MSAL events if needed
            }
        });

        // Cleanup function to remove event callback when component unmounts
        return () => {
            if (callbackId) {
                instance.removeEventCallback(callbackId);
                instance.removePerformanceCallback(callbackId);
            }
        };
        // eslint-disable-next-line
        // Dependency for useEffect
    }, [instance, navigate]);

    return (
        <div data-testid="Login" className="hidden">
            {/* Logout button */}
            <button
                data-testid="logout"
                onClick={() => handleLogout()}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                tabIndex={0}
                className="btn font-medium text-secondary flex items-center">
                <i className="pi pi-sign-out w-4" />
                <span className="">{'LOGOUT'}</span>
            </button>
        </div>
    );
}

export default LoginPage;
