import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useMsal } from '@azure/msal-react';
import { ROLE } from 'constants/app.constant';
import AuthStore from 'core/store/authStore/authStore';
import LoginPage from './login';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';

// Mocking dependencies
jest.mock('@azure/msal-react', () => ({
    __esModule: true,
    useMsal: jest.fn() // mock it explicitly as a function
}));
jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn()
}));
jest.mock('jwt-decode');
jest.mock('core/store/authStore/authStore');

describe('LoginPage Component', () => {
    const mockNavigate = jest.fn();
    const mockAcquireTokenSilent = jest.fn();
    const mockLoginRedirect = jest.fn();
    const mockLogoutRedirect = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();

        // Mock useNavigate hook
        (useNavigate as jest.Mock).mockReturnValue(mockNavigate);

        // Mock useMsal hook
        (useMsal as jest.Mock).mockReturnValue({
            instance: {
                acquireTokenSilent: mockAcquireTokenSilent,
                loginRedirect: mockLoginRedirect,
                logoutRedirect: mockLogoutRedirect,
                addEventCallback: jest.fn(),
                removeEventCallback: jest.fn()
            },
            accounts: [{ username: 'testUser' }],
            inProgress: 'none'
        });
    });

    test.skip('should trigger login redirect if no token exists', async () => {
        localStorage.clear(); // Ensure no token is present

        render(<LoginPage />);

        await waitFor(() => {
            expect(mockLoginRedirect).toHaveBeenCalledTimes(1);
        });
    });

    test('should decode token and navigate to correct URL', () => {
        // Mock the token decoding process
        const mockDecodedToken = {
            authresp: '',
            isPasswordReset: false,
            isForgotPassword: false,
            exp: 999999999
        };
        localStorage.setItem('JwtToken', 'fakeToken');
        (jwtDecode as jest.Mock).mockReturnValue(mockDecodedToken);
        AuthStore.getUserInfo = jest.fn().mockReturnValue({
            userInfo: { roleId: ROLE.VENDOR_SPECIALIST.roleId }
        });

        // Render component
        render(<LoginPage />);

        // Verify the token is decoded and navigation occurs
        expect(jwtDecode).toHaveBeenCalledWith('fakeToken');
        expect(mockNavigate).toHaveBeenCalledWith('/task-management');
    });

    test('should call handleLogout and clear storage', () => {
        // Mock the logout function from AuthStore
        AuthStore.logout = jest.fn();

        // Render component
        render(<LoginPage />);

        // Find the logout button and simulate click
        const logoutButton = screen.getByTestId('logout');
        fireEvent.click(logoutButton);

        // Verify localStorage is cleared and logout is called
        waitFor(() => {
            expect(localStorage.clear).toHaveBeenCalled();
            expect(AuthStore.logout).toHaveBeenCalledTimes(1);
            expect(mockLogoutRedirect).toHaveBeenCalled();
        });
    });
    test('should not trigger login redirect if token is valid', () => {
        const mockDecodedToken = {
            exp: Math.floor(Date.now() / 1000) + 3600 // 1 hour in the future
        };
        localStorage.setItem('JwtToken', 'validToken');
        (jwtDecode as jest.Mock).mockReturnValue(mockDecodedToken);
        AuthStore.getUserInfo = jest.fn().mockReturnValue({
            userInfo: { roleId: ROLE.ADMIN.roleId }
        });

        render(<LoginPage />);
        expect(mockLoginRedirect).not.toHaveBeenCalled();
    });
});
