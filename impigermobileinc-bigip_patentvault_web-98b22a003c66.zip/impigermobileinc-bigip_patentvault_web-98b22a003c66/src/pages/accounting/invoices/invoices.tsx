import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useEffect, useState } from 'react';
import vendorProfileIcon from 'assets/svgs/vendor-profile.svg';
import { END_POINT } from 'constants/endPoint';
import { PATHS } from 'constants/routes.constant';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { formatDate, fxRateTemplate, isContactUser, showToastMessage } from 'core/utils/utils';
import { t } from 'i18next';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { getInvoicesList, resyncInvoiceAll, resyncInvoiceByID } from '../service/invoice.service';
import { getInvoiceTableColumnSchema, InvoiceTableColumnKeys } from '../tableSchema/invoice.schema';
import { InvoicesDataItem } from '../types';
import { DataTableSelectEvent } from 'primereact/datatable';
import { Permissions } from 'constants/permissions';
import AuthStore from 'core/store/authStore/authStore';
import ProgressStatusIndicator from 'shared/dataTable/components/progressStatusIndicator/progressStatusIndicator';
import LinkNavigation from 'pages/components/linkNavigation/linkNavigation';

function AccountingInvoices() {
    const userInfo = AuthStore.getUserInfo();
    const loggedInUserRoleId = userInfo.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);

    const isAccount: boolean =
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE);
    const [tableData, setTableData] = useState<InvoicesDataItem[]>([]);
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.ACCOUNTING_INVOICES_COLUMN_ORDERS;
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 2,
        totalRecords: 20
    });

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const isShowResync = AuthStore.hasPermission(Permissions.RESYNC_INVOICE);
    useEffect(() => {
        fetchInvoiceList();
    }, [requestBody]);

    const fetchInvoiceList = async () => {
        try {
            const response = await getInvoicesList(requestBody);
            setTableData(response?.requestInvoiceService);
            setPaginationInfo({
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            });
        } catch (error) {
            console.error(error);
        }
    };

    const renderDueDateCell = (rowData: InvoicesDataItem) => {
        const dueDate = new Date(rowData.dueDate);
        const currentDate = new Date();
        dueDate.setHours(0, 0, 0, 0);
        currentDate.setHours(0, 0, 0, 0);
        const isDateCrossDue = dueDate < currentDate;

        return (
            <div className={!isDateCrossDue ? 'text-black' : 'text-red-500'}>
                {rowData.dueDate ? formatDate(rowData.dueDate) : '-'}
            </div>
        );
    };

    const renderVendorCell = (rowData: InvoicesDataItem) => {
        return (
            <div className="flex md:items-center">
                <img
                    src={vendorProfileIcon}
                    alt=""
                    data-testid="profile-icon"
                    className="h-[1.13rem] mt-[0.18rem] mr-1"
                />
                <span className="ml-1">{rowData?.accountExecutive}</span>
            </div>
        );
    };

    const renderInvoiceNumber = ({ id, invoiceNumber }: InvoicesDataItem) => {
        return (
            <LinkNavigation
                text={invoiceNumber}
                url={`/${isAccount ? PATHS.ACCOUNT_INVOICES : PATHS.INVOICES}/details/${id}`}
            />
        );
    };
    // const renderCustomLeftHeaderSection = () => {
    //     return (
    //         <TableFilterHeaderSection
    //             onChangeFilter={() => {}}
    //             syncStatusOptions={[
    //                 { label: 'All', value: '1' },
    //                 { label: 'Inprogress', value: '2' },
    //                 { label: 'Success', value: '3' },
    //                 { label: 'Fail', value: '4' }
    //             ]}
    //         />
    //     );
    // };

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // Function for Export
    function exportData() {
        try {
            const exportURL = `${END_POINT.ACCOUNTING.EXPORT_INVOICE_LIST}`;
            SettingsService.exportData(requestBody, exportURL, 'invoice_lists.xlsx');
        } catch (error) {
            console.error(error);
            showToastMessage({
                type: ToastType.ERROR,
                message: t('COMPANIES.ERROR_MESSAGE.EXPORT_COMPANIES_LIST')
            });
        }
    }
    const renderReSync = (rowData: InvoicesDataItem) => {
        const isValidShow: boolean =
            rowData.sageStatusSyncName === 'Failed' || rowData.sageStatusSyncName === 'Error';
        const handleReSyncClick = (e: React.MouseEvent) => {
            e.stopPropagation();
            resyncInvoiceByID((rowData?.requestId as number) || 0)
                .then((response) => {
                    if (response) {
                        fetchInvoiceList();
                    }
                })
                .catch((error) => {
                    console.error(error);
                });
        };
        return (
            <div style={{ display: 'flex', width: '100%' }}>
                <div style={{ width: '100%' }}>
                    <ProgressStatusIndicator
                        syncStatus={rowData?.sageStatusSyncName}
                        sageSyncError={JSON.parse(rowData.sageSyncDetails)}
                    />
                </div>
                {isValidShow && isShowResync && (
                    <button
                        style={{ width: '100%', textAlign: 'left' }}
                        onClick={(e) => {
                            handleReSyncClick(e);
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                        <i className="pi pi-refresh" />
                    </button>
                )}
            </div>
        );
    };

    const exchangeRateTemplate = (rowData: InvoicesDataItem) => {
        return <div>{fxRateTemplate(rowData.exchangeRate as number)}</div>;
    };

    const columnSchema: ColumnDefinition[] = getInvoiceTableColumnSchema(
        {
            invoiceNumber: renderInvoiceNumber,
            dueDate: renderDueDateCell,
            accountExecutive: renderVendorCell,
            renderReSync,
            exchangeRate: exchangeRateTemplate
        },
        isAccount
    );
    const updatedColumnSchema = columnSchema.map((column) => {
        if (column.field === InvoiceTableColumnKeys.STATUS.toString()) {
            return {
                ...column,
                tooltip: {
                    isShow: isThisContactUser,
                    uniqueColumnName: InvoiceTableColumnKeys.INVOICE_NUMBER,
                    content: t('ACCOUNTING.BILLING_STATUS_TOOLTIP_CONTACT_USER'),
                    className: ''
                }
            };
        } else return column;
    });
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.ACCOUNTING_INVOICES_TABLE,
        reOrderableColumns: true,
        columns: updatedColumnSchema,
        emptyMessage: '',
        filters: {},
        localStorageKey: storageKey,
        // leftHeaderSection: renderCustomLeftHeaderSection(),
        title: 'Invoices',
        showResync: AuthStore.hasPermission(Permissions.RESYNC_INVOICE),
        hideTableExport: AuthStore.hasPermission(Permissions.DOWNLOAD_INVOICE)
    };
    const onRowClicked = (e: DataTableSelectEvent) => {
        if (e?.data?.id) {
            window.location.href = `/${isAccount ? PATHS.ACCOUNT_INVOICES : PATHS.INVOICES}/details/${e.data.id}`;
        }
    };
    const onClickResync = () => {
        resyncInvoiceAll();
    };
    return (
        <div data-testid="InvoiceSection">
            <div data-testid="InvoiceTableSection" className="p-4 pb-0">
                <DataTableComponent
                    tableData={tableData}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    handleFilter={handleFilter}
                    handleSort={sortHandler}
                    toggleRowData={() => {}}
                    tablePaginationData={paginationInfo}
                    handlePagination={handlePageChange}
                    exportData={exportData}
                    onRowClicked={onRowClicked}
                    onClickReSync={onClickResync}
                />
            </div>
        </div>
    );
}

export default AccountingInvoices;
