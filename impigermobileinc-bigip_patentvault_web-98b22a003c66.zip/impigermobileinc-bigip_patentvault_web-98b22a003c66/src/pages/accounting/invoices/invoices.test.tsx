import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import AccountingInvoices from './invoices'; // Adjust the path as necessary
import { getInvoicesList } from '../service/invoice.service';
import { useLocation } from 'react-router-dom';

// Mock the necessary imports
jest.mock('../service/invoice.service', () => ({
    getInvoicesList: jest.fn()
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn()
}));

jest.mock('shared/dataTable/dataTable', () => jest.fn(() => <div>DataTableComponent</div>));

describe('AccountingInvoices', () => {
    const mockInvoices = {
        requestInvoiceService: [
            {
                id: 1,
                dueDate: '2024-08-30',
                invoiceNumber: 'INV-001',
                accountExecutive: 'John Doe'
            }
        ],
        pageNo: 1,
        totalPages: 1,
        totalRecords: 1
    };

    beforeEach(() => {
        jest.clearAllMocks();
        (useLocation as jest.Mock).mockReturnValue({ pathname: '/accounting/invoices' });
        (getInvoicesList as jest.Mock).mockResolvedValue(mockInvoices);
    });

    it('should render the component', () => {
        render(<AccountingInvoices />);

        expect(screen.getByTestId('InvoiceSection')).toBeInTheDocument();
    });

    it('should fetch and display invoices', async () => {
        render(<AccountingInvoices />);

        await waitFor(() => {
            expect(getInvoicesList).toHaveBeenCalledWith(expect.any(Object));
        });
        const invoiceListPage = screen.getByTestId('InvoiceSection');
        expect(invoiceListPage).toBeInTheDocument();
        expect(getInvoicesList).toHaveBeenCalledTimes(1);
    });

    it('should render invoice number as a link', async () => {
        render(<AccountingInvoices />);

        await waitFor(() => {
            expect(getInvoicesList).toHaveBeenCalledWith(expect.any(Object));
        });
        const invoiceLink = screen.getByTestId('InvoiceTableSection');
        expect(invoiceLink).toBeInTheDocument();
    });

    it('should handle page change', async () => {
        render(<AccountingInvoices />);
        await waitFor(() => {
            expect(getInvoicesList).toHaveBeenCalledTimes(1);
        });
        fireEvent.click(screen.getByTestId('InvoiceTableSection'));
        await waitFor(() => {
            expect(getInvoicesList).toHaveBeenCalledTimes(1);
        });
    });
});
