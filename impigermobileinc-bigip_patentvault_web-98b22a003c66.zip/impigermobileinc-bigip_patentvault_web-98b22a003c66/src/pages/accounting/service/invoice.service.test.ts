import HttpService from 'core/interceptor/api.handler';
import * as invoiceService from './invoice.service';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getCompanyData', () => {
        const requestBody = {
            searchModels: [],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        };
        it('should fetch getCompanyData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await invoiceService.getInvoicesList(requestBody);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(invoiceService.getInvoicesList(requestBody)).rejects.toThrow(mockError);
        });
    });

    describe('getInvoiceDetails', () => {
        const id = '1';
        it('should fetch getInvoiceDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await invoiceService.getInvoiceDetails(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(invoiceService.getInvoiceDetails(id)).rejects.toThrow(mockError);
        });
    });
});
