import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { ArPaymentDetails, ArPaymentListResponse } from '../types';
import utils, {
    formatDateYYMMDD,
    listReqBodyWithFilterOperator,
    showToastMessage,
    toggleLoadingIndicator
} from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { t } from 'i18next';
import axios from 'axios';
import AuthStore from 'core/store/authStore/authStore';

const _httpService = new HttpService();
const pvBaseURL = process.env.REACT_APP_API_BASE_URL;

const getArPaymentList = async (requestBody: RequestBody): Promise<ArPaymentListResponse> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_AR_PAYMENT_LIST}`;
        const response = await _httpService.post<ArPaymentListResponse, RequestBody>(
            apiUrl,
            listReqBodyWithFilterOperator(requestBody)
        );
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const getArPaymentDetails = async (recordNo: string): Promise<ArPaymentDetails> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_AR_PAYMENT_DETAILS}/?recordNo=${recordNo}`;
        const response = await _httpService.get<ArPaymentDetails>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching payment details:', error);
        throw error;
    }
};

const sageSyncArPaymentList = async (): Promise<void> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.SAGE_SYNC_AR_PAYMENT_LIST}`;
        const response = await _httpService.post<void, undefined>(apiUrl, undefined);
        showToastMessage({
            type: ToastType.SUCCESS,
            message: t('PAYMENTS.PAYMENT_SYNCED_SUCCESSFULLY')
        });
        return response;
    } catch (error) {
        console.error('Error syncing payment list with Sage:', error);
        throw error;
    }
};

const exportArPaymentList = async (requestBody: RequestBody): Promise<void> => {
    try {
        const apiUrl = `${pvBaseURL}/${END_POINT.ACCOUNTING.EXPORT_AR_PAYMENT_LIST}`;
        const token = AuthStore.getUserInfo().authToken || '';
        toggleLoadingIndicator(true);
        const response = await axios.post(apiUrl, listReqBodyWithFilterOperator(requestBody), {
            responseType: 'arraybuffer',
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        // Check if the response is an array buffer
        if (response.data instanceof ArrayBuffer) {
            // Create a Blob from the binary data
            const blob = new Blob([response.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });
            utils.downloadBlob(
                blob,
                `AR-Payments_${formatDateYYMMDD(new Date().toISOString())}.xlsx`
            );
            toggleLoadingIndicator(false);
            showToastMessage({
                type: ToastType.SUCCESS,
                message: t('COMMON.EXPORT_SUCCESSFULLY')
            });
        } else {
            toggleLoadingIndicator(false);
            throw new Error('Response is not an array buffer');
        }
    } catch (error) {
        toggleLoadingIndicator(false);
        console.error('Error exporting payment list:', error);
        throw error;
    }
};

export const arPaymentService = {
    getArPaymentList,
    getArPaymentDetails,
    sageSyncArPaymentList,
    exportArPaymentList
};
