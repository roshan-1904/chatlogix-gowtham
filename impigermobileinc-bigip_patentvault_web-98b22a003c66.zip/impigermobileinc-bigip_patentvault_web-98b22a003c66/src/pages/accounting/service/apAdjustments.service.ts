import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { ApAdjustmentDetails, ApAdjustmentListResponse, SyncDetailsType } from '../types';
import utils, {
    formatDateYYMMDD,
    listReqBodyWithFilterOperator,
    showToastMessage,
    toggleLoadingIndicator
} from 'core/utils/utils';
import axios from 'axios';
import AuthStore from 'core/store/authStore/authStore';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { t } from 'i18next';

const _httpService = new HttpService();
const pvBaseURL = process.env.REACT_APP_API_BASE_URL;

const getApAdjustmentList = async (requestBody: RequestBody): Promise<ApAdjustmentListResponse> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_AP_ADJUSTMENT_LIST}`;
        const response = await _httpService.post<ApAdjustmentListResponse, RequestBody>(
            apiUrl,
            listReqBodyWithFilterOperator(requestBody)
        );
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const getApAdjustmentDetails = async (recordNo: string): Promise<ApAdjustmentDetails> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_AP_ADJUSTMENT_DETAILS}?recordNo=${recordNo}`;
        const response = await _httpService.get<ApAdjustmentDetails>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const exportApAdjustmentList = async (requestBody: RequestBody): Promise<void> => {
    try {
        const apiUrl = `${pvBaseURL}/${END_POINT.ACCOUNTING.EXPORT_AP_ADJUSTMENT_LIST}`;
        const token = AuthStore.getUserInfo().authToken || '';
        toggleLoadingIndicator(true);
        const response = await axios.post(apiUrl, listReqBodyWithFilterOperator(requestBody), {
            responseType: 'arraybuffer',
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        // Check if the response is an array buffer
        if (response.data instanceof ArrayBuffer) {
            // Create a Blob from the binary data
            const blob = new Blob([response.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });

            utils.downloadBlob(
                blob,
                `AP-Adjustments_${formatDateYYMMDD(new Date().toISOString())}.xlsx`
            );
            toggleLoadingIndicator(false);
            showToastMessage({
                type: ToastType.SUCCESS,
                message: t('COMMON.EXPORT_SUCCESSFULLY')
            });
        } else {
            toggleLoadingIndicator(false);
            throw new Error('Response is not an array buffer');
        }
    } catch (error) {
        toggleLoadingIndicator(false);
        console.error('Error exporting adjustment list:', error);
        throw error;
    }
};

const sageSyncApAdjustmentList = async (): Promise<void> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.SAGE_SYNC_AP_ADJUSTMENT_LIST}`;
        const response = await _httpService.post<void, undefined>(apiUrl, undefined);
        showToastMessage({
            type: ToastType.SUCCESS,
            message: t('ADJUSTMENTS.ADJUSTMENT_SYNCED_SUCCESSFULLY')
        });
        return response;
    } catch (error) {
        console.error('Error syncing adjustment list with Sage:', error);
        throw error;
    }
};

const getSyncDetails = async (): Promise<SyncDetailsType[]> => {
    try {
        const apiUrl = `${END_POINT.COMMON.GET_AR_LAST_SYNC_DATE}`;
        const response = await _httpService.get<SyncDetailsType[]>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching sync details:', error);
        throw error;
    }
};

export const apAdjustmentService = {
    getApAdjustmentList,
    getApAdjustmentDetails,
    exportApAdjustmentList,
    sageSyncApAdjustmentList,
    getSyncDetails
};
