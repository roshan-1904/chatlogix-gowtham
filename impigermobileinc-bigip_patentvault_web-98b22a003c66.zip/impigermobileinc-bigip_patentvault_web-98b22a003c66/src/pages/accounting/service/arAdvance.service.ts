import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { ArAdvanceDetails, ArAdvanceListResponse } from '../types';
import AuthStore from 'core/store/authStore/authStore';
import utils, {
    listReqBodyWithFilterOperator,
    showToastMessage,
    toggleLoadingIndicator
} from 'core/utils/utils';
import axios from 'axios';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { t } from 'i18next';

const _httpService = new HttpService();
const pvBaseURL = process.env.REACT_APP_API_BASE_URL;

const getArAdvanceList = async (requestBody: RequestBody): Promise<ArAdvanceListResponse> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_AR_ADVANCE_LIST}`;
        const response = await _httpService.post<ArAdvanceListResponse, RequestBody>(
            apiUrl,
            listReqBodyWithFilterOperator(requestBody)
        );
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const exportArAdvanceList = async (requestBody: RequestBody): Promise<void> => {
    try {
        const apiUrl = `${pvBaseURL}/${END_POINT.ACCOUNTING.EXPORT_AR_ADVANCE_LIST}`;
        const token = AuthStore.getUserInfo().authToken || '';
        toggleLoadingIndicator(true);
        const response = await axios.post(apiUrl, listReqBodyWithFilterOperator(requestBody), {
            responseType: 'arraybuffer',
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        // Check if the response is an array buffer
        if (response.data instanceof ArrayBuffer) {
            // Create a Blob from the binary data
            const blob = new Blob([response.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });

            utils.downloadBlob(blob, `${'AR-Advances' + new Date().toISOString() + '.xlsx'}`);
            toggleLoadingIndicator(false);
            showToastMessage({
                type: ToastType.SUCCESS,
                message: t('COMMON.EXPORT_SUCCESSFULLY')
            });
        } else {
            toggleLoadingIndicator(false);
            throw new Error('Response is not an array buffer');
        }
    } catch (error) {
        toggleLoadingIndicator(false);
        console.error('Error exporting advance list:', error);
        throw error;
    }
};

const sageSyncArAdvanceList = async (): Promise<void> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.SAGE_SYNC_AR_ADVANCE_LIST}`;
        const response = await _httpService.post<void, undefined>(apiUrl, undefined);
        showToastMessage({
            type: ToastType.SUCCESS,
            message: t('ADVANCES.ADVANCE_SYNCED_SUCCESSFULLY')
        });
        return response;
    } catch (error) {
        console.error('Error syncing advance list with Sage:', error);
        throw error;
    }
};

const getArAdvanceDetails = async (recordNo: string): Promise<ArAdvanceDetails> => {
    const apiUrl = `${END_POINT.ACCOUNTING.GET_AR_ADVANCE_DETAILS}?recordNo=${recordNo}`;
    try {
        const response = await _httpService.get<ArAdvanceDetails>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching advance details:', error);
        throw error;
    }
};

export const advanceService = {
    getArAdvanceList,
    exportArAdvanceList,
    sageSyncArAdvanceList,
    getArAdvanceDetails
};
