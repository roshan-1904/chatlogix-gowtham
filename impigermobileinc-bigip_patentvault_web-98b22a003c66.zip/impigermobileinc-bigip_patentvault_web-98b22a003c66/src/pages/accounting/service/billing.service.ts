import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { BillingListResponseModel } from '../types';
import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
const _httpService = new HttpService();
const getBillingList = async (requestBody: RequestBody): Promise<BillingListResponseModel> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_BILL_LIST}`;
        try {
            const response = await _httpService.post<BillingListResponseModel, RequestBody>(
                apiUrl,
                requestBody
            );
            return response;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const getBillingDetails = async <T>(id: string): Promise<T> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_BILL_DETAILS}/${id}`;
        try {
            const response = await _httpService.get<T>(apiUrl);
            return response;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

const resetVendorInvoiceNumber = async <T>(id: number): Promise<T> => {
    const apiUrl = `${END_POINT.ACCOUNTING.RESET_VENDOR_INVOICE_NUMBER}/${id}`;
    try {
        const response = await _httpService.post<T, number>(apiUrl, id);
        return response;
    } catch (error) {
        console.error('Error resetting vendor invoice number:', error);
        throw error;
    }
};

const resyncBillingByID = async <T>(id: number): Promise<T> => {
    try {
        const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}/task/${END_POINT.ACCOUNTING.SYNC_BILLID}/${id}`;
        try {
            const response = await _httpService.post<T, number>(apiUrl, id);
            return response;
        } catch (error) {
            console.error('Error resync:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error resync:', error);
        throw error;
    }
};

const resyncBillingAll = async <T>(): Promise<T> => {
    const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}/task/${END_POINT.ACCOUNTING.SYNC_BILLALL}`;
    try {
        const requestBody = {
            searchModels: [],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        };
        const response = await _httpService.post<T, RequestBody>(apiUrl, requestBody);
        if (response) {
            await getBillingList(requestBody);
        }
        return response;
    } catch (error) {
        console.error('Error in Resync:', error);
        throw error;
    }
};

/**
 * Fetches the source documents for the given order/quote ID.
 * @param id - The ID of the  Order/Quote to get source documents.
 * @returns {Promise<T>} A promise resolving to the source documents data.
 */
const getVendorInvoiceDocuments = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.VENDOR_INVOICE_DOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching source documents:', error);
        throw error;
    }
};

const saveVendorInvoiceNumber = async <T>(
    id: number,
    payload: { vendorInvoiceNo: string }
): Promise<T> => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.SAVE_VENDOR_INVOICE_NUMBER}/${id}`;
    try {
        const response = await _httpService.post<T, { vendorInvoiceNo: string }>(apiUrl, payload);
        return response;
    } catch (error) {
        console.error('Error fetching source documents:', error);
        throw error;
    }
};

export {
    getBillingList,
    getBillingDetails,
    resyncBillingByID,
    resyncBillingAll,
    getVendorInvoiceDocuments,
    saveVendorInvoiceNumber,
    resetVendorInvoiceNumber
};
