import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { InvoicesListResponseModel } from '../types';
import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
const _httpService = new HttpService();
const getInvoicesList = async (requestBody: RequestBody): Promise<InvoicesListResponseModel> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_INVOICE_LIST}`;
        try {
            const response = await _httpService.post<InvoicesListResponseModel, RequestBody>(
                apiUrl,
                requestBody
            );
            return response;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};
const getInvoiceDetails = async <T>(id: string): Promise<T> => {
    try {
        const apiUrl = `${END_POINT.ACCOUNTING.GET_INVOICE_DETAILS}/${id}`;
        try {
            const response = await _httpService.get<T>(apiUrl);
            return response;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};
const resyncInvoiceByID = async <T>(id: number): Promise<T> => {
    try {
        const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}/order/${END_POINT.ACCOUNTING.SYNC_INVOICEID}/${id}`;
        try {
            const response = await _httpService.post<T, number>(apiUrl, id);
            return response;
        } catch (error) {
            console.error('Error resync:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error resync:', error);
        throw error;
    }
};
const resyncInvoiceAll = async <T>(): Promise<T> => {
    try {
        const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}/order/${END_POINT.ACCOUNTING.SYNC_INVOICEALL}`;
        try {
            const requestBody = {
                searchModels: [],
                sorting: {
                    propertyName: '',
                    value: ''
                },
                pageNo: 1,
                pageCount: 10
            };
            const response = await _httpService.post<T, RequestBody>(apiUrl, requestBody);
            return response;
        } catch (error) {
            console.error('Error resync:', error);
            throw error;
        }
    } catch (error) {
        console.error('Error resync:', error);
        throw error;
    }
};
export { getInvoicesList, getInvoiceDetails, resyncInvoiceByID, resyncInvoiceAll };
