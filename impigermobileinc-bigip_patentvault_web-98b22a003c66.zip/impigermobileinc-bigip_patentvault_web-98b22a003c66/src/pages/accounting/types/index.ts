import { VendorInvoiceDocumentsData } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

export const BillingKeys = {
    searchId: '',
    sortby: '',
    status: '',
    syncStatus: []
};

export interface BillingFilterKeysType {
    searchId: string;
    sortby: string;
    status: string;
    syncStatus: string[];
}

export interface BillingFilterProps {
    onChangeFilter?: (filterValue: BillingFilterKeysType, key: string) => void;
    syncStatusOptions?: Array<any>;
}

export interface BillingsDataItem {
    sageSyncDetails: string;
    id: number;
    billNo: string;
    requestNumber: string;
    billDate: string;
    dueDate: string;
    status: string;
    vendorName: string;
    vendorId: string;
    isvendorDocument: boolean;
    sageSyncStatus: number;
    sageSyncDate: string;
    sageSyncError: Array<{
        errorCode: string;
        message: string;
    }>;
    sageStatusSyncName: string;
    sageInvoice: string;
    sageAmount: string;
    updatedAt: string;
    billingTerm: string;
    billAmount: string;
    currencySymbol?: string;
    requestCurrencySymbol?: string;
    companyName: string;
    vendorDocuments: VendorInvoiceDocumentsData[];
}

export interface BillDetails {
    id: number;
    title: string;
    billStatusId: string;
    billNo: string;
    currencySymbol: string;
    sageStatus: string;
    status: string;
    glPostingDate: string;
    sageSyncStatus: string;
    sageSyncDate: string;
    sageSyncError: Array<{
        errorCode: string;
        message: string;
    }>;
    sageSyncStatusName: string;
    dueDate: string;
    billDate: string;
    lastSyncedDate: string;
    billAmount: string;
    isWTFeeWaived: boolean;
    priorityPay: boolean;
    billOnHoldEnabled: boolean;
    paymentNotes: string;
    vendorDetails: {
        id: string;
        fullName: string;
        email: string;
        phoneNumber: string;
        billingTerms: string;
        company: string;
        paymentMethod: string;
        taxId: string;
        billingAddress: string;
        vendorCompany: string;
        sageId: string;
        ptPayPaypalVeem: string;
    };
    taskDetails: Array<TaskDetails>;
    ptPayPaypalVeem: string;
    vendorPreferredCurrency: string;
    taxFormName: string;
    billingTerms: string;
    ccRecipients: string;
    billingEmail: string;
    isSameAddress: boolean;
    patentAppNumber: string;
    billingAddress: {
        address1?: string;
        address2?: string;
        billingEmail?: string;
        ccRecipients?: string;
        city?: string;
        countryId?: string;
        countryName?: string;
        isSameAddress?: string;
        state?: string;
        stateId?: string;
        zip?: string;
    };
    sageAmount?: string;
    isvendorDocument: boolean;
    vendorInvoiceNumber?: string;
    transacationPaidAmount: string;
    transacationBalanceAmount: string;
}

export interface TaskDetails {
    id?: number;
    expenseAccountNo?: string;
    billAmount?: string;
    accountingDeptId?: string;
    taskDescription?: string;
    recipient?: string;
    refNo?: string;
    taskId?: string;
    sourceLanguage?: string;
    targetLanguage?: string;
    targetCountry?: string;
    unit?: string;
    taskName?: string;
    sageAmount: string;
    fxRate?: string;
    taskCurrencySymbol?: string;
    taskRequestedCurrencySymbol?: string;
    sageSyncDate?: string;
    taskAmount: string | number | null;
    orderId?: number | null;
    IsStdOrder?: boolean | null;
}

export interface BillingListResponseModel {
    requestBillService: BillingsDataItem[];
    pageNo: number;
    totalRecords: number;
    totalPages: number;
}

export interface BillingDetailsResponseModel {
    requestBillService: BillDetails;
}

export interface InvoicesListResponseModel {
    requestInvoiceService: InvoicesDataItem[];
    pageNo: number;
    totalRecords: number;
    totalPages: number;
}
export interface InvoicesDataItem {
    sageSyncDetails: string;
    id: number;
    invoiceNumber: string;
    title: string;
    invoiceDate: string;
    companyName: string;
    accountExecutive: string;
    requestNumber: string;
    dueDate: string;
    billingTerms: string;
    poNumber: string;
    sageStatus: string;
    sageStatusSyncName: string;
    amount: string;
    currencySymbol: string;
    sageInvoice: number;
    vendorName?: string;
    status?: string;
    requestId?: number;
    referenceNumber?: string;
    invoiceToContact?: string;
    exchangeRate?: number;
    transactionAmountPaid: number;
    transactionBalanceAmount: number;
    isDocumentUploaded: string;
}

export interface InvoiceTasks {
    id: number;
    taskNo: string;
    taskDisplayId: string;
    taskName: string;
    description: string;
    sourceLanguage: string;
    translationLanguage: string;
    unit: string;
    sageSyncStatus: string;
    sageSyncDate: string;
    sageSyncError: Array<{
        errorCode: string;
        message: string;
    }>;
    sageStatusSyncName: string;
    quantity: number;
    rate: number;
    sageInvoice: number;
    sageAmount: number;
    fxRate: number;
    taskCurrencySymbol?: string;
    amount: string;
    invoiceToContact?: string;
}
export interface InvoiceDetailsData extends InvoicesDataItem {
    taskDetails: InvoiceTasks[];
}
export interface InvoiceDetailsResponseModel {
    data: InvoiceDetailsData;
    pageNo?: number;
    totalRecords?: number;
    totalPages?: number;
}

export interface ArAdjustmentList {
    recordNo: string;
    adjustmentNumber: string;
    adjustmentDate: string;
    adjustmentType: string;
    adjustmentTotal: string;
    adjustmentStatus: string;
    referenceInvoiceNo: string;
    customerName: string;
    transactionCurrency: string;
    transactionCurrencySymbol: string;
    transactionCurrencyBalance: number;
    transactionCurrencyPaid: number;
    transactionCurrencyTotal: number;
    isDocumentUploaded: string;
    createdAt: string;
    updatedAt: string;
}

export interface ArAdjustmentListResponse {
    arAdjustmentList: ArAdjustmentList[];
    totalCount: number;
}

export interface ArAdjustmentDetails {
    adjustmentType: string;
    adjustmentNumber: string;
    referenceInvoiceNo: string;
    vendorCurrency: string;
    departmentIdAndName: string;
    adjustmentDate: string;
    glPostingDate: string;
    exchangeRate: string;
    transactionCurrencyAmount: number;
    amountInUsd: string;
    adjustmentStatus: string;
    paidAmount: string;
    adjustmentBalance: number;
    description: string;
    adjustmentTotal: number;
    vendorCurrencySymbol: string;
    transactionCurrencyPaid: number;
    transactionCurrencyBalance: number;
    customerName: string;
    isDocumentUploaded: string;
    entries: {
        glAccountNumber: string;
        glAccountName: string;
        accountTitle: string;
        departmentId: string;
        transactionCurrencyAmount: number;
        baseCurrencyAmount: number;
        memo: string;
    }[];
}

export interface ArPaymentList {
    recordNo: string;
    paymentNumber: string;
    paymentMethod: string;
    paymentDate: string;
    transactionCurrency: string;
    transactionPaymentAmount: string;
    exchangeRate: string;
    paymentAmount: string;
    creditsApplied: string;
    paymentInUsd: string;
    lastSyncedDate: string;
    createdAt: string;
    updatedAt: string;
}

export interface ArPaymentListResponse {
    arPaymentList: ArPaymentList[];
    totalCount: number;
}

export interface ArPaymentDetails {
    recordNo: string;
    paymentNumber: string;
    paymentMethod: string;
    paymentDate: string;
    company: string;
    transactionCurrency: string;
    transactionPaymentAmount: string;
    exchangeRateValue: string;
    paymentAmount: string;
    receiptDate: string;
    paymentStatus: string;
    description: string;
    transactionCurrencySymbol: string;
    invoiceEntries: Entries[];
    creditEntries: Entries[];
    advanceEntries: Entries[];
}

export interface Entries {
    invoiceNumber: string;
    customerName: string;
    date: string;
    dueDate: string;
    transactionAmount: number;
    exchangeRate: string;
    creditsApplied: string;
    totalPaidAmount: string;
    totalCredits: string;
    availableCredits: string;
}

export interface ArAdvanceList {
    advanceId: string;
    paymentMethod: string;
    paymentDate: string;
    receiptDate: string;
    companyName: string;
    transactionCurrency: string;
    transactionCurrencySymbol: string;
    transactionPaymentAmount: number;
    exchangeRateValue: string;
    paymentAmount: number;
    glPostingDate: string;
    status: string;
    summary: string;
    totalPaid: string;
    totalDue: string;
    isDocumentUploaded: string;
    createdOn: string;
    modifiedOn: string;
}
export interface ArAdvanceListResponse {
    arAdvanceList: ArAdvanceList[];
    totalCount: number;
}

export interface ArAdvanceDetails {
    advanceNumber: string;
    paymentMethod: string;
    paymentDate: string;
    receiptDate: string;
    companyName: string;
    transactionCurrency: string;
    transactionCurrencySymbol: string;
    transactionPaymentAmount: number;
    exchangeRateValue: string;
    paymentAmount: number;
    totalPaid: string;
    totalDue: string;
    glPostingDate: string;
    status: string;
    summary: string;
    isDocumentUploaded: string;
}

export interface SyncDetailsType {
    lastSyncDate: string;
    id: number;
    name: string;
    prefixId: string | null;
    value: string | null;
}

export interface ApPaymentList {
    totalCount: number;
    paymentNo: string;
    batchNo: string;
    paymentAmount: number;
    paidAmount: number;
    paymentDate?: string | Date;
    vendorName: string;
    vendorId: string;
    paymentType: string;
    status: string;
    currencySymbol: string;
    documentNumber: string;
    batchId: number;
    isDocumentRequired: boolean;
    isDownloadRequired: boolean;
    isDocumentNoMandatory: boolean;
    sageSyncStatus: number;
    sageSyncStatusName: string;
    batchDocumentNumber: string;
    transactionCurrencyPaidAmount: number;
    voidDate: string;
    recordNo: string;
}

export interface ApPaymentListResponse {
    paymentList: ApPaymentList[];
    totalCount: number;
}
export interface ApPaymentDetails {
    paymentNumber: string;
    paymentMethod: string;
    paymentDate: string;
    vendorName: string;
    vendorId: string;
    transactionCurrency: string;
    transactionPaymentAmount: number;
    exchangeRateValue: number;
    paymentAmount: number;
    receiptDate: string;
    paymentStatus: string;
    description: string;
    transactionCurrencySymbol: string;
    billEntries: BillEntry[];
    creditEntries: Entries[];
}

export interface BillEntry {
    billNumber: string;
    vendorName: string;
    dueDate: string;
    transactionAmount: number;
    exchangeRate: number;
    paymentAmount: number;
    creditsApplied: number;
    totalPaidAmount: number;
    totalCredits: number;
    availableCredits: number;
}

export interface ApAdjustmentList {
    totalCount: number;
    recordNo: string;
    adjustmentNo: string;
    referenceBillNo: string;
    adjustmentDate: string;
    adjustmentType: string;
    adjustmentStatus: string;
    adjustmentTotal: number;
    paidAmount: number;
    adjustmentBalance: number;
    paymentMethod: string;
    sageSyncStatus: any;
    sageSyncStatusName: string;
    sageSyncDetails: string;
    vendorName: string;
    glPostingDate: string;
    transactionCurrencyTotal: number;
    transactionCurrencyPaid: number;
    transactionCurrencyBalance: number;
    vendorCurrencySymbol: string;
}

export interface ApAdjustmentListResponse {
    adjustmentList: ApAdjustmentList[];
    totalCount: number;
}

export interface ApAdjustmentDetails {
    adjustmentNo: string;
    applicationId: number;
    departmentId: string;
    departmentIdAndName: string;
    adjustmentType: string;
    adjustmentTypeName: string;
    adjustmentTotal: number;
    adjustmentStatus: string;
    vendorName: string;
    vendorId: string;
    adjustmentDate: string;
    glPostingDate: string;
    referenceBillNo: string;
    transactionCurrencyAmount: number;
    baseCurrencyAmount: number;
    description: string;
    exchangeRate: number;
    vendorCurrencySymbol: string;
    vendorCurrency: string;
    baseCurrency: string;
    baseCurrencySymbol: string;
    exchangeRateDate: string;
    sageSyncStatusName: string;
    transactionCurrency: string;
    sageSyncDetails: string;
    paidAmount: number;
    adjustmentBalance: number;
    transactionCurrencyPaid: number;
    transactionCurrencyBalance: number;
    entries: {
        glAccountNumber: string;
        departmentId: string;
        transactionAmount: number;
        amount: number;
        memo: string;
        glAccountName: string;
    }[];
}
