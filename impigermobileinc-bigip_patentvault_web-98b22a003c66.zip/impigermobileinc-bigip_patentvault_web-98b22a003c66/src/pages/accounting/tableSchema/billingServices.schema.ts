import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { convertToValidNumber, isVendorSpecialistUser } from 'core/utils/utils';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';

export enum BillingServicesTableColumnKeys {
    TASK_ID = 'taskId',
    TASK_NAME = 'taskName',
    TASK_AMOUNT = 'taskAmount',
    ACCOUNTING_DEPT_ID = 'accountingDeptId',
    VENDOR_REFERENCE_NUMBER = 'vendorReferenceNumber',
    SOURCE_LANGUAGE = 'sourceLanguage',
    TARGET_LANGUAGE = 'targetLanguage',
    TARGET_COUNTRY = 'targetCountry',
    UNIT = 'UNIT',
    SAGE_AMOUNT = 'sageAmount',
    FX_RATE = 'fxRate',
    REQUEST_NUMBER = 'requestNumber',
    SYNC_STATUS = 'sageStatusSyncName',
    SYNC_DATE_TIME = 'sageSyncDate',
    QUANTITY = 'quantity',
    RATE = 'rate'
}

enum VendorBillTaskListingRestrictedColumns {
    TASK_AMOUNT = 'taskAmount',
    SYNC_STATUS = 'sageStatusSyncName',
    SYNC_DATE_TIME = 'sageSyncDate'
}

const getBillingServicesTableColumnSchema = (
    customComponent: {
        [key: string]: any;
    },
    isAccounting: boolean = false
): ColumnDefinition[] => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const { roleId } = userDetails.userInfo;
    const isThisVendorSpecialistUser = isVendorSpecialistUser(roleId);

    const columnSchema: ColumnDefinition[] = [
        {
            field: BillingServicesTableColumnKeys.TASK_ID,
            header: 'Task ID',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.TASK_NAME,
            header: `${isThisVendorSpecialistUser ? 'Task Name' : 'Task/Abilities'}`,
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            body: customComponent[BillingServicesTableColumnKeys.TASK_NAME]
        },
        {
            field: BillingServicesTableColumnKeys.VENDOR_REFERENCE_NUMBER,
            header: 'Vendor Ref Number',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true
        },

        {
            field: BillingServicesTableColumnKeys.SOURCE_LANGUAGE,
            header: 'Source Language',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 3,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.TARGET_LANGUAGE,
            header: 'Target Language',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 4,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            visibility: true
        },

        {
            field: BillingServicesTableColumnKeys.TARGET_COUNTRY,
            header: 'Target Country',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'targetCountryFlagName',
            columnNumber: 5,
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.REQUEST_NUMBER,
            header: 'Req.Number',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 6,
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.QUANTITY,
            header: 'Quantity',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 7,
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.RATE,
            header: 'Rate',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            body: (rowData: any) =>
                convertToValidNumber({
                    value: rowData?.rate ?? 0,
                    decimalLength: 4,
                    renderAs: 'string'
                }),
            columnNumber: 8,
            visibility: true,
            currencySymbolDataKey: 'taskCurrencySymbol'
        },
        {
            field: BillingServicesTableColumnKeys.TASK_AMOUNT,
            header: 'Total Vendor Currency',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 9,
            visibility: true,
            currencySymbolDataKey: 'taskCurrencySymbol'
        },
        {
            field: BillingServicesTableColumnKeys.SAGE_AMOUNT,
            header: isAccounting ? 'Sage Bill Amount' : 'Bill Amount',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 9,
            visibility: true,
            currencySymbolDataKey: 'taskCurrencySymbol'
        },
        {
            field: BillingServicesTableColumnKeys.SYNC_STATUS,
            header: 'Sync Status',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.ProgressStatusIndicator,
            columnNumber: 11,
            visibility: true
        },
        {
            field: BillingServicesTableColumnKeys.SYNC_DATE_TIME,
            header: 'Sync Date-Time',
            sortable: false,
            filter: false,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 12,
            visibility: true
        }
    ];
    return isAccounting
        ? columnSchema
        : columnSchema.filter(
              (schemaDetail: ColumnDefinition) =>
                  !(Object.values(VendorBillTaskListingRestrictedColumns) as string[]).includes(
                      schemaDetail.field
                  )
          );
};

export { getBillingServicesTableColumnSchema };
