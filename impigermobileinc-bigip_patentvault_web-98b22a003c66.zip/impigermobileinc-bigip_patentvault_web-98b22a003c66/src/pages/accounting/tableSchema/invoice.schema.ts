import { YES_NO_LIST_BOOL } from 'constants/app.constant';
import { t } from 'i18next';
import { ReactNode } from 'react';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';

export enum InvoiceTableColumnKeys {
    INVOICE_NUMBER = 'invoiceNumber',
    INVOICE_DATE = 'invoiceDate',
    COMPANY_NAME = 'companyName',
    TITLE = 'title',
    ACCOUNT_EXECUTIVE = 'accountExecutive',
    REFERENCE_NUMBER = 'referenceNumber',
    REQUEST_NUMBER = 'requestNumber',
    DUE_DATE = 'dueDate',
    BILLING_TERMS = 'billingTerms',
    SAGE_SYNC_STATUS_NAME = 'sageStatusSyncName',
    STATUS = 'sageStatus',
    TOTAL_AMOUNT = 'amount',
    SAGE_INVOICE_AMOUNT = 'sageInvoice',
    RESYNC_DATA = 'resyncData',
    SAGE_SYNC_DATE = 'sageSyncDate',
    TRANSACTION_CURRENCY = 'transactionCurrency',
    TRANSACTION_AMOUNT = 'transactionAmount',
    EXCHANGE_RATE = 'exchangeRate',
    TOTAL_AMOUNT_PAID_USD = 'totalAmountPaid',
    BALANCE_AMOUNT_USD = 'balanceAmount',
    PO_NUMBER = 'poNumber',
    CONTACT_EMAIL = 'contactEmail',
    DESCRIPTION = 'description',
    GL_POSTING_DATE = 'glPostingDate',
    CREATED_AT = 'createdAt',
    UPDATED_AT = 'updatedAt',
    ATTACHMENTS = 'isDocumentUploaded'
}

enum ContactInvoiceListingRestrictedColumns {
    SAGE_SYNC_STATUS_NAME = 'sageStatusSyncName',
    TOTAL_AMOUNT = 'amount',
    SAGE_SYNC_DATE = 'sageSyncDate',
    TRANSACTION_CURRENCY = 'transactionCurrency',
    TRANSACTION_AMOUNT = 'transactionAmount',
    EXCHANGE_RATE = 'exchangeRate',
    TOTAL_AMOUNT_PAID_USD = 'totalAmountPaid',
    BALANCE_AMOUNT_USD = 'balanceAmount',
    PO_NUMBER = 'poNumber',
    CONTACT_EMAIL = 'contactEmail',
    DESCRIPTION = 'description',
    GL_POSTING_DATE = 'glPostingDate',
    CREATED_AT = 'createdAt',
    UPDATED_AT = 'updatedAt'
}

export const getInvoiceTableColumnSchema = (
    customComponent: {
        [key: string]: (data: any) => ReactNode;
    },
    isAccounting: boolean = false
) => {
    const columnSchema: ColumnDefinition[] = [
        {
            field: InvoiceTableColumnKeys.INVOICE_NUMBER,
            header: t('ACCOUNTING.INVOICE_NO'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Link,
            columnNumber: 0,
            visibility: true,
            body: customComponent[InvoiceTableColumnKeys.INVOICE_NUMBER],
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: InvoiceTableColumnKeys.COMPANY_NAME,
            header: t('ACCOUNTING.CUSTOMER'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.INVOICE_DATE,
            header: t('ACCOUNTING.INVOICE_DATE'),
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: 2,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.TITLE,
            header: t('ACCOUNTING.TITLE'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.ACCOUNT_EXECUTIVE,
            header: t('ACCOUNTING.ACCOUNT_EXECUTIVE'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true,
            body: customComponent[InvoiceTableColumnKeys.ACCOUNT_EXECUTIVE]
        },
        {
            field: InvoiceTableColumnKeys.REQUEST_NUMBER,
            header: t('ACCOUNTING.REQUEST_NUMBER'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 5,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.REFERENCE_NUMBER,
            header: t('ACCOUNTING.REFERENCE_NUMBER'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 6,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.DUE_DATE,
            header: t('ACCOUNTING.DUE_DATE'),
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: 7,
            visibility: true,
            body: customComponent[InvoiceTableColumnKeys.DUE_DATE]
        },
        {
            field: InvoiceTableColumnKeys.TRANSACTION_CURRENCY,
            header: t('ACCOUNTING.TRANSACTION_CURRENCY'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 14,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.TRANSACTION_AMOUNT,
            header: t('ACCOUNTING.TRANSACTION_AMOUNT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 15,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: InvoiceTableColumnKeys.EXCHANGE_RATE,
            header: t('ACCOUNTING.EXCHANGE_RATE'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 16,
            visibility: true,
            body: customComponent[InvoiceTableColumnKeys.EXCHANGE_RATE]
        },
        {
            field: InvoiceTableColumnKeys.TOTAL_AMOUNT_PAID_USD,
            header: t('ACCOUNTING.TOTAL_PAID'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 17,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: InvoiceTableColumnKeys.BALANCE_AMOUNT_USD,
            header: t('ACCOUNTING.BALANCE_AMOUNT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 18,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: InvoiceTableColumnKeys.PO_NUMBER,
            header: t('ACCOUNTING.PO_NUMBER'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 19,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.BILLING_TERMS,
            header: t('ACCOUNTING.TERM'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 8,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.SAGE_SYNC_STATUS_NAME,
            header: t('ACCOUNTING.SYNC_STATUS'),
            sortable: false,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.ProgressStatusIndicator,
            columnNumber: 9,
            visibility: true,
            body: customComponent['renderReSync'],
            filterDropDownOptions: [
                {
                    label: t('COMMON.SUCCESS'),
                    value: 'Success'
                },
                {
                    label: t('COMMON.IN_PROGRESS'),
                    value: 'InProgress'
                },
                {
                    label: t('COMMON.FAILED'),
                    value: 'Error'
                }
            ]
        },
        {
            field: InvoiceTableColumnKeys.STATUS,
            header: t('ACCOUNTING.STATUS'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 10,
            visibility: isAccounting,
            body: customComponent[InvoiceTableColumnKeys.STATUS]
        },
        {
            field: InvoiceTableColumnKeys.SAGE_SYNC_DATE,
            header: t('ACCOUNTING.SYNCED_DATE_TIME'),
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.DateTime,
            columnNumber: 11,
            visibility: isAccounting
        },
        {
            field: InvoiceTableColumnKeys.SAGE_INVOICE_AMOUNT,
            header: isAccounting ? t('ACCOUNTING.SAGE_INVOICE') : t('ACCOUNTING.INVOICE_AMOUNT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 12,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: InvoiceTableColumnKeys.TOTAL_AMOUNT,
            header: t('ACCOUNTING.TOTAL'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 13,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: InvoiceTableColumnKeys.CONTACT_EMAIL,
            header: t('ACCOUNTING.CONTACT_EMAIL'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 20,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.GL_POSTING_DATE,
            header: t('ACCOUNTING.GL_POSTING_DATE'),
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: 22,
            visibility: true
        },
        {
            field: InvoiceTableColumnKeys.ATTACHMENTS,
            header: t('COMMON.ATTACHMENTS'),
            columnNumber: 23,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: YES_NO_LIST_BOOL,
            valueType: ValueType.Text
        },
        {
            field: InvoiceTableColumnKeys.CREATED_AT,
            header: t('COMMON.CREATED_AT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 24,
            visibility: isAccounting
        },
        {
            field: InvoiceTableColumnKeys.UPDATED_AT,
            header: t('COMMON.UPDATED_AT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 25,
            visibility: isAccounting
        }
    ];

    return isAccounting
        ? columnSchema
        : columnSchema.filter(
              (schemaDetail: ColumnDefinition) =>
                  !(Object.values(ContactInvoiceListingRestrictedColumns) as string[]).includes(
                      schemaDetail.field ?? ''
                  )
          );
};
