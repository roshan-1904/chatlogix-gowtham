import { convertToValidNumber } from 'core/utils/utils';
import { taskTitleTemplate } from 'pages/taskManagement/tasksList/tasksList';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';

export enum InvoiceServicesTableColumnKeys {
    TASK_ID = 'taskNo',
    TASK_Name = 'taskName',
    TASK_DESCRIPTION = 'taskDescription',
    S_LANGUAGE = 'sourceLanguage',
    T_LANGUAGE = 'targetLanguage',
    UNIT = 'unit',
    SAGE_SYNC_STATUS = 'sageSyncStatus',
    SAGE_SYNC_STATUS_NAME = 'sageStatusSyncName',
    SAGE_SYNC_DATE = 'sageSyncDate',
    QUANTITY = 'quantity',
    RATE = 'rate',
    SAGE_INVOICE = 'sageInvoice',
    FX_RATE = 'fxRate',
    INVOICE_AMOUNT = 'amount',
    TARGET_COUNTRY = 'targetCountry'
}

const getInvoiceServicesTableColumnSchema = (isContactUser: boolean = false) => {
    const columnSchema: ColumnDefinition[] = [
        {
            field: InvoiceServicesTableColumnKeys.TASK_ID,
            header: isContactUser ? 'ID' : 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'taskName',
            header: isContactUser ? 'Service' : 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            body: taskTitleTemplate,
            valueType: ValueType.MultiSelect,
            columnNumber: 1,
            visibility: true
        },
        {
            field: InvoiceServicesTableColumnKeys.TASK_DESCRIPTION,
            header: isContactUser ? 'Description' : 'Item/Description',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            valueType: ValueType.Status,
            columnNumber: 3,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 4,
            visibility: true
        },
        {
            field: InvoiceServicesTableColumnKeys.TARGET_COUNTRY,
            header: 'T.Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'targetCountryFlagName',
            columnNumber: 5,
            visibility: true
        },
        {
            field: InvoiceServicesTableColumnKeys.UNIT,
            header: 'Unit',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 5,
            visibility: isContactUser ? false : true
        },
        {
            field: InvoiceServicesTableColumnKeys.QUANTITY,
            header: 'Quantity',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 6,
            visibility: isContactUser ? false : true
        },
        {
            field: InvoiceServicesTableColumnKeys.RATE,
            header: 'Rate',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 7,
            body: (rowData: any) =>
                convertToValidNumber({
                    value: rowData?.rate ?? 0,
                    decimalLength: 4,
                    renderAs: 'string'
                }),
            visibility: isContactUser ? false : true,
            currencySymbolDataKey: 'taskCurrencySymbol'
        },
        {
            field: InvoiceServicesTableColumnKeys.FX_RATE,
            header: 'Fx Rate',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 8,
            visibility: isContactUser ? false : true
        },
        {
            field: InvoiceServicesTableColumnKeys.INVOICE_AMOUNT,
            header: isContactUser ? 'Amount' : 'Invoice Amount',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: 9,
            visibility: true,
            currencySymbolDataKey: 'taskCurrencySymbol'
        }
    ];
    return columnSchema;
};

export { getInvoiceServicesTableColumnSchema };
