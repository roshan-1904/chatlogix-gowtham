import { ROLE } from 'constants/app.constant';
import AuthStore from 'core/store/authStore/authStore';
import { t } from 'i18next';
import { ReactNode } from 'react';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';

export enum BillingTableColumnKeys {
    BILL_NO = 'billNo',
    REQUEST_NUMBER = 'requestNumber',
    BILL_DATE = 'billDate',
    DUE_DATE = 'dueDate',
    VENDOR = 'vendorName',
    VENDORDOCUMENTS = 'vendorDocuments',
    VENDOR_ID = 'vendorId',
    SAGE_SYNC_STATUS_NAME = 'sageStatusSyncName',
    SAGE_SYNC_DATE = 'sageSyncDate',
    BILLING_TERM = 'billingTerms',
    BILL_AMOUNT = 'billAmount',
    SAGE_AMOUNT = 'sageAmount',
    STATUS = 'sageStatus',
    COMPANY_NAME = 'companyName',
    RESYNC_DATA = 'resyncData',
    PT_PAYPAL_VEEM = 'ptPayPaypalVeem',
    VENDOR_COMPANY = 'vendorCompany',
    VENDOR_INVOICE_DOCUMENTS = 'vendorInvoiceDocuments',
    VENDOR_INVOICE_SUBMITTED = 'isvendorDocument',
    VENDOR_INVOICE_NUMBER = 'vendorInvoiceNumber',
    TASK_ID = 'billsTaskId',
    VENDOR_REFERENCE_NUMBER = 'vendorReferenceNumber',
    TRANSACTION_PAID_AMOUNT = 'transacationPaidAmount',
    TRANSACTION_BALANCE_AMOUNT = 'transacationBalanceAmount'
}

enum VendorBillListingRestrictedColumns {
    SAGE_SYNC_STATUS_NAME = 'sageStatusSyncName',
    SAGE_SYNC_DATE = 'sageSyncDate',
    BILL_AMOUNT = 'billAmount',
    // STATUS = 'sageStatus',
    PT_PAYPAL_VEEM = 'ptPayPaypalVeem',
    VENDOR_COMPANY = 'vendorCompany',
    RESYNC_DATA = 'resyncData'
}

const vendorName = [
    ROLE.VENDOR_SPECIALIST.role,
    // ROLE.VENDOR_ADMIN.role,
    // ROLE.VENDOR_PROJECT_MANAGER.role,
    ROLE.VENDOR_HR.role,
    ROLE.VENDOR_FINANCE.role,
    ROLE.VENDOR_SALES_REP.role
    // ROLE.VENDOR_PROJECT_COORDINATOR.role
];

const getFilteredColumnSchema = (
    columnSchema: ColumnDefinition[],
    userRole: string
): ColumnDefinition[] => {
    switch (userRole) {
        case 'Vendor Specialist':
            return columnSchema.filter(
                (item) =>
                    item.field !== BillingTableColumnKeys.VENDOR_ID.toString() &&
                    item.field !== BillingTableColumnKeys.VENDOR.toString() &&
                    item.field !== BillingTableColumnKeys.COMPANY_NAME.toString()
            );
        case 'Project Manager':
            return columnSchema.filter(
                (item) => item.field !== BillingTableColumnKeys.VENDOR.toString()
            );
        default:
            if (vendorName.includes(userRole)) {
                return columnSchema.filter(
                    (item) => item.field !== BillingTableColumnKeys.COMPANY_NAME.toString()
                );
            }
            return columnSchema;
    }
};

const generateBillingTableColumnSchema = (
    customComponent: {
        [key: string]: (data: any) => ReactNode;
    },
    isAccounting: boolean = false,
    isBillsPermission: boolean = false
): ColumnDefinition[] => {
    let columnNumber = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: BillingTableColumnKeys.BILL_NO,
            header: 'Bill No',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Link,
            columnNumber: columnNumber++,
            visibility: true,
            body: customComponent[BillingTableColumnKeys.BILL_NO],
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: BillingTableColumnKeys.BILL_DATE,
            header: 'Bill Date',
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.VENDOR_INVOICE_NUMBER,
            header: 'Vendor Invoice Number',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.REQUEST_NUMBER,
            header: 'Request Number',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.COMPANY_NAME,
            header: 'Company Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.STATUS,
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: columnNumber++,
            visibility: isAccounting || isBillsPermission,
            // cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border',
            body: customComponent[BillingTableColumnKeys.STATUS]
        },
        {
            field: BillingTableColumnKeys.VENDOR_ID,
            header: 'Vendor ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.VENDOR,
            header: 'Vendor Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true,
            body: customComponent[BillingTableColumnKeys.VENDOR]
        },
        {
            field: BillingTableColumnKeys.VENDOR_COMPANY,
            header: 'Vendor Company',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: isAccounting
        },
        {
            field: BillingTableColumnKeys.DUE_DATE,
            header: 'Due Date',
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: columnNumber++,
            visibility: true,
            body: customComponent[BillingTableColumnKeys.DUE_DATE]
        },
        {
            field: BillingTableColumnKeys.BILLING_TERM,
            header: 'Term',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.SAGE_SYNC_STATUS_NAME,
            header: 'Sync Status',
            sortable: false,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.ProgressStatusIndicator,
            columnNumber: columnNumber++,
            visibility: true,
            body: customComponent['renderReSync'],
            filterDropDownOptions: [
                {
                    label: 'Success',
                    value: 'Success'
                },
                {
                    label: 'In Progress',
                    value: 'InProgress'
                },
                {
                    label: 'Failed',
                    value: 'Error'
                }
            ]
        },
        {
            field: BillingTableColumnKeys.SAGE_SYNC_DATE,
            header: 'Synced Date & Time',
            sortable: true,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.DateTime,
            columnNumber: columnNumber++,
            visibility: isAccounting
        },
        {
            field: BillingTableColumnKeys.PT_PAYPAL_VEEM,
            header: 'PT/Paypal/VeemID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: isAccounting
        },
        {
            field: BillingTableColumnKeys.SAGE_AMOUNT,
            header: isAccounting ? 'Sage Amount' : 'Bill Amount',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: columnNumber++,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: BillingTableColumnKeys.BILL_AMOUNT,
            header: 'Bill Amount',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: columnNumber++,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: BillingTableColumnKeys.TASK_ID,
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.VENDOR_REFERENCE_NUMBER,
            header: 'Vendor Ref Number',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: BillingTableColumnKeys.TRANSACTION_PAID_AMOUNT,
            header: t('ACCOUNTING.PAID_AMOUNT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: columnNumber++,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: BillingTableColumnKeys.TRANSACTION_BALANCE_AMOUNT,
            header: t('ACCOUNTING.BALANCE_AMOUNT'),
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: columnNumber++,
            visibility: true,
            currencySymbolDataKey: 'currencySymbol'
        },
        {
            field: BillingTableColumnKeys.VENDOR_INVOICE_SUBMITTED,
            header: 'Vendor Invoice Submitted',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.YesOrNo,
            columnNumber: columnNumber++,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Yes',
                    value: 'yes'
                },
                {
                    label: 'No',
                    value: 'no'
                }
            ]
        },
        {
            field: BillingTableColumnKeys.VENDOR_INVOICE_DOCUMENTS,
            header: 'Vendor Invoice Documents',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Currency,
            columnNumber: columnNumber++,
            visibility: true,
            body: customComponent['vendorDocuments']
        }
    ];

    const userRole = AuthStore.getUserInfo().userInfo.role;
    const filteredColumnSchema = getFilteredColumnSchema(columnSchema, userRole);

    return isAccounting
        ? filteredColumnSchema
        : filteredColumnSchema.filter(
              (schemaDetail: ColumnDefinition) =>
                  !(Object.values(VendorBillListingRestrictedColumns) as string[]).includes(
                      schemaDetail.field ?? ''
                  )
          );
};

export { generateBillingTableColumnSchema };
