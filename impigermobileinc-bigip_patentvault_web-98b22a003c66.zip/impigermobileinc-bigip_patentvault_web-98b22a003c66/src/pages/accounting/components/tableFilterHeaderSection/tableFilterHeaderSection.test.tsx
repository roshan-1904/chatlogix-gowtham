import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { TableFilterHeaderSection } from './tableFilterHeaderSection';
import { BillingKeys } from '../../types';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: jest.fn((key) => key)
    })
}));

describe('TableFilterHeaderSection', () => {
    const mockOnChangeFilter = jest.fn();
    const mockSyncStatusOptions = [
        { label: 'Synced', value: 'synced' },
        { label: 'Pending', value: 'pending' },
        { label: 'Failed', value: 'failed' }
    ];

    beforeEach(() => {
        render(
            <TableFilterHeaderSection
                onChangeFilter={mockOnChangeFilter}
                syncStatusOptions={mockSyncStatusOptions}
            />
        );
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders the search input', () => {
        const searchInput = screen.getByTestId('search-input');
        expect(searchInput).toBeInTheDocument();
    });

    test('renders the sort by dropdown', () => {
        const sortByDropdown = screen.getByTestId('sort-by-dropdown');
        expect(sortByDropdown).toBeInTheDocument();
    });

    test('renders the sync status dropdown', () => {
        const syncStatusDropdown = screen.getByTestId('sync-status-dropdown');
        expect(syncStatusDropdown).toBeInTheDocument();
    });

    test('calls onChangeFilter when search input changes', () => {
        const searchInput = screen.getByTestId('search-input');
        fireEvent.change(searchInput, { target: { value: '123' } });

        expect(mockOnChangeFilter).toHaveBeenCalledWith(
            { ...BillingKeys, searchId: '123' },
            'searchId'
        );
    });

    test('clears all filters when clear button is clicked', () => {
        const clearButton = screen.getByTestId('clear-filter-button');
        fireEvent.click(clearButton);
        waitFor(() => {
            expect(mockOnChangeFilter).toHaveBeenCalledWith(BillingKeys, 'clear');
        });
    });
});
