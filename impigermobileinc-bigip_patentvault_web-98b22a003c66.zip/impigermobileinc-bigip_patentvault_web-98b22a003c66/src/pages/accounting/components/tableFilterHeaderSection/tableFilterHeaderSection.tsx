import { useTranslation } from 'react-i18next';
import { BillingFilterKeysType, BillingFilterProps, BillingKeys } from '../../types';
import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
import { useState } from 'react';
import { filterDropDownStyle } from 'constants/styles.constant';
import clearIcon from 'assets/images/clear-icon.svg';

export const TableFilterHeaderSection = ({
    onChangeFilter = () => {},
    syncStatusOptions = []
}: BillingFilterProps) => {
    const { t } = useTranslation();
    const [sortBy, setSortBy] = useState<string | null>(null);
    const [syncStatus, setSyncStatus] = useState<string[] | null>(null);
    const [filterChange, setFilterChange] = useState<BillingFilterKeysType>(BillingKeys);

    const handleFilter = (value: any, key: string) => {
        let updatedFilterValue: BillingFilterKeysType = { ...filterChange };
        if (key === 'sortby') {
            updatedFilterValue =
                value !== undefined
                    ? { ...filterChange, sortby: value }
                    : { ...filterChange, sortby: '' };
            value ? setSortBy(value as string) : setSortBy(null);
        }

        if (key === 'searchId') {
            updatedFilterValue = { ...filterChange, searchId: value };
        }

        if (key === 'syncStatus') {
            updatedFilterValue = { ...filterChange, syncStatus: value };
            setSyncStatus(value as string[]);
        }

        setFilterChange(updatedFilterValue);
        onChangeFilter(updatedFilterValue, key);
    };

    const clearFilters = () => {
        setSortBy(null);
        setFilterChange(BillingKeys);
        setSyncStatus([]);
    };

    return (
        <div data-testid="BillingFilterSection" className="flex-1">
            <div className="mt-4 flex justify-between">
                <div className="flex justify-start flex-wrap">
                    <div className="mr-2 mb-2">
                        <label className="input rounded input-bordered h-10 border-[0.02rem] focus-within:outline-none border-neutral-100 focus:border-primary focus-within:border-primary flex items-center gap-2">
                            <i className="pi pi-search text-xs"></i>
                            <input
                                type="text"
                                data-testid="search-input"
                                value={filterChange.searchId}
                                onChange={(e) => handleFilter(e.target.value, 'searchId')}
                                className="grow h-10 font-medium min-w-[250px] text-sm text-black"
                                placeholder={t('TASKS.FILTER.SEARCH_PLACEHOLDER')}
                            />
                        </label>
                    </div>
                    <div className="mr-2 mb-2">
                        <Dropdown
                            filter={true}
                            multiple
                            onChange={(e) => {
                                handleFilter(e.value as string, 'sortby');
                            }}
                            data-testid="sort-by-dropdown"
                            value={sortBy}
                            showClear={true}
                            clearIcon={'pi pi-times'}
                            placeholder="Sort By"
                            valueTemplate={sortBy ? ' Sort By: ' + sortBy : null}
                            pt={{
                                ...filterDropDownStyle,
                                root: {
                                    className:
                                        filterDropDownStyle.root.className +
                                        (sortBy ? ' bg-lightBlue' : '')
                                }
                            }}
                            optionValue="label"
                            options={[
                                { label: 'Deadline - Ascending', value: '1' },
                                { label: 'Deadline - Descending', value: '2' },
                                { label: 'Order Number - Ascending', value: '3' },
                                { label: 'Order Number - Descending', value: '4' }
                            ]}
                        />
                    </div>
                    <div className="mr-2 mb-2">
                        <MultiSelect
                            data-testid="sync-status-dropdown"
                            multiple
                            onChange={(e) => {
                                handleFilter(e.value as string[], 'syncStatus');
                            }}
                            value={syncStatus}
                            showClear={true}
                            clearIcon={'pi pi-times'}
                            placeholder="Sync Status"
                            pt={{
                                ...filterDropDownStyle,
                                root: {
                                    className:
                                        filterDropDownStyle.root.className +
                                        (syncStatus && syncStatus.length > 0 ? ' bg-lightBlue' : '')
                                },
                                item: {
                                    className: 'flex items-center'
                                },
                                checkbox: { root: { className: 'w-4 h-4 rounded-md' } }
                            }}
                            maxSelectedLabels={0}
                            optionLabel="label"
                            optionValue="value"
                            selectedItemsLabel={
                                syncStatus ? `Sync Status: +${syncStatus.length}` : undefined
                            }
                            options={syncStatusOptions}
                        />
                    </div>
                    <div className="mr-2 mb-2">
                        <button
                            onClick={() => {
                                clearFilters();
                            }}
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    clearFilters();
                                }
                            }}
                            data-testid="clear-filter-button"
                            className="h-10 min-h-10 border-0 shadow-none flex items-center justify-center">
                            <img className="pr-2 w-[20px]" src={clearIcon} />{' '}
                            {t('TASKS.CLEAR_FILTER')}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
