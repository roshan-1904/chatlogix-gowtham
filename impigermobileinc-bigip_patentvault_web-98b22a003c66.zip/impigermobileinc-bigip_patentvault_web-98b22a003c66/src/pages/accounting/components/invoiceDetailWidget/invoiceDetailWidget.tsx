import React from 'react';

interface InvoiceDetailsWidgetProps {
    field1Title?: string;
    field1Value?: string;
    field2Title?: string;
    field2Value?: string;
    field3Title?: string;
    field3Value?: string;
    field4Title?: string;
    field4Value?: string | React.ReactNode;
    field1Element?: React.ReactNode;
    field2Element?: React.ReactNode;
    field3Element?: React.ReactNode;
    field4Element?: React.ReactNode;
    fieldValueStyle_1?: string;
    fieldValueStyle_2?: string;
    fieldValueStyle_3?: string;
    fieldValueStyle_4?: string;
}

const Field = ({
    title,
    value,
    dataTestId,
    fieldValueStyle
}: {
    title?: string;
    value?: string | React.ReactNode;
    dataTestId: string;
    fieldValueStyle?: string;
}) => {
    return (
        <div data-testid={dataTestId} className="flex flex-col align-baseline w-6/12">
            {title ? (
                <>
                    <span className="font-normal text-[#484848] text-[13px]">{title}</span>
                    <text className={`font-medium mt-2 text-sm ${fieldValueStyle}`}>
                        {value ?? '-'}
                    </text>
                </>
            ) : (
                ''
            )}
        </div>
    );
};

export const InvoiceDetailsWidget: React.FC<InvoiceDetailsWidgetProps> = ({
    field1Title,
    field1Value,
    field2Title,
    field2Value,
    field3Title,
    field3Value,
    field4Title,
    field4Value,
    field1Element,
    field2Element,
    field3Element,
    field4Element,
    fieldValueStyle_1,
    fieldValueStyle_2,
    fieldValueStyle_3,
    fieldValueStyle_4
}) => {
    return (
        <div data-testid="detailRowSection" className="flex justify-between my-5 gap-8">
            {field1Title ? (
                <Field
                    title={field1Title}
                    value={field1Value}
                    dataTestId="detailsLeftSection"
                    fieldValueStyle={fieldValueStyle_1}
                />
            ) : field1Element ? (
                <div
                    data-testid="detailedField1Element"
                    className="flex flex-col align-baseline w-6/12">
                    {field1Element}
                </div>
            ) : null}

            {field2Title ? (
                <Field
                    title={field2Title}
                    value={field2Value}
                    dataTestId="detailsRightSection"
                    fieldValueStyle={fieldValueStyle_2}
                />
            ) : field2Element ? (
                <div
                    data-testid="detailedField2Element"
                    className="flex flex-col align-baseline w-6/12">
                    {field2Element}
                </div>
            ) : null}

            {field3Element ? (
                <div
                    data-testid="detailedField3Element"
                    className="flex flex-col align-baseline w-6/12">
                    {field3Element}
                </div>
            ) : (
                <Field
                    title={field3Title}
                    value={field3Value}
                    dataTestId="detailsThirdSection"
                    fieldValueStyle={fieldValueStyle_3}
                />
            )}
            {field4Element ? (
                <div
                    data-testid="detailedField2Element"
                    className="flex flex-col align-baseline w-6/12">
                    {field4Element}
                </div>
            ) : (
                <Field
                    title={field4Title}
                    value={field4Value}
                    dataTestId="detailsFourthSection"
                    fieldValueStyle={fieldValueStyle_4}
                />
            )}
        </div>
    );
};
