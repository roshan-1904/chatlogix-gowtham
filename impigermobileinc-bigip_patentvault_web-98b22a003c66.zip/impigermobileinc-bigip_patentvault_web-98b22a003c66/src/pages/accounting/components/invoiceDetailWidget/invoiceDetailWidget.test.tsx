import { render, screen } from '@testing-library/react';
import { InvoiceDetailsWidget } from './invoiceDetailWidget';

describe('InvoiceDetailsWidget', () => {
    it('renders field3Title and field3Value when provided', () => {
        render(<InvoiceDetailsWidget field3Title="Field 3 Title" field3Value="Field 3 Value" />);

        const field3TitleElement = screen.getByText('Field 3 Title');
        const field3ValueElement = screen.getByText('Field 3 Value');

        expect(field3TitleElement).toBeInTheDocument();
        expect(field3ValueElement).toBeInTheDocument();
    });

    it('renders "-" for field3Value when it is not provided', () => {
        render(<InvoiceDetailsWidget field3Title="Field 3 Title" />);

        const field3ValueElement = screen.getByText('-');

        expect(field3ValueElement).toBeInTheDocument();
    });

    it('does not render field3Title when it is not provided', () => {
        render(<InvoiceDetailsWidget field3Value="Field 3 Value" />);

        const field3TitleElement = screen.queryByText('Field 3 Title');

        expect(field3TitleElement).not.toBeInTheDocument();
    });

    it('renders field3Element when provided, overriding field3Title and field3Value', () => {
        render(
            <InvoiceDetailsWidget
                field3Title="Field 3 Title"
                field3Value="Field 3 Value"
                field3Element={<div data-testid="custom-field3">Custom Field 3</div>}
            />
        );

        const customField3Element = screen.getByTestId('custom-field3');
        const field3TitleElement = screen.queryByText('Field 3 Title');
        const field3ValueElement = screen.queryByText('Field 3 Value');

        expect(customField3Element).toBeInTheDocument();
        expect(field3TitleElement).not.toBeInTheDocument();
        expect(field3ValueElement).not.toBeInTheDocument();
    });
});
