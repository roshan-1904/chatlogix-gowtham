export const CustomDetailWidget = ({
    children,
    title
}: {
    children: React.ReactNode;
    title: string;
}) => {
    return (
        <div data-testid="detailsRightSection" className="flex flex-col align-baseline w-6/12">
            <span data-testid="rowf2title" className="font-normal text-[#484848] text-[13px]">
                {title}
            </span>
            <div className="mt-2">{children}</div>
        </div>
    );
};
