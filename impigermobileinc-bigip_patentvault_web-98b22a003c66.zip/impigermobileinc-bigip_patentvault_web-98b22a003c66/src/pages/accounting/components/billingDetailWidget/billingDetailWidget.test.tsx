import { render, screen } from '@testing-library/react';
import { BillingDetailsWidget } from './billingDetailWidget';

describe('BillingDetailsWidget', () => {
    it('should render field2Value when provided', () => {
        render(<BillingDetailsWidget field2Title="Field 2 Title" field2Value="Field 2 Value" />);

        const field2Title = screen.getByTestId('rowf2title');
        const field2Value = screen.getByTestId('rowf2value');

        expect(field2Title).toHaveTextContent('Field 2 Title');
        expect(field2Value).toHaveTextContent('Field 2 Value');
    });

    it('should render "-" when field2Value is not provided', () => {
        render(<BillingDetailsWidget field2Title="Field 2 Title" />);

        const field2Value = screen.getByTestId('rowf2value');

        expect(field2Value).toHaveTextContent('-');
    });

    it('should not render field2 section when field2Title and rightElement are not provided', () => {
        render(<BillingDetailsWidget />);

        const field2Section = screen.queryByTestId('detailsRightSection');

        expect(field2Section).not.toBeInTheDocument();
    });

    it('should render rightElement when provided instead of field2Title and field2Value', () => {
        const rightElement = <div data-testid="customRightElement">Custom Right Element</div>;

        render(<BillingDetailsWidget rightElement={rightElement} />);

        const customRightElement = screen.getByTestId('customRightElement');

        expect(customRightElement).toBeInTheDocument();
        expect(customRightElement).toHaveTextContent('Custom Right Element');
    });
});
