export const BillingDetailsWidget = ({
    field1Title,
    field1Value,
    field2Title,
    field2Value,
    leftElement,
    rightElement,
    fieldValueStyle_1,
    fieldValueStyle_2
}: {
    field1Title?: string;
    field1Value?: string;
    field2Title?: string;
    field2Value?: string;
    leftElement?: React.ReactNode;
    rightElement?: React.ReactNode;
    fieldValueStyle_1?: string;
    fieldValueStyle_2?: string;
}) => {
    return (
        <div data-testid="detailRowSection" className="flex justify-between my-5 gap-5">
            {field1Title ? (
                <div
                    data-testid="detailsLeftSection"
                    className="flex flex-col align-baseline w-6/12">
                    <span
                        data-testid="rowf1title"
                        className="font-normal text-[#484848] text-[13px]">
                        {field1Title}
                    </span>
                    <span
                        data-testid="rowf1value"
                        className={`flex-1 font-medium mt-2 text-sm  + ${fieldValueStyle_1}`}>
                        {field1Value ?? '-'}
                    </span>
                </div>
            ) : leftElement ? (
                leftElement
            ) : null}

            {field2Title ? (
                <div
                    data-testid="detailsRightSection"
                    className="flex flex-col align-baseline w-6/12">
                    <span
                        data-testid="rowf2title"
                        className="font-normal text-[#484848] text-[13px]">
                        {field2Title}
                    </span>
                    <text
                        data-testid="rowf2value"
                        className={`font-medium mt-2 text-sm + + ${fieldValueStyle_2}`}>
                        {field2Value ?? '-'}
                    </text>
                </div>
            ) : rightElement ? (
                rightElement
            ) : null}
        </div>
    );
};
