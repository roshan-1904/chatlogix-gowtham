export const ToggleSwitch = ({
    title = '',
    checked,
    isToggleDisabled = false,
    valueText = null,
    onChange
}: {
    title?: string;
    checked: boolean;
    isToggleDisabled?: boolean;
    valueText?: string | null;
    onChange?: any;
}) => {
    return (
        <div data-testid="detailsRightSection" className="flex items-center gap-3 w-6/12 py-3">
            {title && title !== '' && (
                <text data-testid="rowf2value" className="font-medium text-sm">
                    {title}
                </text>
            )}
            <input
                type="checkbox"
                className="toggle toggle-sm border-2"
                style={{
                    borderColor: checked ? '#1175C2' : '#A4A5A6',
                    backgroundColor: checked ? '#1175C2' : '#A4A5A6'
                }}
                checked={checked}
                onChange={onChange}
                disabled={isToggleDisabled}
            />

            {valueText && valueText !== '' && (
                <text data-testid="row2text" className="text-sm">
                    {valueText}
                </text>
            )}
        </div>
    );
};
