import { render, screen, fireEvent } from '@testing-library/react';
import { ToggleSwitch } from './toggleSwitch';

describe('ToggleSwitch Component', () => {
    it('renders the title when provided', () => {
        render(<ToggleSwitch title="Test Title" checked={false} />);
        expect(screen.getByText('Test Title')).toBeInTheDocument();
    });

    it('does not render the title when not provided', () => {
        render(<ToggleSwitch checked={false} />);
        expect(screen.queryByText('Test Title')).not.toBeInTheDocument();
    });

    it('renders the valueText when provided', () => {
        render(<ToggleSwitch checked={false} valueText="Test Value" />);
        expect(screen.getByText('Test Value')).toBeInTheDocument();
    });

    it('does not render the valueText when not provided', () => {
        render(<ToggleSwitch checked={false} />);
        expect(screen.queryByText('Test Value')).not.toBeInTheDocument();
    });

    it('applies the correct styles when checked is true', () => {
        render(<ToggleSwitch checked={true} />);
        const toggleInput = screen.getByRole('checkbox');
        expect(toggleInput).toHaveStyle('border-color: #1175C2');
        expect(toggleInput).toHaveStyle('background-color: #1175C2');
    });

    it('applies the correct styles when checked is false', () => {
        render(<ToggleSwitch checked={false} />);
        const toggleInput = screen.getByRole('checkbox');
        expect(toggleInput).toHaveStyle('border-color: #A4A5A6');
        expect(toggleInput).toHaveStyle('background-color: #A4A5A6');
    });

    it('calls onChange when toggled', () => {
        const handleChange = jest.fn();
        render(<ToggleSwitch checked={false} onChange={handleChange} />);
        const toggleInput = screen.getByRole('checkbox');
        fireEvent.click(toggleInput);
        expect(handleChange).toHaveBeenCalledTimes(1);
    });

    it('disables the toggle when isToggleDisabled is true', () => {
        render(<ToggleSwitch checked={false} isToggleDisabled={true} />);
        const toggleInput = screen.getByRole('checkbox');
        expect(toggleInput).toBeDisabled();
    });

    it('enables the toggle when isToggleDisabled is false', () => {
        render(<ToggleSwitch checked={false} isToggleDisabled={false} />);
        const toggleInput = screen.getByRole('checkbox');
        expect(toggleInput).not.toBeDisabled();
    });
});
