import {
    VendorInvoiceDocumentsData,
    VendorInvoiceDocumentsResponse
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import { ORDER_QUOTE_MODULE, QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import { DOCUMENT_TYPE, MODULE_TYPE } from 'constants/app.constant';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Dialog } from 'primereact/dialog';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import utils, { getWindowSize } from 'core/utils/utils';
import { previewDialogPopup } from 'constants/styles.constant';
import { getVendorInvoiceDocuments } from 'pages/accounting/service/billing.service';
import { VendorInvoiceNumberEdit } from 'pages/ViewOrderAndQuote/components/billsAndInvoices/invoiceTasks/invoiceTasks';
import { updateDocumentVendorInvoiceNumber } from 'pages/ViewOrderAndQuote/components/billsAndInvoices/invoiceTasks/service/invoiceTasksService';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';

interface VendorInvoiceDocumentsProps {
    orderId?: number | null;
    taskId?: number | null;
    isSTD?: boolean | null;
    vendorInvoiceNumberChange?: () => void | Promise<void>;
}

const VendorInvoiceDocuments: React.FC<VendorInvoiceDocumentsProps> = ({
    orderId,
    taskId,
    isSTD,
    vendorInvoiceNumberChange
}) => {
    const { t } = useTranslation();
    const { billId } = useParams();
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const moduleId = MODULE_TYPE.TASK_MODULE.moduleId;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`;
    const [orderVendorInvoiceDocumentssModelList, setOrderVendorInvoiceDocumentssModelList] =
        useState<VendorInvoiceDocumentsData[]>([]);
    const [fileTypes, setFileTypes] = useState<any>([]);
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const emptyMessage = t('COMMON.NO_DATA_FOUND');
    const [errMessage, setErrMessage] = useState<undefined | string>(undefined);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [documentTableUpdatedCounter, setDocumentTableUpdatedCounter] = useState<number>(0);
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription.unsubscribe();
        };
    }, []);

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 2000) {
                    handleGetVendorInvoiceDocumentss(requestBody);
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    // Fetching SAS URL on component mount
    useEffect(() => {
        getSasUrlApi();
        fetchDocumentTypes();
    }, []);

    // Fetching document types and source documents on component mount
    useEffect(() => {
        handleGetVendorInvoiceDocumentss(requestBody);
    }, [requestBody, documentTableUpdatedCounter]);

    // Fetching document types
    const fetchDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        setFileTypes(response);
    };

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const DocumentPreviewTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileId + ' flex items-center gap-1'}>
                    {fileTypeIcon(rowData.fileType as string)}
                    <p
                        className="text-base text-primary font-medium underline underline-offset-1 max-w-56 truncate cursor-pointer"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handlePreviewDocument(rowData);
                            }
                        }}
                        tabIndex={0}>
                        {rowData.fileName}
                    </p>
                </div>
            </div>
        );
    };

    const DocumentTypeTemplate = (rowData: VendorInvoiceDocumentsData) => {
        return (
            <div>
                {fileTypes.map((type: { id: number; name: string }) => {
                    if (type.id === Number(rowData.documentType)) {
                        return (
                            <p key={rowData.documentId} className="text-base">
                                {type.name}
                            </p>
                        );
                    }
                })}
            </div>
        );
    };
    const showToastMessage = (
        toastMsg: string,
        errorType: (typeof ToastType)[keyof typeof ToastType]
    ) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };
    const updateVendorInvoiceNumberInlineFields = async (
        documentId: number,
        fileId: number,
        documentType: number,
        vendorInvoiceNumber: string,
        toastMsg = { success: '', error: '' }
    ) => {
        const vendorInvoiceNumberUpdateApiUrl = isSTD
            ? `${quoteBaseURL}${ORDER_QUOTE_MODULE.UPDATE_VENDOR_INVOICE_NUMBER}/${documentId}`
            : `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_FILED_EXISTING_FILE}/${taskId}/${documentId}/${fileId}`; // Replace existing file API URL
        const errMsg = t(`${toastMsg?.error}`);
        try {
            const response = await updateDocumentVendorInvoiceNumber(
                vendorInvoiceNumberUpdateApiUrl,
                {
                    orderId,
                    documentId,
                    fileId,
                    documentType,
                    vendorInvoiceNumber
                }
            );
            if (response) {
                setDocumentTableUpdatedCounter((prev) => prev + 1);
                if (vendorInvoiceNumberChange) {
                    vendorInvoiceNumberChange();
                }
                showToastMessage(t(`${toastMsg?.success}`), ToastType.SUCCESS);
            } else {
                showToastMessage(errMsg, ToastType.ERROR);
            }
        } catch (error: any) {
            const errorMsgFromAPI = error?.response?.data?.Message as string;
            showToastMessage(errorMsgFromAPI ?? errMsg, ToastType.ERROR);
        }
    };

    const vendorInvoiceNumberTemplate = (rowData: any) => {
        const vendorInvoiceNumber = rowData?.vendorInvoiceNumber || '';
        if (rowData.documentType !== DOCUMENT_TYPE.VENDOR_INVOICE.id) {
            return <>{vendorInvoiceNumber}</>;
        }

        const handleVendorInvoiceNumberSave = (newValue: string) => {
            updateVendorInvoiceNumberInlineFields(
                rowData.documentId as number,
                rowData.fileId as number,
                rowData.documentType as number,
                newValue,
                {
                    success: 'ACCOUNTING.VENDOR_INVOICE_NUMBER_UPDATED_SUCCESSFULLY',
                    error: 'ACCOUNTING.VENDOR_INVOICE_NUMBER_UPDATED_FAILED'
                }
            );
        };
        return (
            <VendorInvoiceNumberEdit
                fieldName="vendorInvoiceNumber"
                fieldValue={vendorInvoiceNumber}
                onSave={handleVendorInvoiceNumberSave}
                canFormatFields={false}
            />
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'fileName',
            header: 'Document Name',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            body: DocumentPreviewTemplate,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'documentType',
            header: 'Document Type',
            sortable: false,
            filter: false,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            filterDropDownOptions: fileTypes.map((type: { name: any; id: any }) => ({
                label: type.name,
                value: `${type.id}`
            })),
            columnNumber: 2,
            visibility: true,
            body: DocumentTypeTemplate
        },

        {
            field: 'vendorInvoiceNumber',
            header: 'Vendor Invoice Number',
            sortable: false,
            filter: false,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: 3,
            body: vendorInvoiceNumberTemplate,
            visibility: true,
            cellStyle: 'w-64'
        },
        {
            field: 'fileSize',
            header: 'Size',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded by',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: false,
            filter: false,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 5,
            visibility: true
        }
    ];

    const tableDefinition: DataTableDefinition = {
        title: '',
        filters: {},
        reOrderableColumns: false,
        tableType: TableTypes.ORDER_QUOTE_SOURCE_DOCUMENTS,
        emptyMessage: errMessage,
        columns: columnSchema,
        customTableHeight: false,
        customerHeader: null,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.VENDOR_INVOICES_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: true,
        showFilter: false,
        hideColumnSelector: true
    };

    // Fetch and process source documents
    const handleGetVendorInvoiceDocumentss = async (body: RequestBody) => {
        try {
            const response: VendorInvoiceDocumentsResponse =
                await getVendorInvoiceDocuments<VendorInvoiceDocumentsResponse>(
                    String(billId),
                    body
                );

            setOrderVendorInvoiceDocumentssModelList(
                response.vendorDocumentsModel as VendorInvoiceDocumentsData[]
            );

            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil((response.total ?? 0) / body.pageCount),
                totalRecords: response.total as number
            };
            setBlobURL(response.blobUri);
            setPaginationInfo(pagination);

            if (response.vendorDocumentsModel?.length === 0) setErrMessage(emptyMessage);
        } catch (error) {
            console.error('Error fetching source documents:', error);
            setErrMessage(emptyMessage);
        }
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;

        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    return (
        <div>
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    utils.handleDownloadPngSvg(previewImage, previewImageName);
                                }
                            }}
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>

            <DataTableComponent
                tableData={orderVendorInvoiceDocumentssModelList ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                toggleRowData={() => {}}
                previewDocument={handlePreviewDocument}
                handlePagination={handlePageChange}
                tablePaginationData={paginationInfo}
                showPagination={true}
                showHeader={false}
                handleSort={sortHandler}
            />
        </div>
    );
};

export default VendorInvoiceDocuments;
