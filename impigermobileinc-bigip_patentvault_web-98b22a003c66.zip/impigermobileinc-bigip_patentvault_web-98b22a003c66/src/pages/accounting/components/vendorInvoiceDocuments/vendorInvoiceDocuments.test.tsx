import { render, screen } from '@testing-library/react';
import DataTableComponent from 'shared/dataTable/dataTable';
import { DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import VendorInvoiceDocuments from './vendorInvoiceDocuments';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';

jest.mock('shared/dataTable/dataTable', () => jest.fn(() => <div>Mocked DataTableComponent</div>));

describe('VendorInvoiceDocuments Component', () => {
    it('should render the DataTableComponent with the correct table definition', () => {
        render(<VendorInvoiceDocuments />);

        const mockedDataTable = screen.getByText('Mocked DataTableComponent');
        expect(mockedDataTable).toBeInTheDocument();

        const tableDefinition: DataTableDefinition = {
            title: '',
            filters: {},
            reOrderableColumns: false,
            tableType: TableTypes.ORDER_QUOTE_SOURCE_DOCUMENTS,
            emptyMessage: 'No data found',
            columns: expect.any(Array),
            customTableHeight: false,
            customerHeader: null,
            localStorageKey: 'VENDOR_INVOICES_DOCUMENT_COLUMN_ORDERS',
            hideTableExport: true,
            showFilter: false,
            hideColumnSelector: true
        };

        expect(DataTableComponent).toHaveBeenCalledWith(
            expect.objectContaining({
                tableDefinition: expect.objectContaining(tableDefinition)
            }),
            {}
        );
    });
});
