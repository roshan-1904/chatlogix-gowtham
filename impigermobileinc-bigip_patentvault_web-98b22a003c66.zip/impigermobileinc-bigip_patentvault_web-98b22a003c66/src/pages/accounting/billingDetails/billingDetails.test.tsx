import { render, screen } from '@testing-library/react';
import BillingDetails from './billingDetails';
import { getBillingDetails } from '../service/billing.service';
import { BrowserRouter } from 'react-router-dom';

jest.mock('../service/billing.service', () => ({
    getBillingDetails: jest.fn()
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn()
}));

describe('BillingDetails Component', () => {
    const mockBillingDetails = {
        taskDetails: [
            { taskId: '1', taskName: 'Task 1', fxRate: '1.5' },
            { taskId: '2', taskName: 'Task 2', fxRate: '2.0' }
        ],
        billingAddress: {
            address1: '123 Main St',
            city: 'City',
            state: 'State',
            countryName: 'Country',
            zip: '12345'
        },
        vendorDetails: {
            sageId: '123',
            fullName: 'Vendor Name',
            vendorCompany: 'Vendor Company',
            email: 'vendor@example.com',
            phoneNumber: '123-456-7890'
        },
        vendorPreferredCurrency: 'USD',
        billingTerms: 'Net 30',
        taxFormName: 'Form W-9',
        billNo: 'BILL123',
        sageStatus: 'Approved',
        billDate: '2023-01-01',
        dueDate: '2023-01-15',
        title: 'Patent Title',
        patentAppNumber: 'APP123',
        sageAmount: '1000.00',
        billAmount: '1200.00',
        currencySymbol: '$',
        priorityPay: true,
        isvendorDocument: true
    };

    beforeEach(() => {
        (getBillingDetails as jest.Mock).mockResolvedValue(mockBillingDetails);

        render(
            <BrowserRouter>
                <BillingDetails />
            </BrowserRouter>
        );
    });

    it('renders the billing details component', () => {
        expect(screen.getByTestId('billDetailWrapperSection')).toBeInTheDocument();
    });

    it('displays the vendor details', () => {
        expect(screen.getByText('Vendor Name')).toBeInTheDocument();
        expect(screen.getByText('Vendor Company')).toBeInTheDocument();
        expect(screen.getByText('vendor@example.com')).toBeInTheDocument();
        expect(screen.getByText('123-456-7890')).toBeInTheDocument();
    });

    it('displays the billing address', () => {
        expect(screen.getByText('123 Main St')).toBeInTheDocument();
        expect(screen.getByText('City')).toBeInTheDocument();
        expect(screen.getByText('State')).toBeInTheDocument();
        expect(screen.getByText('Country')).toBeInTheDocument();
        expect(screen.getByText('12345')).toBeInTheDocument();
    });

    it('displays the bill details', () => {
        expect(screen.getByText('BILL123')).toBeInTheDocument();
        expect(screen.getByText('Approved')).toBeInTheDocument();
        expect(screen.getByText('Patent Title')).toBeInTheDocument();
        expect(screen.getByText('APP123')).toBeInTheDocument();
        expect(screen.getByText('$ 1000.00')).toBeInTheDocument();
        expect(screen.getByText('$ 1200.00')).toBeInTheDocument();
    });

    it('renders the task details table', () => {
        expect(screen.getByText('Task 1')).toBeInTheDocument();
        expect(screen.getByText('Task 2')).toBeInTheDocument();
        expect(screen.getByText('1.5')).toBeInTheDocument();
        expect(screen.getByText('2.0')).toBeInTheDocument();
    });

    it('displays the priority pay toggle', () => {
        expect(screen.getByText('PRIORITY_PAY')).toBeInTheDocument();
    });

    it('displays the vendor invoice documents section', () => {
        expect(screen.getByText('VENDOR_INVOICE_DOCUMENTS')).toBeInTheDocument();
    });
});
