import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { PATHS } from 'constants/routes.constant';
import { formatCurrency, formatDate } from 'core/utils/utils';
import { TaskNameTemplate } from 'pages/taskManagement/shared/taskManagementHelper';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { BillingDetailsWidget } from '../components/billingDetailWidget/billingDetailWidget';
import { ToggleSwitch } from '../components/toggleSwitch/toggleSwitch';
import {
    getBillingDetails,
    saveVendorInvoiceNumber,
    resetVendorInvoiceNumber
} from '../service/billing.service';
import { getBillingServicesTableColumnSchema } from '../tableSchema/billingServices.schema';
import { BillDetails, TaskDetails } from '../types';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';
import VendorInvoiceDocuments from '../components/vendorInvoiceDocuments/vendorInvoiceDocuments';
import { getBillsInvoiceStatusColors } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { Chips } from 'primereact/chips';
import edit from 'assets/images/editGrey.svg';
import OverflowAnchorTagList from 'shared/dataTable/components/overflowAnchorTagList/overflowAnchorTagList';
import { Tooltip } from 'primereact/tooltip';

type FieldState = {
    value: string | null;
    originalValue: string | null;
    isEdit: boolean;
    hasEditability: boolean;
};
type FieldName = 'vendorInvoiceNumber';
type FieldsDataModel = Record<FieldName, FieldState>;

const BillingDetails = () => {
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const { billId: requestBillId } = useParams();
    const { t } = useTranslation();
    const isAccount: boolean =
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE);

    const [billDetails, setBillDetails] = useState<BillDetails>();
    const [invoiceNumber, setInvoiceNumber] = useState<string>('');
    const [accordionActive1, setAccordionActive1] = useState(true);
    const [accordionActive2, setAccordionActive2] = useState(true);
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        visible: false,
        header: '',
        description: ''
    });

    const [tableRequestBody, setTableRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 2
    });
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.BILLINGS_DETAILS_SERVICES_COLUMN_ORDERS;

    const [fieldsData, setFieldsData] = useState<FieldsDataModel>({
        vendorInvoiceNumber: {
            value: null,
            originalValue: null,
            isEdit: false,
            hasEditability: true
        }
    });
    const [vendorInvoiceNumberEventCounter, setVendorInvoiceNumberEventCounter] = useState(0);
    const [invoiceNumberEdit, setInvoiceNumberEdit] = useState(false);

    function VendorInvoiceNumberChangeEvent() {
        setVendorInvoiceNumberEventCounter((prev) => prev + 1);
    }

    const handleFieldUpdate = async (fieldName: FieldName, newValue: any) => {
        try {
            if (fieldName === 'vendorInvoiceNumber') {
                const payload = {
                    vendorInvoiceNo: (newValue as string[])
                        .filter(Boolean)
                        .map((s) => s.replace(/\s+/g, ''))
                        .join(',')
                        .replace(/,+$/, '')
                };
                const response = await saveVendorInvoiceNumber(billDetails?.id ?? 0, payload);
                if (response) {
                    showToastMessage({
                        message: 'Vendor Invoice Number updated successfully.',
                        type: ToastType.SUCCESS
                    });
                    fetchBillDetails();
                    setInvoiceNumberEdit(false);
                }
            }
        } catch (error: any) {
            console.error('Error updating field:', error);
            showToastMessage({
                message: error?.message,
                type: ToastType.ERROR
            });
        }
    };

    useEffect(() => {
        const inputField = document.getElementById('vendor-invoice-number') as HTMLInputElement;
        if (inputField) {
            inputField.focus();
            inputField.value = '';
        }
    }, [invoiceNumberEdit]);

    useEffect(() => {
        fetchBillDetails();
    }, []);
    useEffect(() => {
        fetchBillDetails();
    }, [vendorInvoiceNumberEventCounter]);
    useEffect(() => {
        setFieldsData({
            ...fieldsData,
            vendorInvoiceNumber: {
                ...fieldsData.vendorInvoiceNumber,
                originalValue: billDetails?.vendorInvoiceNumber ?? ''
            }
        });
    }, [billDetails]);

    const fetchBillDetails = async () => {
        try {
            const response = await getBillingDetails<BillDetails>(requestBillId ?? '');
            setBillDetails(response);
            setInvoiceNumber(response.vendorInvoiceNumber ?? '');
            setPaginationInfo({
                pageNo: 1,
                totalPages: 1,
                totalRecords: response.taskDetails.length
            });
        } catch (error) {
            console.error(error);
        }
    };

    const taskIDTemplate = ({ taskId }: TaskDetails) => {
        return (
            <span
                data-testid="dataTable-link-format"
                className={`underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer`}
                role="button" // Add the role attribute with the value of "button"
                tabIndex={0} // Add the tabIndex attribute to make the element focusable
            >
                {taskId}
            </span>
        );
    };

    const taskTitleTemplate = (rowData: TaskDetails) => {
        const userIconTemplate = TaskNameTemplate(rowData?.taskName as string);

        return (
            <div className="flex items-center">
                <img className="h-[16px]" src={userIconTemplate} alt="" />
                <span className="pl-3">{rowData.taskName}</span>
            </div>
        );
    };

    const renderFXRate = ({ fxRate }: TaskDetails) => {
        return <span>{fxRate}</span>;
    };

    const resetVendorInvoiceNumberEvent = async () => {
        try {
            const response = await resetVendorInvoiceNumber<number>(billDetails?.id ?? 0);
            if (response) {
                showToastMessage({
                    message: 'Vendor Invoice Number reset successfully.',
                    type: ToastType.SUCCESS
                });
                setVendorInvoiceNumberEventCounter((prev) => prev + 1);
            }
        } catch (error) {
            console.error('Error resetting vendor invoice number:', error);
            showToastMessage({
                message: 'Error resetting vendor invoice number.',
                type: ToastType.ERROR
            });
        }
    };

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.ACCOUNT_BILLS_DETAILS_TASK_DETAILS_TABLE,
        reOrderableColumns: true,
        columns: getBillingServicesTableColumnSchema(
            {
                taskId: taskIDTemplate,
                taskName: taskTitleTemplate,
                // sageAmount: renderBillAmount,
                fxRate: renderFXRate
                // taskAmount: renderTaskAmount
            },
            isAccount
        ),
        customerHeader: null,
        emptyMessage: '',
        filters: {},
        localStorageKey: storageKey,
        title: '',
        customTableHeight: false,
        showFilter: false
    };

    const handleFilter = (updatedFilter: RequestBody) => {
        setTableRequestBody(updatedFilter);
    };

    const sortHandler = (updatedSort: RequestBody) => {
        setTableRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setTableRequestBody(updatedPage);
    };

    const getBillingAddress = () => {
        let fullAddress = '';
        const billingAddress = billDetails?.billingAddress;

        if (billingAddress?.address1) {
            fullAddress += billingAddress?.address1;
        }

        if (billingAddress?.address2) {
            fullAddress += ', ' + billingAddress?.address2;
        }

        if (billingAddress?.city) {
            fullAddress += '\n' + billingAddress?.city;
        }

        if (billingAddress?.state) {
            fullAddress += ', ' + billingAddress?.state;
        }

        if (billingAddress?.countryName) {
            fullAddress += '\n' + billingAddress?.countryName;
        }

        if (billingAddress?.zip) {
            fullAddress += ' ' + billingAddress?.zip;
        }

        return fullAddress === '' ? '-' : fullAddress;
    };

    // Confirming file deletion
    const handleConfirm = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
        resetVendorInvoiceNumberEvent();
    };

    // Canceling file deletion
    const handleCancel = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };

    return (
        <div data-testid="billDetailWrapperSection" className="flex-1">
            <TopNavigationStep
                backNavigationPath={`/${isAccount ? PATHS.ACCOUNT_BILLS : PATHS.BILLS}`}
                steps={[
                    {
                        label: t('COMMON.BILLS'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: `/${isAccount ? PATHS.ACCOUNT_BILLS : PATHS.BILLS}`
                    },
                    {
                        label: ` ${billDetails?.billNo ?? ''}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.BILL'),
                        module: 'BILL',
                        isCopyable: true
                    }
                ]}
            />

            {showConfirmationPopup.visible ? (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleConfirm();
                    }}
                    onCancel={() => {
                        handleCancel();
                    }}
                    visible={showConfirmationPopup.visible}
                    headerText={showConfirmationPopup.header}
                    description={showConfirmationPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    popupID={'confirmationPopup'}
                />
            ) : null}

            <div data-testid="detailSection" className="flex px-6 py-3">
                <div
                    data-testid="vendorDetailSection"
                    className="bg-white h-100 rounded-md shadow-md w-6/12 mr-2 p-6">
                    <div className="text-[#1D8ADE] font-medium text-lg">
                        {t('ACCOUNTING.VENDOR_DETAILS')}
                    </div>

                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.VENDOR_ID')}
                        field1Value={billDetails?.vendorDetails?.sageId}
                        field2Title={t('ACCOUNTING.NAME')}
                        field2Value={billDetails?.vendorDetails?.fullName}
                    />
                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.VENDOR_PREFERRED_CURRENCY')}
                        field1Value={billDetails?.vendorPreferredCurrency}
                        field2Title={t('ACCOUNTING.TERMS')}
                        field2Value={billDetails?.billingTerms}
                    />
                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.TAX_FORM')}
                        field1Value={billDetails?.taxFormName}
                        field2Title={t('ACCOUNTING.VENDOR_COMPANY')}
                        field2Value={
                            billDetails?.vendorDetails?.vendorCompany?.trim() === ''
                                ? '-'
                                : billDetails?.vendorDetails?.vendorCompany
                        }
                    />
                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.EMAIL')}
                        field1Value={billDetails?.vendorDetails?.email}
                        field2Title={t('ACCOUNTING.PHONE')}
                        field2Value={billDetails?.vendorDetails?.phoneNumber ?? ''}
                    />

                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.BILLING_ADDRESS')}
                        field1Value={getBillingAddress()}
                        field2Title={isAccount ? t('ACCOUNTING.PT_PAYPAL_VEEM') : ''}
                        field2Value={billDetails?.vendorDetails?.ptPayPaypalVeem}
                    />
                </div>

                <div
                    data-testid="billDetailSection"
                    className="bg-white h-100 rounded-md shadow-md w-6/12 ml-2 p-6">
                    <div className="text-[#1D8ADE] font-medium text-lg">
                        {t('ACCOUNTING.BILL_DETAILS')}
                    </div>

                    {/* TODO:
                     I couldn't accommodate the 3 column design in this page with existing UI format (BillingDetailsWidget). 
                     hence, I customized the Row-01. */}
                    <div className="flex justify-between my-4 gap-5">
                        <div className="w-6/12">
                            <span className="font-normal text-[#484848] text-[13px]">
                                {t('ACCOUNTING.BILL_ID')}
                            </span>
                            <div className="font-medium mt-1 text-sm">{billDetails?.billNo}</div>
                        </div>

                        <div className="flex w-6/12 gap-24 relative">
                            <div className="flex flex-col gap-2">
                                <span className="font-normal text-[#484848] text-[13px]">
                                    {t('ACCOUNTING.BILL_STATUS')}
                                </span>
                                {billDetails?.sageStatus && (
                                    <span
                                        className={`${getBillsInvoiceStatusColors(billDetails?.sageStatus)} font-medium text-sm rounded-md w-fit px-2 py-1`}>
                                        {billDetails?.sageStatus ?? '-'}
                                    </span>
                                )}
                            </div>
                            <div className=" absolute right-0">
                                <div className="flex flex-col gap-2">
                                    <span className="font-normal text-[#484848] text-[13px] flex items-center gap-3">
                                        {t('ACCOUNTING.VENDOR_INVOICE_NUMBER')}
                                        <div>
                                            <Tooltip
                                                position="bottom"
                                                target={'.descVendorInvoiceNo'}
                                                content={t('ACCOUNTING.VENDOR_INVOICE_DESC')}
                                            />
                                            <i className="descVendorInvoiceNo pi pi-info-circle text-primary pt-px"></i>
                                        </div>
                                        <button onClick={() => setInvoiceNumberEdit(true)}>
                                            <img src={edit} alt="Edit" className="h-3" />
                                        </button>
                                        <button
                                            onClick={() => {
                                                setShowConfirmationPopup({
                                                    visible: true,
                                                    header: 'Reset Vendor Invoice Number',
                                                    description:
                                                        'Are you sure you want to reset the Vendor Invoice Number?'
                                                });
                                            }}>
                                            <i
                                                className="pi pi-refresh text-primary"
                                                title="Reset"
                                            />
                                        </button>
                                    </span>
                                    {invoiceNumberEdit ? (
                                        <div className="flex items-center gap-2  w-72">
                                            <Chips
                                                pt={{
                                                    root: {
                                                        className: 'focus:shadow-none w-64'
                                                    },
                                                    container: {
                                                        className:
                                                            'p-1 gap-y-1 max-h-24 overflow-auto rounded-md'
                                                    },
                                                    token: {
                                                        className: 'text-sm bg-black/10 p-1.5'
                                                    },
                                                    removeTokenIcon: {
                                                        className: 'cursor-pointer'
                                                    },
                                                    inputToken: {
                                                        className: 'min-w-4'
                                                    },
                                                    input: {
                                                        id: 'vendor-invoice-number'
                                                    }
                                                }}
                                                value={
                                                    invoiceNumber ? invoiceNumber.split(',') : []
                                                }
                                                id="vendor-invoice"
                                                onChange={(e) => {
                                                    const newValue = e.value
                                                        ? e.value.join(',')
                                                        : '';
                                                    setInvoiceNumber(newValue);
                                                    handleFieldUpdate(
                                                        'vendorInvoiceNumber',
                                                        e.value
                                                    );
                                                }}
                                            />
                                            <div className="flex">
                                                <button
                                                    onClick={() => {
                                                        handleFieldUpdate('vendorInvoiceNumber', [
                                                            ...(invoiceNumber
                                                                ? invoiceNumber.split(',')
                                                                : []),
                                                            (
                                                                document.getElementById(
                                                                    'vendor-invoice-number'
                                                                ) as HTMLInputElement
                                                            ).value
                                                        ]);
                                                    }}>
                                                    {' '}
                                                    <i className="pi pi-check text-[0.75rem] text-primary cursor-pointer" />
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        setInvoiceNumberEdit(false);
                                                        setInvoiceNumber(
                                                            fieldsData.vendorInvoiceNumber
                                                                .originalValue ?? ''
                                                        );
                                                    }}>
                                                    <i className="pi pi-times ml-2 text-[0.75rem] text-secondary cursor-pointer" />
                                                </button>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="w-72">
                                            <OverflowAnchorTagList
                                                tags={
                                                    billDetails?.vendorInvoiceNumber
                                                        ? billDetails.vendorInvoiceNumber
                                                              .split(',')
                                                              .map((tag) => ({
                                                                  text: tag,
                                                                  value: tag
                                                              }))
                                                        : []
                                                }
                                            />
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.BILL_ID')}
                        field1Value={billDetails?.billNo}
                        rightElement={
                            <div className="w-6/12">
                                <div className="flex flex-col align-baseline w-6/12">
                                    <span className="font-normal text-[#484848] text-[13px]">
                                        {t('ACCOUNTING.BILL_STATUS')}
                                    </span>
                                    {billDetails?.sageStatus && (
                                        <span
                                            className={`${getBillsInvoiceStatusColors(billDetails?.sageStatus)} flex-1 font-medium mt-2 text-sm rounded-md w-fit py-0.5 px-3`}>
                                            {billDetails?.sageStatus ?? '-'}
                                        </span>
                                    )}
                                </div>
                            </div>
                        }
                    /> */}

                    {/* <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.GL_POSTING_DATE')}
                        field1Value={formatDate(billDetails?.glPostingDate ?? '')}
                        rightElement={
                            <CustomDetailWidget title={t('ACCOUNTING.SYNCED')}>
                                <ProgressStatusIndicator
                                    syncStatus={billDetails?.sageSyncStatusName}
                                />
                            </CustomDetailWidget>
                        }
                    /> */}

                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.BILL_DATE')}
                        field1Value={formatDate(billDetails?.billDate ?? '')}
                        field2Title={t('ACCOUNTING.DUE_DATE')}
                        field2Value={formatDate(billDetails?.dueDate ?? '')}
                    />

                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.PATENT_TITLE')}
                        field1Value={billDetails?.title ?? ''}
                        field2Title={t('ACCOUNTING.PATENT_APP_NUMBER')}
                        field2Value={billDetails?.patentAppNumber}
                    />

                    <BillingDetailsWidget
                        field1Title={
                            isAccount
                                ? t('ACCOUNTING.SAGE_BILL_AMOUNT')
                                : t('ACCOUNTING.BILL_AMOUNT')
                        }
                        field1Value={
                            `${billDetails?.currencySymbol ?? ''} ` +
                            `${formatCurrency(billDetails?.sageAmount ?? '0.0')}`
                        }
                        field2Title={isAccount ? t('ACCOUNTING.TOTAL_AMOUNT') : ''}
                        field2Value={
                            `${billDetails?.currencySymbol ?? ''} ` +
                            `${formatCurrency(billDetails?.billAmount ?? '0.0')}`
                        }
                        fieldValueStyle_1="font-semibold !text-lg"
                        fieldValueStyle_2="font-semibold !text-lg"
                    />

                    <BillingDetailsWidget
                        field1Title={t('ACCOUNTING.PAID_AMOUNT')}
                        field1Value={
                            `${billDetails?.currencySymbol ?? ''} ` +
                            `${formatCurrency(billDetails?.transacationPaidAmount ?? '0.0')}`
                        }
                        field2Title={t('ACCOUNTING.BALANCE_AMOUNT')}
                        field2Value={
                            `${billDetails?.currencySymbol ?? ''} ` +
                            `${formatCurrency(billDetails?.transacationBalanceAmount ?? '0.0')}`
                        }
                        fieldValueStyle_1="font-semibold !text-lg"
                        fieldValueStyle_2="font-semibold !text-lg"
                    />

                    <BillingDetailsWidget
                        leftElement={
                            <div className="flex flex-col align-middle w-6/12">
                                <span
                                    data-testid="rowf1title"
                                    className="font-normal text-[#484848] text-[13px]">
                                    {t('ACCOUNTING.PRIORITY_PAY')}
                                </span>
                                <ToggleSwitch
                                    title=""
                                    checked={billDetails?.priorityPay ?? false}
                                />
                            </div>
                        }
                        field2Title={t('TASKS.INVOICE_UPLOADED')}
                        field2Value={
                            billDetails?.isvendorDocument ? t('COMMON.YES') : t('COMMON.NO')
                        }
                    />
                </div>
            </div>

            <div data-testid="collapsibleContainer" className="flex px-6 py-3">
                <div
                    className={`collapse collapse-arrow bg-white border-neutral border-1 rounded-md shadow-md`}
                    id="request-detail-container">
                    <input
                        type="checkbox"
                        className="py-1 min-h-0"
                        name="my-accordion-1"
                        onClick={() => setAccordionActive1(!accordionActive1)}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                setAccordionActive1(!accordionActive1);
                            }
                        }}
                        checked={accordionActive1}
                    />
                    <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                        <span className=" text-md font-medium text-[#1D8ADE] text-lg">
                            {t('ACCOUNTING.TASK_DETAILS')}
                        </span>
                    </div>
                    <div className="flex-1 collapse-content border-t-neutral-60 border-t-[1px] px-5 overflow-hidden remove-cursor-pointer">
                        <DataTableComponent
                            tableData={billDetails?.taskDetails ?? []}
                            tableDefinition={tableDefinition}
                            tableRequestBodyData={tableRequestBody}
                            handleFilter={handleFilter}
                            toggleRowData={() => {}}
                            handlePagination={handlePageChange}
                            tablePaginationData={paginationInfo}
                            showPagination={true}
                            handleSort={sortHandler}
                            showHeader={false}
                        />
                    </div>
                </div>
            </div>

            <div data-testid="collapsibleContainer" className="flex px-6 py-3">
                <div
                    className={`collapse collapse-arrow bg-white border-neutral border-1 rounded-md shadow-md`}
                    id="request-detail-container">
                    <input
                        type="checkbox"
                        className="py-1 min-h-0"
                        name="my-accordion-2"
                        onClick={() => setAccordionActive2(!accordionActive2)}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                setAccordionActive2(!accordionActive2);
                            }
                        }}
                        checked={accordionActive2}
                    />
                    <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                        <span className=" text-md font-medium text-[#1D8ADE] text-lg">
                            {t('ACCOUNTING.VENDOR_INVOICE_DOCUMENTS')}
                        </span>
                    </div>
                    <div className="flex-1 collapse-content border-t-neutral-60 border-t-[1px] px-5 overflow-hidden remove-cursor-pointer">
                        <VendorInvoiceDocuments
                            orderId={billDetails?.taskDetails?.[0]?.orderId ?? null}
                            isSTD={billDetails?.taskDetails?.[0]?.IsStdOrder ?? null}
                            taskId={billDetails?.taskDetails?.[0]?.id ?? null}
                            vendorInvoiceNumberChange={VendorInvoiceNumberChangeEvent}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};
export default BillingDetails;
