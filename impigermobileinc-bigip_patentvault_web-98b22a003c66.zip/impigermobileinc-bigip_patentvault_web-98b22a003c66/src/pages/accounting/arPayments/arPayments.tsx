import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { ArPaymentList, ArPaymentListResponse } from '../types';
import { arPaymentService } from '../service/arPayment.service';
import {
    baseCurrencyWithAmountTemplate,
    fxRateTemplate,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { DataTableSelectEvent } from 'primereact/datatable';
import { useNavigate } from 'react-router-dom';
import { arAdjustmentService } from '../service/arAdjustment.service';

const ArPayments = () => {
    const navigate = useNavigate();
    const [paymentList, setPaymentList] = useState<ArPaymentList[]>([]);
    const [syncedDate, setSyncedDate] = useState<string>('');
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 0
    });
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const fetchPaymentList = async (reqBody: RequestBody) => {
        try {
            const response: ArPaymentListResponse =
                await arPaymentService.getArPaymentList(reqBody);
            if (response) {
                setPaymentList(response.arPaymentList);
                const pagination: paginationData = {
                    pageNo: requestBody.pageNo,
                    totalPages: Math.ceil(response.totalCount / reqBody.pageCount),
                    totalRecords: response.totalCount
                };

                setPaginationInfo(pagination);
            }
        } catch (error) {
            console.error('Error fetching Payment list:', error);
        }
    };

    const handleExportList = () => {
        arPaymentService.exportArPaymentList(requestBody);
    };

    const handleSageSync = async () => {
        await arPaymentService.sageSyncArPaymentList();
        getSyncDetails();
        fetchPaymentList(requestBody);
    };

    const getSyncDetails = async () => {
        try {
            const response = await arAdjustmentService.getSyncDetails();

            const arPaymentDate = response
                .filter((item) => item.name === 'ARPAYMENT')
                .map((item) => item.lastSyncDate)
                .join(', ');
            setSyncedDate(arPaymentDate);
        } catch (error) {
            console.error('Error fetching sync details:', error);
        }
    };

    useEffect(() => {
        getSyncDetails();
    }, []);

    useEffect(() => {
        fetchPaymentList(requestBody);
    }, [requestBody]);

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'recordNo',
            header: t('PAYMENTS.RECORD_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { recordNo: string }) => (
                <span className="cursor-pointer text-primary underline font-medium">
                    {rowData.recordNo}
                </span>
            )
        },
        {
            field: 'customerName',
            header: t('PAYMENTS.CUSTOMER'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'paymentStatus',
            header: t('PAYMENTS.PAYMENT_STATUS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'paymentMethod',
            header: t('PAYMENTS.PAYMENT_METHOD'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'paymentDate',
            header: t('PAYMENTS.PAYMENT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'transactionCurrency',
            header: t('PAYMENTS.TRANSACTION_CURRENCY'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'transactionPaymentAmount',
            header: t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: {
                transactionPaymentAmount: number;
                transactionCurrencySymbol: string;
            }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionPaymentAmount,
                    rowData.transactionCurrencySymbol
                )
        },
        {
            field: 'exchangeRate',
            header: t('PAYMENTS.FX_RATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { exchangeRate: number }) => fxRateTemplate(rowData.exchangeRate)
        },
        {
            field: 'paymentAmount',
            header: t('PAYMENTS.PAYMENT_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { paymentAmount: number }) =>
                baseCurrencyWithAmountTemplate(rowData.paymentAmount)
        },
        {
            field: 'creditsApplied',
            header: t('PAYMENTS.CREDITS_APPLIED'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { creditsApplied: number }) =>
                baseCurrencyWithAmountTemplate(rowData.creditsApplied)
        },
        {
            field: 'createdAt',
            header: t('COMMON.CREATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'updatedAt',
            header: t('COMMON.UPDATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.AR_PAYMENTS_TABLE,
        title: t('MENU.AR_PAYMENTS'),
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AR_PAYMENTS_COLUMN_ORDERS,
        columns: columnSchema,
        showResync: true,
        syncedDate: {
            dateTime: syncedDate,
            nextToDateTimeCustomText: t('COMMON.SYNC_DATE_TIME_UTC')
        },
        showResyncCustomize: {
            permission: true,
            customText: t('COMMON.MANUAL_SYNC')
        }
    };

    const onRowClick = (e: DataTableSelectEvent) => {
        const rowData = e.data as ArPaymentList;
        navigate(`/accounting/ar-payments/${rowData.recordNo.toLowerCase()}`);
    };

    return (
        <div className="p-4 pb-0">
            <DataTableComponent
                tableData={paymentList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                onRowClicked={onRowClick}
                onClickReSync={() => {
                    handleSageSync();
                }}
                exportData={handleExportList}
            />
        </div>
    );
};
export default ArPayments;
