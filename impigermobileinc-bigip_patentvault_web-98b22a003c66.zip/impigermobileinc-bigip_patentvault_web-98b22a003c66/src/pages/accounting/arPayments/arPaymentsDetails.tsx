import LabelName from 'components/inputs/labelName';
import ConstructField from 'components/reuseComponents/constructField';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { ArPaymentDetails } from '../types';
import { useParams } from 'react-router-dom';
import {
    baseCurrencyWithAmountTemplate,
    formatDate,
    fxRateTemplate,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { getStatusColor } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { FilterMatchMode } from 'primereact/api';
import { arPaymentService } from '../service/arPayment.service';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';

const ArPaymentsDetails = () => {
    const id = useParams<{ id: string }>().id;
    const [paymentEntries, setPaymentEntries] = useState<ArPaymentDetails['invoiceEntries']>([]);
    const [creditEntries, setCreditEntries] = useState<ArPaymentDetails['creditEntries']>([]);
    const [paymentDetails, setPaymentDetails] = useState<ArPaymentDetails>();
    const [localFilterData, setLocalFilterData] = useState<any>({});
    const dataUniqueAttribute = {
        customClass: { fieldValueLabel: 'font-medium' }
    };
    const reqSorting = {
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 0,
        pageCount: 0
    };

    const fetchPaymentDetails = async () => {
        if (!id) return;
        const res = await arPaymentService.getArPaymentDetails(id);
        setPaymentDetails(res);
        setPaymentEntries(res.invoiceEntries);
        setCreditEntries([
            ...(Array.isArray(res.creditEntries) ? res.creditEntries : []),
            ...(Array.isArray(res.advanceEntries) ? res.advanceEntries : [])
        ]);
        setLocalFilterData(generateFilterState());
    };

    useEffect(() => {
        fetchPaymentDetails();
    }, []);

    const colSchema = (tableType: 'INVOICE' | 'CREDIT') => {
        let columnNumber = 0;
        const columnSchema: ColumnDefinition[] = [
            {
                field: 'invoiceNumber',
                header:
                    tableType === 'INVOICE' ? t('PAYMENTS.INVOICE_NO') : t('PAYMENTS.CREDIT_NO'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                frozen: true,
                alignFrozen: 'left'
            },
            {
                field: 'customerName',
                header: t('PAYMENTS.CUSTOMER'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default
            },
            {
                field: 'dueDate',
                header: t('PAYMENTS.DUE_DATE'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                valueType: ValueType.Date
            },
            {
                field: tableType === 'INVOICE' ? 'transactionAmount' : 'totalCredits',
                header:
                    tableType === 'INVOICE'
                        ? t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT')
                        : t('PAYMENTS.TOTAL_CREDITS'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { transactionAmount: number; totalCredits: number }) => (
                    <span>
                        {vendorCurrencyWithAmountTemplate(
                            tableType === 'INVOICE'
                                ? rowData.transactionAmount
                                : rowData.totalCredits,
                            paymentDetails?.transactionCurrencySymbol ?? ''
                        )}
                    </span>
                )
            },
            {
                field: 'creditsApplied',
                header: t('PAYMENTS.CREDITS_APPLIED'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { creditsApplied: number }) => (
                    <span>{baseCurrencyWithAmountTemplate(rowData.creditsApplied)}</span>
                )
            },
            {
                field: tableType === 'INVOICE' ? 'totalPaidAmount' : 'availableCredits',
                header:
                    tableType === 'INVOICE'
                        ? t('PAYMENTS.TOTAL_AMOUNT_PAID')
                        : t('PAYMENTS.AVAILABLE_CREDITS'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { totalPaidAmount: number; availableCredits: number }) => (
                    <span>
                        {baseCurrencyWithAmountTemplate(
                            tableType === 'INVOICE'
                                ? rowData.totalPaidAmount
                                : rowData.availableCredits
                        )}
                    </span>
                )
            }
        ];
        return columnSchema;
    };

    const generateFilterState = () => {
        const filterState: { [key: string]: { value: any; matchMode: FilterMatchMode } } = {};
        // Default to 'INVOICE' table type for filter state generation
        colSchema('INVOICE').forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });

        colSchema('CREDIT').forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });

        setLocalFilterData(filterState);
        return filterState;
    };

    const tableDef = (tableType: 'INVOICE' | 'CREDIT') => {
        const tableDefinition: DataTableDefinition = {
            title: '',
            columns: colSchema(tableType),
            tableType: TableTypes.ACCOUNTING_PAYMENTS_DETAILS,
            emptyMessage: t('COMMON.NO_DATA_FOUND'),
            filters: localFilterData,
            reOrderableColumns: true,
            localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AR_PAYMENTS_DETAILS_COLUMN_ORDERS,
            lazyLoad: false,
            hideTableExport: false,
            hideColumnSelector: true,
            tableCustomStyle: 'p-0 !pt-0',
            customTableHeight: false
        };
        return tableDefinition;
    };

    return (
        <div>
            <TopNavigationStep
                backNavigationPath={'/accounting/ar-payments'}
                steps={[
                    {
                        label: t('COMMON.AR_PAYMENTS'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: '/accounting/ar-payments'
                    },
                    {
                        label: t('COMMON.PAYMENT') + ` ${id}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.PAYMENT'),
                        module: 'PAYMENT'
                    }
                ]}
            />

            <div className="flex flex-col gap-3 p-3 [&>div]:bg-white [&>div]:border [&>div]:rounded-md [&>div]:p-3">
                <div className="bg-white border-primary/30 !p-0">
                    <div className="!bg-primary/10 px-3 py-2">
                        <div className="flex items-center leading-4 text-black/50 font-medium">
                            {t('PAYMENTS.TOTAL_APPLIED_AMOUNT')}:
                            <span className="font-medium mx-1 text-lg text-black">
                                {baseCurrencyWithAmountTemplate(paymentDetails?.paymentAmount)}
                            </span>
                        </div>
                    </div>
                </div>

                <div>
                    <LabelName
                        name={t('PAYMENTS.PAYMENT_DETAILS')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="grid grid-cols-4 gap-4 py-2">
                        {/* Payment Number */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.RECORD_NO'),
                                fieldValue: paymentDetails?.recordNo
                            }}
                        />

                        {/* Payment Method */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_METHOD'),
                                fieldValue: paymentDetails?.paymentMethod
                            }}
                        />

                        {/* customer */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.CUSTOMER'),
                                fieldValue: paymentDetails?.company
                            }}
                        />

                        {/* Status */}
                        <div>
                            <LabelName name={t('PAYMENTS.STATUS')} />
                            {paymentDetails?.paymentStatus ? (
                                <div
                                    className={`${paymentDetails?.paymentStatus && getStatusColor(paymentDetails?.paymentStatus)} rounded-md w-fit h-fit py-0.5 px-2 font-medium mt-0.5`}>
                                    {paymentDetails?.paymentStatus}
                                </div>
                            ) : (
                                '-'
                            )}
                        </div>

                        {/* Transaction Currency */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.TRANSACTION_CURRENCY'),
                                fieldValue: paymentDetails?.transactionCurrency
                            }}
                        />

                        {/* Transaction Payment Amount */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    paymentDetails?.transactionPaymentAmount,
                                    paymentDetails?.transactionCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* Exchange Rate */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.FX_RATE'),
                                fieldValue: fxRateTemplate(
                                    Number(paymentDetails?.exchangeRateValue)
                                )
                            }}
                        />

                        {/* Payment Amount (USD) */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_AMOUNT'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    paymentDetails?.paymentAmount
                                )
                            }}
                        />

                        {/* Receipt Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.RECEIPT_DATE'),
                                fieldValue: formatDate(paymentDetails?.receiptDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Payment Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_DATE'),
                                fieldValue: formatDate(paymentDetails?.paymentDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Description */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.DESCRIPTION'),
                                fieldValue: paymentDetails?.description
                            }}
                        />
                    </div>
                </div>
                <div>
                    <LabelName
                        name={t('PAYMENTS.PAYMENT_ENTRIES')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="remove-cursor-pointer">
                        <DataTableComponent
                            tableData={paymentEntries}
                            tableDefinition={tableDef('INVOICE')}
                            tableRequestBodyData={reqSorting}
                            toggleRowData={() => {}}
                            isLazy={false}
                        />
                    </div>
                </div>
                <div>
                    <LabelName
                        name={t('PAYMENTS.CREDIT_APPLIED')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="remove-cursor-pointer">
                        <DataTableComponent
                            tableData={creditEntries}
                            tableDefinition={tableDef('CREDIT')}
                            tableRequestBodyData={reqSorting}
                            toggleRowData={() => {}}
                            isLazy={false}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ArPaymentsDetails;
