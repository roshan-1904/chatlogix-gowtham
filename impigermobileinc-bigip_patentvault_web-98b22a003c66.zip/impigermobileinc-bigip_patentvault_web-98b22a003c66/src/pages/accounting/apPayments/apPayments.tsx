import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { ApPaymentList, ApPaymentListResponse } from '../types';
import {
    baseCurrencyWithAmountTemplate,
    isVendorSpecialistUser,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { DataTableSelectEvent } from 'primereact/datatable';
import { useNavigate } from 'react-router-dom';
import { apPaymentService } from '../service/apPayments.service';
import { apAdjustmentService } from '../service/apAdjustments.service';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';

const ApPayments = () => {
    const navigate = useNavigate();
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const { roleId } = userDetails.userInfo;
    const isThisVendorSpecialistUser = isVendorSpecialistUser(roleId);
    const [paymentList, setPaymentList] = useState<ApPaymentList[]>([]);
    const [syncedDate, setSyncedDate] = useState<string>('');
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 0
    });
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const vendorSpecialistDisplayColumns = [
        'recordNo',
        'paymentDate',
        'transactionCurrencyPaidAmount',
        'paymentType',
        'status'
    ];

    const updatedColumnSchema = () => {
        if (isThisVendorSpecialistUser) {
            return columnSchema.filter((column) =>
                vendorSpecialistDisplayColumns.includes(column.field)
            );
        }
        return columnSchema;
    };

    const fetchPaymentList = async (reqBody: RequestBody) => {
        try {
            const response: ApPaymentListResponse =
                await apPaymentService.getApPaymentList(reqBody);
            if (response) {
                setPaymentList(response.paymentList);
                const pagination: paginationData = {
                    pageNo: requestBody.pageNo,
                    totalPages: Math.ceil(response.totalCount / reqBody.pageCount),
                    totalRecords: response.totalCount
                };

                setPaginationInfo(pagination);
            }
        } catch (error) {
            console.error('Error fetching Payment list:', error);
        }
    };

    const handleExportList = () => {
        apPaymentService.exportApPaymentList(requestBody);
    };

    const handleSageSync = async () => {
        await apPaymentService.sageSyncApPaymentList();
        getSyncDetails();
        fetchPaymentList(requestBody);
    };

    const getSyncDetails = async () => {
        try {
            const response = await apAdjustmentService.getSyncDetails();

            const apPaymentDate = response
                .filter((item) => item.name === 'APPAYMENT')
                .map((item) => item.lastSyncDate)
                .join(', ');
            setSyncedDate(apPaymentDate);
        } catch (error) {
            console.error('Error fetching sync details:', error);
        }
    };

    useEffect(() => {
        getSyncDetails();
    }, []);

    useEffect(() => {
        fetchPaymentList(requestBody);
    }, [requestBody]);

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'recordNo',
            header: t('PAYMENTS.RECORD_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: ApPaymentList) => (
                <span className="cursor-pointer text-primary underline font-medium">
                    {rowData.paymentNo}
                </span>
            )
        },
        {
            field: 'paymentAmount',
            header: t('PAYMENTS.PAYMENT_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: ApPaymentList) => baseCurrencyWithAmountTemplate(rowData.paymentAmount)
        },
        {
            field: 'transactionCurrencyPaidAmount',
            header: t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: ApPaymentList) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyPaidAmount,
                    rowData.currencySymbol
                )
        },
        {
            field: 'paymentDate',
            header: t('PAYMENTS.PAYMENT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'vendorId',
            header: t('PAYMENTS.VENDOR_ID'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'vendorName',
            header: t('PAYMENTS.VENDOR_NAME'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'paymentType',
            header: t('PAYMENTS.PAYMENT_METHOD'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'status',
            header: t('PAYMENTS.STATUS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'documentNumber',
            header: t('PAYMENTS.DOCUMENT_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'voidDate',
            header: t('PAYMENTS.VOID_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.AP_PAYMENTS_TABLE,
        title: isThisVendorSpecialistUser ? t('MENU.PAYMENTS') : t('MENU.AP_PAYMENTS'),
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AP_PAYMENTS_COLUMN_ORDERS,
        columns: updatedColumnSchema(),
        showResync: true,
        syncedDate: {
            dateTime: syncedDate,
            nextToDateTimeCustomText: t('COMMON.SYNC_DATE_TIME_UTC')
        },
        showResyncCustomize: {
            permission: true,
            customText: isThisVendorSpecialistUser
                ? t('PAYMENTS.VENDOR_BILL_SYNC_MSG_TOOLTIP_SYNC')
                : t('COMMON.MANUAL_SYNC')
        }
    };

    const onRowClick = (e: DataTableSelectEvent) => {
        const rowData = e.data as ApPaymentList;
        navigate(
            `${isThisVendorSpecialistUser ? '/payments' : '/accounting/ap-payments'}/${rowData.recordNo.toLowerCase()}`
        );
    };

    return (
        <div className="p-4 pb-0">
            <DataTableComponent
                tableData={paymentList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                onRowClicked={onRowClick}
                onClickReSync={() => {
                    handleSageSync();
                }}
                exportData={handleExportList}
            />
        </div>
    );
};
export default ApPayments;
