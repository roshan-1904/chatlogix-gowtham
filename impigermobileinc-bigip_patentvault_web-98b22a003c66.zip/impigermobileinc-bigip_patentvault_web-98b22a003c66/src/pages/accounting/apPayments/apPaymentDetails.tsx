import LabelName from 'components/inputs/labelName';
import ConstructField from 'components/reuseComponents/constructField';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { ApPaymentDetails } from '../types';
import { useParams } from 'react-router-dom';
import {
    baseCurrencyWithAmountTemplate,
    formatDate,
    fxRateTemplate,
    isVendorSpecialistUser,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { getStatusColor } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { FilterMatchMode } from 'primereact/api';
import { apPaymentService } from '../service/apPayments.service';
import { DATA_STORAGE_KEYS } from 'constants/index';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';
import { showToastMessage } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import { ToastType } from 'core/store/notificationStore/notificationStore';

const ApPaymentsDetails = () => {
    const id = useParams<{ id: string }>().id;
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const { roleId } = userDetails.userInfo;
    const isThisVendorSpecialistUser = isVendorSpecialistUser(roleId);
    const [billEntries, setBillEntries] = useState<ApPaymentDetails['billEntries']>([]);
    const [creditEntries, setCreditEntries] = useState<ApPaymentDetails['creditEntries']>([]);
    const [paymentDetails, setPaymentDetails] = useState<ApPaymentDetails>();
    const [localFilterData, setLocalFilterData] = useState<any>({});
    const dataUniqueAttribute = {
        customClass: { fieldValueLabel: 'font-medium' }
    };
    const reqSorting = {
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 0,
        pageCount: 0
    };

    const fetchPaymentDetails = async () => {
        if (!id) return;
        const res = await apPaymentService.getApPaymentDetails(id);
        setPaymentDetails(res);
        setBillEntries(res.billEntries);
        setCreditEntries(res.creditEntries);
        setLocalFilterData(generateFilterState());
    };

    useEffect(() => {
        fetchPaymentDetails();
    }, []);

    const colSchema = (tableType: 'BILL' | 'CREDIT') => {
        let columnNumber = 0;
        const columnSchema: ColumnDefinition[] = [
            {
                field: tableType === 'BILL' ? 'billNumber' : 'creditNumber',
                header: tableType === 'BILL' ? t('PAYMENTS.BILL_NO') : t('PAYMENTS.CREDIT_NO'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                frozen: true,
                alignFrozen: 'left'
            },
            ...(tableType === 'BILL'
                ? [
                      {
                          field: 'vendorInvoiceNumber',
                          header: t('ACCOUNTING.VENDOR_INVOICE_NUMBER'),
                          visibility: true,
                          columnNumber: columnNumber++,
                          filter: true,
                          sortable: true,
                          filterType: FilterType.Default,
                          valueType: ValueType.MultiSelect
                      }
                  ]
                : []),
            {
                field: 'dueDate',
                header: t('PAYMENTS.DUE_DATE'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                valueType: ValueType.Date
            },
            {
                field: tableType === 'BILL' ? 'transactionAmount' : 'totalCredits',
                header:
                    tableType === 'BILL'
                        ? t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT')
                        : t('PAYMENTS.TOTAL_CREDITS'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { transactionAmount: number; totalCredits: number }) => (
                    <span>
                        {vendorCurrencyWithAmountTemplate(
                            tableType === 'BILL' ? rowData.transactionAmount : rowData.totalCredits,
                            paymentDetails?.transactionCurrencySymbol ?? ''
                        )}
                    </span>
                )
            },
            {
                field: 'creditsApplied',
                header: t('PAYMENTS.CREDITS_APPLIED'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { creditsApplied: number }) => (
                    <span>{baseCurrencyWithAmountTemplate(rowData.creditsApplied)}</span>
                )
            },
            {
                field: tableType === 'BILL' ? 'totalPaidAmount' : 'availableCredits',
                header:
                    tableType === 'BILL'
                        ? t('PAYMENTS.TOTAL_AMOUNT_PAID')
                        : t('PAYMENTS.AVAILABLE_CREDITS'),
                visibility: true,
                columnNumber: columnNumber++,
                filter: true,
                sortable: true,
                filterType: FilterType.Default,
                body: (rowData: { totalPaidAmount: number; availableCredits: number }) => (
                    <span>
                        {baseCurrencyWithAmountTemplate(
                            tableType === 'BILL'
                                ? rowData.totalPaidAmount
                                : rowData.availableCredits
                        )}
                    </span>
                )
            }
        ];
        return columnSchema;
    };

    const generateFilterState = () => {
        const filterState: { [key: string]: { value: any; matchMode: FilterMatchMode } } = {};
        // Default to 'BILL' table type for filter state generation
        colSchema('BILL').forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });

        colSchema('CREDIT').forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });

        setLocalFilterData(filterState);
        return filterState;
    };

    const tableDef = (tableType: 'BILL' | 'CREDIT') => {
        const tableDefinition: DataTableDefinition = {
            title: '',
            columns: colSchema(tableType),
            tableType: TableTypes.ACCOUNTING_PAYMENTS_DETAILS,
            emptyMessage: t('COMMON.NO_DATA_FOUND'),
            filters: localFilterData,
            reOrderableColumns: true,
            localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AP_PAYMENTS_DETAILS_COLUMN_ORDERS,
            lazyLoad: false,
            hideTableExport: false,
            hideColumnSelector: true,
            tableCustomStyle: 'p-0 !pt-0',
            customTableHeight: false
        };
        return tableDefinition;
    };

    const exportBillEntries = () => {
        try {
            apPaymentService.exportApPaymentBillEntries(id ?? '');
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.EXPORT_QUOTE_AND_ORDER_LIST'),
                ToastType.ERROR
            );
        }
    };

    return (
        <div>
            <TopNavigationStep
                backNavigationPath={
                    isThisVendorSpecialistUser ? '/payments' : '/accounting/ap-payments'
                }
                steps={[
                    {
                        label: isThisVendorSpecialistUser
                            ? t('COMMON.PAYMENTS')
                            : t('COMMON.AP_PAYMENTS'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: isThisVendorSpecialistUser
                            ? '/payments'
                            : '/accounting/ap-payments'
                    },
                    {
                        label: ` ${id}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.PAYMENT'),
                        module: 'PAYMENT'
                    }
                ]}
            />

            <div className="flex flex-col gap-3 p-3 [&>div]:bg-white [&>div]:border [&>div]:rounded-md [&>div]:p-3">
                <div className="bg-white border-primary/30 !p-0">
                    <div className="!bg-primary/10 px-3 py-2">
                        <div className="flex items-center leading-4 text-black/50 font-medium">
                            {t('PAYMENTS.TOTAL_APPLIED_AMOUNT')}:
                            <span className="font-medium mx-1 text-lg text-black">
                                {baseCurrencyWithAmountTemplate(paymentDetails?.paymentAmount)}
                            </span>
                        </div>
                    </div>
                </div>

                <div>
                    <LabelName
                        name={t('PAYMENTS.PAYMENT_DETAILS')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="grid grid-cols-4 gap-4 py-2">
                        {/* Payment Number */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.RECORD_NO'),
                                fieldValue: paymentDetails?.paymentNumber
                            }}
                        />

                        {/* Payment Method */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_METHOD'),
                                fieldValue: paymentDetails?.paymentMethod
                            }}
                        />

                        {/* Vendor ID */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.VENDOR_ID'),
                                fieldValue: paymentDetails?.vendorId,
                                hidden: isThisVendorSpecialistUser
                            }}
                        />

                        {/* Vendor Name */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.VENDOR_NAME'),
                                fieldValue: paymentDetails?.vendorName,
                                hidden: isThisVendorSpecialistUser
                            }}
                        />

                        {/* Transaction Currency */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.TRANSACTION_CURRENCY'),
                                fieldValue: paymentDetails?.transactionCurrency,
                                hidden: isThisVendorSpecialistUser
                            }}
                        />

                        {/* Transaction Payment Amount */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.TRANSACTION_PAYMENT_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    paymentDetails?.transactionPaymentAmount,
                                    paymentDetails?.transactionCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* Payment Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_DATE'),
                                fieldValue: formatDate(paymentDetails?.paymentDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Exchange Rate */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.FX_RATE'),
                                fieldValue: fxRateTemplate(
                                    Number(paymentDetails?.exchangeRateValue)
                                ),
                                hidden: isThisVendorSpecialistUser
                            }}
                        />

                        {/* Payment Amount (USD) */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.PAYMENT_AMOUNT'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    paymentDetails?.paymentAmount
                                ),
                                hidden: isThisVendorSpecialistUser
                            }}
                        />

                        {/* Status */}
                        <div>
                            <LabelName name={t('PAYMENTS.STATUS')} />
                            {paymentDetails?.paymentStatus ? (
                                <div
                                    className={`${paymentDetails?.paymentStatus && getStatusColor(paymentDetails?.paymentStatus)} rounded-md w-fit h-fit py-0.5 px-2 font-medium mt-0.5`}>
                                    {paymentDetails?.paymentStatus}
                                </div>
                            ) : (
                                '-'
                            )}
                        </div>

                        {/* Description */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('PAYMENTS.DESCRIPTION'),
                                fieldValue: paymentDetails?.description,
                                hidden: isThisVendorSpecialistUser
                            }}
                        />
                    </div>
                </div>
                <div>
                    <div className="flex justify-between">
                        <LabelName
                            name={t('PAYMENTS.BILL_ENTRIES')}
                            customStyle={{
                                nameStyle: 'text-lg font-medium text-primary'
                            }}
                        />
                        <button
                            className="export-button btn border-neutral-100 hover:border-primary min-h-9 h-9"
                            onClick={exportBillEntries}>
                            Export
                        </button>
                    </div>
                    <div className="remove-cursor-pointer">
                        <DataTableComponent
                            tableData={billEntries}
                            tableDefinition={tableDef('BILL')}
                            tableRequestBodyData={reqSorting}
                            toggleRowData={() => {}}
                            isLazy={false}
                        />
                    </div>
                </div>
                <div>
                    <LabelName
                        name={t('PAYMENTS.CREDIT_APPLIED')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="remove-cursor-pointer">
                        <DataTableComponent
                            tableData={creditEntries}
                            tableDefinition={tableDef('CREDIT')}
                            tableRequestBodyData={reqSorting}
                            toggleRowData={() => {}}
                            isLazy={false}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ApPaymentsDetails;
