import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import AccountingBilling from './billing';
import { BillingsDataItem } from '../types';
import AuthStore from 'core/store/authStore/authStore';
import { getBillingList, getVendorInvoiceDocuments } from '../service/billing.service';

jest.mock('components/fileUpload/services/azureStorage.service');

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

jest.mock('core/store/authStore/authStore');
jest.mock('../service/billing.service');

jest.mock('i18next', () => {
    return {
        t: jest.fn()
    };
});

const mockBillingData: BillingsDataItem[] = [
    {
        id: 1,
        billNo: 'BILL001',
        dueDate: '2023-10-01',
        vendorName: 'Vendor 1',
        isvendorDocument: true,
        vendorDocuments: [
            {
                fileId: 1,
                fileName: 'document1.pdf',
                fileType: 'application/pdf',
                fileSize: '1024',
                id: 0,
                documentId: 0,
                uploadedOn: '',
                documentType: '',
                uploadedBy: ''
            }
        ],
        sageStatusSyncName: 'Failed',
        sageSyncDetails: '{}',
        requestNumber: '',
        billDate: '',
        status: '',
        vendorId: '',
        sageSyncStatus: 0,
        sageSyncDate: '',
        sageSyncError: [],
        sageInvoice: '',
        sageAmount: '',
        updatedAt: '',
        billingTerm: '',
        billAmount: '',
        companyName: ''
    }
];

describe('AccountingBilling Component', () => {
    beforeEach(() => {
        AuthStore.hasPermission = jest.fn().mockReturnValue(true);
        AuthStore.getUserInfo = jest.fn().mockReturnValue({ userInfo: { roleId: 1 } });
        (getBillingList as jest.Mock).mockResolvedValue({
            requestBillService: mockBillingData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 1
        });
        (getVendorInvoiceDocuments as jest.Mock).mockResolvedValue({
            vendorDocumentsModel: mockBillingData[0].vendorDocuments,
            blobUri: 'http://example.com/blob'
        });
    });

    test('renders the component', () => {
        render(<AccountingBilling />);
        expect(screen.getByTestId('BillingSection')).toBeInTheDocument();
    });

    test('renders billing table with data', async () => {
        render(<AccountingBilling />);
        expect(await screen.findByText('BILL001')).toBeInTheDocument();
        expect(screen.getByText('Vendor 1')).toBeInTheDocument();
    });

    test('renders due date cell with correct class', async () => {
        render(<AccountingBilling />);
        const dueDateCell = await screen.findByText('2023-10-01');
        expect(dueDateCell).toHaveClass('text-black');
    });

    test('renders vendor documents cell with tooltip', async () => {
        render(<AccountingBilling />);
        const documentIcon = await screen.findByText('document1.pdf');
        expect(documentIcon).toBeInTheDocument();
    });

    test('renders bill number as link', async () => {
        render(<AccountingBilling />);
        const billLink = await screen.findByText('BILL001');
        expect(billLink).toHaveAttribute('href', '/account-bills/details/1');
    });

    test('handles resync button click', async () => {
        render(<AccountingBilling />);
        const resyncButton = await screen.findByTestId('resync-button-1');
        fireEvent.click(resyncButton);
        expect(getBillingList).toHaveBeenCalledTimes(2);
    });
});
