import vendorProfileIcon from 'assets/svgs/vendor-profile.svg';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { END_POINT } from 'constants/endPoint';
import { PATHS } from 'constants/routes.constant';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import utils, {
    formatDate,
    getWindowSize,
    isFinanceUser,
    isVendorSpecialistUser,
    showToastMessage
} from 'core/utils/utils';
import { t } from 'i18next';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { useEffect, useState } from 'react';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import {
    getBillingList,
    getVendorInvoiceDocuments,
    resyncBillingAll,
    resyncBillingByID
} from '../service/billing.service';
import {
    BillingTableColumnKeys,
    generateBillingTableColumnSchema
} from '../tableSchema/billing.schema';
import { BillingsDataItem } from '../types';
import { Permissions } from 'constants/permissions';
import AuthStore from 'core/store/authStore/authStore';
import ProgressStatusIndicator from 'shared/dataTable/components/progressStatusIndicator/progressStatusIndicator';
import {
    VendorInvoiceDocumentsData,
    VendorInvoiceDocumentsResponse
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dialog } from 'primereact/dialog';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { previewDialogPopup } from 'constants/styles.constant';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import { Link } from 'react-router-dom';
import LinkNavigation from 'pages/components/linkNavigation/linkNavigation';

const AccountingBilling = () => {
    const userInfo = AuthStore.getUserInfo();
    const loggedInUserRoleId = userInfo.userInfo.roleId;
    const isThisV3User = isVendorSpecialistUser(loggedInUserRoleId);

    const isAccount: boolean =
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE);
    const isBillsPermission = AuthStore.hasPermission(Permissions.VIEW_BILLS);
    const [tableData, setTableData] = useState<BillingsDataItem[]>([]);
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.ACCOUNTING_BILLINGS_COLUMN_ORDERS;
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 2,
        totalRecords: 20
    });

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const isShowResync = AuthStore.hasPermission(Permissions.RESYNC_BILLS);
    useEffect(() => {
        fetchBillingList();
    }, [requestBody]);

    const renderDueDateCell = (rowData: BillingsDataItem) => {
        const dueDate = new Date(rowData.dueDate);
        const currentDate = new Date();
        dueDate.setHours(0, 0, 0, 0);
        currentDate.setHours(0, 0, 0, 0);
        const isDateCrossDue = rowData.dueDate && dueDate < currentDate;

        return (
            <div className={!isDateCrossDue ? 'text-black' : 'text-red-500'}>
                {rowData.dueDate ? formatDate(rowData.dueDate) : '-'}
            </div>
        );
    };

    const renderVendorCell = (rowData: BillingsDataItem) => {
        return (
            <div className="flex md:items-center">
                <img src={vendorProfileIcon} alt="" className="h-[1.13rem] mt-[0.18rem] mr-1" />
                <span className="ml-1">{rowData.vendorName}</span>
            </div>
        );
    };

    const renderVendorDocumentsCell = (rowData: BillingsDataItem) => {
        return (
            <>
                {rowData.isvendorDocument ? (
                    <div className="flex md:items-center">
                        {rowData.vendorDocuments &&
                            rowData.vendorDocuments.length > 0 &&
                            rowData.vendorDocuments.map((document: VendorInvoiceDocumentsData) => (
                                <>
                                    <Tooltip
                                        position="top"
                                        pt={{
                                            root: { className: 'shadow-none ' },
                                            text: { className: 'text-xs' }
                                        }}
                                        target={'.fileNameTooltip' + document.fileId}
                                        content={document.fileName}></Tooltip>
                                    <span
                                        key={document.fileId}
                                        onClick={() => handlePreviewDocument(document)}
                                        onKeyDown={(event) => {
                                            if (event.key === 'Enter') {
                                                handlePreviewDocument(document);
                                            }
                                        }}
                                        className={
                                            'fileNameTooltip' +
                                            document.fileId +
                                            ' w-[1.5rem] mt-[0.18rem] mr-1'
                                        }>
                                        {fileTypeIcon(document.fileType)}
                                    </span>
                                </>
                            ))}
                    </div>
                ) : (
                    <>-</>
                )}
            </>
        );
    };

    const renderBillNumber = ({ id, billNo }: BillingsDataItem) => {
        return (
            <LinkNavigation
                text={billNo}
                url={`/${isAccount ? PATHS.ACCOUNT_BILLS : PATHS.BILLS}/details/${id}`}
            />
        );
    };

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    function exportData() {
        try {
            const exportURL = `${END_POINT.ACCOUNTING.EXPORT_BILL_LIST}`;
            SettingsService.exportData(requestBody, exportURL, 'bill_lists.xlsx');
        } catch (error) {
            console.error(error);
            showToastMessage({
                type: ToastType.ERROR,
                message: t('COMPANIES.ERROR_MESSAGE.EXPORT_COMPANIES_LIST')
            });
        }
    }

    const fetchBillingList = async () => {
        try {
            const response = await getBillingList(requestBody);
            setTableData(response?.requestBillService);
            setPaginationInfo({
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            });

            response?.requestBillService.forEach((bill) => {
                if (bill.isvendorDocument) {
                    fetchBillingDocument(bill.id, response?.requestBillService);
                }
            });
        } catch (error) {
            console.error('Error fetching dynamic form information:', error);
            throw error;
        }
    };

    const fetchBillingDocument = async (id: number, billingList: BillingsDataItem[]) => {
        try {
            const payload = {
                searchModels: [],
                sorting: {
                    propertyName: '',
                    value: ''
                },
                pageNo: 1,
                pageCount: 100
            };
            const response: VendorInvoiceDocumentsResponse = await getVendorInvoiceDocuments(
                String(id),
                payload
            );

            setBlobURL(response.blobUri);

            if (response) {
                const updatedTableData = billingList.map((bill) => {
                    if (bill.id === id) {
                        bill.vendorDocuments =
                            response.vendorDocumentsModel as VendorInvoiceDocumentsData[];
                    }
                    return bill;
                });

                setTableData(updatedTableData);
            }
        } catch (error) {
            console.error('Error fetching dynamic form information:', error);
            throw error;
        }
    };

    const renderReSync = (rowData: BillingsDataItem) => {
        const isValidShow: boolean =
            rowData.sageStatusSyncName === 'Failed' || rowData.sageStatusSyncName === 'Error';
        const handleReSyncClick = (e: React.MouseEvent | React.KeyboardEvent) => {
            e.stopPropagation();
            resyncBillingByID(rowData?.id || 0)
                .then((response) => {
                    if (response) {
                        fetchBillingList();
                    }
                })
                .catch((error) => {
                    console.error(error);
                });
        };
        return (
            <div style={{ display: 'flex', width: '100%' }}>
                <div style={{ width: '100%' }}>
                    <ProgressStatusIndicator
                        syncStatus={rowData?.sageStatusSyncName}
                        sageSyncError={JSON.parse(rowData.sageSyncDetails)}
                    />
                </div>
                {isValidShow && isShowResync && (
                    <button
                        data-testid={'resync-button-' + rowData.id}
                        style={{ width: '100%', textAlign: 'left' }}
                        onClick={(e) => {
                            handleReSyncClick(e);
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && handleReSyncClick(e)}>
                        <i className="pi pi-refresh" />
                    </button>
                )}
            </div>
        );
    };

    const buttonChildren = () => {
        const middlewareURL = `${process.env.REACT_APP_MIDDLEWARE_URL}`;
        return (
            (isFinanceUser(userInfo.userInfo.roleId) && (
                <Link
                    to={middlewareURL}
                    target="_blank"
                    data-testid="create-ip-instruction-deadline-button"
                    className="btn  btn-sm  text-white font-medium bg-primary hover:bg-primary-200">
                    {t('ACCOUNTING.PROCESS_PAYMENT')}
                </Link>
            )) || <></>
        );
    };

    const columnSchema: ColumnDefinition[] = generateBillingTableColumnSchema(
        {
            billNo: renderBillNumber,
            dueDate: renderDueDateCell,
            vendorName: renderVendorCell,
            vendorDocuments: renderVendorDocumentsCell,
            renderReSync
        },
        isAccount,
        isBillsPermission
    );
    const updatedColumnSchema = columnSchema.map((column) => {
        if (column.field === BillingTableColumnKeys.STATUS.toString()) {
            return {
                ...column,
                tooltip: {
                    isShow: isThisV3User,
                    uniqueColumnName: BillingTableColumnKeys.BILL_NO,
                    content: t('ACCOUNTING.BILLING_STATUS_TOOLTIP_V3_USER'),
                    className: ''
                }
            };
        } else return column;
    });

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.ACCOUNTING_BILLINGS_TABLE,
        reOrderableColumns: true,
        columns: updatedColumnSchema,
        emptyMessage: '',
        filters: {},
        localStorageKey: storageKey,
        title: 'Bills',
        buttonChildren: buttonChildren(),
        showResync: isShowResync,
        hideTableExport: AuthStore.hasPermission(Permissions.DOWNLOAD_BILLS)
    };
    // const onRowClicked = (e: DataTableSelectEvent) => {
    //     if (e?.data?.id) {
    //         window.location.href = `/${isAccount ? PATHS.ACCOUNT_BILLS : PATHS.BILLS}/details/${e.data.id}`;
    //     }
    // };
    const onClickReSync = () => {
        resyncBillingAll();
    };

    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');

    // Fetching SAS URL on component mount
    useEffect(() => {
        getSasUrlApi();
    }, []);

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;

        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    return (
        <div data-testid="BillingSection">
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                            onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                    utils.handleDownloadPngSvg(previewImage, previewImageName);
                                }
                            }}
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>

            <div data-testid="BillingTableSection" className="p-4 pb-0">
                <DataTableComponent
                    data-testid="BillingTable"
                    tableData={tableData}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    handleFilter={handleFilter}
                    handleSort={sortHandler}
                    toggleRowData={() => {}}
                    tablePaginationData={paginationInfo}
                    handlePagination={handlePageChange}
                    exportData={exportData}
                    // onRowClicked={onRowClicked}
                    onClickReSync={onClickReSync}
                />
            </div>
        </div>
    );
};

export default AccountingBilling;
