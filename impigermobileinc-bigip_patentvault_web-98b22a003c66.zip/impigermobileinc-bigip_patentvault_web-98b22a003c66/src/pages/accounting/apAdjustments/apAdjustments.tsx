import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';

import { ApAdjustmentList, ApAdjustmentListResponse } from '../types';
import { baseCurrencyWithAmountTemplate, vendorCurrencyWithAmountTemplate } from 'core/utils/utils';
import { useNavigate } from 'react-router-dom';
import { DataTableSelectEvent } from 'primereact/datatable';
import { apAdjustmentService } from '../service/apAdjustments.service';

const ApAdjustments = () => {
    const navigate = useNavigate();
    const [adjustmentList, setAdjustmentList] = useState<ApAdjustmentList[]>([]);
    const [syncedDate, setSyncedDate] = useState<string>('');
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 0
    });
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const fetchAdjustmentList = async (reqBody: RequestBody) => {
        try {
            // Assuming apAdjustmentService.getApAdjustmentList is a function that fetches the data
            const response: ApAdjustmentListResponse =
                await apAdjustmentService.getApAdjustmentList(reqBody);
            if (response) {
                setAdjustmentList(response.adjustmentList);

                const pagination: paginationData = {
                    pageNo: requestBody.pageNo,
                    totalPages: Math.ceil(response.totalCount / reqBody.pageCount),
                    totalRecords: response.totalCount
                };

                setPaginationInfo(pagination);
            }
        } catch (error) {
            console.error('Error fetching adjustment list:', error);
        }
    };

    const onRowClick = (e: DataTableSelectEvent) => {
        const rowData = e.data as ApAdjustmentList;
        navigate(`/accounting/ap-adjustments/${rowData.recordNo.toLowerCase()}`);
    };

    const handleExportList = () => {
        apAdjustmentService.exportApAdjustmentList(requestBody);
    };

    const handleSageSync = async () => {
        await apAdjustmentService.sageSyncApAdjustmentList();
        getSyncDetails();
        fetchAdjustmentList(requestBody);
    };

    const getSyncDetails = async () => {
        try {
            const response = await apAdjustmentService.getSyncDetails();

            const apAdjustmentDate = response
                .filter((item) => item.name === 'APADJUSTMENT')
                .map((item) => item.lastSyncDate)
                .join(', ');
            setSyncedDate(apAdjustmentDate);
        } catch (error) {
            console.error('Error fetching sync details:', error);
        }
    };

    useEffect(() => {
        getSyncDetails();
    }, []);

    useEffect(() => {
        fetchAdjustmentList(requestBody);
    }, [requestBody]);

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'recordNo',
            header: t('ADJUSTMENTS.RECORD_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { recordNo: string }) => (
                <span className="cursor-pointer text-primary underline font-medium">
                    {rowData.recordNo}
                </span>
            )
        },
        {
            field: 'adjustmentNo',
            header: t('ADJUSTMENTS.ADJUSTMENT_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'referenceBillNo',
            header: t('ADJUSTMENTS.REFERENCE_BILL_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'adjustmentDate',
            header: t('ADJUSTMENTS.ADJUSTMENT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'adjustmentType',
            header: t('ADJUSTMENTS.ADJUSTMENT_TYPE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'description',
            header: t('ADJUSTMENTS.DESCRIPTION'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { description: string }) => (
                <div className="w-52">
                    <p className="truncate">{rowData.description}</p>
                </div>
            )
        },
        {
            field: 'adjustmentStatus',
            header: t('ADJUSTMENTS.ADJUSTMENT_STATUS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'vendorName',
            header: t('ADJUSTMENTS.VENDOR_NAME'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'glPostingDate',
            header: t('ADJUSTMENTS.GL_POSTING_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'transactionCurrencyTotal',
            header: t('ADJUSTMENTS.TRANSACTION_ADJUSTMENT_TOTAL'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { transactionCurrencyTotal: number; vendorCurrencySymbol: string }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyTotal,
                    rowData.vendorCurrencySymbol
                )
        },
        {
            field: 'transactionCurrencyPaid',
            header: t('ADJUSTMENTS.TRANSACTION_PAID_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { transactionCurrencyPaid: number; vendorCurrencySymbol: string }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyPaid,
                    rowData.vendorCurrencySymbol
                )
        },
        {
            field: 'transactionCurrencyBalance',
            header: t('ADJUSTMENTS.TRANSACTION_ADJUSTMENT_BALANCE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { transactionCurrencyBalance: number; vendorCurrencySymbol: string }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyBalance,
                    rowData.vendorCurrencySymbol
                )
        },
        {
            field: 'adjustmentTotal',
            header: t('ADJUSTMENTS.ADJUSTMENT_TOTAL'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { adjustmentTotal: number }) =>
                baseCurrencyWithAmountTemplate(rowData.adjustmentTotal)
        },
        {
            field: 'paidAmount',
            header: t('ADJUSTMENTS.PAID_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { paidAmount: number }) =>
                baseCurrencyWithAmountTemplate(rowData.paidAmount)
        },
        {
            field: 'adjustmentBalance',
            header: t('ADJUSTMENTS.ADJUSTMENT_BALANCE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { adjustmentBalance: number }) =>
                baseCurrencyWithAmountTemplate(rowData.adjustmentBalance)
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.AP_ADJUSTMENTS_TABLE,
        title: t('MENU.AP_ADJUSTMENTS'),
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AP_ADJUSTMENTS_COLUMN_ORDERS,
        columns: columnSchema,
        showResync: true,
        syncedDate: {
            dateTime: syncedDate,
            nextToDateTimeCustomText: t('COMMON.SYNC_DATE_TIME_UTC')
        },
        showResyncCustomize: {
            permission: true,
            customText: t('COMMON.MANUAL_SYNC')
        }
    };

    return (
        <div className="p-4 pb-0">
            <DataTableComponent
                tableData={adjustmentList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                onRowClicked={onRowClick}
                exportData={handleExportList}
                onClickReSync={() => {
                    handleSageSync();
                }}
            />
        </div>
    );
};
export default ApAdjustments;
