import LabelName from 'components/inputs/labelName';
import ConstructField from 'components/reuseComponents/constructField';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { ArAdjustmentDetails } from '../types';
import { arAdjustmentService } from '../service/arAdjustment.service';
import { useParams } from 'react-router-dom';
import {
    baseCurrencyWithAmountTemplate,
    formatDate,
    fxRateTemplate,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { getStatusColor } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { FilterType, TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import { FilterMatchMode } from 'primereact/api';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';

const ArAdjustmentsDetails = () => {
    const id = useParams<{ id: string }>().id;
    const [paymentEntries, setPaymentEntries] = useState<ArAdjustmentDetails['entries']>([]);
    const [adjustmentDetails, setAdjustmentDetails] = useState<ArAdjustmentDetails>();
    const [localFilterData, setLocalFilterData] = useState<any>({});
    const dataUniqueAttribute = {
        customClass: { fieldValueLabel: 'font-medium' }
    };
    const reqSorting = {
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 0,
        pageCount: 0
    };

    const fetchAdjustmentDetails = async () => {
        if (!id) return;
        const res = await arAdjustmentService.getArAdjustmentDetails(id);
        setAdjustmentDetails(res);
        setPaymentEntries(res.entries);
        setLocalFilterData(generateFilterState());
    };

    useEffect(() => {
        fetchAdjustmentDetails();
    }, []);

    let columnNumber = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'glAccountName',
            header: t('ADJUSTMENTS.GL_ACCOUNT_NUMBER'),
            visibility: true,
            columnNumber: columnNumber++,
            filter: true,
            sortable: true,
            filterType: FilterType.Default
        },
        {
            field: 'transactionCurrencyAmount',
            header: t('ADJUSTMENTS.TRANSACTION_AMOUNT'),
            visibility: true,
            columnNumber: columnNumber++,
            filter: true,
            sortable: true,
            filterType: FilterType.Default,
            body: (rowData: { transactionCurrencyAmount: string | number | null | undefined }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyAmount,
                    adjustmentDetails?.vendorCurrencySymbol ?? ''
                )
        },
        {
            field: 'baseCurrencyAmount',
            header: t('ADJUSTMENTS.AMOUNT_IN_USD'),
            visibility: true,
            columnNumber: columnNumber++,
            filter: true,
            sortable: true,
            filterType: FilterType.Default,
            body: (rowData: { baseCurrencyAmount: string | number | null | undefined }) =>
                baseCurrencyWithAmountTemplate(rowData.baseCurrencyAmount)
        },
        {
            field: 'memo',
            header: t('ADJUSTMENTS.MEMO'),
            visibility: true,
            columnNumber: columnNumber++,
            filter: true,
            sortable: true,
            filterType: FilterType.Default
        }
    ];

    const generateFilterState = () => {
        const filterState: { [key: string]: { value: any; matchMode: FilterMatchMode } } = {};
        columnSchema.forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });
        setLocalFilterData(filterState);
        return filterState;
    };

    const tableDefinition: DataTableDefinition = {
        title: '',
        columns: columnSchema,
        tableType: TableTypes.ACCOUNTING_ADJUSTMENTS_DETAILS,
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        filters: localFilterData,
        reOrderableColumns: true,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AR_ADJUSTMENTS_DETAILS_COLUMN_ORDERS,
        lazyLoad: false,
        hideTableExport: false,
        hideColumnSelector: true,
        tableCustomStyle: 'p-0 !pt-0',
        customTableHeight: false
    };

    return (
        <div>
            <TopNavigationStep
                backNavigationPath={'/accounting/ar-adjustments'}
                steps={[
                    {
                        label: t('COMMON.AR_ADJUSTMENTS'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: '/accounting/ar-adjustments'
                    },
                    {
                        label: ` ${id}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.ADJUSTMENT'),
                        module: 'ADJUSTMENT'
                    }
                ]}
            />

            <div className="flex flex-col gap-3 p-3 [&>div]:bg-white [&>div]:border [&>div]:rounded-md [&>div]:p-3">
                <div>
                    <LabelName
                        name={t('ADJUSTMENTS.ADJUSTMENT_DETAILS')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="grid grid-cols-4 gap-4 py-2">
                        {/* Adjustment Type */}
                        <div>
                            <LabelName name={t('ADJUSTMENTS.ADJUSTMENT_TYPE')} />
                            {adjustmentDetails?.adjustmentType ? (
                                <div
                                    className={`${getStatusColor(adjustmentDetails?.adjustmentType)} rounded-md w-fit h-fit py-0.5 px-2 font-medium mt-0.5`}>
                                    {adjustmentDetails?.adjustmentType}
                                </div>
                            ) : (
                                '-'
                            )}
                        </div>

                        {/* Adjustment No */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.ADJUSTMENT_NO'),
                                fieldValue: adjustmentDetails?.adjustmentNumber
                            }}
                        />

                        {/* Customer Name */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.CUSTOMER'),
                                fieldValue: adjustmentDetails?.customerName
                            }}
                        />

                        {/* Status */}
                        <div>
                            <LabelName name={t('ADJUSTMENTS.ADJUSTMENT_STATUS')} />
                            {adjustmentDetails?.adjustmentStatus ? (
                                <div
                                    className={`${getStatusColor(adjustmentDetails?.adjustmentStatus)} rounded-md w-fit h-fit py-0.5 px-2 font-medium mt-0.5`}>
                                    {adjustmentDetails?.adjustmentStatus}
                                </div>
                            ) : (
                                '-'
                            )}
                        </div>

                        {/* Department */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.DEPARTMENT_ID'),
                                fieldValue: adjustmentDetails?.departmentIdAndName
                            }}
                        />

                        {/* Reference Bill No */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.REFERENCE_INVOICE_NO'),
                                fieldValue: adjustmentDetails?.referenceInvoiceNo
                            }}
                        />

                        {/* Adjustment Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.ADJUSTMENT_DATE'),
                                fieldValue: formatDate(adjustmentDetails?.adjustmentDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* GL Posting Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.GL_POSTING_DATE'),
                                fieldValue: formatDate(adjustmentDetails?.glPostingDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Transaction Currency */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.TRANSACTION_CURRENCY'),
                                fieldValue: adjustmentDetails?.vendorCurrency
                            }}
                        />

                        {/* Transaction Currency Amount */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.TRANSACTION_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    adjustmentDetails?.transactionCurrencyAmount,
                                    adjustmentDetails?.vendorCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* Transaction Paid Amount*/}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.TRANSACTION_PAID_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    adjustmentDetails?.transactionCurrencyPaid,
                                    adjustmentDetails?.vendorCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* Transaction Balance Amount*/}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.TRANSACTION_BALANCE_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    adjustmentDetails?.transactionCurrencyBalance,
                                    adjustmentDetails?.vendorCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* FX Rate */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.FX_RATE'),
                                fieldValue: fxRateTemplate(Number(adjustmentDetails?.exchangeRate))
                            }}
                        />

                        {/* Amount in USD */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.AMOUNT_IN_USD'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    adjustmentDetails?.adjustmentTotal
                                )
                            }}
                        />

                        {/* Paid Amount */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.PAID_AMOUNT'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    adjustmentDetails?.paidAmount
                                )
                            }}
                        />

                        {/* Adjustment Balance */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADJUSTMENTS.ADJUSTMENT_BALANCE'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    adjustmentDetails?.adjustmentBalance
                                )
                            }}
                        />

                        {/* Document Submitted */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('COMMON.ATTACHMENTS'),
                                fieldValue: adjustmentDetails?.isDocumentUploaded
                            }}
                        />

                        {/* Description */}
                        <div>
                            <LabelName name={t('ADJUSTMENTS.DESCRIPTION')} />
                            {adjustmentDetails?.description ? (
                                <p className="font-medium max-h-28 overflow-auto">
                                    {adjustmentDetails?.description}
                                </p>
                            ) : (
                                '-'
                            )}
                        </div>
                    </div>
                </div>
                <div>
                    <LabelName
                        name={t('ADJUSTMENTS.PAYMENT_ENTRIES')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="remove-cursor-pointer">
                        <DataTableComponent
                            tableData={paymentEntries}
                            tableDefinition={tableDefinition}
                            tableRequestBodyData={reqSorting}
                            toggleRowData={() => {}}
                            isLazy={false}
                            handleFilter={(e) => {
                                setLocalFilterData(e.filters);
                            }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ArAdjustmentsDetails;
