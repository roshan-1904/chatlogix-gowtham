import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { arAdjustmentService } from '../service/arAdjustment.service';
import { ArAdjustmentList, ArAdjustmentListResponse } from '../types';
import { baseCurrencyWithAmountTemplate, vendorCurrencyWithAmountTemplate } from 'core/utils/utils';
import { useNavigate } from 'react-router-dom';
import { DataTableSelectEvent } from 'primereact/datatable';

const ArAdjustments = () => {
    const navigate = useNavigate();
    const [adjustmentList, setAdjustmentList] = useState<ArAdjustmentList[]>([]);
    const [syncedDate, setSyncedDate] = useState<string>('');
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 0
    });
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const fetchAdjustmentList = async (reqBody: RequestBody) => {
        try {
            // Assuming arAdjustmentService.getArAdjustmentList is a function that fetches the data
            const response: ArAdjustmentListResponse =
                await arAdjustmentService.getArAdjustmentList(reqBody);
            if (response) {
                setAdjustmentList(response.arAdjustmentList);

                const pagination: paginationData = {
                    pageNo: requestBody.pageNo,
                    totalPages: Math.ceil(response.totalCount / reqBody.pageCount),
                    totalRecords: response.totalCount
                };

                setPaginationInfo(pagination);
            }
        } catch (error) {
            console.error('Error fetching adjustment list:', error);
        }
    };

    const onRowClick = (e: DataTableSelectEvent) => {
        const rowData = e.data as ArAdjustmentList;
        navigate(`/accounting/ar-adjustments/${String(rowData.recordNo).toLowerCase()}`);
    };

    const handleExportList = () => {
        arAdjustmentService.exportArAdjustmentList(requestBody);
    };

    const handleSageSync = async () => {
        await arAdjustmentService.sageSyncArAdjustmentList();
        getSyncDetails();
        fetchAdjustmentList(requestBody);
    };

    const getSyncDetails = async () => {
        try {
            const response = await arAdjustmentService.getSyncDetails();

            const arAdjustmentDate = response
                .filter((item) => item.name === 'ARADJUSTMENT')
                .map((item) => item.lastSyncDate)
                .join(', ');
            setSyncedDate(arAdjustmentDate);
        } catch (error) {
            console.error('Error fetching sync details:', error);
        }
    };

    useEffect(() => {
        getSyncDetails();
    }, []);

    useEffect(() => {
        fetchAdjustmentList(requestBody);
    }, [requestBody]);

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'recordNo',
            header: t('ADJUSTMENTS.RECORD_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { recordNo: string }) => (
                <span className="cursor-pointer text-primary underline font-medium">
                    {rowData.recordNo}
                </span>
            )
        },
        {
            field: 'adjustmentNumber',
            header: t('ADJUSTMENTS.ADJUSTMENT_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'customerName',
            header: t('ADJUSTMENTS.CUSTOMER'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'adjustmentStatus',
            header: t('ADJUSTMENTS.ADJUSTMENT_STATUS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'referenceInvoiceNo',
            header: t('ADJUSTMENTS.REFERENCE_INVOICE_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'adjustmentDate',
            header: t('ADJUSTMENTS.ADJUSTMENT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'adjustmentType',
            header: t('ADJUSTMENTS.ADJUSTMENT_TYPE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'transactionCurrency',
            header: t('ADJUSTMENTS.CURRENCY'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'transactionCurrencyTotal',
            header: t('ADJUSTMENTS.TRANSACTION_ADJUSTMENT_TOTAL'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: {
                transactionCurrencyTotal: number;
                transactionCurrencySymbol: string;
            }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyTotal,
                    rowData.transactionCurrencySymbol
                )
        },
        {
            field: 'transactionCurrencyPaid',
            header: t('ADJUSTMENTS.TRANSACTION_AMOUNT_PAID'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: {
                transactionCurrencyPaid: number;
                transactionCurrencySymbol: string;
            }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyPaid,
                    rowData.transactionCurrencySymbol
                )
        },
        {
            field: 'transactionCurrencyBalance',
            header: t('ADJUSTMENTS.TRANSACTION_ADJUSTMENT_BALANCE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: {
                transactionCurrencyBalance: number;
                transactionCurrencySymbol: string;
            }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionCurrencyBalance,
                    rowData.transactionCurrencySymbol
                )
        },
        {
            field: 'adjustmentTotal',
            header: t('ADJUSTMENTS.ADJUSTMENT_TOTAL'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { adjustmentTotal: number }) =>
                baseCurrencyWithAmountTemplate(rowData.adjustmentTotal)
        },
        {
            field: 'paidAmount',
            header: t('ADJUSTMENTS.AMOUNT_PAID'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { paidAmount: number }) =>
                baseCurrencyWithAmountTemplate(rowData.paidAmount)
        },
        {
            field: 'adjustmentBalance',
            header: t('ADJUSTMENTS.ADJUSTMENT_BALANCE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { adjustmentBalance: number }) =>
                baseCurrencyWithAmountTemplate(rowData.adjustmentBalance)
        },

        {
            field: 'isDocumentUploaded',
            header: t('COMMON.ATTACHMENTS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: [
                {
                    label: t('COMMON.YES'),
                    value: 'yes'
                },
                {
                    label: t('COMMON.NO'),
                    value: 'no'
                }
            ],
            valueType: ValueType.Text
        },
        {
            field: 'createdAt',
            header: t('COMMON.CREATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'updatedAt',
            header: t('COMMON.UPDATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.AR_ADJUSTMENTS_TABLE,
        title: t('MENU.AR_ADJUSTMENTS'),
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AR_ADJUSTMENTS_COLUMN_ORDERS,
        columns: columnSchema,
        showResync: true,
        syncedDate: {
            dateTime: syncedDate,
            nextToDateTimeCustomText: t('COMMON.SYNC_DATE_TIME_UTC')
        },
        showResyncCustomize: {
            permission: true,
            customText: t('COMMON.MANUAL_SYNC')
        }
    };

    return (
        <div className="p-4 pb-0">
            <DataTableComponent
                tableData={adjustmentList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                onRowClicked={onRowClick}
                exportData={handleExportList}
                onClickReSync={() => {
                    handleSageSync();
                }}
            />
        </div>
    );
};
export default ArAdjustments;
