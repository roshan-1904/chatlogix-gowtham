import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { ArAdvanceList, ArAdvanceListResponse } from '../types';
import {
    baseCurrencyWithAmountTemplate,
    fxRateTemplate,
    vendorCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { useNavigate } from 'react-router-dom';
import { DataTableSelectEvent } from 'primereact/datatable';
import { advanceService } from '../service/arAdvance.service';
import { arAdjustmentService } from '../service/arAdjustment.service';

const ArAdvances = () => {
    const navigate = useNavigate();
    const [advanceList, setAdvanceList] = useState<ArAdvanceList[]>([]);
    const [syncedDate, setSyncedDate] = useState<string>('');
    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 0
    });
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const fetchAdvanceList = async (reqBody: RequestBody) => {
        try {
            const response: ArAdvanceListResponse = await advanceService.getArAdvanceList(reqBody);
            if (response) {
                setAdvanceList(response.arAdvanceList);
                const pagination: paginationData = {
                    pageNo: requestBody.pageNo,
                    totalPages: Math.ceil(response.totalCount / reqBody.pageCount),
                    totalRecords: response.totalCount
                };

                setPaginationInfo(pagination);
            }
        } catch (error) {
            console.error('Error fetching advance list:', error);
        }
    };

    const onRowClick = (e: DataTableSelectEvent) => {
        const rowData = e.data as ArAdvanceList;
        navigate(`/accounting/ar-advances/${rowData.advanceId.toLowerCase()}`);
    };

    const exportArAdvanceList = () => {
        advanceService.exportArAdvanceList(requestBody);
    };

    const handleSageSync = async () => {
        await advanceService.sageSyncArAdvanceList();
        getSyncDetails();
        fetchAdvanceList(requestBody);
    };

    const getSyncDetails = async () => {
        try {
            const response = await arAdjustmentService.getSyncDetails();

            const arAdvanceDate = response
                .filter((item) => item.name === 'ARADVANCE')
                .map((item) => item.lastSyncDate)
                .join(', ');
            setSyncedDate(arAdvanceDate);
        } catch (error) {
            console.error('Error fetching sync details:', error);
        }
    };

    useEffect(() => {
        getSyncDetails();
    }, []);

    useEffect(() => {
        fetchAdvanceList(requestBody);
    }, [requestBody]);

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'advanceId',
            header: t('ADVANCES.RECORD_NO'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { advanceId: string }) => (
                <span className="cursor-pointer text-primary underline font-medium">
                    {rowData.advanceId}
                </span>
            )
        },
        {
            field: 'companyName',
            header: t('ADVANCES.CUSTOMER'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'status',
            header: t('ADVANCES.STATUS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status
        },
        {
            field: 'paymentMethod',
            header: t('ADVANCES.PAYMENT_METHOD'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'paymentDate',
            header: t('ADVANCES.PAYMENT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'receiptDate',
            header: t('ADVANCES.RECEIPT_DATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'transactionCurrency',
            header: t('ADVANCES.TRANSACTION_CURRENCY'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'transactionPaymentAmount',
            header: t('ADVANCES.TRANSACTION_PAYMENT_AMOUNT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: {
                transactionPaymentAmount: number;
                transactionCurrencySymbol: string;
            }) =>
                vendorCurrencyWithAmountTemplate(
                    rowData.transactionPaymentAmount,
                    rowData.transactionCurrencySymbol
                )
        },
        {
            field: 'exchangeRateValue',
            header: t('ADVANCES.FX_RATE'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { exchangeRateValue: number }) =>
                fxRateTemplate(Number(rowData.exchangeRateValue))
        },
        {
            field: 'paymentAmount',
            header: t('ADVANCES.PAYMENT_AMOUNT_USD'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { paymentAmount: number }) =>
                baseCurrencyWithAmountTemplate(rowData.paymentAmount)
        },
        {
            field: 'summary',
            header: t('ADVANCES.DESCRIPTION'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text
        },
        {
            field: 'totalPaid',
            header: t('ADVANCES.TOTAL_APPLIED'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { totalPaid: number }) =>
                baseCurrencyWithAmountTemplate(rowData.totalPaid)
        },
        {
            field: 'totalDue',
            header: t('ADVANCES.TOTAL_LEFT_TO_BANK'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Text,
            body: (rowData: { totalDue: number }) =>
                baseCurrencyWithAmountTemplate(rowData.totalDue)
        },
        {
            field: 'isDocumentUploaded',
            header: t('COMMON.ATTACHMENTS'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: [
                {
                    label: t('COMMON.YES'),
                    value: 'yes'
                },
                {
                    label: t('COMMON.NO'),
                    value: 'no'
                }
            ],
            valueType: ValueType.Text
        },
        {
            field: 'createdOn',
            header: t('COMMON.CREATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        },
        {
            field: 'modifiedOn',
            header: t('COMMON.UPDATED_AT'),
            columnNumber: columnNumber++,
            visibility: true,
            filter: true,
            sortable: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.AR_ADVANCES_TABLE,
        title: t('MENU.AR_ADVANCES'),
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.AR_ADVANCES_COLUMN_ORDERS,
        columns: columnSchema,
        showResync: true,
        syncedDate: {
            dateTime: syncedDate,
            nextToDateTimeCustomText: t('COMMON.SYNC_DATE_TIME_UTC')
        },
        showResyncCustomize: {
            permission: true,
            customText: t('COMMON.MANUAL_SYNC')
        }
    };

    return (
        <div className="p-4 pb-0">
            <DataTableComponent
                tableData={advanceList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                onRowClicked={onRowClick}
                exportData={exportArAdvanceList}
                onClickReSync={() => {
                    handleSageSync();
                }}
            />
        </div>
    );
};
export default ArAdvances;
