import LabelName from 'components/inputs/labelName';
import ConstructField from 'components/reuseComponents/constructField';
import { t } from 'i18next';
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
    formatDate,
    fxRateTemplate,
    vendorCurrencyWithAmountTemplate,
    baseCurrencyWithAmountTemplate
} from 'core/utils/utils';
import { getStatusColor } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import { ArAdvanceDetails } from '../types';
import { advanceService } from '../service/arAdvance.service';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';

const ArAdvancesDetails = () => {
    const id = useParams<{ id: string }>().id;
    const [advanceDetails, setAdvanceDetails] = useState<ArAdvanceDetails>();

    const fetchAdvanceDetails = async () => {
        if (!id) return;
        const res = await advanceService.getArAdvanceDetails(id);
        setAdvanceDetails(res);
    };

    useEffect(() => {
        fetchAdvanceDetails();
    }, []);

    const dataUniqueAttribute = {
        customClass: { fieldValueLabel: 'font-medium' }
    };

    return (
        <div>
            <TopNavigationStep
                backNavigationPath={'/accounting/ar-advances'}
                steps={[
                    {
                        label: t('COMMON.AR_ADVANCES'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: '/accounting/ar-advances'
                    },
                    {
                        label: ` ${id}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.ADVANCE'),
                        module: 'ADVANCE'
                    }
                ]}
            />

            <div className="flex flex-col gap-3 p-3 [&>div]:bg-white [&>div]:border [&>div]:rounded-md [&>div]:p-3">
                <div>
                    <LabelName
                        name={t('ADVANCES.ADVANCE_DETAILS')}
                        customStyle={{
                            nameStyle: 'text-lg font-medium text-primary'
                        }}
                    />
                    <div className="grid grid-cols-4 gap-4 py-2">
                        {/* Advance Number */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.RECORD_NO'),
                                fieldValue: advanceDetails?.advanceNumber
                            }}
                        />

                        {/* Payment Method */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.PAYMENT_METHOD'),
                                fieldValue: advanceDetails?.paymentMethod
                            }}
                        />

                        {/* customer */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.CUSTOMER'),
                                fieldValue: advanceDetails?.companyName
                            }}
                        />

                        {/* Status */}
                        <div>
                            <LabelName name={t('ADVANCES.STATUS')} />
                            {advanceDetails?.status ? (
                                <div
                                    className={`${getStatusColor(advanceDetails?.status)} rounded-md w-fit h-fit py-0.5 px-2 font-medium mt-0.5`}>
                                    {advanceDetails?.status}
                                </div>
                            ) : (
                                '-'
                            )}
                        </div>

                        {/* Transaction Currency */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.TRANSACTION_CURRENCY'),
                                fieldValue: advanceDetails?.transactionCurrency
                            }}
                        />

                        {/* Transaction Currency Symbol */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.TRANSACTION_PAYMENT_AMOUNT'),
                                fieldValue: vendorCurrencyWithAmountTemplate(
                                    advanceDetails?.transactionPaymentAmount,
                                    advanceDetails?.transactionCurrencySymbol ?? ''
                                )
                            }}
                        />

                        {/* FX Rate */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.FX_RATE'),
                                fieldValue: fxRateTemplate(
                                    Number(advanceDetails?.exchangeRateValue)
                                )
                            }}
                        />

                        {/* Payment Amount in USD */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.PAYMENT_AMOUNT_USD'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    advanceDetails?.paymentAmount
                                )
                            }}
                        />

                        {/* Total Applied */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.TOTAL_APPLIED'),
                                fieldValue: baseCurrencyWithAmountTemplate(
                                    advanceDetails?.totalPaid
                                )
                            }}
                        />

                        {/* Total Left to Bank */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.TOTAL_LEFT_TO_BANK'),
                                fieldValue: baseCurrencyWithAmountTemplate(advanceDetails?.totalDue)
                            }}
                        />

                        {/* Payment Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.PAYMENT_DATE'),
                                fieldValue: formatDate(advanceDetails?.paymentDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Receipt Date */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.RECEIPT_DATE'),
                                fieldValue: formatDate(advanceDetails?.receiptDate ?? ''),
                                inputType: { type: 'calendar' }
                            }}
                        />

                        {/* Document Submitted */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('COMMON.ATTACHMENTS'),
                                fieldValue: advanceDetails?.isDocumentUploaded
                            }}
                        />

                        {/* Summary */}
                        <ConstructField
                            data={{
                                ...dataUniqueAttribute,
                                fieldLabelName: t('ADVANCES.DESCRIPTION'),
                                fieldValue: advanceDetails?.summary
                            }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ArAdvancesDetails;
