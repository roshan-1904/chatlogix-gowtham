import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import InvoiceDetails from './invoiceDetails';
import { getInvoiceDetails } from '../service/invoice.service';

// Mocking necessary modules and functions
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('../service/invoice.service');

const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockNavigate
}));
const mockInvoiceDetails = {
    invoiceNumber: 'INV123',
    title: 'Invoice Title',
    invoiceDate: '2024-01-01',
    companyName: 'Company ABC',
    vendorName: 'Vendor XYZ',
    requestNumber: 'REQ123',
    dueDate: '2024-02-01',
    billingTerms: 'Net 30',
    poNumber: 'PO123',
    sageStatus: 'Pending',
    sageStatusSyncName: 'Synced',
    amount: 1000,
    currencySymbol: '$',
    taskDetails: [
        {
            id: 9262,
            taskNo: 'R2408514',
            taskId: '266',
            taskName: 'Translation',
            taskDescription: 'Translation Fee',
            sourceLanguage: 'English',
            targetLanguage: 'Chinese (Simplified)',
            targetCountry: 'China',
            unit: 'Per Word',
            quantity: 9146,
            amount: 1188.98,
            sageInvoice: null,
            fxRate: 1.0,
            rate: 0.13,
            taskCurrencySymbol: '$'
        }
    ]
};
describe('InvoiceDetails Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('fetches and displays invoice details', async () => {
        (getInvoiceDetails as jest.Mock).mockResolvedValue(mockInvoiceDetails);

        render(
            <Router>
                <InvoiceDetails />
            </Router>
        );

        await waitFor(() => expect(getInvoiceDetails).toHaveBeenCalledWith(''));

        // Wait for the invoice number to be displayed
        await waitFor(() => {
            const invoiceNumberElement = screen.getByTestId('invoice-number');
            expect(invoiceNumberElement).toHaveTextContent('INV123');
        });
    });

    test('renders InvoiceDetails component', async () => {
        (getInvoiceDetails as jest.Mock).mockResolvedValue(mockInvoiceDetails);

        render(
            <Router>
                <InvoiceDetails />
            </Router>
        );

        expect(await screen.findByTestId('billDetailWrapperSection')).toBeInTheDocument();
        expect(screen.getByTestId('headerBarSection')).toBeInTheDocument();
        expect(screen.getByTestId('detailSection')).toBeInTheDocument();
        expect(screen.getByTestId('collapsibleContainer')).toBeInTheDocument();
    });

    test('back navigation works', () => {
        (getInvoiceDetails as jest.Mock).mockResolvedValue(mockInvoiceDetails);

        render(
            <Router>
                <InvoiceDetails />
            </Router>
        );

        const backButton = screen.getByTestId('headerBarSection').querySelector('.cursor-pointer');
        if (backButton) {
            fireEvent.click(backButton);
        }

        expect(mockNavigate).toHaveBeenCalledWith('/accounting/invoices');
    });

    test('accordion toggle works', () => {
        (getInvoiceDetails as jest.Mock).mockResolvedValue(mockInvoiceDetails);

        render(
            <Router>
                <InvoiceDetails />
            </Router>
        );

        const checkbox = screen.getByTestId('accordion-checkbox');
        fireEvent.click(checkbox);
        expect(checkbox).not.toBeChecked();
    });
});
