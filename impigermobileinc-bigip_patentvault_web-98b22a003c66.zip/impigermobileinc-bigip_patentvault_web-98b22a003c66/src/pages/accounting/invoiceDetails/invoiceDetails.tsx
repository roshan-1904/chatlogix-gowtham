import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { PATHS } from 'constants/routes.constant';
import { formatCurrency, formatDate } from 'core/utils/utils';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
import ProgressStatusIndicator from 'shared/dataTable/components/progressStatusIndicator/progressStatusIndicator';
import StatusIndicator from 'shared/dataTable/components/statusIndicator/statusIndicator';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { CustomDetailWidget } from '../components/customDetailsWidget/customDetailsWidget';
import { InvoiceDetailsWidget } from '../components/invoiceDetailWidget/invoiceDetailWidget';
import { getInvoiceDetails } from '../service/invoice.service';
import { getInvoiceServicesTableColumnSchema } from '../tableSchema/invoiceService.schema';
import { InvoiceDetailsData } from '../types';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';
const InvoiceDetails = () => {
    const isAccount: boolean =
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE);

    const { invoiceId } = useParams();
    const { t } = useTranslation();

    const [invoiceDetails, setInvoiceDetails] = useState<InvoiceDetailsData>();
    const [accordionActive, setAccordionActive] = useState(true);

    const [tableRequestBody, setTableRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const [paginationInfo, setPaginationInfo] = useState<paginationData>({
        pageNo: 1,
        totalPages: 1,
        totalRecords: 2
    });
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.ACCOUNTING_INVOICES_SERVICES_COLUMN_ORDERS;

    useEffect(() => {
        fetchInvoiceDetails();
    }, []);

    const fetchInvoiceDetails = async () => {
        try {
            const response = await getInvoiceDetails<InvoiceDetailsData>(invoiceId ?? '');
            setInvoiceDetails(response);
            setPaginationInfo({
                pageNo: 1,
                totalPages: 1,
                totalRecords: response?.taskDetails?.length
            });
        } catch (error) {
            console.error(error);
        }
    };

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.ACCOUNT_INVOICE_DETAILS_TASKS_TABLE,
        reOrderableColumns: true,
        columns: getInvoiceServicesTableColumnSchema(!isAccount),
        customerHeader: null,
        emptyMessage: '',
        filters: {},
        localStorageKey: storageKey,
        title: '',
        customTableHeight: false
    };

    const handleFilter = (updatedFilter: RequestBody) => {
        setTableRequestBody(updatedFilter);
    };

    const sortHandler = (updatedSort: RequestBody) => {
        setTableRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setTableRequestBody(updatedPage);
    };

    return (
        <div data-testid="billDetailWrapperSection" className="flex-1">
            <TopNavigationStep
                backNavigationPath={`/${isAccount ? PATHS.ACCOUNT_INVOICES : PATHS.INVOICES}`}
                steps={[
                    {
                        label: t('COMMON.INVOICES'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: `/${isAccount ? PATHS.ACCOUNT_INVOICES : PATHS.INVOICES}`
                    },
                    {
                        label: ` ${invoiceDetails?.invoiceNumber ?? ''}`,
                        isCurrent: true,
                        isPrevious: false,
                        labelName: t('COMMON.INVOICE'),
                        module: 'INVOICE',
                        isCopyable: true
                    }
                ]}
            />

            <div data-testid="detailSection" className="flex px-6 py-3">
                <div
                    data-testid="vendorDetailSection"
                    className="bg-white h-100 rounded-md shadow-md w-full mr-2 p-6">
                    <div className="text-[#1D8ADE] font-medium text-lg">
                        {t('ACCOUNTING.INVOICE_DETAILS')}
                    </div>

                    <InvoiceDetailsWidget
                        field1Title={t('ACCOUNTING.INVOICE_NUMBER')}
                        field1Value={invoiceDetails?.invoiceNumber}
                        field2Title={t('ACCOUNTING.REQUEST_NUMBER')}
                        field2Value={invoiceDetails?.requestNumber}
                        field3Title={t('ACCOUNTING.CUSTOMER')}
                        field3Value={invoiceDetails?.companyName}
                        field4Element={
                            <CustomDetailWidget title={t('ACCOUNTING.STATUS')}>
                                <StatusIndicator
                                    status={invoiceDetails?.sageStatus}
                                    tableType={TableTypes.ACCOUNTING_INVOICES_TABLE}
                                />
                            </CustomDetailWidget>
                        }
                    />
                    <InvoiceDetailsWidget
                        field1Title={t('ACCOUNTING.INVOICE_DATE')}
                        field1Value={formatDate(invoiceDetails?.invoiceDate ?? '')}
                        field2Title={t('ACCOUNTING.DUE_DATE')}
                        field2Value={formatDate(invoiceDetails?.dueDate ?? '')}
                        field3Title={t('ACCOUNTING.TERMS')}
                        field3Value={invoiceDetails?.billingTerms}
                        field4Title={t('ADDITIONAL_INFO.REFERENCE_NUMBER')}
                        field4Value={invoiceDetails?.referenceNumber || '-'}
                    />
                    {isAccount ? (
                        <>
                            <InvoiceDetailsWidget
                                field1Title={t('ACCOUNTING.SAGE_INVOICE_AMOUNT')}
                                field1Value={`${invoiceDetails?.currencySymbol ?? ''} ${formatCurrency(invoiceDetails?.sageInvoice ?? 0)}`}
                                fieldValueStyle_1={'font-semibold !text-lg'}
                                fieldValueStyle_2={'font-semibold !text-lg'}
                                field2Title={t('ACCOUNTING.TOTAL_AMOUNT')}
                                field2Value={`${invoiceDetails?.currencySymbol ?? ''} ${formatCurrency(invoiceDetails?.amount ?? 0)}`}
                                field3Title={t('ACCOUNTING.PAID_AMOUNT')}
                                field3Value={`${invoiceDetails?.currencySymbol ?? ''} ${formatCurrency(invoiceDetails?.transactionAmountPaid ?? 0)}`}
                                field4Title={t('ACCOUNTING.BALANCE_AMOUNT')}
                                field4Value={`${invoiceDetails?.currencySymbol ?? ''} ${formatCurrency(invoiceDetails?.transactionBalanceAmount ?? 0)}`}
                            />
                            <InvoiceDetailsWidget
                                field1Title={t('ACCOUNTING.PO_NUMBER')}
                                field1Value={invoiceDetails?.poNumber || '-'}
                                field2Title={t('ACCOUNTING.ACCOUNT_EXECUTIVE')}
                                field2Value={invoiceDetails?.accountExecutive}
                                field3Title={t('COMMON.ATTACHMENTS')}
                                field3Value={invoiceDetails?.isDocumentUploaded}
                                field4Element={
                                    <CustomDetailWidget title={t('ACCOUNTING.SYNC_STATUS')}>
                                        <ProgressStatusIndicator
                                            syncStatus={invoiceDetails?.sageStatusSyncName}
                                        />
                                    </CustomDetailWidget>
                                }
                            />
                            <InvoiceDetailsWidget
                                field1Title={t('ACCOUNTING.DESCRIPTION')}
                                field1Value={invoiceDetails?.title}
                            />
                        </>
                    ) : (
                        <>
                            <InvoiceDetailsWidget
                                fieldValueStyle_4={'font-semibold !text-lg'}
                                field1Title={t('ACCOUNTING.INVOICE_COMPANY')}
                                field1Value={invoiceDetails?.companyName}
                                field2Title={t('ACCOUNTING.INVOICE_CONTACT')}
                                field2Value={invoiceDetails?.invoiceToContact ?? '-'}
                                field3Title={t('ACCOUNTING.ACCOUNT_EXECUTIVE')}
                                field3Value={invoiceDetails?.accountExecutive}
                                field4Title={t('ACCOUNTING.INVOICE_TOTAL')}
                                field4Value={`${invoiceDetails?.currencySymbol ?? ''} ${formatCurrency(invoiceDetails?.sageInvoice ?? 0)}`}
                            />
                            <InvoiceDetailsWidget
                                field1Title={t('COMMON.ATTACHMENTS')}
                                field1Value={invoiceDetails?.isDocumentUploaded}
                                field2Title={t('ACCOUNTING.DESCRIPTION')}
                                field2Value={invoiceDetails?.title}
                            />
                        </>
                    )}
                </div>
            </div>

            <div data-testid="collapsibleContainer" className="flex px-6 py-3">
                <div
                    className={`collapse collapse-arrow bg-white border-neutral border-1 rounded-md shadow-md`}
                    id="request-detail-container">
                    <input
                        type="checkbox"
                        className="py-1 min-h-0"
                        name="my-accordion-2"
                        data-testid="accordion-checkbox"
                        onClick={() => setAccordionActive(!accordionActive)}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                setAccordionActive(!accordionActive);
                            }
                        }}
                        checked={accordionActive}
                    />
                    <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                        <span className=" text-md font-medium text-[#1D8ADE] text-lg">
                            {isAccount ? t('ACCOUNTING.TASK_DETAILS') : t('ACCOUNTING.SERVICES')}
                        </span>
                    </div>

                    <div className="flex-1 collapse-content border-t-neutral-60 border-t-[1px] px-5 overflow-hidden remove-cursor-pointer">
                        <DataTableComponent
                            tableData={invoiceDetails?.taskDetails ?? []}
                            tableDefinition={tableDefinition}
                            tableRequestBodyData={tableRequestBody}
                            handleFilter={handleFilter}
                            toggleRowData={() => {}}
                            handlePagination={handlePageChange}
                            tablePaginationData={paginationInfo}
                            showPagination={true}
                            handleSort={sortHandler}
                            showHeader={false}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};
export default InvoiceDetails;
