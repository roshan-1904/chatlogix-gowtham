export interface EpoInfoFormData {
    id: string;
    sourceLanguage: any;
    sourceLanguageName?: string;
    patentApplicationNumber: string;
    patentPublicationNumber: string;
    kind?: string;
    applicantName?: string;
    applicantCount?: number;
    title?: string;
    titleFr?: string;
    titleDe?: string;
    patentPublicationDate?: Date | null;
    statutoryDeadline?: Date | null;
    validationDeadLine?: Date | null;
    validationDeadLineUP?: Date | null;
    descriptionWordCount?: number | null;
    numberOfClaims?: number | null;
    claimWordCount?: number | null;
    descriptionPageCount?: number | null;
    claimsPageCount?: number | null;
    drawingsPageCount?: number | null;
}

export interface EpoInfoModal {
    visible: boolean;
    modalDescription: string;
    acceptLabel?: string;
    rejectLabel?: string;
    isReset?: boolean;
}
