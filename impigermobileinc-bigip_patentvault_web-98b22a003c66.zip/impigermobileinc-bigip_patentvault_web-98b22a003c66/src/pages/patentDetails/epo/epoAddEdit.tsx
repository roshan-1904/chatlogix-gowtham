import { useEffect, useRef, useState } from 'react';
import AuthStore from 'core/store/authStore/authStore';
import { deepEqualValuesOnly, focusOnFirstError, showToastMessage } from 'core/utils/utils';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import HttpService from 'core/interceptor/api.handler';
import { Form } from '@formio/react';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

import epoAddEditJson from '../data/epoAddEdit.json';
import { EpoListModel } from 'pages/settingsPages/pages/rateLabels/types/rateLabel.types';
import { EpoInfoFormData, EpoInfoModal } from '../types/EpoInfoFormData';
import epDetailsStore from 'core/store/epDetailsStore/epDetailsStore';
import {
    createEpoRecord,
    getEPPatentDetails,
    updateEpoRecord
} from 'pages/patentDetails/services/patentDetailServices';
import { Permissions } from 'constants/permissions';

export default function EpoAddEdit() {
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const { t } = useTranslation();
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(epoAddEditJson);

    const [isError, setIsError] = useState<boolean>(false);
    const [editMode, setEditMode] = useState(false);
    const hasCreatePatentPermission = AuthStore.hasPermission(Permissions.CREATE_PATENT);
    const [epoStoreModuleData, setEpoStoreModuleData] = useState(epDetailsStore.getData());

    const [defaultFormData, setDefaultFormData] = useState(epoStoreModuleData);
    const [showModal, setShowModal] = useState<EpoInfoModal>({
        visible: false,
        modalDescription: t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION'),
        acceptLabel: t('COMMON.YES_DISCARD'),
        rejectLabel: t('COMMON.NO_DON_T')
    });
    const initialData = {
        data: {
            ...epoStoreModuleData
        }
    };
    epDetailsStore.subscribe(setEpoStoreModuleData);
    const isFormValuesUpdated = !deepEqualValuesOnly(defaultFormData as object, {
        ...(epoStoreModuleData as object)
    });

    const { requestId } = useParams();

    const showErrMsg = () => {
        setIsError(true);
        showToastMessage({
            type: ToastType.ERROR,
            message: t('COMMON.GET_PATENT_INFORMATION_FAILURE')
        });
    };

    const getEPPatentRecord = async () => {
        try {
            const response: EpoListModel = await getEPPatentDetails<EpoListModel>({
                id: requestId
            });
            if (response) {
                setDefaultFormData({
                    id: response?.id || '',
                    sourceLanguage: response?.sourceLanguage,
                    patentApplicationNumber: response?.patentApplicationNumber || '',
                    patentPublicationNumber: response?.patentPublicationNumber || '',
                    kind: response?.kind || '',
                    applicantName: response?.applicantName || '',
                    applicantCount: response?.applicantCount || 0,
                    title: response?.title || '',
                    titleFr: response?.titleFR || '',
                    titleDe: response?.titleDE || '',
                    patentPublicationDate: response?.patentPublicationDate,
                    statutoryDeadline: response?.statutoryDeadline,
                    validationDeadLine: response?.validationDeadline,
                    validationDeadLineUP: response?.validationDeadlineUP,
                    descriptionWordCount: response?.descriptionWordCount || 0,
                    numberOfClaims: response?.numberOfClaims || 0,
                    claimWordCount: response?.claimWordCount || 0,
                    descriptionPageCount: response?.descriptionPageCount || 0,
                    claimsPageCount: response?.claimsPageCount || 0,
                    drawingsPageCount: response?.drawingsPageCount || 0
                });
                epDetailsStore.updateFormData({
                    id: response?.id || '',
                    patentApplicationNumber: response?.patentApplicationNumber || '',
                    patentPublicationNumber: response?.patentPublicationNumber || '',
                    sourceLanguage: response?.sourceLanguage,
                    kind: response?.kind || '',
                    sourceLanguageName: response?.sourceLanguageName || '',
                    applicantName: response?.applicantName || '',
                    applicantCount: response?.applicantCount || 0,
                    title: response?.title || '',
                    titleFr: response?.titleFR || '',
                    titleDe: response?.titleDE || '',
                    patentPublicationDate: response?.patentPublicationDate,
                    statutoryDeadline: response?.statutoryDeadline,
                    validationDeadLine: response?.validationDeadline,
                    validationDeadLineUP: response?.validationDeadlineUP,
                    descriptionWordCount: response?.descriptionWordCount || 0,
                    numberOfClaims: response?.numberOfClaims || 0,
                    claimWordCount: response?.claimWordCount || 0,
                    descriptionPageCount: response?.descriptionPageCount || 0,
                    claimsPageCount: response?.claimsPageCount || 0,
                    drawingsPageCount: response?.drawingsPageCount || 0
                });
            } else {
                showErrMsg();
            }
        } catch (error) {
            showErrMsg();
            console.error('Error in fetching epo patent details:', error);
        }
    };

    const createEpoDetail = async (requestBody: EpoInfoFormData) => {
        try {
            const response: EpoListModel = await createEpoRecord(requestBody);
            if (response) {
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message:
                        requestBody.patentPublicationNumber +
                        ' EPO patent details created successfully'
                });
                setEditMode(false);
                epDetailsStore.resetStore();
                navigate('/patent-details/epo', { replace: true }); // Navigate and replace current entry
            }
        } catch (error: any) {
            showToastMessage({
                type: ToastType.ERROR,
                message: error?.response?.data?.Message || 'Failed to create EPO patent details'
            });
            console.error('Error in creating EPO patent details:', error);
        }
    };

    const updateEpoDetail = async (requestBody: EpoInfoFormData) => {
        try {
            const response: EpoListModel = await updateEpoRecord(requestBody);
            if (response) {
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message:
                        requestBody.patentPublicationNumber +
                        ' EPO patent details updated successfully'
                });
                setEditMode(false);
                epDetailsStore.resetStore();
                navigate('/patent-details/epo', { replace: true }); // Navigate and replace current entry
            }
        } catch (error) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'Failed to update EPO patent details'
            });
            console.error('Error in updating EPO patent details:', error);
        }
    };

    const handleUpdateAccount = async () => {
        document.getElementById('submit-epo-patent-info')?.click();
        await new Promise((r) => setTimeout(r, 100));
    };
    const formRef: any = useRef(null);

    const handleReady = (formInstance: any) => {
        // Store form instance when form is ready
        formRef.current = formInstance;
    };

    const onFormChange = (submission: any) => {
        const updatedFormData: EpoInfoFormData = submission.data;
        if (submission.changed) {
            if (
                updatedFormData.kind === 'B1' &&
                updatedFormData.patentPublicationDate &&
                (submission.changed.component.key === 'patentPublicationDate' ||
                    submission.changed.component.key === 'kind')
            ) {
                const pubDate = new Date(updatedFormData.patentPublicationDate);
                const newValidationDeadLineDate = new Date(pubDate);
                newValidationDeadLineDate.setMonth(newValidationDeadLineDate.getMonth() + 3);
                newValidationDeadLineDate.setDate(newValidationDeadLineDate.getDate() + 1);

                const newValidationDeadLineUPDate = new Date(pubDate);
                newValidationDeadLineUPDate.setMonth(newValidationDeadLineUPDate.getMonth() + 1);
                newValidationDeadLineUPDate.setDate(newValidationDeadLineUPDate.getDate() + 1);
                if (updatedFormData.validationDeadLineUP !== newValidationDeadLineUPDate) {
                    updatedFormData.validationDeadLineUP = newValidationDeadLineUPDate;
                }
                // Use form instance to update another field
                formRef?.current
                    ?.getComponent('validationDeadLine')
                    .setValue(newValidationDeadLineDate.toISOString().split('T')[0], {
                        modified: false
                    });
                formRef?.current
                    ?.getComponent('validationDeadLineUP')
                    .setValue(newValidationDeadLineUPDate.toISOString().split('T')[0], {
                        modified: false
                    });
            }
            epDetailsStore.updateFormData(updatedFormData);
        }
    };

    const onSubmitChange = async (e: any) => {
        const updatedFormData = e?.data as EpoInfoFormData;
        const rec = {
            id: updatedFormData.id,
            sourceLanguage: updatedFormData?.sourceLanguage,
            patentApplicationNumber: updatedFormData?.patentApplicationNumber,
            patentPublicationNumber: updatedFormData?.patentPublicationNumber,
            applicantCount: updatedFormData?.applicantCount,
            applicantName: updatedFormData?.applicantName,
            kind: updatedFormData?.kind,
            title: updatedFormData?.title,
            titleFr: updatedFormData?.titleFr,
            titleDe: updatedFormData?.titleDe,
            patentPublicationDate: updatedFormData?.patentPublicationDate || null,
            statutoryDeadline: updatedFormData?.statutoryDeadline || null,
            validationDeadLine: updatedFormData?.validationDeadLine || null,
            validationDeadLineUP: updatedFormData?.validationDeadLineUP || null,
            descriptionWordCount: updatedFormData?.descriptionWordCount,
            numberOfClaims: updatedFormData?.numberOfClaims,
            claimWordCount: updatedFormData?.claimWordCount,
            descriptionPageCount: updatedFormData?.descriptionPageCount,
            claimsPageCount: updatedFormData?.claimsPageCount,
            drawingsPageCount: updatedFormData?.drawingsPageCount
        };
        if (updatedFormData.id === '') {
            await createEpoDetail(rec);
        } else {
            await updateEpoDetail(rec);
        }
    };

    const handleModalChange = (
        show = false,
        description = t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION'),
        isReset = false,
        isBack = false
    ) => {
        let acceptLabel = t('COMMON.YES_DISCARD');
        if (isBack) {
            acceptLabel = t('COMMON.YES');
        } else if (isReset) {
            acceptLabel = requestId === '0' ? t('COMMON.YES_CLEAR') : t('COMMON.YES_RESET');
        }

        const rejectLabel = isBack ? t('COMMON.NO') : t('COMMON.NO_DON_T');

        setShowModal((prev: EpoInfoModal) => ({
            ...prev,
            visible: show,
            modalDescription: description,
            acceptLabel,
            rejectLabel,
            isReset,
            isBack
        }));
    };

    const handleConfirm = () => {
        if (showModal?.isReset) {
            epDetailsStore.updateFormData(defaultFormData);
            setShowModal((prev: EpoInfoModal) => ({
                ...prev,
                visible: false
            }));
        } else {
            epDetailsStore.resetStore();
            setEditMode(false);
            setShowModal((prev: EpoInfoModal) => ({
                ...prev,
                visible: false
            }));
            navigate('/patent-details/epo', { replace: true }); // Navigate and replace current entry
        }
    };

    const updateFormFields = (formJson: any) => {
        const updatedComponents = (formJson?.components || []).map((component: any) => {
            if (component.type === 'columns') {
                // Loop through the columns to find the fields to update
                component.columns = component?.columns.map((column: any) => {
                    column.components = column?.components?.map((field: any) => {
                        if (
                            [
                                'sourceLanguage',
                                'patentApplicationNumber',
                                'patentPublicationNumber',
                                'kind',
                                'applicantName',
                                'applicantCount',
                                'title',
                                'titleFr',
                                'titleDe',
                                'patentPublicationDate',
                                'statutoryDeadline',
                                'validationDeadLine',
                                'validationDeadLineUP',
                                'descriptionWordCount',
                                'numberOfClaims',
                                'claimWordCount',
                                'descriptionPageCount',
                                'claimsPageCount',
                                'drawingsPageCount'
                            ].includes(`${field.key}`)
                        ) {
                            field.disabled = !editMode; // Set disabled to true if not in edit mode
                            field.validateOn = editMode ? field.validateOn : 'blur';
                        }
                        return field;
                    });
                    return column;
                });
            }
            return component;
        });

        return { ...formJson, components: updatedComponents };
    };

    const renderEditForm = () => {
        return (
            <div data-testid="edit-patent-info-container" className="max-h-fit">
                <div className="flex align-center justify-between">
                    <h1 className="text-xl font-medium text-primary-500">
                        {requestId === '0'
                            ? 'Add EPO Patent'
                            : editMode
                              ? 'Update EPO Patent'
                              : 'EPO Patent Details'}
                    </h1>
                    <div className="flex gap-2 min-h-10 items-center">
                        {hasCreatePatentPermission && editMode ? (
                            <>
                                <button
                                    disabled={!isFormValuesUpdated}
                                    className="btn button-primary-outline min-h-[2.45rem] h-[2.45rem]"
                                    onClick={() => {
                                        if (isFormValuesUpdated) {
                                            handleModalChange(
                                                true,
                                                requestId === '0'
                                                    ? t('COMMON.CLEAR_INFORMATION')
                                                    : t('COMMON.RESET_INFORMATION'),
                                                true
                                            );
                                        }
                                    }}>
                                    {requestId !== '0' && <i className="pi pi-refresh" />}
                                    {requestId === '0' ? t('COMMON.CLEAR') : t('COMMON.RESET')}
                                </button>
                                <button
                                    onClick={() => handleModalChange(true)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleModalChange(true);
                                        }
                                    }}
                                    className={'btn btn-sm button-neutral font-medium'}
                                    data-testid="cancel-patent-info">
                                    {t('COMMON.DISCARD')}
                                </button>
                                <button
                                    disabled={!isFormValuesUpdated}
                                    className={'btn btn-sm button-primary font-medium'}
                                    onClick={() => {
                                        handleUpdateAccount().catch(console.error);
                                    }}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleUpdateAccount().catch(console.error);
                                        }
                                    }}
                                    data-testid="submit-epo-patent-info">
                                    {t('COMMON.SAVE')}
                                </button>{' '}
                            </>
                        ) : (
                            hasCreatePatentPermission &&
                            !editMode && (
                                <button
                                    data-testid="edit-epo-patent-info"
                                    className={`btn button-primary-outline min-h-[2rem] h-[2rem] !font-medium w-18 ${isError ? 'cursor-not-allowed opacity-75' : ''}`}
                                    onClick={() => !isError && setEditMode(true)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !isError) {
                                            setEditMode(true);
                                        }
                                    }}>
                                    <i className="pi pi-pencil h-3 w-3"></i>
                                    <span>{t('COMMON.EDIT')}</span>
                                </button>
                            )
                        )}
                    </div>
                </div>
                <div
                    className="mt-2 p-4 pt-2 pl-0 flex align-center"
                    data-testid="epo-patent-container">
                    {showModal?.visible && (
                        <ConfirmationPopup
                            onConfirm={handleConfirm}
                            onCancel={handleModalChange}
                            visible={showModal?.visible}
                            headerText={t('COMMON.CONFIRMATION')}
                            description={showModal?.modalDescription}
                            acceptLabel={showModal?.acceptLabel || t('COMMON.YES_DISCARD')}
                            rejectLabel={showModal?.rejectLabel || t('COMMON.NO_DON_T')}
                        />
                    )}
                    <div className="ml-3 w-full">
                        <Form
                            form={updateFormFields(formBuilderData)}
                            submission={initialData}
                            onChange={onFormChange}
                            formReady={handleReady}
                            onSubmit={(e: any) => onSubmitChange(e)}
                            onError={focusOnFirstError}
                        />
                    </div>
                </div>
            </div>
        );
    };

    useEffect(() => {
        epDetailsStore.resetStore();
    }, []);
    useEffect(() => {
        requestId === '0' ? setEditMode(true) : getEPPatentRecord();
    }, [pathname]);
    return (
        <div className="w-full h-full overflow-x-hidden" data-testid="epo-patent-settings">
            <div className="h-12 border-b-2 border-b-primary/70 bg-white pl-4">
                <div
                    className="flex items-center h-full w-fit cursor-pointer"
                    data-testid="back-button-container"
                    onClick={() =>
                        handleModalChange(true, t('COMMON.CLOSE_INFORMATION'), false, true)
                    }
                    tabIndex={0}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            handleModalChange(true, t('COMMON.CLOSE_INFORMATION'), false, true);
                        }
                    }}>
                    <i className="pi pi-chevron-left text-base mt-0.5 mr-2" />
                    <h4 className="font-semibold">{t('COMMON.BACK')}</h4>
                </div>
            </div>
            <div className="flex flex-col justify-center items-center m-3">
                <div className="w-9/12 h-fit">
                    <div className="bg-white shadow-md border border-gray-300 rounded-lg p-5">
                        <div data-testid="epo-patent-info-container" className="px-2">
                            {renderEditForm()}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
