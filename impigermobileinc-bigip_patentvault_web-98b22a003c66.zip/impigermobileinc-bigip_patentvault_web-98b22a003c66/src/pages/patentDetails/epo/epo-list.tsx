import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { useEffect, useState } from 'react';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import {
    COLUMN_FIELD_CONST,
    FilterType,
    TableTypes,
    ValueType
} from 'shared/dataTable/constant/dataTable.constant';
import { t } from 'i18next';
import AuthStore from 'core/store/authStore/authStore';
import DataTableComponent from 'shared/dataTable/dataTable';
import { Permissions } from 'constants/permissions';

import { useNavigate } from 'react-router-dom';

import {
    EpoListModel,
    EpoListApiResponse
} from 'pages/settingsPages/pages/rateLabels/types/rateLabel.types';
import patentDetailService from '../services/patentDetailServices';
import epDetailsStore from 'core/store/epDetailsStore/epDetailsStore';
import { END_POINT } from 'constants/endPoint';
import { LanguageResponse } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';
import { Tooltip } from 'primereact/tooltip';
// constants
const requestBodyInit = {
    searchModels: [],
    sorting: {
        propertyName: '',
        value: ''
    },
    pageNo: 1,
    pageCount: 10
};

const EpoList = () => {
    const [tableData, setTableData] = useState<EpoListModel[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>(requestBodyInit);
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.EPO_COLUMN_ORDER;
    const hasPermissionForActions = AuthStore.hasPermission(Permissions.VIEW_PATENT);
    const [targetLanguageData, setTargetLanguageData] = useState<any[] | null>([]);
    const [countryData, setCountryData] = useState<any[] | null>([]);
    const [tableKey, setTableKey] = useState(0);

    const navigate = useNavigate();

    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    // Fetch Target Language
    const getTargetLanguageData = async () => {
        try {
            const response: LanguageResponse[] = await PVSettingsService.getTargetLanguage();
            const dropdownData: any[] = response
                .filter((s) => s.abbreviation !== '' && s.abbreviation != null)
                .map((language: LanguageResponse) => ({
                    value: language.abbreviation.toUpperCase(),
                    name: language.abbreviation.toUpperCase()
                }));
            setTargetLanguageData(dropdownData);
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_TARGET_LANGUAGES'),
                type: ToastType.ERROR
            });
        }
    };

    // Function for Get Country List using Api
    const getCountryList = async () => {
        try {
            const response = await OrdersAndQuotesService.getCountryList<any[]>();
            const countryCodes = response.map((s) => ({
                name: s.code,
                value: s.code
            }));
            setCountryData(countryCodes);
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_COUNTRY_LIST'),
                type: ToastType.ERROR
            });
        }
    };

    // api
    const getEpoList = async (body: RequestBody) => {
        try {
            const response: EpoListApiResponse =
                await patentDetailService.getEpoTableData<EpoListApiResponse>(body);
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
        } catch (error) {
            console.error('Error in Tasks info fetch:', error);
        }
    };

    let column = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'id',
            header: 'ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            body: (rowData: EpoListModel) => (
                <div>
                    {hasPermissionForActions ? (
                        <div
                            className={`flex items-center ${
                                rowData.recordSource === 'Manual Update' ||
                                rowData.recordSource === 'Manual Entry'
                                    ? ''
                                    : 'ml-4'
                            }`}>
                            {' '}
                            {(rowData.recordSource === 'Manual Update' ||
                                rowData.recordSource === 'Manual Entry') && (
                                <div className="w-1.5 h-1.5 mr-2 rounded-full bg-yellow-500"></div>
                            )}
                            <button
                                onClick={() => navigate(`/patent-details/epo/${rowData.id}`)}
                                onKeyDown={(e) =>
                                    e.key === 'Enter' &&
                                    navigate(`/patent-details/epo/${rowData.id}`)
                                }
                                className="text-primary hover:underline">
                                {rowData.id}
                            </button>
                        </div>
                    ) : (
                        <span>{rowData.id}</span>
                    )}
                </div>
            )
        },
        {
            field: 'sourceLanguageName',
            header: 'Source Language Name',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language Code',
            frozen: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true,
            dropdownOption: targetLanguageData ?? []
        },
        {
            field: 'kind',
            header: 'Kind',
            frozen: false,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            filterDropDownOptions: [
                { label: 'A1', value: 'A1' },
                { label: 'A2', value: 'A2' },
                { label: 'B1', value: 'B1' }
            ],
            sortable: true
        },
        {
            field: 'patentPublicationNumber',
            header: 'Patent Publication Number',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'patentApplicationNumber',
            header: 'Patent Application Number',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'fileName',
            header: 'File Name',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'descriptionWordCount',
            header: 'Description Word Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'numberOfClaims',
            header: 'Number Of Claims',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'title',
            header: 'Title',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: '!w-80',
            sortable: true
        },
        {
            field: 'titleFR',
            header: 'Title FR',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        },
        {
            field: 'titleDE',
            header: 'Title DE',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: 'w-80',
            sortable: true
        },
        {
            field: 'descriptionPageCount',
            header: 'Description Page Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'claimWordCount',
            header: 'Claim Word Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'claimsPageCount',
            header: 'Claims Page Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'drawingsPageCount',
            header: 'Drawings Page Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'applicantCount',
            header: 'Applicant Count',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Integer,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'applicantName',
            header: 'Applicant Name',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'patentPublicationDate',
            header: 'Patent Publication Date',
            isBetweenDateRangeFilter: true,
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'communicationOfIntentionDate',
            header: 'Communication Of Intention Date',
            isBetweenDateRangeFilter: true,
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'validationDeadline',
            header: 'Validation Deadline',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'statutoryDeadline',
            header: 'Statutory Deadline',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'validationDeadlineUP',
            header: 'Validation Deadline UP',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'applicantAddress',
            header: 'Applicant Address  ',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'applicantCountry',
            header: 'Applicant Country',
            frozen: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true,
            dropdownOption: countryData ?? []
        },
        {
            field: 'agentAddress',
            header: 'Agent Address  ',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'agentCountry',
            header: 'Agent Country',
            frozen: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true,
            dropdownOption: countryData ?? []
        },
        {
            field: 'agentName',
            header: 'Agent Name',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'createdAt',
            header: 'Created At',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            sortable: true
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        },
        {
            field: 'recordSource',
            header: 'Record Source',
            frozen: false,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true,
            filterDropDownOptions: [
                { label: 'System Sync', value: 'System Sync' },
                { label: 'Manual Entry', value: 'Manual Entry' },
                { label: 'Manual Update', value: 'Manual Update' }
            ]
        },
        {
            field: 'lastSyncDate',
            header: 'Last Sync Date',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        },
        {
            field: 'lastManualUpdateDate',
            header: 'Last Manual Update Date',
            frozen: false,
            filter: true,
            filterType: FilterType.DateRangeFilter,
            isBetweenDateRangeFilter: true,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        },
        {
            field: 'lastModifiedBy',
            header: 'Last Modified By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        },
        {
            field: 'syncVersion',
            header: 'Sync Version',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true,
            className: 'w-40',
            sortable: true
        }
    ];

    const renderButton = () => {
        return buttonChildren();
    };

    const buttonChildren = () => {
        return (
            <>
                <Tooltip
                    target=".clear-filters-button"
                    mouseTrack={false}
                    position="bottom"
                    content="Clear Filters"
                    pt={{ root: { className: 'shadow-none' } }}
                />
                <button
                    onClick={() => {
                        clearFilters();
                    }}
                    className="clear-filters-button btn px-0 w-10 h-9 min-h-9 grid place-content-center border-neutral-100 hover:bg-neutral-100 hover:text-black hover:border-neutral-100"
                    data-testid="clear-filters-button">
                    <i className="pi pi-filter-slash"></i>
                </button>
                {AuthStore.hasPermission(Permissions.CREATE_PATENT) && (
                    <button
                        onClick={() => {
                            navigate(`/patent-details/epo/0`);
                            epDetailsStore.resetStore();
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        className="btn btn-sm text-white bg-primary hover:bg-primary-200"
                        data-testid="create-epo-patent-button">
                        <i className="pi pi-plus-circle"></i>
                        Add EPO Patent
                    </button>
                )}
            </>
        );
    };

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('SETTING_PAGES.EPO.EPO_LIST'),
        emptyMessage: t('SETTING_PAGES.EPO.EMPTY_MESSAGE'),
        localStorageKey: storageKey,
        columns: hasPermissionForActions
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString()),
        hideTableExport: true,
        disabledExport: false,
        // paginationInfo?.totalRecords === 0 || (paginationInfo?.totalRecords ?? 0) > 5000,
        buttonChildren: renderButton(),
        confirmationPopupAcceptLabel: t('COMMON.YES'),
        confirmationPopupRejectLabel: t('COMMON.NO'),
        confirmationPopupDescription:
            (paginationInfo?.totalRecords ?? 0) > 5000
                ? t('SETTING_PAGES.EPO.EXPORT_CONFIRMATION')
                : t('COMMON.EXPORT_CONFIRMATION')
    };

    const handleFilter = (updatedFilter: RequestBody) => {
        updatedFilter.searchModels.forEach((s) => {
            switch (s.propertyName) {
                case 'sourceLanguage':
                case 'agentCountry':
                case 'applicantCountry':
                    s.isStringList = true;
                    break;
                default:
                    s.isStringList = null;
            }
        });

        setRequestBody(updatedFilter);
    };

    const clearFilters = () => {
        // clear your filter request model
        setRequestBody((prev) => ({
            ...prev,
            searchModels: []
        }));

        // change key to force re-render
        setTableKey((prev) => prev + 1);
        setPaginationInfo((prev) => prev && { ...prev, customNoOfRows: requestBody.pageCount });
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // side effects
    useEffect(() => {
        getEpoList(requestBody);
        getTargetLanguageData();
        getCountryList();
    }, [requestBody]);

    // Function for Export
    function exportData() {
        const baseUrl = process.env.REACT_APP_API_BASE_URL;
        const exportURL = `${END_POINT.PATENT_SERVICE.EXPORT_EPO_PATENT_RECORD}`;
        patentDetailService.exportData(requestBody, exportURL, 'epo_data.xlsx', baseUrl);
    }

    return (
        <div data-testid="epo-list" className="p-4 pb-3">
            <DataTableComponent
                key={tableKey}
                isLazy={true}
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={() => {}}
                onRowClicked={(e) => {
                    hasPermissionForActions && navigate(`/patent-details/epo/${e?.data?.id}`);
                }}
                exportData={exportData}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
            />
        </div>
    );
};

export default EpoList;
