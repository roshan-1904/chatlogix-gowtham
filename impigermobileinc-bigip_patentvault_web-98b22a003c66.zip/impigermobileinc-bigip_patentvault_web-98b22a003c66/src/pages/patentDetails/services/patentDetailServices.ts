import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';
import { notificationModel } from 'core/store/notificationStore/notificationStore';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

/**
 * Fetch table data based on the given page type and request body.
 * @param {RequestBody} requestBody - The request body.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
const getEpoTableData = async <T>(requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${END_POINT.PATENT_SERVICE.GET_EPO_PATENT_LIST}`;

    try {
        const response = await httpService.post<T, RequestBody>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Fetches/updates EPO patent details based on the given ID.
 * @param requestBody - The request body containing the EPO patent details.
 */
export const getEPPatentDetails = async <EpoListApiResponse>(
    requestBody?: any
): Promise<EpoListApiResponse> => {
    const apiUrl = `${END_POINT.PATENT_SERVICE.GET_EPO_PATENT_DETAILS}?id=${requestBody?.id}`;
    try {
        const response: EpoListApiResponse = await httpService.get<EpoListApiResponse>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching EPO patent details:', error);
        throw error;
    }
};

/**
 * Creates a new EPO patent record.
 * @param requestBody - The request body containing the EPO patent details.
 */
export const createEpoRecord = async <EpoListApiResponse>(
    requestBody?: any
): Promise<EpoListApiResponse> => {
    const apiUrl = `${END_POINT.PATENT_SERVICE.CREATE_EPO_PATENT_RECORD}`;
    try {
        const response: EpoListApiResponse = await httpService.post<EpoListApiResponse, any>(
            apiUrl,
            requestBody
        );

        return response;
    } catch (error) {
        console.error('Error creating EPO patent record:', error);
        throw error;
    }
};

/**
 * Updates an existing EPO patent record.
 * @param requestBody - The request body containing the EPO patent details.
 */
export const updateEpoRecord = async <EpoListApiResponse>(
    requestBody?: any
): Promise<EpoListApiResponse> => {
    const apiUrl = `${END_POINT.PATENT_SERVICE.UPDATE_EPO_PATENT_RECORD}`;
    try {
        const response: EpoListApiResponse = await httpService.post<EpoListApiResponse, any>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error updating EPO patent record:', error);
        throw error;
    }
};

const showToastMessage = (message: notificationModel) => {
    NotificationStore.showAlert(message);
};
/**
 * Fetches data for downloading a data for export as excel from the server.
 * @param {B} requestBody - The request body to send to the server.
 * @returns {Promise<T>} A Promise resolving to the fetched data.
 * @throws {Error} Throws an error if the request fails.
 */
const exportData = async <T, B>(
    requestBody: B,
    url: string,
    fileName: string,
    baseUrl?: string
): Promise<T | undefined> => {
    try {
        const apiUrl = url;

        const payload = {
            ...requestBody,
            pageNo: 1
        };
        const disableErrorToast = true;
        const response = await httpService.export<T, B>(
            apiUrl,
            payload,
            {},
            false,
            baseUrl,
            disableErrorToast
        );
        const fileUrl = window.URL.createObjectURL(
            new Blob([response as Blob], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            })
        );
        const link = document.createElement('a');
        link.href = fileUrl;
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        return response;
    } catch (error: any) {
        const message: string = (await error?.response?.data?.text()) ?? '';
        const errorObject = JSON.parse(message);
        showToastMessage({
            type: ToastType.ERROR,
            message: errorObject?.Message ? errorObject.Message : 'An error occurred during export.'
        });
        return error;
    }
};

const patentDetailService = {
    getEpoTableData,
    getEPPatentDetails,
    createEpoRecord,
    updateEpoRecord,
    exportData
};

export default patentDetailService;
