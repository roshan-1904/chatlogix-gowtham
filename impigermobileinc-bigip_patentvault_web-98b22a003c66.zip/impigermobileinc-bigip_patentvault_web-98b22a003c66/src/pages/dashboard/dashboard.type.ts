export interface dashboardResponse {
    dashboardId: string;
    guestToken: string;
    dashboardName: string;
}
