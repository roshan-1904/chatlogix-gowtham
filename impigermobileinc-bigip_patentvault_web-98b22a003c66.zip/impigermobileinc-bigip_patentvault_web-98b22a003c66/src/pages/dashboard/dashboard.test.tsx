import { render, screen, waitFor } from '@testing-library/react';
import DashBoard from './dashboard';
import embedService from 'components/embedDashboard/service/embedService';
import { dashboardResponse } from './dashboard.type';
import '@testing-library/jest-dom';
import userEvent from '@testing-library/user-event';

// Mock embedService
jest.mock('components/embedDashboard/service/embedService');

describe('DashBoard Component', () => {
    const mockResponse: dashboardResponse[] = [
        {
            dashboardId: '1',
            guestToken: 'token1',
            dashboardName: 'Dashboard 1'
        },
        {
            dashboardId: '2',
            guestToken: 'token2',
            dashboardName: 'Dashboard 2'
        }
    ];

    beforeEach(() => {
        (embedService.fetchGuestTokenAndId as jest.Mock).mockResolvedValue(mockResponse);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    test.skip('renders without crashing', () => {
        render(<DashBoard />);
        expect(screen.getByText('Quote/Order Insights')).toBeInTheDocument();
    });

    test.skip('fetches and displays dashboards on initial render', async () => {
        render(<DashBoard />);

        // Wait for the fetch call to complete and UI to update
        await waitFor(() => {
            expect(embedService.fetchGuestTokenAndId).toHaveBeenCalledTimes(1);
        });

        // Ensure the correct number of tabs are rendered
    });

    test.skip('updates active tab on tab click', async () => {
        render(<DashBoard />);

        await waitFor(() => {
            expect(embedService.fetchGuestTokenAndId).toHaveBeenCalledTimes(1);
            const firstTab = screen.getByText('Dashboard 1');
            expect(firstTab).toBeInTheDocument();

            const secondTab = screen.getByText('Dashboard 2');
            userEvent.click(secondTab);

            // Check if the active tab has changed
            expect(secondTab.closest('li')).toHaveClass('p-highlight');
        });
    });
});
