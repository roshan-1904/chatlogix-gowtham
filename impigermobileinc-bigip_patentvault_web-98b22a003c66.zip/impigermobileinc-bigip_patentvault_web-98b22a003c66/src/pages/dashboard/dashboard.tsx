import { useState, useRef, useEffect } from 'react';
import EmbedDashBoard from '../../components/embedDashboard/embedDashboard';
import embedService from 'components/embedDashboard/service/embedService';
import { dashboardResponse } from './dashboard.type';
const DashBoard = () => {
    const myRef = useRef<HTMLDivElement>(null);
    const [dashboardRes, setDashboardRes] = useState<dashboardResponse[]>([]);

    useEffect(() => {
        getDashboardTokenAndId();
    }, []);

    // Function to get DashboardId and Token
    const getDashboardTokenAndId = async () => {
        try {
            const response: dashboardResponse[] = await embedService.fetchGuestTokenAndId<any>();
            if (response && response.length > 0) {
                setDashboardRes(response);
            }
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div>
            {dashboardRes && dashboardRes.length > 0 && (
                <div className="p-3">
                    <EmbedDashBoard
                        data-testid="embed-dashboard"
                        ref={myRef}
                        dashBoardId={dashboardRes[0].dashboardId}
                        guestToken={dashboardRes[0].guestToken}
                        containerName="my-superset-container"
                    />
                </div>
            )}
        </div>
    );
};

export default DashBoard;
