export interface QuoteOrderModel {
    id: number;
    patentCategoryId: number; // service id
    patentCategoryName: string; // service name
    patentServiceTypeId: number; // category id
    patentServiceTypeName: string; // category name
    requestNumber: string;
    requestTypeId: number;
    sourceLanguage?: string;
    contact?: string;
    company?: string;
    patentApplicationNumber?: string;
    patentApplicants?: string | string[];
    patentPublicationNumber?: string;
    referenceNumber?: string;
    requestStatusDisplayName?: string;
    languageCombination?: string | string[];
    contactEmail?: string;
    targetCountries?: string | string[];
    filingDate?: string;
    projectManager?: string;
    deliveryDate?: string;
    requestType?: string;
    overdue?: string;
    receptionDate?: string;
    po?: string;
    mailCC?: string | string[];
    deliverto?: string | string[];
    createdBy?: string;
    createdAt?: string;
    updatedAt?: string;
    serviceUniqueName?: string;
    isActive?: boolean;
    status?: string;
    deletedAt?: string | null;
    deletedBy?: string | null;
    isQuote?: boolean;
    billAmount: string | null;
    margin: number | null;
    marginPercentage: number | null;
    isBothDecideLater: boolean | null;
    epTotal: number | null;
    upTotal: number | null;
    claimsTotal: number | null;
    currencySymbol: string;
    projectedRevenue: number | null;
}

export interface QuoteOrderResponseModel {
    quoteOrderModel: QuoteOrderModel[];
    totalRecord: number;
}

export interface QuoteStatusUpdate {
    success: boolean;
    message: string;
}

export interface OrderSave {
    requestId: number;
    orderNumber: number;
    orderRequestNumber: string;
    totalWordCount: number;
    claimsPriority: boolean;
    specialInstructions: string;
    isClaims71_3: boolean;
    orderDate: string;
    completedDate: any;
    instructionByContactUser: string;
    assignPM: string;
    requestCurrencyId: number;
    grandTotal: number;
    additionalInfo: object;
    disclaimerInfoList: [];
    patentCountrySummaryList: [];
    quoteStatus: number;
    requestedDeliveryDate: any;
    referenceNumber: string;
    emailID: string;
    deliverto: string;
    mailcc: string;
    po: string;
    quoteDatetime: any;
    targetDateTime: any;
    instructionByContanctUser: string;
    instructionByPM: string;
    disclaimer: string;
    customInstruction: string;
    countryId: number;
    languageId: number;
    countryName: any;
    entityType: number;
    agencyFee: number;
    officialFee: number;
    translationFee: number;
    total: number;
    isprimary: boolean;
    groupId: any;
    ep: boolean;
    up: any;
    isBothDecideLater: boolean;
}

interface PdfFile {
    pdfFile: string;
    fileName: string;
}

interface ExcelFile {
    excelFile: string;
    fileName: string;
}

export interface OrderResponseMustHaveProps {
    orderRequestNumber: string;
}
export interface OrderSaveResponse<T extends OrderResponseMustHaveProps> {
    orderResponse: T;
    pdfFiles: PdfFile[];
    excelFiles: ExcelFile[]; // Adjust type as per actual data structure if needed
    generatePDFStatus: string;
}

export const notVisibleForContactUserField = {
    OVER_DUE: 'overdue'
};
