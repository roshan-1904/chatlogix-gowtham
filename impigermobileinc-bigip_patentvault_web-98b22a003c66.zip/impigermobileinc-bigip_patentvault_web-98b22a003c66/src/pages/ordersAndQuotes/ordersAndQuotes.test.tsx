import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import OrdersAndQuotesPage from './ordersAndQuotes';
import OrdersAndQuotesService from './service/ordersAndQuotes.service';
import { BrowserRouter } from 'react-router-dom';
import { QuoteOrderResponseModel } from './types/ordersAndQuotes.types';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { isContactUser } from 'core/utils/utils';
import AuthStore from 'core/store/authStore/authStore';
// import viewOrderQuoteServices from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';

jest.mock('core/store/notificationStore/notificationStore');
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({
        pathname: '/orders-quotes/details/'
    }),
    useParams: () => ({
        requestId: '1'
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('./service/ordersAndQuotes.service', () => ({
    getCountryList: jest.fn(),
    getLanguageList: jest.fn(),
    getRequestStatusList: jest.fn(),
    getOrderAndQuoteList: jest.fn(),
    updateApproveQuote: jest.fn()
}));

jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService', () => ({
    checkFeesHasZeroValues: jest.fn()
}));

jest.mock('pages/settingsPages/service/settings.service', () => ({
    exportData: jest.fn()
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn(),
    ToastType: {
        SUCCESS: 'success',
        ERROR: 'error'
    }
}));

jest.mock('core/utils/utils', () => ({
    isContactUser: jest.fn(),
    useDebouncedWaitCallback: jest.fn(),
    formatCurrency: jest.fn()
}));

const mockData: QuoteOrderResponseModel = {
    quoteOrderModel: [
        {
            id: 3916,
            patentCategoryId: 5,
            patentCategoryName: 'Others',
            patentServiceTypeId: 24,
            patentServiceTypeName: 'patent_non_filing',
            requestNumber: 'R40091',
            requestTypeId: 1,
            sourceLanguage: 'Afrikaan',
            contact: 'test',
            company: 'testCompany',
            patentApplicationNumber: 'string',
            patentPublicationNumber: 'string',
            requestStatusDisplayName: 'Waiting for Approval',
            languageCombination: 'Chinese,English',
            contactEmail: 'test@gmail.com',
            targetCountries: 'Algeria,ARIPO,Australia,Bahrain,Europe,Israel',
            filingDate: '',
            projectManager: 'tester',
            deliveryDate: '',
            mailCC: 'mailcctest1,  mailcctest2',
            deliverto: 'delivertotest1, delivertotest2',
            billAmount: '$ 10.00',
            margin: 0.0,
            marginPercentage: 0.0,
            currencySymbol: '',
            epTotal: 0,
            isBothDecideLater: true,
            upTotal: 0,
            claimsTotal: 0,
            projectedRevenue: 0
        },
        {
            id: 3901,
            patentCategoryId: 5,
            patentCategoryName: 'Others',
            patentServiceTypeId: 24,
            patentServiceTypeName: 'patent_non_filing',
            requestNumber: 'R400885',
            requestTypeId: 2,
            sourceLanguage: 'English',
            contact: 'test1',
            company: 'ABC Technologies',
            patentApplicationNumber: 'P3211',
            patentPublicationNumber: 'P12345',
            requestStatusDisplayName: 'Preparing Quote',
            languageCombination: 'Arabic,English,Thai,Ukrainian,Vietnamese',
            contactEmail: 'test1@gmail.com',
            targetCountries:
                'Albania,Angola,Thailand,Ukraine,United Arab Emirates,United States,Vietnam',
            filingDate: '',
            projectManager: 'John Doe,Emily Brown',
            deliveryDate: '',
            mailCC: 'mailcctest3,  mailcctest4',
            deliverto: 'delivertotest3, delivertotest4',
            billAmount: '$ 10.00',
            margin: 0.0,
            marginPercentage: 0.0,
            currencySymbol: '',
            epTotal: 0,
            isBothDecideLater: null,
            upTotal: 0,
            claimsTotal: 0,
            projectedRevenue: 0
        },
        {
            id: 3902,
            patentCategoryId: 5,
            patentCategoryName: 'Others',
            patentServiceTypeId: 24,
            patentServiceTypeName: 'patent_non_filing',
            requestNumber: 'R240819-2',
            requestTypeId: 2,
            sourceLanguage: 'English',
            contact: 'test3',
            company: 'ABC Technologies3',
            patentApplicationNumber: 'P32113',
            patentPublicationNumber: 'P123453',
            requestStatusDisplayName: 'Waiting for Approval',
            languageCombination: 'Arabic,English,Thai,Ukrainian,Vietnamese',
            contactEmail: 'test1@gmail.com',
            targetCountries:
                'Albania,Angola,Thailand,Ukraine,United Arab Emirates,United States,Vietnam',
            filingDate: '',
            projectManager: 'John Doe,Emily Brown',
            deliveryDate: '',
            mailCC: 'mailcctest5,  mailcctest6',
            deliverto: 'delivertotest5, delivertotest6',
            billAmount: '$ 10.00',
            margin: 0.0,
            marginPercentage: 0.0,
            currencySymbol: '',
            epTotal: 0,
            isBothDecideLater: null,
            upTotal: 0,
            claimsTotal: 0,
            projectedRevenue: 0
        }
    ],
    totalRecord: 2
};

describe('Order and Quote page', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    // test('On click Action item - edit option', async () => {
    //     (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
    //     (isContactUser as jest.Mock).mockReturnValue(true);
    //     const mockNavigate = jest.fn();
    //     // eslint-disable-next-line @typescript-eslint/no-var-requires
    //     jest.spyOn(require('react-router-dom'), 'useNavigate').mockReturnValue(mockNavigate);
    //     render(
    //         <BrowserRouter>
    //             <OrdersAndQuotesPage></OrdersAndQuotesPage>
    //         </BrowserRouter>
    //     );

    //     await waitFor(() => {
    //         const actionButton = screen.getAllByTestId('DataTable-menuIcon');

    //         fireEvent.click(actionButton[0]);
    //         const editButton = screen.getAllByText('QUOTE_AND_ORDER.EDIT_QUOTE');
    //         fireEvent.click(editButton[0]);
    //         expect(actionButton[0]).toBeInTheDocument();
    //         expect(editButton[0]).toBeInTheDocument();
    //     });
    // });

    // test('On click Action item - approve quote option', () => {
    //     (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
    //     (viewOrderQuoteServices.getCountryCostSummaryTotal as jest.Mock).mockResolvedValue({
    //         isCountryTotalValueZero: true // or false depending on what you want to test
    //     });
    //     (OrdersAndQuotesService.updateApproveQuote as jest.Mock).mockResolvedValue(true);
    //     render(
    //         <BrowserRouter>
    //             <OrdersAndQuotesPage />
    //         </BrowserRouter>
    //     );

    //     const actionButton = screen.getAllByTestId('DataTable-menuIcon');
    //     expect(actionButton[0]).toBeInTheDocument();
    //     fireEvent.click(actionButton[0]);
    //     const editButton = screen.getAllByText('QUOTE_AND_ORDER.APPROVE_QUOTE');
    //     expect(editButton[0]).toBeInTheDocument();
    //     fireEvent.click(editButton[0]);
    // });

    test('On click Request Number', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
        const mockNavigate = jest.fn();
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        jest.spyOn(require('react-router-dom'), 'useNavigate').mockReturnValue(mockNavigate);
        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            const requestNumber = screen.getByText('R240819-2');
            expect(requestNumber).toBeInTheDocument();
            fireEvent.click(requestNumber);
        });
        expect(mockNavigate).toHaveBeenCalledWith('/orders-quotes/details/3902', {
            state: {
                id: 3902,
                requestNumber: 'R240819-2',
                statusName: 'Waiting for Approval'
            }
        });
    });

    test('renders page and verifies elements', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('MENU.ORDERS_QUOTES')).toBeInTheDocument();
            expect(screen.getByText('QUOTE_AND_ORDER.FILTER_BY')).toBeInTheDocument();
            expect(screen.getByText('Request No.')).toBeInTheDocument();
            expect(screen.getByText('Contact')).toBeInTheDocument();
            expect(screen.getByText('Company')).toBeInTheDocument();
        });
    });

    test('On click Action item', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
        (isContactUser as jest.Mock).mockReturnValue(true);
        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            const actionButton = screen.getAllByTestId('DataTable-menuIcon');
            expect(actionButton[0]).toBeInTheDocument();
        });
    });

    test('renders table data correctly', () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        setTimeout(() => {
            expect(screen.getByText('R40091')).toBeInTheDocument();
            expect(screen.getByText('test1')).toBeInTheDocument();
            expect(screen.getByText('ABC Technologies')).toBeInTheDocument();
            expect(screen.getByText('P3211')).toBeInTheDocument();
            expect(screen.getByText('P12345')).toBeInTheDocument();
            expect(screen.getByText('In Progress')).toBeInTheDocument();
            expect(screen.getByText('Arabic')).toBeInTheDocument();
            expect(screen.getByText('test1@gmail.com')).toBeInTheDocument();
            expect(screen.getByText('Vietnam')).toBeInTheDocument();
            expect(screen.getByText('tester')).toBeInTheDocument();
        }, 1000);
    });

    test('filters data correctly using global filter', () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        setTimeout(() => {
            const dropdownFilter = screen.getAllByText('All')[0];
            fireEvent.click(dropdownFilter);

            const selectOrder = screen.getByText('Orders');
            fireEvent.click(selectOrder);

            expect(screen.getByText('R400885')).toBeInTheDocument();
        }, 1000);
    });

    test('handles API failures gracefully', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockRejectedValue(
            new Error('API Error')
        );

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('MENU.ORDERS_QUOTES')).toBeInTheDocument(); // Or any error message you display
        });
    });

    test('triggers export functionality on button click', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
        (SettingsService.exportData as jest.Mock).mockResolvedValue('mockExportData');

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            const exportButton = screen.getByTestId('export-list-button');
            expect(exportButton).toBeInTheDocument();
            fireEvent.click(exportButton);
            const confirmExportButton = screen.getByText('COMMON.EXPORT_CONFIRMATION');
            expect(confirmExportButton).toBeInTheDocument();
            const yesButton = screen.getByText('COMMON.YES');
            fireEvent.click(yesButton);
            expect(SettingsService.exportData).toHaveBeenCalled();
        });
    });

    test('handles export API failure gracefully', () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
        // (SettingsService.exportData as jest.Mock).mockRejectedValue(new Error('Export Error'));
        (OrdersAndQuotesService.getCountryList as jest.Mock).mockRejectedValue(new Error('Error'));
        (OrdersAndQuotesService.getLanguageList as jest.Mock).mockRejectedValue(new Error('Error'));
        (OrdersAndQuotesService.getRequestStatusList as jest.Mock).mockRejectedValue(
            new Error('Error')
        );

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );
    });

    test('on clicking create button', async () => {
        (OrdersAndQuotesService.getOrderAndQuoteList as jest.Mock).mockResolvedValue(mockData);
        const mockNavigate = jest.fn();
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        jest.spyOn(require('react-router-dom'), 'useNavigate').mockReturnValue(mockNavigate);
        jest.spyOn(AuthStore, 'hasPermission').mockImplementation(
            (permission) => permission === 'createquote' || permission === 'createorder'
        );

        render(
            <BrowserRouter>
                <OrdersAndQuotesPage />
            </BrowserRouter>
        );

        await waitFor(() => {
            const createButton = screen.getByTestId('create-dropdown');
            expect(createButton).toBeInTheDocument();
            fireEvent.click(createButton);
            const createOrderButton = screen.getByTestId('create-order');
            expect(createOrderButton).toBeInTheDocument();
            fireEvent.click(createOrderButton);
        });
    });
});
