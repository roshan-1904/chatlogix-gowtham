import { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import stepperStore, {
    initialProgressStepperState
} from 'core/store/stepperStore/progressStepper.store';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    dropdownOption,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ActiveStatusEnum,
    FilterType,
    RequestStatusEnum,
    TableTypes,
    ValueType
} from 'shared/dataTable/constant/dataTable.constant';
import createOrderIcon from 'assets/images/create-order-icon.svg';
import createQuoteIcon from 'assets/images/create-quote-icon.svg';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
    QuoteOrderModuleStore,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { PATHS } from 'constants/routes.constant';
import {
    MODE,
    ROLE,
    SCREEN_RESOLUTION,
    SERVICE_TYPE_CATEGORY,
    YES_NO_LIST_BOOL
} from 'constants/app.constant';
import OrdersAndQuotesService from './service/ordersAndQuotes.service';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import {
    QuoteOrderModel,
    QuoteOrderResponseModel,
    QuoteStatusUpdate
} from './types/ordersAndQuotes.types';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { END_POINT } from 'constants/endPoint';

import { Dropdown, DropdownProps } from 'primereact/dropdown';
import { MenuItem } from 'primereact/menuitem';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import ActionMenu from 'shared/dataTable/components/actionMenu/actionMenu';
import viewOrderQuoteServices, {
    getPDFData
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { Dialog } from 'primereact/dialog';
import utils, {
    formatCurrency,
    getWindowSize,
    isContactUser,
    isHRUser,
    isSalesRep,
    isStaffUser,
    isVendorSpecialistUser,
    isVendorUser
} from 'core/utils/utils';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { DataTableSelectEvent } from 'primereact/datatable';
import { Permissions } from 'constants/permissions';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { previewDialogPopup } from 'constants/styles.constant';
import {
    AllLanguageResponse,
    AllLanguageResponseType
} from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import { EPSaveAmountModel } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

type PopupID = 'approveQuoteWithZeroFees' | 'activeInactiveAction' | 'IsBothDecideLaterAction';
interface PopupData {
    visible: boolean;
    header: string;
    subHeader: string;
    description: string | JSX.Element;
    popupId: PopupID | null;
    acceptLabel: string | null;
    rejectLabel: string | null;
    customWidth: string;
}

function OrdersAndQuotesPage() {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const [quoteOrderData, setQuoteOrderData] = useState<QuoteOrderModuleStore>(
        quoteOrderModuleStore?.initialState
    );
    const [countryList, setCountryList] = useState<any>();
    const [showModal, setShowModal] = useState<boolean>(false);
    const [languageList, setLanguageList] = useState<dropdownOption[]>([]);
    const [requestStatusList, setRequestStatusList] = useState<any>();
    const [quoteOrderTableData, setQuoteOrderTableData] = useState<QuoteOrderModel[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const emptyMessage = t('QUOTE_AND_ORDER.EMPTY_MESSAGE');
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 25
    });
    const [internalValue, setInternalValue] = useState<any>('');
    const handleValueChange = (propertyName: any, value: any) => {
        setInternalValue(value);
        handleOnChange(propertyName, value);
    };
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const [toggleRowData, setToggleRowData] = useState<QuoteOrderModel>();
    const RequestTypeId = {
        IsQuote: 1,
        IsOrder: 2
    };
    const [isMobile, setIsMobile] = useState(false);
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserId = userDetails.userInfo.roleId;
    const isDetailAccess =
        loggedInUserId === ROLE.VENDOR_SPECIALIST.roleId || loggedInUserId === ROLE.HR.roleId;
    const [popupData, setPopupData] = useState<PopupData>({
        visible: false,
        header: '',
        subHeader: '',
        description: '',
        popupId: null,
        acceptLabel: null,
        rejectLabel: null,
        customWidth: ''
    });
    const isThisStaffUser = isStaffUser(loggedInUserId);
    const isThisVendorUser = isVendorUser(loggedInUserId);
    const isThisContactUser = isContactUser(loggedInUserId);
    const isThisSalesRepUser = isSalesRep(loggedInUserId);
    const isThisHRUser = isHRUser(loggedInUserId);
    const isThisV3User = isVendorSpecialistUser(loggedInUserId);
    const isThisContactUserExcludedSales = isContactUser(loggedInUserId, true);

    useEffect(() => {
        getSourceLanguages();
        getCountryList();
        // getLanguageList();
        getRequestStatusList();
    }, []);

    useEffect(() => {
        getOrderAndQuoteTableData(requestBody);
    }, [requestBody]);

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= SCREEN_RESOLUTION.TABLET); // Adjust the width as per your requirement
        };

        window.addEventListener('resize', handleResize);
        handleResize(); // Call initially to set the state based on the initial window size

        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    const getSourceLanguages = async () => {
        try {
            const requestBodySorting = { propertyName: 'id', value: 'asc' };
            const response: AllLanguageResponse = await PVSettingsService.getAllLanguages(
                requestBodySorting,
                true
            );
            if (response?.data) {
                const list: AllLanguageResponseType[] = response.data;
                setLanguageList(
                    list.map((item) => ({
                        label: item.name,
                        value: item.name
                    }))
                );
            }
        } catch (error) {
            console.error(`Error in 'getSourceLanguages()':`, error);
            return null;
        }
    };

    // Function for Get Order and Quote Data using Api
    const getOrderAndQuoteTableData = async (body: RequestBody) => {
        try {
            const response =
                await OrdersAndQuotesService.getOrderAndQuoteList<QuoteOrderResponseModel>(body);
            const transResponse = transformResponse(response);
            setQuoteOrderTableData(transResponse?.quoteOrderModel);
            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.totalRecord / body.pageCount),
                totalRecords: response.totalRecord,
                customNoOfRows: 25, // Custom default rows per page
                rowsPerPageOptions: [10, 25, 50, 100] // Custom rows per page options
            };
            setPaginationInfo(pagination);
            if (!response?.quoteOrderModel || response.quoteOrderModel.length === 0) {
                setEmptyMessage(emptyMessage);
            }
        } catch (error) {
            console.error(error);
            setEmptyMessage(emptyMessage);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_QUOTE_AND_ORDER_LIST'),
                ToastType.ERROR
            );
        }
    };

    // Function to transform comma-separated strings into arrays
    const transformResponse = (response: QuoteOrderResponseModel): QuoteOrderResponseModel => {
        const transformedQuoteOrderModel = response?.quoteOrderModel.map(
            (order: QuoteOrderModel) => {
                // Split comma-separated strings into arrays
                if (
                    order &&
                    typeof order?.languageCombination === 'string' &&
                    order?.languageCombination.trim() !== ''
                ) {
                    // Split comma-separated string into array
                    let languageCombinationArray = order.languageCombination
                        .split(',')
                        .map((item) => item.trim());

                    if (order && order?.sourceLanguage) {
                        // Check if sourceLanguage exists in languageCombination
                        const sourceLanguageIndex = languageCombinationArray.indexOf(
                            order?.sourceLanguage
                        );

                        // If sourceLanguage exists, move it to the first index
                        if (sourceLanguageIndex !== -1) {
                            // Remove sourceLanguage from its current index
                            languageCombinationArray = languageCombinationArray.filter(
                                (item) => item !== order.sourceLanguage
                            );

                            // Insert sourceLanguage at the beginning of the array
                            languageCombinationArray.unshift(order?.sourceLanguage);
                        }
                    }

                    // Update order's languageCombination
                    order.languageCombination = languageCombinationArray;
                }
                if (
                    typeof order?.targetCountries === 'string' &&
                    order?.targetCountries.trim() !== ''
                ) {
                    order.targetCountries = order.targetCountries
                        .split(',')
                        .map((item) => item.trim());
                }
                if (typeof order?.mailCC === 'string' && order?.mailCC.trim() !== '') {
                    order.mailCC = order.mailCC.split(',').map((item) => item.trim());
                }
                if (typeof order?.deliverto === 'string' && order?.deliverto.trim() !== '') {
                    order.deliverto = order.deliverto.split(',').map((item) => item.trim());
                }
                if (
                    typeof order?.patentApplicants === 'string' &&
                    order?.patentApplicants.trim() !== ''
                ) {
                    order.patentApplicants = order.patentApplicants
                        .split('=')
                        .map((item) => item.trim());
                }

                return order;
            }
        );

        return { ...response, quoteOrderModel: transformedQuoteOrderModel };
    };

    // Function for Export Quote and Order
    function exportData() {
        try {
            const exportTaskURL = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.EXPORT_ORDER_AND_QUOTE}`;
            SettingsService.exportData(
                requestBody,
                exportTaskURL,
                'Orders/Quotes Data.xlsx',
                quoteBaseURL
            );
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.EXPORT_QUOTE_AND_ORDER_LIST'),
                ToastType.ERROR
            );
        }
    }

    // Function for Get Country List using Api
    const getCountryList = async () => {
        try {
            const response = await OrdersAndQuotesService.getCountryList<string[]>();
            setCountryList(response);
        } catch (error) {
            console.error(error);
            showToastMessage(t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_COUNTRY_LIST'), ToastType.ERROR);
        }
    };

    // // Function for Get Language List using Api
    // const getLanguageList = async () => {
    //     try {
    //         const response = await OrdersAndQuotesService.getLanguageList<string[]>();
    //         setLanguageList(response);
    //     } catch (error) {
    //         console.error(error);
    //         showToastMessage(
    //             t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_REQUEST_STATUS_LIST'),
    //             ToastType.ERROR
    //         );
    //     }
    // };

    // Function for Get Request Status List using Api
    const getRequestStatusList = async () => {
        try {
            const response = await OrdersAndQuotesService.getRequestStatusList<any>();
            setRequestStatusList(response);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_REQUEST_STATUS_LIST'),
                ToastType.ERROR
            );
        }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const handleNavigation = (rowData: QuoteOrderModel) => {
        /** check permission */
        const hasPermission =
            AuthStore.hasPermission(Permissions.VIEW_QUOTE) ||
            AuthStore.hasPermission(Permissions.VIEW_ORDER);

        if (!isDetailAccess && rowData && hasPermission) {
            if (rowData.patentCategoryId === SERVICE_TYPE_CATEGORY.STANDARD) {
                navigate(
                    `/${PATHS.ORDER_QUOTE}/${PATHS.STANDARD}/${PATHS.DETAILS}/${rowData?.id}`,
                    {
                        state: {
                            id: rowData?.id,
                            requestNumber: rowData?.requestNumber,
                            statusName: rowData?.requestStatusDisplayName
                        }
                    }
                );
            } else if (
                rowData.patentServiceTypeId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['upc_opt_out']
            ) {
                navigate(
                    `/${PATHS.ORDER_QUOTE}/${PATHS.DETAILS}/${PATHS.UPC_OPT_OUT}/${rowData?.id}`,
                    {
                        state: {
                            id: rowData?.id,
                            requestNumber: rowData?.requestNumber,
                            statusName: rowData?.requestStatusDisplayName
                        }
                    }
                );
            } else {
                navigate(`/orders-quotes/details/${rowData?.id}`, {
                    state: {
                        id: rowData?.id,
                        requestNumber: rowData?.requestNumber,
                        statusName: rowData?.requestStatusDisplayName
                    }
                });
            }
        }
    };

    // template for request Number column
    const requestNumberTemplate = (rowData: QuoteOrderModel) => {
        return (
            <div className="group relative w-fit">
                <div
                    data-testid="dataTable-link-format"
                    className={`flex items-center ${rowData.requestTypeId === RequestTypeId.IsQuote ? '' : 'ml-4'}`}
                    onClick={() => handleNavigation(rowData)}
                    onKeyDown={() => handleNavigation(rowData)}>
                    {rowData.requestTypeId === RequestTypeId.IsQuote && (
                        <div className="w-1.5 h-1.5 mr-2 rounded-full bg-yellow-500"></div>
                    )}
                    <span className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer">
                        {rowData.requestNumber}
                    </span>
                </div>
                <button
                    className="invisible group-hover:visible absolute -right-6 z-10 -top-1"
                    onClick={() => {
                        navigator.clipboard.writeText(rowData.requestNumber ?? '');
                        NotificationStore.showAlert({
                            type: ToastType.SUCCESS,
                            message: t('COMMON.COPY_SUCCESS')
                        });
                    }}>
                    <i
                        title={t('COMMON.COPY_TO_CLIPBOARD')}
                        className="pi pi-copy text-black/50 hover:text-black/70 ml-2 cursor-pointer "
                    />
                </button>
            </div>
        );
    };

    // Define a helper function to filter items based on the presence of the id property
    function filterMenuItems(items: (MenuItem | MenuItem[])[]): MenuItem[] {
        return items.filter((item): item is MenuItem => {
            return typeof item === 'object' && 'id' in item;
        });
    }

    const editQuote = async (rowData: QuoteOrderModel | null) => {
        try {
            if (!rowData) throw Error('Quote Data not found');

            const info = quoteOrderModuleStore.getData().info;
            const isSTDFlow = rowData.patentCategoryId === SERVICE_TYPE_ID.other_translations;
            const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                ...info,
                primaryId: rowData.id, // store this id as 'PrimaryId' to access the edit-API.
                mode: rowData.requestTypeId,
                isSTDFlow,
                isEditFlow: true
            };
            if (
                rowData.patentServiceTypeId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['upc_opt_out']
            ) {
                navigate(
                    `/${PATHS.ORDER_QUOTE}/${PATHS.DETAILS}/${PATHS.UPC_OPT_OUT}/${rowData.id}`,
                    {
                        state: {
                            id: rowData.id,
                            requestNumber: rowData.requestNumber,
                            statusName: rowData.requestStatusDisplayName
                        }
                    }
                );
            } else if (JSON.stringify(info) !== JSON.stringify(updatedQuoteOrderInfo)) {
                quoteOrderModuleStore.updatePage('info', updatedQuoteOrderInfo);

                await new Promise((r) => setTimeout(r, 100));
                navigate(`/${PATHS.ORDER_QUOTE}/${PATHS.EDIT}/${PATHS.SERVICE_TYPE}`);
            }
        } catch (error) {
            console.error('Error in editQuote(): ', error);
        }
    };

    // Action Button Template
    const actionItems = (rowData: QuoteOrderModel) => {
        const isWFA = rowData.requestStatusDisplayName === RequestStatusEnum.WAITING_FOR_APPROVAL;
        const isPreparingQuote =
            rowData.requestStatusDisplayName === RequestStatusEnum.PREPARING_QUOTE;
        const isQuoteToOrder = rowData?.isQuote === true;
        const isShowPreviewAction = isQuoteToOrder && !isPreparingQuote;

        let filterItems: any = [];

        if (isQuoteToOrder && isThisContactUser) {
            if (isWFA) filterItems = ['3', '4', '6'];
            else filterItems = null;
        } else if (!isThisContactUser && isWFA) {
            filterItems = ['3', '4', '5', '6', '7'];
        } else if (!isThisContactUser && isPreparingQuote) {
            filterItems = ['3', '6', '7'];
        } else {
            filterItems = isThisStaffUser || isThisVendorUser ? ['6', '7'] : null;
        }

        if (!isShowPreviewAction && filterItems) {
            filterItems = filterItems.filter((item: string) => item !== '6');
        }

        // Extract items with specific ids ('1', '2', '3')
        const extractedItems =
            filterItems &&
            menuItems.map((itemGroup) => {
                if (Array.isArray(itemGroup.items)) {
                    return filterMenuItems(itemGroup.items)
                        .filter((item) => filterItems.includes(item.id as string))
                        .filter(
                            /** check permission */
                            (item) => {
                                if (item.id === '3') {
                                    return AuthStore.hasPermission(Permissions.CREATE_QUOTE);
                                } else if (item.id === '4') {
                                    return AuthStore.hasPermission(Permissions.APPROVE_QUOTE);
                                } else if (item.id === '5') {
                                    return AuthStore.hasPermission(Permissions.DELETE_QUOTE);
                                } else if (item.id === '6') {
                                    return isShowPreviewAction;
                                } else if (item.id === '7') {
                                    return AuthStore.hasPermission(Permissions.EXPORT_QUOTE);
                                }
                                return true; // For other items, no permission check
                            }
                        );
                } else return [];
            });

        let modifiedList: any = [];

        if (extractedItems != null && extractedItems.length > 0) {
            modifiedList = [{ items: extractedItems[0] }];
        } else {
            modifiedList = [{ items: [] }];
        }
        return filterItems ? (
            <ActionMenu
                items={modifiedList ?? []}
                onClickToggle={() => {
                    setToggleRowData(rowData);
                }}
            />
        ) : (
            <></>
        );
    };

    let contactColumnNumber = 0;
    const contactUserSchema: ColumnDefinition[] = [
        {
            field: 'requestNumber',
            header: 'Request No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: requestNumberTemplate,
            columnNumber: contactColumnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'requestStatusDisplayName',
            header: 'Request Status',
            sortable: true,
            filter: true,
            filterType: FilterType.MultiselectstatusDropdown,
            valueType: ValueType.Status,
            columnNumber: contactColumnNumber++,
            visibility: true,
            dropdownOption: requestStatusList
        },
        {
            field: 'referenceNumber',
            header: 'Reference No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicationNumber',
            header: 'Application No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentPublicationNumber',
            header: 'Publication No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'filingDate',
            header: 'Filing Deadline',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentTitle',
            header: 'Patent Title',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicants',
            header: 'Patent Applicant(s)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentCategoryName',
            header: 'Patent Category',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'patentServiceTypeName',
            header: 'Patent Service',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'languageCombination',
            header: 'Language Combinations',
            sortable: false,
            filter: true,
            filterType: FilterType.CombinationSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'targetCountries',
            header: 'Target Countries',
            sortable: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: contactColumnNumber++,
            visibility: true,
            dropdownOption: countryList
        },
        {
            field: 'deliveryDate',
            header: 'Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'contact',
            header: 'Contact',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'company',
            header: 'Company',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'projectManager',
            header: 'Project Manager',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'isQuote',
            header: 'Quote Required',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            filterDropDownOptions: YES_NO_LIST_BOOL,
            userRightsForThisColumn: false,
            body: (rowData: any) => (rowData.isQuote ? 'Yes' : 'No')
        },
        {
            field: 'requestType',
            header: 'Request Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'receptionDate',
            header: 'Reception Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'usdgrandTotal',
            header: 'Revenue (USD Grand Total)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'billAmount',
            header: 'Cost (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'margin',
            header: 'Margin (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false,
            body: (rowData: any) =>
                rowData.margin ? `$ ${formatCurrency(rowData.margin as number)}` : '-'
        },
        {
            field: 'marginPercentage',
            header: 'Margin %',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'actualDeliveryDate',
            header: 'Actual Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'salesRepresentative',
            header: 'Sales Representative',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'contactEmail',
            header: 'Contact Email',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'createdBy',
            header: ' Created By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'createdAt',
            header: 'Created At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: ' Deleted At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: contactColumnNumber++,
            visibility: false
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.Action,
            columnNumber: contactColumnNumber++,
            visibility: true,
            body: actionItems
        }
    ];
    let salesRepColumnNumber = 0;
    const salesRepUserSchema: ColumnDefinition[] = [
        {
            field: 'requestNumber',
            header: 'Request No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: requestNumberTemplate,
            columnNumber: salesRepColumnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'requestStatusDisplayName',
            header: 'Request Status',
            sortable: true,
            filter: true,
            filterType: FilterType.MultiselectstatusDropdown,
            valueType: ValueType.Status,
            columnNumber: salesRepColumnNumber++,
            visibility: true,
            dropdownOption: requestStatusList
        },
        {
            field: 'referenceNumber',
            header: 'Reference No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicationNumber',
            header: 'Application No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentPublicationNumber',
            header: 'Publication No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'filingDate',
            header: 'Filing Deadline',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentTitle',
            header: 'Patent Title',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicants',
            header: 'Patent Applicant(s)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentCategoryName',
            header: 'Patent Category',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'patentServiceTypeName',
            header: 'Patent Service',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'languageCombination',
            header: 'Language Combinations',
            sortable: false,
            filter: true,
            filterType: FilterType.CombinationSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'targetCountries',
            header: 'Target Countries',
            sortable: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: salesRepColumnNumber++,
            visibility: true,
            dropdownOption: countryList
        },
        {
            field: 'deliveryDate',
            header: 'Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'contact',
            header: 'Contact',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'company',
            header: 'Company',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'projectManager',
            header: 'Project Manager',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'isQuote',
            header: 'Quote Required',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            filterDropDownOptions: YES_NO_LIST_BOOL,
            userRightsForThisColumn: false,
            body: (rowData: any) => (rowData.isQuote ? 'Yes' : 'No')
        },
        {
            field: 'requestType',
            header: 'Request Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'receptionDate',
            header: 'Reception Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: true
        },
        {
            field: 'projectedRevenue',
            header: 'Projected Revenue (USD)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: true,
            body: (rowData: any) =>
                rowData.projectedRevenue
                    ? `$ ${formatCurrency(rowData.projectedRevenue as number)}`
                    : '-'
        },
        {
            field: 'usdgrandTotal',
            header: 'Revenue (USD Grand Total)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'billAmount',
            header: 'Cost (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'margin',
            header: 'Margin (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false,
            body: (rowData: any) =>
                rowData.margin ? `$ ${formatCurrency(rowData.margin as number)}` : '-'
        },
        {
            field: 'marginPercentage',
            header: 'Margin %',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'actualDeliveryDate',
            header: 'Actual Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'salesRepresentative',
            header: 'Sales Representative',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false,
            userRightsForThisColumn: false
        },
        {
            field: 'contactEmail',
            header: 'Contact Email',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'internalDeliveryDate',
            header: 'Internal Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'createdBy',
            header: ' Created By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'createdAt',
            header: 'Created At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: ' Deleted At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: salesRepColumnNumber++,
            visibility: false
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.Action,
            columnNumber: salesRepColumnNumber++,
            visibility: true,
            body: actionItems
        }
    ];

    let staffColumnNumber = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'requestNumber',
            header: 'Request No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: requestNumberTemplate,
            columnNumber: staffColumnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'requestStatusDisplayName',
            header: 'Request Status',
            sortable: true,
            filter: true,
            filterType: FilterType.MultiselectstatusDropdown,
            valueType: ValueType.Status,
            columnNumber: staffColumnNumber++,
            visibility: true,
            dropdownOption: requestStatusList
        },
        {
            field: 'referenceNumber',
            header: 'Reference No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentTitle',
            header: 'Patent Title',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicants',
            header: 'Patent Applicant(s)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentCategoryName',
            header: 'Patent Category',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentServiceTypeName',
            header: 'Patent Service',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'contact',
            header: 'Contact',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'company',
            header: 'Company',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentApplicationNumber',
            header: 'Application No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'patentPublicationNumber',
            header: 'Publication No.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'languageCombination',
            header: 'Language Combinations',
            sortable: false,
            filter: true,
            filterType: FilterType.CombinationSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'contactEmail',
            header: 'Contact Email',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'targetCountries',
            header: 'Target Countries',
            sortable: false,
            filter: true,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true,
            dropdownOption: countryList
        },
        {
            field: 'filingDate',
            header: 'Filing Deadline',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'projectManager',
            header: 'Project Manager',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'isQuote',
            header: 'Quote Required',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: false,
            filterDropDownOptions: YES_NO_LIST_BOOL,
            userRightsForThisColumn: false,
            body: (rowData: any) => (rowData.isQuote ? 'Yes' : 'No')
        },
        {
            field: 'po',
            header: 'PO',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'deliverto',
            header: 'Also Deliver To',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'mailCC',
            header: 'Other CC',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'deliveryDate',
            header: 'Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'requestType',
            header: 'Request Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'overdue',
            header: 'Overdue',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'receptionDate',
            header: 'Reception Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'projectedRevenue',
            header: 'Projected Revenue (USD)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true,
            body: (rowData: any) =>
                rowData.projectedRevenue
                    ? `$ ${formatCurrency(rowData.projectedRevenue as number)}`
                    : '-'
        },
        {
            field: 'usdgrandTotal',
            header: 'Revenue (USD Grand Total)',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'billAmount',
            header: 'Cost (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'margin',
            header: 'Margin (USD)',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true,
            body: (rowData: any) =>
                rowData.margin ? `$ ${formatCurrency(rowData.margin as number)}` : '-'
        },
        {
            field: 'marginPercentage',
            header: 'Margin %',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'actualDeliveryDate',
            header: 'Actual Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        {
            field: 'salesRepresentative',
            header: 'Sales Representative',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: true
        },
        // {
        //     field: 'orderGrandTotal',
        //     header: 'Order Grand Total',
        //     sortable: true,
        //     filter: true,
        //     filterType: FilterType.Text,
        //     valueType: ValueType.Text,
        //     columnNumber: staffColumnNumber++,
        //     visibility: true
        // },
        {
            field: 'status',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: 'Dropdown',
            valueType: 'StatusDots',
            columnNumber: staffColumnNumber++,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Active',
                    value: 'Active'
                },
                {
                    label: 'Inactive',
                    value: 'Inactive'
                }
            ]
        },
        {
            field: 'internalDeliveryDate',
            header: 'Internal Delivery Date',
            sortable: true,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'createdBy',
            header: 'Created By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'createdAt',
            header: 'Created At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: 'Deleted At',
            frozen: false,
            filter: true,
            isBetweenDateRangeFilter: true,
            filterType: FilterType.DateRangeFilter,
            valueType: ValueType.Date,
            columnNumber: staffColumnNumber++,
            visibility: false
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.Action,
            columnNumber: staffColumnNumber++,
            visibility: true,
            body: actionItems
        }
    ];

    //  code related to create quote and order
    // observe store
    useLayoutEffect(() => {
        const subscriptionQuoteOrderModule = quoteOrderModuleStore.subscribe(setQuoteOrderData);
        quoteOrderModuleStore.init();
        return () => {
            subscriptionQuoteOrderModule.unsubscribe();
        };
    }, []);

    useEffect(() => {
        /* set init values for 'stepper-info' property when user land on this page.
            keep the other 'stepper-data' */
        stepperStore.updateStepper(initialProgressStepperState);
    }, []);

    useEffect(() => {
        // reset the store, when user land on this page.
        stepperStore.resetStepperStore();
        quoteOrderModuleStore.resetQuoteOrderStore();
    }, []);

    // handler
    const createQuoteAndOrder = (mode: number) => {
        // update store - info (selected mode)
        const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
            ...quoteOrderData?.info,
            mode
        };
        quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo);

        navigate(`/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`);
    };

    // Function for handle on change the global filter in quotes and orders page
    const handleOnChange = (propertyName: any, value: any) => {
        if (requestBody !== null) {
            // Create a copy of the searchModels array, or initialize it as an empty array if null
            const updatedSearchModels = [...(requestBody.searchModels || [])];

            // Check if the propertyName already exists in the searchModels array
            const index = updatedSearchModels.findIndex(
                (model) => model.propertyName === propertyName
            );

            // If propertyName exists, update its value, otherwise add a new search model
            if (index !== -1) {
                if (value === '' || value === undefined) {
                    // Remove element at the specified index
                    updatedSearchModels.splice(index, 1);
                } else {
                    // Update value at the specified index
                    updatedSearchModels[index] = { ...updatedSearchModels[index], value };
                }
            } else {
                // Add new object to the array
                updatedSearchModels.push({ propertyName, value });
            }

            // Create a new filterData object with updated searchModels
            const filterData: RequestBody = {
                sorting: requestBody.sorting,
                pageCount: requestBody.pageCount,
                pageNo: requestBody.pageNo,
                searchModels: updatedSearchModels
            };

            setRequestBody(filterData);
        }
    };

    const dropdownProps: DropdownProps = {
        value: internalValue,
        onChange: (e: { value: any }) => handleValueChange('requestTypeId', e.value),
        options: [
            { key: 'All', value: '' },
            { key: 'Orders', value: '2' },
            { key: 'Quotes', value: '1' }
        ],
        optionLabel: 'key',
        optionValue: 'value',
        className: 'w-full h-8',
        pt: {
            root: {
                className:
                    'hover:border-primary font-medium border rounded-lg border-neutral-100 md:w-full w-full h-[2.3rem]'
            },
            item: { className: '' },
            input: {
                className: 'w-9 pl-2.5 md:w-14 md:p-0.5 md:pl-2 flex items-center'
            },
            wrapper: {
                className: 'w-48'
            },
            select: {
                className: 'text-secondary'
            },
            trigger: {
                className: 'hidden md:flex'
            }
        }
    };

    if (isMobile) {
        dropdownProps.valueTemplate = (
            <div className="md:hidden">
                <i className="pi pi-sliders-h" />
            </div>
        );
    }

    // Global filter dropdown component
    const dropdownEditor = () => {
        return <Dropdown data-test-id="edittable-dropdown" {...dropdownProps} />;
    };

    // Function for display global filter in quotes and orders page
    const globalFilter = () => {
        return (
            <div className="flex whitespace-nowrap items-center gap-3">
                <div className="hidden md:inline md:text-neutral-200 md:font-normal">
                    {t('QUOTE_AND_ORDER.FILTER_BY')}
                </div>
                {dropdownEditor()}
            </div>
        );
    };

    const updateApproveQuoteAPI = async () => {
        try {
            const response = await OrdersAndQuotesService.updateApproveQuote(
                toggleRowData?.id as number
            );
            return response;
        } catch (error) {
            console.error(error);
            showToastMessage('Failed to approve the quote', ToastType.ERROR);
        }
    };

    const handleQuoteUpdate = () => {
        (async () => {
            try {
                setShowModal(false);
                const response: QuoteStatusUpdate =
                    await OrdersAndQuotesService.updateWaitingForApprovalQuote(
                        toggleRowData?.id as number,
                        !toggleRowData?.isActive
                    );
                if (response?.success) {
                    showToastMessage(
                        `${response?.message}` ||
                            t('QUOTE_AND_ORDER.QUOTE_STATUS_UPDATE.SUCCESS_MESSAGE'),
                        ToastType.SUCCESS
                    );
                    getOrderAndQuoteTableData(requestBody);
                } else {
                    showToastMessage(
                        `${response?.message}` ||
                            t('QUOTE_AND_ORDER.QUOTE_STATUS_UPDATE.FAILED_MESSAGE'),
                        ToastType.ERROR
                    );
                }
            } catch (error) {
                console.error(error);
                showToastMessage(
                    t('QUOTE_AND_ORDER.QUOTE_STATUS_UPDATE.FAILED_MESSAGE'),
                    ToastType.ERROR
                );
            }
        })();
    };

    const [pdfUrl, setPdfUrl] = useState<string>('');
    const [visible, setVisible] = useState<boolean>(false);
    const showToastMessages = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const downloadPDF = async (
        templateName: string,
        requestId: number,
        patentServiceTypeId: number
    ) => {
        const isUPCOptOut =
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out === patentServiceTypeId;

        try {
            const response = await getPDFData(
                templateName,
                requestId,
                undefined,
                undefined,
                undefined,
                isUPCOptOut
            );
            setPdfUrl(response);
            if (response) {
                setVisible(true);
            }
        } catch (error) {
            showToastMessages({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
                type: ToastType.ERROR
            });
        }
    };

    const downloadPDFData = async (
        pdfPreviewTemplateName: string,
        isUPTemplate: boolean,
        isDownload?: boolean
    ) => {
        try {
            if (isDownload === null) {
                isDownload = false;
            }
            const response = await getPDFData(
                pdfPreviewTemplateName,
                toggleRowData?.id as number,
                isUPTemplate,
                toggleRowData?.id,
                true
            );
            if (isDownload === false) {
                setPdfUrl(response);

                if (response) {
                    setVisible(true);
                }
            } else {
                const link = document.createElement('a');
                link.href = response;

                link.download =
                    toggleRowData?.serviceUniqueName +
                    '' +
                    (toggleRowData?.id + '') +
                    (isUPTemplate ? '-UP' : '-EP') +
                    '.pdf';
                link.click();
            }
        } catch (error) {
            showToastMessage(t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'), ToastType.ERROR);
        }
    };

    const exportToExcel = async (
        templateName: string,
        requestId: number,
        fileName: string,
        rowData: QuoteOrderModel,
        isBothDecideLater?: boolean | null
    ) => {
        const isUPCOptOut =
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out ===
            rowData.patentServiceTypeId;

        try {
            await OrdersAndQuotesService.exportExcel(
                templateName,
                requestId,
                fileName,
                isBothDecideLater,
                isUPCOptOut
            );
        } catch (error) {
            showToastMessages({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_EXPORT_EXCEL'),
                type: ToastType.ERROR
            });
        }
    };

    const handleApproveQuoteAction = () => {
        updateApproveQuoteAPI().then(() => {
            getOrderAndQuoteTableData(requestBody);
        });
    };

    /** #region - popup */
    // trigger
    const triggerPopupActiveInactive = () => {
        setShowModal(true);
        setPopupData({
            ...popupData,
            popupId: 'activeInactiveAction',
            header: t(
                `COMMON.MARK_AS_${toggleRowData?.status === ActiveStatusEnum.ACTIVE.toString() ? 'INACTIVE' : 'ACTIVE'}`
            ),
            description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                status:
                    toggleRowData?.status === ActiveStatusEnum.ACTIVE.toString()
                        ? t('COMMON.INACTIVE')
                        : t('COMMON.ACTIVE'),
                table_name: t('COMMON.QUOTE').toLowerCase()
            })
        });
    };
    const [isUp, setIsUp] = useState<boolean | null>(true);
    const calculateSaveAmount = (rowData: QuoteOrderModel): EPSaveAmountModel => {
        const ep = rowData.epTotal ?? 0;
        const up = rowData.upTotal ?? 0;
        const amount = ep - up;
        const percentage = ((ep - up) / ep) * 100;
        return { amount, percentage };
    };
    const renderSaveAmountWithPercentageTemplate = (rowData: QuoteOrderModel) => {
        const data = calculateSaveAmount(rowData);
        return (
            // Client requested to hide the save amount, So adding hidden class temporarily
            <span className="hidden">
                <span
                    data-testid="grossProfitDetails"
                    className="inline-flex flex-row ml-2 text-[13px] py-[4px] px-[4px] rounded-md font-medium items-center  bg-warning">
                    <i className={data.percentage > 0 ? 'pi pi-caret-down' : 'pi pi-caret-up'} />

                    <span className="flex flex-row mx-1">
                        {data.amount.toFixed(2)} ({data.percentage.toFixed(2)})%
                    </span>
                </span>
            </span>
        );
    };
    const handleDescriptionTemplate = (hasFessZero: boolean, rowData: QuoteOrderModel) => {
        const upTotal = (rowData.upTotal ?? 0) + (rowData.claimsTotal ?? 0);
        const epTotal = (rowData.epTotal ?? 0) + (rowData.claimsTotal ?? 0);
        return (
            <div className="flex flex-col gap-2">
                <div className="text-black">
                    <div>
                        {t('QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE1')}
                        <div className="font-medium text-black">
                            {t('QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE2')}
                        </div>
                    </div>

                    <p className="mt-1 text-black">
                        {t('QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE3')}
                    </p>
                </div>
                <div className="border-t mt-2">
                    <div className="flex gap-2 mt-2 justify-center">
                        <div className="flex flex-col gap-1.5">
                            <label className="flex items-center gap-1.5 cursor-pointer leading-7">
                                <input
                                    type="radio"
                                    name="isUpRadioButton"
                                    value="true"
                                    defaultChecked
                                    onChange={() => {
                                        setIsUp(true);
                                    }}
                                />
                                {t('SUMMARY.UP_NATIONAL_VALIDATIONS')}
                                {rowData.claimsTotal != null && rowData.claimsTotal > 0
                                    ? ` + ${t('SUMMARY.CLAIMS')}`
                                    : ''}
                            </label>
                            <label className="flex items-center gap-1.5 cursor-pointer leading-7">
                                <input
                                    type="radio"
                                    name="isUpRadioButton"
                                    value="false"
                                    onChange={() => {
                                        setIsUp(false);
                                    }}
                                />

                                {t('SUMMARY.NATIONAL_VALIDATION_ONLY')}
                                {rowData.claimsTotal != null && rowData.claimsTotal > 0
                                    ? ` + ${t('SUMMARY.CLAIMS')}`
                                    : ''}
                            </label>
                        </div>
                        <div className="flex flex-col justify-start items-start [&>h4]:text-base [&>h4]:font-medium  gap-3">
                            <h4>
                                {rowData.currencySymbol ?? ''} {formatCurrency(upTotal)}
                                {isThisStaffUser && renderSaveAmountWithPercentageTemplate(rowData)}
                            </h4>

                            <h4>
                                {rowData.currencySymbol} {formatCurrency(epTotal)}
                            </h4>
                        </div>
                    </div>
                </div>
                {hasFessZero && (
                    <div className="flex justify-center">
                        <p className="bg-warning/40 border text-sm border-warning-200 w-fit p-1 rounded-md flex items-center gap-2">
                            <i className="pi pi-info-circle text-sm text-warning-200"></i>{' '}
                            {t('QUOTE_AND_ORDER.WARNING.COUNTY_HAS_ZERO_VALUES')}
                        </p>
                    </div>
                )}
            </div>
        );
    };
    const triggerPopupApproveQuoteWithZeroFees = async (rowData: QuoteOrderModel | null) => {
        try {
            if (!rowData?.id) throw Error('Quote ID not found');
            const isSTDFlow = rowData.patentCategoryId === SERVICE_TYPE_ID.other_translations;

            // api
            const checkCountryFeesHaveZeroFees: { hasZeroValues: boolean } | null =
                await viewOrderQuoteServices.checkFeesHasZeroValues(rowData.id);
            if (checkCountryFeesHaveZeroFees?.hasZeroValues) {
                const popupDesc = isSTDFlow
                    ? t('COMMON.CONFIRMATION_APPROVE_WITH_ZERO_FEES_NON_IP', {
                          statusLabelName: rowData?.requestStatusDisplayName
                      })
                    : rowData.isBothDecideLater !== true
                      ? t('COMMON.CONFIRMATION_APPROVE_WITH_ZERO_FEES_IP')
                      : handleDescriptionTemplate(
                            checkCountryFeesHaveZeroFees?.hasZeroValues,
                            rowData
                        );

                setShowModal(true);
                setPopupData({
                    ...popupData,
                    popupId:
                        rowData.isBothDecideLater === true
                            ? 'IsBothDecideLaterAction'
                            : 'approveQuoteWithZeroFees',
                    header: t('COMMON.CONFIRMATION'),

                    description: popupDesc,
                    customWidth:
                        rowData.isBothDecideLater === true ? ' lg:!w-[30%] lg:!min-w-max' : '',
                    acceptLabel:
                        rowData.isBothDecideLater === true ? t('COMMON.CONFIRM') : t('COMMON.YES'),
                    rejectLabel:
                        rowData.isBothDecideLater === true ? t('COMMON.CANCEL') : t('COMMON.NO')
                });
            } else {
                if (rowData.isBothDecideLater === true) {
                    setShowModal(true);
                    setPopupData({
                        ...popupData,
                        popupId: 'IsBothDecideLaterAction',
                        header: t('COMMON.CONFIRMATION'),
                        description: handleDescriptionTemplate(false, rowData),
                        customWidth: ' lg:!w-[30%] lg:!min-w-max',
                        acceptLabel:
                            rowData.isBothDecideLater === true
                                ? t('COMMON.CONFIRM')
                                : t('COMMON.YES'),
                        rejectLabel:
                            rowData.isBothDecideLater === true ? t('COMMON.CANCEL') : t('COMMON.NO')
                    });
                } else {
                    // actual approve quote action
                    handleApproveQuoteAction();
                }
            }
        } catch (error) {
            console.error('Error in triggerPopupApproveQuoteWithZeroFees(): ', error);
        }
    };
    const approveEPQuote = async () => {
        try {
            const response = await OrdersAndQuotesService.updateApproveQuote(
                toggleRowData?.id as number,
                isUp
            );
            if (response) {
                showToastMessages({
                    message: t('QUOTE_AND_ORDER.ORDER_STATUS_UPDATES'),
                    type: ToastType.SUCCESS
                });
            }
        } catch (error) {
            console.error(error);
            const errorMessage =
                ((error as any).response?.data?.Message as string) ??
                'Failed to update order status';
            showToastMessages({ message: errorMessage, type: ToastType.ERROR });
        }
    };
    // handles
    const popupOnConfirm = () => {
        if (popupData.popupId === 'activeInactiveAction') {
            handleQuoteUpdate();
        } else if (popupData.popupId === 'approveQuoteWithZeroFees') {
            // actual approve quote action
            handleApproveQuoteAction();
        } else if (popupData.popupId === 'IsBothDecideLaterAction') {
            approveEPQuote().then(() => {
                getOrderAndQuoteTableData(requestBody);
            });
        }
    };
    const popupOnCancel = () => {
        setShowModal(false);
    };
    /** #endregion */

    const menuItems: MenuItem[] = [
        {
            items: [
                ...(toggleRowData?.requestType === 'IP'
                    ? [
                          {
                              id: '3',
                              label: t('QUOTE_AND_ORDER.EDIT_QUOTE'),
                              icon: () => (
                                  <img
                                      src="/images/svgs/i-edit-blue-icon.svg"
                                      alt="edit"
                                      className="h-4 w-4"
                                  />
                              ),
                              command() {
                                  editQuote(toggleRowData ?? null);
                              }
                          }
                      ]
                    : []),

                {
                    id: '4',
                    label: t('QUOTE_AND_ORDER.APPROVE_QUOTE'),
                    icon: () => (
                        <img
                            src="/images/svgs/i-approve-blue-icon.svg"
                            alt="approve"
                            className="h-4 w-4"
                        />
                    ),
                    command() {
                        triggerPopupApproveQuoteWithZeroFees(toggleRowData ?? null);
                    }
                },
                {
                    id: '5',
                    label: t(
                        `COMMON.MARK_AS_${toggleRowData?.status === ActiveStatusEnum.ACTIVE.toString() ? 'INACTIVE' : 'ACTIVE'}`
                    ),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        triggerPopupActiveInactive();
                    }
                },
                toggleRowData?.isBothDecideLater === true
                    ? {
                          id: '6',
                          label: t('COMMON.PREVIEW'),
                          icon: () => (
                              <img
                                  src="/images/svgs/i-viewEye-icon.svg"
                                  alt="preview"
                                  className="h-4 w-4"
                              />
                          ),
                          items: [
                              {
                                  label: t('SUMMARY.UP_NATIONAL_VALIDATIONS'),
                                  command() {
                                      downloadPDFData(
                                          'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                          true,
                                          false
                                      );
                                  }
                              },
                              {
                                  label: t('SUMMARY.NATIONAL_VALIDATION_ONLY'),
                                  command() {
                                      downloadPDFData(
                                          'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                          false,
                                          false
                                      );
                                  }
                              }
                          ]
                      }
                    : {
                          id: '6',
                          label: t('COMMON.PREVIEW'),
                          icon: () => (
                              <img
                                  src="/images/svgs/i-viewEye-icon.svg"
                                  alt="preview"
                                  className="h-4 w-4"
                              />
                          ),
                          command() {
                              downloadPDF(
                                  toggleRowData?.serviceUniqueName || ('' as string),
                                  toggleRowData?.id || (0 as number),
                                  toggleRowData?.patentServiceTypeId as number
                              );
                          }
                      },
                {
                    id: '7',
                    label: t('QUOTE_AND_ORDER.EXPORT_QUOTE_TO_EXCEL'),
                    icon: () => (
                        <img
                            src="/images/svgs/i-excel-blue-icon.svg"
                            alt="export"
                            className="h-4 w-4"
                        />
                    ),
                    command() {
                        exportToExcel(
                            toggleRowData?.serviceUniqueName || ('' as string),
                            toggleRowData?.id as unknown as number,
                            (toggleRowData?.requestTypeId === MODE.CREATE_QUOTE
                                ? t('COMMON.QUOTE') + ' - '
                                : t('COMMON.ORDER') + ' - ') + toggleRowData?.requestNumber ||
                                ('' as string),
                            toggleRowData as QuoteOrderModel,
                            toggleRowData?.isBothDecideLater
                        );
                    }
                }
            ]
        }
    ];

    const createOrderQuoteDropDown = () => {
        const isShowModeDropdown =
            AuthStore.hasPermission(Permissions.CREATE_QUOTE) ||
            AuthStore.hasPermission(Permissions.CREATE_ORDER);
        return (
            isShowModeDropdown && (
                <div tabIndex={0} role="button" className="group dropdown dropdown-end">
                    <div
                        tabIndex={0}
                        role="button"
                        data-testid="create-dropdown"
                        className="btn px-2.5 btn-primary text-white min-h-9 h-9 text-lg font-light flex items-center">
                        <span className="h-full flex items-center">
                            <i className="pi pi-plus-circle text-base pt-0.5"></i>
                        </span>
                        {t('COMMON.CREATE')}
                        <span className="border-s border-s-white h-full flex items-center justify-center">
                            <i className="pi pi-chevron-down text-sm pt-0.5 ml-2.5"></i>
                        </span>
                    </div>
                    <ul
                        tabIndex={0}
                        className="dropdown-content z-[99] menu py-3 px-0 shadow-xl bg-base-100 rounded-lg w-52 font-medium text-black">
                        {AuthStore.hasPermission(Permissions.CREATE_ORDER) && (
                            <li
                                className="cursor-pointer hover:bg-primary-50"
                                onClick={() => createQuoteAndOrder(MODE?.CREATE_ORDER)}
                                onKeyDown={() => createQuoteAndOrder(MODE?.CREATE_ORDER)}
                                data-testid="create-order">
                                <div className="flex">
                                    <img src={createOrderIcon} className="h-4 p-0" />
                                    <a className="p-0">
                                        {t('COMMON.CREATE')} {t('COMMON.ORDER')}
                                    </a>
                                </div>
                            </li>
                        )}
                        {AuthStore.hasPermission(Permissions.CREATE_QUOTE) && (
                            <li
                                className="cursor-pointer hover:bg-primary-50"
                                onClick={() => createQuoteAndOrder(MODE?.CREATE_QUOTE)}
                                onKeyDown={() => createQuoteAndOrder(MODE?.CREATE_QUOTE)}
                                data-testid="create-quote">
                                <div className="flex">
                                    <img src={createQuoteIcon} className="h-4 p-0" />
                                    <a className="p-0">
                                        {t('COMMON.CREATE')} {t('COMMON.QUOTE')}
                                    </a>
                                </div>
                            </li>
                        )}
                    </ul>
                </div>
            )
        );
    };

    const customizedColumnsSchema = () => {
        const customizedSchema = isThisSalesRepUser
            ? salesRepUserSchema
            : isThisContactUser
              ? contactUserSchema
              : columnSchema;
        columnSchema.forEach((column) => {
            if (column.field === 'languageCombination') {
                column.combinationSearch = {
                    field: ['sourceLanguage', 'targetLanguage'],
                    options: languageList
                };
            }
        });

        const salesRepColumns = [
            'usdgrandTotal',
            'billAmount',
            'actualDeliveryDate',
            'salesRepresentative',
            'margin',
            'marginPercentage'
        ];
        const isShowQuoteRequiredColumn =
            !isThisHRUser && !isThisV3User && !isThisContactUserExcludedSales;

        customizedSchema.forEach((column) => {
            if (isShowQuoteRequiredColumn && column.field === 'isQuote') {
                column.visibility = true;
                column.userRightsForThisColumn = true;
            }
            if (isThisSalesRepUser && salesRepColumns.includes(column.field)) {
                column.visibility = true;
                column.userRightsForThisColumn = true;
            }
        });

        return customizedSchema;
    };
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.QUOTE_AND_ORDER,
        filters: {},
        reOrderableColumns: true,
        title: t('MENU.ORDERS_QUOTES'),
        emptyMessage: eMessage,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.QUOTE_ORDER_LIST,
        columns: customizedColumnsSchema(),
        buttonChildren: createOrderQuoteDropDown(),
        globalFilter: globalFilter(),
        items: menuItems,
        hideTableExport: AuthStore.hasPermission(Permissions.EXPORT_QUOTE)
    };
    const onRowClicked = (e: DataTableSelectEvent) => {
        /** check permission */
        const hasPermission =
            AuthStore.hasPermission(Permissions.VIEW_QUOTE) ||
            AuthStore.hasPermission(Permissions.VIEW_ORDER);

        if (!isDetailAccess && hasPermission) {
            if (e.data.patentCategoryId === SERVICE_TYPE_CATEGORY.STANDARD) {
                const redirectTo = `/${PATHS.ORDER_QUOTE}/${PATHS.STANDARD}/${PATHS.DETAILS}/${e.data?.id}`;
                navigate(redirectTo, {
                    state: {
                        id: e.data?.id,
                        requestNumber: e.data?.requestNumber,
                        statusName: e.data?.requestStatusDisplayName
                    }
                });
            } else if (
                e.data.patentServiceTypeId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['upc_opt_out']
            ) {
                navigate(
                    `/${PATHS.ORDER_QUOTE}/${PATHS.DETAILS}/${PATHS.UPC_OPT_OUT}/${e.data.id}`,
                    {
                        state: {
                            id: e.data.id,
                            requestNumber: e.data.requestNumber,
                            statusName: e.data.requestStatusDisplayName
                        }
                    }
                );
            } else {
                navigate(`/${PATHS.ORDER_QUOTE}/${PATHS.DETAILS}/${e.data.id}`, {
                    state: {
                        id: e.data.id,
                        requestNumber: e.data.requestNumber,
                        statusName: e.data.requestStatusDisplayName
                    }
                });
            }
        }
    };

    return (
        <div data-testid="TableComponent" className="p-3 md:p-4 md:pb-0 md:mx-2">
            <Dialog
                pt={previewDialogPopup}
                header={
                    <div className="w-full flex justify-between items-center">
                        {(toggleRowData?.requestTypeId === 1
                            ? t('COMMON.QUOTE') + ' - '
                            : t('COMMON.ORDER') + ' - ') +
                            (toggleRowData?.requestNumber ?? 'Preview')}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(
                                    pdfUrl,
                                    (toggleRowData?.requestTypeId === MODE.CREATE_QUOTE
                                        ? t('COMMON.QUOTE') + ' - '
                                        : t('COMMON.ORDER') + ' - ') +
                                        (toggleRowData?.requestNumber ?? 'Preview')
                                )
                            }
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="download-pdf"
                        />
                    </div>
                }
                visible={visible}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            {showModal && (
                <ConfirmationPopup
                    popupID={'QuoteConfirmationPopup'}
                    visible={showModal}
                    headerText={popupData.header}
                    description={popupData.description}
                    acceptLabel={popupData.acceptLabel ?? t('COMMON.YES')}
                    rejectLabel={popupData.rejectLabel ?? t('COMMON.NO')}
                    onConfirm={() => popupOnConfirm()}
                    onCancel={() => popupOnCancel()}
                    customWidth={popupData.customWidth}
                />
            )}
            <DataTableComponent
                tableData={quoteOrderTableData ?? []}
                tableRequestBodyData={requestBody}
                tableDefinition={tableDefinition}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                exportData={exportData}
                onRowClicked={onRowClicked}
            />
        </div>
    );
}
export default OrdersAndQuotesPage;
