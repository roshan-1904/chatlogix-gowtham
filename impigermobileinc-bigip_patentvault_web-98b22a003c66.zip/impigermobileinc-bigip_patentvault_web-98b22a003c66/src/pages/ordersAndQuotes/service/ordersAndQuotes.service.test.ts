import HttpService from 'core/interceptor/api.handler';
import OrdersAndQuotesService from './ordersAndQuotes.service';

jest.mock('core/interceptor/api.handler');

describe('OrdersAndQuotesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getCountryList', () => {
        it('should fetch getCountryList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await OrdersAndQuotesService.getCountryList();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(OrdersAndQuotesService.getCountryList()).rejects.toThrow(mockError);
        });
    });

    describe('getLanguageList', () => {
        it('should fetch getLanguageList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await OrdersAndQuotesService.getLanguageList();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(OrdersAndQuotesService.getLanguageList()).rejects.toThrow(mockError);
        });
    });

    describe('getRequestStatusList', () => {
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await OrdersAndQuotesService.getRequestStatusList();
            expect(result).toEqual([]);
        });
    });

    describe('updateApproveQuote', () => {
        const orderRequestId = 1;
        it('should fetch getLanguageList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue([]);
            const result = await OrdersAndQuotesService.updateApproveQuote(orderRequestId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValueOnce(mockError);
            await expect(OrdersAndQuotesService.updateApproveQuote(orderRequestId)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('updateWaitingForApprovalQuote', () => {
        const orderRequestId = 1;
        const isActive = false;
        it('should fetch getLanguageList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await OrdersAndQuotesService.updateWaitingForApprovalQuote(
                orderRequestId,
                isActive
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                OrdersAndQuotesService.updateWaitingForApprovalQuote(orderRequestId, isActive)
            ).rejects.toThrow(mockError);
        });
    });
});
