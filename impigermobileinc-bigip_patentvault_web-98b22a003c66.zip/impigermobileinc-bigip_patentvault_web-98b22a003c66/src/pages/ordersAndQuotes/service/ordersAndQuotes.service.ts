import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import utils from 'core/utils/utils';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import axios from 'axios';
import AuthStore from 'core/store/authStore/authStore';

// Define the base URL from environment variable
const pvBaseURL = process.env.REACT_APP_API_BASE_URL;
const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
const _httpService = new HttpService();

/**
 * Fetch dynamic form information based on the given page type.
 * @param {RequestBody} requestBody - body for api calling
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getOrderAndQuoteList = async <QuoteOrderResponseModel>(
    requestBody: RequestBody
): Promise<QuoteOrderResponseModel> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_ORDER_AND_QUOTE_LIST}`;
    try {
        const response = await _httpService.post<QuoteOrderResponseModel, RequestBody>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getCountryList = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_COUNTRIES}`;

    try {
        const response = await _httpService.get<T>(apiUrl, { data: { hideLoader: true } });
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getLanguageList = async <T>(): Promise<T> => {
    const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_LANGUAGE}`;
    try {
        const response = await _httpService.get<T>(apiUrl, { data: { hideLoader: true } });
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getRequestStatusList = async <T>(): Promise<T> => {
    const apiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_REQUEST_STATUS}/1,2`;
    try {
        const response = await _httpService.get<T>(apiUrl, { data: { hideLoader: true } });
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Sends a PATCH request to update the status of a Order/Quote.
 * @param orderRequestId - The ID of the  Order/Quote to update.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
export const updateApproveQuote = async <T>(
    orderRequestId: number,
    isUp?: boolean | null
): Promise<T> => {
    let apiUrl = `${quoteBaseURL}/order${END_POINT.ORDERS_AND_QUOTES_END_POINT.QUOTE_APPROVAL}/${orderRequestId}`;
    try {
        if (isUp != null) {
            apiUrl = apiUrl + '?isUp=' + isUp;
        }
        const response = await _httpService.patch<T, null>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

/**
 * Sends a POST request to update the status of a Waiting for Approval quote.
 * @param quoteId - The ID of the Quote to update.
 * @returns {Promise<T>} A promise resolving to the status update.
 */
const updateWaitingForApprovalQuote = async <T>(
    orderRequestId: number,
    isActive = false
): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.ACTIVE_INACTIVE_QUOTE}/${orderRequestId}?isActive=${isActive}`;
    try {
        const response = await _httpService.post<T, null>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

const exportExcel = async (
    templateName: string,
    referenceNo: number,
    fileName: string,
    isBothDecideLater?: boolean | null,
    isUPCOptOut?: boolean | null
) => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.EXPORT_EXCEL}?templateName=${templateName}&isPreview=false`;
    const upcOptOutApiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.QUOTE_ORDER_UPC_EXCEL_DOWNLOAD}${referenceNo}`;
    const token = AuthStore.getUserInfo().authToken || '';

    try {
        const response = await axios.post(
            isUPCOptOut ? upcOptOutApiUrl : apiUrl,
            isUPCOptOut ? undefined : { referenceNo, isBothDecideLater },
            {
                responseType: 'arraybuffer',
                headers: {
                    Authorization: `Bearer ${token}`
                    // 'Content-Type': 'application/json'
                }
            }
        );
        // const response = await axios.post(apiUrl, { referenceNo }, { responseType: 'arraybuffer' });

        // Check if the response is an array buffer
        if (response.data instanceof ArrayBuffer) {
            // Create a Blob from the binary data
            const blob = new Blob([response.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });

            utils.downloadBlob(blob, `${fileName}`);
        } else {
            throw new Error('Response is not an array buffer');
        }
    } catch (error) {
        console.error('Error exporting Excel:', error);
        throw error;
    }
};

// Export an object containing all the services
const OrdersAndQuotesService = {
    getCountryList,
    getLanguageList,
    getRequestStatusList,
    getOrderAndQuoteList,
    updateApproveQuote,
    updateWaitingForApprovalQuote,
    exportExcel
};

export default OrdersAndQuotesService;
