// import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import BackButton from './backButton';
import { useNavigate } from 'react-router-dom';
// import { useTranslation } from 'react-i18next';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
// import NotificationStore from 'core/store/notificationStore/notificationStore';
// import NotificationStore from 'core/store/notificationStore/notificationStore';

jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn(() => jest.fn())
}));

// jest.mock('react-i18next', () => ({
//     useTranslation: () => ({
//         t: (key) => key, // simple mock translation function
//     }),
// }));

jest.mock('core/store/stepperStore/progressStepper.store', () => ({
    subscribe: jest.fn(),
    init: jest.fn(),
    updateStepper: jest.fn(),
    initialState: {
        stepperInfo: {
            currStep: null,
            completedStepsIds: []
        },
        stepperList: []
    }
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(() => ({ mockReturnValue: jest.fn() }))
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

describe('BackButton', () => {
    const navigate = useNavigate();

    beforeEach(() => {
        jest.clearAllMocks();
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                isEditFlow: false
            },
            flags: {
                isSummaryPageTablesInlineEditInProgress: false
            }
        });
    });

    test('should render BackButton and call navigate with the correct path', () => {
        const { getByText } = render(<BackButton isServicePage={false} />);

        const backButton = getByText('COMMON.BACK');
        fireEvent.click(backButton);

        waitFor(() => {
            expect(navigate).toHaveBeenCalled();
        });
    });

    test('should show a confirmation popup when on the summary page', () => {
        stepperStore.initialState.stepperInfo.currStep = {
            stepperId: 0,
            stepperName: 'Step 0',
            stepperDesc: 'Description of Step 0'
        };
        const { getByText, queryByText } = render(<BackButton isServicePage={false} />);

        const backButton = getByText('COMMON.BACK');
        fireEvent.click(backButton);

        const popupHeader = queryByText('COMMON.SUMMARY_BACK_BUTTON_HEADER');
        waitFor(() => {
            expect(popupHeader).toBeInTheDocument();
        });
        // expect(popupHeader).toBeInTheDocument();
    });

    // test('should show a warning toast when summary page table edit is in progress', () => {
    //     quoteOrderModuleStore.getData.mockReturnValue({
    //         info: {
    //             isEditFlow: false
    //         },
    //         flags: {
    //             isSummaryPageTablesInlineEditInProgress: true
    //         }
    //     });

    //     const { getByText } = render(<BackButton isServicePage={false} />);

    //     const backButton = getByText('COMMON.BACK');
    //     fireEvent.click(backButton);

    //     expect(NotificationStore.showAlert).toHaveBeenCalledWith({
    //         message: 'QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS',
    //         type: 'WARNING'
    //     });
    // });

    test('should handle navigation correctly on non-summary pages', () => {
        stepperStore.initialState.stepperInfo = {
            currStep: { stepperId: 2, stepperName: 'Step 2', stepperDesc: 'Description of Step 2' },
            completedStepsIds: [1]
        };
        stepperStore.initialState.stepperList = [
            { stepperId: 1, stepperName: 'Step 1', stepperDesc: 'Description of Step 1' },
            { stepperId: 2, stepperName: 'Step 2', stepperDesc: 'Description of Step 2' }
        ];

        const { getByText } = render(<BackButton isServicePage={false} />);

        const backButton = getByText('COMMON.BACK');
        fireEvent.click(backButton);

        waitFor(() => {
            expect(stepperStore.updateStepper).toHaveBeenCalledWith({
                stepperInfo: {
                    currStep: { stepperId: 1, stepperName: 'Step 1' },
                    completedStepsIds: []
                }
            });
            expect(navigate).toHaveBeenCalledWith('/order-quote/create/step1-path'); // adjust this path accordingly
        });
    });
});
