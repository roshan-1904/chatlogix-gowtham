import { useLayoutEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
    PATHS_FOR_STEPPER,
    STEPPER_DATA,
    STEPPER_TYPE_ID
} from 'constants/progressStepper.constant';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from '../progressStepper/types/progressStepper.type';
import { PATHS } from 'constants/routes.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { isContactUser } from 'core/utils/utils';

const BackButton = ({ isServicePage }: any) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [stepper, setStepper] = useState<STEPPER_STATE>(stepperStore.initialState);
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        description: '',
        acceptLabel: '',
        rejectLabel: t('COMMON.CANCEL')
    });
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);

    // functions
    const redirectToPreviousPage = () => {
        try {
            if (!stepper?.stepperInfo?.currStep || !stepper?.stepperList) return;

            let pageRedirection: number = 1; // default value
            let updatedCurrStepId: number;
            let updatedCurrStep: STEPPER_DATA_TYPE;

            /** for previous page - remove the last item from the 'completedStepsIds'.
             and, set that removed item as 'currStepId' */
            const completedPages: number[] = stepper?.stepperInfo?.completedStepsIds;
            const currPage: STEPPER_DATA_TYPE = stepper?.stepperInfo?.currStep;

            if (completedPages && completedPages.length > 0) {
                updatedCurrStepId = completedPages[completedPages?.length - 1];
                updatedCurrStep = stepper.stepperList.find(
                    (step) => step.stepperId === updatedCurrStepId
                ) as STEPPER_DATA_TYPE;

                const updatedCompletedStepsIds: number[] = completedPages?.slice(0, -1);

                // update store with new data for upcoming page
                const updatedStepperInfo: STEPPER_INFO = {
                    currStep: updatedCurrStep,
                    completedStepsIds: updatedCompletedStepsIds
                };
                if (updatedStepperInfo) {
                    stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
                }

                pageRedirection = updatedCurrStep?.stepperId;
            } else if (currPage) {
                /** if completedPages[] empty means, the current page is '1'(next page of service-page). 
                     so re-direct to '0'(service-page) without any 'state' changes  */
                // the page order is not static, so here used number('1') instead of constant.
                // TODO: yet to do..
                // pageRedirection = currPage.stepperId === 1 ? STEPPER_TYPE_ID.SELECT_SERVICE : currPage.stepperId;

                // use this for local stepper setup for now. uncomment prev line once api deployed.
                pageRedirection = STEPPER_TYPE_ID.SELECT_SERVICE;
            }

            /* when a user clicks the 'back' button on the 'service-type' page, 
                they will return to the 'orders-quotes' list page. */
            const isEditFlow = quoteOrderModuleStore.getData().info.isEditFlow;
            const flowType = isEditFlow ? PATHS.EDIT : PATHS.CREATE;

            const redirectTo = !isServicePage
                ? `/${PATHS.ORDER_QUOTE}/${flowType}/${PATHS_FOR_STEPPER[pageRedirection]}`
                : `/${PATHS.ORDER_QUOTE}`;

            // redirect to the previous page
            navigate(redirectTo);
        } catch (error) {
            console.error('Error on redirectToPreviousPage:', error);
        }
    };

    // handlers
    const onClickBackButton = () => {
        const quoteOrderData = quoteOrderModuleStore.getData();

        /** ignore further actions if summary tables inline edit is in-progress. */
        if (quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        if (
            stepper?.stepperInfo?.currStep?.stepperId === STEPPER_DATA.SUMMARY?.stepperId &&
            !isThisContactUser
        ) {
            handleConfirmPopup();
        } else {
            redirectToPreviousPage();
        }
    };

    // popup
    const handleConfirmPopup = () => {
        // handle confirmation popup
        setShowPopup({
            ...showPopup,
            visible: true,
            header: t('COMMON.SUMMARY_BACK_BUTTON_HEADER'),
            description: t('COMMON.SUMMARY_BACK_BUTTON_DESCRIPTION'),
            acceptLabel: t('COMMON.CONFIRM')
        });
    };
    const handleConfirm = () => {
        // handle the confirm button
        redirectToPreviousPage();
        setShowPopup({ ...showPopup, visible: false });
    };

    // helpers
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    useLayoutEffect(() => {
        const subscription = stepperStore.subscribe(setStepper);
        stepperStore.init();
        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    return (
        <>
            {showPopup.visible && (
                <ConfirmationPopup
                    popupID="orderOrQuotePopup"
                    image={ConfirmationRedImage}
                    className={'orderOrQuotePopup'}
                    onConfirm={() => {
                        handleConfirm();
                    }}
                    onCancel={() => {
                        setShowPopup({ ...showPopup, visible: false });
                    }}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={showPopup.acceptLabel}
                    rejectLabel={showPopup.rejectLabel}
                />
            )}
            <button
                onClick={() => onClickBackButton()}
                onKeyDown={(event) => {
                    if (event.key === 'Enter') {
                        onClickBackButton();
                    }
                }}
                data-testid="back-button"
                className="btn font-medium rounded-md min-h-10 h-10 button-neutral px-2 md:px-4">
                <i className="pi pi-chevron-left"></i>
                <span className="font-medium hidden md:block">{t('COMMON.BACK')}</span>
            </button>
        </>
    );
};

export default BackButton;
