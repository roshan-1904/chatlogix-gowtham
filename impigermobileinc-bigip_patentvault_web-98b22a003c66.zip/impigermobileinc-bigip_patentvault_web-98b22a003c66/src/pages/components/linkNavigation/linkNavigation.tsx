import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';
import { t } from 'i18next';

const LinkNavigation = ({ text, url }: { text: string; url: string }) => {
    return (
        <div className="group" data-testid="dataTable-link-format">
            {text ? (
                <a
                    href={url ?? ''}
                    className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer font-medium">
                    {text}
                </a>
            ) : (
                '-'
            )}
            <button
                className="invisible group-hover:visible"
                onClick={() => {
                    navigator.clipboard.writeText(text);
                    NotificationStore.showAlert({
                        type: ToastType.SUCCESS,
                        message: t('COMMON.COPY_SUCCESS')
                    });
                }}>
                <i
                    title={t('COMMON.COPY_TO_CLIPBOARD')}
                    className="pi pi-copy text-black/50 hover:text-black/70 ml-2 cursor-pointer "
                />
            </button>
        </div>
    );
};
export default LinkNavigation;
