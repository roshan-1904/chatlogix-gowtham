import { AllowedQuoteOrderStoreValue } from 'core/store/orderQuoteStore/orderQuote.store';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';

export type STEPPER_DATA_TYPE = {
    id?: number;
    stepperId: number;
    stepperName: string | ((params?: any) => string);
    stepperDesc: string | ((params?: any) => string);
    stepperPath?: string;
};

export type STEPPER_INFO = {
    currStep: STEPPER_DATA_TYPE | null;
    completedStepsIds: number[];
};

export type STEPPER_STATE = {
    stepperInfo: STEPPER_INFO;
    stepperList: STEPPER_DATA_TYPE[] | null;
};

export type StepperInfoForMobileView = {
    currStepId: number;
    currStepName: string | null;
    nextStepName: string | null;
    totalStepsLength: number;
};
export type Subscription = {
    unsubscribe: () => void;
};
type StepperModuleStoreDataKeys<T> = keyof StepperModuleStoreData<T>;
export interface StepperStoreState<T> {
    init: () => void;
    subscribe: (setState: (value: any) => void) => Subscription;
    updatePage: (field: StepperModuleStoreDataKeys<T>, value: any) => void;
    getData: () => StepperModuleStoreData<T>;
    resetStepperModuleStore: () => void;
    initialState: StepperModuleStoreData<T>;
}
export interface BooleanObject {
    [key: string]: boolean | null;
}
export interface stepperInfo {
    [key: string]: null;
}

export interface StepperModuleStoreInfo {
    userType: number | null;
    primaryId: number | null;
    documentId: number | null;
    name?: string | null;
}
export interface StepperModuleStoreData<T> {
    stepperInfo?: StepperModuleStoreInfo;
    isFormValid: BooleanObject;
    formData: T;
}

export interface StepperQuoteStoreState {
    init: () => void;
    subscribe: (setState: (value: any) => void) => Subscription;
    updatePage: (field: AllowedQuoteOrderStoreValue, value: any) => void;
    getData: () => QuoteOrderModuleStore;
    resetQuoteOrderStore: () => void;
    initialState: QuoteOrderModuleStore;
}
