import { MODE, ROLE } from 'constants/app.constant';
import { STEPPER_DATA, SERVICE_TYPE_ID, CATEGORY_TYPE_ID } from 'constants/index';

export const STEPPER_DATA_LOCAL = {
    [MODE.CREATE_ORDER]: {
        // staff users
        [ROLE.ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_USER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },

        // vendor users
        [ROLE.VENDOR_ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_COORDINATOR.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        }
    },
    [MODE.CREATE_QUOTE]: {
        // staff users
        [ROLE.ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_USER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },

        // vendor users
        [ROLE.VENDOR_ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_COORDINATOR.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        }
    },
    [MODE.EDIT_ORDER]: {
        // staff users
        [ROLE.ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_USER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },

        // vendor users
        [ROLE.VENDOR_ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_COORDINATOR.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        }
    },
    [MODE.EDIT_QUOTE]: {
        // staff users
        [ROLE.ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.CONTACT_USER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },

        // vendor users
        [ROLE.VENDOR_ADMIN.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_MANAGER.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_PROJECT_COORDINATOR.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        },
        [ROLE.VENDOR_SALES_REP.roleId]: {
            [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.annuities}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ]
            },
            [SERVICE_TYPE_ID.european_patent]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['71_3_claims']}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.translation_only}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation']}`]:
                    [
                        STEPPER_DATA.PATENT_AUTHENTICATION,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.Renewals}`]: [
                    STEPPER_DATA.PATENT_AUTHENTICATION,
                    STEPPER_DATA.ADDITIONAL_INFORMATION,
                    STEPPER_DATA.PATENT_DETAILS,
                    STEPPER_DATA.DOCUMENT_UPLOAD,
                    STEPPER_DATA.SELECT_COUNTRY,
                    STEPPER_DATA.SUMMARY
                ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.upc_opt_out}`]: [
                    {
                        ...STEPPER_DATA.PATENT_AUTHENTICATION,
                        stepperName:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperName === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperName({
                                      name: 'European Patent – UPC Opt-Out'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperName,
                        stepperDesc:
                            typeof STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc === 'function'
                                ? STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc({
                                      description:
                                          'UPC Opt-Out requires a valid European patent number'
                                  })
                                : STEPPER_DATA.PATENT_AUTHENTICATION.stepperDesc
                    }
                ]
            },
            [SERVICE_TYPE_ID.paris_convention_treaty]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.translation_only}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ],
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]?.['translation_&_filing']}`]:
                    [
                        STEPPER_DATA.PATENT_DETAILS,
                        STEPPER_DATA.ADDITIONAL_INFORMATION,
                        STEPPER_DATA.DOCUMENT_UPLOAD,
                        STEPPER_DATA.SELECT_COUNTRY,
                        STEPPER_DATA.SUMMARY
                    ]
            },
            [SERVICE_TYPE_ID.other_translations]: {
                [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing}`]: [
                    STEPPER_DATA.ORDER_QUOTE_DETAILS,
                    STEPPER_DATA.STD_UPLOAD_AND_SELECTION
                ]
            }
        }
    }
};
