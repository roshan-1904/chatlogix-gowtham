import { QuoteOrderModuleStoreInfo } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { STEPPER_DATA_TYPE, STEPPER_INFO, STEPPER_STATE } from '../types/progressStepper.type';
import { STEPPER_DATA_LOCAL } from '../progressStepperMapping';
import { UserDetailsModal } from 'core/store/authStore/authStore';
import { MODE } from 'constants/app.constant';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

// update stepper-data(steps) when user select the service category on the 'service-type' page.
const getStepperDataForSelectedCategory = (
    quoteOrderInfo: QuoteOrderModuleStoreInfo,
    userInfo: UserDetailsModal,
    serviceTypeId: number,
    categoryId: number
) => {
    try {
        let requestType = quoteOrderInfo.mode;
        const isEditFlow = quoteOrderInfo.isEditFlow === true;

        // temporarily we have 2nd category for STD flow. but that also has same behavior as 1st category.
        if (serviceTypeId === SERVICE_TYPE_ID.other_translations)
            categoryId = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.other_translations]?.patent_non_filing;

        if (isEditFlow && requestType === MODE.CREATE_QUOTE) {
            requestType = MODE.EDIT_QUOTE;
        } else if (isEditFlow && requestType === MODE.CREATE_ORDER) {
            requestType = MODE.EDIT_ORDER;
        }

        if (!requestType) throw Error;

        // TODO:
        // const isEditFlow = quoteOrderInfo.isEditFlow;
        // const payload: { [key: string]: number } = {
        //     requestType,
        //     serviceTypeId,
        //     categoryId,
        //     orderRequestId: isEditFlow ? requestType : 0 // '0' for create
        // };
        // const apiUrl = `${END_POINT.SERVICE_TYPE.STEPPER_DATA}`;

        // const response: STEPPER_DATA_TYPE[] = await httpService.post(
        //     apiUrl,
        //     payload,
        //     {},
        //     false,
        //     baseURL
        // );
        // return response;

        // TODO: code to fetch local stepper data.
        // for now 'Admin' role config is not available. so that we use 'Project Manager' role config.
        const stepperDataLocal: STEPPER_DATA_TYPE[] =
            STEPPER_DATA_LOCAL[requestType][userInfo.roleId][serviceTypeId][categoryId];
        const updatedStepperDataLocal: STEPPER_DATA_TYPE[] = stepperDataLocal?.map(
            (step, index: number) => {
                /** use this as uniqueId of steps. 'stepperId' is unique but not in ascending order. */
                return { ...step, id: index + 1 };
            }
        );

        return updatedStepperDataLocal;
    } catch (error) {
        console.error('Error in getStepperDataForSelectedCategory(): ', error);
    }
};

// update stepper-info(currStep\completedSteps) when user click continue\next button.
const updateStepperStoreForNextPage = (stepper: STEPPER_STATE) => {
    try {
        if (!stepper?.stepperList) return;

        /* initially we have only default stepper values. 
        so that we send 'updatedStepperList' for only service-type page.
        for other pages it will use StoreData(stepper param). */
        const updatedStepperList = stepper?.stepperList;

        const stepperInfo = stepper.stepperInfo;
        // initially 'currStepId' is null
        const currStepId: number =
            stepperInfo.currStep?.stepperId ?? updatedStepperList[0]?.stepperId;

        const nextStep = getNextStep(currStepId, updatedStepperList);
        if (!nextStep) return; // if nextStep is undefined then this is the last step.

        /** check if currStepId is already completed. because we can jump among the completed steps.
         * so that time we can possible add the step twice */
        const isStepAlreadyCompleted: boolean | null = currStepId
            ? (stepperInfo.completedStepsIds || []).includes(currStepId)
            : null;

        // Update stepper info
        const updatedStepperInfo: STEPPER_INFO = {
            currStep: nextStep,
            // No need to modify if already completed or currStepId is empty, otherwise push currStepId
            completedStepsIds:
                isStepAlreadyCompleted || !currStepId
                    ? stepperInfo.completedStepsIds
                    : [...(stepperInfo.completedStepsIds || []), currStepId]
        };

        return updatedStepperInfo;
    } catch (error) {
        console.error('Error in updateStepperStoreForNextPage:', error);
    }
};
const updateStepperStoreForPreviousPage = (stepper: STEPPER_STATE) => {
    let updatedCurrStepId: number;
    let updatedCurrStep: STEPPER_DATA_TYPE;

    /** for previous page - remove the last item from the 'completedStepsIds'.
     and, set that removed item as 'currStepId' */
    const completedPages: number[] = stepper?.stepperInfo?.completedStepsIds;
    if (completedPages && completedPages.length > 0 && stepper?.stepperList) {
        updatedCurrStepId = completedPages[completedPages?.length - 1];
        updatedCurrStep = stepper?.stepperList.find(
            (step) => step.stepperId === updatedCurrStepId
        ) as STEPPER_DATA_TYPE;
        const updatedCompletedStepsIds: number[] = completedPages?.slice(0, -1);
        // update store with new data for upcoming page
        const updatedStepperInfo: STEPPER_INFO = {
            currStep: updatedCurrStep,
            completedStepsIds: updatedCompletedStepsIds
        };
        return updatedStepperInfo;
    }
};

// get the next step key
const getNextStep = (currStepId: number, stepperList: STEPPER_DATA_TYPE[]) => {
    if (!stepperList || stepperList.length === 0) {
        throw new Error('Stepper data is empty');
    }

    const currStepIndex = stepperList.findIndex((step: STEPPER_DATA_TYPE) => {
        return step?.stepperId === currStepId;
    });
    if (currStepIndex === -1) return;

    if (currStepIndex + 1 >= stepperList.length) {
        console.warn('Current step is the last step. No further steps to navigate.');
        return;
    }

    // Get the next step key
    const nextStep: STEPPER_DATA_TYPE = stepperList[currStepIndex + 1];

    return nextStep;
};

const progressStepperServices = {
    getStepperDataForSelectedCategory,
    updateStepperStoreForNextPage,
    updateStepperStoreForPreviousPage,
    getNextStep
};
export default progressStepperServices;
