import progressStepperServices from './progressStepper.service';
import { QuoteOrderModuleStoreInfo } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { STEPPER_DATA_TYPE, STEPPER_STATE } from '../types/progressStepper.type';
import { UserDetailsModal } from 'core/store/authStore/authStore';
import { MODE } from 'constants/app.constant';
import { STEPPER_DATA_LOCAL } from '../progressStepperMapping';
import { waitFor } from '@testing-library/react';

describe('progressStepperServices', () => {
    describe('getStepperDataForSelectedCategory', () => {
        it('should return updated stepper data for selected category', () => {
            const quoteOrderInfo: QuoteOrderModuleStoreInfo = {
                mode: MODE.CREATE_QUOTE,
                isEditFlow: false,
                // other properties
                selectedService: null,
                selectedCategory: null,
                primaryId: null,
                requestCurrencyId: null,
                documentId: null,
                isUP: null,
                approveStatus: 0,
                statusId: null,
                isSTDFlow: null
            };
            const userInfo: UserDetailsModal = {
                roleId: 1,
                // other properties
                permissions: [],
                userId: 0,
                userFullName: '',
                role: ''
            };
            const serviceTypeId = 1;
            const categoryId = 1;

            const result = progressStepperServices.getStepperDataForSelectedCategory(
                quoteOrderInfo,
                userInfo,
                serviceTypeId,
                categoryId
            );

            waitFor(() => {
                expect(result).toEqual(
                    STEPPER_DATA_LOCAL[MODE.CREATE_QUOTE][userInfo.roleId][serviceTypeId][
                        categoryId
                    ].map((step, index) => ({ ...step, id: index + 1 }))
                );
            });
        });
    });

    describe('updateStepperStoreForNextPage', () => {
        it('should update stepper info for next page', () => {
            const stepper: STEPPER_STATE = {
                stepperList: [
                    {
                        stepperId: 1 /* other properties */,
                        stepperName: '',
                        stepperDesc: ''
                    },
                    {
                        stepperId: 2 /* other properties */,
                        stepperName: '',
                        stepperDesc: ''
                    }
                ],
                stepperInfo: {
                    currStep: {
                        stepperId: 1,
                        stepperName: '',
                        stepperDesc: '' /* other properties */
                    },
                    completedStepsIds: []
                }
            };

            const result = progressStepperServices.updateStepperStoreForNextPage(stepper);

            if (result && stepper.stepperList) {
                expect(result).toEqual({
                    currStep: stepper.stepperList[1],
                    completedStepsIds: [1]
                });
            } else {
                expect(result).toBeUndefined();
            }

            waitFor(() => {
                expect(result).toEqual({
                    currStep: null,
                    completedStepsIds: [1]
                });
            });
        });

        it('should return undefined if stepperList is not defined', () => {
            const stepper: STEPPER_STATE = {
                stepperList: null,
                stepperInfo: {
                    currStep: null,
                    completedStepsIds: []
                }
            };

            const result = progressStepperServices.updateStepperStoreForNextPage(stepper);

            expect(result).toBeUndefined();
        });
    });

    describe('updateStepperStoreForPreviousPage', () => {
        it('should update stepper info for previous page', () => {
            const stepper: STEPPER_STATE = {
                stepperList: [
                    {
                        stepperId: 1 /* other properties */,
                        stepperName: '',
                        stepperDesc: ''
                    },
                    {
                        stepperId: 2 /* other properties */,
                        stepperName: '',
                        stepperDesc: ''
                    }
                ],
                stepperInfo: {
                    currStep: null,
                    completedStepsIds: [1, 2]
                }
            };

            const result = progressStepperServices.updateStepperStoreForPreviousPage(stepper);

            waitFor(() => {
                expect(result).toEqual({
                    currStep: [],
                    completedStepsIds: [1]
                });
            });
        });

        it('should return undefined if completedStepsIds is empty', () => {
            const stepper: STEPPER_STATE = {
                stepperList: [
                    { stepperId: 1, stepperName: '', stepperDesc: '' /* other properties */ },
                    { stepperId: 2, stepperName: '', stepperDesc: '' /* other properties */ }
                ],
                stepperInfo: {
                    currStep: {
                        stepperId: 1,
                        stepperName: '',
                        stepperDesc: '' /* other properties */
                    },
                    completedStepsIds: []
                }
            };

            const result = progressStepperServices.updateStepperStoreForPreviousPage(stepper);

            expect(result).toBeUndefined();
        });
    });

    describe('getNextStep', () => {
        it('should return the next step', () => {
            const stepperList: STEPPER_DATA_TYPE[] = [
                {
                    stepperId: 1 /* other properties */,
                    stepperName: '',
                    stepperDesc: ''
                },
                {
                    stepperId: 2 /* other properties */,
                    stepperName: '',
                    stepperDesc: ''
                }
            ];

            const result = progressStepperServices.getNextStep(1, stepperList);

            expect(result).toEqual(stepperList[1]);
        });

        it('should return undefined if current step is the last step', () => {
            const stepperList: STEPPER_DATA_TYPE[] = [
                {
                    stepperId: 1 /* other properties */,
                    stepperName: '',
                    stepperDesc: ''
                },
                {
                    stepperId: 2 /* other properties */,
                    stepperName: '',
                    stepperDesc: ''
                }
            ];

            const result = progressStepperServices.getNextStep(2, stepperList);

            expect(result).toBeUndefined();
        });

        it('should throw an error if stepperList is empty', () => {
            expect(() => {
                progressStepperServices.getNextStep(1, []);
            }).toThrow('Stepper data is empty');
        });
    });
});
