import { FC, useEffect, useState, CSSProperties, useLayoutEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import stepperStore from 'core/store/stepperStore/progressStepper.store';
import progressStepperServices from './services/progressStepper.service';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE,
    StepperInfoForMobileView,
    StepperStoreState
} from './types/progressStepper.type';
import { replaceLastSegment } from 'core/utils/utils';
import { isFormValid } from 'components/stepper/stepperButtons/stepperButton.constant';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';

interface ProgressStepperProps<T> {
    pathsForStepper: { [key: number]: string }; // Pass PATHS_FOR_STEPPER as a prop
    stepperModuleStore?: StepperStoreState<T>;
}

const ProgressStepper: FC<ProgressStepperProps<{ [key: string]: any }>> = ({
    pathsForStepper,
    stepperModuleStore
}) => {
    const stepperInfoForMobileViewInitialData: StepperInfoForMobileView = {
        currStepId: 0,
        currStepName: null,
        nextStepName: null,
        totalStepsLength: 0
    };

    const { t } = useTranslation();
    const navigate = useNavigate();
    const [stepper, setStepper] = useState<STEPPER_STATE>();
    const [stepperInfoForMobileView, setStepperInfoForMobileView] =
        useState<StepperInfoForMobileView>(stepperInfoForMobileViewInitialData);

    const [progressStepper, setProgressStepper] = useState('50%');

    const location = useLocation();
    const pathname = location?.pathname || '';
    const isFromView: boolean = pathname?.includes('view');
    const lastSegment = pathname.split('/').filter(Boolean).pop() || '';
    const style = {
        background: `radial-gradient(closest-side, white 85%, transparent 80% 100%), conic-gradient(#1d8ade ${progressStepper}, #A7D1F2 0)`
    } as CSSProperties;
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const handlerStepClick = async (switchToThisStep: STEPPER_DATA_TYPE) => {
        try {
            if (!stepper?.stepperInfo) return;

            const switchToThisStepId = switchToThisStep?.stepperId;

            // we can switch among only the completed steps. otherwise, no action needed for other steps.
            const completedPages = stepper?.stepperInfo?.completedStepsIds;
            const selectedStepIsAlreadyCompleted = completedPages?.includes(switchToThisStepId);
            if (!selectedStepIsAlreadyCompleted) return; // stop action if user try to switch in-completed steps.
            if (stepperModuleStore && !isFromView) {
                const formIsValid = await isFormValid(lastSegment, stepperModuleStore);
                if (!formIsValid) {
                    showToastMessage({
                        type: ToastType.ERROR,
                        message: t('COMMON.PLEASE_ENTER_MANDATORY')
                    });
                    return;
                }
            }
            // update store with new data for upcoming page
            const updatedStepperInfo: STEPPER_INFO = {
                ...stepper?.stepperInfo,
                currStep: switchToThisStep
            };
            if (updatedStepperInfo) {
                stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
            }

            /* when a user clicks the 'back' button on the 'service-type' page, 
                they will return to the 'orders-quotes' list page. */
            // const redirectTo = `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS_FOR_STEPPER[switchToThisStepId]}`;
            const redirectTo = replaceLastSegment(pathname, pathsForStepper[switchToThisStepId]);
            // const redirectTo = `${baseStepperPath}/${pathsForStepper[switchToThisStepId]}`;
            // redirect the next page
            navigate(redirectTo);
        } catch (error) {
            console.error('Error while retrieving metadata:', error);
        }
    };

    const getStepperInfoForMobileView = () => {
        try {
            if (!stepper?.stepperInfo?.currStep || !stepper?.stepperList) return;

            // Destructure stepperInfo and stepperList for clarity
            const { currStep } = stepper.stepperInfo;
            const { stepperList } = stepper;

            // curr step id
            const currStepId = currStep.stepperId ?? null;

            // current step index
            const currStepIndex =
                currStepId &&
                stepperList.findIndex((step: STEPPER_DATA_TYPE) => {
                    return step?.stepperId === currStepId;
                });

            // curr step name
            const currStepNameRaw = currStep.stepperName;
            const currStepName =
                typeof currStepNameRaw === 'function'
                    ? currStepNameRaw()
                    : (currStepNameRaw ?? null);

            // total steps length
            const totalStepsLength = stepperList.length;

            // next step name
            const nextStep: STEPPER_DATA_TYPE = progressStepperServices.getNextStep(
                currStepId,
                stepperList
            ) as STEPPER_DATA_TYPE;
            const nextStepNameRaw = nextStep ? nextStep.stepperName : null;
            const nextStepName =
                typeof nextStepNameRaw === 'function'
                    ? nextStepNameRaw()
                    : (nextStepNameRaw ?? null);

            const updatedStepperInfoForMobileView = {
                currStepId: currStepIndex + 1, // sometimes step id is not order. so that we use index+1
                currStepName,
                nextStepName,
                totalStepsLength
            };

            // progress bar UI update (mobile view)
            const progressPercentage: string =
                currStepIndex !== undefined && totalStepsLength !== undefined
                    ? (((currStepIndex + 1) / totalStepsLength) * 100).toFixed(2) + '%'
                    : '0%';
            setProgressStepper(progressPercentage);

            setStepperInfoForMobileView(updatedStepperInfoForMobileView);
        } catch (error) {
            console.error('Error on getNextStepName:', error);
        }
    };

    useEffect(() => {
        getStepperInfoForMobileView();
    }, [stepper]);

    // observe store
    useLayoutEffect(() => {
        const subscriptionStepper = stepperStore.subscribe(setStepper);
        stepperStore.init();

        return () => {
            subscriptionStepper?.unsubscribe();
        };
    }, []);

    return (
        <div data-testid="progress-stepper">
            {/* device - small */}
            <div className="lg:hidden flex justify-between">
                <div className="flex flex-col justify-center font-medium">
                    <h5 data-testid="current-step-name">
                        {t(stepperInfoForMobileView?.currStepName as string)}
                    </h5>
                    {stepperInfoForMobileView?.nextStepName && (
                        <p className="text-neutral-200" data-testid="next-step-name">
                            <span className="text-primary">{t('COMMON.NEXT')} </span>
                            {t(stepperInfoForMobileView?.nextStepName)}
                        </p>
                    )}
                </div>
                <div
                    className="w-16 h-16 rounded-badge"
                    style={style}
                    data-testid="progress-stepper-circle">
                    <div
                        className="h-full w-full flex items-center justify-center"
                        data-testid="progress-stepper-text">
                        {`${stepperInfoForMobileView?.currStepId} ${t('COMMON.OF_SMALL')} ${stepperInfoForMobileView?.totalStepsLength}`}
                    </div>
                </div>
            </div>
            {/* device - medium and above */}
            <div className="hidden lg:inline">
                <div data-testid="stepper-list">
                    <ul>
                        {stepper?.stepperList?.map((step: STEPPER_DATA_TYPE, index: number) => {
                            const currStepId = stepper?.stepperInfo?.currStep?.stepperId;
                            const completedStepsIds = stepper?.stepperInfo?.completedStepsIds;
                            return (
                                <li
                                    key={step?.stepperId}
                                    className={`flex ${completedStepsIds?.includes(step?.stepperId) ? 'cursor-pointer' : 'cursor-default'}`}
                                    onKeyDown={() =>
                                        completedStepsIds?.includes(step?.stepperId)
                                            ? void handlerStepClick(step)
                                            : null
                                    }
                                    onClick={() =>
                                        completedStepsIds?.includes(step?.stepperId)
                                            ? void handlerStepClick(step)
                                            : null
                                    }
                                    data-testid={`step-${step?.stepperId}`}>
                                    {(stepper.stepperList?.length ?? 0) > 1 && (
                                        <div className="flex flex-col justify-start items-center w-fit">
                                            <div
                                                className={`${step?.stepperId === currStepId ? 'border-primary border-[1px]' : null} p-[2px] h-[26px] w-[26px] rounded-full relative`}
                                                data-testid={`step-indicator-${step?.stepperId}`}>
                                                <div
                                                    className={`${
                                                        completedStepsIds?.includes(step?.stepperId)
                                                            ? 'bg-primary text-white'
                                                            : step?.stepperId === currStepId
                                                              ? 'bg-primary text-white'
                                                              : 'bg-neutral-200/25 text-neutral-200'
                                                    } h-[20px] w-[20px] grid place-content-center rounded-full text-xs font-medium`}
                                                    data-testid={`step-circle-${step?.stepperId}`}>
                                                    {completedStepsIds?.includes(
                                                        step?.stepperId
                                                    ) ? (
                                                        <i className="font-semibold pi pi-check text-[0.70rem] p-1"></i>
                                                    ) : (
                                                        index + 1
                                                    )}
                                                </div>
                                            </div>
                                            {stepper.stepperList?.length !== index + 1 && (
                                                <div
                                                    className="w-px h-full relative my-1 bg-neutral-200/50"
                                                    data-testid={`step-separator-${step?.stepperId}`}></div>
                                            )}
                                        </div>
                                    )}
                                    <div className="ml-2">
                                        <p
                                            className={`${step?.stepperId === currStepId ? 'text-primary' : null} text-lg font-medium`}
                                            data-testid={`step-name-${step?.stepperId}`}>
                                            {typeof step?.stepperName === 'function'
                                                ? step?.stepperName()
                                                : step?.stepperName}
                                        </p>
                                        <p
                                            className="text-base text-neutral-1000 pb-7"
                                            data-testid={`step-desc-${step?.stepperId}`}>
                                            {typeof step?.stepperDesc === 'string' ? (
                                                <span
                                                    dangerouslySetInnerHTML={{
                                                        __html: step?.stepperDesc
                                                    }}></span>
                                            ) : typeof step?.stepperDesc === 'function' ? (
                                                step?.stepperDesc()
                                            ) : (
                                                ''
                                            )}
                                        </p>
                                    </div>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default ProgressStepper;
