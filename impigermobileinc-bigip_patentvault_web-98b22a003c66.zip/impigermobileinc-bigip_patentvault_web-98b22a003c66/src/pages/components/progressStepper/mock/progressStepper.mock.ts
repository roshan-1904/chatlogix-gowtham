export const DEFAULT_STEPPER_DATA: any = {
    'STEP: 1': {
        data: {
            stepperId: 2,
            stepperName: 'Patent Authentication',
            stepperDesc: 'Patent Authentication'
        },
        role: [
            {
                roleId: 1,
                role: 'Contact User'
            },
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [1, 2, 3, 4, 5, 6]
    },
    'STEP: 2': {
        data: {
            stepperId: 7,
            stepperName: 'Additional information',
            stepperDesc: 'Additional information'
        },
        role: [
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [4, 5, 6]
    },
    'STEP: 3': {
        data: {
            stepperId: 3,
            stepperName: 'Patent Details',
            stepperDesc: 'Patent Details'
        },
        role: [
            {
                roleId: 1,
                role: 'Contact User'
            },
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [1, 2, 3, 4, 5, 6]
    },
    'STEP: 4': {
        data: {
            stepperId: 4,
            stepperName: 'Select Country',
            stepperDesc: 'Select Country'
        },
        role: [
            {
                roleId: 1,
                role: 'Contact User'
            },
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [1, 2, 3, 4, 5, 6]
    },
    'STEP: 5': {
        data: {
            stepperId: 5,
            stepperName: 'Document Upload',
            stepperDesc: 'Document Upload'
        },
        role: [
            {
                roleId: 1,
                role: 'Contact User'
            },
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [1, 2, 3, 4, 5, 6]
    },
    'STEP: 6': {
        data: {
            stepperId: 8,
            stepperName: 'Summary',
            stepperDesc: 'Summary'
        },
        role: [
            {
                roleId: 1,
                role: 'Contact User'
            },
            {
                roleId: 2,
                role: 'Project Manager'
            }
        ],
        mode: [1, 2, 3, 4, 5, 6]
    }
};
