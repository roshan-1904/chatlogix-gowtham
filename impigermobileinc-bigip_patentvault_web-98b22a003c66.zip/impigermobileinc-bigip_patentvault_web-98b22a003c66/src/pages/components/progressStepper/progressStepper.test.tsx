import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ProgressStepper from './progressStepper';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

jest.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate hook can use it without a warning being shown
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useSelector: jest.fn()
}));

describe('<ProgressStepper />', () => {
    const initialState = { progressStepper: [] };
    const mockStore = configureStore();
    let store;
    test.skip('it should mount', () => {
        store = mockStore(initialState);
        render(
            <Provider store={store}>
                <ProgressStepper pathsForStepper={{}} />
            </Provider>
        );

        const progressStepper = screen.getByTestId('progress-stepper');

        expect(progressStepper).toBeInTheDocument();
    });
});
