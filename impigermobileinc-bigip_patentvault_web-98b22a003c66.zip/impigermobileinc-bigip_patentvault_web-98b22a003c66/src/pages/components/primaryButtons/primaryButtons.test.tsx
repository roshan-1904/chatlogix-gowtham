// import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
// import { useTranslation } from 'react-i18next';
import PrimaryButtons from './primaryButtons';
// import stepperStore from 'core/store/stepperStore/progressStepper.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import orderQuoteServices from 'pages/createOrderAndQuote/services/createOrderAndQuote.service';
// import NotificationStore from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({ pathname: '/some-path' })
}));

jest.mock('core/store/stepperStore/progressStepper.store', () => ({
    subscribe: jest.fn(),
    updateStepper: jest.fn()
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(),
    subscribe: jest.fn(),
    updatePage: jest.fn()
}));

jest.mock('pages/createOrderAndQuote/services/createOrderAndQuote.service', () => ({
    getPDFData: jest.fn(),
    orderSave: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn(),
    hasPermission: jest.fn()
}));

describe('PrimaryButtons', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: { roleId: 1 }
        });
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                mode: 1,
                selectedService: { serviceTypeId: 1 },
                selectedCategory: { patentCategoryId: 1 }
            },
            formData: {
                companyDetailsPage: {},
                patentDetailsPage: {},
                summaryPage: { responseData: { summaryResponse: {} } },
                selectCountryPage: { customCountries: [] }
            },
            flags: { pagesMatchStatusWithBackupData: {} },
            isFormValid: {}
        });
    });

    test('renders PrimaryButtons component', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );
        expect(screen.getByText('COMMON.CONTINUE')).toBeInTheDocument();
    });

    test('handles Save & Export To PDF button click', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        waitFor(() => {
            const splitButton = screen.getByText('COMMON.SAVE_QUOTE');
            fireEvent.click(splitButton);
            expect(orderQuoteServices.getPDFData).toHaveBeenCalled();
        });
    });

    test('handles Save & Export To Excel button click', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        waitFor(() => {
            const splitButton = screen.getByText('COMMON.SAVE_QUOTE');
            fireEvent.click(splitButton);

            expect(orderQuoteServices.getPDFData).toHaveBeenCalled();
        });
    });

    test('handles Discard Quote button click', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        waitFor(() => {
            const discardButton = screen.getByText('Discard Quote');
            fireEvent.click(discardButton);

            expect(screen.getByText('COMMON.DISCARD_HEADER_QUOTE')).toBeInTheDocument();
        });
    });

    test('handles Continue button click', async () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        await waitFor(() => {
            const continueButton = screen.getByText('COMMON.CONTINUE');
            fireEvent.click(continueButton);
            expect(quoteOrderModuleStore.updatePage).toHaveBeenCalled();
        });
    });

    test('handles popup confirm button click', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        waitFor(() => {
            const discardButton = screen.getByText('Discard Quote');
            fireEvent.click(discardButton);

            const confirmButton = screen.getByText('COMMON.DISCARD');
            fireEvent.click(confirmButton);
            expect(screen.queryByText('COMMON.DISCARD_HEADER_QUOTE')).not.toBeInTheDocument();
        });
    });

    test('handles popup cancel button click', () => {
        render(
            <MemoryRouter>
                <PrimaryButtons />
            </MemoryRouter>
        );

        waitFor(() => {
            const discardButton = screen.getByText('Discard Quote');
            fireEvent.click(discardButton);

            const cancelButton = screen.getByText('COMMON.CANCEL');
            fireEvent.click(cancelButton);

            expect(screen.queryByText('COMMON.DISCARD_HEADER_QUOTE')).not.toBeInTheDocument();
        });
    });
});
