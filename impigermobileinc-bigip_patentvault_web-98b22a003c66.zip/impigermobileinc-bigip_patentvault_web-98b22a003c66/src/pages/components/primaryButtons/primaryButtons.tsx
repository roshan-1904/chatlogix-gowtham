import { useEffect, useState, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { QuoteOrderModuleStoreInfo } from 'core/store/orderQuoteStore/orderQuote.type.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import progressStepperServices from '../progressStepper/services/progressStepper.service';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from '../progressStepper/types/progressStepper.type';

import {
    CATEGORY_TYPE_ID,
    PATHS_FOR_STEPPER,
    SERVICE_TYPE_ID,
    STEPPER_TYPE_ID
} from 'constants/progressStepper.constant';
import { PATHS } from 'constants/routes.constant';
import orderQuoteServices, {
    createUpcOptOut
} from 'pages/createOrderAndQuote/services/createOrderAndQuote.service';
import orderQuoteModuleService, {
    pagesComparisonWithBackupData
} from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import {
    FILE_EXPORT_TYPE,
    MODE,
    PATENT_SOURCE_LANGUAGE,
    SAVE_APPROVE_BOOL,
    SAVE_APPROVE_NUM,
    STATUS_MODE,
    YES_NO
} from 'constants/app.constant';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import ConfirmationImage from 'assets/images/alertSuccess.svg';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import successImage from 'assets/images/successTickIcon.svg';
import { SplitButton } from 'primereact/splitbutton';
import { MenuItem } from 'primereact/menuitem';
import { OrderSave, OrderSaveResponse } from 'pages/ordersAndQuotes/types/ordersAndQuotes.types';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { Dialog } from 'primereact/dialog';
import utils, {
    focusOnFirstError,
    getWindowSize,
    isContactUser,
    isStaffUser,
    isVendorUser,
    penTestSecurityUtils
} from 'core/utils/utils';
import { Permissions } from 'constants/permissions';
import { dropDownStyle, previewDialogPopup, tooltipStyle } from 'constants/styles.constant';
import { Dropdown } from 'primereact/dropdown';
import { Tooltip } from 'primereact/tooltip';

interface ParamSaveApprovePopup {
    responseRequestNo: number;
    orderRequestNumber: string;
    isRecordalRenewalAnnuities: boolean;
}
interface ParamPageNavigation {
    /** we should send to API as number.
     *  yes this is 'Approve', but we should 'SaveQuote' first. */
    wantThisQuoteToSaveOrApprove: number;
    /** to handle popup description. */
    userTriggerThisQuoteToSaveOrApprove: boolean;
    fileExportType: number | null;
    triggerSuccessToastAndNavigateToListing: boolean;
}
interface PopupDescriptionType {
    isPopupConfirmation?: boolean;
}

const PrimaryButtons = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;

    // stores
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const [stepper, setStepper] = useState<STEPPER_STATE>();
    stepperStore.subscribe(setStepper);
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);

    const [currentPage, setCurrentPage] = useState<string>('');
    const [pdfUrl, setPdfUrl] = useState<string>('');
    const [fileExportType, setFileExportType] = useState<number | null>(null);

    const [visible, setVisible] = useState<boolean>(false);
    const [isDiscard, setIsDiscard] = useState<boolean>(false);
    const [isSummaryTablesConfirmForZero, setIsSummaryTablesConfirmForZero] =
        useState<boolean>(false);
    const [isLastPage, setIsLastPage] = useState<boolean>(false);
    const [userTriggerThisQuoteToSaveOrApprove, setUserTriggerThisQuoteToSaveOrApprove] =
        useState<boolean>(SAVE_APPROVE_BOOL.SAVE); // to handle hide/show popup buttons.
    const [isDisableNextButton, setIsDisableNextButton] = useState<boolean>(false);

    // variables
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const mode = quoteOrderData?.info.mode;
    const selectedServiceId = quoteOrderData.info.selectedService?.serviceTypeId;
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId;
    const PCT = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty];
    const EP = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent];
    const PC = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty];
    const isPCT = selectedServiceId === SERVICE_TYPE_ID.patent_cooperation_treaty;
    const isEP = selectedServiceId === SERVICE_TYPE_ID.european_patent;
    const isPC = selectedServiceId === SERVICE_TYPE_ID.paris_convention_treaty;
    const isStandard = selectedServiceId === SERVICE_TYPE_ID.other_translations;
    const isUpcOptOut = selectedCategoryId === EP['upc_opt_out'];
    const isQuoteCreationMode = mode === MODE.CREATE_QUOTE;
    const isOrderCreationMode = mode === MODE.CREATE_ORDER;
    const isEditFlow = quoteOrderData.info.isEditFlow === true;
    const contactUserName =
        quoteOrderData?.formData.companyDetailsPage?.selectedContact?.fullName ||
        quoteOrderData?.formData.patentDetailsPage?.contactUser?.fullName;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const sourceLanguage =
        quoteOrderData?.formData?.patentDetailsPage?.sourceLanguage?.toLowerCase() || '';
    const sourceLanguageName =
        quoteOrderData?.formData?.patentDetailsPage?.sourceLanguageName || null;
    const isBothDecideLater = quoteOrderData?.flags?.isBothDecideLaterDisableApprove ?? null;

    // helpers
    const isRecordalRenewalAnnuities = () => {
        const patentCategoryId = selectedCategoryId;
        const servicePCT = PCT;
        const serviceEP = EP;

        return (
            patentCategoryId === servicePCT.recordal ||
            patentCategoryId === servicePCT.annuities ||
            patentCategoryId === serviceEP.recordal ||
            patentCategoryId === serviceEP.Renewals
        );
    };
    const isInstantCountriesSelected = (): boolean => {
        // function to check if instant countries are selected
        const summaryResponse = quoteOrderData?.formData?.summaryPage?.responseData.summaryResponse;
        const instantCountrySelected =
            quoteOrderData?.formData.selectCountryPage?.instantCountries?.filter(
                (country) => country.isSelected
            );

        if (
            (summaryResponse?.instantCountryList?.countryFeeList &&
                summaryResponse.instantCountryList.countryFeeList.length > 0) ||
            (instantCountrySelected && instantCountrySelected?.length > 0)
        ) {
            return true;
        } else {
            return false;
        }
    };
    const isCustomCountriesSelected = (): boolean => {
        // function to check if custom countries are selected
        const summaryResponse = quoteOrderData?.formData?.summaryPage?.responseData.summaryResponse;
        const customCountrySelected =
            quoteOrderData?.formData.selectCountryPage?.customCountries?.filter(
                (country) => country.isSelected
            );

        if (
            (summaryResponse?.customCountryList &&
                summaryResponse?.customCountryList?.length > 0) ||
            (customCountrySelected && customCountrySelected?.length > 0)
        ) {
            return true;
        } else {
            return false;
        }
    };
    const isOnlyCustomCountriesSelected = () => {
        // function to check if only custom countries are selected
        const summaryResponse = quoteOrderData?.formData?.summaryPage?.responseData.summaryResponse;
        if (
            summaryResponse?.customCountryList &&
            summaryResponse?.customCountryList?.length > 0 &&
            summaryResponse?.instantCountryList?.countryFeeList.length === 0
        ) {
            return true;
        }
        return false;
    };
    const getCountriesNames = () => {
        const custom =
            quoteOrderData?.formData.selectCountryPage?.customCountries
                ?.filter((country) => country.isSelected)
                .map((country) => country.data.name) || [];
        const selectedCountryNames = [...custom].filter(Boolean);

        return selectedCountryNames;
    };
    const isDisabledApproveButton = () => {
        // Check it was a Approve button

        if (isThisContactUser && isUpcOptOut) {
            return false;
        }

        if (!isLastPage) {
            return false;
        }

        if (isLastPage && isBothDecideLater) {
            return true;
        }

        /** check permission */
        if (isLastPage && !AuthStore.hasPermission(Permissions.APPROVE_QUOTE)) {
            return true;
        }

        /** in create, if Contact-User select EstSeqListing as Yes means, then disable the Approve button. */
        const isEstSeqListingYes = getEstSeqListing() === YES_NO.YES;
        if (isThisContactUser && isQuoteCreationMode && isEstSeqListingYes) {
            return true;
        }

        // Check use is Admin or PM
        if (isThisStaffUser || isThisVendorUser) {
            return false;
        }

        // check if it was a Create Order
        if (isOrderCreationMode) {
            return false;
        }

        // Updated Store Data for changed values
        pagesComparisonWithBackupData(quoteOrderData);

        const pagesMatchStatusWithBackupData = quoteOrderData.flags.pagesMatchStatusWithBackupData;
        const isCountOrCountryChanged: boolean =
            pagesMatchStatusWithBackupData.isCountsModified ||
            pagesMatchStatusWithBackupData.isCountriesModified ||
            pagesMatchStatusWithBackupData.isCurrencyModified;

        /** 'isCountOrCountryChanged' - this flag ensure, if any mismatch b/w 'Edit-API' response and 'current-page' data. */
        if (isCountOrCountryChanged) {
            if (!isCustomCountriesSelected() && !isRecordalRenewalAnnuities()) {
                return false;
            }
            return true;
        }

        // If Mode is Crate Quote/Order or Preparing Quote.
        if (
            quoteOrderData.info.quoteStatus === STATUS_MODE.PREPARING_QUOTE ||
            isOrderCreationMode ||
            isQuoteCreationMode
        ) {
            // Check is there any Custom country selected.
            if (isCustomCountriesSelected()) {
                // Check weather its a Quote waiting for the approval status
                if (
                    quoteOrderData.info.quoteStatus &&
                    quoteOrderData.info.quoteStatus === STATUS_MODE.WAITING_FOR_APPROVAL
                ) {
                    return false;
                } else {
                    return true;
                }
            }

            // Check If it was the REcordal or Renewals or Annuities
            if (isRecordalRenewalAnnuities()) {
                if (
                    quoteOrderData.info.quoteStatus &&
                    quoteOrderData.info.quoteStatus === STATUS_MODE.WAITING_FOR_APPROVAL
                ) {
                    return false;
                } else {
                    return true;
                }
            }

            // Check is there any Custom country selected.
            if (isPatentSourceLanguage()) {
                return false;
            }
        }

        // Check PC has SL as English and Translation Only
        if (PC) {
            if (
                isQuoteCreationMode &&
                selectedCategoryId === PC['translation_only'] &&
                sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH.toLowerCase()
            ) {
                return false;
            }

            if (quoteOrderData.info.quoteStatus === STATUS_MODE.WAITING_FOR_APPROVAL) {
                return false;
            }
        }

        return true;
    };
    const checkToHideExport = () => {
        // check conditions by service and return the boolean value to hide export buttons.

        let serviceTypeShort = '';
        if (isPCT) serviceTypeShort = 'PCT';
        else if (isEP) serviceTypeShort = 'EP';
        else if (isPC) serviceTypeShort = 'PC';

        const isRRA = isRecordalRenewalAnnuities();
        const isEstSeqListingYes = getEstSeqListing() === YES_NO.YES;
        const isAnyCustomCountriesSelected = isCustomCountriesSelected();
        const isAnyInstantCountriesSelected = isInstantCountriesSelected();
        const majorSourceLanguages = ['en', 'fr', 'de'].some((lang) =>
            sourceLanguage.includes(lang)
        );

        // for PC show the button for rest of the scenarios except this.
        const showScenarioForPC =
            selectedCategoryId === PC['translation_only'] &&
            isAnyInstantCountriesSelected &&
            sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH.toLowerCase();

        switch (serviceTypeShort) {
            case 'PCT':
                return (
                    isThisContactUser &&
                    isQuoteCreationMode &&
                    isPCT &&
                    (isRRA ||
                        isEstSeqListingYes ||
                        isAnyCustomCountriesSelected ||
                        /** other source languages */
                        !majorSourceLanguages ||
                        /** 'en', 'fr', 'de' with custom country combination. */
                        (majorSourceLanguages && isAnyCustomCountriesSelected))
                );
            case 'EP':
                return (
                    isThisContactUser &&
                    isQuoteCreationMode &&
                    isEP &&
                    (isRRA || isEstSeqListingYes)
                );
            case 'PC':
                return (
                    isThisContactUser &&
                    isQuoteCreationMode &&
                    isPC &&
                    (isEstSeqListingYes || !showScenarioForPC)
                );
            default:
                return false;
        }
    };
    const isShowExportButtons = (): boolean => {
        /** should hide the export button, if below cond are satisfied. */
        const isHideExportOptions = checkToHideExport();
        return Boolean(!isHideExportOptions);
    };
    const getSplitButtonItems = (): MenuItem[] => {
        /** to avoid the unnecessary check. this function should only run when it required (isShowSplitButton()). */
        if (!isShowSplitButton()) return [];

        const items: MenuItem[] = [
            /** export excel and pdf will be hide / show based on the conditions. */
            ...(isShowExportButtons()
                ? [
                      {
                          label: 'Save & Export To PDF',
                          icon: (
                              <img
                                  src="/images/svgs/i-pdf-icon.svg"
                                  alt="PDF Icon"
                                  className="h-4 mr-2"
                              />
                          ),
                          command() {
                              setFileExportType(FILE_EXPORT_TYPE.PDF);
                              pageNavigation({
                                  wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.SAVE,
                                  userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.SAVE,
                                  fileExportType: FILE_EXPORT_TYPE.PDF,
                                  triggerSuccessToastAndNavigateToListing: false
                              });
                          }
                      },
                      {
                          label: 'Save & Export To Excel',
                          icon: (
                              <img
                                  src="/images/svgs/i-excel-blue-icon.svg"
                                  alt="Excel Icon"
                                  className="h-4 mr-2"
                              />
                          ),
                          command() {
                              setFileExportType(FILE_EXPORT_TYPE.EXCEL);
                              pageNavigation({
                                  wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.SAVE,
                                  userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.SAVE,
                                  fileExportType: FILE_EXPORT_TYPE.EXCEL,
                                  triggerSuccessToastAndNavigateToListing: false
                              });
                          }
                      }
                  ]
                : []),
            {
                label: 'Discard Quote',
                icon: 'pi pi-exclamation-circle text-secondary !font-medium',
                command() {
                    handleDiscardButton();
                }
            }
        ];

        return items;
    };
    const isShowPreviewButton = () => {
        const isWFA =
            quoteOrderModuleStore.getData().info.statusId === STATUS_MODE.WAITING_FOR_APPROVAL;

        return isLastPage && isEditFlow && isWFA && !isStandard;
    };
    const isShowSplitButton = () => {
        return isQuoteCreationMode && isLastPage && !isStandard && !isUpcOptOut;
    };

    const getEstSeqListing = (): number => {
        return (
            quoteOrderModuleStore.getData()?.formData?.patentDetailsPage
                ?.estimatedSequenceListing ?? 0
        );
    };
    const isPatentSourceLanguage = () => {
        const patentSourceLanguage =
            quoteOrderData.formData.companyDetailsPage?.patentDetails?.sourceLanguage;
        const patentTargetLanguage =
            patentSourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH ||
            patentSourceLanguage === PATENT_SOURCE_LANGUAGE.FRENCH ||
            patentSourceLanguage === PATENT_SOURCE_LANGUAGE.GERMANY;

        return patentTargetLanguage;
    };
    const getPrimaryButtonLabel = (): string => {
        const currStepId = stepper?.stepperInfo.currStep?.stepperId as number;
        const stepperList = stepper?.stepperList as STEPPER_DATA_TYPE[];
        if (!currStepId || !stepperList) return 'COMMON.CONTINUE'; // return if stepper data is not available

        const getNextStep = progressStepperServices.getNextStep(currStepId, stepperList);

        let labelName = '';

        if (getNextStep) {
            labelName = 'COMMON.CONTINUE';
        } else if (isUpcOptOut) {
            labelName = isQuoteCreationMode
                ? 'QUOTE_AND_ORDER.REQUEST_QUOTE'
                : 'QUOTE_AND_ORDER.SUBMIT_ORDER';
        } else if (isQuoteCreationMode) {
            labelName = 'QUOTE_AND_ORDER.APPROVE_QUOTE';
        } else if (isOrderCreationMode) {
            labelName = 'QUOTE_AND_ORDER.APPROVE_ORDER';
        }
        return labelName;
    };
    const buttonLabel = () => {
        // function for decide the button label based on condition
        if (isThisStaffUser || isThisVendorUser) {
            return 'COMMON.SAVE_&_SEND';
        } else {
            return 'COMMON.SAVE_QUOTE';
        }
    };

    // actions
    const downloadPDF = async (isEpOrNonUpPreview?: 'EP' | 'Non-UP') => {
        try {
            const response = await orderQuoteServices.getPDFData(
                quoteOrderData?.info?.selectedCategory?.serviceUniqueName as string,
                isEpOrNonUpPreview
            );
            setPdfUrl(response);
            if (response) {
                setVisible(true);
            }
        } catch (error) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
                type: ToastType.ERROR
            });
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    // functions
    const formSummaryValidation = (params: ParamPageNavigation) => {
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();

        /** ignore further actions if summary tables inline edit is in-progress. */
        if (updatedQuoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        if (isThisStaffUser || isThisVendorUser) {
            const updatedQuoteOrderIsFormValid = {
                ...quoteOrderData.isFormValid,
                [PATHS.SUMMARY]: true
            };

            /** trigger the table error if any cell has null values. */
            const isSummaryTablesHasInvalidValues: boolean =
                orderQuoteModuleService.checkSummaryTablesHasInvalidValues(updatedQuoteOrderData);

            /** if cells don't have invalid values('isSummaryTablesHasValuesAsZero' is false),
             *  then check if any cells has value as '0'. If yes then trigger the confirmation popup to proceed further. */
            let isSummaryTablesHasValuesAsZero: boolean = false;
            if (!isSummaryTablesHasInvalidValues) {
                isSummaryTablesHasValuesAsZero =
                    orderQuoteModuleService.checkSummaryTablesHasInvalidValues(
                        updatedQuoteOrderData,
                        true // flag to check only zero values
                    );
            }

            if (isSummaryTablesHasInvalidValues) {
                const message: notificationModel = {
                    message: t('SUMMARY.COUNTRY_FEE_ERROR'),
                    type: ToastType.ERROR
                };
                NotificationStore.showAlert(message);
                updatedQuoteOrderIsFormValid[PATHS.SUMMARY] = false;
            }
            if (isSummaryTablesHasValuesAsZero) {
                handleSummaryTablesConfirmForZero(params);
            }
            quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);

            if (isSummaryTablesHasInvalidValues) {
                return;
            } else if (!isSummaryTablesHasInvalidValues && !isSummaryTablesHasValuesAsZero) {
                formValidationToNavigate(params);
            }
        } else {
            formValidationToNavigate(params);
        }
    };
    const formValidationToNavigate = async (params: ParamPageNavigation) => {
        let updatedQuoteOrderData = quoteOrderModuleStore.getData();
        // approve status update whether save or approved
        const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
            ...quoteOrderData?.info,
            approveStatus: params.wantThisQuoteToSaveOrApprove
        };
        quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo);

        // trigger form submit event for current page
        document.getElementById(`submit-${currentPage}`)?.click();

        // Wait for the form to be validated and store to be updated
        await new Promise((r) => setTimeout(r, 100));

        focusOnFirstError();

        // update the store data
        setQuoteOrderData(quoteOrderModuleStore.getData());

        // check the form validation status to redirect
        updatedQuoteOrderData = quoteOrderModuleStore.getData();

        if (updatedQuoteOrderData.isFormValid[currentPage]) {
            redirectToNextPage(params);
        }
    };
    const pageNavigation = (params: ParamPageNavigation) => {
        penTestSecurityUtils(quoteOrderModuleStore?.getData()?.formData);
        const isSummaryPage = currentPage === PATHS.SUMMARY;

        if (isSummaryPage) {
            /** Note: this 'formSummaryValidation()' will take care of this 'formValidationToNavigate()' too. */
            formSummaryValidation(params);
        } else {
            formValidationToNavigate(params);
        }
    };
    const redirectToNextPage = (params: ParamPageNavigation) => {
        try {
            const _quoteOrderData = quoteOrderModuleStore.getData();
            if (!_quoteOrderData.isFormValid[currentPage] || !stepper?.stepperInfo) return;

            // update stepperInfo on store
            /** set default value for the first page 'service-type'.
                 because once selected the service category after that we fetch stepper data,
                 and assign that first value of index as stepperInfo.
                 otherwise go with regular functionality */
            const updatedStepperInfo: STEPPER_INFO | undefined =
                currentPage !== PATHS.SERVICE_TYPE
                    ? progressStepperServices?.updateStepperStoreForNextPage(stepper)
                    : stepper.stepperInfo;

            /** if this info is 'undefined' then this is the last step.
                 so, return and trigger Submission API call */
            if (!updatedStepperInfo) {
                triggerFinalSubmission(params);
                return;
            } else if (updatedStepperInfo?.currStep) {
                const isSelectCountryPage = currentPage === PATHS.SELECT_COUNTRY;
                const isPatentDetailsPage = currentPage === PATHS.PATENT_DETAILS;

                /** Note: When user clicks on 'Continue' button, each time we should handle both 'Stepper-Navigation' and 'Page-Navigation(URL)'.
                 *  But if we do any API call in b/w of the pages, the process will be the async right?. In this scenario API may pass/fail.
                 *  So, we need to handle this scenario based on the API response.
                 *  Use 'skipStepperNavigate' to find those pages. and handle those navigation on Service file. */
                const skipStepperNavigate = isPatentDetailsPage || isSelectCountryPage;
                if (!skipStepperNavigate) {
                    // get data to redirect from store
                    const currStep = updatedStepperInfo?.currStep;
                    const redirectTo = PATHS_FOR_STEPPER[currStep?.stepperId];

                    stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
                    setCurrentPage(redirectTo);

                    // redirect the next page
                    navigate(
                        `/${PATHS.ORDER_QUOTE}/${isEditFlow ? PATHS.EDIT : PATHS.CREATE}/${redirectTo}`
                    );
                }
            }
        } catch (error) {
            console.error('Error while retrieving metadata:', error);
        }
    };
    const triggerFinalSubmission = async (params: ParamPageNavigation) => {
        try {
            if (isUpcOptOut) {
                setShowPopup({
                    ...showPopup,
                    visible: true,
                    header: <h4 className="text-secondary">{t('COMMON.CONFIRMATION')}</h4>,
                    description: getPopupDescription({ isPopupConfirmation: true }),
                    acceptLabel: t('COMMON.YES'),
                    rejectLabel: t('COMMON.NO')
                });
            } else {
                const isLastSelectCountryPage =
                    currentPage === PATHS.SELECT_COUNTRY &&
                    stepperStore.getIsLastStepper(STEPPER_TYPE_ID.SELECT_COUNTRY);

                let response: OrderSaveResponse<OrderSave> | null = null;

                if (isLastSelectCountryPage) {
                    const res: string | null = await orderQuoteModuleService.saveDraft(true);
                    if (res === 'IS_FINAL_STEP') {
                        response = await orderQuoteServices.orderSave(params.fileExportType);
                    }
                } else {
                    response = await orderQuoteServices.orderSave(params.fileExportType);
                }

                if (!response) return; // no valid response, stop execution
                const endSubmission: OrderSave = response.orderResponse;
                const paramSaveApprovePopupData: ParamSaveApprovePopup = {
                    responseRequestNo: endSubmission.orderNumber,
                    orderRequestNumber: endSubmission.orderRequestNumber,
                    isRecordalRenewalAnnuities: isRecordalRenewalAnnuities()
                };

                if (!endSubmission) return;

                // handle success + toast + navigation
                if (params.triggerSuccessToastAndNavigateToListing) {
                    navigate(`/${PATHS.ORDER_QUOTE}`);
                    setShowPopup({ ...popupDataInit, visible: false });

                    if (endSubmission.quoteStatus === MODE.CREATE_ORDER && isQuoteCreationMode) {
                        showToastMessage({
                            message: `${endSubmission.orderRequestNumber} ${t('COMMON.ORDER_SUCCESS_MESSAGE')}`,
                            type: ToastType.SUCCESS
                        });
                    }
                }

                // handle popup confirmation
                handleConfirmPopup(
                    paramSaveApprovePopupData,
                    params.userTriggerThisQuoteToSaveOrApprove
                );
            }
        } catch (error) {
            console.error('Error while final submission:', error);
        }
    };

    // popup
    const getPopupHeaderImage = (): string => {
        let img = null;

        if (isUpcOptOut) {
            img = showPopup.isShowAcceptButton ? ConfirmationRedImage : successImage;
        } else if (isDiscard || isSummaryTablesConfirmForZero) {
            img = ConfirmationRedImage;
        } else if (
            selectedCategoryId === PCT.recordal &&
            selectedCategoryId === PCT.annuities &&
            selectedCategoryId === EP.recordal &&
            selectedCategoryId === EP.Renewals
        ) {
            img = ConfirmationImage;
        } else {
            img = successImage;
        }

        return img;
    };
    const setPopupCustomClass = (): string => {
        let className: string = '';

        if (isDiscard || isSummaryTablesConfirmForZero) {
            className = 'orderOrQuotePopup';
        } else if ((!userTriggerThisQuoteToSaveOrApprove || isOrderCreationMode) && !isUpcOptOut) {
            // when user trigger Save or user entered as Order creation mode
            className = 'orderOrQuotePopupHideCancelButton';
        } else {
            className = 'orderOrQuotePopup';
        }

        return className;
    };
    const pcConfirmationPopupHeader = () => {
        if (isQuoteCreationMode && isThisContactUser) {
            if (
                (selectedCategoryId === PC['translation_only'] &&
                    sourceLanguage !== PATENT_SOURCE_LANGUAGE.ENGLISH.toLowerCase()) ||
                selectedCategoryId === PC['translation_&_filing']
            ) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    };
    const renderOrderLink = (
        requestId: number | number[],
        orderRequestNumber: string | string[] | undefined,
        _userTriggerThisQuoteToSaveOrApprove: boolean
    ) => {
        /** check permission */
        const hasPermission =
            AuthStore.hasPermission(Permissions.VIEW_QUOTE) ||
            AuthStore.hasPermission(Permissions.VIEW_ORDER);

        const handleClick = (id: number) => {
            if (!hasPermission) return;
            navigate(
                isUpcOptOut
                    ? `/orders-quotes/details/upc-opt-out/${id}`
                    : `/orders-quotes/details/${id}`
            );
        };
        const orderLinkButton = (id: number, index: number | null = null) => {
            return !_userTriggerThisQuoteToSaveOrApprove || isOrderCreationMode ? (
                <span
                    className={`${hasPermission ? 'underline' : ''} text-primary cursor-pointer`}
                    role="button"
                    onClick={() => handleClick(id)}
                    data-testid="order-link"
                    onKeyDown={(e) => e.key === 'Enter' && handleClick(id)}>
                    {orderRequestNumber && (index || index === 0)
                        ? orderRequestNumber[index]
                        : orderRequestNumber}{' '}
                </span>
            ) : (
                <span className="text-black">
                    {orderRequestNumber && (index || index === 0)
                        ? orderRequestNumber[index]
                        : orderRequestNumber}{' '}
                </span>
            );
        };

        if (
            typeof requestId === 'number' &&
            requestId !== 0 &&
            typeof orderRequestNumber === 'string' &&
            orderRequestNumber !== ''
        ) {
            return orderLinkButton(requestId);
        } else if (Array.isArray(requestId) && Array.isArray(orderRequestNumber)) {
            return (
                <>
                    {requestId.map((id, index) => (
                        <>
                            <br />
                            {orderLinkButton(id, index)}
                        </>
                    ))}
                </>
            );
        }

        return null;
    };
    const headerStyle = (
        requestId: number | number[],
        orderRequestNumber: string | string[] | undefined,
        recordalRenewalAnnuitiesFlag: boolean,
        _userTriggerThisQuoteToSaveOrApprove: boolean
    ) => {
        const pagesMatchStatusWithBackupData = quoteOrderData.flags.pagesMatchStatusWithBackupData;
        const isAnyChanged: boolean =
            pagesMatchStatusWithBackupData.isCountsModified ||
            pagesMatchStatusWithBackupData.isCountriesModified ||
            pagesMatchStatusWithBackupData.isCompanyModified ||
            pagesMatchStatusWithBackupData.isLanguagesModified;
        return (
            <div>
                {/* Popup header title */}
                {(() => {
                    // 'checkToHideExport' - by this same condition we should change the title as well.
                    const isHideExport = checkToHideExport();

                    if (isUpcOptOut) {
                        return (
                            <h4 className="text-success mb-2">
                                {_userTriggerThisQuoteToSaveOrApprove
                                    ? t('QUOTE_AND_ORDER.ORDER_SUCCESS')
                                    : t('COMMON.QUOTE_REQUEST_MESSAGE')}
                            </h4>
                        );
                    } else if (isHideExport) {
                        return (
                            <h4 className="text-success">
                                {t('COMMON.QUOTE_SUCCESS_ALMOST_THERE')}
                            </h4>
                        );
                    } else if (
                        pcConfirmationPopupHeader() ||
                        (!isThisStaffUser &&
                            !isThisVendorUser &&
                            !_userTriggerThisQuoteToSaveOrApprove &&
                            recordalRenewalAnnuitiesFlag)
                    ) {
                        if (isAnyChanged) {
                            return (
                                <h4 className="text-success">{t('COMMON.FINAL_POPUP_HEADER_1')}</h4>
                            );
                        } else if (isPC) {
                            if (_userTriggerThisQuoteToSaveOrApprove) {
                                return (
                                    <h4 className="text-success">
                                        {t('COMMON.QUOTE_SUCCESS_MESSAGE')}
                                    </h4>
                                );
                            } else {
                                return (
                                    <h4 className="text-success">
                                        {t('COMMON.QUOTE_SAVED_SUCCESS_MESSAGE')}
                                    </h4>
                                );
                            }
                        } else {
                            return (
                                <h4 className="text-success">
                                    {t('COMMON.QUOTE_SAVED_SUCCESS_MESSAGE')}
                                </h4>
                            );
                        }
                    } else if (isQuoteCreationMode || isEditFlow) {
                        if (_userTriggerThisQuoteToSaveOrApprove) {
                            return (
                                <h4 className="text-success">
                                    {t('COMMON.QUOTE_SUCCESS_MESSAGE')}
                                </h4>
                            );
                        } else if (!isThisStaffUser && !isThisVendorUser) {
                            return (
                                <h4 className="text-success">
                                    {t('COMMON.QUOTE_SAVED_SUCCESS_MESSAGE')}
                                </h4>
                            );
                        } else {
                            return (
                                <h4 className="text-success">{t('COMMON.QUOTE_SAVE_AND_SEND')}</h4>
                            );
                        }
                    } else {
                        return (
                            <h4 className="text-success">{t('COMMON.ORDER_SUCCESS_MESSAGE')}</h4>
                        );
                    }
                })()}

                {/* Popup desc at below title */}
                <h6 className="text-black">
                    {t('COMMON.FINAL_POPUP_HEADER_2')}{' '}
                    {renderOrderLink(
                        requestId,
                        orderRequestNumber,
                        _userTriggerThisQuoteToSaveOrApprove
                    )}
                </h6>
            </div>
        );
    };
    const popupDataInit = {
        visible: false,
        header: headerStyle(0, '', false, true),
        description: '',
        acceptLabel: '',
        rejectLabel: t('COMMON.CANCEL'),
        userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.APPROVE,
        isShowAcceptButton: true
    };
    const [showPopup, setShowPopup] = useState(popupDataInit);

    // trigger popup
    const handleConfirmPopup = (
        /** popup - end submission on final */
        params: ParamSaveApprovePopup,
        _userTriggerThisQuoteToSaveOrApprove: boolean
    ) => {
        setShowPopup({
            ...showPopup,
            visible: true,
            header: headerStyle(
                params.responseRequestNo,
                params.orderRequestNumber,
                params.isRecordalRenewalAnnuities,
                _userTriggerThisQuoteToSaveOrApprove
            ),
            description: getPopupDescription({ isPopupConfirmation: true }),
            acceptLabel: isQuoteCreationMode
                ? _userTriggerThisQuoteToSaveOrApprove
                    ? t('COMMON.CONFIRM')
                    : t('COMMON.CLOSE')
                : t('COMMON.CLOSE'),
            userTriggerThisQuoteToSaveOrApprove: _userTriggerThisQuoteToSaveOrApprove
        });
    };
    const handleSummaryTablesConfirmForZero = (params: ParamPageNavigation) => {
        let zeroValidationPopupDescription: string = '';
        const isUserTriggerSaveButton =
            params.userTriggerThisQuoteToSaveOrApprove === SAVE_APPROVE_BOOL.SAVE;
        const isUserTriggerApproveButton =
            params.userTriggerThisQuoteToSaveOrApprove === SAVE_APPROVE_BOOL.APPROVE;

        if (isUserTriggerSaveButton) {
            zeroValidationPopupDescription = t(
                'QUOTE_AND_ORDER.WARNING.TABLE_SAVE_QUOTE_HAS_ZERO_VALUES'
            );
        } else if (isUserTriggerApproveButton) {
            if (isQuoteCreationMode) {
                zeroValidationPopupDescription = t(
                    'QUOTE_AND_ORDER.WARNING.TABLE_ORDER_HAS_ZERO_VALUES',
                    {
                        requestType: 'quote'
                    }
                );
            } else if (isOrderCreationMode) {
                zeroValidationPopupDescription = t(
                    'QUOTE_AND_ORDER.WARNING.TABLE_ORDER_HAS_ZERO_VALUES',
                    {
                        requestType: 'order'
                    }
                );
            }
        }

        /** popup - confirmation for zero */
        setIsSummaryTablesConfirmForZero(true);
        setShowPopup({
            ...showPopup,
            visible: true,
            header: <h4 className="text-danger">{t('COMMON.WARNING_CAPS')}</h4>,
            acceptLabel: t('COMMON.CONFIRM'),
            rejectLabel: t('COMMON.CANCEL'),
            description: zeroValidationPopupDescription,
            userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.SAVE
        });
    };

    const handleCreateUpcOptOut = async () => {
        const result: {
            orderRequestId: number;
            requestNumber: string;
            requestTypeId: number;
        } = await createUpcOptOut();
        try {
            if (result) {
                setShowPopup({
                    ...showPopup,
                    visible: true,
                    header: headerStyle(
                        result.orderRequestId,
                        result.requestNumber,
                        false,
                        result.requestTypeId === MODE.CREATE_ORDER
                            ? SAVE_APPROVE_BOOL.APPROVE
                            : SAVE_APPROVE_BOOL.SAVE
                    ),
                    description: '',
                    rejectLabel: t('COMMON.CLOSE'),
                    isShowAcceptButton: false
                });
            }
        } catch (error) {
            console.error('Error while creating UPC Opt-Out:', error);
            showToastMessage({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.UPC_OPT_OUT_CREATION_FAILED'),
                type: ToastType.ERROR
            });
        }
    };

    const handleDiscardButton = () => {
        /** popup - handle discard */
        setIsDiscard(true);
        setUserTriggerThisQuoteToSaveOrApprove(SAVE_APPROVE_BOOL.APPROVE);
        setShowPopup({
            ...showPopup,
            visible: true,
            header: discardHeaderStyle(),
            acceptLabel: t('COMMON.DISCARD'),
            description: getPopupDescription(),
            userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.SAVE
        });
    };

    // popup - confirm button handler
    const popupHandleConfirm = () => {
        if (isUpcOptOut) {
            handleCreateUpcOptOut();
            setShowPopup({ ...showPopup, visible: false });
        } else if (isSummaryTablesConfirmForZero) {
            setIsSummaryTablesConfirmForZero(false);

            formValidationToNavigate({
                wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.SAVE,
                userTriggerThisQuoteToSaveOrApprove,
                triggerSuccessToastAndNavigateToListing: false,
                fileExportType
            });
            setShowPopup({ ...showPopup, visible: false });
        } else if (isDiscard || isOrderCreationMode || !userTriggerThisQuoteToSaveOrApprove) {
            navigate(`/${PATHS.ORDER_QUOTE}`);
            setShowPopup({ ...showPopup, visible: false });
        } else {
            formValidationToNavigate({
                wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.APPROVE,
                userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.APPROVE,
                triggerSuccessToastAndNavigateToListing: true, // trigger final process and navigate to listing
                fileExportType
            });
        }
    };
    const popupHandleCancel = () => {
        if (isUpcOptOut && !showPopup.isShowAcceptButton) {
            navigate(`/${PATHS.ORDER_QUOTE}`);
        } else {
            setShowPopup({ ...popupDataInit, visible: false });
            setUserTriggerThisQuoteToSaveOrApprove(SAVE_APPROVE_BOOL.SAVE);
            setIsDiscard(false);
            setIsSummaryTablesConfirmForZero(false);
        }
    };

    // popup - helpers
    const discardHeaderStyle = () => {
        return (
            <div>
                {isQuoteCreationMode ? (
                    <>
                        <h4 className="text-danger">{t('COMMON.DISCARD_HEADER_QUOTE')}</h4>
                        <h6 className="text-black">{t('COMMON.DISCARD_MESSAGE_QUOTE')}</h6>
                    </>
                ) : (
                    <>
                        <h4 className="text-danger">{t('COMMON.DISCARD_HEADER_ORDER')}</h4>
                        <h6 className="text-black">{t('COMMON.DISCARD_MESSAGE_ORDER')}</h6>
                    </>
                )}
            </div>
        );
    };
    const getPopupDescription = (params: PopupDescriptionType = {}): string => {
        const { isPopupConfirmation } = params;
        const isHideExport = checkToHideExport();
        const isRRA = isRecordalRenewalAnnuities();
        const countryNames: string[] = getCountriesNames();
        const countryNameString = countryNames.length > 0 ? `(${countryNames.join(', ')})` : '';
        let desc = '';

        // check if user went back from Summary page and made any changes in prev forms.
        const pagesMatchStatusWithBackupData = quoteOrderData.flags.pagesMatchStatusWithBackupData;
        const isUserHasMadeChanges: boolean =
            pagesMatchStatusWithBackupData.isCountsModified ||
            pagesMatchStatusWithBackupData.isCountriesModified ||
            pagesMatchStatusWithBackupData.isCompanyModified ||
            pagesMatchStatusWithBackupData.isLanguagesModified;

        const baseConditions = () => {
            if (isEditFlow && showPopup.userTriggerThisQuoteToSaveOrApprove) {
                return '';
            } else if (isSummaryTablesConfirmForZero && !isPopupConfirmation) {
                return t('QUOTE_AND_ORDER.WARNING.TABLE_HAS_ZERO_VALUES');
            } else if (isUserHasMadeChanges) {
                return 'CHANGE_OCCURRED';
            }
            return '';
        };

        if (isPCT) {
            if (isHideExport && !isRRA) {
                desc = t('COMMON.DESC_WITH_SL_COUNTRY', {
                    txt_source_language: sourceLanguageName || '{Source Language}',
                    txt_selected_countries: countryNameString
                });
            } else if (selectedCategoryId === PCT.recordal) {
                desc = baseConditions();
                if (desc === 'CHANGE_OCCURRED' || isHideExport) {
                    desc = t('COMMON.PCT_RECORDAL');
                }
            } else if (selectedCategoryId === PCT.annuities) {
                desc = baseConditions();
                if (desc === 'CHANGE_OCCURRED' || isHideExport) {
                    desc = t('COMMON.PCT_ANNUITIES');
                }
            } else if (isPopupConfirmation) {
                if (isThisContactUser && isOnlyCustomCountriesSelected()) {
                    desc = t('COMMON.ONLY_CUSTOM_COUNTRY_DESCRIPTION');
                } else if (isQuoteWithHighRole()) {
                    desc = `${t('COMMON.QUOTE_DESCRIPTION')} ${contactUserName}`;
                } else if (isOrderCreationMode) {
                    desc = '';
                }
            }
        } else if (isEP) {
            if (selectedCategoryId === EP.recordal) {
                desc = baseConditions();
                if (desc === 'CHANGE_OCCURRED' || isHideExport) {
                    desc = t('COMMON.EP_RECORDAL');
                }
            } else if (selectedCategoryId === EP.Renewals) {
                desc = baseConditions();
                if (desc === 'CHANGE_OCCURRED' || isHideExport) {
                    desc = t('COMMON.EP_RENEWALS');
                }
            } else if (isUpcOptOut) {
                desc = isOrderCreationMode
                    ? t('QUOTE_AND_ORDER.UPC_ORDER_CONFIRMATION')
                    : t('QUOTE_AND_ORDER.UPC_QUOTE_CONFIRMATION');
            }
        } else if (isPC) {
            if (isHideExport && !isRRA) {
                const condDesc =
                    countryNames.length > 0
                        ? 'COMMON.DESC_WITH_SL_COUNTRY'
                        : 'COMMON.PC_DESCRIPTION';
                desc = t(condDesc, {
                    txt_source_language: sourceLanguageName || '{Source Language}',
                    txt_selected_countries: countryNameString
                });
            } else if (pcConfirmationPopupHeader() && isUserHasMadeChanges) {
                desc = t('COMMON.PC_DESCRIPTION', { txt_source_language: sourceLanguage });
            }
        }

        setShowPopup({ ...showPopup, description: desc });
        return desc;
    };
    const isQuoteWithHighRole = () => {
        // function to check if quote is created by Staff/Vendor user
        if (isQuoteCreationMode && (isThisStaffUser || isThisVendorUser)) {
            return true;
        }
        return false;
    };

    useEffect(() => {
        /** disable/enable 'Continue' button for 'service-type' page. */

        /** listen store changes about form valid status,
            and make for validation for 'Continue' button here based on that changes */
        if (currentPage && quoteOrderData && currentPage === PATHS.SERVICE_TYPE) {
            const formValidation = quoteOrderData?.isFormValid[currentPage];
            setIsDisableNextButton(formValidation !== null ? formValidation : false);
        } else setIsDisableNextButton(true);

        const currStepId = stepper?.stepperInfo.currStep?.stepperId as number;
        const stepperList = stepper?.stepperList as STEPPER_DATA_TYPE[];
        if (currStepId && stepperList) {
            const getNextStep = progressStepperServices.getNextStep(currStepId, stepperList);
            setIsLastPage(getNextStep ? false : true);
        }
    }, [currentPage, quoteOrderData]);
    useEffect(() => {
        /** get current page name from pathname. */
        const pathNameList = pathname.split('/');
        const currentPageUrl = pathNameList[pathNameList.length - 1];

        if (currentPageUrl) {
            setCurrentPage(currentPageUrl);
        }
    }, [pathname]);

    return (
        <div className="flex items-center gap-1 md:gap-5">
            {showPopup.visible && (
                <ConfirmationPopup
                    popupID="orderOrQuotePopup"
                    image={getPopupHeaderImage()}
                    className={setPopupCustomClass()}
                    onConfirm={() => {
                        popupHandleConfirm();
                    }}
                    onCancel={() => {
                        popupHandleCancel();
                    }}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={showPopup.acceptLabel}
                    rejectLabel={showPopup.rejectLabel}
                    isShowAcceptButton={showPopup.isShowAcceptButton}
                />
            )}

            <Dialog
                pt={previewDialogPopup}
                header={
                    <div className="w-full flex justify-between items-center">
                        {(isQuoteCreationMode
                            ? t('COMMON.QUOTE') + ' - '
                            : t('COMMON.ORDER') + ' - ') +
                            (quoteOrderData?.info?.requestNumber ?? 'Preview')}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(
                                    pdfUrl,
                                    (isQuoteCreationMode
                                        ? t('COMMON.QUOTE') + ' - '
                                        : t('COMMON.ORDER') + ' - ') +
                                        (quoteOrderData?.info.requestNumber ?? 'Preview')
                                )
                            }
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="download-pdf"
                        />
                    </div>
                }
                visible={visible}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>

            {/* button - preview */}
            {isShowPreviewButton() && (
                <div className="card flex justify-content-center">
                    {isBothDecideLater ? (
                        <Dropdown
                            options={[
                                {
                                    label: t('SUMMARY.UP_NATIONAL_VALIDATIONS'),
                                    value: 'preview',
                                    isUp: true
                                },
                                {
                                    label: t('SUMMARY.NATIONAL_VALIDATION_ONLY'),
                                    value: 'download',
                                    isUp: false
                                }
                            ]}
                            itemTemplate={(option) => (
                                <button>
                                    <i
                                        className={`pi pi-file-pdf pr-1.5 ${option.isUp ? 'text-primary' : 'text-warning-200'}`}></i>
                                    {option.label}
                                </button>
                            )}
                            value={null}
                            optionValue="isUp"
                            onChange={(e) => {
                                const selectedOption = e.value;
                                downloadPDF(selectedOption ? 'EP' : 'Non-UP');
                            }}
                            placeholder={t('COMMON.PREVIEW')}
                            pt={{
                                ...dropDownStyle,
                                root: {
                                    className: `${dropDownStyle.root.className} h-[2.40rem] border-primary`
                                },
                                input: {
                                    className: `${dropDownStyle.input.className} text-primary`
                                },
                                panel: {
                                    className: `${dropDownStyle.panel.className} rounded-md`
                                },
                                item: {
                                    className: `${dropDownStyle.item.className} bg-white`
                                }
                            }}
                            dropdownIcon="pi pi-angle-up text-primary before:!font-normal"
                            collapseIcon="pi pi-angle-up text-primary before:!font-normal"
                        />
                    ) : (
                        <button
                            className="btn button-primary-outline min-h-[2.40rem] h-[2.40rem] !font-medium !transform-none"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="preview-pdf"
                            onClick={() => {
                                downloadPDF();
                            }}>
                            {t('COMMON.PREVIEW')}
                        </button>
                    )}
                </div>
            )}

            {/* button - save-quote (buttons-group) */}
            {isShowSplitButton() && (
                <div className="card flex justify-content-center">
                    <SplitButton
                        onClick={() => {
                            setUserTriggerThisQuoteToSaveOrApprove(SAVE_APPROVE_BOOL.SAVE);
                            setFileExportType(null); // set null to normalize the state
                            pageNavigation({
                                wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.SAVE,
                                userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.SAVE,
                                fileExportType: null, // default value
                                triggerSuccessToastAndNavigateToListing: false
                            });
                        }}
                        data-testid="save-quote"
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        model={getSplitButtonItems()}
                        buttonClassName="!bg-primary !hover:bg-primary-100 !font-medium h-[2.40rem] !focus:outline-none !focus:shadow-none text-white"
                        menuButtonClassName="!bg-primary !hover:bg-primary-100 border-l border-l-white hover:border-l-white h-[2.40rem] !font-medium !focus:outline-none !focus:shadow-none !focus:shadow-transparent text-white"
                        icon={<p className="font-medium">{t(buttonLabel())}</p>}
                        dropdownIcon="pi pi-bars"
                        disabled={!isDisableNextButton}
                        appendTo={'self'}
                        severity="contrast"
                        menuStyle={{ whiteSpace: 'nowrap' }}
                    />
                </div>
            )}

            {/* button - view summary */}
            <div
                className={`${isLastPage && isBothDecideLater && isEP && pathname.includes(PATHS.SUMMARY) ? 'continue-submit-button' : ''}`}>
                {isLastPage && pathname.includes(PATHS.SUMMARY) && (
                    <Tooltip
                        target=".continue-submit-button"
                        position="left"
                        className="custom-tooltip"
                        pt={tooltipStyle}
                        content={
                            isBothDecideLater
                                ? t('QUOTE_AND_ORDER.BOTH_DECIDE_APPROVE_TOOLTIP')
                                : ''
                        }
                    />
                )}
                <button
                    onClick={() => {
                        isLastPage &&
                            setUserTriggerThisQuoteToSaveOrApprove(SAVE_APPROVE_BOOL.APPROVE);
                        setFileExportType(null); // set null to normalize the state
                        pageNavigation({
                            wantThisQuoteToSaveOrApprove: SAVE_APPROVE_NUM.SAVE,
                            userTriggerThisQuoteToSaveOrApprove: SAVE_APPROVE_BOOL.APPROVE,
                            fileExportType: null, // default value
                            triggerSuccessToastAndNavigateToListing: false
                        });
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    data-testid="continue"
                    disabled={isDisabledApproveButton()}
                    className="btn button-primary font-medium rounded-md min-h-10 h-10">
                    <span className="font-medium">{t(getPrimaryButtonLabel())}</span>
                    {!isLastPage && <i className="pi pi-chevron-right"></i>}
                </button>
            </div>
        </div>
    );
};

export default PrimaryButtons;
