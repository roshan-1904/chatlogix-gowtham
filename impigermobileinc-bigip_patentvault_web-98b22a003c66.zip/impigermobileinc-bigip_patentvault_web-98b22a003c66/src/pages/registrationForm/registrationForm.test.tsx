import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import RegistrationForm from './registrationForm';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import { collaboratePartnerWithUs } from './services/registrationFormService';
import NotificationStore from 'core/store/notificationStore/notificationStore';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div>Mocked Form</div>)
}));
jest.mock('core/store/formIoStore/formIoStore', () => ({
    getFormData: jest.fn(() => ({})),
    updateFormData: jest.fn(),
    subscribe: jest.fn()
}));
jest.mock('./services/registrationFormService', () => ({
    collaboratePartnerWithUs: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    __esModule: true,
    default: {
        init: jest.fn(),
        subscribe: jest.fn(),
        showAlert: jest.fn(),
        initialState: { data: null, hasError: true }
    }
}));
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

describe('RegistrationForm', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should render the RegistrationForm component', () => {
        render(
            <Router>
                <RegistrationForm />
            </Router>
        );
        waitFor(() => {
            expect(
                screen.getByText('COMMON.REGISTRATION_FORM.COLLABORATE_OR_PARTNER_WITH_US')
            ).toBeInTheDocument();
            expect(screen.getByText('Mocked Form')).toBeInTheDocument();
        });
    });

    it('should call handleRegistration when submit button is clicked', () => {
        render(
            <Router>
                <RegistrationForm />
            </Router>
        );

        const submitButton = screen.getByTestId('registration-btn');
        fireEvent.click(submitButton);

        waitFor(() => {
            expect(
                document.getElementById('submit-registration-form')?.click
            ).toHaveBeenCalledTimes(1);
        });
    });

    it('should handle form changes correctly', () => {
        const mockUpdateFormData = jest.spyOn(formStatusStore, 'updateFormData');
        // const mockFormChange = jest.fn();

        render(
            <Router>
                <RegistrationForm />
            </Router>
        );
        waitFor(() => {
            fireEvent.change(screen.getByText('Mocked Form'), {
                target: { value: 'new data' }
            });

            expect(mockUpdateFormData).toHaveBeenCalled();
        });
    });

    it('should handle successful form submission', () => {
        (collaboratePartnerWithUs as jest.Mock).mockResolvedValueOnce(true);
        const showAlertMock = jest.spyOn(NotificationStore, 'showAlert');

        render(
            <Router>
                <RegistrationForm />
            </Router>
        );

        const formProps = {
            data: {
                firstName: 'John',
                lastName: 'Doe',
                email: 'john@example.com',
                phoneNumber: '123456789'
            }
        };

        waitFor(() => {
            const formElement = screen.getByText('Mocked Form');
            fireEvent.submit(formElement, { data: formProps });
            expect(collaboratePartnerWithUs).toHaveBeenCalledWith({
                firstName: 'John',
                middleName: '',
                lastName: 'Doe',
                email: 'john@example.com',
                phoneNumber: '123456789',
                company: undefined,
                hearAboutUs: undefined,
                country: undefined,
                notes: undefined,
                services: undefined
            });
            expect(showAlertMock).toHaveBeenCalledWith({
                type: 'success',
                message: 'COMMON.REGISTRATION_FORM.REGISTRATION_SUCCESSFUL'
            });
        });
    });

    it('should handle form submission failure', () => {
        (collaboratePartnerWithUs as jest.Mock).mockRejectedValueOnce(
            new Error('Submission Failed')
        );
        const showAlertMock = jest.spyOn(NotificationStore, 'showAlert');

        render(
            <Router>
                <RegistrationForm />
            </Router>
        );

        waitFor(() => {
            const formElement = screen.getByText('Mocked Form');
            fireEvent.submit(formElement);
            expect(showAlertMock).toHaveBeenCalledWith({
                type: 'error',
                message: 'COMMON.REGISTRATION_FORM.REGISTER_FAILED'
            });
        });
    });
});
