import { collaboratePartnerWithUs } from '../services/registrationFormService';
import HttpService from 'core/interceptor/api.handler';
import { RegisterFormPayload } from '../types/registrationForm.types';
import { END_POINT } from 'constants/endPoint';

jest.mock('core/interceptor/api.handler');

const mockedHttpService = HttpService as jest.MockedClass<typeof HttpService>;

describe('collaboratePartnerWithUs', () => {
    const requestBody: RegisterFormPayload = {
        firstName: 'John',
        middleName: 'Michael',
        lastName: 'Doe',
        email: 'johndoe@example.com',
        phoneNumber: '9876543210',
        company: 'Example Corp',
        hearAboutUs: 'Social Media',
        country: 'India',
        notes: 'Looking forward to partnering with you.',
        services: 'I am a company that needs translation/filing services'
    };

    const apiUrl = `${END_POINT.USER_REGISTRATION}`;

    beforeEach(() => {
        mockedHttpService.mockClear();
    });

    it('should successfully submit registration form', async () => {
        const mockResponse = { success: true };
        mockedHttpService.prototype.post.mockResolvedValue(mockResponse);

        const result = await collaboratePartnerWithUs<typeof mockResponse>(requestBody);

        expect(mockedHttpService.prototype.post).toHaveBeenCalledWith(apiUrl, requestBody);
        expect(result).toEqual(mockResponse);
    });

    it('should handle errors during registration form submission', async () => {
        const mockError = new Error('Network Error');
        mockedHttpService.prototype.post.mockRejectedValue(mockError);

        await expect(collaboratePartnerWithUs(requestBody)).rejects.toThrow(mockError);
        expect(mockedHttpService.prototype.post).toHaveBeenCalledWith(apiUrl, requestBody);
    });
});
