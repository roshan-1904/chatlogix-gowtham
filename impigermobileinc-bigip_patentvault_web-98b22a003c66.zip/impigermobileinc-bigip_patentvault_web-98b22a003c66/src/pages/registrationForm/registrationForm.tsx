import { Form } from '@formio/react';
import HttpService from 'core/interceptor/api.handler';
import { focusOnFirstError } from 'core/utils/utils';
import RegistrationFormBuilderData from './data/registrationForm.json';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { RegisterFormPayload, RegistrationFormData } from './types/registrationForm.types';
import { collaboratePartnerWithUs } from './services/registrationFormService';
import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';
import ToastAlert from 'components/toast/toastAlert';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';

export default function RegistrationForm() {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(
        RegistrationFormBuilderData
    );
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());
    formStatusStore.subscribe(setFormState);

    const handleRegistration = async () => {
        document.getElementById('submit-registration-form')?.click();
        await new Promise((r) => setTimeout(r, 100));
    };

    const onFormChange = (e: any) => {
        if (e.changed) {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    const handleCollaboratePartnerWithUs = async (requestBody: RegisterFormPayload) => {
        try {
            const response = await collaboratePartnerWithUs(requestBody);
            if (response) {
                NotificationStore.showAlert({
                    type: ToastType.SUCCESS,
                    message: t('COMMON.REGISTRATION_FORM.REGISTRATION_SUCCESSFUL')
                });
                setTimeout(() => {
                    navigate(`/${PATHS.LOGIN}`);
                }, 2000);
            }
        } catch (error) {
            NotificationStore.showAlert({
                type: ToastType.ERROR,
                message: t('COMMON.REGISTRATION_FORM.REGISTER_FAILED')
            });
            console.error('Error while submitting registration form:', error);
        }
    };

    const onSubmitChange = async (e: any) => {
        const updatedFormData = e?.data as RegistrationFormData;
        await handleCollaboratePartnerWithUs({
            firstName: updatedFormData?.firstName || '',
            middleName: updatedFormData?.middleName || '',
            lastName: updatedFormData?.lastName || '',
            email: updatedFormData?.email || '',
            phoneNumber: updatedFormData?.phoneNumber || '',
            company: updatedFormData?.company,
            hearAboutUs: updatedFormData?.hearAboutUs,
            country: updatedFormData?.country?.name,
            notes: updatedFormData?.notes,
            services: updatedFormData?.services
        });
    };
    return (
        <div id="wrapper" className="registration-form lg:h-screen">
            <div>
                <ToastAlert />
            </div>
            <div className="lg:flex h-full">
                <div
                    className="w-full h-full lg:flex overflow-hidden justify-center items-center p-4 py-6 relative loginBg"
                    style={{
                        background:
                            'url(https://bltestb2ccustom.blob.core.windows.net/customb2c/src/images/login_background.jpg)',
                        backgroundRepeat: 'no-repeat, no-repeat',
                        backgroundPosition: 'center center, center center',
                        backgroundSize: 'cover, cover'
                    }}>
                    <div className="lg:w-10/12 max-h-[calc(100vh-80px)]">
                        <div className="w-3/12">
                            <img
                                src="https://bltestb2ccustom.blob.core.windows.net/customb2c/src/images/bigLanguageLogo_white.png"
                                alt="organization logo"
                            />
                        </div>
                        <h3 className="text-white my-8 font-medium">
                            {t('COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.WELCOME')}
                        </h3>
                        <div className="grid gap-8 text-white mt-9 text-xl pb-10">
                            <p>{t('COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.DESCRIPTION')}</p>
                            <p>
                                <span className="font-medium block text-[20px] py-3">
                                    {t(
                                        'COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.INTERESTED_IN_FIXED_RATE_FILING'
                                    )}
                                </span>
                                {t(
                                    'COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.FIXED_RATE_DESCRIPTION'
                                )}
                            </p>
                            <div>
                                <span className="font-medium block text-[20px] py-3">
                                    {t('COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.NEED_HELP')}
                                </span>
                                <div className="lg:flex h-full w-full">
                                    <div className="flex items-center">
                                        <img
                                            className="w-8 pr-3"
                                            src="https://bltestb2ccustom.blob.core.windows.net/customb2c/src/images/icon_email.svg"
                                            alt="Email"
                                        />
                                        <a href="mailto:request@big-ip.com">
                                            {'request@big-ip.com'}
                                        </a>
                                    </div>
                                    <div className="lg:ml-10 flex items-center">
                                        <img
                                            className="w-8 pr-3"
                                            src="https://bltestb2ccustom.blob.core.windows.net/customb2c/src/images/icon_phone.svg"
                                            alt="Phone"
                                        />
                                        <a href="tel:+1.646.357.3972">{'+1.646.357.3972'}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p className="absolute copyright text-center !text-sm w-full !text-white pt-6 bottom-7 origin-center left-[50%] translate-x-[-50%]">
                            {`© ${t('COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.COPYRIGHT')}`}{' '}
                            <span id="copyright">{new Date().getFullYear()}</span>{' '}
                            {t('COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.ALL_RIGHTS_RESERVED')}
                        </p>
                    </div>
                </div>
                <div className="w-full h-full z-10 flex justify-center items-center max-h-[calc(100vh)] overflow-auto registration-form-container">
                    <div
                        className="w-full flex flex-col justify-start 3xl:justify-center items-center lg:w-8/12 h-full justify-items-start p-5 pt-10"
                        data-testid="registration-form-fields">
                        <h1 className="text-left pb-2 self-start font-medium text-[24px] leading-[29px] font-barlow tracking-normal text-black">
                            {t('COMMON.REGISTRATION_FORM.COLLABORATE_OR_PARTNER_WITH_US')}
                        </h1>
                        <div className="mt-4 w-full">
                            <Form
                                form={formBuilderData}
                                submission={{ data: formState?.data }}
                                onChange={(e: any) => onFormChange(e)}
                                onSubmit={(e: any) => onSubmitChange(e)}
                                onError={focusOnFirstError}
                            />
                        </div>
                        <div>
                            <button
                                data-testid="registration-btn"
                                className="text-center font-medium justify-self-center text-[16px] leading-[19px] font-barlow tracking-normal text-white w-[380px] h-[52px] bg-primary rounded-[10px] mt-8"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    handleRegistration().catch(console.error);
                                }}>
                                {t('COMMON.REGISTRATION_FORM.SUBMIT_REQUEST')}
                            </button>
                        </div>
                        <div className="justify-self-center my-8">
                            <span className="text-left font-normal text-[15px] leading-[18px] font-barlow tracking-normal text-neutral-700">
                                {`${t(
                                    'COMMON.REGISTRATION_FORM.BIGIP_BANNER_CONTENT.ALREADY_HAVE_AN_ACCOUNT'
                                )}?`}{' '}
                                <a
                                    href="login"
                                    data-testid="login-btn"
                                    className="text-left underline font-medium text-[15px] leading-[18px] font-barlow tracking-normal text-primary">
                                    {t('COMMON.LOGIN')}
                                </a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
