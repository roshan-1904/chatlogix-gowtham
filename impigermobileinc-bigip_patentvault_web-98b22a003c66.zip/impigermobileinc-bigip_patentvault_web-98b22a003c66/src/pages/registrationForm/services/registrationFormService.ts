import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { RegisterFormPayload } from '../types/registrationForm.types';

const baseURL: string | undefined = process.env.REACT_APP_API_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

/**
 * Used to collaborate/partner with us.
 * @param requestBody
 */
export const collaboratePartnerWithUs = async <T>(requestBody: RegisterFormPayload): Promise<T> => {
    const apiUrl = `${END_POINT.USER_REGISTRATION}`;
    try {
        const response = await httpService.post<T, RegisterFormPayload>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error while collaborating/partnering:', error);
        throw error;
    }
};
