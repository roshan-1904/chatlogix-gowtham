export interface RegistrationFormData {
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    company: string;
    hearAboutUs: string;
    country: {
        id: number;
        name: string;
        code: string;
        iconName: string;
        countryNameCode: string;
        latitude: string;
        longitude: string;
    };
    notes: string;
    services: string;
}

export type RegisterFormPayload = Omit<RegistrationFormData, 'country'> & {
    country: string;
};
