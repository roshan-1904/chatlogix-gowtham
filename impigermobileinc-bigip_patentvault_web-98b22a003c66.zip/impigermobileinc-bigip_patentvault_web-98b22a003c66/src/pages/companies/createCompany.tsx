import { useEffect, useState } from 'react';
import { Outlet, useLocation, useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import ProgressStepper from 'pages/components/progressStepper/progressStepper';
import { PATHS } from 'constants/routes.constant';
import {
    COMPANY_PATHS_FOR_STEPPER,
    COMPANY_STEPPER_DATA,
    CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY
} from './constants/companyStepper.constant';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { CreateCompanyPayloadType } from './types/createCompany.types';
import companiesService from './service/companies.service';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import { STEPPER_STATE } from 'pages/components/progressStepper/types/progressStepper.type';
import StepperButtons from 'components/stepper/stepperButtons/stepperButtons';
import { Step } from 'components/stepper/stepperButtons/stepperButton.types';
import StepperNavigation from 'components/stepper/stepperNavigation/StepperNavigation';
import {
    generateFormData,
    buildCompanyData,
    redirectToNextPage,
    getHeaderTitleAndStepButtons
} from './utils/createCompanyUtils';
import CompanyLookupPopupModel from 'pages/companies/companySteppers/companyLookupPopupModel';
import { handleEditClick, handleStepperUpdate } from 'pages/users/utils/vendorUserUtils';
import { useDebouncedWaitCallback } from 'core/utils/utils';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';

const CreateCompany = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: 'Confirmation',
        description: t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')
    });
    const location = useLocation();
    const { pathname } = location;
    const { company_id } = useParams();
    const isFromEdit: boolean = pathname?.includes('edit');
    const isFromView: boolean = pathname?.includes('view');
    const { headerTitle, stepButtonArray: buttonArray } = getHeaderTitleAndStepButtons(
        t,
        isFromEdit,
        isFromView,
        companyStepperStore.getData()?.stepperInfo?.name ?? ''
    );
    const [stepButtonArray, setStepButtonArray] = useState<Step[]>(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        buttonArray ?? CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY
    );
    const [isLoaded, setIsLoaded] = useState(true);
    // back button
    const handleConfirm = () => {
        // reset the store, when user click this back button
        stepperStore.resetStepperStore();
        companyStepperStore.resetStepperModuleStore();

        navigate(`/${PATHS.COMPANIES}`);
    };

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleBackToListingPage = () => {
        if (isFromView) {
            handleConfirm();
        } else {
            setShowPopup({ ...showPopup, visible: true });
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    useEffect(() => {
        const fetchCompanyData = async () => {
            try {
                if (!company_id) {
                    throw new Error('Company ID is missing! Please check your URL.');
                }
                const companyId = parseInt(company_id.replace(/\D/g, ''), 10);
                if (isNaN(companyId)) {
                    throw new Error('Invalid company ID! Please check your URL.');
                }
                const response =
                    await companiesService.getCompanyById<CreateCompanyPayloadType>(companyId);
                if (response) {
                    // Assuming you have a function to update the store with company data
                    setIsLoaded(true);
                    companyStepperStore.updatePage('stepperInfo', {
                        primaryId: companyId,
                        documentId: response?.documentId ?? null,
                        userType: null,
                        name: response?.name ?? ''
                    });
                    if (!isFromView) {
                        const { country, state } = await companiesService.getCountryAndState(
                            response.mailingAddress.countryId,
                            response.mailingAddress.stateId
                        );
                        generateFormData({ ...response, ['id']: companyId }, country, state);
                    } else {
                        generateFormData(
                            { ...response, ['id']: companyId },
                            response.mailingAddress.country,
                            response.mailingAddress.state
                        );
                    }
                }
            } catch (error) {
                console.error('Error fetching company data:', error);
            }
        };
        // Call the fetchCompanyData function when the component mounts
        if (company_id) {
            fetchCompanyData();
            setIsLoaded(false);
            navigate(pathname);
        }
    }, [company_id]); // Execute the effect whenever company_id changes

    // redirection while hard refresh
    useEffect(() => {
        handleStepperUpdate(
            company_id,
            pathname,
            COMPANY_PATHS_FOR_STEPPER,
            COMPANY_STEPPER_DATA,
            stepperStore
        );
    }, []);

    const createCompany = async (
        companyData: CreateCompanyPayloadType,
        isNavigate: boolean = false,
        hideLoader = false
    ) => {
        try {
            const response = await companiesService.createCompany<CreateCompanyPayloadType>(
                companyData,
                hideLoader
            );
            if (response) {
                // Optionally handle response data if needed
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('COMPANIES.SUCCESS_MESSAGE.COMPANY_CREATED_SUCCESSFULLY')
                });
                if (isNavigate) {
                    stepperStore.resetStepperStore();
                    companyStepperStore.resetStepperModuleStore();
                    navigate(`/${PATHS.COMPANIES}`);
                    // Optionally perform any additional actions after successful creation
                } else {
                    return response;
                }
            }
        } catch (error) {
            console.error('Error creating company:', error);
            throw error;
        }
    };
    const updateCompany = async (
        companyId: number,
        companyData: CreateCompanyPayloadType,
        isNavigation = false,
        hideLoader = false
    ) => {
        try {
            const response = await companiesService.updateCompany<CreateCompanyPayloadType>(
                companyId,
                companyData,
                hideLoader
            );
            if (response) {
                // Optionally handle response data if needed
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('COMPANIES.UPDATE_MESSAGE.COMPANY_UPDATED_SUCCESSFULLY')
                });

                if (isNavigation) {
                    stepperStore.resetStepperStore();
                    companyStepperStore.resetStepperModuleStore();
                    navigate(`/${PATHS.COMPANIES}`);
                    // Optionally perform any additional actions after successful creation
                } else {
                    return response;
                }
            }
        } catch (error) {
            console.error('Error creating company:', error);
            throw error;
        }
    };

    const onHandleSaveDraft = async (isNavigate: boolean = false, stepperState?: STEPPER_STATE) => {
        try {
            const data = companyStepperStore.getData();
            // Extract relevant information to create user data
            const { formData, stepperInfo } = data;

            const { companyProfilePage, billingInfoPage } = formData;

            if (!companyProfilePage && !billingInfoPage) {
                throw new Error('Company Profile && BillingInfo Page data is missing.');
            }

            const primaryId: number = stepperInfo?.primaryId ? stepperInfo.primaryId : 0;
            const companyData: CreateCompanyPayloadType = await buildCompanyData(formData);
            if (primaryId !== 0) {
                const response = await updateCompany(primaryId, companyData, isNavigate, true);
                if (!isNavigate) {
                    if (response) {
                        companyStepperStore.updatePage('stepperInfo', {
                            primaryId,
                            documentId: response?.documentId ?? null,
                            userType: null
                        });
                        if (stepperState) redirectToNextPage(stepperState);
                    }
                }
            } else {
                const response = (await createCompany(companyData, isNavigate, true)) ?? undefined;
                if (!isNavigate) {
                    if (response) {
                        companyStepperStore.updatePage('stepperInfo', {
                            primaryId: response.id,
                            documentId: response?.documentId ?? null,
                            userType: null
                        });
                        const dynamicButtonData = getHeaderTitleAndStepButtons(
                            t,
                            response.id !== 0,
                            isFromView,
                            companyStepperStore.getData()?.stepperInfo?.name ?? ''
                        );
                        setStepButtonArray(dynamicButtonData.stepButtonArray);
                        if (stepperState) redirectToNextPage(stepperState);
                    }
                }
            }
        } catch (error) {
            console.error('Error in onHandleSaveDraft:', error);
        }
    };
    const onClickPrimaryValidation = async (stepperState?: STEPPER_STATE) => {
        try {
            const data = companyStepperStore.getData();
            const { formData, stepperInfo } = data;
            const { companyProfilePage } = formData;

            if (!companyProfilePage) {
                throw new Error('Company Profile  data is missing.');
            }

            const companyName: string = companyProfilePage.container?.name;
            if (!companyName) {
                throw new Error('Company Name is missing.');
            }
            const primaryId: number = stepperInfo?.primaryId ? stepperInfo?.primaryId : 0;
            if (primaryId !== 0) {
                if (stepperState) redirectToNextPage(stepperState);
                return;
            } else if (companyName.trim().length > 2) {
                const response = await companiesService.checkExistingCompany(companyName);
                if (!response) {
                    showToastMessage({
                        type: ToastType.ERROR,
                        message: t('COMPANIES.COMPANY_PROFILE.COMPANY_ALREADY_EXISTS')
                    });
                } else if (stepperState) {
                    redirectToNextPage(stepperState);
                }
            }
        } catch (error) {
            console.error('Error in onClickPrimaryValidation:', error);
        }
    };

    const debouncedHandleSaveDraft = useDebouncedWaitCallback(
        (isNavigate: boolean = false, stepperState?: STEPPER_STATE) => {
            onHandleSaveDraft(isNavigate, stepperState);
        },
        800
    );
    return (
        <div data-testid="CreateCompany">
            <StepperNavigation
                popupId={'createCompanyPopup'}
                visible={showPopup.visible}
                onConfirm={handleConfirm} // Pass the confirmation handler
                onCancel={handleCancel} // Pass the cancellation handler
                onKeyDown={handleBackToListingPage} // Pass the onKeyDown handler
                showEdit={isFromView && AuthStore.hasPermission(Permissions.EDIT_COMPANIES)}
                onClickEdit={() =>
                    handleEditClick(
                        pathname,
                        COMPANY_PATHS_FOR_STEPPER,
                        COMPANY_STEPPER_DATA,
                        stepperStore,
                        `/${PATHS.COMPANIES}/${PATHS.EDIT}/${company_id}`
                    )
                }
                steps={[
                    {
                        label: t('COMMON.COMPANIES'),
                        isCurrent: false,
                        isPrevious: true
                    },
                    {
                        labelName: t('COMMON.COMPANY'),
                        label: headerTitle,
                        isCurrent: true,
                        isPrevious: false,
                        module: 'COMPANY'
                    }
                ]}
            />

            <div className="lg:flex bg-neutral-100/5 w-full">
                <div className="lg:w-1/5 p-3 pb-0 md:p-4 md:px-5 md:h-full progressStepperHeight">
                    <ProgressStepper
                        pathsForStepper={COMPANY_PATHS_FOR_STEPPER}
                        stepperModuleStore={companyStepperStore}
                    />
                </div>
                {isLoaded && (
                    <div className={`w-full h-full lg:max-w-[calc(100vw-270px)]`}>
                        <div className="border border-neutral-100/50 m-2 md:m-3 rounded-md md:rounded-lg md:mb-0 border-b-0 md:rounded-b-none h-[calc(100vh-170px)] 2xl:h-[calc(100vh-164px)] 4xl:h-[calc(100vh-188px)]">
                            <div className="createOrderQuoteSelection" id="scrollTarget">
                                <Outlet />
                                <CompanyLookupPopupModel />
                            </div>
                        </div>

                        <StepperButtons
                            steps={stepButtonArray}
                            stepperModuleStore={companyStepperStore}
                            saveDraft={(stepperState: STEPPER_STATE) => {
                                debouncedHandleSaveDraft(false, stepperState);
                            }}
                            onUpdate={() => {
                                debouncedHandleSaveDraft(true);
                            }}
                            onCreate={() => {
                                debouncedHandleSaveDraft(true);
                            }}
                            onBackToList={() => {
                                navigate(`/${PATHS.COMPANIES}`);
                            }}
                            checkPrimaryValidation={(stepperState: STEPPER_STATE) => {
                                onClickPrimaryValidation(stepperState);
                            }}
                        />
                    </div>
                )}
            </div>
        </div>
    );
};

export default CreateCompany;
