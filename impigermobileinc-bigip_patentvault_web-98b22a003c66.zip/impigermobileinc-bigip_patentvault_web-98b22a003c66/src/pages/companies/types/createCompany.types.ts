import { filterRequestModelType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { stepperMode } from 'pages/users/constant/user.constant';
export interface MailingAddress {
    address1: string;
    address2: string;
    city: string;
    state: string;
    stateId: number;
    country: string;
    countryId: number;
    zip: string;
    billingEmail: string;
    ccRecipients?: string;
    isSameAddress?: boolean;
}

export interface ContactDetails {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    roleId: number;
}

export interface CreateCompanyPayloadType {
    id?: number;
    name: string;
    companyType: number;
    parentCompanyName: string;
    sageParentId: string | null;
    companyStatus: string;
    customerTierLevel?: string;
    parentCompanyId?: any;
    serviceAgreement?: boolean;
    website?: string;
    primaryPhoneNumber?: string;
    salesRepId?: number | null;
    companyNotes?: string;
    billingTermsId?: number | null;
    paymentTypeId?: number | null;
    currencyId: number | null;
    grossProfit?: number;
    isAccountOnHold?: boolean;
    rateId?: number;
    accountHoldReasonNotes?: string;
    billingNotes?: string;
    mailingAddress: MailingAddress;
    contactDetails: ContactDetails[];
    documentId?: number | null;
    billingPeriodId?: number | null;
    billingTypeId?: number | null;
    isPoRequired?: boolean;
    invoiceMode?: string;
    invoiceDeliveryStatement?: string;
    industryId?: number | null;
    isAgreeTMDiscounts?: boolean;
    ccRecipients?: string;
    serviceAgreementStartDate?: string | null;
    serviceAgreementEndDate?: string | null;
    vatRegistrationNumber?: string | null;
}

export interface requestCurrencyResponseType {
    name: string;
    isoCode: string;
    currencySymbol: string;
    currencyId: number;
    concatNameCode: string;
    id: number;
}

export interface dropdownValuesType {
    label: string;
    value: number;
}

export interface CompanyRatesResponseType {
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    targetLanguageId: number;
    filterRequestModel: filterRequestModelType;
    companyId?: number;
}

export interface CompanyTranslationsResponseType {
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    targetLanguageId: number;
    filterRequestModel: filterRequestModelType;
}

export interface companyFeeResponseType {
    id: number;
    companyTranslationFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
    companyOfficialFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
    companyAgencyFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
}

export interface preferredCurrencyResponse {
    currencyCode: string;
    currencyId: number;
    currencyName: string;
    isPreferredCurrency: boolean;
    currencySymbol: string;
}

export interface SageCompanyFilterQueryParams {
    filterQuery?: string;
}

export interface SageCompanyDetails {
    modeOfInvoicing?: string | null;
    billingPeriod?: string;
    billingType?: string | undefined | null;
    poRequired?: string;
    isAgreeTMDiscounts?: boolean;
    industry?: string;
    industryId?: number | null;
    companyNotes?: string | null;
    website?: string | null;
    serviceAgreement?: boolean;
    companyId?: string;
    companyName?: string;
    entityId?: string;
    isParentCompany?: boolean;
    name?: string | null;
    companyTypeName?: string | null;
    companyType?: number;
    parentCompanyName?: string;
    companyStatus?: string;
    customerTierLevel?: string | null;
    primaryPhoneNumber?: string;
    salesRepName?: string;
    city?: string;
    state?: string;
    country?: string;
    billingEmail?: string;
    status: null;
    address1: string;
    address2: string;
    zip: null;
    billingTerms: '';
    formofPayment?: string | null;
    isAccountHoldStatus?: string | null;
    preferredCurrency?: string | null;
    grossProfit: number | null;
    isAccountOnHold?: boolean;
    billingNotes?: string | null;
    accountHoldReasonNotes?: string | null;
    billingEmailCc?: string | null;
    invoiceDeliveryStatement?: string | null;
    billingEmailTo?: string;
}

export interface Country {
    id: number;
    name: string;
    code: string;
    iconName: string;
    countryNameCode: string;
    latitude: string;
    longitude: string;
}
export interface State {
    id: number;
    name: string;
    code: string;
}

export interface CreateContactModal {
    mode: stepperMode;
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    company: string;
    role: string;
    projectManagers: number[];
    comments: string | null;
    mainphone: string;
    officePhone: string | null;
    extension: number | null;
    salesRep: string;
    linkedInUrl: string | null;
    mobilePhone: number | null;
    homePhone: number | null;
    address1: string;
    address2: string | null;
    city: string;
    state: State | null;
    country: Country | null;
    zip: string;
    billingEmail: string;
    billingEmailCC: string | null;
    baddress1: string;
    baddress2: string | null;
    bcity: string;
    bstate: State | null;
    bcountry: Country | null;
    bzip: string;
    sameAsMailing: boolean;
}
