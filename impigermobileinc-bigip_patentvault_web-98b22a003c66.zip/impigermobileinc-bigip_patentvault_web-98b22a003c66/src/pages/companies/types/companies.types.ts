import { Country, State } from './createCompany.types';

export interface CompaniesTableSchema {
    id: number;
    formName: string;
    schema: string;
}
export interface ContactDetails {
    fullName: string;
    firstName: string;
    middleName: string;
    lastName: string;
}

export interface MailingAddress {
    address1: string;
    address2: string;
    city: string;
    state: string;
    country: string;
    zip: string;
}
export interface CompaniesDataItem {
    sageSyncDetails: string;
    id: number;
    billingNotes: string;
    billingTerms: string;
    companyStatus: string;
    companyType: number;
    createdBy: string;
    customerTierLevel: string;
    grossProfit: number;
    isAccountOnHold: boolean;
    isAccountHoldStatus: string;
    isActive: boolean;
    active: string;
    formofPayment: string;
    preferredCurrencies: string | null;
    address1: string;
    address2: string;
    city: string;
    state: string;
    country: string;
    zip: string;
    billingEmail: string;
    name: string;
    parentCompanyName: string | null;
    primaryPhoneNumber: string;
    salesRepName: string;
    updatedAt: string;
    accountHoldReasonNotes: string;
    updatedBy: string;
    createdAt: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
    sageStatusSyncName?: string;
}

export interface GetCompaniesListApiResponse {
    companyServiceModel: CompaniesDataItem[];
    totalRecords: number;
}

export interface CompanyProfileDetails {
    name: string;
    companyType: number;
    companyStatus: string;
    customerTierLevel?: string;
    parentCompanyName: any;
    serviceAgreement?: string;
    website?: string;
    primaryPhoneNumber?: string;
    salesRepId?: number | null;
    notes?: string;
    id?: number;
    industryId?: number;
    isAgreeTMDiscounts?: string;
    container: {
        name: string;
    };
    serviceAgreementStartDate?: string | null;
    serviceAgreementEndDate?: string | null;
}
export interface BillingInfoDetails {
    billingTermsId?: number | null;
    paymentTypeId?: number | null;
    currencyId: number | null;
    grossProfit?: number;
    accountOnHold?: string;
    rate?: {
        id?: number;
    };
    reason?: string;
    billingNotes?: string;
    address1?: string;
    address2?: string;
    city?: string;
    state?: State;
    country?: Country;
    zip?: string;
    billingEmail?: string;
    billingPeriodId?: number | null;
    billingTypeId?: number | null;
    isPoRequired?: string;
    invoiceMode?: string;
    ccRecipients?: string;
    invoiceDeliveryStatement?: string;
    cc?: string;
    vatRegistrationNumber?: string | null;
}

export interface BalanceInfo {
    customerId: string;
    totalDue: number;
    totalInvoiceBalance: number;
    totalCreditAdjustmentsBalance: number;
    totalDebitAdjustmentsBalance: number;
    totalAdvancesBalance: number;
}
