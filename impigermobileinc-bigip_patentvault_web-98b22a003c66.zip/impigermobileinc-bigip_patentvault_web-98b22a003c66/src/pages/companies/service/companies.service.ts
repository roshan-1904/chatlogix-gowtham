import { END_POINT } from '../../../constants/endPoint';
import HttpService from '../../../core/interceptor/api.handler';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import {
    CompanyRatesResponseType,
    Country,
    CreateCompanyPayloadType,
    SageCompanyFilterQueryParams,
    State,
    companyFeeResponseType
} from '../types/createCompany.types';
import { PV_SETTINGS_RATES } from 'pages/pvsettings/subaccordions/rates/rates.const';
import { CompanyTranslationFormulaUpdate } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { BalanceInfo } from '../types/companies.types';

// Define the base URL from environment variable
const _httpService = new HttpService();

/**
 * Fetch table data based on the given page type and request body.

 * @param {RequestBody} requestBody - The request body.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
const getTableData = async <T>(requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.GET_ALL_TABLE_DATA}`;

    try {
        const response = await _httpService.post<T, RequestBody>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Sends a PATCH request to update the status of a company.
 * @param companyId - The ID of the company to update.
 * @param isActive - The new status of the company (true for active, false for inactive).
 * @returns {Promise<T>} A promise resolving to the table data.
 */
const updateChangeStatus = async <T>(companyId: number, isActive: boolean): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.PATCH_ACTIVATE_STATUS}/${companyId}/${isActive}`;

    try {
        const response = await _httpService.patch<T, null>(apiUrl, null, {
            headers: {
                Accept: 'text/plain'
            }
        });
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Sends a POST request to create a new company.
 * @param company - The company data to be created.
 * @returns {Promise<T>} A promise resolving to the response data.
 */
const createCompany = async <T>(
    company: CreateCompanyPayloadType,
    hideLoader = false
): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}`;

    try {
        const response = await _httpService.post<T, CreateCompanyPayloadType>(apiUrl, company, {
            data: { hideLoader }
        });
        return response;
    } catch (error) {
        console.error('Error creating company:', error);
        throw error;
    }
};

/**
 * Sends a PUT request to update an existing company.
 * @param companyId - The ID of the company to update.
 * @param company - The updated company data.
 * @returns {Promise<T>} A promise resolving to the response data.
 */
const updateCompany = async <T>(
    companyId: number,
    company: CreateCompanyPayloadType,
    hideLoader = false
): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${companyId}`;

    try {
        if (company.id && companyId !== company.id) {
            throw new Error('Company ID mismatch, Reach out to support team.');
        }
        const response = await _httpService.update<T, CreateCompanyPayloadType>(apiUrl, company, {
            data: { hideLoader }
        });
        return response;
    } catch (error) {
        console.error(`Error updating company ${companyId}:`, error);
        throw error;
    }
};

/**
 * Sends a GET request to fetch company data by ID.
 * @param companyId - The ID of the company to retrieve.
 * @returns {Promise<T>} A promise resolving to the response data.
 */
const getCompanyById = async <T>(companyId: number): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_COMPANY_DETAILS}/${companyId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error(`Error fetching company ${companyId} data:`, error);
        throw error;
    }
};

/**
 * Get the source languages filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getSourceLanguages = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_SOURCE_LANGUAGES}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching source language', error);
        throw error;
    }
};

/**
 * Get the request currencies filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getRequestCurrencyData = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_CURRENCY}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching request currency data:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {IPRatesResponseType} requestBody - request body for post API type
 */

const getIPRequestData = async <T>(requestBody: CompanyRatesResponseType): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_COMPANY_RATES}`;
    try {
        const response = await _httpService.post<T, CompanyRatesResponseType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {companyFeeResponseType} requestBody - request body for post API type
 */

const updateFee = async <T>(requestBody: companyFeeResponseType): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.UPDATE_COMPANY_FEE}`;
    try {
        const response = await _httpService.patch<T, companyFeeResponseType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error updating fee details:', error);
        throw error;
    }
};

/**
 * Get the request currencies filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getPreferredCurrency = async <T>(companyId: any, activeTab: number): Promise<T> => {
    const patentServiceId: any = {
        0: PV_SETTINGS_RATES['pct'],
        2: PV_SETTINGS_RATES['ep'],
        4: PV_SETTINGS_RATES['pc']
    };
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY}/${companyId}/${patentServiceId[activeTab]}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching request currency data:', error);
        throw error;
    }
};

/**
 * Fetch Sage company listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {SageCompanyFilterQueryParams} queryParams -  for get API type
 */

const getSageCompanyList = async <T>(queryParams?: SageCompanyFilterQueryParams): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.SEARCH_SAGE_COMPANY_LIST}${queryParams?.filterQuery ? `?filterQuery=${queryParams.filterQuery}` : ''}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

/**
 * Fetch Parent company listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getParentCompanyList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.SEARCH_TOP_LEVEL_COMPANY_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Parent Company listing data:', error);
        throw error;
    }
};

interface GetParentCompanyListParams {
    limit?: number;
    skip?: number;
    filterQuery?: string;
}

const getParentCompanyId = async <T>(params: GetParentCompanyListParams = {}): Promise<T> => {
    const { limit = 100, skip = 0, filterQuery = '' } = params;
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.SEARCH_TOP_LEVEL_COMPANY_LIST}?limit=${limit}&skip=${skip}&filterQuery=${encodeURIComponent(filterQuery)}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Parent Company listing data:', error);
        throw error;
    }
};

/**
 * Fetch Payment type listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getPaymentTypeList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PAYMENT_TYPES_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Payment Type listing data:', error);
        throw error;
    }
};

/**
 * Fetch Sales Rep Name listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getSalesRepList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_SALES_REP_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Sales Rep listing data:', error);
        throw error;
    }
};

/**
 * Fetch Billing Terms listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getBillingTermsList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_TERMS_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching billing terms listing data:', error);
        throw error;
    }
};

/**
 * Fetch Industry listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getIndustryList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_INDUSTRIES_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

/**
 * Fetch Preferred Currency listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getPreferredCurrencyList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

/**
 * Fetch Billing Periods listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getBillingPeriodList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_PERIOD_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

/**
 * Fetch Country listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getCountryList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_COUNTRIES_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

/**
 * Fetch State listing  based on country id data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getStatesList = async <T>(countryId: number): Promise<T> => {
    const apiUrl = `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_STATES_LIST}/${countryId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};
const getCountryById = async (countryId: number = 0): Promise<Country | null> => {
    try {
        const countryList: Country[] = (await companiesService.getCountryList()) ?? [];
        if (countryList.length) {
            const country = countryList.find(
                (eachCountry: Country) => eachCountry.id === countryId
            );
            return country ?? null;
        }
        return null;
    } catch (error) {
        console.error('Error fetching Country listing data:', error);
        return null;
    }
};
async function getStateById(countryId: number, stateId: number): Promise<State | null> {
    try {
        const statesList: State[] = (await companiesService.getStatesList(countryId)) ?? [];
        if (statesList.length) {
            const state = statesList.find((eachState) => eachState.id === stateId);
            return state ?? null;
        }
        return null;
    } catch (error) {
        console.error('Error fetching State listing data:', error);
        return null;
    }
}
async function getCountryAndState(
    countryId?: number,
    stateId?: number
): Promise<{ country: Country | null; state: State | null }> {
    try {
        const country = await companiesService.getCountryById(countryId);
        let state: State | null = null;

        if (stateId && countryId) {
            state = await companiesService.getStateById(countryId, stateId);
        }

        return { country, state };
    } catch (error) {
        console.error('Error fetching country or state data:', error);
        return { country: null, state: null };
    }
}
const checkExistingCompany = async <T>(companyName: string): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.CHECK_EXISTING_COMPANY}/${companyName}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

const updateCurrencyDetails = async <T>(
    companyId: number,
    activeIndex: number,
    currencyId: number
): Promise<T> => {
    const patentServiceId: any = {
        0: PV_SETTINGS_RATES['pct'],
        1: PV_SETTINGS_RATES['claims'],
        2: PV_SETTINGS_RATES['ep'],
        3: PV_SETTINGS_RATES['upc'],
        4: PV_SETTINGS_RATES['pc']
    };
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY}/${companyId}/${patentServiceId[activeIndex]}/${currencyId}`;
    try {
        const response = await _httpService.post<T, number>(apiUrl, 0);
        return response;
    } catch (error) {
        console.error('Error fetching Industries listing data:', error);
        throw error;
    }
};

const updateEnglishTranslationFormula = async <T>(
    requestBody: CompanyTranslationFormulaUpdate
): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.UPDATE_COMPANY_IP_RATE}`;
    try {
        const response = await _httpService.patch<T, CompanyTranslationFormulaUpdate>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error updating fee details:', error);
        throw error;
    }
};

const resyncCompanyByID = async <T>(id: number): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.SYNC_COMPANYID}/${id}`;
    try {
        const response = await _httpService.post<T, number>(apiUrl, id);
        return response;
    } catch (error) {
        console.error('Error in Resync:', error);
        throw error;
    }
};
const resyncCompanyByAll = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.SYNC_COMPANYALL}`;
    try {
        const requestBody = {
            searchModels: [],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        };
        const response = await _httpService.post<T, RequestBody>(apiUrl, requestBody);
        if (response) {
            await getTableData(requestBody);
        }
        return response;
    } catch (error) {
        console.error('Error in Resync:', error);
        throw error;
    }
};

const getBalanceInformation = async <T>(companyId: number): Promise<BalanceInfo> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BALANCE_INFORMATION}/${companyId}`;
    try {
        const response = await _httpService.get<T>(apiUrl, {
            data: { hideLoader: true }
        });
        return response as BalanceInfo;
    } catch (error) {
        console.error('Error fetching balance information:', error);
        throw error;
    }
};

// Export an object containing all the services
const companiesService = {
    getTableData,
    updateChangeStatus,
    createCompany,
    updateCompany,
    getCompanyById,
    getSourceLanguages,
    getRequestCurrencyData,
    getIPRequestData,
    updateFee,
    getPreferredCurrency,
    getSageCompanyList,
    getBillingTermsList,
    getParentCompanyList,
    getParentCompanyId,
    getPaymentTypeList,
    getSalesRepList,
    getIndustryList,
    getPreferredCurrencyList,
    getBillingPeriodList,
    getCountryList,
    getStatesList,
    getCountryById,
    getStateById,
    getCountryAndState,
    checkExistingCompany,
    updateCurrencyDetails,
    updateEnglishTranslationFormula,
    resyncCompanyByID,
    resyncCompanyByAll,
    getBalanceInformation
};

export default companiesService;
