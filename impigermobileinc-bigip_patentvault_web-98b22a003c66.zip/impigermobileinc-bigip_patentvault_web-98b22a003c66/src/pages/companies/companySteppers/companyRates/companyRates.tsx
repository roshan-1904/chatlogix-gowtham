import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TabView, TabPanel } from 'primereact/tabview';
import { tabPanelPT, tabViewPT } from 'constants/styles.constant';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import {
    CompanyRatesListingResponseType,
    SourceLanguageResponseType,
    TargetLanguageResponse,
    defaultDropdownValues,
    unitOptions
} from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import companiesService from 'pages/companies/service/companies.service';
import {
    requestCurrencyResponseType,
    dropdownValuesType,
    preferredCurrencyResponse
} from 'pages/companies/types/createCompany.types';
import FilterDropDown from '../../../pvsettings/subaccordions/rates/components/filterDropdown';
import {
    CLAIMS_COLUMN_CONFIG,
    EP_COLUMN_CONFIG,
    PCT_COLUMN_CONFIG,
    PCT_COLUMN_CONFIG_2,
    PC_COLUMN_CONFIG,
    PC_COLUMN_CONFIG_2,
    UPC_COLUMN_CONFIG
} from './ratesColumnConfig';
import TableData from 'pages/pvsettings/subaccordions/rates/components/TableData';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import { useLocation } from 'react-router-dom';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { Dropdown } from 'primereact/dropdown';
import UnSelectedFilterDropdown from 'pages/pvsettings/subaccordions/rates/components/unSelectedFilter';
import { DataTableExpandedRows } from 'primereact/datatable';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import {
    ADDITIONAL_FIELDS_LANG,
    PV_SETTINGS_RATES,
    SOURCE_LANGUAGE_ID,
    TRANSLATION_MODULES
} from 'pages/pvsettings/subaccordions/rates/rates.const';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { AgencyFee } from 'pages/pvsettings/subaccordions/rates/components/addCountriesPopup';
import EnglishTranslationPopup from 'pages/pvsettings/subaccordions/rates/components/englishTranslationPopup';

export default function CompanyRates() {
    const { t } = useTranslation();
    const [activeIndex, setActiveIndex] = useState(0);
    const [sourceLanguagesData, setSourceLanguagesData] = useState<dropdownValuesType[] | null>([]);
    const [requestCurrencyData, setRequestCurrencyData] = useState<dropdownValuesType[] | null>([]);
    const [targetLanguageData, setTargetLanguageData] = useState<dropdownValuesType[] | null>([]);
    const [filteredSourceLanguage, setFilteredSourceLanguage] = useState<number>(0);
    const [filteredReqCurrency, setFilteredReqCurrency] = useState<number>(0);
    const [filteredTargetLang, setFilteredTargetLang] = useState<number>(0);
    const [isLoading, setIsLoading] = useState(false);
    const [defaultSelections, setDefaultSelections] = useState<defaultDropdownValues>({
        requestCurrency: { label: '', value: 0 },
        sourceLanguage: { label: '', value: 0 }
    });
    const [unitOptionsValues, setUnitOptionsValue] = useState<unitOptions[]>();
    const [languageIds, setLanguageIds]: any = useState({});
    const [isEnglishTranslationUpdated, setIsEnglishTranslationUpdated] = useState<boolean>(false);
    const [FormulaFields, setFormulaFields] = useState<Array<string>>();
    const [preferredCurrency, setPreferredCurrency] = useState<dropdownValuesType[] | null>([]);
    const [filteredPreferredCurrency, setFilteredPreferredCurrency] = useState<number>(0);
    const [expandedRows, setExpandedRows] = useState<
        DataTableExpandedRows | Record<string, boolean>
    >({});

    // find view mode
    const location = useLocation();
    const { pathname } = location;
    const readOnly: boolean = pathname?.includes('view');

    const showPreferredCurrency = false;

    // Company details
    const companyData = companyStepperStore?.getData?.() || {};
    const { stepperInfo, formData } = companyData || {};
    const isTMDiscountAgreed = formData?.companyProfilePage?.isAgreeTMDiscounts === 'yes' || false;
    const { FRE, GER } = SOURCE_LANGUAGE_ID;
    const {
        DATA_TABLE: {
            RATES: { pct, pct_fre_ger, ep, ep_fre, ep_ger }
        }
    } = DATA_STORAGE_KEYS;

    const [listingData, setListingData] = useState<CompanyRatesListingResponseType>({
        ipRateDetailList: [],
        companyRateDetailList: [],
        companyTranslationRatesList: [],
        companyLevelTranslationRatesList: [],
        pageNo: 1,
        totalCount: 0,
        descriptionTranslationFormulaModel: {
            feeType: '',
            unitTypeId: 0,
            formula: '',
            fee: 0
        },
        companyDescriptionTranslationFormulaModel: {
            feeType: '',
            unitTypeId: 0,
            formula: '',
            fee: 0
        },
        totalPages: 0,
        currencyData: {
            currencyCode: '',
            currencyId: 0,
            currencyName: '',
            currencySymbol: ''
        },
        agencyFeeInfo: 0,
        companyAgencyFeeInfo: 0
    });

    const toggleRow = (data: any) => {
        const expandedRowsCopy = { ...expandedRows };
        if (expandedRowsCopy[data.id]) {
            delete expandedRowsCopy[data.id];
        } else {
            expandedRowsCopy[data.id] = true;
        }
        setExpandedRows(expandedRowsCopy);
    };

    const expanderTemplate = (data: any) => {
        return (
            <button
                type="button"
                onClick={() => toggleRow(data)}
                onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                        toggleRow(data);
                    }
                }}
                data-testid="dataTable-link-format"
                className="p-link mr-1">
                <i
                    className={`text-primary pi pi-fw pi-chevron-${expandedRows[data.id] ? 'down' : 'right'} `}
                />
            </button>
        );
    };

    const RowExpansionTemplate = (data: Record<string, any>) => {
        if (!Object.keys(data)?.length) return '-';
        const canExpand =
            isTMDiscountAgreed && !!data?.agreeTmDiscount && !!data?.breakdowns?.length;
        return (
            <div
                data-testid="dataTable-link-format"
                className={`flex items-center ${canExpand ? '' : isTMDiscountAgreed ? 'ml-6' : ''}`}
                role="button"
                tabIndex={0}>
                {canExpand && expanderTemplate(data)}
                <div className="text-golden-brown bg-cream-yellow px-1 rounded border-soft-yellow border">
                    {data?.sourceLanguageName}
                </div>
            </div>
        );
    };

    function emptyTemplate(options: any) {
        return options.value;
    }

    const COMPANY_TRANSLATIONS_COLUMN_CONFIG: ColumnDefinition[] = [
        {
            field: 'sourceLanguageName',
            header: t('PV_SETTING.RATES.SOURCE_LANGUAGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: RowExpansionTemplate,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        {
            field: 'targetLanguageName',
            header: t('PV_SETTING.RATES.TARGET_LANGUAGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle:
                'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px] !normal-case',
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        {
            field: 'currencyCode',
            header: t('PV_SETTING.RATES.CURRENCY'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        {
            field: 'enableMinCharge',
            header: t('PV_SETTING.RATES.ENABLE_MIN_CHARGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'minCharge',
            header: t('PV_SETTING.RATES.MIN_CHARGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            body: (rowData: any) => (
                <span>
                    {rowData?.minCharge
                        ? `${rowData?.currencySymbol || ''} ${rowData?.minCharge}`
                        : '-'}
                </span>
            ),
            visibility: true
        },
        {
            field: 'agreeTmDiscount',
            header: t('PV_SETTING.RATES.TM'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'unitName',
            header: t('PV_SETTING.RATES.UNIT'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'translationRate',
            header: t('PV_SETTING.RATES.TRANSLATION_RATE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.TranslationRate,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4 !p-0'
        },
        {
            field: 'agreeTmDiscount',
            header: t('PV_SETTING.RATES.BREAKDOWN'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.YesOrNoIcon,
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'action',
            header: t('COMMON.ACTION'),
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.EditDelete,
            columnNumber: 4,
            visibility: true,
            onEdit: emptyTemplate
        }
    ];

    // Tab view styles
    const tabViewPTStyles = {
        ...tabViewPT,
        header: { clasname: 'border-neutral-100/50 border' },
        nav: { className: `${tabViewPT.nav.className} gap-3` }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    // Fetch Source Language Data
    const getSourceLanguage = async () => {
        try {
            setIsLoading(true);
            const response: SourceLanguageResponseType[] =
                await companiesService.getSourceLanguages();
            const languageIdsData: any = {};
            const dropdownData: dropdownValuesType[] = response.map(
                (language: SourceLanguageResponseType) => {
                    languageIdsData[language.id] = {
                        name: language.name,
                        langCode: language.abbreviation
                    };
                    return { label: language.name, value: language.id };
                }
            );
            setSourceLanguagesData(dropdownData);
            setLanguageIds(languageIdsData);
            if (dropdownData?.length) {
                setFilteredSourceLanguage(activeIndex === 5 ? 0 : Number(dropdownData[0]?.value));
            }
            setTimeout(() => {
                setIsLoading(false);
            }, 1);
        } catch (error) {
            console.error(error);
            setIsLoading(false);
            showToastMessage(
                t('PV_SETTING.RATES.ERROR_MESSAGE.GET_SOURCE_LANGUAGES'),
                ToastType.ERROR
            );
        }
    };

    // Fetch Target Language
    const getTargetLanguageData = async () => {
        try {
            const response: TargetLanguageResponse[] = await PVSettingsService.getTargetLanguage();
            const dropdownData: dropdownValuesType[] = response.map(
                (language: TargetLanguageResponse) => ({
                    label: language.name,
                    value: language.id
                })
            );
            setTargetLanguageData(dropdownData);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.RATES.ERROR_MESSAGE.GET_TARGET_LANGUAGES'),
                ToastType.ERROR
            );
        }
    };

    // Fetch Currency Units
    const getRequestCurrencyData = async () => {
        try {
            setIsLoading(true);
            const response: requestCurrencyResponseType[] =
                await companiesService.getRequestCurrencyData();

            // Create a sorted copy of the response based on isoCode
            const sortedResponse = [...response].sort((a, b) => a.isoCode.localeCompare(b.isoCode));

            const dropdownData: dropdownValuesType[] = sortedResponse.map(
                (currency: requestCurrencyResponseType) => ({
                    label: currency.isoCode,
                    value: currency.id
                })
            );
            setRequestCurrencyData(dropdownData);
            if (dropdownData?.length) {
                setFilteredReqCurrency(
                    activeIndex === 5
                        ? 0
                        : Number(dropdownData.filter((e) => e.label === 'USD')[0].value)
                );
            }
            setIsLoading(false);
        } catch (error) {
            console.error(error);
            setIsLoading(false);
            showToastMessage(t('PV_SETTING.ERROR_MESSAGE.GET_CURRENCY_DATA'), ToastType.ERROR);
        }
    };

    const onDropdownChange = (event: any) => {
        /* eslint-disable @typescript-eslint/no-unsafe-argument */
        if (Object.keys(event)[0] === 'sourceLanguage') {
            setFilteredSourceLanguage(event.sourceLanguage ? Number(event.sourceLanguage) : 0);
        } else if (Object.keys(event)[0] === 'requestCurrency')
            setFilteredReqCurrency(event.requestCurrency ? Number(event.requestCurrency) : 0);
        else if (Object.keys(event)[0] === 'targetLanguage')
            setFilteredTargetLang(event.targetLanguage ? Number(event.targetLanguage) : 0);
        if (event.sourceLanguage) {
            setFilteredSourceLanguage(Number(event.sourceLanguage));
        } else if (event.requestCurrency) setFilteredReqCurrency(Number(event.requestCurrency));
    };

    const getUnitTypes = async () => {
        try {
            const response: unitOptions[] = await PVSettingsService.getUnitTypes();
            setUnitOptionsValue(response);
        } catch (error) {
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.GET_UNIT_TYPES'),
                ToastType.ERROR
            );
        }
    };

    const getFormulaFields = async () => {
        try {
            const response: Array<string> = await PVSettingsService.getFormulaFields();
            setFormulaFields(response);
        } catch (error) {
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.GET_FORMULA_FIELDS'),
                ToastType.ERROR
            );
        }
    };

    const getPreferredCurrency = async () => {
        try {
            const response: preferredCurrencyResponse[] =
                await companiesService.getPreferredCurrency(
                    stepperInfo?.primaryId ?? 0,
                    activeIndex
                );
            const dropDownOptions: dropdownValuesType[] = response.map(
                (currency: preferredCurrencyResponse) => {
                    if (currency.isPreferredCurrency) {
                        setFilteredPreferredCurrency(currency.currencyId);
                    }
                    return {
                        label: currency.currencyCode,
                        value: currency.currencyId
                    };
                }
            );
            setPreferredCurrency(dropDownOptions);
        } catch (error) {
            showToastMessage(
                t('PV_SETTING.RATES.ERROR_MESSAGE.GET_PREFERRED_CURRENCY'),
                ToastType.ERROR
            );
        }
    };

    const handleCurrencyChange = async (currencyId: number) => {
        try {
            const currencyUpdate = await companiesService.updateCurrencyDetails(
                stepperInfo?.primaryId ?? 0,
                Number(activeIndex),
                currencyId
            );
            if (currencyUpdate) setFilteredPreferredCurrency(currencyId);
        } catch (error) {
            showToastMessage(
                t('PV_SETTING.RATES.ERROR_MESSAGE.UPDATE_PREFERRED_CURRENCY'),
                ToastType.ERROR
            );
        }
    };

    const EnglishTranslationFormulaTemplate = (patentId: number) => {
        return (
            <div key={patentId} className="mr-3">
                {ADDITIONAL_FIELDS_LANG.includes(
                    `${languageIds?.[filteredSourceLanguage]?.langCode}`
                ) &&
                    listingData?.companyDescriptionTranslationFormulaModel?.formula?.length > 0 && (
                        <EnglishTranslationPopup
                            currencySymbol={listingData?.currencyData?.currencySymbol || ''}
                            indirectTranslationRate={listingData?.indirectTranslationRate || 0}
                            aiIndirectTranslationRate={listingData?.aiIndirectTranslationRate || 0}
                            indirectTrAiTrDifference={listingData?.indirectTrAiTrDifference || 0}
                            indirectTrAiTrDifferencePercent={
                                listingData?.indirectTrAiTrDifferencePercent || 0
                            }
                            isAiIndirectTranslation={listingData?.isAiIndirectTranslation || false}
                            descriptionTranslationFormulaModel={
                                listingData?.companyDescriptionTranslationFormulaModel || {}
                            }
                            formulaFields={FormulaFields || []}
                            patentServiceId={patentId}
                            sourceLanguageId={filteredSourceLanguage || 0}
                            requestCurrencyId={filteredReqCurrency || 0}
                            updatedSuccessfully={() =>
                                setIsEnglishTranslationUpdated(!isEnglishTranslationUpdated)
                            }
                            isCompany={true}
                            viewMode={readOnly}
                            companyId={stepperInfo?.primaryId || 0}
                        />
                    )}
            </div>
        );
    };

    const getTabPanelPT = (index: number) => {
        return tabPanelPT(activeIndex === index, () => {
            setFilteredSourceLanguage(0);
            setFilteredReqCurrency(0);
            setFilteredTargetLang(0);
            setActiveIndex(index);
        });
    };

    const getTabPassThrough = (index: number) => ({
        ...getTabPanelPT(index),
        root: {
            ...getTabPanelPT(index).root,
            className: getTabPanelPT(index).root.className + ' pb-0 border-b-0 relative'
        },
        header: {
            ...getTabPanelPT(index).header,
            className: getTabPanelPT(index).header.className + ' pb-2',
            onClick: getTabPanelPT(index).header.onClick
        },
        content: {
            className: getTabPanelPT(index).content.className + ' pt-4'
        }
    });

    useEffect(() => {
        const TranslationModules = activeIndex === 5;
        if (!TranslationModules) {
            setFilteredSourceLanguage(
                defaultSelections?.sourceLanguage?.value ||
                    (sourceLanguagesData?.filter(
                        (language: dropdownValuesType) => language.label === 'English'
                    )[0]?.value ??
                        0)
            );
            setFilteredReqCurrency(
                defaultSelections?.requestCurrency?.value ||
                    (requestCurrencyData?.filter(
                        (currency: dropdownValuesType) => currency.label === 'USD'
                    )?.[0]?.value ??
                        0)
            );
        }
    }, [activeIndex]);

    useEffect(() => {
        getSourceLanguage();
        getRequestCurrencyData();
        getUnitTypes();
        getFormulaFields();
        getTargetLanguageData();
    }, []);

    useEffect(() => {
        if (requestCurrencyData?.length && sourceLanguagesData?.length) {
            const defaultLanguage: dropdownValuesType = sourceLanguagesData?.filter(
                (language: dropdownValuesType) => language.label === 'English'
            )[0] ?? { label: '', value: 0 };
            const defaultCurrency = requestCurrencyData?.filter(
                (currency: dropdownValuesType) => currency.label === 'USD'
            )?.[0] ?? { label: '', value: 0 };
            setDefaultSelections({
                ...defaultSelections,
                sourceLanguage: defaultLanguage,
                requestCurrency: defaultCurrency
            });
        }
    }, [requestCurrencyData]);

    return (
        <div className="">
            <h4 className="font-semibold px-5 pt-4">{t('COMMON.RATES')}</h4>
            <div className="p-4 ratesTabView pb-0">
                <TabView
                    activeIndex={activeIndex}
                    pt={tabViewPTStyles}
                    onTabChange={(e) => {
                        if (e.index !== activeIndex) {
                            setActiveIndex(e.index);
                        }
                    }}>
                    <TabPanel
                        className="border-1"
                        pt={getTabPassThrough(0)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.PCT')}>
                        {activeIndex === 0 && (
                            <>
                                {!isLoading && (
                                    <TableData
                                        key={PV_SETTINGS_RATES.pct}
                                        sourceLanguageId={filteredSourceLanguage ?? 0}
                                        requestCurrencyId={filteredReqCurrency ?? 0}
                                        columnSchema={
                                            [FRE, GER]?.includes(filteredSourceLanguage)
                                                ? PCT_COLUMN_CONFIG_2
                                                : PCT_COLUMN_CONFIG
                                        }
                                        moduleName={'pct'}
                                        localStorageKey={
                                            [FRE, GER]?.includes(filteredSourceLanguage)
                                                ? pct_fre_ger
                                                : pct
                                        }
                                        company={true}
                                        getPreferredCurrency={getPreferredCurrency}
                                        FormulaFields={FormulaFields ?? []}
                                        serviceType={'PCT'}
                                        unitOptionsValues={unitOptionsValues ?? []}
                                        {...{
                                            listingData,
                                            setListingData,
                                            readOnly,
                                            isEnglishTranslationUpdated,
                                            setIsEnglishTranslationUpdated,
                                            activeIndex
                                        }}
                                        leftHeaderSection={
                                            <div className="flex justify-between items-center w-full">
                                                <div className="flex items-center">
                                                    <FilterDropDown
                                                        sourceLanguagesData={
                                                            sourceLanguagesData ?? []
                                                        }
                                                        requestCurrencyData={
                                                            requestCurrencyData ?? []
                                                        }
                                                        moduleName={'pct'}
                                                        company={true}
                                                        defaultSelections={defaultSelections}
                                                        onChange={onDropdownChange}
                                                    />
                                                    {!readOnly && showPreferredCurrency && (
                                                        <div className="px-2 py-0 border h-10 border-neutral-100 flex items-center gap-2 rounded-md bg-lightBlue ml-2">
                                                            <p className="text-xs whitespace-nowrap font-medium mt">
                                                                {t(
                                                                    'PV_SETTING.RATES.LABEL.PREFERRED_CURRENCY'
                                                                )}
                                                            </p>
                                                            <Dropdown
                                                                value={filteredPreferredCurrency}
                                                                className="!w-full border-none"
                                                                onChange={(e: any) => {
                                                                    (async () => {
                                                                        await handleCurrencyChange(
                                                                            Number(e.target.value)
                                                                        );
                                                                    })();
                                                                }}
                                                                pt={{
                                                                    root: {
                                                                        className: 'p-1 gap-1'
                                                                    },
                                                                    input: { className: '!p-0' },
                                                                    trigger: {
                                                                        className: 'w-5 mt-0.5'
                                                                    }
                                                                }}
                                                                options={preferredCurrency ?? []}
                                                            />
                                                        </div>
                                                    )}
                                                </div>
                                                {EnglishTranslationFormulaTemplate(
                                                    PV_SETTINGS_RATES.pct
                                                )}
                                            </div>
                                        }
                                    />
                                )}
                            </>
                        )}
                    </TabPanel>
                    <TabPanel
                        pt={getTabPassThrough(1)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.71_3_CLAIMS')}>
                        {activeIndex === 1 && (
                            <TableData
                                key={PV_SETTINGS_RATES.claims}
                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                requestCurrencyId={filteredReqCurrency ?? 0}
                                columnSchema={CLAIMS_COLUMN_CONFIG}
                                moduleName={'claims'}
                                company={true}
                                getPreferredCurrency={getPreferredCurrency}
                                listingData={listingData}
                                setListingData={setListingData}
                                readOnly={readOnly}
                                serviceType={'71[3] claims'}
                                FormulaFields={FormulaFields ?? []}
                                unitOptionsValues={unitOptionsValues ?? []}
                                {...{ activeIndex }}
                                leftHeaderSection={
                                    <div className="flex justify-between items-center w-full">
                                        <FilterDropDown
                                            sourceLanguagesData={sourceLanguagesData ?? []}
                                            requestCurrencyData={requestCurrencyData ?? []}
                                            defaultSelections={defaultSelections}
                                            moduleName={'claims'}
                                            company={true}
                                            onChange={onDropdownChange}
                                        />
                                    </div>
                                }
                            />
                        )}
                    </TabPanel>
                    <TabPanel
                        pt={getTabPassThrough(2)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.EP_NON_UP')}>
                        {activeIndex === 2 && (
                            <TableData
                                key={PV_SETTINGS_RATES.ep}
                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                requestCurrencyId={filteredReqCurrency ?? 0}
                                columnSchema={
                                    [FRE, GER]?.includes(filteredSourceLanguage)
                                        ? [
                                              ...EP_COLUMN_CONFIG.slice(0, 2),
                                              {
                                                  field: 'isEngDescriptionTranslationRequired',
                                                  header: t(
                                                      `PV_SETTING.RATES.${FRE === filteredSourceLanguage ? 'FRE_INDIRECT_TRANSLATION_RATE' : 'GER_INDIRECT_TRANSLATION_RATE'}`
                                                  ),
                                                  sortable: false,
                                                  filter: false,
                                                  frozen: false,
                                                  filterType: FilterType.Text,
                                                  valueType: ValueType.YesOrNo,
                                                  columnNumber: 1,
                                                  visibility: true,
                                                  className: 'w-1/4'
                                              },
                                              ...EP_COLUMN_CONFIG.slice(2, EP_COLUMN_CONFIG?.length)
                                          ]
                                        : EP_COLUMN_CONFIG
                                }
                                moduleName={'ep'}
                                company={true}
                                listingData={listingData}
                                readOnly={readOnly}
                                localStorageKey={
                                    [FRE, GER]?.includes(filteredSourceLanguage)
                                        ? FRE === filteredSourceLanguage
                                            ? ep_fre
                                            : ep_ger
                                        : ep
                                }
                                getPreferredCurrency={getPreferredCurrency}
                                serviceType={'EP, NON-UP'}
                                setListingData={setListingData}
                                FormulaFields={FormulaFields ?? []}
                                unitOptionsValues={unitOptionsValues ?? []}
                                isEnglishTranslationUpdated={isEnglishTranslationUpdated}
                                {...{ activeIndex }}
                                leftHeaderSection={
                                    <div className="flex justify-between items-center w-full">
                                        <div className="flex items-center">
                                            <FilterDropDown
                                                sourceLanguagesData={sourceLanguagesData ?? []}
                                                requestCurrencyData={requestCurrencyData ?? []}
                                                defaultSelections={defaultSelections}
                                                moduleName={'ep'}
                                                company={true}
                                                onChange={onDropdownChange}
                                            />
                                            {!readOnly && showPreferredCurrency && (
                                                <div className="px-2 py-0 border h-10 border-neutral-100 flex items-center gap-2 rounded-md bg-lightBlue mt-3 ml-2">
                                                    <p className="text-xs whitespace-nowrap font-medium mt">
                                                        {t(
                                                            'PV_SETTING.RATES.LABEL.PREFERRED_CURRENCY'
                                                        )}
                                                    </p>
                                                    <Dropdown
                                                        value={filteredPreferredCurrency}
                                                        className="!w-full border-none"
                                                        pt={{
                                                            root: { className: 'p-1 gap-1' },
                                                            input: { className: '!p-0' },
                                                            trigger: { className: 'w-5 mt-0.5' }
                                                        }}
                                                        onChange={(e: any) => {
                                                            (async () => {
                                                                await handleCurrencyChange(
                                                                    Number(e.target.value)
                                                                );
                                                            })();
                                                        }}
                                                        defaultValue={preferredCurrency?.[0]?.value}
                                                        options={preferredCurrency ?? []}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                        <div>
                                            {EnglishTranslationFormulaTemplate(
                                                PV_SETTINGS_RATES.ep
                                            )}
                                        </div>
                                    </div>
                                }
                            />
                        )}
                    </TabPanel>
                    <TabPanel
                        pt={getTabPassThrough(3)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.UPC')}>
                        {activeIndex === 3 && (
                            <TableData
                                key={PV_SETTINGS_RATES.upc}
                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                requestCurrencyId={filteredReqCurrency ?? 0}
                                columnSchema={UPC_COLUMN_CONFIG}
                                moduleName={'upc'}
                                company={true}
                                getPreferredCurrency={getPreferredCurrency}
                                readOnly={readOnly}
                                listingData={listingData}
                                serviceType={'UPC'}
                                setListingData={setListingData}
                                FormulaFields={FormulaFields ?? []}
                                unitOptionsValues={unitOptionsValues ?? []}
                                {...{ activeIndex }}
                                leftHeaderSection={
                                    <div className="flex justify-between items-center w-full">
                                        <FilterDropDown
                                            sourceLanguagesData={sourceLanguagesData ?? []}
                                            requestCurrencyData={requestCurrencyData ?? []}
                                            moduleName={'upc'}
                                            company={true}
                                            defaultSelections={defaultSelections}
                                            onChange={onDropdownChange}
                                        />
                                        <AgencyFee
                                            rowData={{
                                                currencyData: listingData.currencyData,
                                                agencyFeeInfo: listingData.companyAgencyFeeInfo,
                                                updateValues: {
                                                    sourceLanguageId: filteredSourceLanguage,
                                                    requestCurrencyId: filteredReqCurrency,
                                                    patentServiceId: PV_SETTINGS_RATES['upc']
                                                }
                                            }}
                                            company={true}
                                            readOnly={readOnly}
                                        />
                                    </div>
                                }
                            />
                        )}
                    </TabPanel>
                    <TabPanel
                        pt={getTabPassThrough(4)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.PC')}>
                        {activeIndex === 4 && (
                            <TableData
                                key={PV_SETTINGS_RATES.pc}
                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                requestCurrencyId={filteredReqCurrency ?? 0}
                                columnSchema={
                                    [FRE, GER]?.includes(filteredSourceLanguage)
                                        ? PC_COLUMN_CONFIG_2
                                        : PC_COLUMN_CONFIG
                                }
                                moduleName={'pc'}
                                company={true}
                                getPreferredCurrency={getPreferredCurrency}
                                listingData={listingData}
                                readOnly={readOnly}
                                serviceType={'PC'}
                                setListingData={setListingData}
                                FormulaFields={FormulaFields ?? []}
                                unitOptionsValues={unitOptionsValues ?? []}
                                {...{ activeIndex }}
                                leftHeaderSection={
                                    <div className="flex justify-between items-center w-full">
                                        <div>
                                            <FilterDropDown
                                                sourceLanguagesData={sourceLanguagesData ?? []}
                                                requestCurrencyData={requestCurrencyData ?? []}
                                                moduleName={'pc'}
                                                company={true}
                                                defaultSelections={defaultSelections}
                                                onChange={onDropdownChange}
                                            />
                                            {!readOnly && showPreferredCurrency && (
                                                <div className="px-2 py-0 border h-10 border-neutral-100 flex items-center gap-2 rounded-md bg-lightBlue ml-2">
                                                    <p className="text-xs whitespace-nowrap font-medium mt">
                                                        {t(
                                                            'PV_SETTING.RATES.LABEL.PREFERRED_CURRENCY'
                                                        )}
                                                    </p>
                                                    <Dropdown
                                                        value={filteredPreferredCurrency}
                                                        className="!w-full border-none"
                                                        pt={{
                                                            root: { className: 'p-1 gap-1' },
                                                            input: { className: '!p-0' },
                                                            trigger: { className: 'w-5 mt-0.5' }
                                                        }}
                                                        onChange={(e: any) => {
                                                            (async () => {
                                                                await handleCurrencyChange(
                                                                    Number(e.target.value)
                                                                );
                                                            })();
                                                        }}
                                                        defaultValue={preferredCurrency?.[0]?.value}
                                                        options={preferredCurrency ?? []}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                        <div>
                                            {EnglishTranslationFormulaTemplate(
                                                PV_SETTINGS_RATES.pc
                                            )}
                                        </div>
                                    </div>
                                }
                            />
                        )}
                    </TabPanel>
                    <TabPanel
                        pt={getTabPassThrough(5)}
                        header={t('PV_SETTING.RATES.TAB_HEADERS.COMPANY_TRANSLATIONS')}>
                        {activeIndex === 5 && (
                            <TableData
                                key={`${PV_SETTINGS_RATES.companytranslations}_${TRANSLATION_MODULES?.[0]}`}
                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                requestCurrencyId={filteredReqCurrency ?? 0}
                                targetLanguage={filteredTargetLang ?? 0}
                                columnSchema={
                                    readOnly
                                        ? [...COMPANY_TRANSLATIONS_COLUMN_CONFIG]?.filter(
                                              ({ field }) => field !== 'action'
                                          )
                                        : COMPANY_TRANSLATIONS_COLUMN_CONFIG
                                }
                                moduleName={'companytranslations'}
                                localStorageKey={
                                    readOnly ? 'viewCompanytranslations' : 'companytranslations'
                                }
                                listingData={listingData}
                                setListingData={setListingData}
                                company={true}
                                FormulaFields={FormulaFields ?? []}
                                expandedRows={expandedRows}
                                unitOptionsValues={unitOptionsValues ?? []}
                                {...{ activeIndex }}
                                leftHeaderSection={
                                    <UnSelectedFilterDropdown
                                        sourceLanguagesData={sourceLanguagesData ?? []}
                                        requestCurrencyData={requestCurrencyData ?? []}
                                        onChange={onDropdownChange}
                                        targetLanguageData={targetLanguageData ?? []}
                                    />
                                }
                            />
                        )}
                    </TabPanel>
                </TabView>
            </div>
        </div>
    );
}
