import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CompanyRates from './companyRates';
import { BrowserRouter as Router } from 'react-router-dom';
import companiesService from 'pages/companies/service/companies.service';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';

jest.mock('react-i18next', () => ({
    useTranslation: jest.fn().mockReturnValue({
        t: (key: string) => key
    })
}));

jest.mock('pages/companies/service/companies.service');
jest.mock('pages/pvsettings/subaccordions/service/pvsettings.service');
jest.mock('core/store/stepperStore/companyStore/company.store');

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

describe('CompanyRates Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders CompanyRates component', () => {
        (companiesService.getSourceLanguages as jest.Mock).mockResolvedValue([]);
        (companiesService.getRequestCurrencyData as jest.Mock<any>).mockResolvedValue([]);
        (PVSettingsService.getTargetLanguage as jest.Mock).mockResolvedValue([]);
        (PVSettingsService.getUnitTypes as jest.Mock).mockResolvedValue([]);
        (companiesService.getPreferredCurrency as jest.Mock).mockResolvedValue([]);

        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        expect(screen.getByText('COMMON.RATES')).toBeInTheDocument();
    });

    test('fetches source languages on mount', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        await waitFor(() => {
            expect(companiesService.getSourceLanguages).toHaveBeenCalled();
        });
    });

    test('fetches request currency data on mount', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );
        (companiesService.getRequestCurrencyData as jest.Mock).mockResolvedValue({});

        await waitFor(() => {
            expect(companiesService.getRequestCurrencyData).toHaveBeenCalled();
        });
    });

    test('fetches target languages on mount', async () => {
        const mockTargetLanguages = [
            { id: 1, name: 'Spanish' },
            { id: 2, name: 'German' }
        ];
        (PVSettingsService.getTargetLanguage as jest.Mock).mockResolvedValue(mockTargetLanguages);

        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        await waitFor(() => {
            expect(PVSettingsService.getTargetLanguage).toHaveBeenCalled();
        });
    });

    test('fetches unit types on mount', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        await waitFor(() => {
            expect(PVSettingsService.getUnitTypes).toHaveBeenCalled();
        });
    });

    test('fetches formula fields on mount', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        await waitFor(() => {
            expect(PVSettingsService.getFormulaFields).toHaveBeenCalled();
        });
    });

    test.skip('fetches preferred currency on mount', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );
        (companiesService.getPreferredCurrency as jest.Mock).mockResolvedValue({});
        await waitFor(() => {
            expect(companiesService.getPreferredCurrency).toHaveBeenCalled();
        });
    });

    test.skip('handles tab change', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        const tabHeaders = screen.getAllByRole('tab');
        fireEvent.click(tabHeaders[1]);

        await waitFor(() => {
            expect(tabHeaders[1]).toHaveClass('p-highlight');
        });
    });

    test.skip('opens and closes modal', async () => {
        render(
            <Router>
                <CompanyRates />
            </Router>
        );

        const editIcon = screen.getByRole('button', { name: /edit/i });
        fireEvent.click(editIcon);

        await waitFor(() => {
            expect(screen.getByRole('dialog')).toBeInTheDocument();
        });

        const closeButton = screen.getByRole('button', { name: /close/i });
        fireEvent.click(closeButton);

        await waitFor(() => {
            expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
        });
    });
});
