import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';

import companyProfileFormBuilderData from '../mocks/companyProfile.mock.json';
import { PATHS } from 'constants/routes.constant';
import HttpService from 'core/interceptor/api.handler';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { useLocation } from 'react-router-dom';
import { baseCurrencyWithAmountTemplate, focusOnFirstError } from 'core/utils/utils';
import { StepperModuleStoreData } from 'pages/components/progressStepper/types/progressStepper.type';
import { CompanyFormData } from 'core/store/stepperStore/companyStore/company.store.type';
import { Skeleton } from 'primereact/skeleton';
import companiesService from '../service/companies.service';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';

const CompanyProfile = () => {
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;
    const isReadOnly: boolean = pathname?.includes('view');
    const isEditMode: boolean = pathname?.includes('edit');
    const isViewInvoicePermission: boolean = AuthStore.hasPermission(Permissions.VIEW_INVOICE);
    const [CompanyStoreModuleData, setCompanyStoreModuleData] = useState(
        companyStepperStore.getData()
    );

    const balanceInfo = CompanyStoreModuleData.formData.companyProfilePage?.balanceInformation;
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(
        companyProfileFormBuilderData
    );

    companyStepperStore.subscribe(setCompanyStoreModuleData);

    const initialData = {
        data: {
            ...CompanyStoreModuleData?.formData.companyProfilePage,
            id: CompanyStoreModuleData?.stepperInfo?.primaryId
        }
    };

    const onSubmitChange = (e: any) => {
        /** note: this submit function will be only call when user clicks the 'next' button without any field error.\
             if error means, this function will not be call, rather than form-builder trigger the fields validation (errors). */
        const updatedFormData = e.data;
        companyProfileUpdateStore(updatedFormData, true, CompanyStoreModuleData);
    };

    const onFormChange = (e: any) => {
        const { data } = e;
        const updatedFormData = data;
        const fetchFormData = CompanyStoreModuleData.formData.companyProfilePage;
        if (e.changed && JSON.stringify(updatedFormData) !== JSON.stringify(fetchFormData)) {
            /** set always 'isFormValid' to false when form on change. \
                 we set true user once submitted. we can use this for navigation\other purpose.
                 because, the form builder returns 'isValid' flag as true even form is invalid while init rendering.
                 so we handled like this. */
            companyProfileUpdateStore(updatedFormData, false, CompanyStoreModuleData);
        }
    };

    const fetchBalanceInfo = async () => {
        try {
            const response = await companiesService.getBalanceInformation(
                Number(CompanyStoreModuleData?.formData.companyProfilePage?.id) || 0
            );

            const updatedFormData = {
                ...CompanyStoreModuleData.formData.companyProfilePage,
                balanceInformation: response
            };

            companyProfileUpdateStore(updatedFormData, true, CompanyStoreModuleData);
        } catch (error) {
            console.error('Error fetching balance info:', error);
        }
    };

    useEffect(() => {
        const updatedCompanyIsFormValid = {
            ...CompanyStoreModuleData.isFormValid,
            [PATHS.COMPANY_PROFILE]: false
        };
        companyStepperStore.updatePage('isFormValid', updatedCompanyIsFormValid);
    }, []);

    useEffect(() => {
        if (CompanyStoreModuleData?.formData.companyProfilePage?.balanceInformation === undefined) {
            fetchBalanceInfo();
        }
    }, [isEditMode, []]);

    return (
        <div className="companyProfilePage">
            <h4 className="font-semibold px-5 pt-4">{t('COMPANIES.COMPANY_PROFILE.TITLE')}</h4>
            <div className="p-3" data-testid="companyProfilePage">
                <Form
                    data-testid="companyProfilePage"
                    form={formBuilderData}
                    options={{
                        readOnly: isReadOnly ?? false
                    }}
                    onError={focusOnFirstError}
                    submission={initialData}
                    onChange={(e: any) => onFormChange(e)}
                    onSubmit={(e: any) => onSubmitChange(e)}
                />
                {(isReadOnly || isEditMode) && isViewInvoicePermission && (
                    <div className="flex flex-col gap-3 px-2">
                        <div className="p-3 bg-black/5 rounded-md flex justify-between">
                            <div className="flex flex-col gap-2">
                                <h5 className="font-medium">
                                    {t('COMPANIES.BALANCE_INFORMATION')}
                                </h5>
                                <p className="bg-warning/30 border-warning-700/50 p-1 px-2 border rounded-md text-[0.950rem] leading-4 w-fit flex items-center gap-1.5 justify-end">
                                    <i className="pi pi-exclamation-circle text-warning-800"></i>
                                    {t('COMPANIES.BALANCE_INFORMATION_DISCLAIMER')}
                                </p>
                            </div>
                            <p className="font-medium text-black/60 flex items-center gap-2">
                                {t('COMPANIES.TOTAL_BALANCE')}:
                                <span className="text-lg font-medium text-black">
                                    {balanceInfo === undefined ? (
                                        <Skeleton
                                            width="6rem"
                                            height="1rem"
                                            pt={{
                                                root: {
                                                    className: '!mb-0'
                                                }
                                            }}
                                        />
                                    ) : (
                                        baseCurrencyWithAmountTemplate(
                                            Number(balanceInfo?.totalDue) || 0
                                        )
                                    )}
                                </span>
                            </p>
                        </div>
                        <div className="flex flex-col gap-3">
                            <div className="flex gap-4 justify-between [&>div]:border [&>div]:p-4 [&>div]:rounded-md [&>div]:bg-black/[0.02] [&>div]:w-full [&>div]:flex [&>div]:justify-center [&>div]:flex-col [&>div]:gap-4 [&>div]:items-center [&>div]:h-32">
                                <div>
                                    <p className="font-medium text-black/60">
                                        {t('COMPANIES.INVOICE_BALANCE')}
                                    </p>
                                    <p className="font-medium text-md">
                                        {balanceInfo === undefined ? (
                                            <Skeleton
                                                width="4rem"
                                                height="1rem"
                                                pt={{
                                                    root: {
                                                        className: '!mb-0'
                                                    }
                                                }}
                                            />
                                        ) : (
                                            baseCurrencyWithAmountTemplate(
                                                Number(balanceInfo?.totalInvoiceBalance) || 0
                                            )
                                        )}
                                    </p>
                                </div>
                                <div>
                                    <p className="font-medium text-black/60">
                                        {t('COMPANIES.CREDIT_MEMO_AVAILABLE')}
                                    </p>
                                    <p className="font-medium text-md">
                                        {balanceInfo === undefined ? (
                                            <Skeleton
                                                width="4rem"
                                                height="1rem"
                                                pt={{
                                                    root: {
                                                        className: '!mb-0'
                                                    }
                                                }}
                                            />
                                        ) : (
                                            baseCurrencyWithAmountTemplate(
                                                Number(
                                                    balanceInfo?.totalCreditAdjustmentsBalance
                                                ) || 0
                                            )
                                        )}
                                    </p>
                                </div>
                                <div>
                                    <p className="font-medium text-black/60">
                                        {t('COMPANIES.DEBIT_MEMO_AVAILABLE')}
                                    </p>
                                    <p className="font-medium text-md">
                                        {balanceInfo === undefined ? (
                                            <Skeleton
                                                width="4rem"
                                                height="1rem"
                                                pt={{
                                                    root: {
                                                        className: '!mb-0'
                                                    }
                                                }}
                                            />
                                        ) : (
                                            baseCurrencyWithAmountTemplate(
                                                Number(balanceInfo?.totalDebitAdjustmentsBalance) ||
                                                    0
                                            )
                                        )}
                                    </p>
                                </div>
                                <div>
                                    <p className="font-medium text-black/60">
                                        {t('COMPANIES.ADVANCE_PAYMENT_AVAILABLE')}
                                    </p>
                                    <p className="font-medium text-md">
                                        {balanceInfo === undefined ? (
                                            <Skeleton
                                                width="4rem"
                                                height="1rem"
                                                pt={{
                                                    root: {
                                                        className: '!mb-0'
                                                    }
                                                }}
                                            />
                                        ) : (
                                            baseCurrencyWithAmountTemplate(
                                                Number(balanceInfo?.totalAdvancesBalance) || 0
                                            )
                                        )}
                                    </p>
                                </div>
                            </div>
                            {/* <div className="flex justify-end bg-primary/5 p-3 border rounded-md">
                                
                            </div> */}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
// update store
export const companyProfileUpdateStore = (
    updatedFormData: any,
    isValid = true,
    CompanyModuleData: StepperModuleStoreData<CompanyFormData>
) => {
    // updateFormData(updatedFormData);
    const updatedCompanyFormData = {
        ...CompanyModuleData.formData,
        billingInfoPage:
            CompanyModuleData.formData?.billingInfoPage ||
            companyStepperStore.getData().formData?.billingInfoPage,
        companyProfilePage: updatedFormData
    };

    companyStepperStore.updatePage('formData', updatedCompanyFormData);
    // updateIsFormValid(isValid);
    const updatedCompanyIsFormValid = {
        ...CompanyModuleData.isFormValid,
        [PATHS.COMPANY_PROFILE]: isValid
    };

    companyStepperStore.updatePage('isFormValid', updatedCompanyIsFormValid);
};
export default CompanyProfile;
