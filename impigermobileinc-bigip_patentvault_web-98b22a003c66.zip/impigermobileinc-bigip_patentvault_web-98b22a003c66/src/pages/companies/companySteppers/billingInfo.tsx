import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';

import billingInfoFormBuilderData from '../mocks/billingInfo.mock.json';
import { PATHS } from 'constants/routes.constant';
import HttpService from 'core/interceptor/api.handler';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { useLocation } from 'react-router-dom';
import {
    StepperModuleStoreData,
    StepperStoreState
} from 'pages/components/progressStepper/types/progressStepper.type';
import { CompanyFormData } from 'core/store/stepperStore/companyStore/company.store.type';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { Tooltip } from 'primereact/tooltip';

const BillingInfo = () => {
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;
    const isReadOnly: boolean = pathname?.includes('view');
    const [formReady, setFormReady] = useState(false);
    const [companyStoreModuleData, setCompanyModuleData] = useState(companyStepperStore.getData());
    const [showConfirmationPopup, setShowConfirmationPopup] = useState<boolean>(false);
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(billingInfoFormBuilderData);

    companyStepperStore.subscribe(setCompanyModuleData);

    const initialData = {
        data: {
            ...companyStoreModuleData?.formData.billingInfoPage
        }
    };

    const onSubmitChange = (e: any) => {
        /** note: this submit function will be only call when user clicks the 'next' button without any field error.\
             if error means, this function will not be call, rather than form-builder trigger the fields validation (errors). */
        const updatedFormData = e.data;
        billingInfoUpdateStore(updatedFormData, true, companyStoreModuleData, companyStepperStore);
    };

    const onFormChange = (e: any) => {
        const { data } = e;
        const updatedFormData = data;
        if (e?.changed?.component?.key === 'accountOnHold' && e?.changed?.value === 'yes') {
            setShowConfirmationPopup(true);
        } else {
            const fetchFormData = companyStoreModuleData.formData.billingInfoPage;

            if (e.changed && JSON.stringify(updatedFormData) !== JSON.stringify(fetchFormData)) {
                /** set always 'isFormValid' to false when form on change. \
                 we set true user once submitted. we can use this for navigation\other purpose.
                 because, the form builder returns 'isValid' flag as true even form is invalid while init rendering.
                 so we handled like this. */
                billingInfoUpdateStore(
                    updatedFormData,
                    false,
                    companyStoreModuleData,
                    companyStepperStore
                );
            }
        }
    };

    // update store
    useEffect(() => {
        const updatedBillingInfoIsFormValid = {
            ...companyStoreModuleData?.isFormValid,
            [PATHS.BILLING_INFO]: false
        };
        companyStepperStore.updatePage('isFormValid', updatedBillingInfoIsFormValid);

        setTimeout(() => {
            // this is to map the tooltip in DOM after the form is ready.
            setFormReady(true);
        }, 1500);
    }, []);

    const faQuestionCircleElement = document.querySelector('.fa-question-circle');
    if (faQuestionCircleElement) {
        faQuestionCircleElement.classList.add(
            'pi',
            'pi-info-circle',
            'py-2',
            'px-0.5',
            'text-primary'
        );
    }

    return (
        <div className="companyProfilePage">
            {showConfirmationPopup && (
                <ConfirmationPopup
                    onConfirm={() => {
                        companyStepperStore.updatePage('formData', {
                            ...companyStoreModuleData.formData,
                            billingInfoPage: {
                                ...companyStoreModuleData.formData.billingInfoPage,
                                accountOnHold: 'yes'
                            }
                        });
                        setShowConfirmationPopup(false);
                    }}
                    onCancel={() => {
                        companyStepperStore.updatePage('formData', {
                            ...companyStoreModuleData.formData,
                            billingInfoPage: {
                                ...companyStoreModuleData.formData.billingInfoPage,
                                accountOnHold: 'no'
                            }
                        });
                        setShowConfirmationPopup(false);
                    }}
                    visible={showConfirmationPopup}
                    headerText={t('COMMON.CONFIRMATION')}
                    description={t('COMPANIES.CONFIRMATION_FOR_ON_HOLD')}
                    acceptLabel={t('COMMON.YES')}
                    acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                    rejectClassName="!bg-error !text-white !border-none"
                    rejectLabel={t('COMMON.NO')}
                    popupID={'confirmationOnHoldPopup'}
                />
            )}
            <h4 className="font-semibold px-5 pt-4">{t('COMPANIES.BILLING_INFORMATION.TITLE')}</h4>
            <div className="p-3" data-testid="companyProfilePage">
                <Form
                    data-testid="companyProfilePage"
                    form={formBuilderData}
                    options={{
                        readOnly: isReadOnly ?? false
                    }}
                    submission={initialData}
                    onChange={(e: any) => onFormChange(e)}
                    onSubmit={(e: any) => onSubmitChange(e)}
                />

                {formReady && (
                    <Tooltip
                        position="bottom"
                        target={'.tooltip_BillingEmailTo'}
                        content={
                            "Used only for Sage integration. Invoices will be sent to the contact's billing email."
                        }
                    />
                )}
            </div>
        </div>
    );
};

export const billingInfoUpdateStore = (
    updatedFormData: any,
    isValid = true,
    CompanyModuleData: StepperModuleStoreData<CompanyFormData>,
    companyStore: StepperStoreState<CompanyFormData>
) => {
    // updateFormData(updatedFormData);
    const updatedBillingInfoFormData = {
        ...CompanyModuleData.formData,
        companyProfilePage:
            CompanyModuleData.formData.companyProfilePage ||
            companyStore.getData().formData.companyProfilePage,
        billingInfoPage: updatedFormData
    };

    companyStepperStore.updatePage('formData', updatedBillingInfoFormData);
    // updateIsFormValid(isValid);
    const updatedBillingInfoIsFormValid = {
        ...CompanyModuleData.isFormValid,
        [PATHS.BILLING_INFO]: isValid
    };

    companyStepperStore.updatePage('isFormValid', updatedBillingInfoIsFormValid);
};
export default BillingInfo;
