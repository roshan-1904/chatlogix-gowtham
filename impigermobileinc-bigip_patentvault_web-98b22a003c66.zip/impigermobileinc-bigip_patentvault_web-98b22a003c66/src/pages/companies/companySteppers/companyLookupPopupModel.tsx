import { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
    SageCompanyDetails,
    SageCompanyFilterQueryParams
} from 'pages/companies/types/createCompany.types';
import companiesService from 'pages/companies/service/companies.service';
import { useDebouncedWaitCallback } from 'core/utils/utils';
import { generateSageCompanyFormData } from 'pages/companies/utils/createCompanyUtils';
import PopupModal from 'components/popupModal/popupModal';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';

const CompanyLookupPopupModel = () => {
    const { t } = useTranslation();

    const [sageCompanyList, setSageCompanyList] = useState<SageCompanyDetails[]>([]);
    const [searchCompanyFilterValue, setSearchCompanyFilterValue] = useState('');
    const [isSageCompanyLoader, setIsSageCompanyLoader] = useState(true);
    const [checkedClassName, setCheckedClassName] = useState('');
    const [selectedSageCompanyDetail, setSelectedSageCompanyDetail] = useState<any>(null);

    const openModal = () => {
        handleToggleModal(false);
    };

    const element: HTMLDialogElement | null = document.getElementById(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        TABLE_POP_IDS.CREATE_POPUP.COMPANY_LOOKUP_INFORMATION_POPUP_ICON
    ) as HTMLDialogElement | null;

    if (element) {
        element.onclick = () => openModal();
    }

    const HandleFilterChange = useCallback((event: React.ChangeEvent<HTMLInputElement>): void => {
        const value: string = event.target.value || '';
        setSearchCompanyFilterValue(value);
        onFilterChange(value);
    }, []);

    const handleToggleModal = async (isShow: boolean = false) => {
        try {
            const modal: HTMLDialogElement | null = document.getElementById(
                // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                TABLE_POP_IDS.CREATE_POPUP.COMPANY_LOOKUP_INFORMATION_POPUP_MODAL
            ) as HTMLDialogElement | null;
            if (modal) {
                if (isShow) {
                    modal.close();
                } else {
                    modal.show();
                    await getSageCompanyList();
                }
            }
        } catch (error) {
            console.error('Error opening modal:', error);
        }
    };

    const close = () => {
        setSelectedSageCompanyDetail({});
        setCheckedClassName('');
        setSearchCompanyFilterValue('');
        setSageCompanyList([]);
        handleToggleModal(true);
    };

    const handleSubmit = () => {
        generateSageCompanyFormData(selectedSageCompanyDetail as SageCompanyDetails);
        close();
    };

    const getSageCompanyList = async (filterData?: SageCompanyFilterQueryParams) => {
        try {
            setIsSageCompanyLoader(true);
            // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
            setSageCompanyList(await companiesService.getSageCompanyList(filterData));
        } catch (error) {
            if (!sageCompanyList?.length) {
                setSageCompanyList([]);
            }
        }
        setIsSageCompanyLoader(false);
    };

    const onFilterChange = useDebouncedWaitCallback((value: string): void => {
        const filterData: SageCompanyFilterQueryParams = {
            filterQuery: value || ''
        };
        getSageCompanyList(filterData).catch((error) => {
            console.error('Error fetching company list:', error);
        });
    }, 1000);

    const renderNoResult = () => {
        return !isSageCompanyLoader && sageCompanyList?.length === 0 ? (
            <tr>
                <td className="text-center p-4s" colSpan={4}>
                    No Result Found
                </td>
            </tr>
        ) : (
            ''
        );
    };

    return (
        <PopupModal
            id={TABLE_POP_IDS.CREATE_POPUP.COMPANY_LOOKUP_INFORMATION_POPUP_MODAL}
            title={t('COMPANIES.SEARCH_COMPANY')}
            onClose={() => close()}
            createButtonText={t('COMMON.CONFIRM')}
            resetButtonText={t('COMMON.CANCEL')}
            isEdit={true}
            skipValidation={true}
            onSubmit={handleSubmit}>
            <div className="p-4 bg-neutral-bg h-80 overflow-y-scroll company_lookup_information_popup_modal_style">
                <label className="search-company-label rounded-md gap-2 bg-primary-50 input input-bordered w-3/4 h-9 border-[0.02rem]  focus-within:outline-none border-neutral-100 focus:border-primary focus-within:border-primary flex items-center">
                    <input
                        data-testid={'filter-search-company'}
                        type="text"
                        className="grow font-medium text-sm text-black"
                        placeholder="Search Company"
                        value={searchCompanyFilterValue}
                        onChange={HandleFilterChange}
                    />
                    <i className="pi pi-search text-xxs text-neutral-200"></i>
                </label>
                <div className="cutomizedPopupTableStyle">
                    <table>
                        <tr>
                            <th>BLS ID</th>
                            <th>Company name</th>
                            <th>Parent name</th>
                            <th>Entity</th>
                        </tr>
                        {sageCompanyList?.length
                            ? sageCompanyList.map((sageCompany: any, index) => {
                                  return (
                                      <tr
                                          className={`${checkedClassName === sageCompany.companyId ? '!bg-primary-50' : ''}`}
                                          key={`${index}-${sageCompany?.companyName}`}
                                          onKeyDown={(e) => {
                                              if (e.key === 'Enter' || e.key === ' ') {
                                                  setSelectedSageCompanyDetail(sageCompany);
                                              }
                                          }}
                                          data-testid={'company-lookup-row-' + index}
                                          onClick={() => {
                                              setSelectedSageCompanyDetail(sageCompany);
                                          }}>
                                          <td>
                                              {sageCompany.companyId ? (
                                                  <div
                                                      key={sageCompany.companyId}
                                                      onClick={() => {
                                                          setCheckedClassName(
                                                              (sageCompany?.companyId ||
                                                                  '') as string
                                                          );
                                                      }}
                                                      data-testid={
                                                          'company-lookup-line-' +
                                                          sageCompany?.companyId
                                                      }
                                                      onKeyDown={(e) => {
                                                          if (e.key === 'Enter' || e.key === ' ') {
                                                              setCheckedClassName(
                                                                  (sageCompany?.companyId ||
                                                                      '') as string
                                                              );
                                                          }
                                                      }}
                                                      tabIndex={0}>
                                                      <div className="form-control">
                                                          <label className="label cursor-pointer flex items-center !justify-normal gap-2">
                                                              <input
                                                                  type="radio"
                                                                  name="radio-1"
                                                                  className="radio border h-5 w-5 border-neutral-200 checked:bg-primary"
                                                                  checked={
                                                                      checkedClassName ===
                                                                      sageCompany.companyId
                                                                  }
                                                              />
                                                              <span className="label-text text-base font-medium">
                                                                  {sageCompany.companyId}
                                                              </span>
                                                          </label>
                                                      </div>
                                                  </div>
                                              ) : (
                                                  '-'
                                              )}
                                          </td>
                                          <td>{sageCompany.companyName}</td>
                                          <td>
                                              {sageCompany.parentCompanyName
                                                  ? sageCompany.parentCompanyName
                                                  : '-'}
                                          </td>
                                          <td>
                                              {sageCompany.entityId ? sageCompany.entityId : '-'}
                                          </td>
                                      </tr>
                                  );
                              })
                            : renderNoResult()}
                    </table>
                </div>
            </div>
        </PopupModal>
    );
};

export default CompanyLookupPopupModel;
