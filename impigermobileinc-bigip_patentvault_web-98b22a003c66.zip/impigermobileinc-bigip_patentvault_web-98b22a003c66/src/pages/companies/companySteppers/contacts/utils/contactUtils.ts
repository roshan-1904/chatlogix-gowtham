import { UserType, stepperMode } from 'pages/users/constant/user.constant';
import { CreateUserPayloadType } from 'pages/users/types/createUser.types';
import { TFunction } from 'i18next';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { Country, CreateContactModal, State } from 'pages/companies/types/createCompany.types';

export const buildUserData = (
    contactUserData: CreateContactModal,
    contactUserId?: number | undefined
): CreateUserPayloadType => {
    return {
        id: contactUserId ?? undefined,
        firstName: contactUserData.firstName,
        middleName: contactUserData.middleName,
        lastName: contactUserData.lastName,
        email: contactUserData.email,
        companyIds:
            contactUserData.company?.toString() ??
            companyStepperStore.getData()?.stepperInfo?.primaryId ??
            null,
        roleId: +contactUserData.role || null,

        projectManagers: contactUserData.projectManagers.join(','),
        comments: contactUserData.comments,
        userTypeId: UserType.ContactUser,
        userContactInformation: {
            mainPhone: contactUserData?.mainphone,
            officePhone: contactUserData.officePhone,
            extension: contactUserData.extension?.toString() || null,
            salesRep: parseInt(contactUserData?.salesRep, 10),
            linkedInUrl: contactUserData.linkedInUrl,
            mobilePhone: contactUserData?.mobilePhone,
            homePhone: contactUserData?.homePhone
        },
        mailingAddressModel: {
            address1: contactUserData.address1,
            address2: contactUserData.address2,
            city: contactUserData.city,
            state: contactUserData?.state?.name || '',
            stateId: contactUserData?.state?.id || 0,
            country: contactUserData.country?.name + ` (${contactUserData.country?.code})` || '',
            countryId: contactUserData?.country?.id || 0,
            zip: contactUserData.zip,
            billingEmail: contactUserData.billingEmail,
            isSameAddress: contactUserData?.sameAsMailing
        },
        userBillingAddressModel: {
            address1: contactUserData.baddress1,
            address2: contactUserData.baddress2,
            city: contactUserData.bcity,
            state: contactUserData?.bstate?.name || '',
            stateId: contactUserData?.bstate?.id || 0,
            country: contactUserData.bcountry?.name + ` (${contactUserData.bcountry?.code})` || '',
            countryId: contactUserData?.bcountry?.id || 0,
            zip: contactUserData.bzip,
            billingEmail: contactUserData.billingEmail,
            isSameAddress: contactUserData?.sameAsMailing,
            billingEmailCC: contactUserData?.billingEmailCC
        }
    };
};

export const buildUserDataFromAPI = (
    response: any,
    mode: stepperMode,
    country: Country | null,
    state: State | null,
    bcountry: Country | null,
    bstate: State | null
): CreateContactModal => {
    return {
        mode,
        firstName: response.firstName,
        middleName: response.middleName || '',
        lastName: response.lastName,
        email: response.email,
        company: response.companyIds ? response.companyIds.split(',').map(Number) : [],
        role: response.roleId.toString(),
        projectManagers: response.projectManagers
            ? response.projectManagers.split(',').map(Number)
            : [],
        comments: response.comments,
        mainphone: response?.userContactInformation?.mainPhone,
        officePhone: response.userContactInformation.officePhone,
        extension: response.userContactInformation.extension?.toString() ?? null,
        salesRep: response.userContactInformation.salesRep?.toString() || '',
        linkedInUrl: response.userContactInformation.linkedInUrl,
        mobilePhone: response.userContactInformation.mobilePhone,
        homePhone: response.userContactInformation.homePhone,
        address1: response.mailingAddressModel.address1,
        address2: response.mailingAddressModel.address2,
        city: response.mailingAddressModel.city,
        state,
        country,
        zip: response.mailingAddressModel.zip,
        billingEmail: response.userBillingAddressModel.billingEmail,
        billingEmailCC: response.userBillingAddressModel.billingEmailCC,
        baddress1: response.userBillingAddressModel.address1,
        baddress2: response.userBillingAddressModel.address2,
        bcity: response.userBillingAddressModel.city,
        bstate,
        bcountry,
        bzip: response.userBillingAddressModel.zip,
        sameAsMailing: response?.mailingAddressModel?.isSameAddress
    };
};

export const getHeaderTitleAndStepperMode = (
    t: TFunction,
    isFromEdit: boolean,
    isFromView: boolean
): { headerTitle: string; cancelBtnTitle: string; saveBtnTitle: string; mode: stepperMode } => {
    const { CREATE, VIEW, EDIT } = stepperMode;
    let headerTitle: string;
    let cancelBtnTitle: string;
    let saveBtnTitle: string;
    let mode: stepperMode;

    if (isFromEdit) {
        headerTitle = t('COMPANIES.CONTACTS.EDIT_CONTACT');
        cancelBtnTitle = t('COMMON.CANCEL');
        saveBtnTitle = t('COMMON.UPDATE');
        mode = EDIT;
    } else if (isFromView) {
        headerTitle = t('COMPANIES.CONTACTS.VIEW_CONTACT');
        cancelBtnTitle = t('COMMON.CANCEL');
        saveBtnTitle = t('COMMON.SAVE');
        mode = VIEW;
    } else {
        headerTitle = t('COMPANIES.CONTACTS.CREATE_CONTACT');
        cancelBtnTitle = t('COMMON.CLEAR');
        saveBtnTitle = t('COMMON.SAVE');
        mode = CREATE;
    }

    return { headerTitle, cancelBtnTitle, saveBtnTitle, mode };
};
