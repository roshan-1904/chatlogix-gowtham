import { useLocation } from 'react-router-dom';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    SearchModel,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS } from '../../../../constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';
import { useEffect, useLayoutEffect, useState } from 'react';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import {
    GetUsersListApiResponse,
    UserDataItem,
    UserProjectManager
} from 'pages/users/types/users.types';
import usersService from 'pages/users/service/users.service';
import { isProjectManagerArray } from 'pages/users/users';
import CreateContact from './createContact';
import {
    CONTACT_STEPPER_ACTIONS,
    ContactUserProperty
} from 'pages/companies/constants/companyStepper.constant';
import { customTableStyle } from 'constants/styles.constant';
import tasksIcon from 'assets/images/tasks-icon.png';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { DataTableSelectEvent } from 'primereact/datatable';
export interface ShowContactForm {
    visible: boolean;
    mode: CONTACT_STEPPER_ACTIONS;
}
export default function Contacts() {
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;
    const [toggleRowData, setToggleRowData] = useState<UserDataItem>();
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [showContactForm, setShowContactForm] = useState<ShowContactForm>({
        visible: false,
        mode: CONTACT_STEPPER_ACTIONS.CREATE
    });

    const [tableData, setTableData] = useState<UserDataItem[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [emptyMessage, setEmptyMessage] = useState({ isError: false, errMsg: ' ' });
    const toastMessages = {
        markActive: {
            SUCCESS_MESSAGE: t('USERS.MARK_ACTIVE.SUCCESS_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('USERS.MARK_INACTIVE.SUCCESS_MESSAGE')
        }
    };
    const emptyMsg = t('COMPANIES.CONTACTS.NO_CONTACT_FOUND');
    const isFromView = pathname?.includes(CONTACT_STEPPER_ACTIONS.VIEW as string);

    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const createSearchModel = (propertyName: string, value: string): SearchModel => ({
        propertyName,
        value
    });

    const getCompanyIdModel = (): SearchModel =>
        createSearchModel(
            ContactUserProperty?.COMPANY_ID,
            companyStepperStore.getData()?.stepperInfo?.primaryId?.toString() ?? ''
        );

    const getAllUsersList = async (body: RequestBody) => {
        setIsLoading(true);
        try {
            const updatedRequestBody: RequestBody = {
                ...body,
                searchModels: [...body.searchModels, getCompanyIdModel()]
            };
            const response: GetUsersListApiResponse =
                await usersService.getTableData<GetUsersListApiResponse>(updatedRequestBody);
            const formattedResponse: UserDataItem[] = response?.userDetails.map(
                (userDetail: UserDataItem) => {
                    if (
                        typeof userDetail.taskName === 'string' &&
                        userDetail.taskName.trim() !== ''
                    ) {
                        userDetail.taskName = userDetail.taskName
                            .split(',')
                            .map((item) => item.trim());
                    }
                    if (
                        typeof userDetail.languageCombination === 'string' &&
                        userDetail.languageCombination.trim() !== ''
                    ) {
                        userDetail.languageCombination = userDetail.languageCombination
                            .split(',')
                            .map((item) => item.trim());
                    }
                    if (
                        typeof userDetail.translationTool === 'string' &&
                        userDetail.translationTool.trim() !== ''
                    ) {
                        userDetail.translationTool = userDetail.translationTool
                            .split(',')
                            .map((item) => item.trim());
                    }
                    if (
                        Array.isArray(userDetail.projectManager) &&
                        userDetail.projectManager.length > 0
                    ) {
                        if (
                            isProjectManagerArray(userDetail.projectManager as UserProjectManager[])
                        ) {
                            userDetail.projectManager = userDetail.projectManager.map((manager) =>
                                typeof manager !== 'string' ? manager.name : manager
                            );
                        }
                    }

                    return userDetail;
                }
            );
            setTableData(formattedResponse);

            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.total / body.pageCount),
                totalRecords: response.total
            };
            setPaginationInfo(pagination);
            setIsLoading(false);
            setTimeout(() => {
                if (!tableData?.length)
                    setEmptyMessage((prev) => ({
                        ...prev,
                        errMsg: emptyMsg
                    }));
            }, 1);
        } catch (error) {
            console.error('Error in Companies info fetch:', error);
            setEmptyMessage((prev) => ({
                ...prev,
                isError: true,
                errMsg: emptyMsg
            }));
            setIsLoading(false);
        }
    };

    const postChangeStatus = async (userId: number, isActive: boolean) => {
        try {
            const response: boolean = await usersService.updateChangeStatus<boolean>(
                userId,
                isActive
            );
            if (response) {
                getAllUsersList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
            // Handle response data as needed
        } catch (error) {
            console.error('Error updating status:', error);
            showToastMessage({
                type: ToastType.ERROR,
                message: error as string
            });
        }
    };

    const buttonChildren = () => {
        return (
            <button
                onClick={() => {
                    setShowContactForm((prev) => ({
                        ...prev,
                        visible: true
                    }));
                }}
                onKeyDown={(event) => {
                    if (event.key === 'Enter') {
                        setShowContactForm((prev) => ({
                            ...prev,
                            visible: true
                        }));
                    }
                }}
                className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMPANIES.CONTACTS.CREATE_CONTACT')}
            </button>
        );
    };

    const setContactFormData = (mode: ShowContactForm['mode']) => {
        setShowContactForm((prev) => ({
            ...prev,
            mode,
            visible: true
        }));
    };

    const menuItems: MenuItem[] = [
        {
            items: [
                !isFromView && {
                    label: t('COMMON.EDIT'),
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {
                        setContactFormData(CONTACT_STEPPER_ACTIONS.EDIT);
                    }
                },
                !isFromView && {
                    label: t(
                        `COMMON.MARK_AS_${toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString() ? 'INACTIVE' : 'ACTIVE'}`
                    ),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header: t(
                                    `COMMON.MARK_AS_${toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString() ? 'INACTIVE' : 'ACTIVE'}`
                                ),
                                subHeader: toggleRowData.firstName,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status: t(
                                        `COMMON.${toggleRowData.active === ActiveStatusEnum.ACTIVE.toString() ? 'INACTIVE' : 'ACTIVE'}`
                                    ),
                                    table_name: t('USERS.USERS').toLowerCase()
                                })
                            });
                        }
                    }
                }
            ].filter(Boolean) as MenuItem[] | MenuItem[][]
        }
    ];

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                +toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'firstName',
            header: 'First Name',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'lastName',
            header: 'Last Name',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'email',
            header: 'Email',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Link',
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'role',
            header: 'Role',
            sortable: true,
            filter: true,
            filterType: 'Dropdown',
            valueType: 'Text',
            columnNumber: 3,
            visibility: true,
            filterDropDownOptions: [
                { label: 'ContactManager', value: 'contactmanager' },
                { label: 'ContactUser', value: 'contactuser' }
            ]
        },
        {
            field: 'projectManager',
            header: 'Project Managers',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'MultiSelect',
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'billingEmail',
            header: 'Billing Email',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Link',
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'active',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: 'Dropdown',
            valueType: 'StatusDots',
            columnNumber: 6,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Active',
                    value: 'Active'
                },
                {
                    label: 'Inactive',
                    value: 'Inactive'
                }
            ]
        },
        {
            field: 'mainPhone',
            header: 'Main Phone',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'PhoneNumber',
            columnNumber: 7,

            visibility: false
        },
        {
            field: 'address1',
            header: 'Address 1',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'PhoneNumber',
            columnNumber: 8,

            visibility: false
        },
        {
            field: 'country',
            header: 'Country',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 9,
            visibility: false
        },
        {
            field: 'state',
            header: 'State',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 10,
            visibility: false
        },
        {
            field: 'city',
            header: 'City',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 11,
            visibility: false
        },
        {
            field: 'zip',
            header: 'Zip',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 12,
            visibility: false
        },
        {
            field: 'createdBy',
            header: 'Created By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 13,
            visibility: false
        },
        {
            field: 'createdAt',
            header: 'Created At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 14,
            visibility: false
        },
        {
            field: 'updatedBy',
            header: 'Updated By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 15,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 16,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 17,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: 'Deleted At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 18,
            visibility: false
        },
        {
            field: 'restoredBy',
            header: 'Restored By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 19,
            visibility: false
        },
        {
            field: 'restoredAt',
            header: 'Restored At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 20,
            visibility: false
        },
        {
            field: 'action',
            header: 'Action',
            sortable: false,
            filter: false,
            frozen: true,
            filterType: 'Text',
            valueType: 'Action',
            columnNumber: 21,
            visibility: true,
            className: 'w-40 !z-10'
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.USER_TABLE,
        title: t('COMPANIES.CONTACTS.TITLE'),
        ...(isFromView && { columnSelectorStyle: 'left-0 md:-left-40' }),
        emptyMessage: emptyMessage?.errMsg,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.CONTACT_USER_LIST,
        ...(!isFromView && { buttonChildren: buttonChildren() }),
        items: menuItems,
        hideTableExport: false,
        customTablePT: {
            ...customTableStyle(),
            wrapper: { className: `${customTableStyle().wrapper.className} !max-h-[40%]` }
        },
        columns: !isFromView
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    useLayoutEffect(() => {
        getAllUsersList(requestBody);
    }, [requestBody]);

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const renderEmptyContact = () => {
        return (
            <div data-testid="emptyContactList" className="tableComponent">
                <div className="bg-white rounded-lg m-4 mx-6 p-4">
                    <div className="min-h-[calc(100vh-150px)] flex flex-col align-middle justify-center">
                        <div className="text-center">
                            <img
                                className="inline-block py-6 cursor-pointer"
                                src={tasksIcon}
                                alt="Tasks"
                            />
                            <h1 className="text-xl my-2 font-bold">
                                {t('COMPANIES.CONTACTS.EMPTY_CONTACT_LIST')}
                            </h1>
                            <p className="text-sm my-3 text-slate-700">
                                {t('COMPANIES.CONTACTS.CREATE_CONTACT_DESCRIPTION')}
                            </p>
                            <div className="mt-6">{buttonChildren()}</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    const isEmptyContact = () => {
        return (
            !tableData?.length &&
            !isFromView &&
            !requestBody?.searchModels?.some(
                ({ propertyName }) => propertyName !== ContactUserProperty?.COMPANY_ID
            ) &&
            !isLoading &&
            !emptyMessage?.isError
        );
    };
    const onRowClicked = (e: DataTableSelectEvent) => {
        setContactFormData(CONTACT_STEPPER_ACTIONS.VIEW);
        setToggleRowData(e?.data as UserDataItem);
    };
    const renderTable = () => {
        return isEmptyContact() ? (
            renderEmptyContact()
        ) : (
            <div className="contactUserTableStyle">
                <DataTableComponent
                    tableData={tableData}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    handleFilter={handleFilter}
                    handleSort={sortHandler}
                    toggleRowData={(rowData) => {
                        setToggleRowData(rowData as UserDataItem);
                    }}
                    tablePaginationData={paginationInfo}
                    handlePagination={handlePageChange}
                    onRowClicked={onRowClicked}
                />
            </div>
        );
    };
    return (
        <div className="p-4 pt-0">
            {!showContactForm?.visible ? (
                <>
                    {showPopup.visible && (
                        <ConfirmationPopup
                            onConfirm={() => handleConfirm()}
                            onCancel={() => handleCancel()}
                            visible={showPopup.visible}
                            headerText={showPopup.header}
                            subHeaderText={showPopup.subHeader}
                            description={showPopup.description}
                        />
                    )}
                    {renderTable()}
                </>
            ) : (
                <CreateContact
                    selectedContactUser={toggleRowData}
                    setSelectedContactUser={setToggleRowData}
                    refetchContactList={() => getAllUsersList(requestBody)}
                    {...{ showContactForm, setShowContactForm }}
                />
            )}
        </div>
    );
}
