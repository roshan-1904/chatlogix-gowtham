import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';

import contactFormBuilderData from '../../mocks/contacts.mock.json';
import { PATHS } from 'constants/routes.constant';
import HttpService from 'core/interceptor/api.handler';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { useLocation } from 'react-router-dom';
import { CreateUserPayloadType } from 'pages/users/types/createUser.types';
import usersService from 'pages/users/service/users.service';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import {
    deepEqualValuesOnly,
    focusOnFirstError,
    isDataEmpty,
    showToastMessage
} from 'core/utils/utils';
import {
    buildUserData,
    buildUserDataFromAPI,
    getHeaderTitleAndStepperMode
} from './utils/contactUtils';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { ShowContactForm } from './contactsList';
import { UserDataItem } from 'pages/users/types/users.types';
import { CONTACT_STEPPER_ACTIONS } from 'pages/companies/constants/companyStepper.constant';
import companiesService from 'pages/companies/service/companies.service';
import { CreateContactModal } from 'pages/companies/types/createCompany.types';

interface CreateContact {
    selectedContactUser?: UserDataItem;
    showContactForm: ShowContactForm;
    setShowContactForm: Dispatch<SetStateAction<ShowContactForm>>;
    setSelectedContactUser: Dispatch<SetStateAction<UserDataItem | undefined>>;
    refetchContactList: () => Promise<void>;
}
export default function CreateContact({
    showContactForm,
    setShowContactForm = () => {},
    setSelectedContactUser = () => {},
    refetchContactList,
    selectedContactUser
}: Readonly<CreateContact>) {
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;
    const id = selectedContactUser?.id ?? null;
    const isEditMode = showContactForm?.mode === CONTACT_STEPPER_ACTIONS?.EDIT;
    const isReadOnly: boolean = [pathname, showContactForm.mode]?.includes(
        CONTACT_STEPPER_ACTIONS.VIEW
    );
    const { headerTitle, cancelBtnTitle, saveBtnTitle, mode } = getHeaderTitleAndStepperMode(
        t,
        isEditMode,
        isReadOnly
    );
    const [companyStoreModuleData, setCompanyStoreModuleData] = useState(
        companyStepperStore.getData()
    );

    const [defaultUserData, setDefaultUserData] = useState(
        companyStoreModuleData?.formData.contacts
    );

    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(contactFormBuilderData);

    companyStepperStore.subscribe(setCompanyStoreModuleData);

    const [showModal, setShowModal] = useState<boolean>(false);

    const initialData = {
        data: {
            ...companyStoreModuleData?.formData.contacts
        }
    };

    const isFormValuesUpdated =
        defaultUserData || companyStoreModuleData?.formData.contacts || {}
            ? !deepEqualValuesOnly(defaultUserData as object, {
                  ...(companyStoreModuleData?.formData?.contacts as object),
                  extension: companyStoreModuleData?.formData?.contacts?.extension || null
              })
            : false;

    const onSubmitChange = (e: any) => {
        /** note: this submit function will be only call when user clicks the 'next' button without any field error.\
             if error means, this function will not be call, rather than form-builder trigger the fields validation (errors). */
        const updatedFormData = e.data;
        updateStore(updatedFormData);
    };

    const onFormChange = (e: any) => {
        const { data } = e;
        const updatedForm = data;
        const fetchFormData = companyStoreModuleData.formData.contacts;
        if (e.changed && JSON.stringify(updatedForm) !== JSON.stringify(fetchFormData)) {
            /** set always 'isFormValid' to false when form on change. \
                 we set true user once submitted. we can use this for navigation\other purpose.
                 because, the form builder returns 'isValid' flag as true even form is invalid while init rendering.
                 so we handled like this. */
            updateStore(updatedForm, false);
        }
    };

    // update store
    const updateStore = (updatedFormData: any, isValid = true) => {
        updateFormData(updatedFormData);
        updateIsFormValid(isValid);
    };
    const updateFormData = (updatedFormData: any) => {
        const updatedCompanyFormData = {
            ...companyStoreModuleData.formData,
            contacts: updatedFormData
        };

        companyStepperStore.updatePage('formData', updatedCompanyFormData);
    };
    const updateIsFormValid = (isValid: boolean) => {
        const updatedCompanyIsFormValid = {
            ...companyStoreModuleData.isFormValid,
            [PATHS.CONTACTS]: isValid
        };

        companyStepperStore.updatePage('isFormValid', updatedCompanyIsFormValid);
    };

    const clearSelectedContact = () => {
        if (selectedContactUser) {
            setSelectedContactUser(undefined);
        }
    };

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                if (!id) {
                    throw new Error('User ID is missing! Please check your URL.');
                }
                const userId = parseInt(`${id}`.replace(/\D/g, ''), 10);
                if (isNaN(userId)) {
                    throw new Error('Invalid user ID! Please check your URL.');
                }
                const response = await usersService.getUserById<CreateUserPayloadType>(userId);
                if (response) {
                    const mailingCountryId: number = response.mailingAddressModel?.countryId ?? 0;
                    const mailingStateId: number = response.mailingAddressModel?.stateId ?? 0;
                    const { country, state } = await companiesService.getCountryAndState(
                        mailingCountryId,
                        mailingStateId
                    );
                    const billingCountryId: number =
                        response.userBillingAddressModel?.countryId ?? 0;
                    const billingStateId: number = response.userBillingAddressModel?.stateId ?? 0;
                    const { country: bCountry, state: bState } =
                        await companiesService.getCountryAndState(billingCountryId, billingStateId);
                    // Assuming you have a function to update the store with user data
                    if (response?.id) {
                        updateStore(
                            buildUserDataFromAPI(response, mode, country, state, bCountry, bState)
                        );
                        setDefaultUserData(
                            buildUserDataFromAPI(response, mode, country, state, bCountry, bState)
                        );
                    }
                }
            } catch (error) {
                console.error('Error fetching user data:', error);
            }
        };
        // Call the fetchUserData function when the component mounts
        if (id && (isReadOnly || isEditMode)) {
            fetchUserData();
        }
    }, [id]); // Execute the effect whenever user_id changes

    useEffect(() => {
        updateIsFormValid(false);
        const stepperButtonContainer = document.getElementById('stepper-button-container');
        const scrollTarget = document.getElementById('scrollTarget');
        if (stepperButtonContainer && showContactForm && pathname?.includes(PATHS.CONTACTS)) {
            stepperButtonContainer.style.display = 'none';
        }
        if (scrollTarget) {
            scrollTarget.classList.add('create-contact');
        }
        window.scrollTo(0, 0);
        return () => {
            if (stepperButtonContainer) stepperButtonContainer.style.display = 'block';
            scrollTarget?.classList.remove('create-contact');
            updateIsFormValid(true);
        };
    }, []);

    const createUser = async (userData: CreateUserPayloadType) => {
        try {
            const response = await usersService.createUser<CreateUserPayloadType>(userData);
            if (response) {
                // Optionally handle response data if needed
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('COMPANIES.CONTACTS.CONTACT_CREATED_SUCCESSFULLY')
                });
                clearSelectedContact();
                updateStore(null, false);
                setShowContactForm((prev) => ({
                    ...prev,
                    mode: CONTACT_STEPPER_ACTIONS.CREATE,
                    visible: false
                }));
                refetchContactList();
            }
        } catch (error) {
            console.error('Error creating user:', error);
        }
    };

    const handleBack = () => {
        if (isReadOnly) {
            setShowContactForm((prev) => ({
                ...prev,
                mode: CONTACT_STEPPER_ACTIONS.CREATE,
                visible: false
            }));
            updateStore(null, false);
        } else {
            setShowModal(true);
        }
    };

    const saveUser = async (userId: number, userData: CreateUserPayloadType) => {
        try {
            const response = await usersService.updateUser<CreateUserPayloadType>(userId, userData);
            if (response) {
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('COMPANIES.CONTACTS.CONTACT_UPDATED_SUCCESSFULLY')
                });
                updateStore(null, false);
                clearSelectedContact();
                setShowContactForm((prev) => ({
                    ...prev,
                    mode: CONTACT_STEPPER_ACTIONS.CREATE,
                    visible: false
                }));
                refetchContactList();
            }
        } catch (error) {
            console.error('Error updating user:', error);
        }
    };

    const handleCreateContact = async () => {
        const isFormValid = async (): Promise<boolean> => {
            document.getElementById('submit-contacts')?.click();
            await new Promise((r) => setTimeout(r, 100));
            const updatedCompanyStepperStore = companyStepperStore.getData();
            return updatedCompanyStepperStore.isFormValid[PATHS.CONTACTS] ?? false;
        };
        if (await isFormValid()) {
            const data = companyStepperStore.getData();
            // Extract relevant information to create user data
            const { formData } = data;
            const { contacts } = formData;
            const userData = buildUserData(contacts as CreateContactModal, selectedContactUser?.id);
            selectedContactUser?.id && isEditMode
                ? saveUser(selectedContactUser?.id, userData)
                : createUser(userData);
        }
    };

    const handleClear = () => {
        if (isEditMode) {
            updateStore(defaultUserData);
        } else {
            updateStore(null, false);
        }
    };

    const isDisabled = () => {
        const isFormUpdated = formContact ? isDataEmpty(formContact, true) : true;
        return isEditMode ? !isFormValuesUpdated : isFormUpdated;
    };

    const formContact = companyStepperStore.getData()?.formData.contacts;

    return (
        <div>
            <div className="sticky top-0 z-50 bg-white flex justify-between items-center h-full p-3 px-1 pt-4 border-b border-neutral-900">
                <div
                    className="flex items-center cursor-pointer"
                    role="button"
                    tabIndex={0}
                    onClick={handleBack}
                    data-testid="back-button"
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            setShowModal(true);
                        }
                    }}>
                    <i className="pi pi-chevron-left text-base mr-2" />
                    <h6 className="font-medium text-lg">{headerTitle}</h6>
                </div>
                {!isReadOnly && (
                    <div className="flex gap-2">
                        <button
                            disabled={isDisabled()}
                            className={`btn btn-sm button-neutral font-medium ${isDisabled() ? '!opacity-50 cursor-not-allowed' : ''}`}
                            onClick={handleClear}
                            data-testid="clear-button"
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    handleClear();
                                }
                            }}>
                            {cancelBtnTitle}
                        </button>
                        <button
                            disabled={isEditMode ? !isFormValuesUpdated : false}
                            onClick={() => {
                                handleCreateContact().catch(console.error);
                            }}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    handleCreateContact().catch(console.error);
                                }
                            }}
                            data-testid="save-button"
                            className={`btn btn-sm button-primary font-medium`}>
                            {saveBtnTitle}
                        </button>
                    </div>
                )}
            </div>
            {showModal && (
                <ConfirmationPopup
                    onConfirm={() => {
                        setShowContactForm((prev) => ({
                            ...prev,
                            mode: CONTACT_STEPPER_ACTIONS.CREATE,
                            visible: false
                        }));
                        clearSelectedContact();
                        updateStore(null, false);
                        refetchContactList();
                    }}
                    onCancel={() => setShowModal(false)}
                    visible={showModal}
                    headerText={t('COMMON.CONFIRMATION')}
                    description={t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')}
                    acceptLabel={t('COMMON.YES_DISCARD')}
                    rejectLabel={t('COMMON.NO_DON_T')}
                    rejectClassName={'!bg-error !px-6 !text-white'}
                    acceptClassName={'!bg-neutral-50 !px-5 !text-black !border-neutral-100'}
                />
            )}
            <div className="py-2">
                <Form
                    form={formBuilderData}
                    options={{
                        readOnly: isReadOnly ?? false
                    }}
                    submission={initialData}
                    onChange={(e: any) => onFormChange(e)}
                    onSubmit={(e: any) => onSubmitChange(e)}
                    onError={focusOnFirstError}
                />
            </div>
        </div>
    );
}
