import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Contacts from '../contactsList';
import usersService from 'pages/users/service/users.service';
import { useTranslation } from 'react-i18next';
import MockContactList from '../../../data/mockContactList.json';
import {
    buildUserData,
    buildUserDataFromAPI,
    getHeaderTitleAndStepperMode
} from '../utils/contactUtils';
import { stepperMode } from 'pages/users/constant/user.constant';
import { TFunction } from 'i18next';
import { Country, CreateContactModal, State } from 'pages/companies/types/createCompany.types';
import { CreateUserPayloadType } from 'pages/users/types/createUser.types';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({
        pathname: '/contacts'
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('pages/users/service/users.service');

jest.mock('core/store/notificationStore/notificationStore', () => ({
    __esModule: true,
    default: {
        showAlert: jest.fn()
    }
}));

jest.mock('core/interceptor/api.handler');

describe('Contacts Component', () => {
    const { t } = useTranslation();
    const mockGetTableData = usersService.getTableData as jest.Mock;

    beforeEach(() => {
        (usersService.getTableData as jest.Mock).mockResolvedValue(MockContactList);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('should render the component and fetch user list', async () => {
        mockGetTableData.mockResolvedValue({
            userDetails: [],
            total: 0
        });

        render(<Contacts />);

        expect(screen.getByText(t('COMPANIES.CONTACTS.TITLE'))).toBeInTheDocument();
        await waitFor(() => {
            expect(mockGetTableData).toHaveBeenCalled();
        });
    });

    test('should show empty contact list message when no contacts are available', async () => {
        mockGetTableData.mockResolvedValue({
            userDetails: [],
            total: 0
        });

        render(<Contacts />);

        await waitFor(() => {
            expect(
                screen.getByText(t('COMPANIES.CONTACTS.EMPTY_CONTACT_LIST'))
            ).toBeInTheDocument();
        });
    });

    test('renders table with correct data', async () => {
        mockGetTableData.mockResolvedValue(MockContactList);
        const { firstName, lastName, email } = MockContactList.userDetails[0];
        render(<Contacts />);
        await waitFor(() => {
            [firstName, lastName, email].forEach((field) => {
                expect(screen.getByText(field)).toBeInTheDocument();
            });
        });
    });

    test('should open create contact form', async () => {
        render(<Contacts />);

        fireEvent.click(screen.getByText(t('COMPANIES.CONTACTS.CREATE_CONTACT')));

        await waitFor(() => {
            expect(screen.getByText(t('COMPANIES.CONTACTS.CREATE_CONTACT'))).toBeInTheDocument();
        });
    });

    test('handles pagination', async () => {
        render(<Contacts />);

        // Simulate clicking the "Last Page" button (>>)
        await waitFor(() => {
            fireEvent.click(screen.getByLabelText('Last Page'));
        });

        await waitFor(() => {
            expect(mockGetTableData).toHaveBeenCalledTimes(2);
        });

        // Simulate clicking the "First Page" button (<<)
        await waitFor(() => {
            fireEvent.click(screen.getByLabelText('First Page'));
        });

        await waitFor(() => {
            expect(mockGetTableData).toHaveBeenCalledTimes(3);
        });
    });

    test('handles specific page link', async () => {
        render(<Contacts />);

        await waitFor(() => {
            fireEvent.click(screen.getByLabelText('Page 2'));
            // Simulate clicking the "Page 2" button
            expect(mockGetTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles sorting', async () => {
        render(<Contacts />);

        await waitFor(() => {
            expect(screen.getByText(MockContactList.userDetails[0].firstName)).toBeInTheDocument();
        });

        fireEvent.click(screen.getByText('First Name'));

        await waitFor(() => {
            expect(mockGetTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles error states', async () => {
        mockGetTableData.mockRejectedValue(new Error('Network Error'));

        render(<Contacts />);

        await waitFor(() => {
            expect(screen.getByText(t('COMPANIES.CONTACTS.NO_CONTACT_FOUND'))).toBeInTheDocument();
        });
    });
});

const mockTFunction: TFunction<'translation', undefined> = ((key: string) => key) as TFunction<
    'translation',
    undefined
> & { $TFunctionBrand: 'translation' };

describe('getHeaderTitleAndStepperMode', () => {
    beforeEach(() => {
        jest.clearAllMocks(); // Clear mock call history before each test
    });

    it('should return edit mode values when isFromEdit is true', () => {
        const result = getHeaderTitleAndStepperMode(mockTFunction, true, false);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.CONTACTS.EDIT_CONTACT',
            cancelBtnTitle: 'COMMON.CANCEL',
            saveBtnTitle: 'COMMON.UPDATE',
            mode: stepperMode.EDIT
        });
    });

    it('should return view mode values when isFromView is true', () => {
        const result = getHeaderTitleAndStepperMode(mockTFunction, false, true);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.CONTACTS.VIEW_CONTACT',
            cancelBtnTitle: 'COMMON.CANCEL',
            saveBtnTitle: 'COMMON.SAVE',
            mode: stepperMode.VIEW
        });
    });

    it('should return create mode values when neither isFromEdit nor isFromView is true', () => {
        const result = getHeaderTitleAndStepperMode(mockTFunction, false, false);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.CONTACTS.CREATE_CONTACT',
            cancelBtnTitle: 'COMMON.CLEAR',
            saveBtnTitle: 'COMMON.SAVE',
            mode: stepperMode.CREATE
        });
    });
});

describe('buildUserDataFromAPI', () => {
    it('should build user data correctly from API response', () => {
        const response = {
            firstName: 'John',
            middleName: 'A',
            lastName: 'Doe',
            email: 'john.doe@example.com',
            companyId: 1,
            roleId: 2,
            projectManagers: '3,4',
            comments: 'No comments',
            userContactInformation: {
                mainPhone: '123-456-7890',
                officePhone: '098-765-4321',
                extension: '123',
                salesRep: '5',
                linkedInUrl: 'https://linkedin.com/in/johndoe',
                mobilePhone: '111-222-3333',
                homePhone: '444-555-6666'
            },
            mailingAddressModel: {
                address1: '123 Main St',
                address2: 'Apt 4',
                city: 'Metropolis',
                zip: '12345',
                billingEmail: 'billing@example.com',
                isSameAddress: true
            },
            userBillingAddressModel: {
                address1: '456 Elm St',
                address2: '',
                city: 'Gotham',
                zip: '67890'
            }
        };

        const country = { id: 1, name: 'Country1' } as Country;
        const state = { id: 2, name: 'State1' } as State;
        const bcountry = { id: 3, name: 'Country2' } as Country;
        const bstate = { id: 4, name: 'State2' } as State;

        const result = buildUserDataFromAPI(
            response,
            stepperMode.CREATE,
            country,
            state,
            bcountry,
            bstate
        );

        expect(result).toEqual({
            mode: stepperMode.CREATE,
            firstName: 'John',
            middleName: 'A',
            lastName: 'Doe',
            email: 'john.doe@example.com',
            company: 1,
            role: '2',
            projectManagers: [3, 4],
            comments: 'No comments',
            mainphone: '123-456-7890',
            officePhone: '098-765-4321',
            extension: '123',
            salesRep: '5',
            linkedInUrl: 'https://linkedin.com/in/johndoe',
            mobilePhone: '111-222-3333',
            homePhone: '444-555-6666',
            address1: '123 Main St',
            address2: 'Apt 4',
            city: 'Metropolis',
            state,
            country,
            zip: '12345',
            billingEmail: 'billing@example.com',
            baddress1: '456 Elm St',
            baddress2: '',
            bcity: 'Gotham',
            bstate,
            bcountry,
            bzip: '67890',
            sameAsMailing: true
        });
    });
});

describe('buildUserData', () => {
    it('should build user data correctly from contactUserData with contactUser', () => {
        const userId = 786;
        const contactUserData: CreateContactModal = {
            firstName: 'TestVendor123',
            lastName: 'test',
            email: 'test123@gmail.com',
            role: '6',
            projectManagers: [124, 615, 450],
            mainphone: '(123) 423-4543',
            salesRep: '245',
            address1: '3/357',
            country: {
                id: 138,
                name: 'Afghanistan',
                code: 'AF',
                iconName: '122-afghanistan.svg',
                countryNameCode: 'Afghanistan (AF)',
                latitude: '33.93911',
                longitude: '67.709953'
            },
            state: {
                id: 347,
                name: 'Badakhshan',
                code: 'AF-BDS'
            },
            city: 'cbe',
            zip: '641401',
            sameAsMailing: true,
            baddress1: '3/357',
            bcountry: {
                id: 138,
                name: 'Afghanistan',
                code: 'AF',
                iconName: '122-afghanistan.svg',
                countryNameCode: 'Afghanistan (AF)',
                latitude: '33.93911',
                longitude: '67.709953'
            },
            bstate: {
                id: 347,
                name: 'Badakhshan',
                code: 'AF-BDS'
            },
            bcity: 'cbe',
            bzip: '641401',
            billingEmail: 'test123@gmail.com',
            billingEmailCC: null,
            mode: 1,
            middleName: '',
            company: '678',
            comments: null,
            officePhone: null,
            extension: 12,
            linkedInUrl: null,
            mobilePhone: null,
            homePhone: null,
            address2: null,
            baddress2: null
        };

        const expectedResult: CreateUserPayloadType = {
            id: 786,
            firstName: 'TestVendor123',
            middleName: '',
            lastName: 'test',
            email: 'test123@gmail.com',
            companyIds: '678',
            roleId: 6,
            projectManagers: '124,615,450',
            comments: null,
            userTypeId: 2,
            userContactInformation: {
                mainPhone: '(123) 423-4543',
                officePhone: null,
                extension: '12',
                salesRep: 245,
                linkedInUrl: null,
                mobilePhone: null,
                homePhone: null
            },
            mailingAddressModel: {
                address1: '3/357',
                address2: null,
                city: 'cbe',
                state: 'Badakhshan',
                stateId: 347,
                country: 'Afghanistan (AF)',
                countryId: 138,
                zip: '641401',
                billingEmail: 'test123@gmail.com',
                isSameAddress: true
            },
            userBillingAddressModel: {
                address1: '3/357',
                address2: null,
                city: 'cbe',
                state: 'Badakhshan',
                stateId: 347,
                country: 'Afghanistan (AF)',
                countryId: 138,
                zip: '641401',
                billingEmail: 'test123@gmail.com',
                isSameAddress: true
            }
        };

        const result = buildUserData(contactUserData, userId);

        expect(result).toEqual(expectedResult);
    });
});
