import FileUpload from 'components/fileUpload/fileUpload';
import { MODULE_TYPE } from 'constants/app.constant';
import { QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { useState } from 'react';
import { useLocation } from 'react-router-dom';

const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

const CompanyFileUpload = () => {
    const [companyStoreModuleData] = useState(companyStepperStore.getData());
    const isMandatory = false;
    const location = useLocation();
    const { pathname } = location;
    const isFromView: boolean = pathname?.includes('view');
    companyStepperStore.updatePage('formData', companyStoreModuleData?.formData);

    const stepperInfo = companyStoreModuleData?.stepperInfo || undefined;
    const primaryId = (stepperInfo?.primaryId as number) ?? 0; // Get primaryId from store
    const { moduleId, azureFolderName } = MODULE_TYPE.COMPANY_DOCUMENT_MODULE; // Destructure moduleTypeMode function
    const uploadFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPLOAD_FILE}${primaryId}&moduleType=${moduleId}`; // Upload file API URL
    const getFileListApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_FILE_LIST}${primaryId ?? 0}/${moduleId}/false       `; // Get file list API URL
    const deleteFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`; // Delete file API URL
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`; // Get document type API URL
    const updateDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPDATE_DOCUMENT_TYPE}`; // Update document type API URL

    return (
        <div className="userProfilePage p-2" data-testid="fileUpload">
            <FileUpload
                data-testid="fileUpload"
                documentUploadRequired={isMandatory}
                uploadFileApiUrl={uploadFileApiUrl}
                getFileListApiUrl={getFileListApiUrl}
                deleteFileApiUrl={deleteFileApiUrl}
                getDocumentTypeApiUrl={getDocumentTypeApiUrl}
                updateDocumentTypeApiUrl={updateDocumentTypeApiUrl}
                moduleType={{ moduleId, azureFolderName }}
                primaryId={primaryId}
                stepperModuleStore={companyStepperStore}
                isViewOnly={isFromView}
                moduleName={'company-' + primaryId}
            />
        </div>
    );
};

export default CompanyFileUpload;
