import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import {
    Country,
    CreateCompanyPayloadType,
    SageCompanyDetails,
    State
} from 'pages/companies/types/createCompany.types';
import { CompanyProfileDetails, BillingInfoDetails } from 'pages/companies/types/companies.types';
import { STEPPER_STATE } from 'pages/components/progressStepper/types/progressStepper.type';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import companiesService from '../service/companies.service';
import { TFunction } from 'i18next';
import { Step } from 'components/stepper/stepperButtons/stepperButton.types';
import { stepperMode } from 'pages/users/constant/user.constant';
import {
    CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY,
    EDIT_COMPANY_PATHS_FOR_STEPPER_ARRAY,
    VIEW_COMPANY_PATHS_FOR_STEPPER_ARRAY
} from '../constants/companyStepper.constant';

export const generateFormData = (
    companyData: CreateCompanyPayloadType,
    country: Country | string | null,
    state: State | string | null
) => {
    const data = {
        companyProfilePage: {
            id: companyData?.id,
            container: {
                name: companyData.name || ''
            },
            companyType: companyData?.companyType,
            parentCompanyName: companyData?.parentCompanyName || null,
            companyStatus: companyData?.companyStatus,
            customerTierLevel: companyData?.customerTierLevel,
            serviceAgreement: companyData?.serviceAgreement ? 'yes' : 'no',
            website: companyData?.website,
            primaryPhoneNumber: companyData?.primaryPhoneNumber || '',
            salesRepId: companyData?.salesRepId || null,
            notes: companyData?.companyNotes,
            industryId: companyData?.industryId ?? null,
            isAgreeTMDiscounts: companyData?.isAgreeTMDiscounts ? 'yes' : 'no',
            serviceAgreementStartDate: companyData?.serviceAgreementStartDate ?? null,
            serviceAgreementEndDate: companyData?.serviceAgreementEndDate ?? null,
            vatRegistrationNumber: companyData?.vatRegistrationNumber ?? null
        },
        billingInfoPage: {
            billingTermsId: companyData?.billingTermsId || null,
            paymentTypeId: companyData?.paymentTypeId || null,
            currencyId: companyData.currencyId || null,
            grossProfit: companyData.grossProfit,
            accountOnHold: companyData.isAccountOnHold ? 'yes' : 'no',
            reason: companyData.accountHoldReasonNotes,
            billingNotes: companyData.billingNotes,
            address1: companyData.mailingAddress.address1,
            address2: companyData.mailingAddress.address2,
            country,
            state,
            city: companyData.mailingAddress.city,
            zip: companyData.mailingAddress.zip,
            billingEmail: companyData.mailingAddress.billingEmail,
            isPoRequired: companyData?.isPoRequired ? 'yes' : 'no',
            billingPeriodId: companyData?.billingPeriodId ?? null,
            billingTypeId: companyData?.billingTypeId ?? null,
            invoiceMode: companyData?.invoiceMode ?? '',
            invoiceDeliveryStatement: companyData?.invoiceDeliveryStatement ?? '',
            cc: companyData?.mailingAddress?.ccRecipients ?? '',
            vatRegistrationNumber: companyData?.vatRegistrationNumber ?? ''
        },
        contact: null,
        rates: null
    };
    companyStepperStore.updatePage('formData', data);
};

export const buildCompanyData = async (formData: {
    companyProfilePage: CompanyProfileDetails;
    billingInfoPage: BillingInfoDetails;
}): Promise<CreateCompanyPayloadType> => {
    const { companyProfilePage, billingInfoPage } = formData;
    let id: number | undefined;
    if (companyProfilePage?.id) {
        id = companyProfilePage?.id;
    }
    type ParentCompanyDetails = {
        companyName?: string;
        companyId: string | null;
    };

    const parentCompanyDetails = companyProfilePage?.parentCompanyName;
    let companyName: string = '';
    // let existingCompanyId: string| null = null;

    if (typeof parentCompanyDetails === 'object' && parentCompanyDetails !== null) {
        companyName = (parentCompanyDetails as ParentCompanyDetails).companyName || '';
        // existingCompanyId = (parentCompanyDetails as ParentCompanyDetails).companyId || '';
    } else if (typeof parentCompanyDetails === 'string') {
        companyName = parentCompanyDetails;
        // existingCompanyId = null;
    }

    const updatedCompanyName = companyName.includes(' (Create New)')
        ? companyName.replace(' (Create New)', '')
        : companyName;

    const response: any = await companiesService.getParentCompanyId({
        limit: 50,
        skip: 10,
        filterQuery: updatedCompanyName
    });
    let firstCompanyId: string | null = null;
    if (response?.length > 0) {
        // Access the companyId from the list

        firstCompanyId =
            response.find(
                (list: { companyName: string }) =>
                    list.companyName.replace(' (Create New)', '') === updatedCompanyName
            ).companyId || 'new_customer';
    }

    return {
        id,
        name: companyProfilePage.container.name,
        companyType: 0,
        companyStatus: companyProfilePage.companyStatus,
        customerTierLevel: companyProfilePage.customerTierLevel?.toString() ?? '',
        parentCompanyName: updatedCompanyName,
        sageParentId: firstCompanyId,
        serviceAgreement: companyProfilePage?.serviceAgreement === 'yes',
        website: companyProfilePage?.website || '',
        primaryPhoneNumber: companyProfilePage?.primaryPhoneNumber || '',
        salesRepId: companyProfilePage?.salesRepId || null,
        companyNotes: companyProfilePage?.notes || '',
        billingTermsId: billingInfoPage?.billingTermsId || null,
        paymentTypeId: billingInfoPage?.paymentTypeId || null,
        currencyId: billingInfoPage?.currencyId || null,
        grossProfit: billingInfoPage?.grossProfit || 0,
        isAccountOnHold: billingInfoPage?.accountOnHold === 'yes' || false,
        industryId: companyProfilePage?.industryId || null,
        isAgreeTMDiscounts: companyProfilePage?.isAgreeTMDiscounts === 'yes',
        billingPeriodId: billingInfoPage?.billingPeriodId || null,
        billingTypeId: billingInfoPage?.billingTypeId || null,
        isPoRequired: billingInfoPage?.isPoRequired === 'yes',
        invoiceMode: billingInfoPage?.invoiceMode ?? '',
        invoiceDeliveryStatement: billingInfoPage?.invoiceDeliveryStatement ?? '',
        rateId: billingInfoPage?.rate?.id,
        accountHoldReasonNotes: billingInfoPage?.reason || '',
        billingNotes: billingInfoPage?.billingNotes || '',
        serviceAgreementStartDate: companyProfilePage?.serviceAgreementStartDate ?? null,
        serviceAgreementEndDate: companyProfilePage?.serviceAgreementEndDate ?? null,
        vatRegistrationNumber: billingInfoPage?.vatRegistrationNumber ?? null,
        mailingAddress: {
            address1: billingInfoPage?.address1 || '',
            address2: billingInfoPage?.address2 || '',
            city: billingInfoPage?.city || '',
            state: billingInfoPage?.state?.name || '',
            stateId: billingInfoPage?.state?.id || 0,
            country: billingInfoPage.country?.name || '',
            countryId: billingInfoPage?.country?.id || 0,
            zip: billingInfoPage?.zip || '',
            billingEmail: billingInfoPage?.billingEmail || '',
            ccRecipients: billingInfoPage?.cc ?? ''
        },
        contactDetails: [] // Add contact details if available
    };
};

export const redirectToNextPage = (stepperState: STEPPER_STATE) => {
    try {
        const updatedStepperInfo =
            progressStepperServices.updateStepperStoreForNextPage(stepperState);
        if (updatedStepperInfo) stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
    } catch (error) {
        console.error('Error while redirecting to the next page:', error);
    }
};

export const generateSageCompanyFormData = async (companyData: SageCompanyDetails) => {
    const { salesRepId, industryId, billingTermsId, billingPeriodId, country, state } =
        await getCompanyAPIDetails(companyData);

    const updatePrimaryPhoneNumber = companyData?.primaryPhoneNumber
        ? companyData?.primaryPhoneNumber
        : '';
    const data = {
        companyProfilePage: {
            container: {
                name: companyData.companyName || ''
            },
            parentCompanyName: companyData?.parentCompanyName,
            companyStatus: 'Prospecting',
            serviceAgreement: companyData?.serviceAgreement ? 'yes' : 'no',
            website: companyData?.website,
            primaryPhoneNumber: updatePrimaryPhoneNumber,
            salesRepId,
            notes: companyData?.companyNotes,
            industryId,
            isAgreeTMDiscounts: companyData?.isAgreeTMDiscounts ? 'yes' : 'no'
        },
        billingInfoPage: {
            billingTermsId: billingTermsId || null,
            paymentTypeId: null,
            currencyId: null,
            accountOnHold: companyData.isAccountOnHold ? 'yes' : 'no',
            reason: companyData.accountHoldReasonNotes,
            billingNotes: companyData.billingNotes,
            address1: companyData.address1,
            address2: companyData.address2,
            country,
            state,
            city: companyData.city,
            zip: companyData.zip,
            billingEmail: companyData.billingEmailTo || companyData.billingEmail,
            isPoRequired: companyData.poRequired === 'Yes' ? 'yes' : 'no',
            billingPeriodId: billingPeriodId || null,
            billingTypeId:
                companyData?.billingType === ''
                    ? null
                    : companyData?.billingType === 'Single'
                      ? 2
                      : companyData?.billingType === 'Consolidated'
                        ? 1
                        : null,
            invoiceMode: companyData?.modeOfInvoicing || '',
            invoiceDeliveryStatement: companyData?.invoiceDeliveryStatement || '',
            cc: companyData?.billingEmailCc
        },
        contact: null,
        rates: null
    };
    companyStepperStore.updatePage('formData', data);
};

const getCompanyAPIDetails = async (companyData: SageCompanyDetails) => {
    let salesRepId: number | null = null;
    let industryId: number | null = null;
    let billingTermsId: number | null = null;
    let billingPeriodId: number | null = null;
    let country: Country | null = null;
    let state: State | null = null;

    if (companyData.salesRepName?.length) {
        try {
            const salesRepList: any[] = (await companiesService.getSalesRepList()) ?? [];
            if (salesRepList?.length) {
                salesRepId =
                    salesRepList.filter(
                        (eachSalesRep: any) => eachSalesRep?.name === companyData.salesRepName
                    )?.[0]?.id || null;
            }
        } catch (error) {
            console.error('Error fetching Sales Rep listing data:', error);
        }
    }

    if (companyData.industry?.length) {
        try {
            const industriesList: any[] = (await companiesService.getIndustryList()) ?? [];
            if (industriesList?.length) {
                industryId =
                    industriesList.filter(
                        (eachIndustry: any) => eachIndustry?.name === companyData.industry
                    )?.[0]?.id || null;
            }
        } catch (error) {
            console.error('Error fetching Industries listing data:', error);
        }
    }

    if (companyData.billingTerms?.length) {
        try {
            const billingTermsList: any[] = (await companiesService.getBillingTermsList()) ?? [];
            if (billingTermsList?.length) {
                billingTermsId =
                    billingTermsList.filter(
                        (eachBillingTerm: any) => eachBillingTerm?.name === companyData.billingTerms
                    )?.[0]?.id || null;
            }
        } catch (error) {
            console.error('Error fetching Industries listing data:', error);
        }
    }

    if (companyData.billingPeriod?.length) {
        try {
            const billingPeriodList: any[] = (await companiesService.getBillingPeriodList()) ?? [];
            if (billingPeriodList?.length) {
                billingPeriodId =
                    billingPeriodList.filter(
                        (eachBillingPeriod: any) =>
                            eachBillingPeriod?.name === companyData.billingPeriod
                    )?.[0]?.id || null;
            }
        } catch (error) {
            console.error('Error fetching Billing Period listing data:', error);
        }
    }

    if (companyData.country?.length) {
        try {
            const countryList: any[] = (await companiesService.getCountryList()) ?? [];
            if (countryList?.length) {
                country =
                    countryList.filter(
                        (eachCountry: any) => eachCountry?.name === companyData.country
                    )?.[0] || null;
            }
        } catch (error) {
            console.error('Error fetching Country listing data:', error);
        }
    }

    if (country && country?.id && companyData?.state) {
        try {
            const statesList: any[] = (await companiesService.getStatesList(country?.id)) ?? [];
            if (statesList?.length) {
                state =
                    statesList.filter(
                        (eachState: any) => eachState?.name === companyData.state
                    )?.[0] || null;
            }
        } catch (error) {
            console.error('Error fetching State listing data:', error);
        }
    }
    return {
        salesRepId,
        industryId,
        billingTermsId,
        billingPeriodId,
        country,
        state
    };
};

// const formatPhoneNumber = (phoneNumber: string): string => {
//     // Remove non-digit characters
//     const cleaned = phoneNumber.replace(/\D/g, '');

//     // Define the regex to match the parts of the phone number
//     const regex = /^(\d{2})(\d{2})(\d{7,10})$/;

//     // Apply the regex to the cleaned input
//     const match = cleaned.match(regex);

//     if (match) {
//         const countryCode = match[1];
//         const firstTwoDigits = match[2];
//         const restOfNumber = match[3];

//         // Format the phone number
//         return `+${countryCode}-${firstTwoDigits}-${restOfNumber}`;
//     } else {
//         // If the input doesn't match the expected format, return the original input
//         return phoneNumber;
//     }
// };
export const getHeaderTitleAndStepButtons = (
    t: TFunction,
    isFromEdit: boolean,
    isFromView: boolean,
    title?: string
): { headerTitle: string; stepButtonArray: Step[]; mode: stepperMode } => {
    let headerTitle: string;
    let stepButtonArray: Step[];
    let mode: stepperMode;

    if (isFromEdit) {
        headerTitle = (title ?? '') + ' ' + `(${t('COMMON.EDIT')})`;
        stepButtonArray = EDIT_COMPANY_PATHS_FOR_STEPPER_ARRAY;
        mode = stepperMode.EDIT;
    } else if (isFromView) {
        headerTitle = title ?? '';
        stepButtonArray = VIEW_COMPANY_PATHS_FOR_STEPPER_ARRAY;
        mode = stepperMode.VIEW;
    } else {
        headerTitle = t('COMPANIES.CREATE_COMPANY');
        stepButtonArray = CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY;
        mode = stepperMode.CREATE;
    }

    return { headerTitle, stepButtonArray, mode };
};
