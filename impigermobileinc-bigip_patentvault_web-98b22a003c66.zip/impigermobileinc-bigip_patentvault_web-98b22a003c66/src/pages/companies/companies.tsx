import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS } from '../../constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';
import { useEffect, useState } from 'react';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import tableSchema from './data/companiesTableSchema.json';
import DataTableComponent from 'shared/dataTable/dataTable';
import { CompaniesDataItem, GetCompaniesListApiResponse } from './types/companies.types';
import companiesService from './service/companies.service';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import stepperStore, {
    initialProgressStepperState
} from 'core/store/stepperStore/progressStepper.store';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { END_POINT } from 'constants/endPoint';
import { DataTableSelectEvent } from 'primereact/datatable';
import { Permissions } from 'constants/permissions';
import ProgressStatusIndicator from 'shared/dataTable/components/progressStatusIndicator/progressStatusIndicator';

function CompaniesPage() {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const [columnSchema] = useState<ColumnDefinition[]>(tableSchema as ColumnDefinition[]);
    const [toggleRowData, setToggleRowData] = useState<CompaniesDataItem>();

    const [tableData, setTableData] = useState<CompaniesDataItem[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.COMPANIES_COLUMN_ORDERS;
    const isShowResync = AuthStore.hasPermission(Permissions.CREATE_COMPANIES);
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        markActive: {
            SUCCESS_MESSAGE: t('COMPANIES.MARK_ACTIVE.SUCCESS_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('COMPANIES.MARK_INACTIVE.SUCCESS_MESSAGE')
        }
    };
    const emptyMessage = t('COMPANIES.EMPTY_MESSAGE');
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const getAllCompaniesList = async (body: RequestBody) => {
        try {
            const response: GetCompaniesListApiResponse =
                await companiesService.getTableData<GetCompaniesListApiResponse>(body);
            setTableData(response?.companyServiceModel);

            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.totalRecords / body.pageCount),
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response?.companyServiceModel?.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            setEmptyMessage(emptyMessage);
        }
    };
    const postChangeStatus = async (companyId: number, isActive: boolean) => {
        try {
            const response: boolean = await companiesService.updateChangeStatus<boolean>(
                companyId,
                isActive
            );
            if (response) {
                getAllCompaniesList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error in updating company status:', error);
        }
    };

    // Function for Export
    function exportData() {
        try {
            const exportURL = `${END_POINT.COMPANIES.EXPORT}`;
            SettingsService.exportData(requestBody, exportURL, 'companies_data.xlsx');
        } catch (error) {
            showToastMessage({
                type: ToastType.ERROR,
                message: t('COMPANIES.ERROR_MESSAGE.EXPORT_COMPANIES_LIST')
            });
        }
    }
    useEffect(() => {
        getAllCompaniesList(requestBody);
    }, [requestBody]);
    const resetCompanyStores = () => {
        stepperStore.resetStepperStore();
        companyStepperStore.resetStepperModuleStore();
    };
    const buttonChildren = () => {
        return (
            <button
                onClick={() => {
                    resetCompanyStores();
                    navigate(`/${PATHS.COMPANIES}/${PATHS.CREATE}/${PATHS.COMPANY_PROFILE}`);
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn btn-sm text-white bg-primary hover:bg-primary-200"
                data-testid="create-company-button">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE_COMPANY')}
            </button>
        );
    };

    const renderButton = () => {
        return AuthStore.hasPermission(Permissions.CREATE_COMPANIES) && buttonChildren();
    };

    // Extend the original MenuItem interface to include permission property
    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {
                        resetCompanyStores();
                        navigate(
                            `/${PATHS.COMPANIES}/${PATHS.EDIT}/${toggleRowData?.id}/${PATHS.COMPANY_PROFILE}`
                        );
                    }
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header:
                                    toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                        ? t('COMMON.MARK_AS_INACTIVE')
                                        : t('COMMON.MARK_AS_ACTIVE'),
                                subHeader: toggleRowData.name,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status:
                                        toggleRowData.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.INACTIVE')
                                            : t('COMMON.ACTIVE'),
                                    table_name: t('COMPANIES.COMPANY').toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const renderReSync = (rowData: CompaniesDataItem) => {
        const isValidShow: boolean =
            rowData.sageStatusSyncName === 'Failed' || rowData.sageStatusSyncName === 'Error';
        const handleReSyncClick = async (e: React.MouseEvent) => {
            e.stopPropagation();
            const response = await companiesService.resyncCompanyByID(rowData?.id || 0);
            if (response) {
                getAllCompaniesList(requestBody);
            }
        };
        return (
            <div style={{ display: 'flex', width: '100%' }}>
                <div style={{ width: '100%' }}>
                    <ProgressStatusIndicator
                        syncStatus={rowData?.sageStatusSyncName}
                        sageSyncError={JSON.parse(rowData.sageSyncDetails)}
                    />
                </div>
                {isValidShow && isShowResync && (
                    <button
                        style={{ width: '100%', textAlign: 'left' }}
                        onClick={(e) => {
                            handleReSyncClick(e);
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        data-testid="resync-button">
                        <i className="pi pi-refresh" />
                    </button>
                )}
            </div>
        );
    };

    const updatedColumnSchema = columnSchema.map((column) => {
        if (column.field === 'sageStatusSyncName') {
            return {
                ...column,
                body: renderReSync
            };
        }
        return column;
    });
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.COMPANIES'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        buttonChildren: renderButton(),
        items: menuItems,
        showResync: isShowResync,
        columns: AuthStore.hasPermission(Permissions.EDIT_COMPANIES)
            ? updatedColumnSchema
            : updatedColumnSchema?.filter(
                  (item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString()
              )
    };
    useEffect(() => {
        /* set init values for 'stepper-info' property when user land on this page.
            keep the other 'stepper-data' */
        stepperStore.updateStepper(initialProgressStepperState);
    }, []);

    useEffect(() => {
        resetCompanyStores();
    }, []);
    const onRowClicked = (e: DataTableSelectEvent) => {
        const companyId = e?.data?.id;

        if (companyId) {
            navigate(`/${PATHS.COMPANIES}/${PATHS.VIEW}/${companyId}/${PATHS.COMPANY_PROFILE}`);
        } else {
            console.error('Error: Company ID is undefined', e);
        }
    };
    const onClickReSyncFunc = () => {
        companiesService.resyncCompanyByAll();
    };
    return (
        <div data-testid="CompaniesPageComponent" className="p-4 pb-3">
            {showPopup?.visible && (
                <ConfirmationPopup
                    data-testid="confirmation-popup"
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}

            <DataTableComponent
                tableData={tableData}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as CompaniesDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
                onRowClicked={onRowClicked}
                onClickReSync={onClickReSyncFunc}
            />
        </div>
    );
}
export default CompaniesPage;
