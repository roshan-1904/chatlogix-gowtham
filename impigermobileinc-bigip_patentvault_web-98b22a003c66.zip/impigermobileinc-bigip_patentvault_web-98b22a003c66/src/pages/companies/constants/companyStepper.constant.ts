import { BUTTON_KEYS } from 'components/stepper/stepperButtons/stepperButton.constant';
import { Step } from 'components/stepper/stepperButtons/stepperButton.types';
import { PATHS } from 'constants/routes.constant';

// IDs - Stepper
export const STEPPER_TYPE_ID = {
    COMPANY_PROFILE: 1,
    BILLING_INFORMATION: 2,
    DOCUMENT_UPLOAD: 3,
    RATES: 4
};
// Paths for Stepper
export const COMPANY_PATHS_FOR_STEPPER: { [key: number]: string } = {
    [STEPPER_TYPE_ID.COMPANY_PROFILE]: PATHS.COMPANY_PROFILE,
    [STEPPER_TYPE_ID.BILLING_INFORMATION]: PATHS.BILLING_INFO,
    [STEPPER_TYPE_ID.DOCUMENT_UPLOAD]: PATHS.FILE_UPLOAD,
    [STEPPER_TYPE_ID.RATES]: PATHS.RATES
};

// Define the steps array directly
export const CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY: Step[] = [
    {
        path: PATHS.COMPANY_PROFILE,
        buttons: [{ key: BUTTON_KEYS.CHECK_PRIMARY_VALIDATION, name: 'Continue' }]
    },
    {
        path: PATHS.BILLING_INFO,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.SAVE_DRAFT, name: 'Save & Continue' }
        ],
        optionalAction: { key: BUTTON_KEYS.CREATE, name: 'Create' }
    },
    {
        path: PATHS.FILE_UPLOAD,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.CONTINUE, name: 'Continue' }
        ],
        optionalAction: { key: BUTTON_KEYS.BACK_TO_LIST, name: 'Back to list' }
    },
    {
        path: PATHS.RATES,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.CONTINUE, name: 'Continue' }
        ],
        optionalAction: { key: BUTTON_KEYS.BACK_TO_LIST, name: 'Back to list' },
        finalAction: { key: BUTTON_KEYS.UPDATE, name: 'Update' }
    }
];
// edit buttons
export const EDIT_COMPANY_PATHS_FOR_STEPPER_ARRAY: Step[] = [
    {
        path: PATHS.COMPANY_PROFILE,
        buttons: [{ key: BUTTON_KEYS.CONTINUE, name: 'Continue' }]
    },
    {
        path: PATHS.BILLING_INFO,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.SAVE_DRAFT, name: 'Update & Continue' }
        ],
        optionalAction: { key: BUTTON_KEYS.UPDATE, name: 'Update' }
    },
    {
        path: PATHS.FILE_UPLOAD,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.CONTINUE, name: 'Continue' }
        ],
        optionalAction: { key: BUTTON_KEYS.BACK_TO_LIST, name: 'Back to list' }
    },
    {
        path: PATHS.RATES,
        buttons: [{ key: BUTTON_KEYS.BACK, name: 'Back' }],
        optionalAction: { key: BUTTON_KEYS.BACK_TO_LIST, name: 'Back to list' },

        finalAction: { key: BUTTON_KEYS.UPDATE, name: 'Update' }
    }
];

// View buttons
export const VIEW_COMPANY_PATHS_FOR_STEPPER_ARRAY: Step[] = [
    {
        path: PATHS.COMPANY_PROFILE,
        buttons: [{ key: BUTTON_KEYS.CONTINUE, name: 'Continue' }]
    },
    {
        path: PATHS.BILLING_INFO,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.CONTINUE, name: 'Continue' }
        ]
    },
    {
        path: PATHS.FILE_UPLOAD,
        buttons: [
            { key: BUTTON_KEYS.BACK, name: 'Back' },
            { key: BUTTON_KEYS.CONTINUE, name: 'Continue' }
        ]
    },
    {
        path: PATHS.RATES,
        buttons: [{ key: BUTTON_KEYS.BACK, name: 'Back' }],
        finalAction: { key: BUTTON_KEYS.BACK_TO_LIST, name: 'Back to list' }
    }
];
// Stepper Data
export const COMPANY_STEPPER_DATA = [
    {
        stepperId: 1,
        stepperName: 'Company Profile',
        stepperDesc: 'Enter Company Information'
    },
    {
        stepperId: 2,
        stepperName: 'Billing Information',
        stepperDesc: 'Payment and Currency Information'
    },
    {
        stepperId: 3,
        stepperName: 'Documents Upload',
        stepperDesc: 'Optional'
    },
    {
        stepperId: 4,
        stepperName: 'Rates',
        stepperDesc: 'Manage Rates (Optional)'
    }
];

export enum CONTACT_STEPPER_ACTIONS {
    CREATE = 'create',
    VIEW = 'view',
    EDIT = 'edit'
}

export const ContactUserProperty = {
    COMPANY_ID: 'companyId'
};
