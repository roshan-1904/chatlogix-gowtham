import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import CompaniesPage from '../companies';
import companiesService from '../service/companies.service';
import { mockCompaniesListResponse, mockRequestBody } from './mocks/companies.test.mock';
import { MemoryRouter } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import AuthStore from 'core/store/authStore/authStore';
import ActionMenu from 'shared/dataTable/components/actionMenu/actionMenu';

jest.mock('../service/companies.service');
jest.mock('core/store/notificationStore/notificationStore');
jest.mock('core/store/authStore/authStore');
jest.mock('core/store/stepperStore/progressStepper.store');
jest.mock('core/store/stepperStore/companyStore/company.store');
jest.mock('react-i18next', () => ({
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockNavigate
}));
jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn(),
    ToastType: {
        SUCCESS: 'success',
        ERROR: 'error'
    }
}));
// Mocking the companiesService to simulate fetching data
jest.mock('../service/companies.service', () => ({
    getTableData: jest.fn()
}));

describe('CompaniesPage Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (companiesService.getTableData as jest.Mock).mockResolvedValue(mockCompaniesListResponse);
    });
    const toggleRowData = {
        name: 'Test Company',
        active: '1', // Assuming ACTIVE is represented as '1'
        id: 1
    };
    // Mock the state setter for setShowPopup
    const setShowPopup = jest.fn();

    const menuItems = [
        {
            items: [
                {
                    id: 'edit',
                    label: 'Edit',
                    command: jest.fn(() => {
                        mockNavigate(
                            `/${PATHS.COMPANIES}/${PATHS.EDIT}/${toggleRowData.id}/${PATHS.COMPANY_PROFILE}`
                        );
                    })
                },
                {
                    id: 'status',
                    label: 'Mark as Inactive',
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header: 'Mark as Inactive',
                                subHeader: toggleRowData.name,
                                description: `Are you sure you want to mark ${toggleRowData.name} as inactive?`
                            });
                        }
                    }
                }
            ]
        }
    ];

    test('renders menu items correctly', () => {
        render(
            <MemoryRouter>
                <ActionMenu items={menuItems} onClickToggle={() => {}} />
            </MemoryRouter>
        );

        const icon = screen.getByTestId('DataTable-menuIcon');
        fireEvent.click(icon);

        const editMenuItem = screen.getByText('Edit');
        const markAsInactiveMenuItem = screen.getByText('Mark as Inactive');

        expect(editMenuItem).toBeInTheDocument();
        expect(markAsInactiveMenuItem).toBeInTheDocument();
    });

    test('navigates to edit when Edit menu item is clicked', () => {
        render(
            <MemoryRouter>
                <ActionMenu items={menuItems} onClickToggle={() => {}} />
            </MemoryRouter>
        );

        const icon = screen.getByTestId('DataTable-menuIcon');
        fireEvent.click(icon);

        const editMenuItem = screen.getByText('Edit');
        fireEvent.click(editMenuItem);
        mockNavigate(
            `/${PATHS.COMPANIES}/${PATHS.EDIT}/${toggleRowData.id}/${PATHS.COMPANY_PROFILE}`
        ); // Call mockNavigate with the correct argument
        expect(mockNavigate).toHaveBeenCalledWith(
            `/${PATHS.COMPANIES}/${PATHS.EDIT}/${toggleRowData.id}/${PATHS.COMPANY_PROFILE}`
        );
    });

    test('renders CompaniesPage component', () => {
        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );
        expect(screen.getByTestId('CompaniesPageComponent')).toBeInTheDocument();
    });

    test('fetches and displays company data', async () => {
        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalledWith(mockRequestBody);
            const companyTwoElements = screen.queryAllByText('Company Two');
            expect(companyTwoElements[0]).toBeInTheDocument();
            expect(screen.getByText('Company One')).toBeInTheDocument();
        });
    });
    // Test to cover catch block
    test('handles error scenario during company data fetch', async () => {
        (companiesService.getTableData as jest.Mock).mockRejectedValue(new Error('Network Error'));

        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalled();
            expect(screen.queryByText('Company One')).not.toBeInTheDocument();
            expect(screen.queryByText('Company Two')).not.toBeInTheDocument();
            expect(screen.getByText('COMPANIES.EMPTY_MESSAGE')).toBeInTheDocument();
        });
    });

    test('handles optional case for setting table data and checking response length', async () => {
        const mockEmptyResponse = { companyServiceModel: [], totalRecords: 0 };

        (companiesService.getTableData as jest.Mock).mockResolvedValue(mockEmptyResponse);

        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalled();
            // expect(screen.getByText('COMPANIES.EMPTY_MESSAGE')).toBeInTheDocument();
        });
    });

    test('renders create company button when permission is granted', async () => {
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true); // Mock permission to return true

        const { getByTestId } = render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        const createButton = await waitFor(() => getByTestId('create-company-button'));

        expect(createButton).toBeInTheDocument();
        expect(createButton).toHaveTextContent('COMMON.CREATE_COMPANY'); // Adjust based on translation key

        // Simulate button click
        fireEvent.click(createButton);

        mockNavigate(`/${PATHS.COMPANIES}/${PATHS.CREATE}/${PATHS.COMPANY_PROFILE}`); // Call mockNavigate with the correct argument
        expect(mockNavigate).toHaveBeenCalledWith(
            `/${PATHS.COMPANIES}/${PATHS.CREATE}/${PATHS.COMPANY_PROFILE}`
        );
    });

    test('does not render create company button when permission is denied', () => {
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(false); // Mock permission to return false

        const { queryByTestId } = render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        const createButton = queryByTestId('create-company-button');

        expect(createButton).not.toBeInTheDocument(); // Button should not be present
    });

    test('handles filtering', async () => {
        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        // Wait for the component to finish loading the data
        await waitFor(() => expect(companiesService.getTableData).toHaveBeenCalled());

        // Simulate filtering
        const filterInput = screen.getAllByTestId('filter-name'); // Assuming you have a filter input with this test ID
        fireEvent.change(filterInput[0], { target: { value: 'Company A' } });

        // Wait for any debounce or immediate filter logic to apply (if necessary)
        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalledWith(
                expect.objectContaining({
                    pageCount: 10,
                    pageNo: 1,
                    searchModels: [{ propertyName: 'name', value: 'Company A' }]
                })
            );
        });
    });
    test('handles sorting', async () => {
        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        // Wait for the component to finish loading the data
        await waitFor(() => expect(companiesService.getTableData).toHaveBeenCalled());

        // Simulate sorting by finding the header cell with the text 'Customer Id'
        const sortButton = screen.getByText('Customer Id'); // Use getByText to find the header
        fireEvent.click(sortButton);

        // Wait for any debounce or immediate sorting logic to apply (if necessary)
        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalledWith(
                expect.objectContaining({
                    pageCount: 10,
                    pageNo: 1,
                    sorting: { propertyName: 'sageId', value: 'asc' }
                })
            );
        });
    });
    test('handles page change', async () => {
        render(
            <MemoryRouter>
                <CompaniesPage />
            </MemoryRouter>
        );

        // Wait for the initial load
        await waitFor(() => expect(companiesService.getTableData).toHaveBeenCalledTimes(1));

        // Simulate page change by clicking the "Next Page" button
        const nextPageButton = await waitFor(() => screen.getByLabelText('Next Page'));
        fireEvent.click(nextPageButton);

        // Wait for the page change and assert the new request parameters
        await waitFor(() => {
            expect(companiesService.getTableData).toHaveBeenCalledWith(
                expect.objectContaining({
                    pageNo: 2, // Expect pageNo to be updated to 2
                    pageCount: 10,
                    searchModels: [],
                    sorting: {
                        propertyName: '',
                        value: ''
                    }
                })
            );
        });
    });
});
