import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter, useLocation, useParams } from 'react-router-dom';
import CreateCompany from '../createCompany';
import companiesService from '../service/companies.service';
import AuthStore from 'core/store/authStore/authStore';

// Mock necessary modules and components
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useParams: jest.fn(),
    useLocation: jest.fn()
}));

jest.mock('pages/components/progressStepper/progressStepper', () => {
    return () => <div data-testid="mock-progress-stepper">ProgressStepper</div>;
});
jest.mock('components/stepper/stepperButtons/stepperButtons', () => {
    return () => <div data-testid="mock-stepper-buttons">StepperButtons</div>;
});
jest.mock('components/stepper/stepperNavigation/StepperNavigation', () => {
    return () => <div data-testid="mock-stepper-navigation">StepperNavigation</div>;
});
jest.mock('pages/companies/companySteppers/companyLookupPopupModel', () => {
    return () => <div data-testid="mock-company-lookup-popup">CompanyLookupPopupModel</div>;
});
jest.mock('core/store/authStore/authStore', () => ({
    hasPermission: jest.fn()
}));
jest.mock('../service/companies.service', () => ({
    getCompanyById: jest.fn(),
    getCountryAndState: jest.fn(),
    createCompany: jest.fn(),
    updateCompany: jest.fn(),
    checkExistingCompany: jest.fn()
}));
jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));
jest.mock('core/utils/utils', () => ({
    useDebouncedWaitCallback: jest.fn((fn) => fn) // Directly return the function for synchronous execution
}));

const mockUseLocation = (pathname: string) => {
    (useLocation as jest.Mock).mockReturnValue({
        pathname,
        search: '',
        hash: '',
        state: null,
        key: 'default'
    });
};

const mockUseParams = (company_id: string | undefined) => {
    (useParams as jest.Mock).mockReturnValue({ company_id });
};

describe('CreateCompany Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        // Set default mock implementations to avoid undefined behavior
        (companiesService.getCompanyById as jest.Mock).mockResolvedValue({});
        (companiesService.getCountryAndState as jest.Mock).mockResolvedValue({});
        (companiesService.createCompany as jest.Mock).mockResolvedValue({});
        (companiesService.updateCompany as jest.Mock).mockResolvedValue({});
        (companiesService.checkExistingCompany as jest.Mock).mockResolvedValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        mockUseLocation('/');
        mockUseParams(undefined);
    });

    it('renders the CreateCompany component', () => {
        mockUseLocation('/companies/create');
        render(
            <BrowserRouter>
                <CreateCompany />
            </BrowserRouter>
        );
        const createCompanyElement = screen.getByTestId('CreateCompany');
        expect(createCompanyElement).toBeInTheDocument();
    });

    it('fetches company data on mount when company_id is present', async () => {
        mockUseParams('123');
        mockUseLocation('/companies/edit/123');
        (companiesService.getCompanyById as jest.Mock).mockResolvedValue({
            id: 123,
            name: 'Test Company',
            mailingAddress: { countryId: 1, stateId: 1 }
        });
        (companiesService.getCountryAndState as jest.Mock).mockResolvedValue({
            country: 'USA',
            state: 'California'
        });

        render(
            <BrowserRouter>
                <CreateCompany />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(companiesService.getCompanyById).toHaveBeenCalledWith(123);
        });
    });

    it('displays an error message when company ID is invalid', async () => {
        mockUseParams('invalid-id');
        mockUseLocation('/companies/edit/invalid-id');

        // Mock console.error to capture error messages
        const consoleErrorMock = jest.spyOn(console, 'error').mockImplementation(() => {});

        render(
            <BrowserRouter>
                <CreateCompany />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(consoleErrorMock).toHaveBeenCalledWith(
                'Error fetching company data:',
                new Error('Invalid company ID! Please check your URL.')
            );
        });

        consoleErrorMock.mockRestore(); // Restore console.error
    });
});
