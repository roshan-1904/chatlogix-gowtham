import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import CompanyProfile, {
    companyProfileUpdateStore as updateStore
} from 'pages/companies/companySteppers/companyProfile';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { PATHS } from 'constants/routes.constant';
import { StepperModuleStoreData } from 'pages/components/progressStepper/types/progressStepper.type';
import { CompanyFormData } from 'core/store/stepperStore/companyStore/company.store.type';

// Mock the dependencies
jest.mock('core/interceptor/api.handler');
jest.mock('core/store/stepperStore/companyStore/company.store');
jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div data-testid="form">Mocked Formio Form</div>)
}));
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));
jest.mock('react-i18next', () => ({
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

describe('CompanyProfile Component', () => {
    beforeEach(() => {
        // Reset mock implementations before each test
        companyStepperStore.updatePage = jest.fn();
        companyStepperStore.getData = jest.fn(() => ({
            formData: {
                companyProfilePage: {},
                billingInfoPage: {},
                contacts: {},
                companyFileUpload: {}
            },
            isFormValid: {}
        }));
    });

    test('should render CompanyProfile component with view mode', () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/view'
        });

        render(
            <MemoryRouter>
                <CompanyProfile />
            </MemoryRouter>
        );

        // Check if the component rendered correctly
        expect(screen.getByText('COMPANIES.COMPANY_PROFILE.TITLE')).toBeInTheDocument();
        expect(screen.getByTestId('companyProfilePage')).toBeInTheDocument();
    });

    test('should render CompanyProfile component with edit mode', () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        render(
            <MemoryRouter>
                <CompanyProfile />
            </MemoryRouter>
        );

        // Check if the component rendered correctly
        expect(screen.getByText('COMPANIES.COMPANY_PROFILE.TITLE')).toBeInTheDocument();
        expect(screen.getByTestId('companyProfilePage')).toBeInTheDocument();
    });

    test('should call onFormChange on companyProfilePage change', async () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        const { getByTestId } = render(
            <MemoryRouter>
                <CompanyProfile />
            </MemoryRouter>
        );

        const form = getByTestId('companyProfilePage').querySelector('div');
        const mockChangeEvent = {
            changed: { component: { key: 'companyName' } },
            data: { companyName: 'New Company Name' }
        };

        // Simulate form change
        if (form) {
            fireEvent.change(form, { target: { value: JSON.stringify(mockChangeEvent) } });
        }

        await waitFor(() => {
            // expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            //     'formData',
            //     expect.objectContaining({
            //         companyProfilePage: { companyName: 'New Company Name' }
            //     })
            // );

            expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.objectContaining({
                    [PATHS.COMPANY_PROFILE]: false // or whatever logic sets this to false
                })
            );
        });
    });

    test('should call onSubmitChange on companyProfilePage submit', async () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        const mockSubmitEvent = { data: { companyName: 'New Company Name' } };

        const { getByTestId } = render(
            <MemoryRouter>
                <CompanyProfile />
            </MemoryRouter>
        );

        const form = getByTestId('companyProfilePage').querySelector('div');

        // Simulate form submit
        if (form) {
            fireEvent.submit(form, { data: mockSubmitEvent });
        }

        await waitFor(() => {
            // expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            //     'formData',
            //     expect.objectContaining({ companyProfilePage: { companyName: 'New Company Name' } })
            // );

            expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.objectContaining({
                    [PATHS.COMPANY_PROFILE]: false
                })
            );
        });
    });
});

describe('companyProfile Component Store Updates', () => {
    let CompanyModuleData: StepperModuleStoreData<CompanyFormData>;

    beforeEach(() => {
        CompanyModuleData = {
            formData: {
                billingInfoPage: undefined,
                companyProfilePage: {},
                contacts: undefined,
                companyFileUpload: undefined
            },
            isFormValid: {}
        };

        companyStepperStore.getData = jest.fn(() => CompanyModuleData);
        companyStepperStore.updatePage = jest.fn();
    });

    it('should update form data and isValid when updateStore is called', () => {
        const updatedFormData = {
            companyId: 2,
            companyPeriodId: 1
        };

        updateStore(updatedFormData, true, CompanyModuleData);

        expect(companyStepperStore.updatePage).toHaveBeenCalledTimes(2);
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'formData',
            expect.objectContaining({ companyProfilePage: updatedFormData })
        );
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'isFormValid',
            expect.objectContaining({
                [PATHS.COMPANY_PROFILE]: true
            })
        );
    });
});
