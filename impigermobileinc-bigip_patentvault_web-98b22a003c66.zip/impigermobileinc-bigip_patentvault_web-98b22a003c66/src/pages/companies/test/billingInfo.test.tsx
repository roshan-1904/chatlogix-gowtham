import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import BillingInfo, {
    billingInfoUpdateStore as updateStore
} from 'pages/companies/companySteppers/billingInfo';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { PATHS } from 'constants/routes.constant';
import { StepperModuleStoreData } from 'pages/components/progressStepper/types/progressStepper.type';
import { CompanyFormData } from 'core/store/stepperStore/companyStore/company.store.type';

// Mock the dependencies
jest.mock('core/interceptor/api.handler');
jest.mock('core/store/stepperStore/companyStore/company.store');

jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div>Mocked Formio Form</div>)
}));
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));

jest.mock('react-i18next', () => ({
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

describe('BillingInfo Component', () => {
    beforeEach(() => {
        companyStepperStore.getData = jest.fn().mockReturnValue({
            formData: {
                billingInfoPage: {}
            },
            isFormValid: {}
        });
        companyStepperStore.updatePage = jest.fn();
    });

    it('should render Billing Info component in view mode', () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/view'
        });

        render(
            <MemoryRouter>
                <BillingInfo />
            </MemoryRouter>
        );

        expect(screen.getByText('COMPANIES.BILLING_INFORMATION.TITLE')).toBeInTheDocument();
        expect(screen.getByTestId('companyProfilePage')).toBeInTheDocument(); // Check for the presence of the main container
    });

    it('should render Billing Info component in edit mode', () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        render(
            <MemoryRouter>
                <BillingInfo />
            </MemoryRouter>
        );

        expect(screen.getByText('COMPANIES.BILLING_INFORMATION.TITLE')).toBeInTheDocument();
    });

    test('should call onFormChange on form change', async () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        const { getByTestId } = render(
            <MemoryRouter>
                <BillingInfo />
            </MemoryRouter>
        );

        const form = getByTestId('companyProfilePage').querySelector('div');
        const mockChangeEvent = {
            changed: { component: { key: 'billingTermsId' } },
            data: { billingTermsId: 1 }
        };

        // Simulate form change
        if (form) {
            fireEvent.change(form, { target: { value: JSON.stringify(mockChangeEvent) } }); // Use JSON.stringify if necessary
        }

        await waitFor(() => {
            // expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            //     'formData',
            //     expect.objectContaining({
            //         billingInfoPage: { billingTermsId: 1 }
            //     })
            // );

            expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.objectContaining({
                    [PATHS.BILLING_INFO]: false // Or whatever the expected value is
                })
            );
        });
    });

    test('should call onSubmitChange on form submit', async () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });

        const { getByTestId } = render(
            <MemoryRouter>
                <BillingInfo />
            </MemoryRouter>
        );

        const form = getByTestId('companyProfilePage').querySelector('div');
        const mockSubmitEvent = { data: { billingTermsId: 1, billingPeriodId: 1 } };

        if (form) {
            fireEvent.submit(form, { target: { value: mockSubmitEvent } });
        }

        await waitFor(() => {
            // expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            //     'formData',
            //     expect.objectContaining({
            //         billingInfoPage: mockSubmitEvent.data
            //     })
            // );
            expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.objectContaining({
                    [PATHS.BILLING_INFO]: false // Or whatever the expected value is
                })
            );
        });
    });
});

describe('BillingInfo Component Store Updates', () => {
    let CompanyModuleData: StepperModuleStoreData<CompanyFormData>;

    beforeEach(() => {
        CompanyModuleData = {
            formData: {
                billingInfoPage: {},
                companyProfilePage: undefined,
                contacts: undefined,
                companyFileUpload: undefined
            },
            isFormValid: {}
        };

        companyStepperStore.getData = jest.fn(() => CompanyModuleData);
        companyStepperStore.updatePage = jest.fn();
    });

    it('should update form data and isValid when updateStore is called', () => {
        const updatedFormData = {
            billingTermsId: 2,
            billingPeriodId: 1
        };

        updateStore(updatedFormData, true, CompanyModuleData, companyStepperStore);

        expect(companyStepperStore.updatePage).toHaveBeenCalledTimes(2);
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'formData',
            expect.objectContaining({ billingInfoPage: updatedFormData })
        );
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'isFormValid',
            expect.objectContaining({
                [PATHS.BILLING_INFO]: true
            })
        );
    });
});
