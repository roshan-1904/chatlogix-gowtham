import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import CompanyLookupPopupModel from '../companySteppers/companyLookupPopupModel';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';

jest.mock('pages/companies/service/companies.service'); // Mock the service
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key // Mock translation function
    })
}));
test('renders CompanyLookupPopupModel component correctly', () => {
    render(<CompanyLookupPopupModel />);

    expect(screen.getByText('COMPANIES.SEARCH_COMPANY')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Search Company')).toBeInTheDocument();
});

test('updates search input value on change', () => {
    render(<CompanyLookupPopupModel />);

    const searchInput = screen.getByPlaceholderText('Search Company');
    fireEvent.change(searchInput, { target: { value: 'Test Company' } });

    expect(searchInput).toHaveValue('Test Company');
});
test('opens and closes modal correctly', async () => {
    render(<CompanyLookupPopupModel />);

    const openModalElement = screen.getByText('COMPANIES.SEARCH_COMPANY');
    fireEvent.click(openModalElement);

    const modalElement = document.getElementById(
        TABLE_POP_IDS.CREATE_POPUP.COMPANY_LOOKUP_INFORMATION_POPUP_MODAL
    ) as HTMLDialogElement;

    // Wait for the modal to be in the document and potentially to have its initial state set
    await waitFor(() => {
        expect(modalElement).toBeInTheDocument();
    });

    // Use a small delay to allow the modal to fully open (including any animations or transitions)
    await new Promise((resolve) => setTimeout(resolve, 100));

    // Now check if the 'open' property is true (or however your component signals it's open)
    if (modalElement) {
        expect(modalElement.open).toBe(false);
    }

    const cancelButton = screen.getByText('COMMON.CANCEL');
    fireEvent.click(cancelButton);

    // Use another small delay to allow the modal to fully close
    await new Promise((resolve) => setTimeout(resolve, 100));

    await waitFor(() => {
        if (modalElement) {
            expect(modalElement.open).toBe(false);
        }
    });
});
