// src/pages/companies/test/createCompanyMocks.ts

import { BillingInfoDetails, CompanyProfileDetails } from 'pages/companies/types/companies.types';
import {
    Country,
    CreateCompanyPayloadType,
    State
} from 'pages/companies/types/createCompany.types';

export const mockCountry: Country = {
    id: 1,
    name: 'Test Country',
    code: 'TC',
    iconName: 'icon-test',
    countryNameCode: 'Test Country Code',
    latitude: '0.0',
    longitude: '0.0'
};

export const mockState: State = {
    id: 1,
    name: 'Test State',
    code: 'TS'
};

export const mockCompanyData: CreateCompanyPayloadType = {
    id: 1,
    name: 'Test Company',
    companyType: 1,
    parentCompanyName: 'Parent Company',
    sageParentId: 'SAGE123',
    companyStatus: 'Active',
    customerTierLevel: 'Gold',
    parentCompanyId: 1,
    serviceAgreement: true,
    website: 'https://testcompany.com',
    primaryPhoneNumber: '123-456-7890',
    salesRepId: null,
    companyNotes: 'Test notes',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 1,
    grossProfit: 50,
    isAccountOnHold: false,
    rateId: 1,
    accountHoldReasonNotes: 'No hold',
    billingNotes: 'Billing notes',
    mailingAddress: {
        address1: '123 Test St',
        address2: 'Suite 100',
        city: 'Test City',
        state: 'Test State',
        stateId: 1,
        country: 'Test Country',
        countryId: 1,
        zip: '12345',
        billingEmail: 'billing@test.com',
        ccRecipients: 'cc@example.com'
    },
    contactDetails: [
        {
            id: 1,
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.doe@test.com',
            phoneNumber: '123-456-7890',
            roleId: 1
        }
    ],
    documentId: null,
    billingPeriodId: null,
    billingTypeId: null,
    isPoRequired: false,
    invoiceMode: '',
    invoiceDeliveryStatement: '',
    industryId: null,
    isAgreeTMDiscounts: false,
    ccRecipients: 'cc@example.com',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null
};

export const partialCompanyData: CreateCompanyPayloadType = {
    id: 2,
    name: 'Another Company',
    companyType: 2,
    parentCompanyName: '',
    sageParentId: '',
    companyStatus: 'Inactive',
    mailingAddress: {
        address1: '456 Another St',
        address2: '',
        city: 'Another City',
        state: 'Another State',
        stateId: 2,
        country: 'Another Country',
        countryId: 2,
        zip: '54321',
        billingEmail: 'billing@another.com',
        ccRecipients: ''
    },
    contactDetails: [
        {
            id: 2,
            firstName: 'Jane',
            lastName: 'Smith',
            email: 'jane.smith@another.com',
            phoneNumber: '987-654-3210',
            roleId: 2
        }
    ],
    currencyId: 2,
    isAccountOnHold: true,
    serviceAgreement: false
};

// Updated mock data based on provided structure
export const mockUpdatedFormData: {
    companyProfilePage: CompanyProfileDetails;
    billingInfoPage: BillingInfoDetails;
} = {
    companyProfilePage: {
        id: 678,
        container: { name: 'TestingDev123' },
        parentCompanyName: {
            companyId: 'C-06171',
            companyName: 'Customer Parent PC1',
            entityId: 'Top Level',
            isParentCompany: false,
            billingPeriod: '',
            industry: '',
            poRequired: 'No',
            modeOfInvoicing: null,
            billingType: '',
            billingEmailTo: '',
            billingEmailCc: '',
            isEntityParent: false,
            id: 0,
            name: null,
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: '',
            companyStatus: 'active',
            customerTierLevel: null,
            primaryPhoneNumber: '',
            salesRepName: '',
            city: '',
            state: 'CA',
            country: 'United States',
            billingEmail: '',
            updatedAt: '2024-08-01T14:00:20',
            updatedBy: null,
            createdAt: '2024-06-24T08:13:23',
            createdBy: null,
            status: null,
            address1: 'Suite 14',
            address2: '765 Antony Lane',
            zip: '94538',
            billingTerms: '',
            formofPayment: null,
            isAccountHoldStatus: null,
            preferredCurrency: '',
            grossProfit: null,
            isAccountOnHold: null,
            billingNotes: null,
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: null,
            sageSyncDetails:
                '{"RECORDNO":"10119","CUSTOMERID":"C-06171","NAME":"Customer Parent PC1","...}',
            sageSyncDate: null,
            sageId: 'C-06171',
            sageStatusSyncName: null,
            accountHoldReasonNotes: null,
            isActive: false,
            active: null
        },
        companyStatus: 'Prospecting',
        primaryPhoneNumber: '',
        website: '',
        industryId: 7,
        salesRepId: null,
        isAgreeTMDiscounts: 'yes',
        serviceAgreement: 'no',
        notes: '',
        customerTierLevel: '', // Optional field
        companyType: 0, // Ensure this value is correctly set
        serviceAgreementStartDate: null,
        serviceAgreementEndDate: null
    } as CompanyProfileDetails,
    billingInfoPage: {
        billingTermsId: null,
        billingPeriodId: null,
        billingTypeId: null,
        paymentTypeId: null,
        currencyId: 6,
        isPoRequired: 'no',
        invoiceMode: '',
        accountOnHold: 'no',
        reason: '',
        address1: 'Cbe',
        address2: '',
        city: 'Cbe',
        zip: '123456',
        billingEmail: 'test2523@mailinator.com',
        cc: '',
        billingNotes: '',
        grossProfit: 0,
        invoiceDeliveryStatement: '',
        state: {
            id: 347,
            name: 'Badakhshan',
            code: 'AF-BDS'
        }, // Ensure this is valid
        country: {
            id: 138,
            name: 'Afghanistan',
            code: 'AF',
            iconName: '122-afghanistan.svg',
            countryNameCode: 'Afghanistan',
            latitude: '33.93911',
            longitude: '67.709953'
        } // Ensure this is valid
    } as BillingInfoDetails
};

// Expected result based on updated data
export const expectedUpdatedResult: CreateCompanyPayloadType = {
    id: 678,
    name: 'TestingDev123',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyName: 'Customer Parent PC1',
    sageParentId: 'C-06171',
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: '',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 6,
    grossProfit: 0,
    isAccountOnHold: false,
    industryId: 7,
    isAgreeTMDiscounts: true,
    billingPeriodId: null,
    billingTypeId: null,
    isPoRequired: false,
    invoiceMode: '',
    invoiceDeliveryStatement: '',
    rateId: undefined,
    accountHoldReasonNotes: '',
    billingNotes: '',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    mailingAddress: {
        address1: 'Cbe',
        address2: '',
        city: 'Cbe',
        state: 'Badakhshan', // Assuming this is correct
        stateId: 347,
        country: 'Afghanistan', // Concatenated name and code
        countryId: 138,
        zip: '123456',
        billingEmail: 'test2523@mailinator.com',
        ccRecipients: ''
    },
    contactDetails: [] // Add contact details if available
};

// Mock data for optional fields test
export const mockPartialFormData: {
    companyProfilePage: CompanyProfileDetails;
    billingInfoPage: BillingInfoDetails;
} = {
    companyProfilePage: {
        id: 678, // Adjusted based on provided data
        container: { name: 'TestingDev123' },
        companyStatus: 'Prospecting',
        customerTierLevel: '',
        parentCompanyName: {
            companyId: 'C-06171',
            companyName: 'Customer Parent PC1',
            entityId: 'Top Level',
            isParentCompany: false,
            billingPeriod: '',
            industry: '',
            poRequired: 'No',
            modeOfInvoicing: null,
            billingType: '',
            billingEmailTo: '',
            billingEmailCc: '',
            isEntityParent: false,
            id: 0,
            name: null,
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: '',
            companyStatus: 'active',
            customerTierLevel: null,
            primaryPhoneNumber: '',
            salesRepName: '',
            city: '',
            state: 'CA',
            country: 'United States',
            billingEmail: '',
            updatedAt: '2024-08-01T14:00:20',
            updatedBy: null,
            createdAt: '2024-06-24T08:13:23',
            createdBy: null,
            status: null,
            address1: 'Suite 14',
            address2: '765 Antony Lane',
            zip: '94538',
            billingTerms: '',
            formofPayment: null,
            isAccountHoldStatus: null,
            preferredCurrency: '',
            grossProfit: null,
            isAccountOnHold: null,
            billingNotes: null,
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: null,
            sageSyncDetails:
                '{"RECORDNO":"10119","CUSTOMERID":"C-06171","NAME":"Customer Parent PC1","...}',
            sageSyncDate: null,
            sageId: 'C-06171',
            sageStatusSyncName: null,
            accountHoldReasonNotes: null,
            isActive: false,
            active: null
        },
        primaryPhoneNumber: '',
        website: '',
        industryId: 7,
        salesRepId: null,
        isAgreeTMDiscounts: 'yes',
        serviceAgreement: 'no',
        notes: '',
        serviceAgreementStartDate: null,
        serviceAgreementEndDate: null,
        companyType: 0 // Ensure this value is correctly set
    } as CompanyProfileDetails,
    billingInfoPage: {
        billingTermsId: null,
        billingPeriodId: null,
        billingTypeId: null,
        paymentTypeId: null,
        currencyId: 6,
        isPoRequired: 'no',
        invoiceMode: '',
        accountOnHold: 'no',
        reason: '',
        address1: 'Cbe',
        address2: '',
        city: 'Cbe',
        state: {
            id: 347,
            name: 'Badakhshan',
            code: 'AF-BDS'
        }, // Ensure this is valid
        country: {
            id: 138,
            name: 'Afghanistan',
            code: 'AF',
            iconName: '122-afghanistan.svg',
            countryNameCode: 'Afghanistan',
            latitude: '33.93911',
            longitude: '67.709953'
        }, // Ensure this is valid
        zip: '123456',
        billingEmail: 'test2523@mailinator.com',
        cc: '',
        billingNotes: '',
        grossProfit: 0,
        invoiceDeliveryStatement: '',
        submit: true // Assuming this is part of your billingInfoPage structure
    } as BillingInfoDetails
};

// Expected result based on updated mock data
export const expectedPartialResult: CreateCompanyPayloadType = {
    id: 678,
    name: 'TestingDev123',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyName: 'Customer Parent PC1',
    sageParentId: 'C-06171',
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: '',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 6,
    grossProfit: 0,
    isAccountOnHold: false,
    industryId: 7,
    isAgreeTMDiscounts: true,
    billingPeriodId: null,
    billingTypeId: null,
    isPoRequired: false,
    invoiceMode: '',
    invoiceDeliveryStatement: '',
    rateId: undefined, // Assuming no rate ID is provided
    accountHoldReasonNotes: '',
    billingNotes: '',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    mailingAddress: {
        address1: 'Cbe',
        address2: '',
        city: 'Cbe',
        state: 'Badakhshan', // Ensure this is valid
        stateId: 347, // Assuming you want to store state ID as well
        country: 'Afghanistan', // Concatenated name and code
        countryId: 138, // Assuming you want to store country ID
        zip: '123456',
        billingEmail: 'test2523@mailinator.com',
        ccRecipients: ''
    },
    contactDetails: [] // Add contact details if available
};
