import { CompanyRatesResponseType } from 'pages/companies/types/createCompany.types';

// mockCompanyData.ts
export const companyListResponse = {
    companyServiceModel: [
        {
            id: 539,
            name: 'Craton Company',
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: '',
            companyStatus: 'Prospecting',
            customerTierLevel: '',
            primaryPhoneNumber: '',
            salesRepName: null,
            city: 'test city',
            state: 'Queensland',
            country: 'Australia (AU)',
            billingEmail: 'test@gmail.com',
            updatedAt: '2024-08-01T10:21:06.6917145',
            updatedBy: 'Arthy',
            createdAt: '2024-08-01T09:14:21.7989171',
            createdBy: 'Arthy',
            status: null,
            address1: 'Address 1',
            address2: '',
            zip: '46332',
            billingTerms: null,
            formofPayment: null,
            isAccountHoldStatus: 'No',
            preferredCurrency: 'USD',
            grossProfit: 0,
            isAccountOnHold: false,
            billingNotes: '',
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: '2',
            sageSyncDetails: null,
            sageSyncDate: null,
            sageId: null,
            sageStatusSyncName: 'InProgress',
            accountHoldReasonNotes: '',
            isActive: true,
            active: 'Active',
            sageParentId: null
        },
        {
            id: 542,
            name: 'Testing4',
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: 'Test Contact Mapping',
            companyStatus: 'Prospecting',
            customerTierLevel: '',
            primaryPhoneNumber: '',
            salesRepName: null,
            city: 'Cbe',
            state: 'Badakhshan',
            country: 'Afghanistan (AF)',
            billingEmail: 'cbe@mailinator.com',
            updatedAt: '2024-08-01T10:19:42.0986818',
            updatedBy: 'Shenbagam',
            createdAt: '2024-08-01T10:19:22.5650631',
            createdBy: 'Shenbagam',
            status: null,
            address1: 'Cbe',
            address2: 'Cbe',
            zip: '123545',
            billingTerms: null,
            formofPayment: null,
            isAccountHoldStatus: 'No',
            preferredCurrency: 'EUR',
            grossProfit: 0,
            isAccountOnHold: false,
            billingNotes: '',
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: '2',
            sageSyncDetails: null,
            sageSyncDate: null,
            sageId: null,
            sageStatusSyncName: 'InProgress',
            accountHoldReasonNotes: '',
            isActive: true,
            active: 'Active',
            sageParentId: 'C-06445'
        },
        {
            id: 541,
            name: 'Tick and Toe',
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: '',
            companyStatus: 'Prospecting',
            customerTierLevel: '',
            primaryPhoneNumber: '',
            salesRepName: 'Lara  a',
            city: 'CBE',
            state: 'Tamil Nadu',
            country: 'India  (IN)',
            billingEmail: 'biglcontactuser2024+bobby@gmail.com',
            updatedAt: '2024-08-01T10:13:21.4592655',
            updatedBy: 'Priya',
            createdAt: '2024-08-01T09:56:56.782299',
            createdBy: 'Sara  a',
            status: null,
            address1: '3424 Peachtree Road NE',
            address2: '',
            zip: '30326',
            billingTerms: null,
            formofPayment: null,
            isAccountHoldStatus: 'Yes',
            preferredCurrency: 'USD',
            grossProfit: 0,
            isAccountOnHold: true,
            billingNotes: '',
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: '2',
            sageSyncDetails: null,
            sageSyncDate: null,
            sageId: null,
            sageStatusSyncName: 'InProgress',
            accountHoldReasonNotes: 'Yes it is hold',
            isActive: true,
            active: 'Active',
            sageParentId: null
        },
        {
            id: 540,
            name: 'Test company for contact',
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: 'Test Contact Mapping',
            companyStatus: 'Prospecting',
            customerTierLevel: '',
            primaryPhoneNumber: '',
            salesRepName: null,
            city: 'test address',
            state: 'Daykundi',
            country: 'Afghanistan (AF)',
            billingEmail: 'priyanga435+test1@gmail.com',
            updatedAt: '2024-08-01T09:37:29.795178',
            updatedBy: 'Pradeep Gopal',
            createdAt: '2024-08-01T09:29:31.0694615',
            createdBy: 'Mekala Nantha',
            status: null,
            address1: 'test address',
            address2: '',
            zip: '0989798',
            billingTerms: null,
            formofPayment: null,
            isAccountHoldStatus: 'No',
            preferredCurrency: 'AUD',
            grossProfit: 0,
            isAccountOnHold: false,
            billingNotes: '',
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: '2',
            sageSyncDetails: null,
            sageSyncDate: null,
            sageId: null,
            sageStatusSyncName: 'InProgress',
            accountHoldReasonNotes: '',
            isActive: true,
            active: 'Active',
            sageParentId: 'C-06445'
        },
        {
            id: 538,
            name: 'Test CMP 876',
            companyTypeName: null,
            companyType: 0,
            parentCompanyName: '',
            companyStatus: 'Prospecting',
            customerTierLevel: '',
            primaryPhoneNumber: '',
            salesRepName: null,
            city: 'KL',
            state: 'Badghis',
            country: 'Afghanistan (AF)',
            billingEmail: 'test@Gmail.com',
            updatedAt: '2024-08-01T06:35:23.1164895',
            updatedBy: 'Arthy',
            createdAt: '2024-08-01T06:14:05.3150943',
            createdBy: 'Umasankar Govindaraj',
            status: null,
            address1: 'Address',
            address2: '',
            zip: '8273897298',
            billingTerms: null,
            formofPayment: null,
            isAccountHoldStatus: 'No',
            preferredCurrency: 'AUD',
            grossProfit: 0,
            isAccountOnHold: false,
            billingNotes: '',
            deletedBy: null,
            deletedAt: null,
            restoredBy: null,
            restoredAt: null,
            sageSyncStatus: '2',
            sageSyncDetails: null,
            sageSyncDate: null,
            sageId: null,
            sageStatusSyncName: 'InProgress',
            accountHoldReasonNotes: '',
            isActive: true,
            active: 'Active',
            sageParentId: null
        }
    ],
    totalRecords: 506
};

export const companyListRequest = {
    searchModels: [],
    sorting: {
        propertyName: '',
        value: ''
    },
    pageNo: 1,
    pageCount: 5
};
export const CreateCompanyRequest = {
    name: 'Test company for contact',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyName: 'Test Contact Mapping',
    sageParentId: 'C-06445',
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: 'testone',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 1,
    grossProfit: 0,
    isAccountOnHold: false,
    industryId: 5,
    isAgreeTMDiscounts: false,
    billingPeriodId: null,
    billingTypeId: null,
    isPoRequired: false,
    invoiceMode: '',
    invoiceDeliveryStatement: 'Email',
    accountHoldReasonNotes: '',
    billingNotes: '',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    mailingAddress: {
        address1: 'test address',
        address2: '',
        city: 'test address',
        state: 'Daykundi',
        stateId: 218,
        country: 'Afghanistan (AF)',
        countryId: 138,
        zip: '0989798',
        billingEmail: 'priyanga435+test1@gmail.com',
        ccRecipients: ''
    },
    contactDetails: []
};
export const createCompanyResponse = {
    contactDetails: [],
    model: 'Company',
    name: 'Test company for contact',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyId: null,
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: 'testone',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 1,
    grossProfit: 0,
    isAccountOnHold: false,
    accountHoldReasonNotes: '',
    billingNotes: '',
    isPoRequired: false,
    preferredCurrencies: null,
    mailingAddress: {
        address1: 'test address',
        address2: '',
        city: 'test address',
        state: 'Daykundi',
        stateId: 218,
        country: 'Afghanistan (AF)',
        countryId: 138,
        zip: '0989798',
        billingEmail: 'priyanga435+test1@gmail.com',
        ccRecipients: '',
        isSameAddress: null
    },
    industryId: 5,
    isAgreeTMDiscounts: false,
    billingPeriodId: null,
    billingTypeId: null,
    invoiceMode: '',
    invoiceDeliveryStatement: 'Email',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    parentCompanyName: 'Test Contact Mapping',
    sageParentId: 'C-06445',
    id: 540,
    createdBy: null,
    createdAt: '0001-01-01T00:00:00',
    updatedBy: null,
    updatedAt: null,
    isActive: false
};
export const updateCompanyRequest = {
    name: 'update company for contact',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyName: 'Test Contact Mapping',
    sageParentId: 'C-06445',
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: 'testone',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 1,
    grossProfit: 0,
    isAccountOnHold: false,
    industryId: 5,
    isAgreeTMDiscounts: false,
    billingPeriodId: null,
    billingTypeId: null,
    isPoRequired: false,
    invoiceMode: '',
    invoiceDeliveryStatement: 'Email',
    accountHoldReasonNotes: '',
    billingNotes: '',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    mailingAddress: {
        address1: 'test address',
        address2: '',
        city: 'test address',
        state: 'Daykundi',
        stateId: 218,
        country: 'Afghanistan (AF)',
        countryId: 138,
        zip: '0989798',
        billingEmail: 'priyanga435+test1@gmail.com',
        ccRecipients: ''
    },
    contactDetails: []
};
export const companyUpdateDataResponse = {
    contactDetails: [],
    model: 'Company',
    name: 'Test company for contact',
    companyType: 0,
    companyStatus: 'Prospecting',
    customerTierLevel: '',
    parentCompanyId: null,
    serviceAgreement: false,
    website: '',
    primaryPhoneNumber: '',
    salesRepId: null,
    companyNotes: 'testone',
    billingTermsId: null,
    paymentTypeId: null,
    currencyId: 1,
    grossProfit: 0,
    isAccountOnHold: false,
    accountHoldReasonNotes: '',
    billingNotes: '',
    isPoRequired: false,
    preferredCurrencies: null,
    mailingAddress: {
        address1: 'test address',
        address2: '',
        city: 'test address',
        state: 'Daykundi',
        stateId: 218,
        country: 'Afghanistan (AF)',
        countryId: 138,
        zip: '0989798',
        billingEmail: 'priyanga435+test1@gmail.com',
        ccRecipients: '',
        isSameAddress: null
    },
    industryId: 5,
    isAgreeTMDiscounts: false,
    billingPeriodId: null,
    billingTypeId: null,
    invoiceMode: '',
    invoiceDeliveryStatement: 'Email',
    serviceAgreementStartDate: null,
    serviceAgreementEndDate: null,
    parentCompanyName: 'Test Contact Mapping',
    sageParentId: 'C-06445',
    id: 540,
    createdBy: null,
    createdAt: '0001-01-01T00:00:00',
    updatedBy: null,
    updatedAt: null,
    isActive: false
};

export const sourceLanguagesResponse = [
    {
        id: 38,
        name: 'English',
        isocode: 'ENG',
        abbreviation: 'en'
    },
    {
        id: 51,
        name: 'French',
        isocode: 'FRE',
        abbreviation: 'fr'
    },
    {
        id: 59,
        name: 'German',
        isocode: 'GER',
        abbreviation: 'de'
    }
];
export const requestCurrencyResponse = [
    {
        name: 'Australian Dollar',
        isoCode: 'AUD',
        currencySymbol: 'AU$',
        currencyId: 0,
        concatNameCode: 'Australian Dollar - AUD (AU$)',
        id: 1,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    },
    {
        name: 'US Dollar',
        isoCode: 'USD',
        currencySymbol: '$',
        currencyId: 0,
        concatNameCode: 'US Dollar - USD ($)',
        id: 2,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    },
    {
        name: 'Pound Sterling',
        isoCode: 'GBP',
        currencySymbol: '£',
        currencyId: 0,
        concatNameCode: 'Pound Sterling - GBP (£)',
        id: 3,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    },
    {
        name: 'New Zealand Dollar',
        isoCode: 'NZD',
        currencySymbol: 'NZ$',
        currencyId: 0,
        concatNameCode: 'New Zealand Dollar - NZD (NZ$)',
        id: 4,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    },
    {
        name: 'Canadian Dollar',
        isoCode: 'CAD',
        currencySymbol: 'C$',
        currencyId: 0,
        concatNameCode: 'Canadian Dollar - CAD (C$)',
        id: 5,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    },
    {
        name: 'Euro',
        isoCode: 'EUR',
        currencySymbol: '€',
        currencyId: 0,
        concatNameCode: 'Euro - EUR (€)',
        id: 6,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    }
];
export const getIPresponse = {
    companyRateDetailList: [
        {
            companyTranslationRate: 0.12,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '(20+(({Abstractwordcount}+{DescriptionWordCount}+{DrawingsWordCount}+{Claimswordcount})*{ENGIndirectTranslationRate})+(4*{DrawingsPageCount}))',
                fee: 0
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '1.17*(142+56.7+22.7*{NumberofPriorities}+IF({TotalPageCount}>10,16*ROUNDUP(({TotalPageCount}-10)/5,0),0)+6*{DrawingsPageCount})',
                fee: 0
            },
            companyAgencyFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '750+175+(100*{NumberofPriorities})+IF({TotalPageCount}>10,45*ROUNDUP(({SpecificationPageCount}-10)/5,0),0)+25*{DrawingsPageCount}',
                fee: 0
            },
            companyTranslationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"(20+(({Abstractwordcount}+{DescriptionWordCount}+{DrawingsWordCount}+{Claimswordcount})*{ENGIndirectTranslationRate})+(4*{DrawingsPageCount}))","Fee":0.0}',
            companyOfficialFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"1.17*(142+56.7+22.7*{NumberofPriorities}+IF({TotalPageCount}>10,16*ROUNDUP(({TotalPageCount}-10)/5,0),0)+6*{DrawingsPageCount})","Fee":0.0}',
            companyAgencyFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"750+175+(100*{NumberofPriorities})+IF({TotalPageCount}>10,45*ROUNDUP(({SpecificationPageCount}-10)/5,0),0)+25*{DrawingsPageCount}","Fee":0.0}',
            id: 329386,
            countryId: 1,
            countryIcon: '126-algeria.svg',
            countryName: 'Algeria',
            languageId: 5,
            languageName: 'Arabic',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.12,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '(20+(({Abstractwordcount}+{DescriptionWordCount}+{DrawingsWordCount}+{Claimswordcount})*{ENGIndirectTranslationRate})+(4*{DrawingsPageCount}))',
                fee: 0
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '1.17*(142+56.7+22.7*{NumberofPriorities}+IF({TotalPageCount}>10,16*ROUNDUP(({TotalPageCount}-10)/5,0),0)+6*{DrawingsPageCount})',
                fee: 0
            },
            agencyFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '750+175+(100*{NumberofPriorities})+IF({TotalPageCount}>10,45*ROUNDUP(({SpecificationPageCount}-10)/5,0),0)+25*{DrawingsPageCount}',
                fee: 0
            },
            translationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"(20+(({Abstractwordcount}+{DescriptionWordCount}+{DrawingsWordCount}+{Claimswordcount})*{ENGIndirectTranslationRate})+(4*{DrawingsPageCount}))","Fee":0.0}',
            officialFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"1.17*(142+56.7+22.7*{NumberofPriorities}+IF({TotalPageCount}>10,16*ROUNDUP(({TotalPageCount}-10)/5,0),0)+6*{DrawingsPageCount})","Fee":0.0}',
            agencyFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"750+175+(100*{NumberofPriorities})+IF({TotalPageCount}>10,45*ROUNDUP(({SpecificationPageCount}-10)/5,0),0)+25*{DrawingsPageCount}","Fee":0.0}'
        },
        {
            companyTranslationRate: 0,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 875
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula: '334+(98*18)',
                fee: 0
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 1300
            },
            companyTranslationFeeDetail:
                '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":875.0}',
            companyOfficialFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"334+(98*18)","Fee":0.0}',
            companyAgencyFeeDetail:
                '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":1300.0}',
            id: 329387,
            countryId: 2,
            countryIcon: 'ARIPO.svg',
            countryName: 'Aripo',
            languageId: 38,
            languageName: 'English',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0,
            translationFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 875
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula: '334+(98*18)',
                fee: 0
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 1300
            },
            translationFeeDetail: '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":875.0}',
            officialFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"334+(98*18)","Fee":0.0}',
            agencyFeeDetail: '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":1300.0}'
        },
        {
            companyTranslationRate: 0,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 10
            },
            companyOfficialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 300
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 675
            },
            companyTranslationFeeDetail:
                '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":10.0}',
            companyOfficialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "300.00 "}',
            companyAgencyFeeDetail:
                '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":675.0}',
            id: 329388,
            countryId: 3,
            countryIcon: '130-australia.svg',
            countryName: 'Australia',
            languageId: 38,
            languageName: 'English',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0,
            translationFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 10
            },
            officialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 300
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: '',
                fee: 675
            },
            translationFeeDetail: '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":10.0}',
            officialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "300.00 "}',
            agencyFeeDetail: '{"FeeType":"Flat Fee","UnitTypeId":1,"Formula":"","Fee":675.0}'
        },
        {
            companyTranslationRate: 0.12,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '(20+(({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount})*{TranslationRate})+(4*{DrawingsPageCount}))',
                fee: 0
            },
            companyOfficialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 1435
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 700
            },
            companyTranslationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"(20+(({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount})*{TranslationRate})+(4*{DrawingsPageCount}))","Fee":0.0}',
            companyOfficialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "1435.00 "}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "700.00 "}',
            id: 329389,
            countryId: 4,
            countryIcon: '116-bahrain.svg',
            countryName: 'Bahrain',
            languageId: 5,
            languageName: 'Arabic',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.12,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '(20+(({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount})*{TranslationRate})+(4*{DrawingsPageCount}))',
                fee: 0
            },
            officialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 1435
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 700
            },
            translationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"(20+(({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount})*{TranslationRate})+(4*{DrawingsPageCount}))","Fee":0.0}',
            officialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "1435.00 "}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "700.00 "}'
        },
        {
            companyTranslationRate: 0.12,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    'SUM({TranslationRate}*({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount}))+4*{DrawingsPageCount}',
                fee: null
            },
            companyOfficialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 60
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 500
            },
            companyTranslationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "SUM({TranslationRate}*({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount}))+4*{DrawingsPageCount}", "Fee": null}',
            companyOfficialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "60.00"}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "500.00 "}',
            id: 329390,
            countryId: 5,
            countryIcon: '250-brazil.svg',
            countryName: 'Brazil',
            languageId: 109,
            languageName: 'Portuguese',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.12,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    'SUM({TranslationRate}*({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount}))+4*{DrawingsPageCount}',
                fee: null
            },
            officialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 60
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 500
            },
            translationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "SUM({TranslationRate}*({AbstractWordCount}+{DescriptionWordCount}+{DrawingsWordCount}+{ClaimsWordCount}))+4*{DrawingsPageCount}", "Fee": null}',
            officialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "60.00"}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "500.00 "}'
        },
        {
            companyTranslationRate: 0.18,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}',
                fee: null
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: '85+IF({NumberofClaims}>10,5.5*({NumberofClaims}-10),0)',
                fee: null
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 700
            },
            companyTranslationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}", "Fee": null}',
            companyOfficialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "85+IF({NumberofClaims}>10,5.5*({NumberofClaims}-10),0)", "Fee": null}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "700.00 "}',
            id: 329391,
            countryId: 6,
            countryIcon: '132-cambodia.svg',
            countryName: 'Cambodia',
            languageId: 79,
            languageName: 'Khmer',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.18,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}',
                fee: null
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: '85+IF({NumberofClaims}>10,5.5*({NumberofClaims}-10),0)',
                fee: null
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 700
            },
            translationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}", "Fee": null}',
            officialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "85+IF({NumberofClaims}>10,5.5*({NumberofClaims}-10),0)", "Fee": null}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "700.00 "}'
        },
        {
            companyTranslationRate: 0,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: null,
                unitTypeId: 0,
                formula: null,
                fee: 0
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: 'IF({Entity}={Small}, 165, IF({Entity}={Large}, 325))',
                fee: null
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 850
            },
            companyTranslationFeeDetail: '',
            companyOfficialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "IF({Entity}={Small}, 165, IF({Entity}={Large}, 325))", "Fee": null}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "850.00 "}',
            id: 329392,
            countryId: 7,
            countryIcon: '206-canada.svg',
            countryName: 'Canada',
            languageId: 38,
            languageName: 'English',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0,
            translationFeeModel: {
                feeType: null,
                unitTypeId: 0,
                formula: null,
                fee: 0
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: 'IF({Entity}={Small}, 165, IF({Entity}={Large}, 325))',
                fee: null
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 850
            },
            translationFeeDetail: '',
            officialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "IF({Entity}={Small}, 165, IF({Entity}={Large}, 325))", "Fee": null}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "850.00 "}'
        },
        {
            companyTranslationRate: 0.11,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '{TranslationRate}*({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})',
                fee: 0
            },
            companyOfficialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 80
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 600
            },
            companyTranslationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"{TranslationRate}*({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})","Fee":0.0}',
            companyOfficialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "80.00 "}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "600.00 "}',
            id: 329393,
            countryId: 8,
            countryIcon: '051-chile.svg',
            countryName: 'Chile',
            languageId: 125,
            languageName: 'Spanish',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.11,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: 0,
                formula:
                    '{TranslationRate}*({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})',
                fee: 0
            },
            officialFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 80
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 600
            },
            translationFeeDetail:
                '{"FeeType":"Formula","UnitTypeId":0,"Formula":"{TranslationRate}*({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})","Fee":0.0}',
            officialFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "80.00 "}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "600.00 "}'
        },
        {
            companyTranslationRate: 0.13,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({TranslationRate}*({AbstractWordCount}+({DrawingsWordCount}+{DescriptionWordCount})+{ClaimsWordCount}))+4*{DrawingsPageCount}',
                fee: null
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    'SUM(153+(13*{NumberofPriorities})+IF({NumberofClaims}>10,24.5*({NumberofClaims}-10))+IF(AND(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>30,({SpecificationPageCount}*0.7)+{DrawingsPageCount}<300),8.5*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-30))+IF(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>300,2295+(16*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-300))))',
                fee: null
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 600
            },
            companyTranslationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({TranslationRate}*({AbstractWordCount}+({DrawingsWordCount}+{DescriptionWordCount})+{ClaimsWordCount}))+4*{DrawingsPageCount}", "Fee": null}',
            companyOfficialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "SUM(153+(13*{NumberofPriorities})+IF({NumberofClaims}>10,24.5*({NumberofClaims}-10))+IF(AND(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>30,({SpecificationPageCount}*0.7)+{DrawingsPageCount}<300),8.5*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-30))+IF(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>300,2295+(16*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-300))))", "Fee": null}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "600.00 "}',
            id: 329394,
            countryId: 9,
            countryIcon: '261-china.svg',
            countryName: 'China',
            languageId: 21,
            languageName: 'Chinese (Simplified)',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.13,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({TranslationRate}*({AbstractWordCount}+({DrawingsWordCount}+{DescriptionWordCount})+{ClaimsWordCount}))+4*{DrawingsPageCount}',
                fee: null
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    'SUM(153+(13*{NumberofPriorities})+IF({NumberofClaims}>10,24.5*({NumberofClaims}-10))+IF(AND(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>30,({SpecificationPageCount}*0.7)+{DrawingsPageCount}<300),8.5*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-30))+IF(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>300,2295+(16*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-300))))',
                fee: null
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 600
            },
            translationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({TranslationRate}*({AbstractWordCount}+({DrawingsWordCount}+{DescriptionWordCount})+{ClaimsWordCount}))+4*{DrawingsPageCount}", "Fee": null}',
            officialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "SUM(153+(13*{NumberofPriorities})+IF({NumberofClaims}>10,24.5*({NumberofClaims}-10))+IF(AND(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>30,({SpecificationPageCount}*0.7)+{DrawingsPageCount}<300),8.5*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-30))+IF(({SpecificationPageCount}*0.7)+{DrawingsPageCount}>300,2295+(16*((({SpecificationPageCount}*0.7)+{DrawingsPageCount})-300))))", "Fee": null}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "600.00 "}'
        },
        {
            companyTranslationRate: 0.11,
            companyEngIndirectTranslationRate: null,
            companyTranslationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}',
                fee: null
            },
            companyOfficialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: '26+IF({NumberofClaims}>10,14*({NumberofClaims}-10),0)',
                fee: null
            },
            companyAgencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 950
            },
            companyTranslationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}", "Fee": null}',
            companyOfficialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "26+IF({NumberofClaims}>10,14*({NumberofClaims}-10),0)", "Fee": null}',
            companyAgencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "950.00 "}',
            id: 329395,
            countryId: 10,
            countryIcon: '062-colombia.svg',
            countryName: 'Colombia',
            languageId: 125,
            languageName: 'Spanish',
            targetLanguage: null,
            isDirectTranslation: null,
            isEngDescriptionTranslationRequired: null,
            engIndirectTranslationRate: null,
            translationRate: 0.11,
            translationFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula:
                    '({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}',
                fee: null
            },
            officialFeeModel: {
                feeType: 'Formula',
                unitTypeId: null,
                formula: '26+IF({NumberofClaims}>10,14*({NumberofClaims}-10),0)',
                fee: null
            },
            agencyFeeModel: {
                feeType: 'Flat Fee',
                unitTypeId: 1,
                formula: null,
                fee: 950
            },
            translationFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "({Abstractwordcount}+({DrawingsWordCount}+{DescriptionWordCount})+{Claimswordcount})*{TranslationRate}", "Fee": null}',
            officialFeeDetail:
                '{"FeeType": "Formula", "UnitTypeId": null, "Formula": "26+IF({NumberofClaims}>10,14*({NumberofClaims}-10),0)", "Fee": null}',
            agencyFeeDetail:
                '{"FeeType": "FlatFee", "UnitTypeId": 1, "Formula": null, "Fee": "950.00 "}'
        }
    ],
    agencyFeeInfo: 0,
    descriptionTranslationFormula: '',
    totalCount: 40,
    currencyData: {
        currencyId: 2,
        currencyName: 'US Dollar',
        currencyIcon: null,
        concatCode: null,
        currencyCode: 'USD',
        currencySymbol: '$',
        isPreferredCurrency: null
    },
    ipRateDetailList: null
};
export const CompanyRatesRequest: CompanyRatesResponseType = {
    patentServiceId: 1,
    sourceLanguageId: 38,
    requestCurrencyId: 2,
    targetLanguageId: 0,
    companyId: 540,
    filterRequestModel: {
        searchModels: [
            {
                propertyName: '',
                value: ''
            }
        ],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    }
};

export const preferredCurrencyResponse = [
    {
        currencyId: 1,
        currencyName: 'Australian Dollar',
        currencyIcon: '130-australia.svg',
        concatCode: null,
        currencyCode: 'AUD',
        currencySymbol: 'AU$',
        isPreferredCurrency: false
    },
    {
        currencyId: 5,
        currencyName: 'Canadian Dollar',
        currencyIcon: '206-canada.svg',
        concatCode: null,
        currencyCode: 'CAD',
        currencySymbol: 'C$',
        isPreferredCurrency: false
    },
    {
        currencyId: 6,
        currencyName: 'Euro',
        currencyIcon: '022-european-union.svg',
        concatCode: null,
        currencyCode: 'EUR',
        currencySymbol: '€',
        isPreferredCurrency: false
    },
    {
        currencyId: 4,
        currencyName: 'New Zealand Dollar',
        currencyIcon: '048-new-zealand.svg',
        concatCode: null,
        currencyCode: 'NZD',
        currencySymbol: 'NZ$',
        isPreferredCurrency: false
    },
    {
        currencyId: 3,
        currencyName: 'Pound Sterling',
        currencyIcon: '262-united-kingdom.svg',
        concatCode: null,
        currencyCode: 'GBP',
        currencySymbol: '£',
        isPreferredCurrency: false
    },
    {
        currencyId: 2,
        currencyName: 'US Dollar',
        currencyIcon: '153-united-states-of-america.svg',
        concatCode: null,
        currencyCode: 'USD',
        currencySymbol: '$',
        isPreferredCurrency: true
    }
];
export const sageCompanyResponse = [
    {
        companyId: 'C-06445',
        companyName: 'Test Contact Mapping',
        entityId: 'Top Level',
        isParentCompany: false,
        billingPeriod: '',
        industry: '',
        poRequired: 'No',
        modeOfInvoicing: null,
        billingType: '',
        billingEmailTo: '',
        billingEmailCc: '',
        isEntityParent: false,
        id: 0,
        name: null,
        companyTypeName: null,
        companyType: 0,
        parentCompanyName: '',
        companyStatus: 'active',
        customerTierLevel: null,
        primaryPhoneNumber: '',
        salesRepName: '',
        city: 'Coimbatore',
        state: 'KY',
        country: 'United States',
        billingEmail: '',
        updatedAt: '2024-07-31T07:18:31',
        updatedBy: null,
        createdAt: '2024-07-31T07:14:54',
        createdBy: null,
        status: null,
        address1: 'S 78',
        address2: 'DIJ32',
        zip: '',
        billingTerms: '',
        formofPayment: null,
        isAccountHoldStatus: null,
        preferredCurrency: '',
        grossProfit: null,
        isAccountOnHold: null,
        billingNotes: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null,
        sageSyncStatus: null,
        sageSyncDetails:
            '{"RECORDNO":"11114","CUSTOMERID":"C-06445","NAME":"Test Contact Mapping","ENTITY":"CC-06445","PARENTKEY":"","PARENTID":"","PARENTNAME":"","DISPLAYCONTACT.CONTACTNAME":"Test Contact Mapping(CC-06445)","DISPLAYCONTACT.COMPANYNAME":"Test Contact Mapping","DISPLAYCONTACT.PREFIX":"","DISPLAYCONTACT.FIRSTNAME":"Test","DISPLAYCONTACT.LASTNAME":"Mapping","DISPLAYCONTACT.INITIAL":"","DISPLAYCONTACT.PRINTAS":"Test Contact Mapping","DISPLAYCONTACT.TAXABLE":"true","DISPLAYCONTACT.TAXGROUP":"","DISPLAYCONTACT.TAXSOLUTIONKEY":"","DISPLAYCONTACT.TAXSOLUTIONID":"","DISPLAYCONTACT.TAXSCHEDULE":"","DISPLAYCONTACT.TAXID":"","DISPLAYCONTACT.SIRET":"","DISPLAYCONTACT.PHONE1":"","DISPLAYCONTACT.PHONE2":"","DISPLAYCONTACT.CELLPHONE":"","DISPLAYCONTACT.PAGER":"","DISPLAYCONTACT.FAX":"","DISPLAYCONTACT.TAXIDVALIDATIONDATE":"","DISPLAYCONTACT.GSTREGISTERED":"","DISPLAYCONTACT.TAXCOMPANYNAME":"","DISPLAYCONTACT.TAXADDRESS":"","DISPLAYCONTACT.EMAIL1":"","DISPLAYCONTACT.EMAIL2":"","DISPLAYCONTACT.URL1":"","DISPLAYCONTACT.URL2":"","DISPLAYCONTACT.VISIBLE":"true","DISPLAYCONTACT.MAILADDRESS.ADDRESS1":"S 78","DISPLAYCONTACT.MAILADDRESS.ADDRESS2":"DIJ32","DISPLAYCONTACT.MAILADDRESS.ADDRESS3":"","DISPLAYCONTACT.MAILADDRESS.CITY":"Coimbatore","DISPLAYCONTACT.MAILADDRESS.STATE":"KY","DISPLAYCONTACT.MAILADDRESS.ZIP":"","DISPLAYCONTACT.MAILADDRESS.COUNTRY":"United States","DISPLAYCONTACT.MAILADDRESS.COUNTRYCODE":"US","DISPLAYCONTACT.MAILADDRESS.LATITUDE":"","DISPLAYCONTACT.MAILADDRESS.LONGITUDE":"","DISPLAYCONTACT.STATUS":"active","TERMNAME":"","TERMVALUE":"","CUSTREPID":"","CUSTREPNAME":"","RESALENO":"","TAXID":"","CREDITLIMIT":"","TOTALDUE":"0","COMMENTS":"","ACCOUNTLABEL":"","ARACCOUNT":"","ARACCOUNTTITLE":"","LAST_INVOICEDATE":"","LAST_STATEMENTDATE":"","DELIVERY_OPTIONS":"Print","TERRITORYID":"","TERRITORYNAME":"","SHIPPINGMETHOD":"","CUSTTYPE":"","GLGRPKEY":"","GLGROUP":"","PRICESCHEDULE":"","DISCOUNT":"","PRICELIST":"","VSOEPRICELIST":"","CURRENCY":"","CONTACTINFO.CONTACTNAME":"","CONTACTINFO.PREFIX":"","CONTACTINFO.FIRSTNAME":"","CONTACTINFO.INITIAL":"","CONTACTINFO.LASTNAME":"","CONTACTINFO.COMPANYNAME":"","CONTACTINFO.PRINTAS":"","CONTACTINFO.PHONE1":"","CONTACTINFO.PHONE2":"","CONTACTINFO.CELLPHONE":"","CONTACTINFO.PAGER":"","CONTACTINFO.FAX":"","CONTACTINFO.EMAIL1":"","CONTACTINFO.EMAIL2":"","CONTACTINFO.URL1":"","CONTACTINFO.URL2":"","CONTACTINFO.VISIBLE":"","CONTACTINFO.MAILADDRESS.ADDRESS1":"","CONTACTINFO.MAILADDRESS.ADDRESS2":"","CONTACTINFO.MAILADDRESS.ADDRESS3":"","CONTACTINFO.MAILADDRESS.CITY":"","CONTACTINFO.MAILADDRESS.STATE":"","CONTACTINFO.MAILADDRESS.ZIP":"","CONTACTINFO.MAILADDRESS.COUNTRY":"","CONTACTINFO.MAILADDRESS.COUNTRYCODE":"","SHIPTO.CONTACTNAME":"","SHIPTO.PREFIX":"","SHIPTO.FIRSTNAME":"","SHIPTO.INITIAL":"","SHIPTO.LASTNAME":"","SHIPTO.COMPANYNAME":"","SHIPTO.PRINTAS":"","SHIPTO.TAXABLE":"","SHIPTO.TAXGROUP":"","SHIPTO.TAXSOLUTIONKEY":"","SHIPTO.TAXSOLUTIONID":"","SHIPTO.TAXSCHEDULE":"","SHIPTO.TAXID":"","SHIPTO.PHONE1":"","SHIPTO.PHONE2":"","SHIPTO.CELLPHONE":"","SHIPTO.PAGER":"","SHIPTO.FAX":"","SHIPTO.EMAIL1":"","SHIPTO.EMAIL2":"","SHIPTO.URL1":"","SHIPTO.URL2":"","SHIPTO.VISIBLE":"","SHIPTO.MAILADDRESS.ADDRESS1":"","SHIPTO.MAILADDRESS.ADDRESS2":"","SHIPTO.MAILADDRESS.ADDRESS3":"","SHIPTO.MAILADDRESS.CITY":"","SHIPTO.MAILADDRESS.STATE":"","SHIPTO.MAILADDRESS.ZIP":"","SHIPTO.MAILADDRESS.COUNTRY":"","SHIPTO.MAILADDRESS.COUNTRYCODE":"","BILLTO.CONTACTNAME":"","BILLTO.PREFIX":"","BILLTO.FIRSTNAME":"","BILLTO.INITIAL":"","BILLTO.LASTNAME":"","BILLTO.COMPANYNAME":"","BILLTO.PRINTAS":"","BILLTO.TAXABLE":"","BILLTO.TAXGROUP":"","BILLTO.TAXSOLUTIONKEY":"","BILLTO.TAXSOLUTIONID":"","BILLTO.TAXSCHEDULE":"","BILLTO.PHONE1":"","BILLTO.PHONE2":"","BILLTO.CELLPHONE":"","BILLTO.PAGER":"","BILLTO.FAX":"","BILLTO.EMAIL1":"","BILLTO.EMAIL2":"","BILLTO.URL1":"","BILLTO.URL2":"","BILLTO.VISIBLE":"","BILLTO.MAILADDRESS.ADDRESS1":"","BILLTO.MAILADDRESS.ADDRESS2":"","BILLTO.MAILADDRESS.ADDRESS3":"","BILLTO.MAILADDRESS.CITY":"","BILLTO.MAILADDRESS.STATE":"","BILLTO.MAILADDRESS.ZIP":"","BILLTO.MAILADDRESS.COUNTRY":"","BILLTO.MAILADDRESS.COUNTRYCODE":"","STATUS":"active","ONETIME":"false","CUSTMESSAGEID":"","ONHOLD":"false","PRCLST_OVERRIDE":"C","OEPRCLSTKEY":"","OEPRICESCHEDKEY":"","ENABLEONLINECARDPAYMENT":"true","ENABLEONLINEACHPAYMENT":"true","VSOEPRCLSTKEY":"","WHENMODIFIED":"07/31/2024 07:18:31","ARINVOICEPRINTTEMPLATEID":"","OEQUOTEPRINTTEMPLATEID":"","OEORDERPRINTTEMPLATEID":"","OELISTPRINTTEMPLATEID":"","OEINVOICEPRINTTEMPLATEID":"","OEADJPRINTTEMPLATEID":"","OEOTHERPRINTTEMPLATEID":"","WHENCREATED":"07/31/2024 07:14:54","CREATEDBY":"62","MODIFIEDBY":"62","DISPLAYCONTACTKEY":"147610","CONTACTKEY":"","SHIPTOKEY":"","BILLTOKEY":"","CUSTREPKEY":"","SHIPVIAKEY":"","TERRITORYKEY":"","TERMSKEY":"","ACCOUNTLABELKEY":"","ACCOUNTKEY":"","CUSTTYPEKEY":"","PRICESCHEDULEKEY":"","OFFSETGLACCOUNTNO":"","OFFSETGLACCOUNTNOTITLE":"","ADVBILLBY":"","ADVBILLBYTYPE":"","SUPDOCID":"","RETAINAGEPERCENTAGE":"","EMAILOPTIN":"false","MEGAENTITYKEY":"","MEGAENTITYID":"","MEGAENTITYNAME":"","LSP_COMPANYID":"","LV_INDUSTRY":"","LV_BILLING_PERIOD":"","BL_BILLING_TYPE":"","BL_BILLING_EMAILTO":"","BL_BILLING_EMAIL_CC":"","BL_MODE_OF_INVOICING":"","BL_PO_REQUIRED":"No","BL_ID":"","HIDEDISPLAYCONTACT":"false"}',
        sageSyncDate: null,
        sageId: 'C-06445',
        sageStatusSyncName: null,
        accountHoldReasonNotes: null,
        isActive: false,
        active: null,
        sageParentId: null
    }
];
export const parentCompanyResponse = [
    {
        companyId: 'C-06445',
        companyName: 'Test Contact Mapping',
        entityId: 'Top Level',
        isParentCompany: false,
        billingPeriod: '',
        industry: '',
        poRequired: 'No',
        modeOfInvoicing: null,
        billingType: '',
        billingEmailTo: '',
        billingEmailCc: '',
        isEntityParent: false,
        id: 0,
        name: null,
        companyTypeName: null,
        companyType: 0,
        parentCompanyName: '',
        companyStatus: 'active',
        customerTierLevel: null,
        primaryPhoneNumber: '',
        salesRepName: '',
        city: 'Coimbatore',
        state: 'KY',
        country: 'United States',
        billingEmail: '',
        updatedAt: '2024-07-31T07:18:31',
        updatedBy: null,
        createdAt: '2024-07-31T07:14:54',
        createdBy: null,
        status: null,
        address1: 'S 78',
        address2: 'DIJ32',
        zip: '',
        billingTerms: '',
        formofPayment: null,
        isAccountHoldStatus: null,
        preferredCurrency: '',
        grossProfit: null,
        isAccountOnHold: null,
        billingNotes: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null,
        sageSyncStatus: null,
        sageSyncDetails:
            '{"RECORDNO":"11114","CUSTOMERID":"C-06445","NAME":"Test Contact Mapping","ENTITY":"CC-06445","PARENTKEY":"","PARENTID":"","PARENTNAME":"","DISPLAYCONTACT.CONTACTNAME":"Test Contact Mapping(CC-06445)","DISPLAYCONTACT.COMPANYNAME":"Test Contact Mapping","DISPLAYCONTACT.PREFIX":"","DISPLAYCONTACT.FIRSTNAME":"Test","DISPLAYCONTACT.LASTNAME":"Mapping","DISPLAYCONTACT.INITIAL":"","DISPLAYCONTACT.PRINTAS":"Test Contact Mapping","DISPLAYCONTACT.TAXABLE":"true","DISPLAYCONTACT.TAXGROUP":"","DISPLAYCONTACT.TAXSOLUTIONKEY":"","DISPLAYCONTACT.TAXSOLUTIONID":"","DISPLAYCONTACT.TAXSCHEDULE":"","DISPLAYCONTACT.TAXID":"","DISPLAYCONTACT.SIRET":"","DISPLAYCONTACT.PHONE1":"","DISPLAYCONTACT.PHONE2":"","DISPLAYCONTACT.CELLPHONE":"","DISPLAYCONTACT.PAGER":"","DISPLAYCONTACT.FAX":"","DISPLAYCONTACT.TAXIDVALIDATIONDATE":"","DISPLAYCONTACT.GSTREGISTERED":"","DISPLAYCONTACT.TAXCOMPANYNAME":"","DISPLAYCONTACT.TAXADDRESS":"","DISPLAYCONTACT.EMAIL1":"","DISPLAYCONTACT.EMAIL2":"","DISPLAYCONTACT.URL1":"","DISPLAYCONTACT.URL2":"","DISPLAYCONTACT.VISIBLE":"true","DISPLAYCONTACT.MAILADDRESS.ADDRESS1":"S 78","DISPLAYCONTACT.MAILADDRESS.ADDRESS2":"DIJ32","DISPLAYCONTACT.MAILADDRESS.ADDRESS3":"","DISPLAYCONTACT.MAILADDRESS.CITY":"Coimbatore","DISPLAYCONTACT.MAILADDRESS.STATE":"KY","DISPLAYCONTACT.MAILADDRESS.ZIP":"","DISPLAYCONTACT.MAILADDRESS.COUNTRY":"United States","DISPLAYCONTACT.MAILADDRESS.COUNTRYCODE":"US","DISPLAYCONTACT.MAILADDRESS.LATITUDE":"","DISPLAYCONTACT.MAILADDRESS.LONGITUDE":"","DISPLAYCONTACT.STATUS":"active","TERMNAME":"","TERMVALUE":"","CUSTREPID":"","CUSTREPNAME":"","RESALENO":"","TAXID":"","CREDITLIMIT":"","TOTALDUE":"0","COMMENTS":"","ACCOUNTLABEL":"","ARACCOUNT":"","ARACCOUNTTITLE":"","LAST_INVOICEDATE":"","LAST_STATEMENTDATE":"","DELIVERY_OPTIONS":"Print","TERRITORYID":"","TERRITORYNAME":"","SHIPPINGMETHOD":"","CUSTTYPE":"","GLGRPKEY":"","GLGROUP":"","PRICESCHEDULE":"","DISCOUNT":"","PRICELIST":"","VSOEPRICELIST":"","CURRENCY":"","CONTACTINFO.CONTACTNAME":"","CONTACTINFO.PREFIX":"","CONTACTINFO.FIRSTNAME":"","CONTACTINFO.INITIAL":"","CONTACTINFO.LASTNAME":"","CONTACTINFO.COMPANYNAME":"","CONTACTINFO.PRINTAS":"","CONTACTINFO.PHONE1":"","CONTACTINFO.PHONE2":"","CONTACTINFO.CELLPHONE":"","CONTACTINFO.PAGER":"","CONTACTINFO.FAX":"","CONTACTINFO.EMAIL1":"","CONTACTINFO.EMAIL2":"","CONTACTINFO.URL1":"","CONTACTINFO.URL2":"","CONTACTINFO.VISIBLE":"","CONTACTINFO.MAILADDRESS.ADDRESS1":"","CONTACTINFO.MAILADDRESS.ADDRESS2":"","CONTACTINFO.MAILADDRESS.ADDRESS3":"","CONTACTINFO.MAILADDRESS.CITY":"","CONTACTINFO.MAILADDRESS.STATE":"","CONTACTINFO.MAILADDRESS.ZIP":"","CONTACTINFO.MAILADDRESS.COUNTRY":"","CONTACTINFO.MAILADDRESS.COUNTRYCODE":"","SHIPTO.CONTACTNAME":"","SHIPTO.PREFIX":"","SHIPTO.FIRSTNAME":"","SHIPTO.INITIAL":"","SHIPTO.LASTNAME":"","SHIPTO.COMPANYNAME":"","SHIPTO.PRINTAS":"","SHIPTO.TAXABLE":"","SHIPTO.TAXGROUP":"","SHIPTO.TAXSOLUTIONKEY":"","SHIPTO.TAXSOLUTIONID":"","SHIPTO.TAXSCHEDULE":"","SHIPTO.TAXID":"","SHIPTO.PHONE1":"","SHIPTO.PHONE2":"","SHIPTO.CELLPHONE":"","SHIPTO.PAGER":"","SHIPTO.FAX":"","SHIPTO.EMAIL1":"","SHIPTO.EMAIL2":"","SHIPTO.URL1":"","SHIPTO.URL2":"","SHIPTO.VISIBLE":"","SHIPTO.MAILADDRESS.ADDRESS1":"","SHIPTO.MAILADDRESS.ADDRESS2":"","SHIPTO.MAILADDRESS.ADDRESS3":"","SHIPTO.MAILADDRESS.CITY":"","SHIPTO.MAILADDRESS.STATE":"","SHIPTO.MAILADDRESS.ZIP":"","SHIPTO.MAILADDRESS.COUNTRY":"","SHIPTO.MAILADDRESS.COUNTRYCODE":"","BILLTO.CONTACTNAME":"","BILLTO.PREFIX":"","BILLTO.FIRSTNAME":"","BILLTO.INITIAL":"","BILLTO.LASTNAME":"","BILLTO.COMPANYNAME":"","BILLTO.PRINTAS":"","BILLTO.TAXABLE":"","BILLTO.TAXGROUP":"","BILLTO.TAXSOLUTIONKEY":"","BILLTO.TAXSOLUTIONID":"","BILLTO.TAXSCHEDULE":"","BILLTO.PHONE1":"","BILLTO.PHONE2":"","BILLTO.CELLPHONE":"","BILLTO.PAGER":"","BILLTO.FAX":"","BILLTO.EMAIL1":"","BILLTO.EMAIL2":"","BILLTO.URL1":"","BILLTO.URL2":"","BILLTO.VISIBLE":"","BILLTO.MAILADDRESS.ADDRESS1":"","BILLTO.MAILADDRESS.ADDRESS2":"","BILLTO.MAILADDRESS.ADDRESS3":"","BILLTO.MAILADDRESS.CITY":"","BILLTO.MAILADDRESS.STATE":"","BILLTO.MAILADDRESS.ZIP":"","BILLTO.MAILADDRESS.COUNTRY":"","BILLTO.MAILADDRESS.COUNTRYCODE":"","STATUS":"active","ONETIME":"false","CUSTMESSAGEID":"","ONHOLD":"false","PRCLST_OVERRIDE":"C","OEPRCLSTKEY":"","OEPRICESCHEDKEY":"","ENABLEONLINECARDPAYMENT":"true","ENABLEONLINEACHPAYMENT":"true","VSOEPRCLSTKEY":"","WHENMODIFIED":"07/31/2024 07:18:31","ARINVOICEPRINTTEMPLATEID":"","OEQUOTEPRINTTEMPLATEID":"","OEORDERPRINTTEMPLATEID":"","OELISTPRINTTEMPLATEID":"","OEINVOICEPRINTTEMPLATEID":"","OEADJPRINTTEMPLATEID":"","OEOTHERPRINTTEMPLATEID":"","WHENCREATED":"07/31/2024 07:14:54","CREATEDBY":"62","MODIFIEDBY":"62","DISPLAYCONTACTKEY":"147610","CONTACTKEY":"","SHIPTOKEY":"","BILLTOKEY":"","CUSTREPKEY":"","SHIPVIAKEY":"","TERRITORYKEY":"","TERMSKEY":"","ACCOUNTLABELKEY":"","ACCOUNTKEY":"","CUSTTYPEKEY":"","PRICESCHEDULEKEY":"","OFFSETGLACCOUNTNO":"","OFFSETGLACCOUNTNOTITLE":"","ADVBILLBY":"","ADVBILLBYTYPE":"","SUPDOCID":"","RETAINAGEPERCENTAGE":"","EMAILOPTIN":"false","MEGAENTITYKEY":"","MEGAENTITYID":"","MEGAENTITYNAME":"","LSP_COMPANYID":"","LV_INDUSTRY":"","LV_BILLING_PERIOD":"","BL_BILLING_TYPE":"","BL_BILLING_EMAILTO":"","BL_BILLING_EMAIL_CC":"","BL_MODE_OF_INVOICING":"","BL_PO_REQUIRED":"No","BL_ID":"","HIDEDISPLAYCONTACT":"false"}',
        sageSyncDate: null,
        sageId: 'C-06445',
        sageStatusSyncName: null,
        accountHoldReasonNotes: null,
        isActive: false,
        active: null,
        sageParentId: null
    }
];
export const paymentTypeResponse = [
    {
        name: 'Paypal',
        id: 2,
        createdBy: null,
        createdAt: null,
        updatedBy: null,
        updatedAt: null,
        active: null,
        deletedBy: null,
        deletedAt: null,
        restoredBy: null,
        restoredAt: null
    }
];
