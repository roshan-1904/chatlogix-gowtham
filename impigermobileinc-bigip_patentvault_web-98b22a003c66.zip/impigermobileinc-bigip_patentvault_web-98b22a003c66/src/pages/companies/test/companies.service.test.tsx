import HttpService from '../../../core/interceptor/api.handler';
import companiesService from '../service/companies.service';
import { RatesListingResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { END_POINT } from 'constants/endPoint';
import { PV_SETTINGS_RATES } from 'pages/pvsettings/subaccordions/rates/rates.const';
import {
    companyListRequest,
    companyListResponse,
    CompanyRatesRequest,
    companyUpdateDataResponse,
    CreateCompanyRequest,
    createCompanyResponse,
    getIPresponse,
    parentCompanyResponse,
    paymentTypeResponse,
    preferredCurrencyResponse,
    requestCurrencyResponse,
    sageCompanyResponse,
    sourceLanguagesResponse,
    updateCompanyRequest
} from './mocks/companies.service.test.mock';

jest.mock('../../../core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getTableData', () => {
        it('should fetch table data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue(companyListResponse);

            const result = await companiesService.getTableData(companyListRequest);

            expect(result).toEqual(companyListResponse);
            expect(HttpService.prototype.post).toHaveBeenCalledWith(
                expect.any(String), // Endpoint URL
                companyListRequest
            );
        });

        it('should handle error while fetching table data', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValue(mockError);
            await expect(companiesService.getTableData(companyListRequest)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('updateChangeStatus', () => {
        const updateChangeStatusResponse = true;
        const companyId = 1;
        it('should update company status successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue(
                updateChangeStatusResponse
            );
            const isActive = true;

            const result = await companiesService.updateChangeStatus<boolean>(companyId, isActive);

            expect(result).toEqual(updateChangeStatusResponse);
            expect(HttpService.prototype.patch).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.PATCH_ACTIVATE_STATUS}/${companyId}/${isActive}`,
                null,
                {
                    headers: { Accept: 'text/plain' }
                }
            );
        });

        it('should update company status to inactive and show success message', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue(
                updateChangeStatusResponse
            );
            const isActive = false;

            const result = await companiesService.updateChangeStatus(companyId, isActive);

            expect(result).toEqual(updateChangeStatusResponse);
            expect(HttpService.prototype.patch).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.PATCH_ACTIVATE_STATUS}/${companyId}/${isActive}`,
                null,
                {
                    headers: { Accept: 'text/plain' }
                }
            );
        });

        it('should handle error while updating company status', async () => {
            const updateChangeStatusError = new Error('Mock error');
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValue(updateChangeStatusError);
            const isActive = true;

            await expect(
                companiesService.updateChangeStatus<boolean>(companyId, isActive)
            ).rejects.toThrow(updateChangeStatusError);
        });
    });

    describe('createCompany', () => {
        it('should create a company successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue(createCompanyResponse);

            const result = await companiesService.createCompany(CreateCompanyRequest);

            expect(result).toEqual(createCompanyResponse);
            expect(HttpService.prototype.post).toHaveBeenCalledWith(
                expect.any(String),
                CreateCompanyRequest,
                { data: { hideLoader: false } }
            );
        });

        it('should handle error while creating a company', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValue(mockError);

            await expect(companiesService.createCompany(CreateCompanyRequest)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('updateCompany', () => {
        it('should update a company successfully', async () => {
            jest.spyOn(HttpService.prototype, 'update').mockResolvedValueOnce(
                companyUpdateDataResponse
            );
            const companyId = 540;

            const result = await companiesService.updateCompany(companyId, updateCompanyRequest);
            expect(result).toEqual(companyUpdateDataResponse);
            expect(HttpService.prototype.update).toHaveBeenCalledWith(
                expect.any(String),
                updateCompanyRequest,
                { data: { hideLoader: false } }
            );
        });

        it('should handle error while updating a company', async () => {
            const mError = new Error('Failed to update company');
            const companyId = 540;

            // Mock the update method to reject with an error
            jest.spyOn(HttpService.prototype, 'update').mockRejectedValueOnce(mError);

            await expect(
                companiesService.updateCompany(companyId, updateCompanyRequest)
            ).rejects.toThrow(mError);
        });
    });

    describe('getCompanyById', () => {
        it('should fetch company data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(createCompanyResponse);
            const companyId = 540;
            const result = await companiesService.getCompanyById(companyId);
            expect(result).toEqual(createCompanyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching company data', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            const companyId = 540;

            await expect(companiesService.getCompanyById(companyId)).rejects.toThrow(mockError);
        });
    });

    describe('getSourceLanguages', () => {
        it('should fetch source languages successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(sourceLanguagesResponse);
            const result = await companiesService.getSourceLanguages();
            expect(result).toEqual(sourceLanguagesResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching source languages', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);

            await expect(companiesService.getSourceLanguages()).rejects.toThrow(mockError);
        });
    });

    describe('getRequestCurrencyData', () => {
        it('should fetch request currency data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(requestCurrencyResponse);
            const result = await companiesService.getRequestCurrencyData();
            expect(result).toEqual(requestCurrencyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);

            await expect(companiesService.getRequestCurrencyData()).rejects.toThrow(mockError);
        });
    });

    describe('getIPRequestData', () => {
        it('should fetch IP request data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue(getIPresponse);

            const result: RatesListingResponseType =
                await companiesService.getIPRequestData(CompanyRatesRequest);
            expect(result).toEqual(getIPresponse);
            expect(HttpService.prototype.post).toHaveBeenCalledWith(
                expect.any(String),
                CompanyRatesRequest
            );
        });

        it('should handle error while fetching IP request data', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValue(mockError);

            await expect(companiesService.getIPRequestData(CompanyRatesRequest)).rejects.toThrow(
                mockError
            );
        });
    });

    // describe('updateFee', () => {
    //     const updateFeeRequest = {
    //         id: 1,
    //         companyTranslationRate: 0,
    //         companyTranslationFeeModel: {
    //             feeType: 'string',
    //             unitTypeId: 0,
    //             formula: 'string',
    //             fee: 0
    //         },
    //         companyOfficialFeeModel: {
    //             feeType: 'string',
    //             unitTypeId: 0,
    //             formula: 'string',
    //             fee: 0
    //         },
    //         companyAgencyFeeModel: {
    //             feeType: 'string',
    //             unitTypeId: 0,
    //             formula: 'string',
    //             fee: 0
    //         }
    //     };
    //     it('should update fee successfully', async () => {
    //         // HttpService.prototype.patch.mockResolvedValue(mockResponse);
    //         jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue(mockResponse);

    //         const result = await companiesService.updateFee(updateFeeRequest);
    //         expect(result).toEqual(mockResponse);
    //         expect(HttpService.prototype.patch).toHaveBeenCalledWith(
    //             expect.any(String),
    //             requestBody
    //         );
    //     });

    //     it('should handle error while updating fee', async () => {
    //         HttpService.prototype.patch.mockRejectedValue(mockError);

    //         await expect(companiesService.updateFee(updateFeeRequest)).rejects.toThrow(mockError);
    //     });
    // });

    describe('getPreferredCurrency', () => {
        it('should fetch preferred currency successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(preferredCurrencyResponse);
            const companyId = 1;
            const activeTab = 0;
            const result = await companiesService.getPreferredCurrency(companyId, activeTab);
            expect(result).toEqual(preferredCurrencyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching preferred currency', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            const companyId = 1;
            const activeTab = 0;

            await expect(
                companiesService.getPreferredCurrency(companyId, activeTab)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getSageCompanyList', () => {
        it('should fetch sage company list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(sageCompanyResponse);
            const queryParams = { filterQuery: 'test' };
            const result = await companiesService.getSageCompanyList(queryParams);
            expect(result).toEqual(sageCompanyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching sage company list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            const queryParams = { filterQuery: 'test' };

            await expect(companiesService.getSageCompanyList(queryParams)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getParentCompanyList', () => {
        it('should fetch parent company list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(parentCompanyResponse);
            const result = await companiesService.getParentCompanyList();
            expect(result).toEqual(parentCompanyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching parent company list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);

            await expect(companiesService.getParentCompanyList()).rejects.toThrow(mockError);
        });
    });

    describe('getPaymentTypeList', () => {
        it('should fetch payment type list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(paymentTypeResponse);
            const result = await companiesService.getPaymentTypeList();
            expect(result).toEqual(paymentTypeResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(expect.any(String));
        });

        it('should handle error while fetching payment type list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);

            await expect(companiesService.getPaymentTypeList()).rejects.toThrow(mockError);
        });
    });

    describe('getSalesRepList', () => {
        const mockSalesRepListResponse = [
            { id: 1, name: 'John Doe' },
            { id: 2, name: 'Jane Smith' }
        ];

        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should fetch sales rep list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(mockSalesRepListResponse);

            const result =
                await companiesService.getSalesRepList<typeof mockSalesRepListResponse>();

            expect(result).toEqual(mockSalesRepListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_SALES_REP_LIST}`
            );
        });

        it('should handle error while fetching sales rep list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);

            await expect(companiesService.getSalesRepList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_SALES_REP_LIST}`
            );
        });
    });

    describe('getBillingTermsList', () => {
        const mockBillingTermsListResponse = [
            { id: 1, name: 'Net 30' },
            { id: 2, name: 'Net 60' }
        ];

        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should fetch billing terms list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(
                mockBillingTermsListResponse
            );

            const result =
                await companiesService.getBillingTermsList<typeof mockBillingTermsListResponse>();

            expect(result).toEqual(mockBillingTermsListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_TERMS_LIST}`
            );
        });

        it('should handle error while fetching billing terms list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);

            await expect(companiesService.getBillingTermsList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_TERMS_LIST}`
            );
        });
    });

    describe('getIndustryList', () => {
        const mockIndustryListResponse = [
            { id: 1, name: 'Technology' },
            { id: 2, name: 'Finance' }
        ];

        it('should fetch industry list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(mockIndustryListResponse);
            const result =
                await companiesService.getIndustryList<typeof mockIndustryListResponse>();
            expect(result).toEqual(mockIndustryListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_INDUSTRIES_LIST}`
            );
        });

        it('should handle error while fetching industry list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.getIndustryList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_INDUSTRIES_LIST}`
            );
        });
    });

    describe('getPreferredCurrencyList', () => {
        const mockPreferredCurrencyListResponse = [
            { id: 1, name: 'USD' },
            { id: 2, name: 'EUR' }
        ];

        it('should fetch preferred currency list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(
                mockPreferredCurrencyListResponse
            );
            const result =
                await companiesService.getPreferredCurrencyList<
                    typeof mockPreferredCurrencyListResponse
                >();
            expect(result).toEqual(mockPreferredCurrencyListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY_LIST}`
            );
        });

        it('should handle error while fetching preferred currency list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.getPreferredCurrencyList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY_LIST}`
            );
        });
    });

    describe('getBillingPeriodList', () => {
        const mockBillingPeriodListResponse = [
            { id: 1, name: 'Monthly' },
            { id: 2, name: 'Quarterly' }
        ];

        it('should fetch billing period list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(
                mockBillingPeriodListResponse
            );
            const result =
                await companiesService.getBillingPeriodList<typeof mockBillingPeriodListResponse>();
            expect(result).toEqual(mockBillingPeriodListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_PERIOD_LIST}`
            );
        });

        it('should handle error while fetching billing period list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.getBillingPeriodList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_BILLING_PERIOD_LIST}`
            );
        });
    });

    describe('getCountryList', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockCountryListResponse = [
            { id: 1, name: 'USA' },
            { id: 2, name: 'Canada' }
        ];

        it('should fetch country list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(mockCountryListResponse);
            const result = await companiesService.getCountryList<typeof mockCountryListResponse>();
            expect(result).toEqual(mockCountryListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_COUNTRIES_LIST}`
            );
        });

        it('should handle error while fetching country list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.getCountryList()).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_COUNTRIES_LIST}`
            );
        });
    });

    describe('getStatesList', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockStatesListResponse = [
            { id: 1, name: 'California' },
            { id: 2, name: 'Texas' }
        ];

        it('should fetch states list successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(mockStatesListResponse);
            const result = await companiesService.getStatesList<typeof mockStatesListResponse>(1);
            expect(result).toEqual(mockStatesListResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_STATES_LIST}/1`
            );
        });

        it('should handle error while fetching states list', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.getStatesList(1)).rejects.toThrow(mockError);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.USERS.BASE}/${END_POINT.COMPANIES.GET_STATES_LIST}/1`
            );
        });
    });

    describe('getCountryById', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockCountryResponse = [
            {
                id: 138,
                name: 'Afghanistan',
                code: 'AF',
                iconName: '122-afghanistan.svg',
                countryNameCode: 'Afghanistan (AF)',
                latitude: '33.93911',
                longitude: '67.709953'
            }
        ];

        it('should fetch country by id successfully', async () => {
            jest.spyOn(companiesService, 'getCountryList').mockResolvedValue(mockCountryResponse);
            const result = await companiesService.getCountryById(138);
            expect(result).toEqual(mockCountryResponse[0]); // Check for equality
            expect(companiesService.getCountryList).toHaveBeenCalled();
        });

        it('should return null if country not found', async () => {
            jest.spyOn(companiesService, 'getCountryList').mockResolvedValue(mockCountryResponse);
            const result = await companiesService.getCountryById(3); // ID 3 doesn't exist
            expect(result).toBeNull(); // Check for null
            expect(companiesService.getCountryList).toHaveBeenCalled();
        });
        it('should return null if country list is empty', async () => {
            jest.spyOn(companiesService, 'getCountryList').mockResolvedValue([]); // Mock empty response
            const result = await companiesService.getCountryById(138); // Any ID
            expect(result).toBeNull();
            expect(companiesService.getCountryList).toHaveBeenCalled();
        });
        it('should handle error while fetching country by id', async () => {
            jest.spyOn(companiesService, 'getCountryList').mockRejectedValue(mockError);
            const result = await companiesService.getCountryById(1);
            expect(result).toBeNull(); // Expect null on error
            expect(companiesService.getCountryList).toHaveBeenCalled();
        });
    });

    describe('getStateById', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockStateResponse = [
            { id: 347, name: 'Badakhshan', code: 'AF-BDS' },
            { id: 90, name: 'Badghis', code: 'AF-BDG' }
        ];

        it('should fetch state by id successfully', async () => {
            jest.spyOn(companiesService, 'getStatesList').mockResolvedValue(mockStateResponse);
            const result = await companiesService.getStateById(1, 347);
            expect(result).toEqual(mockStateResponse[0]);
            expect(companiesService.getStatesList).toHaveBeenCalledWith(1);
        });

        it('should return null if state not found', async () => {
            jest.spyOn(companiesService, 'getStatesList').mockResolvedValue(mockStateResponse);
            const result = await companiesService.getStateById(1, 3);
            expect(result).toBeNull();
            expect(companiesService.getStatesList).toHaveBeenCalledWith(1);
        });
        it('should return null if state list is empty', async () => {
            jest.spyOn(companiesService, 'getStatesList').mockResolvedValue([]); // Mock empty response
            const result = await companiesService.getStateById(1, 8); // Any ID
            expect(result).toBeNull();
            expect(companiesService.getStatesList).toHaveBeenCalled();
        });
        it('should handle error while fetching state by id', async () => {
            jest.spyOn(companiesService, 'getStatesList').mockRejectedValue(mockError);
            const result = await companiesService.getStateById(1, 1);
            expect(result).toBeNull();
            expect(companiesService.getStatesList).toHaveBeenCalledWith(1);
        });
    });

    describe('getCountryAndState', () => {
        it('should fetch country and state successfully', async () => {
            const mockCountryResponse = {
                id: 138,
                name: 'Afghanistan',
                code: 'AF',
                iconName: '122-afghanistan.svg',
                countryNameCode: 'Afghanistan (AF)',
                latitude: '33.93911',
                longitude: '67.709953'
            };

            const mockStateResponse = [
                { id: 347, name: 'Badakhshan', code: 'AF-BDS' },
                { id: 90, name: 'Badghis', code: 'AF-BDG' }
            ];

            jest.spyOn(companiesService, 'getCountryById').mockResolvedValue(mockCountryResponse);
            jest.spyOn(companiesService, 'getStateById').mockResolvedValue(mockStateResponse[0]); // Assuming you want to get the first state

            const result = await companiesService.getCountryAndState(138, 347); // Mock countryId and stateId

            expect(result).toEqual({ country: mockCountryResponse, state: mockStateResponse[0] });
            expect(companiesService.getCountryById).toHaveBeenCalledWith(138);
            expect(companiesService.getStateById).toHaveBeenCalledWith(138, 347);
        });

        it('should return null for country and state when not found', async () => {
            jest.spyOn(companiesService, 'getCountryById').mockResolvedValue(null);
            jest.spyOn(companiesService, 'getStateById').mockResolvedValue(null);

            const result = await companiesService.getCountryAndState(0, 0); // Assuming 0 is not a valid ID

            expect(result).toEqual({ country: null, state: null });
        });

        it('should handle errors in fetching country and state', async () => {
            jest.spyOn(companiesService, 'getCountryById').mockRejectedValue(mockError);
            jest.spyOn(companiesService, 'getStateById').mockResolvedValue(null);

            const result = await companiesService.getCountryAndState(138, 347);

            expect(result).toEqual({ country: null, state: null });
        });
    });
    describe('checkExistingCompany', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockExistingCompanyResponse = { id: 1, name: 'Test Company' };
        it('should fetch existing company successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(mockExistingCompanyResponse);
            const result = await companiesService.checkExistingCompany('Test Company');
            expect(result).toEqual(mockExistingCompanyResponse);
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.CHECK_EXISTING_COMPANY}/Test Company`
            );
        });

        it('should return null if company is not found', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(null);
            const result = await companiesService.checkExistingCompany('Nonexistent Company');
            expect(result).toBeNull();
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.CHECK_EXISTING_COMPANY}/Nonexistent Company`
            );
        });

        it('should handle error while fetching existing company', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValue(mockError);
            await expect(companiesService.checkExistingCompany('Error Company')).rejects.toThrow(
                mockError
            );
            expect(HttpService.prototype.get).toHaveBeenCalledWith(
                `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.CHECK_EXISTING_COMPANY}/Error Company`
            );
        });
    });

    describe('updateCurrencyDetails', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });
        const mockUpdateCurrencyResponse = { success: true };
        it('should update currency details successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue(mockUpdateCurrencyResponse);
            const result = await companiesService.updateCurrencyDetails(1, 2, 3);
            const expectedApiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY}/1/${PV_SETTINGS_RATES['ep']}/3`;
            expect(result).toEqual(mockUpdateCurrencyResponse);
            expect(HttpService.prototype.post).toHaveBeenCalledWith(expectedApiUrl, 0);
        });

        it('should handle error while updating currency details', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValue(mockError);
            await expect(companiesService.updateCurrencyDetails(1, 2, 3)).rejects.toThrow(
                mockError
            );
            const expectedApiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_PREFERRED_CURRENCY}/1/${PV_SETTINGS_RATES['ep']}/3`;
            expect(HttpService.prototype.post).toHaveBeenCalledWith(expectedApiUrl, 0);
        });
    });
});
