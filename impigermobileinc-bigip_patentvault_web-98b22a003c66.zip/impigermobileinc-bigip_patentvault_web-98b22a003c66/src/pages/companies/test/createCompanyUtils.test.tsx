import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import {
    buildCompanyData,
    generateFormData,
    getHeaderTitleAndStepButtons,
    redirectToNextPage
} from '../utils/createCompanyUtils';
import {
    expectedPartialResult,
    expectedUpdatedResult,
    mockCompanyData,
    mockCountry,
    mockPartialFormData,
    mockState,
    mockUpdatedFormData,
    partialCompanyData
} from './mocks/createCompanyUtils.test.mock';
import { CreateCompanyPayloadType } from '../types/createCompany.types';
import { STEPPER_STATE } from 'pages/components/progressStepper/types/progressStepper.type';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { TFunction } from 'i18next';
import {
    CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY,
    EDIT_COMPANY_PATHS_FOR_STEPPER_ARRAY,
    VIEW_COMPANY_PATHS_FOR_STEPPER_ARRAY
} from '../constants/companyStepper.constant';
import { stepperMode } from 'pages/users/constant/user.constant';

// Mock the companyStepperStore
jest.mock('core/store/stepperStore/companyStore/company.store', () => ({
    updatePage: jest.fn()
}));
jest.mock('pages/components/progressStepper/services/progressStepper.service');
jest.mock('core/store/stepperStore/progressStepper.store'); //

describe('generateFormData', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should generate form data correctly with all fields', () => {
        generateFormData(mockCompanyData, mockCountry, mockState);

        expect(companyStepperStore.updatePage).toHaveBeenCalledWith('formData', {
            billingInfoPage: {
                accountOnHold: 'no',
                address1: '123 Test St',
                address2: 'Suite 100',
                billingEmail: 'billing@test.com',
                billingNotes: 'Billing notes',
                billingPeriodId: null,
                billingTermsId: null,
                billingTypeId: null,
                cc: 'cc@example.com',
                city: 'Test City',
                country: {
                    code: 'TC',
                    countryNameCode: 'Test Country Code',
                    iconName: 'icon-test',
                    id: 1,
                    latitude: '0.0',
                    longitude: '0.0',
                    name: 'Test Country'
                },
                currencyId: 1,
                grossProfit: 50,
                invoiceDeliveryStatement: '',
                invoiceMode: '',
                isPoRequired: 'no',
                paymentTypeId: null,
                reason: 'No hold',
                state: {
                    code: 'TS',
                    id: 1,
                    name: 'Test State'
                },
                zip: '12345'
            },
            companyProfilePage: {
                companyStatus: 'Active',
                companyType: 1,
                container: {
                    name: 'Test Company'
                },
                customerTierLevel: 'Gold',
                id: 1,
                industryId: null,
                isAgreeTMDiscounts: 'no',
                notes: 'Test notes',
                parentCompanyName: 'Parent Company',
                primaryPhoneNumber: '123-456-7890',
                salesRepId: null,
                serviceAgreement: 'yes',
                serviceAgreementEndDate: null,
                serviceAgreementStartDate: null,
                website: 'https://testcompany.com'
            },
            contact: null,
            rates: null // Ensure this matches the output of your function
        });
    });

    it('should handle optional fields correctly', () => {
        generateFormData(partialCompanyData, null, null);

        expect(companyStepperStore.updatePage).toHaveBeenCalledWith('formData', {
            companyProfilePage: {
                id: 2,
                container: {
                    name: 'Another Company'
                },
                companyType: 2,
                parentCompanyName: null,
                companyStatus: 'Inactive',
                customerTierLevel: undefined,
                serviceAgreement: 'no',
                primaryPhoneNumber: undefined,
                salesRepId: null,
                notes: undefined,
                industryId: null,
                isAgreeTMDiscounts: 'no',
                serviceAgreementStartDate: null,
                serviceAgreementEndDate: null,
                website: undefined
            },
            billingInfoPage: {
                billingTermsId: null,
                paymentTypeId: null,
                currencyId: 2,
                grossProfit: undefined,
                accountOnHold: 'yes',
                reason: undefined,
                billingNotes: undefined,
                address1: '456 Another St',
                address2: '',
                country: null,
                state: null,
                city: 'Another City',
                zip: '54321',
                billingEmail: 'billing@another.com',
                isPoRequired: 'no',
                billingPeriodId: null,
                billingTypeId: null,
                invoiceMode: '',
                invoiceDeliveryStatement: '',
                cc: ''
            },
            contact: null,
            rates: null
        });
    });

    it('should handle missing optional fields in billingInfoPage correctly', () => {
        const minimalBillingData: CreateCompanyPayloadType = {
            id: undefined,
            name: 'Billing Minimal Company',
            companyType: 4,
            parentCompanyName: '',
            sageParentId: null,
            companyStatus: '',
            customerTierLevel: undefined,
            // parentCompanyName: undefined,
            serviceAgreement: undefined,
            website: undefined,
            primaryPhoneNumber: undefined,
            salesRepId: null,
            companyNotes: undefined,
            billingTermsId: null,
            paymentTypeId: null,
            currencyId: null,
            mailingAddress: {
                address1: '789 Minimal St',
                address2: '',
                city: 'Minimal City',
                state: '',
                zip: '67890',
                country: '',
                stateId: 0,
                countryId: 0,
                billingEmail: ''
            },
            contactDetails: [],
            documentId: null,
            billingPeriodId: null,
            billingTypeId: null,
            isPoRequired: undefined,
            invoiceMode: undefined,
            invoiceDeliveryStatement: undefined,
            industryId: null,
            isAgreeTMDiscounts: true,
            ccRecipients: undefined,
            serviceAgreementStartDate: null,
            serviceAgreementEndDate: null
        };

        generateFormData(minimalBillingData, null, null);

        expect(companyStepperStore.updatePage).toHaveBeenCalledWith('formData', {
            companyProfilePage: {
                id: undefined,
                container: {
                    name: 'Billing Minimal Company'
                },
                companyType: 4,
                companyStatus: '',
                parentCompanyName: null,
                customerTierLevel: undefined,
                serviceAgreement: 'no',
                primaryPhoneNumber: undefined,
                salesRepId: null,
                notes: undefined,
                industryId: null,
                isAgreeTMDiscounts: 'yes',
                serviceAgreementStartDate: null,
                serviceAgreementEndDate: null,
                website: undefined
            },
            billingInfoPage: {
                accountOnHold: 'no',
                address1: '789 Minimal St',
                address2: '',
                billingEmail: '',
                billingNotes: undefined,
                billingPeriodId: null,
                billingTermsId: null,
                billingTypeId: null,
                cc: '',
                city: 'Minimal City',
                country: null,
                currencyId: null,
                grossProfit: undefined,
                invoiceDeliveryStatement: '',
                invoiceMode: '',
                isPoRequired: 'no',
                paymentTypeId: null,
                reason: undefined,
                state: null,
                zip: '67890'
            },
            contact: null,
            rates: null
        });
    });
});
describe('buildCompanyData', () => {
    it('should build company data correctly with all fields populated', () => {
        const result = buildCompanyData(mockUpdatedFormData);
        expect(result).toEqual(expectedUpdatedResult);
    });

    it('should handle undefined optional fields correctly', () => {
        const result = buildCompanyData(mockPartialFormData);
        expect(result).toEqual(expectedPartialResult);
    });
});

describe('redirectToNextPage', () => {
    const mockStepperState: STEPPER_STATE = {
        stepperInfo: {
            currStep: null,
            completedStepsIds: []
        },
        // It will be update based on users selecting the service category */
        stepperList: null
    };

    beforeEach(() => {
        jest.clearAllMocks(); // Clear any previous mocks before each test
    });

    it('should update the stepper store for the next page', () => {
        const mockUpdatedInfo = { stepperInfo: 'mockInfo' };

        // Mock the implementation of the updateStepperStoreForNextPage method
        (progressStepperServices.updateStepperStoreForNextPage as jest.Mock).mockReturnValue(
            mockUpdatedInfo
        );

        // Call the function
        redirectToNextPage(mockStepperState);

        // Assert that the updateStepperStoreForNextPage was called with the correct argument
        expect(progressStepperServices.updateStepperStoreForNextPage).toHaveBeenCalledWith(
            mockStepperState
        );

        // Assert that the stepper store was updated with the correct data
        expect(stepperStore.updateStepper).toHaveBeenCalledWith({ stepperInfo: mockUpdatedInfo });
    });

    it('should handle errors and log them', () => {
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(); // Spy on console.error

        // Mock the implementation to throw an error
        (progressStepperServices.updateStepperStoreForNextPage as jest.Mock).mockImplementation(
            () => {
                throw new Error('Test error');
            }
        );

        // Call the function
        redirectToNextPage(mockStepperState);

        // Assert that console.error was called with the expected error message
        expect(consoleErrorSpy).toHaveBeenCalledWith(
            'Error while redirecting to the next page:',
            expect.any(Error)
        );

        consoleErrorSpy.mockRestore(); // Restore the original console.error
    });
});

// Create a mock function for TFunction
// Define a type for mockTFunction that meets the TFunction requirements
const mockTFunction: TFunction<'translation', undefined> = ((key: string) => key) as TFunction<
    'translation',
    undefined
> & { $TFunctionBrand: 'translation' };

describe('getHeaderTitleAndStepButtons', () => {
    beforeEach(() => {
        jest.clearAllMocks(); // Clear mock call history before each test
    });

    it('should return edit mode values when isFromEdit is true', () => {
        const result = getHeaderTitleAndStepButtons(mockTFunction, true, false);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.EDIT_COMPANY',
            stepButtonArray: EDIT_COMPANY_PATHS_FOR_STEPPER_ARRAY, // Ensure this is defined or mocked properly
            mode: stepperMode.EDIT
        });
    });

    it('should return view mode values when isFromView is true', () => {
        const result = getHeaderTitleAndStepButtons(mockTFunction, false, true);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.VIEW_COMPANY',
            stepButtonArray: VIEW_COMPANY_PATHS_FOR_STEPPER_ARRAY, // Ensure this is defined or mocked properly
            mode: stepperMode.VIEW
        });
    });

    it('should return create mode values when neither isFromEdit nor isFromView is true', () => {
        const result = getHeaderTitleAndStepButtons(mockTFunction, false, false);

        expect(result).toEqual({
            headerTitle: 'COMPANIES.CREATE_COMPANY',
            stepButtonArray: CREATE_COMPANY_PATHS_FOR_STEPPER_ARRAY, // Ensure this is defined or mocked properly
            mode: stepperMode.CREATE
        });
    });
});
