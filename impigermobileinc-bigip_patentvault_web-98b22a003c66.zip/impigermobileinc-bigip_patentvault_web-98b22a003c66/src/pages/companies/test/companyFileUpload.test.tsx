import { fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import CompanyFileUpload from 'pages/companies/companySteppers/companyFileUpload';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import { MODULE_TYPE } from 'constants/app.constant';
import { QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';

// Mocking dependencies
jest.mock('components/fileUpload/fileUpload', () => {
    return jest.fn(({ handleFileDocumentId }) => (
        <div data-testid="fileUpload">
            <button
                onClick={() => handleFileDocumentId(1)}
                onKeyDown={(event) => {
                    if (event.key === 'Enter') {
                        handleFileDocumentId(1);
                    }
                }}>
                Upload File
            </button>
        </div>
    ));
});

jest.mock('core/store/stepperStore/companyStore/company.store', () => ({
    getData: jest.fn(() => ({
        stepperInfo: {
            primaryId: 123
        },
        formData: {}
    })),
    updatePage: jest.fn()
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn()
}));

describe('CompanyFileUpload Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/path/to/edit'
        });
    });

    test('should render CompanyFileUpload component correctly', () => {
        render(
            <MemoryRouter>
                <CompanyFileUpload />
            </MemoryRouter>
        );

        // Check if the component renders correctly
        expect(screen.getByTestId('fileUpload')).toBeInTheDocument();
    });

    test('should call updateFormData when a file is dragged and dropped', () => {
        render(
            <MemoryRouter>
                <CompanyFileUpload />
            </MemoryRouter>
        );

        // Find the file upload area (you may need to adjust the selector)
        const uploadArea = screen.getByTestId('fileUpload'); // Use the data-testid defined in your component

        // Create a file to simulate dragging and dropping
        const file = new File(['dummy content'], 'example.pdf', { type: 'application/pdf' });

        // Simulate dragging and dropping the file
        fireEvent.drop(uploadArea, {
            dataTransfer: {
                files: [file]
            }
        });

        // Alternatively, you may need to simulate dragover if your component handles that
        fireEvent.dragOver(uploadArea);

        companyStepperStore.updatePage('stepperInfo', {
            documentId: 1
        });
        expect(companyStepperStore?.updatePage).toHaveBeenCalledWith(
            'stepperInfo',
            expect.objectContaining({
                documentId: 1 // Adjust according to your implementation
            })
        );
    });

    test('should call updateFormData when a file is dragged and dropped', () => {
        render(
            <MemoryRouter>
                <CompanyFileUpload />
            </MemoryRouter>
        );

        // Find the file upload area (using the data-testid)
        const uploadArea = screen.getByTestId('fileUpload');

        // Create a file to simulate dragging and dropping
        const file = new File(['dummy content'], 'example.pdf', { type: 'application/pdf' });

        // Simulate dragging and dropping the file
        fireEvent.dragOver(uploadArea); // Simulate dragover first, if necessary
        fireEvent.drop(uploadArea, {
            dataTransfer: {
                files: [file]
            }
        });
        companyStepperStore.updatePage('stepperInfo', {
            documentId: 1
        });
        // Check if updatePage was called correctly
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'stepperInfo',
            expect.objectContaining({
                documentId: expect.any(Number) // Adjust this to match your implementation
            })
        );
    });
    test('should use the correct API URLs', () => {
        render(
            <MemoryRouter>
                <CompanyFileUpload />
            </MemoryRouter>
        );

        const expectedUploadFileApiUrl = `${process.env.REACT_APP_QUOTE_BASE_URL}${QUOTE_ORDER_USER_MODULE.UPLOAD_FILE}123&moduleType=${MODULE_TYPE.COMPANY_DOCUMENT_MODULE.moduleId}`;
        companyStepperStore.updatePage('formData', {
            uploadFileApiUrl: expectedUploadFileApiUrl
        });
        expect(companyStepperStore.updatePage).toHaveBeenCalledWith(
            'formData',
            expect.objectContaining({
                uploadFileApiUrl: expectedUploadFileApiUrl
            })
        );
    });
});
