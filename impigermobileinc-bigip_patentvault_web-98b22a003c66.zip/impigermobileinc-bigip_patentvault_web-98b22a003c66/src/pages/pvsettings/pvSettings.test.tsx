import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import PVSettings from './pvSettings';
import { useLocation } from 'react-router-dom';

jest.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate hook can use it without a warning being shown
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn()
}));

describe('PVSettings Unit test', () => {
    const mockLocation = {
        pathname: '/patent-vault-settings',
        search: '',
        state: null,
        hash: ''
    };

    test('Checking Wheather PVSettting page is rendered', () => {
        (useLocation as jest.Mock).mockReturnValue(mockLocation);
        render(<PVSettings />);

        const sample: HTMLElement = screen.getByTestId('PV-Settings-Page');

        expect(sample).toBeInTheDocument();
    });

    test('checking wheather accordions are rendered', () => {
        (useLocation as jest.Mock).mockReturnValue(mockLocation);
        render(<PVSettings />);

        const addressAccordion: HTMLElement = screen.getByText('COMMON.ADDRESS_INFORMATION');
        expect(addressAccordion).toBeInTheDocument();

        const currencyAccordion: HTMLElement = screen.getByText('COMMON.CURRENCY_EXCHANGES');
        expect(currencyAccordion).toBeInTheDocument();
    });
});
