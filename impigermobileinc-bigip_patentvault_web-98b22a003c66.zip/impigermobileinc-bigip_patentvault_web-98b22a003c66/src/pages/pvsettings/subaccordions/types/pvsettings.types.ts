import { ColumnDefinition, DataValue } from 'shared/dataTable/types/dataTable.types';
import { PV_SETTINGS_RATES } from '../rates/rates.const';
import { Breakdown } from 'pages/users/types/users.types';
import { Country, State } from 'pages/companies/types/createCompany.types';
export interface CurrencyList {
    currencyId: number;
    currencyName: string;
    currencyIcon: string;
    currencyCode?: string;
}

export interface CurrencyRequestBody {
    id: number;
    from: CurrencyList;
    to: CurrencyList;
    rate: string;
}

export interface CreateCurrency {
    id?: number;
    from?: CurrencyList | null;
    to?: CurrencyList | null;
    rate?: string | undefined;
}

export interface CurrencyRequestBody {
    id: number;
    from: CurrencyList;
    to: CurrencyList;
    rate: string;
}

export interface UpdateRequestBody {
    id: number;
    fromCurrencyId: number;
    fromCurrencyName: string;
    fromCurrencyImage: string;
    toCurrencyId: number;
    toCurrencyName: string;
    toCurrencyImage: string;
    rate: string;
}

export interface CurrencyExchangeData {
    id: number;
    from: CurrencyList;
    to: CurrencyList;
    rate: string;
}

export interface CurrencyExchangeModel {
    id: number;
    fromCurrencyId: number;
    fromCurrencyName: string;
    fromCurrencyImage: string;
    toCurrencyId: number;
    toCurrencyName: string;
    toCurrencyImage: string;
    rate: string;
}

export interface AddressInformationModel {
    id: number;
    address1: string;
    address2: string;
    city: string;
    state: State | null;
    phoneNumber: string;
    webSiteUrl: string;
    countryId: number;
    stateId: number;
    countryName: Country | null;
    zip: string;
}

export interface ErrorCurrencyExchange {
    from: string | null;
    to: string | null;
    rate: string | null;
}

export interface GetCurrencyExchangeApiResponse {
    data: CurrencyExchangeModel[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
export interface AllLanguageResponse {
    data: AllLanguageResponseType[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}

export interface SourceLanguageResponseType {
    label?: string;
    id: number;
    name: string;
    isocode: string;
    abbreviation: string;
}

export interface AllLanguageResponseType {
    label?: string;
    id: number;
    name: string;
    isocode: string;
    abbreviation: string;
}

export interface CurrencyRequestResponseType {
    concatCode: string;
    currencyCode: string;
    currencyIcon: string | null;
    currencyId: number;
    currencyName: string;
}

export interface filterRequestModelType {
    searchModels: [
        {
            propertyName: string;
            value: string;
        }
    ];
    sorting: {
        propertyName: string;
        value: string;
    };
    pageNo: number;
    pageCount: number;
}

export interface IPRatesResponseType {
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    targetLanguageId: number;
    filterRequestModel: filterRequestModelType;
}

export interface dropdownValuesType {
    label: string;
    value: number;
}
export interface languageFilterDropdownValuesType {
    label: string;
    value: string;
}

export interface TabComponents {
    sourceLanguageId: number;
    requestCurrencyId?: number;
}
export interface TableComponent {
    sourceLanguageId: number;
    requestCurrencyId?: number;
    columnSchema: ColumnDefinition[];
    moduleName: PVSettingsRatesKeys;
    company?: boolean;
    listingData: RatesListingResponseType;
    setListingData: any;
    unitOptionsValues: unitOptions[];
    FormulaFields: string[];
    expandedRows?: any;
    readOnly?: boolean;
    targetLanguage?: number;
    serviceType?: string;
    getPreferredCurrency?: any;
    localStorageKey?: string;
    activeIndex: number;
    isEnglishTranslationUpdated?: boolean;
    leftHeaderSection?: React.ReactNode;
}

export interface descriptionTranslationFormula {
    feeType: string | null;
    unitTypeId: number;
    formula: string;
    fee: number;
}

export interface RatesListingResponseType {
    ipRateDetailList: listingData[] | [];
    companyRateDetailList: listingData[] | [];
    companyLevelTranslationRatesList: listingData[] | [];
    companyTranslationRatesList: listingData[] | [];
    pageNo: number;
    totalCount: number;
    currencyData: currencyData;
    totalPages: number;
    indirectTranslationRate?: number;
    aiIndirectTranslationRate?: number;
    indirectTrAiTrDifferencePercent?: number;
    indirectTrAiTrDifference?: number;
    isAiIndirectTranslation?: boolean;
    descriptionTranslationFormulaModel: descriptionTranslationFormula;
    agencyFeeInfo: number;
    companyAgencyFeeInfo?: number;
}

export type CompanyRatesListingResponseType = RatesListingResponseType & {
    companyDescriptionTranslationFormulaModel: descriptionTranslationFormula;
};

export interface paginationType {
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}

export interface defaultDropdownValues {
    sourceLanguage: dropdownValuesType;
    requestCurrency: dropdownValuesType;
}

export interface ratesTableColumnSchema {
    pct: ColumnDefinition[];
    claims: ColumnDefinition[];
    ep: ColumnDefinition[];
    upc: ColumnDefinition[];
    pc: ColumnDefinition[];
}

export interface feeModal {
    fee: string | null;
    feeType: string | null;
    formula: string | null;
    unitTypeId: string | null;
}

export interface listingDetailsList {
    agencyFeeModel: feeModal;
    countryIcon: string;
    countryId: number;
    countryName: string;
    officialFeeModel: feeModal;
    translationFeeModel: feeModal;
    id: number;
    isDirectTranslation: number;
    translationRate: number;
    currencyData: string;
    aiTranslationRate?: number;
    trAiTrDifference?: boolean;
    trAiTrDifferencePercent?: number;
    isAiTranslation?: string;
    currencySymbol: string;
    isAiTranslationFieldsModified?: boolean;
}

export interface currencyData {
    currencyCode: string;
    currencyId: number;
    currencyName: string;
    currencySymbol: string;
}

export interface listingData {
    currencyData: currencyData;
    agencyFeeInfo: string | null;
    descriptionTranslationFormula: string | null;
    ipRateDetailList: listingDetailsList[];
    isAiTranslationFieldsModified?: boolean;
    id: number;
    languageId?: number;
    languageName?: string;
    aiTranslationRate?: number;
    targetLanguage?: string;

    aiCompanyTranslationRate?: number;
}

export interface editFormulaModalInitialValues {
    opened: boolean;
    title: editFormulaTitle;
    rowData: DataValue;
    feeType: string;
    editMode: boolean;
}

export interface editFormulaTitle {
    countryIcon: string | null;
    countryName: string | null;
}

export type PVSettingsRatesKeys = keyof typeof PV_SETTINGS_RATES;

export type FeeModelKeys =
    | 'translationFeeModel'
    | 'officialFeeModel'
    | 'agencyFeeModel'
    | 'companyTranslationFeeModel'
    | 'companyOfficialFeeModel'
    | 'companyAgencyFeeModel';

export interface FeeResponseType {
    id: number;
    translationFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
    officialFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
    agencyFeeModel: {
        feeType: string;
        unitTypeId: number;
        formula: string;
        fee: number;
    };
}

export interface directFeeRequestBody {
    id: number;
    isDirectTranslation: boolean;
    isEngDescriptionTranslationRequired: boolean;
    translationRate: number;
    aiTranslationRate?: number;
    trAiTrDifference?: number;
    trAiTrDifferencePercent?: number;
    isAiTranslationFieldsModified?: boolean;
    isAiTranslation?: boolean;
    groupId?: number;
    patentCategoryId?: number;
}

export interface companyDetailRateRequestBody {
    id: number;
    isDirectTranslation: boolean;
    isEngDescriptionTranslationRequired: boolean;
    companyTranslationRate: number;
    aiTranslationRate?: number;
    trAiTrDifference?: number;
    trAiTrDifferencePercent?: number;
    groupId?: number;
    isAiTranslationFieldsModified: boolean;
    isAiTranslation?: boolean;
}

export interface unitOptions {
    id: number;
    name: string;
}

export interface breakdownValues {
    breakdownName: string;
    vendorPercentage: number;
    companyPercentage: number;
    translateRateValue: number;
    rateChanged: boolean;
}

export interface companyTranslations {
    id: number;
    sourceLanguageId: number;
    sourceLanguageName: string;
    targetLanguageId: number;
    targetLanguageName: string;
    currencyId: number;
    currencyCode: string;
    enableMinCharge: true;
    minCharge: number;
    unitId: number;
    unitName: string;
    translationRate: number;
    agreeTmDiscount: boolean;
    breakdowns: breakdownValues[];
    currencySymbol: string;
}

export interface breakDownComponentProps {
    symbol: string;
    breakdown: breakdownProps[];
}

export interface breakdownProps {
    label: string;
    percentageValue: number;
    suffixValue: number;
    rateChanged: boolean;
}

export interface companyTranslationPopup {
    popupId: string;
    closeModal: () => void;
    rowData: DataValue;
    editMode: boolean;
    moduleName: string;
    updateListing: () => void;
    company: boolean;
    globalBreakdownValues: Breakdown[];
    rowBreakdownValues?: Breakdown[];
}

export interface dropdownDataValues {
    sourceLanguage: dropdownValuesType[];
    requestCurrency: dropdownValuesType[];
    unitOptions: unitOptions[];
    targetLanguage: dropdownValuesType[];
    allCurrencies: dropdownValuesType[];
}

export interface companyTranslationsChildren {
    rowData: any;
    setFormValues: any;
    breakdownValues: Breakdown[];
    editMode: boolean;
}
export interface companyTranslationsFormValues {
    id: number;
    sourceLanguageId: number;
    sourceLanguageName: string;
    targetLanguageId: number;
    targetLanguageName: string;
    targetLanguageIds: Array<number>;
    currencyId: number;
    currencyCode: string;
    enableMinCharge: true;
    minCharge: number;
    unitId: number;
    unitName: string;
    translationRate: number;
    agreeTmDiscount: true;
    breakdowns: breakdownValues[];
}

export interface userLanguagesResponse {
    name: string;
    isoCode: string;
    abbreviation: string;
    isSource: boolean;
    id: number;
}

export interface currencyListResponse {
    currencyId: number;
    currencyName: string;
    currencyIcon: string;
    concatCode: string;
    currencyCode: string;
    currencySymbol: string;
}

export interface TargetLanguageResponse {
    name: string;
    id: number;
}

export interface LanguageResponse {
    name: string;
    isoCode: string;
    abbreviation: string;
    id: number;
}

export interface CreateCompanyPayloadType {
    id: number;
    sourceLanguageId: number;
    sourceLanguageName: string;
    targetLanguageId: number;
    targetLanguageName: string;
    targetLanguageIds: Array<number>;
    currencyId: number;
    currencyCode: string;
    enableMinCharge: boolean;
    minCharge: number;
    unitId: number;
    unitName: string;
    translationRate: number;
    agreeTmDiscount: boolean;
    breakdowns?: any;
    rateChanged?: boolean;
}

export interface CreateVendorPayloadType {
    id: number;
    sourceLanguageId: number;
    sourceLanguageName: string;
    targetLanguageId: number;
    targetLanguageName: string;
    targetLanguageIds: Array<number>;
    currencyId: number;
    currencyCode: string;
    unitId: number;
    unitName: string;
    translationRate: number;
    enableBreakdown: boolean;
    abilityId: number;
    breakdowns?: any;
}

export interface validateFormulaTypes {
    state: 'valid' | 'invalid' | 'validate';
    error?: string;
}

export interface FormulaUpdateResponse {
    isSuccess: boolean;
    error: string;
}

export interface editCompanylevelTranslations {
    id: number;
    translationRate: number;
    breakdowns?: any;
    rateChanged: boolean;
    agreeTmDiscount: boolean;
    minCharge: number;
}

export interface TranslationFormulaUpdate {
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    agencyFee?: number;
    translationRate?: number;
    descriptionTranslationFormula: descriptionTranslationFormula;
    aiIndirectTranslationRate?: number;
    indirectTrAiTrDifference?: number;
    indirectTrAiTrDifferencePercent?: number;
    isAiTranslation?: boolean;
    isAiTranslationFieldsModified?: boolean;
}

export interface CompanyTranslationFormulaUpdate {
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    agencyFee?: number;
    translationRate?: number;
    descriptionTranslationFormula: descriptionTranslationFormula;
    companyId: number;
}

export interface TranslationRateEditProps {
    rowData: DataValue;
    fieldName: string;
    inlineEditStyles?: string;
    inlineEdit: boolean;
    valueKey?: string;
    compareKey?: string;
    readOnly?: boolean;
    editCell: (rowData: DataValue, fieldName: string, updatedValue?: number) => void;
    isPercentage?: boolean;
}
