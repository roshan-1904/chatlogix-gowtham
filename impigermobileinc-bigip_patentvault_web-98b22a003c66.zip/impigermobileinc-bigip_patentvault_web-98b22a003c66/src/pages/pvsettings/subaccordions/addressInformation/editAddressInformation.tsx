import { Form } from '@formio/react';
import { useTranslation } from 'react-i18next';
import { useState } from 'react';

import formData from './editform.mock.json';

import PopupModal from 'components/popupModal/popupModal';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import { isDataDifferent } from 'core/utils/utils';
import HttpService from 'core/interceptor/api.handler';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';

const EditAddressInformation: React.FC<{
    closeModal: (data: any) => void;
    onSubmit: (data: any) => void;
}> = ({ closeModal, onSubmit }) => {
    const { t } = useTranslation();
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData);

    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(formData);

    const onFormChange = (e: any) => {
        if (e.changed) {
            const { data, isValid } = e;
            delete data.submit;
            if (isDataDifferent(formState.data, data)) {
                formStatusStore.updateFormData(data, isValid as boolean);
            }
        }
    };

    const handleSubmit = () => {
        onSubmit(formState.data);
    };

    formStatusStore.subscribe(setFormState);

    const close = () => {
        closeModal(formState.data);
    };

    return (
        <div>
            <PopupModal
                id={TABLE_POP_IDS.CREATE_POPUP.EDIT_ADDRESS_INFORMATION_POPUP}
                title={t('COMMON.EDIT_ADDRESS_INFORMATION')}
                onClose={() => close()}
                createButtonText={t('COMMON.UPDATE')}
                resetButtonText={t('COMMON.CANCEL')}
                isEdit={true}
                onSubmit={handleSubmit}>
                <div className="p-4 bg-neutral-300 pb-0">
                    <Form
                        form={formBuilderData}
                        onChange={onFormChange}
                        submission={{ data: formState.data }}
                    />
                </div>
            </PopupModal>
        </div>
    );
};

export default EditAddressInformation;
