import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import AddressInformation from './addressInformation';
import PVSettingsService from '../service/pvsettings.service';
import AuthStore from 'core/store/authStore/authStore';
import formStatusStore from 'core/store/formIoStore/formIoStore';

// Override the react-formio components with mock implementations
jest.mock('@formio/react', () => ({
    Form: jest.fn(),
    FormBuilder: jest.fn(),
    Utils: jest.fn()
}));

jest.mock('../service/pvsettings.service', () => ({
    getAddressInformation: jest.fn(),
    updateAddressInformation: jest.fn()
}));

jest.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate hook can use it without a warning being shown
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

AuthStore.hasPermission = jest.fn();

describe('PVSettings Unit test', () => {
    test('Checking Wheather Address Information Accordion is rendered', () => {
        render(<AddressInformation setVisibility={() => {}} visibility={true} />);

        const sample: HTMLElement = screen.getByTestId('AddressInformation-Accordian');

        expect(sample).toBeInTheDocument();
    });

    test('checking wheather address information labels  are rendered', async () => {
        render(<AddressInformation setVisibility={() => {}} visibility={true} />);
        await waitFor(() => {
            const address1: HTMLElement = screen.getByText('COMMON.ADDRESS_1');
            const address2: HTMLElement = screen.getByText('COMMON.ADDRESS_2');
            const country: HTMLElement = screen.getByText('COMMON.COUNTRY');
            const state: HTMLElement = screen.getByText('COMMON.STATE');
            const city: HTMLElement = screen.getByText('COMMON.CITY');
            const zip: HTMLElement = screen.getByText('COMMON.ZIP');

            expect(address1).toBeInTheDocument();
            expect(address2).toBeInTheDocument();
            expect(country).toBeInTheDocument();
            expect(state).toBeInTheDocument();
            expect(city).toBeInTheDocument();
            expect(zip).toBeInTheDocument();
        });
    });

    test('checking wheather edit address button onClick', () => {
        const mockModal = {
            show: jest.fn()
        };

        jest.spyOn(document, 'getElementById').mockReturnValueOnce(
            mockModal as unknown as HTMLDialogElement | null
        );

        const mockModal1 = {
            close: jest.fn()
        };

        // Mock the document.getElementById method
        jest.spyOn(document, 'getElementById').mockReturnValueOnce(
            mockModal1 as unknown as HTMLDialogElement | null
        );
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);

        // Call the openModal function

        // Verify that showModal was called

        render(<AddressInformation setVisibility={() => {}} visibility={true} />);

        const editAddressButton: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS');

        expect(editAddressButton).toBeInTheDocument();

        fireEvent.click(editAddressButton);

        const editPopBox: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS_INFORMATION');

        expect(editPopBox).toBeInTheDocument();

        const closeButton: HTMLElement = screen.getByTestId('PopUp-Close');

        expect(closeButton).toBeInTheDocument();

        // fireEvent.click(closeButton);
        // expect(mockModal1.close).toHaveBeenCalled();
    });

    test('Get Address Inforamtion Api mock', async () => {
        const mockData = [
            {
                address1: '3424 Peachtree Rd NEs',
                address2: 'Test',
                city: 'Atlantas',
                state: 'Ain Defla',
                countryId: 1,
                stateId: 3059,
                countryName: 'Algeria (DZ)',
                zip: '30320',
                webSiteUrl: '',
                phoneNumber: '+93-6866966868',
                id: 1,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            }
        ];

        (PVSettingsService.getAddressInformation as jest.Mock).mockResolvedValue(mockData);
        render(<AddressInformation setVisibility={() => {}} visibility={true} />);
        await new Promise((r) => setTimeout(r, 1000));

        await waitFor(() => {
            const sample: HTMLElement = screen.getByTestId('AddressInformation-Accordian');
            const address1: HTMLElement = screen.getByText('3424 Peachtree Rd NEs');
            const address2: HTMLElement = screen.getByText('Test');
            const city: HTMLElement = screen.getByText('Atlantas');
            // const state: HTMLElement = screen.getByText('Ain Defla');
            // const countryName: HTMLElement = screen.getByText('Algeria (DZ)');
            const zip: HTMLElement = screen.getByText('30320');

            expect(sample).toBeInTheDocument();
            expect(address1).toBeInTheDocument();
            expect(address2).toBeInTheDocument();
            expect(city).toBeInTheDocument();
            // expect(state).toBeInTheDocument();
            // expect(countryName).toBeInTheDocument();
            expect(zip).toBeInTheDocument();
        });
    });

    test('checking edit address Page', async () => {
        const mockModal = {
            show: jest.fn()
        };

        jest.spyOn(document, 'getElementById').mockReturnValueOnce(
            mockModal as unknown as HTMLDialogElement | null
        );

        const mockSetFormState = jest.fn();

        // Mock useState implementation
        jest.mock('react', () => ({
            ...jest.requireActual('react'),
            useState: (formState: any) => [formState, mockSetFormState]
        }));
        // Call the openModal function

        // Verify that showModal was called

        const mockData = [
            {
                address1: 'test1',
                address2: 'Test',
                city: 'New York',
                state: 'US state',
                countryId: 2,
                countryName: 'ARIPO',
                zip: '12345',
                id: 1,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            }
        ];

        mockSetFormState(mockData);
        // const mockModal1 = {
        //     close: jest.fn(),
        //     onSubmit: jest.fn()
        // };

        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getAddressInformation as jest.Mock).mockResolvedValue(mockData);

        render(<AddressInformation setVisibility={() => {}} visibility={true} />);
        await waitFor(() => {
            const editAddressButton: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS');

            expect(editAddressButton).toBeInTheDocument();

            fireEvent.click(editAddressButton);

            const editPopBox: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS_INFORMATION');

            expect(editPopBox).toBeInTheDocument();

            expect(mockModal.show).toHaveBeenCalled();

            expect(screen.getByText('COMMON.UPDATE')).toBeInTheDocument();
        });

        await waitFor(() => {
            const address1: HTMLElement = screen.getByText('test1');
            const address2: HTMLElement = screen.getByText('Test');
            const city: HTMLElement = screen.getByText('New York');
            // const state: HTMLElement = screen.getByText('US state');
            // const countryName: HTMLElement = screen.getByText('ARIPO');
            const zip: HTMLElement = screen.getByText('12345');

            expect(address1).toBeInTheDocument();
            expect(address2).toBeInTheDocument();
            expect(city).toBeInTheDocument();
            // expect(state).toBeInTheDocument();
            // expect(countryName).toBeInTheDocument();
            expect(zip).toBeInTheDocument();

            // TODO:
            // fireEvent.change(address1, { target: { value: 'steve' } });
            // fireEvent.change(address2, { target: { value: 'captain' } });
            // fireEvent.change(city, { target: { value: 'brooklin' } });
            // fireEvent.change(state, { target: { value: 'US' } });
            // fireEvent.click(countryName);
            // expect(screen.getByText);
            // fireEvent.change(zip, { target: { value: '54321' } });
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const save: HTMLElement = screen.getByText('COMMON.UPDATE');
            expect(save).toBeInTheDocument();
            fireEvent.click(save);

            const editPopBox: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS_INFORMATION');

            expect(editPopBox).toBeInTheDocument();
        });
    });

    // TODO:
    it('should submit address information data with country as an object', async () => {
        const mockData = [
            {
                address1: 'test1',
                address2: 'Test',
                city: 'New York',
                state: 'US state',
                countryId: 2,
                countryName: 'ARIPO',
                zip: '12345',
                id: 1,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            }
        ];
        (PVSettingsService.getAddressInformation as jest.Mock).mockResolvedValue(mockData);
        const data = {
            id: '1',
            address1: '123 Main St',
            address2: 'Apt 2',
            city: 'New York',
            state: { id: 1, name: 'NY' },
            countryName: { id: 'US', name: 'United States' }, // Country is an object
            zip: '12345'
        };
        formStatusStore.updateFormData(data, true, true);
        (PVSettingsService.updateAddressInformation as jest.Mock).mockResolvedValue(true);
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        const mockModal = {
            show: jest.fn()
        };

        jest.spyOn(document, 'getElementById').mockReturnValueOnce(
            mockModal as unknown as HTMLDialogElement | null
        );
        render(<AddressInformation setVisibility={() => {}} visibility={true} />);

        await waitFor(() => {
            const editAddressButton: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS');

            expect(editAddressButton).toBeInTheDocument();

            fireEvent.click(editAddressButton);

            const editPopBox: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS_INFORMATION');

            expect(editPopBox).toBeInTheDocument();

            expect(mockModal.show).toHaveBeenCalled();
            const save: HTMLElement = screen.getByText('COMMON.UPDATE');
            expect(save).toBeInTheDocument();
            fireEvent.click(save);
            fireEvent.keyDown(save);

            expect(editPopBox).toBeInTheDocument();
            // expect(screen.getByText('COMMON.NO_DON_T')).toBeInTheDocument();
        });
        // Expect updateAddressInformationData to be called with the correct address object
        // expect(updateAddressInformationData).toHaveBeenCalledWith({
        //     id: '1',
        //     address1: '123 Main St',
        //     address2: 'Apt 2',
        //     city: 'New York',
        //     state: 'NY',
        //     countryId: 'US',
        //     countryName: 'United States',
        //     zip: '12345'
        // });
    });

    it('closing the edit address popup', async () => {
        const data = {
            id: '1',
            address1: '123 Main St',
            address2: 'Apt 2',
            city: 'New York',
            state: { id: 1, name: 'NY' },
            countryName: { id: 'US', name: 'United States' }, // Country is an object
            zip: '12345'
        };
        formStatusStore.updateFormData(data, true, true);
        const mockModal = {
            show: jest.fn()
        };

        jest.spyOn(document, 'getElementById').mockReturnValueOnce(
            mockModal as unknown as HTMLDialogElement | null
        );

        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        render(<AddressInformation setVisibility={() => {}} visibility={true} />);

        await waitFor(() => {
            const editAddressButton: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS');

            expect(editAddressButton).toBeInTheDocument();

            fireEvent.keyDown(editAddressButton);
            fireEvent.click(editAddressButton);

            const editPopBox: HTMLElement = screen.getByText('COMMON.EDIT_ADDRESS_INFORMATION');

            expect(editPopBox).toBeInTheDocument();

            expect(mockModal.show).toHaveBeenCalled();
            const cancelButton: HTMLElement = screen.getByText('COMMON.CANCEL');
            expect(cancelButton).toBeInTheDocument();
            fireEvent.click(cancelButton);
        });
    });

    // it('should submit address information data with country as a string', async () => {
    //     const data = {
    //         id: '1',
    //         address1: '123 Main St',
    //         address2: 'Apt 2',
    //         city: 'New York',
    //         state: 'NY',
    //         countryName: 'US', // Country is a string
    //         zip: '12345'
    //     };

    //     await onSubmit(data);

    //     // Expect updateAddressInformationData to be called with the correct address object
    //     expect(updateAddressInformationData).toHaveBeenCalledWith({
    //         id: '1',
    //         address1: '123 Main St',
    //         address2: 'Apt 2',
    //         city: 'New York',
    //         state: 'NY',
    //         countryId: 'US',
    //         countryName: 'US',
    //         zip: '12345'
    //     });
    // });

    // it('should call closeModal after submitting address information data', async () => {
    //     const data = {
    //         id: '1',
    //         address1: '123 Main St',
    //         address2: 'Apt 2',
    //         city: 'New York',
    //         state: 'NY',
    //         countryName: 'US',
    //         zip: '12345'
    //     };

    //     await onSubmit(data);

    //     // Expect closeModal to be called
    //     expect(closeModal).toHaveBeenCalled();
    // });
});
