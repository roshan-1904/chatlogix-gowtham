import { useTranslation } from 'react-i18next';

import EditAddressInformation from './editAddressInformation';
import { useEffect, useState } from 'react';
import PVSettingsService from '../service/pvsettings.service';
import { AddressInformationModel } from '../types/pvsettings.types';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { isDataDifferent } from 'core/utils/utils';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';
import companiesService from 'pages/companies/service/companies.service';
import { Permissions } from 'constants/permissions';

interface AddressInformationProps {
    setVisibility: (data: boolean) => void;
    visibility: boolean;
}
const AddressInformation: React.FC<AddressInformationProps> = ({ setVisibility }) => {
    const { t } = useTranslation();
    const [addressData, setAddressData] = useState<AddressInformationModel>();
    const [showModal, setShowModal] = useState(false);
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        description: ''
    });

    const showToastMessage = (toastMsg: string, notifyType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: notifyType
        };
        NotificationStore.showAlert(message);
    };

    // Function for Get Currency Exchange Data using Api
    const getAddressInformationData = async () => {
        try {
            const response =
                await PVSettingsService.getAddressInformation<AddressInformationModel[]>();
            if (response.length > 0) {
                const selectedData: AddressInformationModel = response[0];
                const stateID: number = selectedData.stateId;
                const { country, state } = await companiesService.getCountryAndState(
                    selectedData.countryId,
                    stateID
                );

                response[0].countryName = country;
                response[0].state = state;
                setAddressData(response[0]);
            }
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.ADDRESS_INFORMATION.ERROR_MESSAGE.GET_ADDRESS_INFORMATION_DATA'),
                ToastType.ERROR
            );
        }
    };

    // Function for Update Address Information Data using Api
    const updateAddressInformationData = async (body: AddressInformationModel) => {
        try {
            const response =
                await PVSettingsService.updateAddressInformation<AddressInformationModel>(body);
            if (response) {
                showToastMessage(
                    t(
                        'PV_SETTING.ADDRESS_INFORMATION.SUCCESS_MESSAGE.UPDATE_ADDRESS_INFORMATION_DATA'
                    ),
                    ToastType.SUCCESS
                );
                const stateID: number = response.stateId;
                const { country, state } = await companiesService.getCountryAndState(
                    response?.countryId,
                    stateID
                );

                response.countryName = country;
                response.state = state;
                setAddressData(response);
            }
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.ADDRESS_INFORMATION.ERROR_MESSAGE.UPDATE_ADDRESS_INFORMATION_DATA'),
                ToastType.ERROR
            );
        }
    };

    const onSubmit = (data: any) => {
        const address: AddressInformationModel = {
            id: data?.id,
            address1: data?.address1,
            address2: data?.address2,
            city: data?.city,
            phoneNumber: data?.phoneNumber,
            webSiteUrl: data?.webSiteUrl,
            stateId: data.state?.id,
            state: data.state?.name,
            countryId: data.countryName?.id,
            countryName: data.countryName?.name,
            zip: data.zip.toString()
        };
        updateAddressInformationData(address)
            .then(() => {
                closeModal();
            })
            .catch(() => {
                closeModal();
            });
    };

    useEffect(() => {
        getAddressInformationData();
    }, []);

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.EDIT_ADDRESS_INFORMATION_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
        setVisibility(false);
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.EDIT_ADDRESS_INFORMATION_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
            setShowPopup({ ...showPopup, visible: false });
            setVisibility(false);
        }
    };

    const handleConfirmationPopup = (data: any) => {
        if (data) {
            const isDifferent = isDataDifferent(addressData, data);
            if (isDifferent) {
                setShowPopup({
                    visible: true,
                    header: t('COMMON.CONFIRMATION'),
                    description: t('COMMON.CONFIRMATION_FOR_STATUS_CLOSE')
                });
            } else {
                closeModal();
            }
        }
    };

    const handleConfirm = () => {
        closeModal();
        setShowPopup({ ...showPopup, visible: false });
    };

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    return (
        <div className="py-2 pb-3" data-testid="AddressInformation-Accordian">
            {showModal && (
                <>
                    {showPopup.visible && (
                        <ConfirmationPopup
                            onConfirm={() => handleConfirm()}
                            onCancel={() => handleCancel()}
                            visible={showPopup.visible}
                            headerText={showPopup.header}
                            description={showPopup.description}
                            acceptLabel={t('COMMON.YES_DISCARD')}
                            rejectLabel={t('COMMON.NO_DON_T')}
                            rejectClassName={'!bg-error !px-6 !text-white'}
                            acceptClassName={'!bg-neutral-50 !px-5 !text-black !border-neutral-100'}
                        />
                    )}

                    <EditAddressInformation
                        closeModal={handleConfirmationPopup}
                        onSubmit={onSubmit}
                    />
                </>
            )}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.ADDRESS_1')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.address1?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.ADDRESS_2')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.address2?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.PHONE_NUMBER')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.phoneNumber?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.WEBSITE_URL')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.webSiteUrl?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.COUNTRY')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.countryName?.name?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.STATE')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.state?.name?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.CITY')}
                    </label>
                    <div className="break-words font-medium">
                        {addressData?.city?.trim() || '-'}
                    </div>
                </div>
                <div>
                    <label className="text-neutral-700 font-medium text-sm">
                        {t('COMMON.ZIP')}
                    </label>
                    <div className="break-words font-medium">{addressData?.zip?.trim() || '-'}</div>
                </div>
            </div>
            {AuthStore.hasPermission(Permissions.EDIT_IP_VAULT_SETTINGS) && (
                <div className="pt-3">
                    <button
                        onClick={() => {
                            formStatusStore.updateFormData(addressData, false);
                            openModal();
                        }}
                        onKeyDown={() => {
                            formStatusStore.updateFormData(addressData, false);
                            openModal();
                        }}
                        className="btn btn-outline min-h-[2.7rem] h-[2.7rem] border-[1.6px] text-base text-primary border-primary-100 hover:bg-primary-50 hover:text-primary hover:border-primary !font-medium">
                        <img src="/images/svgs/i-edit-blue-icon.svg" className="h-4 w-4" />
                        {t('COMMON.EDIT_ADDRESS')}
                    </button>
                </div>
            )}
        </div>
    );
};

export default AddressInformation;
