import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import PVSettingsService from '../service/pvsettings.service';
import CreateCurrencyExchange from './createCurrencyExchanges';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: () => ({
        pathname: 'localhost:3000/example/path'
    })
}));

jest.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate hook can use it without a warning being shown
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

jest.mock('../service/pvsettings.service', () => ({
    getCurrencyList: jest.fn(),
    createCurrencyExchange: jest.fn()
}));

const mockCloseModal = jest.fn();
const mockOnChangeCreateAnother = jest.fn();
const mockOnSubmit = jest.fn();

describe('PVSettings Unit test create currency exchange', () => {
    test('checking wheather able to create the currency exchange', async () => {
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        render(
            <CreateCurrencyExchange
                closeModal={mockCloseModal}
                onChangeCreateAnother={mockOnChangeCreateAnother}
                onSubmit={mockOnSubmit}
            />
        );

        await waitFor(() => {
            const title: HTMLElement = screen.getByText('COMMON.CONFIGURE_CURRENCY_EXCHANGE');
            expect(title).toBeInTheDocument();
        });

        await waitFor(() => {
            const fromDropdown: HTMLElement = screen.getByTestId('from-dropdown');
            expect(fromDropdown).toBeInTheDocument();
            fireEvent.click(fromDropdown);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value: HTMLElement = screen.getByText('ABC - ABC Currency01');
            expect(value).toBeInTheDocument();
            fireEvent.click(value);
        });

        await waitFor(() => {
            const toDropdown: HTMLElement = screen.getByTestId('to-dropdown');
            expect(toDropdown).toBeInTheDocument();
            fireEvent.click(toDropdown);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value2: HTMLElement = screen.getByText('XUA - ADB Unit of Account');
            expect(value2).toBeInTheDocument();
            fireEvent.click(value2);
        });

        await waitFor(() => {
            const swapButton: HTMLElement = screen.getByTestId('swap-button');
            expect(swapButton).toBeInTheDocument();
            fireEvent.click(swapButton);

            const rateInputBox: HTMLElement = screen.getByPlaceholderText('Rate');
            expect(rateInputBox).toBeInTheDocument();
            fireEvent.change(rateInputBox, { target: { value: '9.9999' } });
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const saveButton: HTMLElement = screen.getByText('COMMON.CREATE');
            expect(saveButton).toBeInTheDocument();
            fireEvent.click(saveButton);
        });
    });

    test('checking wheather currency list api failes', () => {
        (PVSettingsService.getCurrencyList as jest.Mock).mockRejectedValue(
            'failed to fetch currency list'
        );
        render(
            <CreateCurrencyExchange
                closeModal={mockCloseModal}
                onChangeCreateAnother={mockOnChangeCreateAnother}
                onSubmit={mockOnSubmit}
            />
        );
    });

    test('checking create another and reset button', () => {
        (PVSettingsService.getCurrencyList as jest.Mock).mockRejectedValue(
            'failed to fetch currency list'
        );
        render(
            <CreateCurrencyExchange
                closeModal={mockCloseModal}
                onChangeCreateAnother={mockOnChangeCreateAnother}
                onSubmit={mockOnSubmit}
            />
        );

        const createAnother: HTMLElement = screen.getByText('COMMON.CREATE_ANOTHER');
        expect(createAnother).toBeInTheDocument();
        fireEvent.click(createAnother);

        const rateInputBox: HTMLElement = screen.getByPlaceholderText('Rate');
        expect(rateInputBox).toBeInTheDocument();
        fireEvent.change(rateInputBox, { target: { value: '9.999999' } });

        const resetButton: HTMLElement = screen.getByText('COMMON.RESET');
        expect(resetButton).toBeInTheDocument();
        fireEvent.click(resetButton);

        const saveButton: HTMLElement = screen.getByText('COMMON.CREATE');
        expect(saveButton).toBeInTheDocument();
        fireEvent.click(saveButton);
    });

    test('checking wheather able to create the currency exchange when error in required field', async () => {
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        render(
            <CreateCurrencyExchange
                closeModal={mockCloseModal}
                onChangeCreateAnother={mockOnChangeCreateAnother}
                onSubmit={mockOnSubmit}
            />
        );

        await waitFor(() => {
            const title: HTMLElement = screen.getByText('COMMON.CONFIGURE_CURRENCY_EXCHANGE');
            expect(title).toBeInTheDocument();
        });

        await waitFor(() => {
            const toDropdown: HTMLElement = screen.getByTestId('to-dropdown');
            expect(toDropdown).toBeInTheDocument();
            fireEvent.click(toDropdown);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value2: HTMLElement = screen.getByText('XUA - ADB Unit of Account');
            expect(value2).toBeInTheDocument();
            fireEvent.click(value2);
        });

        await waitFor(() => {
            const rateInputBox: HTMLElement = screen.getByPlaceholderText('Rate');
            expect(rateInputBox).toBeInTheDocument();
            fireEvent.change(rateInputBox, { target: { value: '9.9999999' } });
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const saveButton: HTMLElement = screen.getByText('COMMON.CREATE');
            expect(saveButton).toBeInTheDocument();
            fireEvent.click(saveButton);
            // const errorMessgae: HTMLElement = screen.getByText('From currency is required.');
            // expect(errorMessgae).toBeInTheDocument();
            const confirmPopup: HTMLElement = screen.getByTestId('PopUp-Close');
            expect(confirmPopup).toBeInTheDocument();
            fireEvent.click(confirmPopup);
            const yes: HTMLElement = screen.getByText('COMMON.YES');
            expect(yes).toBeInTheDocument();
            fireEvent.click(yes);
        });
    });

    test('checking wheather able to create the currency exchange when popup is closes', async () => {
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        render(
            <CreateCurrencyExchange
                closeModal={mockCloseModal}
                onChangeCreateAnother={mockOnChangeCreateAnother}
                onSubmit={mockOnSubmit}
            />
        );

        await waitFor(() => {
            const title: HTMLElement = screen.getByText('COMMON.CONFIGURE_CURRENCY_EXCHANGE');
            expect(title).toBeInTheDocument();
        });

        await waitFor(async () => {
            const saveButton: HTMLElement = screen.getByText('COMMON.CREATE');
            expect(saveButton).toBeInTheDocument();
            fireEvent.click(saveButton);
            const confirmPopup: HTMLElement = screen.getByTestId('PopUp-Close');
            expect(confirmPopup).toBeInTheDocument();
            fireEvent.click(confirmPopup);
            await waitFor(() => {
                const rateInputBox: HTMLElement = screen.getByPlaceholderText('Rate');
                expect(rateInputBox).toBeInTheDocument();
                fireEvent.change(rateInputBox, { target: { value: '9.9999999' } });
            });

            const noButton: HTMLElement = screen.getByText('COMMON.NO');
            expect(noButton).toBeInTheDocument();
            fireEvent.click(noButton);
        });
    });
});
