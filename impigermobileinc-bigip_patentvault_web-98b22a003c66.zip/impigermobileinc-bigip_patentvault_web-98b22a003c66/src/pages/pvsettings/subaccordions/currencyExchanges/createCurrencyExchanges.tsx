import { useTranslation } from 'react-i18next';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';

import { Dropdown } from 'primereact/dropdown';

import { CreateCurrency, CurrencyList, ErrorCurrencyExchange } from '../types/pvsettings.types';
import PVSettingsService from '../service/pvsettings.service';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import { dropDownStyle } from 'constants/styles.constant';

const CreateCurrencyExchange: React.FC<{
    closeModal: () => void;
    onChangeCreateAnother: Dispatch<SetStateAction<boolean>>;
    onSubmit: (data: any) => void;
}> = ({ closeModal, onChangeCreateAnother, onSubmit }) => {
    const { t } = useTranslation();
    const [currency, setCurrency] = useState<CurrencyList[] | undefined>([
        {
            currencyId: 513,
            currencyName: 'ABC - ABC Currency01',
            currencyIcon: ''
        },
        {
            currencyId: 514,
            currencyName: 'USD - US Dollar',
            currencyIcon: ''
        }
    ]);
    const [currencyExchange, setCurrencyExchange] = useState<CreateCurrency | undefined>();
    const [errorMessage, setErrorMessage] = useState<ErrorCurrencyExchange>({
        from: null,
        to: null,
        rate: null
    });
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        description: ''
    });

    // Function for Get Currency List using Api
    const getCurrencyList = async () => {
        try {
            const response = await PVSettingsService.getCurrencyList<CurrencyList[]>();
            setCurrency(response);
        } catch (error) {
            console.error('Error Fetching currency list:', error);
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.GET_CURRENCY_DATA'),
                ToastType.ERROR
            );
        }
    };

    // Toast message function
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    useEffect(() => {
        getCurrencyList();
    }, []);

    useEffect(() => {
        if (currencyExchange?.rate && !/^\d{1,6}(\.\d{1,5})?$/.test(currencyExchange?.rate)) {
            // If rate is not in the correct format, show error message
            setErrorMessage((prev) => ({
                ...prev,
                rate: 'Invalid rate format. Please enter a numerical value with a maximum of 6 digits.'
            }));
        } else {
            setErrorMessage((prev) => ({
                ...prev,
                rate: null
            }));
        }
    }, [currencyExchange?.rate]);

    useEffect(() => {}, [errorMessage]);

    const selectedCountryTemplate = (option: CurrencyList, props: any) => {
        if (option) {
            return (
                <div className="flex items-center">
                    <div className="avatar">
                        <div className="h-6 rounded-full border">
                            <div
                                className={`h-full w-full bg-no-repeat bg-center`}
                                style={{
                                    backgroundImage:
                                        'url(/images/country-flags/' + option?.currencyIcon + ')',
                                    backgroundSize: '150%'
                                }}></div>
                        </div>
                    </div>
                    &nbsp;&nbsp;
                    <div>{option.currencyName}</div>
                </div>
            );
        }
        return (
            <span className="text-neutral-200/90 flex items-center pl-[0.675rem]">
                {props.placeholder}
            </span>
        );
    };

    const countryOptionTemplate = (option: CurrencyList) => {
        return (
            <div className="flex items-center">
                <div className="avatar">
                    <div className="h-6 rounded-full border">
                        <div
                            className={`h-full w-full bg-no-repeat bg-center`}
                            style={{
                                backgroundImage:
                                    'url(/images/country-flags/' + option?.currencyIcon + ')',
                                backgroundSize: '150%'
                            }}></div>
                    </div>
                </div>
                &nbsp;&nbsp;
                <div className="truncate">{option.currencyName}</div>
            </div>
        );
    };

    const handleSubmit = () => {
        const errors = {
            from: !currencyExchange?.from ? 'From currency is required.' : null,
            to: !currencyExchange?.to ? 'To currency is required.' : null,
            rate: !currencyExchange?.rate ? 'Rate is required.' : errorMessage.rate
        };

        if (currencyExchange?.from?.currencyId === currencyExchange?.to?.currencyId) {
            errors.to = 'To and From Currencies cannot be the same.';
        }

        // Set error messages for empty fields
        setErrorMessage({
            from: errors.from,
            to: errors.to,
            rate: errors.rate
        });

        // If any field is empty, return without submitting the form
        if (errors.from == null && errors.to == null && errors.rate == null) {
            onSubmit(currencyExchange);
            setCurrencyExchange(undefined);
        }
        // If there are no errors, proceed with form submission
        else {
            return;
        }
    };

    const handleOnChange = (field: string, value: any) => {
        const val = { ...currencyExchange, [field]: value };

        setCurrencyExchange(val);

        // Validate input dynamically and set error messages
        switch (field) {
            case 'from':
                if (value?.currencyId === currencyExchange?.to?.currencyId) {
                    setErrorMessage((prev) => ({
                        ...prev,
                        from: 'From and To Currencies cannot be the same.'
                    }));
                } else {
                    setErrorMessage((prev) => ({
                        ...prev,
                        from: null
                    }));
                }
                if (!value) {
                    setErrorMessage((prev) => ({
                        ...prev,
                        from: 'From currency is required.'
                    }));
                }
                break;
            case 'to':
                if (value?.currencyId === currencyExchange?.from?.currencyId) {
                    setErrorMessage((prev) => ({
                        ...prev,
                        to: 'To and From Currencies cannot be the same.'
                    }));
                } else {
                    setErrorMessage((prev) => ({
                        ...prev,
                        to: null
                    }));
                }
                if (!value) {
                    setErrorMessage((prev) => ({
                        ...prev,
                        to: 'To currency is required.'
                    }));
                }
                break;
            case 'rate':
                if (!/^\d{1,6}(\.\d{1,5})?$/.test(value as string)) {
                    setErrorMessage((prev) => ({
                        ...prev,
                        rate: 'Invalid rate format. Please enter a numerical value with a maximum of 6 digits.'
                    }));
                } else {
                    setErrorMessage((prev) => ({
                        ...prev,
                        rate: null
                    }));
                }
                break;
            default:
                break;
        }
    };

    const handleSwap = () => {
        const temp = currencyExchange?.from;
        setCurrencyExchange({ from: currencyExchange?.to, to: temp, rate: currencyExchange?.rate });
    };

    const dropdownEditor = (field: string, value: any) => {
        return (
            <Dropdown
                data-testid={`${field}-dropdown`}
                value={value}
                filter={true}
                onChange={(e) => handleOnChange(field, e.value)}
                options={currency}
                optionLabel="currencyName"
                valueTemplate={selectedCountryTemplate}
                itemTemplate={countryOptionTemplate}
                placeholder="Select a Currency"
                pt={{
                    ...dropDownStyle,
                    root: {
                        className: 'h-10 w-72 md:w-72 font-medium border border-neutral-100'
                    },
                    item: { className: 'hover:bg-primary-50 border-b-2 mx-2' },
                    input: { className: 'p-1 h-9' },
                    panel: { className: 'w-72' }
                }}
            />
        );
    };

    const handleConfirmPop = () => {
        setShowPopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t('COMMON.CONFIRMATION_FOR_STATUS_CLOSE')
        });
    };

    const handleConfirm = () => {
        closeModal();
        setShowPopup({ ...showPopup, visible: false });
    };

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    const handleClose = () => {
        if (
            currencyExchange === undefined ||
            (currencyExchange.from == null &&
                currencyExchange.to == null &&
                currencyExchange.rate == null) ||
            currencyExchange.rate === ''
        ) {
            return closeModal();
        } else {
            return handleConfirmPop();
        }
    };

    return (
        <div className="">
            <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50">
                <div className="bg-white shadow-lg rounded-md">
                    {/* Header */}
                    <div className="flex items-center justify-between bg-white drop-shadow p-4 rounded-t-lg">
                        <h2 className="text-xl font-medium text-primary-200">
                            {t('COMMON.CONFIGURE_CURRENCY_EXCHANGE')}
                        </h2>
                        <button
                            onClick={handleClose}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="PopUp-Close"
                            className="text-gray-500 hover:text-gray-800">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-6 w-6"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                    d="M6 18L18 6M6 6l12 12"
                                />
                            </svg>
                        </button>
                    </div>
                    {/* Content */}
                    {showPopup.visible && (
                        <ConfirmationPopup
                            onConfirm={() => handleConfirm()}
                            onCancel={() => handleCancel()}
                            visible={showPopup.visible}
                            headerText={showPopup.header}
                            description={showPopup.description}
                            acceptLabel={t('COMMON.YES')}
                            rejectLabel={t('COMMON.NO')}
                        />
                    )}
                    <div className="px-5 pt-6 bg-neutral-300 ">
                        <div className="container flex flex-col">
                            <div className="flex gap-3 h-20">
                                <div className="flex flex-col">
                                    <label className="pb-1 font-medium text-neutral-200">
                                        From&nbsp;<span className="text-red-500">*</span>
                                    </label>
                                    {dropdownEditor('from', currencyExchange?.from)}
                                    {errorMessage.from && (
                                        <p className="text-end text-secondary font-medium flex gap-1 justify-end items-center pt-1">
                                            <span className="text-[0.65625rem] pt-[0.1rem]">
                                                {errorMessage.from}
                                            </span>
                                        </p>
                                    )}
                                </div>
                                <div className="pt-7 mt-[0.35rem]">
                                    <button
                                        data-testid="swap-button"
                                        className="bg-neutral-100/50 border border-neutral-200/50 rounded-md w-6 h-6 group hover:bg-primary grid place-content-center"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => handleSwap()}>
                                        <i className="pi pi-arrow-right-arrow-left font-normal group-hover:text-white text-[1rem] text-neutral-700"></i>
                                    </button>
                                </div>
                                <div className="flex flex-col">
                                    <label className="pb-1 font-medium text-neutral-200">
                                        To&nbsp;<span className="text-red-500">*</span>
                                    </label>
                                    {dropdownEditor('to', currencyExchange?.to)}
                                    {errorMessage.to && (
                                        <p className="text-end text-secondary font-medium flex gap-1 justify-end items-center pt-1">
                                            <span className="text-[0.65625rem] pt-[0.1rem]">
                                                {errorMessage.to}
                                            </span>
                                        </p>
                                    )}
                                </div>
                            </div>
                            <div className="flex flex-col w-fit h-24">
                                <label className="pb-1 font-medium text-neutral-200">
                                    Rate&nbsp;<span className="text-red-500">*</span>
                                </label>
                                <input
                                    value={currencyExchange ? currencyExchange?.rate : ''}
                                    type="text"
                                    className="w-72 text-sm font-medium input input-bordered border-neutral-100 focus:border-neutral-100 focus:outline-none h-10 rounded-md border disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200"
                                    placeholder="Rate"
                                    onChange={(e) => handleOnChange('rate', e.target.value)}
                                    pattern="\d+(\.\d{1,5})?"
                                />
                                {errorMessage.rate && (
                                    <p className="text-end text-secondary font-medium flex gap-1 justify-end items-center pt-1">
                                        <span className="text-[0.65625rem] pt-[0.1rem]">
                                            {errorMessage.rate}
                                        </span>
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Footer */}
                    <div
                        className={`flex items-center bg-white border-t border-gray-300 shadow-md px-4 py-3 rounded-b-lg  justify-between `}>
                        <label className="label cursor-pointer flex items-center space-x-2">
                            <input
                                type="checkbox"
                                className="form-checkbox"
                                onChange={(e) => onChangeCreateAnother(e.target.checked)}
                            />
                            <span className="text-base leading-none">
                                {t('COMMON.CREATE_ANOTHER')}
                            </span>
                        </label>
                        <div className="flex gap-2">
                            <button
                                className="btn btn-sm button-neutral font-medium"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                data-testid="reset-button"
                                onClick={() => {
                                    setCurrencyExchange(undefined);
                                    setErrorMessage({ from: null, to: null, rate: null });
                                }}>
                                {t('COMMON.RESET')}
                            </button>
                            <button
                                className={'btn btn-sm button-primary font-medium'}
                                onClick={handleSubmit}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                data-testid={'submit-button-popup'}
                                disabled={
                                    !(
                                        currencyExchange?.from &&
                                        currencyExchange?.to &&
                                        currencyExchange?.rate
                                    )
                                }>
                                {t('COMMON.CREATE')}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateCurrencyExchange;
