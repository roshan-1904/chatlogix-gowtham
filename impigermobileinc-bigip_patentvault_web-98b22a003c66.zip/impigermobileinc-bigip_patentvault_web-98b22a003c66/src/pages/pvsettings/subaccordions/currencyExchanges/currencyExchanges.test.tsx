import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CurrencyExchanges from './currencyExchanges';
import PVSettingsService from '../service/pvsettings.service';
import { CurrencyExchangeModel, GetCurrencyExchangeApiResponse } from '../types/pvsettings.types';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: () => ({
        pathname: 'localhost:3000/example/path'
    })
}));

jest.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate hook can use it without a warning being shown
    useTranslation() {
        return {
            t: (str: string) => str,
            i18n: {
                changeLanguage: () => new Promise(() => {})
            }
        };
    },
    initReactI18next: {
        type: '3rdParty',
        init() {}
    }
}));

jest.mock('../service/pvsettings.service', () => ({
    getCurrencyExchangeData: jest.fn(),
    getCurrencyList: jest.fn(),
    updateCurrencyExchange: jest.fn(),
    createCurrencyExchange: jest.fn(),
    deleteCurrencyExchange: jest.fn()
}));

AuthStore.hasPermission = jest.fn();

describe('PVSettings Unit test', () => {
    test('Checking Wheather Currency Exchanges Accordion is rendered', () => {
        render(<CurrencyExchanges />);

        const sample: HTMLElement = screen.getByTestId('CurrencyExchanges-Accordion');

        expect(sample).toBeInTheDocument();
    });

    test('checking wheather table is rendered', () => {
        render(<CurrencyExchanges />);

        const from: HTMLElement = screen.getByText('COMMON.FROM');
        const to: HTMLElement = screen.getByText('COMMON.TO');
        const rate: HTMLElement = screen.getByText('COMMON.RATE');
        // const action: HTMLElement = screen.getByLabelText('State');

        expect(from).toBeInTheDocument();
        expect(to).toBeInTheDocument();
        expect(rate).toBeInTheDocument();
    });

    test('checking whether delete record onClick', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'AUD - Australian Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'CAD - Canadian Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };

        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        (PVSettingsService.deleteCurrencyExchange as jest.Mock).mockResolvedValue(true);
        render(<CurrencyExchanges />);
        await waitFor(() => {
            const editIcon: HTMLElement = screen.getByTestId('DeleteIcon-1');
            expect(editIcon).toBeInTheDocument();
            fireEvent.click(editIcon);
            const confirmationPopup: HTMLElement = screen.getByText('COMMON.CONFIRMATION');
            expect(confirmationPopup).toBeInTheDocument();
            const confirmButton: HTMLElement = screen.getByText('COMMON.CONFIRM');
            expect(confirmButton).toBeInTheDocument();
            fireEvent.click(confirmButton);
        });
    });

    test('checking wheather delete api failed', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'AUD - Australian Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'CAD - Canadian Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        (PVSettingsService.deleteCurrencyExchange as jest.Mock).mockRejectedValue(false);
        render(<CurrencyExchanges />);
        await waitFor(() => {
            const editIcon: HTMLElement = screen.getByTestId('DeleteIcon-1');
            expect(editIcon).toBeInTheDocument();
            fireEvent.click(editIcon);
            const popup: HTMLElement = screen.getByText('PV_SETTING.CONFIRMATION_FOR_DELETE');
            expect(popup).toBeInTheDocument();
            const confirmButton: HTMLElement = screen.getByText('COMMON.CONFIRM');
            expect(confirmButton).toBeInTheDocument();
            fireEvent.click(confirmButton);
        });
        // await new Promise((r) => setTimeout(r, 1000));
        // await waitFor(() => {
        //     const toastMessage: HTMLElement = screen.getByText(
        //         'PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.DELETE_CURRENCY_EXCHANGE_RECORD'
        //     );
        //     expect(toastMessage).toBeInTheDocument();
        // });
    });

    test('checking wheather edit value in input box onClick', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'AUD - Australian Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'CAD - Canadian Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };

        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        render(<CurrencyExchanges />);

        await waitFor(() => {
            const editIcon: HTMLElement[] = screen.getAllByLabelText('Row Edit');
            expect(editIcon[0]).toBeInTheDocument();
            fireEvent.click(editIcon[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const inputBox: HTMLElement = screen.getByTestId('edittable-inputbox');
            expect(inputBox).toBeInTheDocument();

            fireEvent.change(inputBox, { target: { value: '9.9999' } });
            expect(inputBox).toHaveValue('9.9999');

            const tickIcon: HTMLElement[] = screen.getAllByLabelText('Save Edit');
            expect(tickIcon[0]).toBeInTheDocument();
            fireEvent.click(tickIcon[0]);
        });
    });

    test('checking wheather edit value in dropdown box onClick', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'AUD - Australian Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'CAD - Canadian Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        (PVSettingsService.updateCurrencyExchange as jest.Mock).mockResolvedValue(true);

        render(<CurrencyExchanges />);

        await waitFor(() => {
            const editIcon: HTMLElement[] = screen.getAllByLabelText('Row Edit');
            expect(editIcon[0]).toBeInTheDocument();
            fireEvent.click(editIcon[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const dropdownBox: HTMLElement[] = screen.getAllByTestId('edittable-dropdown');
            expect(dropdownBox[0]).toBeInTheDocument();
            fireEvent.click(dropdownBox[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value: HTMLElement[] = screen.getAllByText('ABC - ABC Currency01');
            fireEvent.click(value[0]);
            // expect(inputBox).toHaveValue('9.9999');
        });
        await waitFor(() => {
            const tickIcon: HTMLElement = screen.getByLabelText('Save Edit');
            expect(tickIcon).toBeInTheDocument();
            fireEvent.click(tickIcon);
        });
    });

    test('checking wheather Edit value find duplicate value', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'ABC - ABC Currency01',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'USD - US Dollar',
                currencyIcon: ''
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        (PVSettingsService.updateCurrencyExchange as jest.Mock).mockResolvedValue(true);

        render(<CurrencyExchanges />);

        await waitFor(() => {
            const editIcon: HTMLElement[] = screen.getAllByLabelText('Row Edit');
            expect(editIcon[0]).toBeInTheDocument();
            fireEvent.click(editIcon[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const dropdownBox: HTMLElement[] = screen.getAllByTestId('edittable-dropdown');
            expect(dropdownBox[0]).toBeInTheDocument();
            fireEvent.click(dropdownBox[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value: HTMLElement[] = screen.getAllByText('ABC - ABC Currency01');
            fireEvent.click(value[0]);
            // expect(inputBox).toHaveValue('9.9999');
        });
        await waitFor(() => {
            const tickIcon: HTMLElement = screen.getByLabelText('Save Edit');
            expect(tickIcon).toBeInTheDocument();
            fireEvent.click(tickIcon);
        });
    });

    test('checking wheather update api failed ', async () => {
        const mockData: CurrencyExchangeModel[] = [
            {
                id: 1,
                fromCurrencyId: 1,
                fromCurrencyName: 'USD - US Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 2,
                toCurrencyName: 'HKD - Hong Kong Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            },
            {
                id: 2,
                fromCurrencyId: 3,
                fromCurrencyName: 'AUD - Australian Dollar',
                fromCurrencyImage: 'string',
                toCurrencyId: 4,
                toCurrencyName: 'CAD - Canadian Dollar',
                toCurrencyImage: 'string',
                rate: '1.21'
            }
        ];
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];

        const mockDataPage: GetCurrencyExchangeApiResponse = {
            data: mockData,
            pageNo: 1,
            totalPages: 1,
            totalRecords: 2
        };

        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockResolvedValue(mockDataPage);
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        (PVSettingsService.updateCurrencyExchange as jest.Mock).mockRejectedValue(false);

        render(<CurrencyExchanges />);

        await waitFor(() => {
            const editIcon: HTMLElement[] = screen.getAllByLabelText('Row Edit');
            expect(editIcon[0]).toBeInTheDocument();
            fireEvent.click(editIcon[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const dropdownBox: HTMLElement[] = screen.getAllByTestId('edittable-dropdown');
            expect(dropdownBox[0]).toBeInTheDocument();
            fireEvent.click(dropdownBox[0]);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value: HTMLElement[] = screen.getAllByText('ABC - ABC Currency01');
            fireEvent.click(value[0]);
            // expect(inputBox).toHaveValue('9.9999');
        });
        await waitFor(() => {
            const tickIcon: HTMLElement = screen.getByLabelText('Save Edit');
            expect(tickIcon).toBeInTheDocument();
            fireEvent.click(tickIcon);
        });
    });

    test('checking wheather able to create the currency exchange', async () => {
        const mockCurrencyList = [
            {
                currencyId: 513,
                currencyName: 'ABC - ABC Currency01',
                currencyIcon: ''
            },
            {
                currencyId: 514,
                currencyName: 'XUA - ADB Unit of Account',
                currencyIcon: ''
            }
        ];
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        (PVSettingsService.getCurrencyList as jest.Mock).mockResolvedValue(mockCurrencyList);
        (PVSettingsService.createCurrencyExchange as jest.Mock).mockResolvedValue(true);
        render(<CurrencyExchanges />);

        await waitFor(() => {
            const createCurrency: HTMLElement = screen.getByText('COMMON.CONFIGURE');
            expect(createCurrency).toBeInTheDocument();
            fireEvent.click(createCurrency);
        });

        await waitFor(() => {
            const title: HTMLElement = screen.getByText('COMMON.CONFIGURE_CURRENCY_EXCHANGE');
            expect(title).toBeInTheDocument();
        });

        await waitFor(() => {
            const fromDropdown: HTMLElement = screen.getByTestId('from-dropdown');
            expect(fromDropdown).toBeInTheDocument();
            fireEvent.click(fromDropdown);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value: HTMLElement = screen.getByText('ABC - ABC Currency01');
            expect(value).toBeInTheDocument();
            fireEvent.click(value);
        });

        await waitFor(() => {
            const toDropdown: HTMLElement = screen.getByTestId('to-dropdown');
            expect(toDropdown).toBeInTheDocument();
            fireEvent.click(toDropdown);
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const value2: HTMLElement = screen.getByText('XUA - ADB Unit of Account');
            expect(value2).toBeInTheDocument();
            fireEvent.click(value2);
        });

        await waitFor(() => {
            const swapButton: HTMLElement = screen.getByTestId('swap-button');
            expect(swapButton).toBeInTheDocument();
            fireEvent.click(swapButton);

            const rateInputBox: HTMLElement = screen.getByPlaceholderText('Rate');
            expect(rateInputBox).toBeInTheDocument();
            fireEvent.change(rateInputBox, { target: { value: '9.9999' } });
        });
        await new Promise((r) => setTimeout(r, 1000));
        await waitFor(() => {
            const saveButton: HTMLElement = screen.getByText('COMMON.CREATE');
            expect(saveButton).toBeInTheDocument();
            fireEvent.click(saveButton);
        });
    });

    test('checking wheather api failes', () => {
        (PVSettingsService.getCurrencyExchangeData as jest.Mock).mockRejectedValue(
            'Failed to get currency exchange data'
        );
        (PVSettingsService.getCurrencyList as jest.Mock).mockRejectedValue(
            'failed to get currency list'
        );

        render(<CurrencyExchanges />);
    });
});
