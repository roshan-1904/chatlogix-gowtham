import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { Dropdown } from 'primereact/dropdown';

import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    editTableProps,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import CreateCurrencyExchange from './createCurrencyExchanges';
import PVSettingsService from '../service/pvsettings.service';
import {
    CurrencyList,
    CurrencyExchangeModel,
    CurrencyExchangeData,
    GetCurrencyExchangeApiResponse
} from '../types/pvsettings.types';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { dropDownStyle } from 'constants/styles.constant';
import { END_POINT } from 'constants/endPoint';
import SettingsService from 'pages/settingsPages/service/settings.service';
import { PAGE_TYPE } from 'pages/settingsPages/constant/settings.constant';
import { Permissions } from 'constants/permissions';
import { formatDate } from 'core/utils/utils';

const CurrencyExchanges: React.FC = () => {
    const { t } = useTranslation();
    const [currencyData, setCurrencyData] = useState<CurrencyExchangeModel[] | undefined>();
    const [currencyList, setcurrencyList] = useState<CurrencyList[]>();
    const [visibility, setVisibility] = useState<boolean>(false);
    const [createAnother, setCreateAnother] = useState(false);
    const [toggleRowData, setToggleRowData] = useState<CurrencyExchangeModel>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        description: ''
    });

    const textEditor = (options: any, isDateFormat?: boolean) => {
        return (
            <div>
                {isDateFormat ? (
                    <span>{formatDate((options?.value ?? '') as string) || '-'}</span>
                ) : (
                    <input
                        data-testid="edittable-inputbox"
                        type="text"
                        value={options.value}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                            const value = e.target.value;
                            if (/^\d{0,6}(\.\d{0,5})?$/.test(value)) {
                                options.editorCallback(value);
                            }
                        }}
                        className="md:w-60 w-full text-sm font-medium input input-bordered h-8 rounded-md border-2 focus-within:outline-none border-neutral-100 focus:border-primary focus-within:border-primary disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200"
                    />
                )}
            </div>
        );
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    // Function for Get Currency Exchange Data using Api
    const getCurrencyExchangeTableData = async () => {
        try {
            const response =
                await PVSettingsService.getCurrencyExchangeData<GetCurrencyExchangeApiResponse>(
                    requestBody
                );
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            setCurrencyData(response.data);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.GET_CURRENCY_EXCHANGE_DATA'),
                ToastType.ERROR
            );
        }
    };

    // Function for Get Currency List using Api
    const getCurrencyList = async () => {
        try {
            const response = await PVSettingsService.getCurrencyList<CurrencyList[]>();
            setcurrencyList(response);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.GET_CURRENCY_DATA'),
                ToastType.ERROR
            );
        }
    };

    // Function for Update Currency Exchange Data using Api
    const SaveCurrencyExchange = async (updatedData: CurrencyExchangeModel) => {
        try {
            updatedData.fromCurrencyImage = '';
            updatedData.toCurrencyImage = '';
            const response =
                await PVSettingsService.createCurrencyExchange<CurrencyExchangeModel>(updatedData);
            if (response) {
                showToastMessage(
                    t(
                        'PV_SETTING.CURRENCY_EXCHANGES.SUCCESS_MESSAGE.CREATE_CURRENCY_EXCHANGE_RECORD'
                    ),
                    ToastType.SUCCESS
                );
                getCurrencyExchangeTableData();
            }
        } catch (error: any) {
            if (
                error?.response?.data?.Message ===
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.DUPLICATE_CURRENCY_EXCHANGE_RECORD')
            ) {
                showToastMessage(error?.response?.data?.Message as string, ToastType.ERROR);
            } else {
                showToastMessage(
                    t(
                        'PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.CREATE_CURRENCY_EXCHANGE_RECORD'
                    ),
                    ToastType.ERROR
                );
            }
        }
    };

    // Function for Update Currency Exchange Data using Api
    const updateCurrencyExchange = async (updatedData: CurrencyExchangeModel) => {
        try {
            updatedData.fromCurrencyImage = '';
            updatedData.toCurrencyImage = '';
            const response =
                await PVSettingsService.updateCurrencyExchange<CurrencyExchangeModel>(updatedData);
            if (response) {
                showToastMessage(
                    t(
                        'PV_SETTING.CURRENCY_EXCHANGES.SUCCESS_MESSAGE.UPDATE_CURRENCY_EXCHANGE_RECORD'
                    ),
                    ToastType.SUCCESS
                );
                getCurrencyExchangeTableData();
            }
        } catch (error: any) {
            if (
                error?.response?.data?.Message ===
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.DUPLICATE_CURRENCY_EXCHANGE_RECORD')
            ) {
                showToastMessage(error?.response?.data?.Message as string, ToastType.ERROR);
            } else {
                showToastMessage(
                    t(
                        'PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.UPDATE_CURRENCY_EXCHANGE_RECORD'
                    ),
                    ToastType.ERROR
                );
            }
        }
    };

    // Function for Delete Currency Exchange Data using Api
    const deleteCurrencyExchange = async (id: number) => {
        try {
            const response = await PVSettingsService.deleteCurrencyExchange<number>(id);
            if (response) {
                showToastMessage(
                    t(
                        'PV_SETTING.CURRENCY_EXCHANGES.SUCCESS_MESSAGE.DELETE_CURRENCY_EXCHANGE_RECORD'
                    ),
                    ToastType.SUCCESS
                );
                getCurrencyExchangeTableData();
            }
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.DELETE_CURRENCY_EXCHANGE_RECORD'),
                ToastType.ERROR
            );
        }
    };

    useEffect(() => {
        getCurrencyExchangeTableData();
        getCurrencyList();
    }, []);

    useEffect(() => {
        if (requestBody) getCurrencyExchangeTableData();
    }, [requestBody]);

    const selectedCountryTemplate = (option: CurrencyList) => {
        if (option) {
            return (
                <div className="flex items-center">
                    <div className="avatar">
                        <div className="h-6 rounded-full border">
                            <div
                                className={`h-full w-full bg-no-repeat bg-center`}
                                style={{
                                    backgroundImage:
                                        'url(/images/country-flags/' + option?.currencyIcon + ')',
                                    backgroundSize: '150%'
                                }}></div>
                        </div>
                    </div>
                    &nbsp;&nbsp;
                    <div>{option.currencyName}</div>
                </div>
            );
        }
    };

    const countryOptionTemplate = (option: CurrencyList) => {
        return (
            <div className="flex items-center">
                <div className="avatar">
                    <div className="h-6 rounded-full border">
                        <div
                            className={`h-full w-full bg-no-repeat bg-center`}
                            style={{
                                backgroundImage:
                                    'url(/images/country-flags/' + option?.currencyIcon + ')',
                                backgroundSize: '150%'
                            }}></div>
                    </div>
                </div>
                &nbsp;&nbsp;
                <div>{option.currencyName}</div>
            </div>
        );
    };

    const dropdownEditor = (options: any) => {
        return (
            <Dropdown
                data-testid="edittable-dropdown"
                value={options.value}
                filter={true}
                onChange={(e) => options.editorCallback(e.value)}
                options={currencyList}
                optionLabel="currencyName"
                optionValue="currencyName"
                className="w-full h-8"
                valueTemplate={selectedCountryTemplate}
                itemTemplate={countryOptionTemplate}
                pt={{
                    ...dropDownStyle,
                    root: {
                        className:
                            'hover:border-primary font-medium border-2 border-neutral-100 md:w-full w-full h-8'
                    },
                    item: { className: 'hover:bg-primary-50 border-b-2 mx-2' },
                    input: { className: 'p-0.5' }
                }}
            />
        );
    };

    // TODO : If edit functionality is needed in future then uncomment below code
    // const emptyTemplate = (options: any) => {
    //     return options.value;
    // };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'fromCurrencyName',
            header: t('COMMON.FROM'),
            sortable: true,
            filter: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'fromCurrencyImage',
            columnNumber: 0,
            visibility: true,
            className: 'w-1/4',
            onEdit: dropdownEditor
        },
        {
            field: 'toCurrencyName',
            header: t('COMMON.TO'),
            sortable: true,
            filter: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'toCurrencyImage',
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4',
            onEdit: dropdownEditor
        },
        {
            field: 'rate',
            header: t('COMMON.RATE'),
            sortable: true,
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true,
            className: 'w-2/5',
            onEdit: textEditor
        },
        {
            field: 'effectiveStartDate',
            header: t('COMMON.UPDATED_AT'),
            sortable: true,
            filter: true,
            frozen: false,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 3,
            visibility: true,
            className: 'w-1/4',
            onEdit: (e: any) => textEditor(e, true)
        }
        // TODO : If edit functionality is needed in future then uncomment below code
        // {
        //     field: '',
        //     header: '',
        //     frozen: true,
        //     filterType: FilterType.Text,
        //     valueType: ValueType.Edit,
        //     columnNumber: 4,
        //     visibility: true,
        //     editRow: true,
        //     className: 'w-20'
        // },
        // {
        //     field: 'action',
        //     header: t('COMMON.ACTION'),
        //     frozen: true,
        //     filterType: FilterType.Text,
        //     valueType: ValueType.Edit,
        //     columnNumber: 5,
        //     visibility: true,
        //     className: 'w-20',
        //     onEdit: emptyTemplate
        // }
    ];

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };

    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };

    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    const buttonChildren = () => {
        if (AuthStore.hasPermission(Permissions.CREATE_IP_VAULT_SETTINGS)) {
            return (
                <button
                    data-testid="add-currency-exchange"
                    onClick={openModal}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                    <i className="pi pi-plus-circle"></i>
                    {t('COMMON.CONFIGURE')}
                </button>
            );
        } else {
            return <></>;
        }
    };

    const IsDataChanged = (newData: CurrencyExchangeModel) => {
        const existingItem = currencyData?.find((item) => item.id === newData.id);
        if (
            existingItem?.fromCurrencyName !== newData.fromCurrencyName ||
            existingItem?.toCurrencyName !== newData.toCurrencyName ||
            existingItem?.rate !== newData.rate
        ) {
            return true;
        } else {
            return false;
        }
    };

    const onRowEditComplete = (e: any) => {
        const newData: CurrencyExchangeModel = e.newData;
        if (IsDataChanged(newData)) {
            if (newData.fromCurrencyName === newData.toCurrencyName) {
                const toastMessage = t(
                    'PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.FROM_AND_TO_CURRENCY_CANNOT_BE_THE_SAME'
                );

                showToastMessage(toastMessage, ToastType.ERROR);
            } else if (newData.rate === '') {
                const toastMessage = t(
                    'PV_SETTING.CURRENCY_EXCHANGES.ERROR_MESSAGE.RATE_FIELD_CANNOT_BE_EMPTY'
                );

                showToastMessage(toastMessage, ToastType.ERROR);
            } else {
                updateCurrencyExchange(newData);
            }
        }
    };

    const edit: editTableProps = {
        editType: 'row',
        rowEditComplete: onRowEditComplete,
        isRowEdit: true
    };

    const openModal = () => {
        setVisibility(true);
    };

    const closeModal = () => {
        setVisibility(false);
    };

    const onSubmit = (data: CurrencyExchangeData) => {
        const saveData: CurrencyExchangeModel = {
            id: 0,
            fromCurrencyId: data.from.currencyId,
            fromCurrencyName: data.from.currencyName,
            fromCurrencyImage: data.from.currencyIcon,
            toCurrencyId: data.to.currencyId,
            toCurrencyName: data.to.currencyName,
            toCurrencyImage: data.to.currencyIcon,
            rate: data.rate
        };
        SaveCurrencyExchange(saveData).finally(() => {
            if (createAnother) {
                formStatusStore.clearFormData();
            } else {
                closeModal();
            }
        });
    };
    const tableDefinition: DataTableDefinition = {
        title: 'Currency Exchange Rates',
        filters: {},
        reOrderableColumns: false,
        tableType: TableTypes.CURRENCY_EXCHANGE_RATES,
        emptyMessage: '',
        localStorageKey: '',
        buttonChildren: buttonChildren(),
        tableCustomStyle: 'py-2',
        editTable: edit,
        columns: columnSchema,
        //  AuthStore.hasPermission(Permissions.EDIT_IP_VAULT_SETTINGS)
        //     ? columnSchema
        //     : columnSchema.filter((column) => [0, 1, 2, 3].includes(column.columnNumber)),
        hideColumnSelector: true
    };

    const handleDeleteRecord = (data: CurrencyExchangeModel) => {
        setToggleRowData(data);

        setShowPopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t('PV_SETTING.CONFIRMATION_FOR_DELETE')
        });
    };

    const handleConfirm = () => {
        if (toggleRowData) {
            deleteCurrencyExchange(toggleRowData.id);
            setShowPopup({ ...showPopup, visible: false });
        }
    };

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    function exportData() {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.CURRENCY_EXCHANGES}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Currency Exchanges.xlsx');
    }

    return (
        <div className="tableCurrency" data-testid="CurrencyExchanges-Accordion">
            {!visibility && showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.CONFIRM')}
                    rejectLabel={t('COMMON.CANCEL')}
                    popupID="currencyExchange"
                />
            )}
            {visibility && (
                <CreateCurrencyExchange
                    closeModal={closeModal}
                    onChangeCreateAnother={setCreateAnother}
                    onSubmit={onSubmit}
                />
            )}
            <DataTableComponent
                tableData={currencyData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                deleteRecord={handleDeleteRecord}
                toggleRowData={() => {}}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
};

export default CurrencyExchanges;
