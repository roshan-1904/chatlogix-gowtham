import HttpService from 'core/interceptor/api.handler';
import PVSettingsService from './pvsettings.service';
import { FeeResponseType, IPRatesResponseType } from '../types/pvsettings.types';

jest.mock('core/interceptor/api.handler');

describe('PVSettingsService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getCurrencyExchangeData', () => {
        const requestBody = {
            searchModels: [],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        };
        it('should fetch getCompanyData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.getCurrencyExchangeData(requestBody);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getCurrencyExchangeData(requestBody)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getCurrencyList', () => {
        it('should fetch getContactUserData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getCurrencyList();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getCurrencyList()).rejects.toThrow(mockError);
        });
    });

    describe('createCurrencyExchange', () => {
        const exchangemodal = {
            id: 1,
            fromCurrencyId: 1,
            fromCurrencyName: 'test 1',
            fromCurrencyImage: '.img',
            toCurrencyId: 1,
            toCurrencyName: 'USD',
            toCurrencyImage: '.img',
            rate: '1'
        };
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.createCurrencyExchange(exchangemodal);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.createCurrencyExchange(exchangemodal)).rejects.toThrow(
                mockError
            );
        });
    });
    describe('deleteCurrencyExchange', () => {
        const id = 1;
        it('should fetch deleteCurrencyExchange successfully', async () => {
            jest.spyOn(HttpService.prototype, 'delete').mockResolvedValue([]);
            const result = await PVSettingsService.deleteCurrencyExchange(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'delete').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.deleteCurrencyExchange(id)).rejects.toThrow(mockError);
        });
    });

    describe('getAddressInformation', () => {
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getAddressInformation();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getAddressInformation()).rejects.toThrow(mockError);
        });
    });

    describe('updateAddressInformation', () => {
        const addressInformationModal = {
            id: 1,
            address1: 'test',
            address2: 'test1',
            city: 'colombo',
            state: null,
            phoneNumber: '123456789',
            countryCode: '',
            webSiteUrl: 'www.test.com',
            countryId: 1,
            stateId: 1,
            countryName: null,
            zip: '123'
        };
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'update').mockResolvedValue([]);
            const result =
                await PVSettingsService.updateAddressInformation(addressInformationModal);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'update').mockRejectedValueOnce(mockError);
            await expect(
                PVSettingsService.updateAddressInformation(addressInformationModal)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getSourceLanguages', () => {
        it('should fetch getSourceLanguages successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getSourceLanguages();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getSourceLanguages()).rejects.toThrow(mockError);
        });
    });

    describe('getAllLanguages', () => {
        it('should fetch getAllLanguages successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.getAllLanguages();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getAllLanguages()).rejects.toThrow(mockError);
        });
    });

    describe('getRequestCurrencyData', () => {
        it('should fetch getRequestCurrencyData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getRequestCurrencyData();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getRequestCurrencyData()).rejects.toThrow(mockError);
        });
    });

    describe('getIPRequestData', () => {
        const reqType: IPRatesResponseType = {
            patentServiceId: 1,
            sourceLanguageId: 1,
            requestCurrencyId: 2,
            targetLanguageId: 3,
            filterRequestModel: {
                searchModels: [
                    {
                        propertyName: 'name',
                        value: 'test'
                    }
                ],
                sorting: {
                    propertyName: 'name',
                    value: 'test'
                },
                pageNo: 1,
                pageCount: 10
            }
        };
        it('should fetch getIPRequestData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.getIPRequestData(reqType);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getIPRequestData(reqType)).rejects.toThrow(mockError);
        });
    });

    describe('validateFormula', () => {
        const formula = 'test';
        it('should fetch validateFormula successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.validateFormula(formula);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.validateFormula(formula)).rejects.toThrow(mockError);
        });
    });

    describe('updateFee', () => {
        const feeResponseType: FeeResponseType = {
            id: 1,
            translationFeeModel: {
                feeType: 'test',
                unitTypeId: 1,
                formula: 'test',
                fee: 1
            },
            officialFeeModel: {
                feeType: 'test',
                unitTypeId: 1,
                formula: 'test',
                fee: 1
            },
            agencyFeeModel: {
                feeType: 'test',
                unitTypeId: 1,
                formula: 'test',
                fee: 1
            }
        };
        it('should fetch updateFee successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue([]);
            const result = await PVSettingsService.updateFee(feeResponseType);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.updateFee(feeResponseType)).rejects.toThrow(mockError);
        });
    });

    describe('updateIpRateDetail', () => {
        const data = {
            id: 1,
            isDirectTranslation: true,
            isEngDescriptionTranslationRequired: true,
            engIndirectTranslationRate: 1,
            translationRate: 1
        };
        it('should fetch updateIpRateDetail successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue([]);
            const result = await PVSettingsService.updateIpRateDetail(data);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.updateIpRateDetail(data)).rejects.toThrow(mockError);
        });
    });

    describe('getUnitTypes', () => {
        it('should fetch getUnitTypes successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getUnitTypes();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getUnitTypes()).rejects.toThrow(mockError);
        });
    });

    describe('getFormulaFields', () => {
        it('should fetch getFormulaFields successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getFormulaFields();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getFormulaFields()).rejects.toThrow(mockError);
        });
    });

    describe('getTargetLanguage', () => {
        it('should fetch getTargetLanguage successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getTargetLanguage();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getTargetLanguage()).rejects.toThrow(mockError);
        });
    });

    describe('getTargetLanguage', () => {
        it('should fetch getTargetLanguage successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getTargetLanguage();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getTargetLanguage()).rejects.toThrow(mockError);
        });
    });

    describe('saveVendorTranslations', () => {
        const vendorPayload = {
            id: 1,
            sourceLanguageId: 1,
            sourceLanguageName: 'test',
            targetLanguageId: 1,
            targetLanguageName: 'test',
            targetLanguageIds: [1],
            currencyId: 1,
            currencyCode: 'USD',
            unitId: 1,
            unitName: 'test',
            translationRate: 1,
            enableBreakdown: true,
            breakdowns: {},
            abilityId: 1
        };
        it('should fetch saveVendorTranslations successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.saveVendorTranslations(vendorPayload);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.saveVendorTranslations(vendorPayload)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('deleteCompanyTranslations', () => {
        const id = 1;
        it('should fetch getTargetLanguage successfully', async () => {
            jest.spyOn(HttpService.prototype, 'delete').mockResolvedValue([]);
            const result = await PVSettingsService.deleteCompanyTranslations(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'delete').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.deleteCompanyTranslations(id)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('deleteVendorTranslations', () => {
        const id = 1;
        it('should fetch getTargetLanguage successfully', async () => {
            jest.spyOn(HttpService.prototype, 'delete').mockResolvedValue([]);
            const result = await PVSettingsService.deleteVendorTranslations(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'delete').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.deleteVendorTranslations(id)).rejects.toThrow(mockError);
        });
    });

    describe('deleteVendorTranslations', () => {
        const id = 1;
        it('should fetch getTargetLanguage successfully', async () => {
            jest.spyOn(HttpService.prototype, 'delete').mockResolvedValue([]);
            const result = await PVSettingsService.deleteVendorTranslations(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'delete').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.deleteVendorTranslations(id)).rejects.toThrow(mockError);
        });
    });

    describe('getCompanyLevelTranslationsData', () => {
        const reqType: IPRatesResponseType = {
            patentServiceId: 1,
            sourceLanguageId: 1,
            requestCurrencyId: 2,
            targetLanguageId: 3,
            filterRequestModel: {
                searchModels: [
                    {
                        propertyName: 'name',
                        value: 'test'
                    }
                ],
                sorting: {
                    propertyName: 'name',
                    value: 'test'
                },
                pageNo: 1,
                pageCount: 10
            }
        };
        it('should fetch getCompanyLevelTranslationsData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.getCompanyLevelTranslationsData(reqType);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                PVSettingsService.getCompanyLevelTranslationsData(reqType)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getBreakdowns', () => {
        it('should fetch getCompanyLevelTranslationsData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getBreakdowns();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getBreakdowns()).rejects.toThrow(mockError);
        });
    });

    describe('getVendorCurrency', () => {
        it('should fetch getCompanyLevelTranslationsData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await PVSettingsService.getVendorCurrency();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(PVSettingsService.getVendorCurrency()).rejects.toThrow(mockError);
        });
    });

    describe('resetToDefault', () => {
        const id = 1;
        const serviceId = 1;
        const sourceLanguageId = 1;
        const requestCurrencyId = 1;
        it('should fetch getCompanyLevelTranslationsData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await PVSettingsService.resetToDefault(
                id,
                serviceId,
                sourceLanguageId,
                requestCurrencyId
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                PVSettingsService.resetToDefault(id, serviceId, sourceLanguageId, requestCurrencyId)
            ).rejects.toThrow(mockError);
        });
    });
});
