import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import {
    AddressInformationModel,
    UpdateRequestBody,
    CurrencyExchangeModel,
    IPRatesResponseType,
    FeeResponseType,
    directFeeRequestBody,
    CreateCompanyPayloadType,
    CreateVendorPayloadType,
    editCompanylevelTranslations,
    TranslationFormulaUpdate,
    companyDetailRateRequestBody
} from '../types/pvsettings.types';

// Define the base URL from environment variable
const baseURL = process.env.REACT_APP_API_BASE_URL;
const _httpService = new HttpService();

/**
 * Fetch dynamic form information based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */
const getCurrencyExchangeData = async <T>(requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_CURRENCY_EXCHANGE_DATA}`;
    try {
        const response = await _httpService.post<T, RequestBody>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching dynamic form information:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getCurrencyList = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_CURRENCY_LIST}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch table data based on the given page type and request body.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @param {RequestBody} requestBody - The request body.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
const createCurrencyExchange = async <T>(requestBody: CurrencyExchangeModel): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.CREATE_CURRENCY_EXCHANGE}`;

    try {
        const response = await _httpService.post<T, CurrencyExchangeModel>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Updates the status of an item.
 * @param {PAGE_TYPE} pageType - The type of page for the API request.
 * @param {number} id - The ID of the item.
 * @param {boolean} isActive - The new status of the item.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */
const updateCurrencyExchange = async <T>(requestBody: UpdateRequestBody): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.UPDATE_CURRENCY_EXCHANGE}`;

    try {
        const response = await _httpService.update<T, UpdateRequestBody>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

const deleteCurrencyExchange = async <T>(id: number): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.DELETE_CURRENCY_EXCHANGE_RECORD}/${id}`;

    try {
        const response = await _httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @param {PAGE_TYPE} pageType - The type of the page.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getAddressInformation = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_ADDRESS_INFORMATION}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Updates the status of an item.
 * @param {PAGE_TYPE} pageType - The type of page for the API request.
 * @param {number} id - The ID of the item.
 * @param {boolean} isActive - The new status of the item.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */
const updateAddressInformation = async <T>(requestBody: AddressInformationModel): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.UPDATE_ADDRESS_INFORMATION}`;
    try {
        const response = await _httpService.update<T, AddressInformationModel>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

/**
 * Get the source languages filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getSourceLanguages = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_SOURCE_LANGUAGES}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching source language', error);
        throw error;
    }
};

/**
 * Get the source languages filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getAllLanguages = async <T>(
    requestBodySorting: {
        propertyName: string;
        value: string;
    } | null = null,
    hideLoader?: boolean
): Promise<T> => {
    interface RequestBodyType {
        pageNo: number;
        pageCount: number;
        sorting?: {
            propertyName: string;
            value: string;
        };
    }

    const apiUrl = `${baseURL}/setting/Languages/get/all`;

    const defaultRequestBody = {
        pageNo: 1,
        pageCount: 200,
        ...(requestBodySorting && { sorting: { ...requestBodySorting } })
    };

    try {
        const response = await _httpService.post<T, RequestBodyType>(apiUrl, defaultRequestBody, {
            data: { hideLoader: hideLoader || false }
        });
        return response;
    } catch (error) {
        console.error('Error fetching source language', error);
        throw error;
    }
};
/**
 * Get the request currencies filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getRequestCurrencyData = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.SUMMARY.GET_CURRENCY}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching request currency data:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {IPRatesResponseType} requestBody - request body for post API type
 */
const getIPRequestData = async <T>(requestBody: IPRatesResponseType): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_IP_RATES_LIST}`;
    try {
        const response = await _httpService.post<T, IPRatesResponseType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

const validateFormula = async <T>(formula: string): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.VALIDATE_FORMULA}?formula=${encodeURIComponent(formula)}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error validating formula:', error);
        throw error;
    }
};

const updateFee = async <T>(requestBody: FeeResponseType): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.UPDATE_FEE}`;
    try {
        const response = await _httpService.patch<T, FeeResponseType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error updating fee details:', error);
        throw error;
    }
};

const updateIpRateDetail = async <T>(requestBody: directFeeRequestBody): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.IP_RATE_DETAIL}`;
    try {
        const response = await _httpService.patch<T, directFeeRequestBody>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

const updateCompanyRateDetail = async <T>(
    requestBody: companyDetailRateRequestBody
): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.COMPANY_IP_RATE_DETAIL}`;
    try {
        const response = await _httpService.patch<T, companyDetailRateRequestBody>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error fetching company IP rates listing data:', error);
        throw error;
    }
};

const getUnitTypes = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.GET_IP_UNITS}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching units:', error);
        throw error;
    }
};

const getFormulaFields = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.GET_FORMULA_FIELDS}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching units:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {IPRatesResponseType} requestBody - request body for post API type
 */
const getCompanyTranslationsData = async <T>(
    requestBody: Omit<IPRatesResponseType, 'patentServiceId'>,
    moduleName: string
): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${moduleName === 'companytranslations' ? END_POINT.PVSETTINGS.GET_COMPANY_TRANSLATIONS_LIST : END_POINT.PVSETTINGS.GET_VENDOR_TRANSLATIONS_LIST}`;
    try {
        const response = await _httpService.post<T, Omit<IPRatesResponseType, 'patentServiceId'>>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

/**
 * Get the request currencies filter dropdown data.
 * @returns {Promise<T>} A promise that resolves with the API response data.
 */

const getTargetLanguage = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.GET_USER_LANGUAGE}`;

    try {
        const response = await _httpService.get<T>(apiUrl, {
            data: { hideLoader: true }
        });
        return response;
    } catch (error) {
        console.error('Error fetching request currency data:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {CreateCompanyPayloadType} requestBody - request body for post API type
 */

const saveCompanyTranslations = async <T>(
    requestBody: CreateCompanyPayloadType,
    company: boolean
): Promise<T> => {
    const apiUrl = `${baseURL}${company ? END_POINT.COMPANIES.BASE : END_POINT.PV_SETTINGS_END_POINT}${company ? END_POINT.COMPANIES.SAVE_COMPANY_IP_RATES : END_POINT.PVSETTINGS.SAVE_COMPANY_TRANSLATIONS}`;
    try {
        const response = await _httpService.post<T, CreateCompanyPayloadType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error saving company translations data', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {CreateVendorPayloadType} requestBody - request body for post API type
 */

const saveVendorTranslations = async <T>(requestBody: CreateVendorPayloadType): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.SAVE_VENDOR_TRANSLATIONS}`;
    try {
        const response = await _httpService.post<T, CreateVendorPayloadType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error saving company translations data', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */

const deleteCompanyTranslations = async <T>(id: number): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.DELETE_COMPANY_TRANSLATIONS}/${id}`;
    try {
        const response = await _httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error saving company translations data', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 */

const deleteVendorTranslations = async <T>(id: number): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.DELETE_VENDOR_TRANSLATIONS}/${id}`;
    try {
        const response = await _httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error saving company translations data', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {IPRatesResponseType} requestBody - request body for post API type
 */
const getCompanyLevelTranslationsData = async <T>(requestBody: IPRatesResponseType): Promise<T> => {
    const apiUrl = `${baseURL}/company${END_POINT.PVSETTINGS.GET_COMPANY_LEVEL_TRANSLATION_DATA}`;
    try {
        const response = await _httpService.post<T, IPRatesResponseType>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching IP rates listing data:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getBreakdowns = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PV_SETTINGS_END_POINT}${END_POINT.PVSETTINGS.GET_PV_BREAKDOWNS}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
const getVendorCurrency = async <T>(): Promise<T> => {
    const apiUrl = `${baseURL}/${END_POINT.USERS.VENDOR_CURRENCIES}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch dynamic rates listing data.
 * @returns {Promise<T>} A promise resolving to the dynamic form information.
 * * @param {editCompanylevelTranslations} requestBody - request body for post API type
 */

const saveCompanyLevelTranslations = async <T>(
    requestBody: editCompanylevelTranslations
): Promise<T> => {
    const apiUrl = `${baseURL}/${END_POINT.COMPANIES.BASE}${END_POINT.COMPANIES.SAVE_COMPANY_IP_RATES}`;
    try {
        const response = await _httpService.patch<T, editCompanylevelTranslations>(
            apiUrl,
            requestBody
        );
        return response;
    } catch (error) {
        console.error('Error saving company translations data', error);
        throw error;
    }
};

const resetToDefault = async <T>(
    id: number,
    patentServiceId: number,
    soruceLanguageId: number,
    requestCurrencyId: number
): Promise<T> => {
    const apiUrl = `${baseURL}/${END_POINT.COMPANIES.BASE}${END_POINT.PVSETTINGS.RESET_TO_DEFAULT}/${id}?patentServiceId=${patentServiceId}&soruceLanguageId=${soruceLanguageId}&requestCurrencyId=${requestCurrencyId}`;
    try {
        const response = await _httpService.post<T, number>(apiUrl, id);
        return response;
    } catch (error) {
        console.error('Error updating fee details:', error);
        throw error;
    }
};

const updateEnglishTranslationFormula = async <T>(
    requestBody: TranslationFormulaUpdate,
    isCompany?: boolean,
    companyId?: number
): Promise<T> => {
    const updatedRequestBody = isCompany && companyId ? { ...requestBody, companyId } : requestBody;
    const {
        PV_SETTINGS_END_POINT,
        COMPANIES: { BASE },
        PVSETTINGS: { UPDATE_ENGLISH_TRANSLATION_RATE, UPDATE_COMPANY_ENGLISH_TRANSLATION_RATE }
    } = END_POINT;
    const apiUrl = `${baseURL}${isCompany ? '/' + BASE : PV_SETTINGS_END_POINT}${isCompany ? UPDATE_COMPANY_ENGLISH_TRANSLATION_RATE : UPDATE_ENGLISH_TRANSLATION_RATE}`;
    try {
        const response = await _httpService.patch<T, TranslationFormulaUpdate>(
            apiUrl,
            updatedRequestBody
        );
        return response;
    } catch (error) {
        console.error('Error updating fee details:', error);
        throw error;
    }
};

const getGroupedCountries = async <T>(patentCategoryId: number, groupId: number): Promise<T> => {
    const apiUrl = `${baseURL}${END_POINT.PVSETTINGS.GET_PV_GROUPED_COUNTRIES}/${patentCategoryId}/${groupId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching grouped countries:', error);
        throw error;
    }
};

// Export an object containing all the services
const PVSettingsService = {
    getCurrencyExchangeData,
    getCurrencyList,
    updateCurrencyExchange,
    createCurrencyExchange,
    deleteCurrencyExchange,
    getAddressInformation,
    updateAddressInformation,
    getSourceLanguages,
    getAllLanguages,
    getRequestCurrencyData,
    getIPRequestData,
    validateFormula,
    updateFee,
    updateIpRateDetail,
    updateCompanyRateDetail,
    getUnitTypes,
    getFormulaFields,
    getCompanyTranslationsData,
    getTargetLanguage,
    saveCompanyTranslations,
    saveVendorTranslations,
    deleteCompanyTranslations,
    deleteVendorTranslations,
    getCompanyLevelTranslationsData,
    getBreakdowns,
    getVendorCurrency,
    saveCompanyLevelTranslations,
    resetToDefault,
    updateEnglishTranslationFormula,
    getGroupedCountries
};

export default PVSettingsService;
