import { Observer, Subject } from 'rxjs';
import { RatesListingResponseType } from '../../types/pvsettings.types';

export const initialPvSettingState = {
    ipRateDetailList: [],
    companyTranslationRatesList: [],
    companyRateDetailList: [],
    companyLevelTranslationRatesList: [],
    pageNo: 1,
    totalCount: 0,
    descriptionTranslationFormulaModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    },
    totalPages: 0,
    currencyData: {
        currencyCode: '',
        currencyId: 0,
        currencyName: '',
        currencySymbol: ''
    },
    agencyFeeInfo: 0
} as RatesListingResponseType;

let state: typeof initialPvSettingState = initialPvSettingState;
const subject = new Subject<typeof initialPvSettingState>();
export const pvSettingStore = {
    init() {
        state = { ...state };
        subject.next(state);
    },
    subscribe: (
        setState:
            | Partial<Observer<RatesListingResponseType>>
            | ((value: RatesListingResponseType) => void)
            | undefined
    ) => subject.subscribe(setState),
    updatePage(field?: any, value?: any, allData?: any) {
        if (allData) {
            state = {
                ...allData
            };
            subject.next(state);
            return;
        }
        state = {
            ...state,
            [field]: value
        };
        subject.next(state);
    },
    getData() {
        return state;
    },
    resetStepperModuleStore() {
        state = initialPvSettingState;
        subject.next(state);
    },
    initialState: initialPvSettingState
};
