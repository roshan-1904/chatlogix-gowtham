import { useState } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { filterDropDownStyle } from 'constants/styles.constant';
import { useTranslation } from 'react-i18next';
import { dropdownValuesType } from '../../types/pvsettings.types';

export interface FilterDropdownProps {
    sourceLanguagesData: dropdownValuesType[];
    requestCurrencyData: dropdownValuesType[];
    onChange: any;
    targetLanguageData: dropdownValuesType[];
    isVendorTranslation?: boolean;
}

export default function UnSelectedFilterDropdown({
    sourceLanguagesData,
    requestCurrencyData,
    targetLanguageData,
    onChange,
    isVendorTranslation = false
}: Readonly<FilterDropdownProps>) {
    const [filteredSourceLanguage, setFilteredSourceLanguage] = useState<number | null>(null);
    const [filteredReqCurrencyData, setFilteredReqCurrencyData] = useState<number | null>(null);
    const [filteredtargetLanguageData, setFilteredTargetLanguageData] = useState<number | null>(
        null
    );
    const { t } = useTranslation();
    return (
        <div className="flex justify-start flex-wrap mx-0 w-full">
            <div className="mr-2">
                <Dropdown
                    filter={true}
                    multiple
                    resetFilterOnHide
                    onChange={(e) => {
                        setFilteredSourceLanguage(e.value as number);
                        onChange({ sourceLanguage: e.value });
                    }}
                    data-testid="source-language-dropdown"
                    value={filteredSourceLanguage}
                    clearIcon={'pi pi-times'}
                    placeholder={t('COMPANY_DETAILS.SOURCE_LANGUAGE')}
                    filterPlaceholder={t('COMMON.TYPE_SEARCH')}
                    valueTemplate={`${t('COMPANY_DETAILS.SOURCE_LANGUAGE')}: ${sourceLanguagesData.filter((e) => e.value === filteredSourceLanguage)?.[0]?.label ?? ''}`}
                    pt={{
                        ...filterDropDownStyle,
                        root: {
                            className:
                                filterDropDownStyle.root.className +
                                ' items-center' +
                                (filteredSourceLanguage ? ' bg-lightBlue' : '')
                        },
                        input: {
                            className:
                                filterDropDownStyle.input.className + 'text-black  items-center'
                        },
                        trigger: {
                            className: 'mt-0.5 w-9'
                        }
                    }}
                    optionValue="value"
                    optionLabel="label"
                    showClear
                    options={sourceLanguagesData ?? []}
                />
            </div>
            <div className="mr-2">
                <Dropdown
                    filter={true}
                    multiple
                    resetFilterOnHide
                    onChange={(e) => {
                        setFilteredReqCurrencyData(e.value as number);
                        onChange({ requestCurrency: e.value });
                    }}
                    data-testid={`${isVendorTranslation ? 'vendor-currency' : 'request-currency'}-dropdown`}
                    value={filteredReqCurrencyData}
                    clearIcon={'pi pi-times'}
                    placeholder={t(
                        `PV_SETTING.RATES.${isVendorTranslation ? 'VENDOR_CURRENCY' : 'REQUEST_CURRENCY'}`
                    )}
                    filterPlaceholder={t('COMMON.TYPE_SEARCH')}
                    valueTemplate={`${t(`PV_SETTING.RATES.${isVendorTranslation ? 'VENDOR_CURRENCY' : 'REQUEST_CURRENCY'}`)}: ${requestCurrencyData.filter((e) => e.value === filteredReqCurrencyData)?.[0]?.label ?? ''}`}
                    pt={{
                        ...filterDropDownStyle,
                        root: {
                            className:
                                filterDropDownStyle.root.className +
                                ' items-center' +
                                (filteredReqCurrencyData ? ' bg-lightBlue' : '')
                        },
                        input: {
                            className:
                                filterDropDownStyle.input.className + ' text-black  items-center'
                        },
                        trigger: {
                            className: 'mt-0.5 w-9'
                        }
                    }}
                    optionValue="value"
                    optionLabel="label"
                    showClear
                    options={requestCurrencyData ?? []}
                />
            </div>
            <div>
                <Dropdown
                    filter={true}
                    multiple
                    resetFilterOnHide
                    onChange={(e) => {
                        setFilteredTargetLanguageData(e.value as number);
                        onChange({ targetLanguage: e.value });
                    }}
                    data-testid="target-language-dropdown"
                    value={filteredtargetLanguageData}
                    clearIcon={'pi pi-times'}
                    placeholder={t('PV_SETTING.RATES.TARGET_LANGUAGE')}
                    filterPlaceholder={t('COMMON.TYPE_SEARCH')}
                    valueTemplate={`${t('PV_SETTING.RATES.TARGET_LANGUAGE')}: ${targetLanguageData.filter((e) => e.value === filteredtargetLanguageData)?.[0]?.label ?? ''}`}
                    pt={{
                        ...filterDropDownStyle,
                        root: {
                            className:
                                filterDropDownStyle.root.className +
                                'items-center' +
                                (filteredtargetLanguageData ? ' bg-lightBlue' : '')
                        },
                        input: {
                            className:
                                filterDropDownStyle.input.className + ' text-black  items-center'
                        },
                        trigger: {
                            className: 'mt-0.5 w-9'
                        }
                    }}
                    optionValue="value"
                    optionLabel="label"
                    showClear
                    options={targetLanguageData ?? []}
                />
            </div>
        </div>
    );
}
