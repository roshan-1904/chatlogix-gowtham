import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { EditFormulaPopup } from './addCountriesPopup';
import { useTranslation } from 'react-i18next';
import AdditionalInfoFormBuilderData from '../json/addCountry.json';
import { DataValue } from 'shared/dataTable/types/dataTable.types';
import { unitOptions } from '../../types/pvsettings.types';
import PVSettingsService from '../../service/pvsettings.service';
import companiesService from 'pages/companies/service/companies.service';
import NotificationStore from 'core/store/notificationStore/notificationStore';
import utils from 'core/utils/utils';

jest.mock('react-i18next', () => ({
    useTranslation: jest.fn()
}));

jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div>Form Component</div>)
}));

jest.mock('core/interceptor/api.handler', () => {
    return {
        default: jest.fn().mockImplementation(() => {
            return {
                updateJsonDataWithDynamicValues: jest.fn(() => AdditionalInfoFormBuilderData)
            };
        })
    };
});

jest.mock('../../service/pvsettings.service', () => ({
    validateFormula: jest.fn(),
    updateFee: jest.fn()
}));

jest.mock('pages/companies/service/companies.service', () => ({
    updateFee: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

jest.mock('core/utils/utils', () => ({
    extractWordsBetweenCurlyBraces: jest.fn()
}));

describe('EditFormulaPopup Component', () => {
    const mockRowData: DataValue = {
        id: 1,
        translationFeeModel: { feeType: 'Units', formula: '', fee: 100, unitTypeId: 1 },
        officialFeeModel: { feeType: 'Formula', formula: 'x + y', fee: 200, unitTypeId: 2 },
        agencyFeeModel: { feeType: 'Units', formula: '', fee: 300, unitTypeId: 3 },
        countryIcon: 'us.png',
        requestCurrency: 'USD'
    };

    const mockUnitOptions: unitOptions[] = [
        { id: 1, name: 'Flat Fee' },
        { id: 2, name: 'Per Hour' }
    ];

    const mockTitle = { countryName: 'USA', countryIcon: 'us.png' };

    beforeEach(() => {
        (useTranslation as jest.Mock).mockReturnValue({ t: (key: string) => key });
        jest.clearAllMocks();
    });

    test('renders EditFormulaPopup component', async () => {
        const closeModal = jest.fn();
        const updateLocalTable = jest.fn();

        render(
            <EditFormulaPopup
                closeModal={closeModal}
                popupId="test-popup"
                title={mockTitle}
                rowData={mockRowData}
                feeType="translationFeeModel"
                formulaFields={['x', 'y']}
                unitOptionsValues={mockUnitOptions}
                updateLocalTable={updateLocalTable}
                company={false}
            />
        );

        await waitFor(() => {
            expect(screen.getByText('USA')).toBeInTheDocument();
            expect(screen.getByText('COMMON.UPDATE')).toBeInTheDocument();
            expect(screen.getByText('COMMON.CLEAR')).toBeInTheDocument();
        });
    });

    describe('Formula Validation and Submission', () => {
        test('validates formula correctly and shows valid formula message', async () => {
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                formulaValue: ['valid']
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const validateButton = screen.getByText('PV_SETTING.RATES.VALIDATE');
            fireEvent.click(validateButton);

            await waitFor(() => {
                expect(screen.getByText('PV_SETTING.RATES.VALID_FORMULA')).toBeInTheDocument();
            });
        });

        test('validates formula correctly and shows invalid formula message', async () => {
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                error: 'Invalid Formula'
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const validateButton = screen.getByText('PV_SETTING.RATES.VALIDATE');
            fireEvent.click(validateButton);

            await waitFor(() => {
                expect(screen.getByText('Invalid Formula')).toBeInTheDocument();
            });
        });

        test('validates formula and shows formula new fields error when formula contains invalid fields', async () => {
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                error: 'Invalid Formula'
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y', 'z']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const validateButton = screen.getByText('PV_SETTING.RATES.VALIDATE');
            fireEvent.click(validateButton);

            await waitFor(() => {
                expect(screen.getByText(/FORMULA_NEWFIELDS_ERROR/)).toBeInTheDocument();
            });
        });

        test('handles form submission correctly for PVSettingsService', async () => {
            (PVSettingsService.updateFee as jest.Mock).mockResolvedValue({ isSuccess: true });
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                formulaValue: ['valid']
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const updateButton = screen.getByText('COMMON.UPDATE');
            fireEvent.click(updateButton);

            await waitFor(() => {
                expect(updateLocalTable).toHaveBeenCalled();
                expect(closeModal).toHaveBeenCalled();
                expect(NotificationStore.showAlert).toHaveBeenCalledWith(
                    expect.objectContaining({ message: 'COMMON.FORMULA_UPDATE.SUCCESS' })
                );
            });
        });

        test('handles form submission correctly for companiesService', async () => {
            (companiesService.updateFee as jest.Mock).mockResolvedValue({ isSuccess: true });
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                formulaValue: ['valid']
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={true}
                />
            );

            const updateButton = screen.getByText('COMMON.UPDATE');
            fireEvent.click(updateButton);

            await waitFor(() => {
                expect(updateLocalTable).toHaveBeenCalled();
                expect(closeModal).toHaveBeenCalled();
                expect(NotificationStore.showAlert).toHaveBeenCalledWith(
                    expect.objectContaining({ message: 'COMMON.FORMULA_UPDATE.SUCCESS' })
                );
            });
        });

        test('handles form submission failure', async () => {
            (PVSettingsService.updateFee as jest.Mock).mockResolvedValue({ isSuccess: false });
            (PVSettingsService.validateFormula as jest.Mock).mockResolvedValue({
                formulaValue: ['valid']
            });
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['x', 'y']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const updateButton = screen.getByText('COMMON.UPDATE');
            fireEvent.click(updateButton);

            await waitFor(() => {
                expect(NotificationStore.showAlert).toHaveBeenCalledWith(
                    expect.objectContaining({ message: 'COMMON.FORMULA_UPDATE.FAILED' })
                );
            });
        });
    });

    describe('Unit Type Selection and Submission', () => {
        test('handles unit type selection and submission', async () => {
            (PVSettingsService.updateFee as jest.Mock).mockResolvedValue({ isSuccess: true });

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="translationFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const updateButton = screen.getByText('COMMON.UPDATE');
            fireEvent.click(updateButton);

            await waitFor(() => {
                expect(updateLocalTable).toHaveBeenCalled();
                expect(closeModal).toHaveBeenCalled();
                expect(NotificationStore.showAlert).toHaveBeenCalledWith(
                    expect.objectContaining({ message: 'COMMON.FORMULA_UPDATE.SUCCESS' })
                );
            });
        });

        test('renders EditFormulaPopup with empty unit options', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="translationFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={[]} // Empty unit options
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('USA')).toBeInTheDocument();
                expect(screen.queryByText('Flat Fee')).not.toBeInTheDocument();
            });
        });

        test('renders correct fields when company is true', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={true} // Company-specific behavior
                />
            );

            await waitFor(() => {
                expect(screen.getByText('USA')).toBeInTheDocument();
                expect(screen.getByText('COMMON.UPDATE')).toBeInTheDocument();
                // Add assertions for company-specific fields if any
            });
        });

        test('clears form fields when Clear button is clicked', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const clearButton = screen.getByText('COMMON.CLEAR');
            fireEvent.click(clearButton);

            await waitFor(() => {
                // Add assertions to verify that form fields are cleared
                expect(screen.queryByDisplayValue('x + y')).not.toBeInTheDocument();
            });
        });

        test('renders localized strings correctly', async () => {
            (useTranslation as jest.Mock).mockReturnValue({
                t: (key: string) => `Translated(${key})`
            });

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={{ countryName: 'USA', countryIcon: 'us.png' }}
                    rowData={mockRowData}
                    feeType="translationFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('Translated(COMMON.UPDATE)')).toBeInTheDocument();
                expect(screen.getByText('Translated(COMMON.CLEAR)')).toBeInTheDocument();
            });
        });
        test('updates formula fields dynamically based on input', async () => {
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['a', 'b']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={{ countryName: 'USA', countryIcon: 'us.png' }}
                    rowData={{
                        ...mockRowData,
                        officialFeeModel: { ...mockRowData.officialFeeModel, formula: '{a} + {b}' }
                    }}
                    feeType="officialFeeModel"
                    formulaFields={['a', 'b']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('{a} + {b}')).toBeInTheDocument(); // Ensure updated formula is displayed
            });
        });

        test('renders EditFormulaPopup with missing unitOptionsValues', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="translationFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={[]} // Empty unit options
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('USA')).toBeInTheDocument();
                expect(screen.queryByText('Flat Fee')).not.toBeInTheDocument(); // Ensure no unit options are displayed
            });
        });

        test('updates formula fields dynamically based on input', async () => {
            (utils.extractWordsBetweenCurlyBraces as jest.Mock).mockReturnValue(['a', 'b']);

            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={{ countryName: 'USA', countryIcon: 'us.png' }}
                    rowData={{
                        ...mockRowData,
                        officialFeeModel: { ...mockRowData.officialFeeModel, formula: '{a} + {b}' }
                    }}
                    feeType="officialFeeModel"
                    formulaFields={['a', 'b']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('{a} + {b}')).toBeInTheDocument(); // Ensure updated formula is displayed
                expect(screen.getByText('COMMON.UPDATE')).toBeEnabled(); // Ensure button is enabled after field updates
            });
        });
        test('clears form fields when Clear button is clicked', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={{ countryName: 'USA', countryIcon: 'us.png' }}
                    rowData={{
                        ...mockRowData,
                        officialFeeModel: { ...mockRowData.officialFeeModel, formula: '{x} + {y}' }
                    }}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            const clearButton = screen.getByText('COMMON.CLEAR');
            fireEvent.click(clearButton);

            await waitFor(() => {
                expect(screen.queryByDisplayValue('{x} + {y}')).not.toBeInTheDocument(); // Ensure fields are cleared
                expect(screen.queryByText('COMMON.UPDATE')).toBeDisabled(); // Ensure "Update" button is disabled after clearing fields
            });
        });

        test('handles case where no formula fields are provided', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={[]} // Empty formula fields
                    unitOptionsValues={mockUnitOptions}
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('USA')).toBeInTheDocument();
            });
        });

        test('handles case where no unit options are available', async () => {
            const closeModal = jest.fn();
            const updateLocalTable = jest.fn();

            render(
                <EditFormulaPopup
                    closeModal={closeModal}
                    popupId="test-popup"
                    title={mockTitle}
                    rowData={mockRowData}
                    feeType="officialFeeModel"
                    formulaFields={['x', 'y']}
                    unitOptionsValues={[]} // No unit options
                    updateLocalTable={updateLocalTable}
                    company={false}
                />
            );

            await waitFor(() => {
                expect(screen.getByText('USA')).toBeInTheDocument();
            });
        });
    });
});
