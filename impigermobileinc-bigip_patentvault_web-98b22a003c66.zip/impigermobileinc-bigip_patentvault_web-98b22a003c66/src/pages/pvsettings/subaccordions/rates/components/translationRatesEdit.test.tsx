import { render, fireEvent, screen } from '@testing-library/react';
import TranslationRateEdit from './translationRatesEdit';
import { RATE_INLINE_EDIT_FIELDS } from '../rates.const';

jest.mock('components/reuseComponents/constructField', () => ({
    FieldValueLabelTemplate: ({ data }: any) => (
        <div data-testid="field-value-label">{data.value}</div>
    ),
    InputFieldTemplate: ({ data }: any) => (
        <input
            data-testid="input-field"
            value={data.value}
            onChange={(e) => data.action(e.target.value)}
            type="number"
        />
    )
}));

jest.mock('assets/images/editBlue.svg', () => ({
    ReactComponent: (props: any) => <svg data-testid="editIcon" {...props} />
}));

describe('TranslationRateEdit Component', () => {
    const mockEditCell = jest.fn();

    const defaultProps = {
        fieldName: 'translationRate',
        rowData: {
            translationRateNumber: 25.5,
            currencySymbol: '$'
        },
        inlineEdit: true,
        editCell: mockEditCell
    };

    beforeEach(() => {
        mockEditCell.mockClear();
    });

    test('renders in view mode by default', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        expect(screen.getByTestId('field-value-label')).toBeInTheDocument();
        expect(screen.queryByTestId('input-field')).not.toBeInTheDocument();
    });

    test('shows edit icon when editable and not readOnly', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        const icon = screen.getByTestId('editIcon');
        expect(icon).toBeInTheDocument();
    });

    test('enters edit mode on edit icon click', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        fireEvent.click(screen.getByTestId('editIcon'));
        expect(screen.getByTestId('input-field')).toBeInTheDocument();
    });

    test('calls editCell with updated value on save', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        fireEvent.click(screen.getByTestId('editIcon'));
        const input = screen.getByTestId('input-field');
        fireEvent.change(input, { target: { value: '42.42' } });
        fireEvent.click(screen.getByTestId('saveButton'));

        expect(mockEditCell).toHaveBeenCalledWith(expect.anything(), 'translationRate', 42.42);
    });

    test('resets value and exits edit mode on cancel', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        fireEvent.click(screen.getByTestId('editIcon'));

        const input = screen.getByTestId('input-field');
        fireEvent.change(input, { target: { value: '99.99' } });

        fireEvent.click(screen.getByTestId('cancelButton'));

        // Input field should disappear and field label should return
        expect(screen.queryByTestId('input-field')).not.toBeInTheDocument();
        expect(screen.getByTestId('field-value-label')).toBeInTheDocument();
    });

    test('does not render edit icon if readOnly', () => {
        render(<TranslationRateEdit {...defaultProps} readOnly={true} />);
        expect(screen.queryByTestId('editIcon')).not.toBeInTheDocument();
    });

    test('disables editing for direct translation on non-translation field', () => {
        render(
            <TranslationRateEdit
                {...defaultProps}
                fieldName="someOtherRate"
                rowData={{ isDirectTranslation: true }}
            />
        );
        expect(screen.queryByTestId('editIcon')).not.toBeInTheDocument();
    });

    test('allows edit for COMPANY_TRANSLATION_RATE', () => {
        render(
            <TranslationRateEdit
                {...defaultProps}
                fieldName={RATE_INLINE_EDIT_FIELDS.COMPANY_TRANSLATION_RATE}
                rowData={{ isDirectTranslation: true }}
            />
        );
        expect(screen.getByTestId('editIcon')).toBeInTheDocument();
    });
    test('should not apply bg-cream-yellow when compareKey values are equal', () => {
        render(
            <TranslationRateEdit
                {...defaultProps}
                compareKey="compareRate"
                rowData={{ translationRateNumber: 50, compareRate: 50 }}
            />
        );
        const wrapper = screen.getByTestId('field-value-label').parentElement;
        expect(wrapper?.className.includes('bg-cream-yellow')).toBe(false);
    });
    test('enters edit mode via keyboard (Enter) on edit icon', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        const icon = screen.getByTestId('editIcon');
        fireEvent.keyDown(icon, { key: 'Enter' });
        expect(screen.getByTestId('input-field')).toBeInTheDocument();
    });
    test('saves on Enter key in edit mode', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        fireEvent.click(screen.getByTestId('editIcon'));
        const input = screen.getByTestId('input-field');
        fireEvent.change(input, { target: { value: '99.9' } });

        fireEvent.keyDown(screen.getByTestId('saveButton'), { key: 'Enter' });
        expect(mockEditCell).toHaveBeenCalledWith(expect.anything(), 'translationRate', 99.9);
    });
    test('cancels edit on Space key', () => {
        render(<TranslationRateEdit {...defaultProps} />);
        fireEvent.click(screen.getByTestId('editIcon'));
        const input = screen.getByTestId('input-field');
        fireEvent.change(input, { target: { value: '88.8' } });

        fireEvent.keyDown(screen.getByTestId('cancelButton'), { key: ' ' });
        expect(screen.queryByTestId('input-field')).not.toBeInTheDocument();
    });
});
