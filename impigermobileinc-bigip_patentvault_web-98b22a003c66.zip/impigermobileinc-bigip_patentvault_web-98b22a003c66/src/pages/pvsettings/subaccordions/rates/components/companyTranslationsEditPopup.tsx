import { useEffect, useState } from 'react';
import PopupModal from 'components/popupModal/popupModal';
import { useTranslation } from 'react-i18next';
import {
    CreateCompanyPayloadType,
    CreateVendorPayloadType,
    companyTranslationPopup,
    editCompanylevelTranslations
} from '../../types/pvsettings.types';
import HttpService from 'core/interceptor/api.handler';
import { Form } from '@formio/react';
import CreateTranslation, { CreateCompanyLevelTranslation } from '../json/CreateTranslation.json';
import { Breakdown } from 'pages/users/types/users.types';
import { UNIT_FEE_MODEL } from '../rates.const';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import { generateKeys } from 'pages/users/utils/vendorUserUtils';
import PVSettingsService from '../../service/pvsettings.service';
import CreateVendorTranslation from '../json/CreateVendorTranslation.json';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

export default function CompanyTranslationsEditPopup({
    rowData,
    popupId,
    closeModal,
    editMode,
    moduleName,
    updateListing,
    company,
    globalBreakdownValues,
    rowBreakdownValues = []
}: Readonly<companyTranslationPopup>) {
    const { t } = useTranslation();
    const [createAnother, setCreateAnother] = useState<boolean>(false);
    const companyData = companyStepperStore.getData();
    const { formData } = companyData;
    const [showResetPopup, setShowResetPopup] = useState<boolean>(false);
    const breakdownValues =
        rowBreakdownValues.length > 0 ? rowBreakdownValues : globalBreakdownValues;
    const createBreakdownsWithKeys = (breakdowns: Breakdown[]) =>
        breakdowns.map(({ breakdownName, vendorPercentage, value }) => {
            const { percentageKey, valueKey } = generateKeys(breakdownName);
            return {
                [percentageKey]: vendorPercentage,
                [valueKey]: value
            };
        });
    const globalBreakdownsWithPercentageValueKey = createBreakdownsWithKeys(globalBreakdownValues);
    const rowBreakdownsWithPercentageValueKey = createBreakdownsWithKeys(rowBreakdownValues);

    const isCompanyTranslations = moduleName === 'companytranslations' ? true : false;

    useEffect(() => {
        return () => {
            clearFormValues();
        };
    }, [editMode]);

    const httpService = new HttpService();
    const isTMDiscountAgreed =
        formData.companyProfilePage && formData.companyProfilePage.isAgreeTMDiscounts === 'yes';

    /* eslint-disable @typescript-eslint/no-unsafe-argument */
    const createCompanyTranslations = isCompanyTranslations
        ? company
            ? CreateCompanyLevelTranslation(breakdownValues, isTMDiscountAgreed, editMode)
            : CreateTranslation(breakdownValues, editMode)
        : CreateVendorTranslation(breakdownValues, editMode);
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(createCompanyTranslations);

    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());
    const [renderForm, setRenderForm] = useState<boolean>(false);
    formStatusStore.subscribe(setFormState);

    // Merge all the objects in the array into a single object
    const initialBreakDownData = (
        rowBreakdownValues.length > 0
            ? rowBreakdownsWithPercentageValueKey
            : globalBreakdownsWithPercentageValueKey
    ).reduce((acc, item) => {
        return { ...acc, ...item };
    }, {});

    const initialData = {
        sourceLanguageId: { id: rowData.sourceLanguageId, name: rowData.sourceLanguageName },
        targetLanguageId: editMode
            ? { id: rowData.targetLanguageId, name: rowData.targetLanguageName }
            : [{ id: rowData.targetLanguageId, name: rowData.targetLanguageName }],
        currencyId: { currencyId: rowData.currencyId, currencyCode: rowData.currencyCode },
        minCharge: rowData.minCharge,
        enableMinCharge: rowData.enableMinCharge,
        unitId: { id: rowData.unitId, name: rowData.unitName },
        rate: rowData.translationRate,
        agreeTmDiscount: rowData.agreeTmDiscount,
        breakdowns: breakdownValues,
        translationRate: rowData.translationRate,
        abilityId: { id: rowData.abilityId, name: rowData.abilityName || '' }, // 1 is defaulting to Translation ability
        id: rowData.id ?? 0,
        enableBreakdown: rowData.enableBreakdown,
        ...initialBreakDownData
    };

    const onFormChange = (e: any) => {
        if (e.changed) {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            if (e?.changed?.component?.key === 'resetToDefault') {
                setShowResetPopup(true);
            }
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    useEffect(() => {
        if (editMode) {
            formStatusStore.updateFormData(initialData, true);
            setRenderForm(true);
        } else {
            formStatusStore.updateFormData(
                {
                    ...initialBreakDownData,
                    agreeTmDiscount: true,
                    enableMinCharge: true,
                    enableBreakdown: true
                },
                true
            );
            setRenderForm(true);
        }
    }, [rowData, breakdownValues]);

    const resetFormValues = () => {
        formStatusStore.updateFormData(
            {
                ...initialBreakDownData,
                agreeTmDiscount: true,
                enableMinCharge: true,
                enableBreakdown: true
            },
            false
        );
    };

    const clearFormValues = () => {
        formStatusStore.clearFormData();
    };

    const handleSubmit = () => {
        onSubmit(formState?.data);
    };

    const getResetFormData = () => {
        const updatedData = {
            ...initialData,
            agreeTmDiscount: formStatusStore.getFormData()?.data?.agreeTmDiscount,
            breakdowns: globalBreakdownValues,
            currencyId: formStatusStore.getFormData()?.data?.currencyId,
            enableBreakdown: formStatusStore.getFormData()?.data?.enableBreakdown,
            enableMinCharge: formStatusStore.getFormData()?.data?.enableMinCharge,
            id: formStatusStore.getFormData()?.data?.id,
            minCharge: formStatusStore.getFormData()?.data?.minCharge,
            rate: formStatusStore.getFormData()?.data?.rate,
            resetToDefault: formStatusStore.getFormData()?.data?.resetToDefault,
            sourceLanguageId: formStatusStore.getFormData()?.data?.sourceLanguageId,
            targetLanguageId: formStatusStore.getFormData()?.data?.targetLanguageId,
            translationRate: formStatusStore.getFormData()?.data?.translationRate,
            unitId: formStatusStore.getFormData()?.data?.unitId
        };
        // Dynamically remove only percentage and value keys
        (Object.keys(updatedData) as (keyof typeof updatedData)[]).forEach((key) => {
            if (
                typeof key === 'string' &&
                (key.startsWith('percentage') || key.startsWith('value'))
            ) {
                delete (updatedData as any)[key];
            }
        });

        // Add new percentage and value keys from globalBreakdownsWithPercentageValueKey
        globalBreakdownsWithPercentageValueKey.forEach((item) => {
            Object.keys(item).forEach((key) => {
                (updatedData as any)[key] = item[key as keyof typeof item];
            });
        });
        return updatedData;
    };

    const onSubmit = async (data: { [key: string]: any }) => {
        const breakdowns = breakdownValues.map((breakdown) => {
            const { valueKey, percentageKey } = generateKeys(breakdown.breakdownName);
            return {
                id: breakdown.id,
                breakdownName: breakdown.breakdownName,
                translateRateValue:
                    data[valueKey] == null || data[valueKey] === '' || isNaN(data[valueKey])
                        ? ((data[percentageKey] / 100) * data?.rate || 0).toFixed(2)
                        : data[valueKey],
                [isCompanyTranslations ? 'companyPercentage' : 'vendorPercentage']:
                    data[percentageKey]
            };
        });

        if (isCompanyTranslations) {
            if (company) {
                let payload: editCompanylevelTranslations = {
                    id: rowData?.id ?? 0,
                    translationRate: data?.rate,
                    rateChanged: data?.rateChanged ?? false,
                    agreeTmDiscount: isTMDiscountAgreed ? data?.agreeTmDiscount : false,
                    minCharge: data?.minCharge
                };
                if (data?.agreeTmDiscount && isTMDiscountAgreed)
                    payload = { ...payload, breakdowns };
                await PVSettingsService.saveCompanyLevelTranslations(payload).then((response) => {
                    if (response && Object.keys(response).length > 0) {
                        if (createAnother) resetFormValues();
                        else {
                            closeModal();
                            clearFormValues();
                        }
                        updateListing();
                    }
                });
            } else {
                let payload: CreateCompanyPayloadType = {
                    id: rowData?.id ?? 0,
                    sourceLanguageId: (data?.sourceLanguageId?.id as number) || 0,
                    sourceLanguageName: data?.sourceLanguageId?.name,
                    targetLanguageId: 0,
                    targetLanguageName: editMode
                        ? data?.targetLanguageId?.name
                        : data?.targetLanguageId
                              ?.map((item: { name: string }) => item?.name)
                              ?.join(','),
                    targetLanguageIds: editMode
                        ? [(data?.targetLanguageId?.id as number) || 0]
                        : data?.targetLanguageId.map((item: { id: any }) => item.id),
                    currencyId: (data?.currencyId?.currencyId as number) || 0,
                    currencyCode: data?.currencyId?.currencyCode,
                    enableMinCharge: data?.enableMinCharge,
                    minCharge: data?.minCharge,
                    unitId: data?.unitId?.id,
                    unitName: data?.unitId?.name,
                    translationRate: data?.rate,
                    agreeTmDiscount: data?.agreeTmDiscount
                };
                if (data?.agreeTmDiscount) payload = { ...payload, breakdowns };

                if (company) payload = { ...payload, rateChanged: data.rateChanged ?? false };

                if (
                    !data?.sourceLanguageId ||
                    !data?.targetLanguageId ||
                    !data?.currencyId ||
                    !data?.rate ||
                    (data?.enableMinCharge && (data?.minCharge == null || data?.minCharge === ''))
                ) {
                    return;
                }

                await PVSettingsService.saveCompanyTranslations(payload, company).then(
                    (response) => {
                        if (response && Object.keys(response).length > 0) {
                            if (createAnother) resetFormValues();
                            else {
                                closeModal();
                                clearFormValues();
                            }
                            updateListing();
                        }
                    }
                );
            }
        } else {
            let payload: CreateVendorPayloadType = {
                id: rowData?.id ?? 0,
                sourceLanguageId: (data?.sourceLanguageId?.id as number) || 0,
                sourceLanguageName: data?.sourceLanguageId?.name,
                targetLanguageId: 0,
                targetLanguageName: editMode
                    ? data?.targetLanguageId?.name
                    : data?.targetLanguageId
                          ?.map((item: { name: string }) => item?.name)
                          ?.join(','),
                targetLanguageIds: editMode
                    ? [(data?.targetLanguageId?.id as number) || 0]
                    : data?.targetLanguageId.map((item: { id: any }) => item.id),
                currencyId: (data?.currencyId?.currencyId as number) || 0,
                currencyCode: data?.currencyId?.currencyCode,
                unitId: UNIT_FEE_MODEL?.PER_WORD?.unitId,
                unitName: UNIT_FEE_MODEL?.PER_WORD?.unitName,
                translationRate: data?.rate,
                abilityId: data?.abilityId?.id || 1, // 1 is defaulting to Translation ability
                enableBreakdown: data?.enableBreakdown
            };
            if (data?.enableBreakdown) payload = { ...payload, breakdowns };
            if (
                !data?.sourceLanguageId ||
                !data?.targetLanguageId ||
                !data?.currencyId ||
                !data?.rate
            ) {
                return;
            }

            await PVSettingsService.saveVendorTranslations(payload).then((response) => {
                if (response && Object.keys(response).length > 0) {
                    if (createAnother) resetFormValues();
                    else {
                        closeModal();
                        clearFormValues();
                    }
                    updateListing();
                }
            });
        }
    };

    return (
        <PopupModal
            id={popupId}
            title={
                editMode
                    ? t('PV_SETTING.RATES.EDIT_TRANSLATION_RATE')
                    : t('PV_SETTING.RATES.CREATE_TRANSLATION_RATE')
            }
            onClose={() => {
                closeModal();
                formStatusStore.updateFormData({}, true);
            }}
            formDataOnReset={{
                ...initialBreakDownData,
                agreeTmDiscount: true,
                enableMinCharge: true,
                enableBreakdown: true
            }}
            onSubmit={handleSubmit}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            onChangeCreateAnother={() => {
                setCreateAnother(!createAnother);
            }}
            createButtonText={editMode ? t('COMMON.UPDATE') : t('COMMON.CREATE')}
            resetButtonText={t(`COMMON.${editMode ? 'CANCEL' : 'CLEAR'}`)}
            isEdit={editMode}>
            {/* {breakdownValues?.length ? <CompanyTranslations rowData={rowData} setFormValues={setFormValues} breakdownValues={breakdownValues} editMode={editMode} /> : <></>} */}
            <div className="p-4 bg-neutral max-h-96 overflow-auto translation-form">
                {renderForm ? (
                    <Form
                        form={formBuilderData}
                        submission={{ data: { ...formState.data } }}
                        onCancel={() => formStatusStore.updateFormData({}, true)}
                        onChange={(e: any) => onFormChange(e)}
                    />
                ) : (
                    <></>
                )}
                {showResetPopup && (
                    <ConfirmationPopup
                        onConfirm={() => {
                            formStatusStore.updateFormData(getResetFormData(), true, true);
                            setShowResetPopup(false);
                        }}
                        onCancel={() => {
                            setShowResetPopup(false);
                        }}
                        visible={showResetPopup}
                        headerText={t('COMMON.CONFIRMATION')}
                        description={t('PV_SETTING.RATES.RESET_CONFIRMATION_DESCRIPTION')}
                        acceptLabel={t('PV_SETTING.RATES.RESET_CONFIRMATION_BUTTON_YES')}
                        acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                        rejectClassName="!bg-error !text-white !border-none"
                        rejectLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_NO')}
                        popupID={'resetPopup'}
                    />
                )}
            </div>
        </PopupModal>
    );
}
