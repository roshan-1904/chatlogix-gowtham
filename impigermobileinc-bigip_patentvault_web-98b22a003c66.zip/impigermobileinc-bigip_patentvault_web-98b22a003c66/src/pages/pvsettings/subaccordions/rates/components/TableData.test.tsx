import { render, screen, fireEvent } from '@testing-library/react';
import TableData from './TableData';
import { TableComponent } from '../../types/pvsettings.types';
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: any) => key // Mock translation function
    })
}));

jest.mock('core/store/stepperStore/companyStore/company.store', () => ({
    getData: jest.fn(() => ({ stepperInfo: { primaryId: 1 } }))
}));

jest.mock('../../service/pvsettings.service', () => ({
    getCompanyLevelTranslationsData: jest.fn(),
    getCompanyTranslationsData: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

describe('TableData Component', () => {
    const defaultProps = {
        sourceLanguageId: 1,
        requestCurrencyId: 2,
        columnSchema: [
            {
                field: 'countryName',
                header: 'Country',
                columnNumber: 1,
                visibility: true // Add missing properties
            }
        ],
        moduleName: 'pct' as const,
        company: false,
        listingData: [],
        setListingData: jest.fn(),
        unitOptionsValues: [],
        FormulaFields: [],
        expandedRows: [],
        readOnly: false,
        targetLanguage: 'en',
        serviceType: '',
        getPreferredCurrency: jest.fn(),
        localStorageKey: 'testKey',
        isEnglishTranslationUpdated: false,
        activeIndex: 0
    } as unknown as TableComponent;

    it('renders without crashing', () => {
        render(<TableData {...defaultProps} />);
        expect(screen.getByTestId('addCountry')).toBeInTheDocument();
    });

    it('displays the correct button based on moduleName and company props', () => {
        const { rerender } = render(<TableData {...defaultProps} />);

        // Check for "Add Country" button
        expect(screen.getByTestId('addCountry')).toBeInTheDocument();

        // Rerender with company=true
        rerender(<TableData {...defaultProps} company={true} />);

        // Check for "Reset to Default" button
        expect(screen.getByTestId('resetToDefault')).toBeInTheDocument();
    });

    it('opens modal when "Add Country" button is clicked', () => {
        render(<TableData {...defaultProps} />);

        const addButton = screen.getByTestId('addCountry');

        fireEvent.click(addButton);

        // Assuming modal has a specific ID or test ID
        expect(screen.getAllByText('PV_SETTING.RATES.ADD_COUNTRY').length).toBeGreaterThan(0);
    });

    it('handles page updates correctly', () => {
        const setListingDataMock = jest.fn();

        render(<TableData {...defaultProps} setListingData={setListingDataMock} />);

        // Simulate page update logic (mock implementation of handlePageUpdate)
        fireEvent.click(screen.getByTestId('addCountry'));

        expect(setListingDataMock).toHaveBeenCalled();
    });

    it('shows toast message on error', () => {
        const showToastMessageMock = jest.fn();

        render(<TableData {...defaultProps} />);

        // Simulate error scenario
        showToastMessageMock('Error occurred', 'error');

        expect(showToastMessageMock).toHaveBeenCalledWith('Error occurred', 'error');
    });
});
