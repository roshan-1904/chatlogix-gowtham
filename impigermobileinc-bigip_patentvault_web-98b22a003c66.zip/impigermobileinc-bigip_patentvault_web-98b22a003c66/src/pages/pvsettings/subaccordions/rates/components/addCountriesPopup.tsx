import PopupModal from 'components/popupModal/popupModal';
import { Form } from '@formio/react';
import React, { useEffect, useState } from 'react';
import AdditionalInfoFormBuilderData from '../json/addCountry.json';
import { useTranslation } from 'react-i18next';
import HttpService from 'core/interceptor/api.handler';
import {
    CompanyTranslationFormulaUpdate,
    FeeModelKeys,
    FormulaUpdateResponse,
    PVSettingsRatesKeys,
    TranslationFormulaUpdate,
    descriptionTranslationFormula,
    editFormulaTitle,
    unitOptions,
    validateFormulaTypes
} from '../../types/pvsettings.types';
import { DataValue } from 'shared/dataTable/types/dataTable.types';
import PVSettingsService from '../../service/pvsettings.service';
import {
    DEFAULT_COMPANY_FEE_MODAL,
    DEFAULT_FEE_MODAL,
    HEADER_LANGUAGE_MODULES,
    PV_SETTINGS_FEE_MODALS,
    PV_SETTINGS_RATES
} from '../rates.const';
import { RadioButton } from 'primereact/radiobutton';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import ReactTextareaAutocomplete from '@webscopeio/react-textarea-autocomplete';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import companiesService from 'pages/companies/service/companies.service';
import { companyFeeResponseType } from 'pages/companies/types/createCompany.types';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import utils from 'core/utils/utils';

const buttonStyles: any = {
    validate: 'border-primary/50 hover:border-primary/50 text-primary border-2',
    invalid:
        'bg-negative-tone bg-opacity-25 hover:bg-negative-tone hover:bg-opacity-25 border-none',
    valid: 'bg-positive-tone bg-opacity-25 hover:bg-positive-tone hover:bg-opacity-25 border-none'
};

export const AddCountries: React.FC<{
    closeModal: () => void;
    popupId: string;
}> = ({ closeModal, popupId }) => {
    const { t } = useTranslation();

    return (
        <PopupModal
            id={popupId}
            title={t('PV_SETTING.RATES.ADD_COUNTRY')}
            onClose={closeModal}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            resetButtonText={t('COMMON.CANCEL')}
            isEdit={true}>
            <PopupChildren />
        </PopupModal>
    );
};

export const PopupChildren: React.FC = () => {
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(
        AdditionalInfoFormBuilderData
    );

    return (
        <div className="p-4">
            <div>
                <Form form={formBuilderData} onChange={() => {}} submission={{}} />
            </div>
        </div>
    );
};

export const EditFormulaPopup: React.FC<{
    closeModal: () => void;
    popupId: string;
    title: editFormulaTitle;
    rowData: DataValue;
    feeType: string;
    formulaFields: Array<string>;
    unitOptionsValues: unitOptions[];
    updateLocalTable: (rowData: any) => void;
    company: boolean;
    serviceType?: string;
}> = ({
    closeModal,
    popupId,
    title,
    rowData,
    feeType,
    updateLocalTable,
    unitOptionsValues,
    formulaFields,
    company,
    serviceType
}) => {
    const { t } = useTranslation();
    const [validFormula, setValidFormula] = useState<validateFormulaTypes>({ state: 'validate' });
    const [resetFormulaConfirmation, setResetFormulaConfirmation] = useState<boolean>(false);
    const feeModelMapping: Record<string, string> = {
        companyTranslationFeeModel: 'translationFeeModel',
        companyOfficialFeeModel: 'officialFeeModel',
        companyAgencyFeeModel: 'agencyFeeModel'
    };
    const [feeInfo, setFeeInfo]: any = useState(
        company
            ? {
                  id: rowData?.id,
                  companyTranslationFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  },
                  companyOfficialFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  },
                  companyAgencyFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  }
              }
            : {
                  id: rowData?.id,
                  translationFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  },
                  officialFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  },
                  agencyFeeModel: {
                      feeType: '',
                      unitTypeId: 0,
                      formula: '',
                      fee: 0
                  }
              }
    );

    const data = {
        feeType: rowData?.[feeType]?.feeType === 'Formula' ? 'Formula' : 'Units',
        formula: rowData?.[feeType]?.formula,
        fee: rowData?.[feeType]?.fee,
        unitTypeId: rowData?.[feeType]?.unitTypeId ?? 0
    };

    useEffect(() => {
        setFeeInfo({
            ...feeInfo,
            id: rowData?.id,
            [feeType]: data
        });
    }, [rowData, feeType]);

    const updateLocalData = (response: any, submissionBody: any) => {
        if (response) {
            let currentFeeType: FeeModelKeys = 'translationFeeModel';
            switch (feeType) {
                case 'translationFeeModel':
                    currentFeeType = 'translationFeeModel';
                    break;
                case 'officialFeeModel':
                    currentFeeType = 'officialFeeModel';
                    break;
                case 'agencyFeeModel':
                    currentFeeType = 'agencyFeeModel';
                    break;
                case 'companyTranslationFeeModel':
                    currentFeeType = 'companyTranslationFeeModel';
                    break;
                case 'companyOfficialFeeModel':
                    currentFeeType = 'companyOfficialFeeModel';
                    break;
                case 'companyAgencyFeeModel':
                    currentFeeType = 'companyAgencyFeeModel';
                    break;
                default:
                    currentFeeType = 'agencyFeeModel';
                    break;
            }
            const unitTypeIdVal =
                feeInfo?.[feeType]?.unitTypeId !== null || feeInfo?.[feeType]?.unitTypeId !== 0;
            updateLocalTable({
                ...rowData,
                [feeType]: {
                    ...rowData?.[feeType],
                    ...submissionBody?.[currentFeeType],
                    feeType: unitTypeIdVal
                        ? (feeInfo?.[feeType]?.feeTypeText ?? unitOptionsValues?.[0]?.name)
                        : 'Formula'
                }
            });
            closeModal();
        }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const validateFormula = async (formula: string) => {
        try {
            const usedFieldsList = utils.extractWordsBetweenCurlyBraces(formula);
            const newFieldsList =
                usedFieldsList.filter((field) => !formulaFields.includes(field.trim())) || [];

            if (newFieldsList.length > 0) {
                const invalidFields = newFieldsList.join(', ');
                const errorMessage = t('PV_SETTING.RATES.FORMULA_NEWFIELDS_ERROR', {
                    invalidFields
                });
                setValidFormula({ state: 'invalid', error: errorMessage });
                return 'invalid';
            }

            const response: any = await PVSettingsService.validateFormula(formula);
            if (response?.formulaValue?.length) {
                setValidFormula({ state: 'valid' });
                return 'valid';
            } else if (response.error?.length) {
                setValidFormula({ state: 'invalid', error: response.error });
                return 'invalid';
            }
            return 'invalid';
        } catch (error) {
            console.error(error);
            setValidFormula({ state: 'invalid' });
        }
    };

    const onSubmit = async () => {
        let formulaStatus = null;
        if (validFormula.state === 'validate' && feeInfo?.[feeType]?.feeType === 'Formula') {
            formulaStatus = await validateFormula(feeInfo?.[feeType]?.formula as string);
        }

        await new Promise((r) => setTimeout(r, 100));
        if (validFormula.state === 'invalid' || formulaStatus === 'invalid') return;

        let submissionBody = { ...DEFAULT_FEE_MODAL, id: rowData?.id };
        let companySubmissionBody: companyFeeResponseType = {
            id: rowData?.id,
            ...DEFAULT_COMPANY_FEE_MODAL
        };
        if (feeInfo?.[feeType]?.feeType === 'Formula') {
            if (company)
                companySubmissionBody = {
                    id: rowData?.id,
                    ...DEFAULT_COMPANY_FEE_MODAL,
                    [feeType]: {
                        feeType:
                            feeInfo?.[feeType]?.feeType.replace(/^./, (char: string) =>
                                char.toUpperCase()
                            ) ?? '',
                        unitTypeId: 0,
                        formula: feeInfo?.[feeType]?.formula,
                        fee: 0
                    }
                };
            else
                submissionBody = {
                    ...feeInfo,
                    [feeType]: {
                        feeType:
                            feeInfo?.[feeType]?.feeType.replace(/^./, (char: string) =>
                                char.toUpperCase()
                            ) ?? '',
                        unitTypeId: 0,
                        formula: feeInfo?.[feeType]?.formula,
                        fee: 0
                    }
                };
        } else if (feeInfo?.[feeType]?.unitTypeId !== null) {
            const unitTypeId = feeInfo?.[feeType]?.unitTypeId
                ? parseInt(String(feeInfo?.[feeType].unitTypeId), 10)
                : undefined;
            if (company)
                companySubmissionBody = {
                    id: rowData?.id,
                    ...DEFAULT_COMPANY_FEE_MODAL,
                    [feeType]: {
                        feeType:
                            feeInfo?.[feeType]?.feeType.replace(/^./, (char: string) =>
                                char.toUpperCase()
                            ) ?? '',
                        unitTypeId: unitTypeId ?? 1,
                        formula: '',
                        fee: feeInfo?.[feeType]?.fee
                    }
                };
            submissionBody = {
                id: rowData?.id,
                ...DEFAULT_FEE_MODAL,
                [feeType]: {
                    feeType:
                        feeInfo?.[feeType]?.feeType.replace(/^./, (char: string) =>
                            char.toUpperCase()
                        ) ?? '',
                    unitTypeId: unitTypeId ?? 1,
                    formula: '',
                    fee: feeInfo?.[feeType]?.fee
                }
            };
        }
        if (company)
            await companiesService.updateFee(companySubmissionBody).then((response: any) => {
                if (response?.isSuccess) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType?.SUCCESS);
                    updateLocalData(response, companySubmissionBody);
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType?.ERROR);
                }
            });
        else
            await PVSettingsService.updateFee(submissionBody).then((response: any) => {
                if (response?.isSuccess) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType?.SUCCESS);
                    updateLocalData(response, submissionBody);
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType?.ERROR);
                }
            });
    };
    const CountryFlag = () => {
        return (
            <div
                className={`h-[1rem] w-[1rem] rounded-full border overflow-hidden bg-no-repeat bg-center mr-2`}
                style={{
                    backgroundImage: 'url(/images/country-flags/' + rowData?.countryIcon + ')',
                    backgroundSize: '150%'
                }}></div>
        );
    };

    const resetFormula = () => {
        if (feeType in feeModelMapping) {
            const formulaKey = feeModelMapping[feeType];
            setFeeInfo((prevState: any) => ({
                ...prevState,
                [feeType]: {
                    ...prevState[feeType],
                    formula: rowData?.[formulaKey]?.formula || prevState[feeType]?.formula || ''
                }
            }));
        }
    };

    const renderResetToDefault = () => {
        return (
            <button
                onClick={() => setResetFormulaConfirmation(true)}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn btn-sm my-3 border border-neutral-600 hover:border-neutral-600">
                <i className="pi pi-refresh text-primary" />
                {t('PV_SETTING.RATES.RESET_TO_DEFAULT')}
            </button>
        );
    };

    const disableSubmit = () => {
        return feeInfo[feeType]?.feeType === 'Formula' ? !feeInfo[feeType]?.formula : false;
    };

    return (
        <PopupModal
            id={popupId}
            title={
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    {HEADER_LANGUAGE_MODULES.includes(serviceType ?? '') ? (
                        <div>
                            <span className="mr-2">{rowData?.['languageName']}</span>
                            <span className="text-xs font-semibold text-neutral-200/80">
                                {`(${serviceType})`}
                            </span>
                        </div>
                    ) : (
                        <>
                            <CountryFlag />
                            <span className="text-xl mr-3">{title.countryName}</span>
                            <span className="text-xs font-semibold text-neutral-200/80">
                                {`(${serviceType})`}
                            </span>
                        </>
                    )}
                </div>
            }
            onClose={() => {
                closeModal();
                setValidFormula({ state: 'validate' });
                setFeeInfo({
                    ...feeInfo,
                    id: rowData.id,
                    [feeType]: data
                });
            }}
            createButtonText={t('COMMON.UPDATE')}
            resetButtonText={t('COMMON.CLEAR')}
            renderCustomBtn={
                feeInfo[feeType]?.feeType === 'Formula' &&
                company &&
                feeType in feeModelMapping &&
                !!rowData?.[feeModelMapping[feeType]]?.formula
                    ? renderResetToDefault
                    : undefined
            }
            disableSubmit={disableSubmit()}
            isFormIo={false}
            customReset={() => {
                setFeeInfo((prevState: any) => ({
                    ...prevState,
                    [feeType]:
                        feeInfo?.[feeType].feeType === 'Units'
                            ? {
                                  ...prevState[feeType],
                                  unitTypeId: 0,
                                  fee: 0
                              }
                            : {
                                  ...prevState[feeType],
                                  formula: ''
                              }
                }));
            }}
            onSubmit={() => {
                (async () => {
                    if (
                        feeInfo?.[feeType]?.feeType === 'Units' &&
                        (feeInfo?.[feeType]?.fee === '' || feeInfo?.[feeType]?.fee === null)
                    ) {
                        return;
                    }
                    await onSubmit();
                })();
            }}
            isEdit={true}>
            {resetFormulaConfirmation && company && (
                <ConfirmationPopup
                    onConfirm={() => {
                        resetFormula();
                        setResetFormulaConfirmation(false);
                    }}
                    onCancel={() => {
                        setResetFormulaConfirmation(false);
                    }}
                    visible={resetFormulaConfirmation}
                    headerText={t('COMMON.CONFIRMATION')}
                    description={t('PV_SETTING.RATES.RESET_CONFIRMATION_DESCRIPTION')}
                    acceptLabel={t('PV_SETTING.RATES.RESET_CONFIRMATION_BUTTON_YES')}
                    acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                    rejectClassName="!bg-error !text-white !border-none"
                    rejectLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_NO')}
                    popupID={'resetPopup'}
                />
            )}
            <EditFormulaChildrenCustomForm
                feeType={feeType}
                rowData={rowData}
                unitOptionsValues={unitOptionsValues}
                formulaFields={formulaFields}
                feeInfo={feeInfo}
                validFormula={validFormula}
                setValidFormula={setValidFormula}
                setFeeInfo={setFeeInfo}
                // handleValidate={handleValidate}
            />
        </PopupModal>
    );
};

const EditFormulaChildrenCustomForm: React.FC<{
    feeType: string;
    rowData: DataValue;
    formulaFields: Array<string>;
    unitOptionsValues: unitOptions[];
    feeInfo: any;
    setFeeInfo: any;
    validFormula: validateFormulaTypes;
    setValidFormula: any;
}> = ({
    feeType,
    rowData,
    unitOptionsValues,
    formulaFields,
    feeInfo,
    setFeeInfo,
    validFormula,
    setValidFormula
}) => {
    const { t } = useTranslation();

    const Item = ({ entity: { name } }: { entity: any }) => <div>{`${name}`}</div>;
    const filterFields = (key: string) => {
        return formulaFields
            .filter((fieldName) => fieldName.toLowerCase().includes(key.toLowerCase()))
            .map((fieldName) => {
                return { name: fieldName, char: fieldName };
            });
    };

    useEffect(() => {
        setFeeInfo({
            ...feeInfo,
            [feeType]: {
                ...feeInfo.feeType,
                feeType: rowData?.[feeType]?.unitTypeId !== 0 ? 'Units' : 'Formula',
                formula: rowData?.[feeType]?.formula ?? '',
                fee: rowData?.[feeType]?.fee ?? null,
                unitTypeId: rowData?.[feeType]?.unitTypeId ?? 1
            }
        });
    }, []);

    const onChange = (internalName: string, value: any) => {
        let feeModalInfo = {
            ...feeInfo,
            [feeType]: {
                ...feeInfo[feeType],
                [internalName]: value
            }
        };
        if (internalName === 'unitTypeId') {
            feeModalInfo = {
                ...feeModalInfo,
                [feeType]: {
                    ...feeModalInfo[feeType],
                    feeTypeText: unitOptionsValues.find((option) => option.id === value)?.name
                }
            };
        }
        setFeeInfo(feeModalInfo);
        if (internalName === 'formula' && validFormula.state !== 'validate') {
            setValidFormula({ state: 'validate' });
        }
    };

    // const showToastMessage = (toastMsg: string, errorType: ToastType) => {
    //     const message: notificationModel = {
    //         message: toastMsg,
    //         type: errorType
    //     };
    //     NotificationStore.showAlert(message);
    // };

    const validateFormula = async (formula: string) => {
        try {
            const usedFieldsList = utils.extractWordsBetweenCurlyBraces(formula);
            const newFieldsList =
                usedFieldsList.filter(
                    (field) =>
                        !formulaFields
                            .map((f) => f.toLowerCase())
                            .includes(field.toLowerCase().trim())
                ) || [];

            if (newFieldsList.length > 0) {
                const invalidFields = newFieldsList.join(', ');
                const errorMessage = t('PV_SETTING.RATES.FORMULA_NEWFIELDS_ERROR', {
                    invalidFields
                });
                setValidFormula({ state: 'invalid', error: errorMessage });
                return 'invalid';
            }

            const response: any = await PVSettingsService.validateFormula(formula);
            if (response?.formulaValue?.length) {
                setValidFormula({ state: 'valid' });
                return 'valid';
            } else if (response.error?.length) {
                setValidFormula({ state: 'invalid', error: response.error });
                return 'invalid';
            }
        } catch (error) {
            console.error(error);
            setValidFormula({ state: 'invalid' });
        }
    };
    const value = unitOptionsValues.find((item) => item.name === 'Flat Fee')?.id;
    return (
        <div className="p-4">
            <div>
                <label
                    className="field-required font-medium text-neutral-700"
                    htmlFor="rb1"
                    aria-required={true}>
                    {PV_SETTINGS_FEE_MODALS[feeType]}
                </label>
            </div>
            {/* Fee Type Raido button */}
            <div className="flex mt-3">
                <div className="flex align-items-center mr-5">
                    <RadioButton
                        value={'Units'}
                        name={'Units'}
                        checked={feeInfo?.[feeType]?.feeType === 'Units'}
                        onChange={(e) => {
                            onChange('feeType', e.target.value);
                            // handleValidate(true);
                        }}
                    />
                    <label htmlFor="Units" className="ml-2">
                        {t('MENU.UNITS')}
                    </label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton
                        value={'Formula'}
                        name={'Formula'}
                        checked={feeInfo[feeType]?.feeType === 'Formula'}
                        onChange={(e) => {
                            onChange('feeType', e.target.value);
                            // handleValidate(false);
                        }}
                    />
                    <label htmlFor="Formula" className="ml-2">
                        {t('PV_SETTING.RATES.FORMULA')}
                    </label>
                </div>
            </div>
            {/* Units Dropdown */}
            {feeInfo[feeType]?.feeType === 'Units' ? (
                <div className="mt-3">
                    <label
                        className="field-required font-medium text-neutral-700"
                        htmlFor="Formula">
                        {t('MENU.UNITS')}
                    </label>
                    <div className="flex mt-2">
                        <div className="col-6 mr-3">
                            <Dropdown
                                optionValue="id"
                                className="!w-full font-semibold"
                                value={
                                    feeInfo[feeType].unitTypeId !== 0
                                        ? (feeInfo[feeType].unitTypeId ?? value)
                                        : value
                                }
                                placeholder={'Select Units'}
                                onChange={(e) => {
                                    onChange('unitTypeId', e.target.value);
                                }}
                                optionLabel="name"
                                options={unitOptionsValues ?? []}
                                pt={{
                                    item: {
                                        className: 'font-medium'
                                    }
                                }}
                            />
                        </div>
                        <div className="col-3 flex items-center">
                            <InputNumber
                                disabled={(value ?? feeInfo[feeType].unitTypeId) ? false : true}
                                pt={{ root: { className: 'w-fit' } }}
                                className="mr-2"
                                value={feeInfo[feeType].fee || 0.0}
                                onValueChange={(e) => onChange('fee', e.value)}
                                mode="decimal"
                                maxFractionDigits={2}
                                id="input-fee"
                            />
                            <div>{rowData?.requestCurrency}</div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="mt-3">
                    {/* Formula Text area */}
                    <div className="flex justify-between">
                        <label className="field-required" htmlFor="Formula">
                            {t('PV_SETTING.RATES.FORMULA')}
                        </label>
                        <div className="bg-warning/40 w-fit px-2 rounded border border-warning text-neutral-700 flex gap-1 items-center">
                            <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                            <label className="">
                                {t('PV_SETTING.RATES.FORMULA_TEXTAREA_NOTE')}
                            </label>
                        </div>
                    </div>
                    <ReactTextareaAutocomplete
                        className="form-control formulaEditor mt-2 border-2 border-neutral-100/25 outline-none p-2 max-h-96"
                        value={feeInfo[feeType]?.formula}
                        onChange={(e) => onChange('formula', e.target.value)}
                        loadingComponent={() => <span>Loading</span>}
                        trigger={{
                            '{': {
                                dataProvider: (key: string) => filterFields(key),
                                component: Item,
                                output: (item: any) => '{' + item.char
                            }
                        }}
                    />
                    {validFormula?.error?.length && validFormula?.state === 'invalid' ? (
                        <label className="text-error">{validFormula.error}</label>
                    ) : (
                        <></>
                    )}
                    <div className="flex justify-end mt-3">
                        <button
                            className={`noButton btn button-primaryrate-outline ${buttonStyles[validFormula.state]} border-2 min-w-16 font-medium rounded-lg px-2 ${!feeInfo[feeType]?.formula ? 'opacity-50 cursor-default' : ''}`}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="validateFormula"
                            onClick={() => {
                                (async () => {
                                    if (!feeInfo[feeType]?.formula) return;
                                    await validateFormula(`${feeInfo[feeType].formula}`);
                                })();
                            }}>
                            {validFormula.state === 'valid' ? (
                                <i className="pi pi-check-circle text-success pr-1 text-xl" />
                            ) : validFormula.state === 'invalid' ? (
                                <i className="pi pi-exclamation-triangle text-negative-tone pr-1 text-xl" />
                            ) : (
                                <></>
                            )}
                            {validFormula.state === 'validate'
                                ? t('PV_SETTING.RATES.VALIDATE')
                                : validFormula.state === 'valid'
                                  ? t('PV_SETTING.RATES.VALID_FORMULA')
                                  : t('PV_SETTING.RATES.INVALID_FORMULA')}
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

interface EnglishTranslationEditPopup {
    formulaValue: descriptionTranslationFormula;
    resetFormulaValue?: descriptionTranslationFormula;
    formulaFields: Array<string>;
    serviceType: PVSettingsRatesKeys;
    popupID: string;
    closeModal: any;
    sourceLanguageId: number;
    requestCurrencyId: number;
    title?: string;
    isCompany?: boolean;
    companyId?: number;
    onSubmit?: () => void;
}

export const EnglishTranslationEditPopup = ({
    popupID,
    formulaValue,
    resetFormulaValue,
    formulaFields,
    serviceType,
    closeModal,
    sourceLanguageId,
    requestCurrencyId,
    title,
    isCompany = false,
    companyId,
    onSubmit = () => {}
}: EnglishTranslationEditPopup) => {
    const { t } = useTranslation();
    const [formula, setFormula] = useState<string>(`${formulaValue.formula ?? ''}`);
    const [validFormula, setValidFormula] = useState<validateFormulaTypes>({ state: 'validate' });
    const [showResetPopup, setShowResetPopup] = useState<boolean>(false);

    const Item = ({ entity: { name } }: { entity: any }) => <div>{`${name}`}</div>;
    const filterFields = (key: string) => {
        return formulaFields
            .filter((fieldName) => fieldName.toLowerCase().includes(key.toLowerCase()))
            .map((fieldName) => {
                return { name: fieldName, char: fieldName };
            });
    };

    const validateFormula = async () => {
        try {
            const usedFieldsList = utils.extractWordsBetweenCurlyBraces(formula);
            const newFieldsList =
                usedFieldsList.filter((field) => !formulaFields.includes(field.trim())) || [];

            if (newFieldsList.length > 0) {
                const invalidFields = newFieldsList.join(', ');
                const errorMessage = t('PV_SETTING.RATES.FORMULA_NEWFIELDS_ERROR', {
                    invalidFields
                });
                setValidFormula({ state: 'invalid', error: errorMessage });
                return 'invalid';
            }

            const response: any = await PVSettingsService.validateFormula(formula);
            if (response?.formulaValue?.length) {
                setValidFormula({ state: 'valid' });
                return 'valid';
            } else if (response.error?.length) {
                setValidFormula({ state: 'invalid', error: response.error });
                return 'invalid';
            }
        } catch (error) {
            setValidFormula({ state: 'invalid' });
        }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const handleSubmit = async (requestBody: TranslationFormulaUpdate) => {
        if (validFormula.state === 'validate') {
            await validateFormula();
        }

        if (validFormula.state === 'invalid') return;

        try {
            const updateFormula: FormulaUpdateResponse =
                await PVSettingsService.updateEnglishTranslationFormula(
                    requestBody,
                    isCompany,
                    companyId
                );
            if (updateFormula?.isSuccess) {
                showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType.SUCCESS);
                onSubmit();
                closeModal(TABLE_POP_IDS.CREATE_POPUP.EDIT_IP_RATES_FORMULA);
                return true;
            } else showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
        } catch (error) {
            console.error('Invalid Formula', error);
            showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
        }
    };

    const handleFormSubmit = () => {
        const requestBody: TranslationFormulaUpdate = {
            patentServiceId: PV_SETTINGS_RATES[serviceType],
            sourceLanguageId,
            requestCurrencyId,
            agencyFee: 0,
            descriptionTranslationFormula: {
                ...formulaValue,
                formula,
                fee: formulaValue.fee ?? 0,
                unitTypeId: formulaValue.unitTypeId ?? 0
            }
        };
        handleSubmit(requestBody).catch((error) => {
            console.error('Error during form submission:', error);
        });
    };

    const renderResetToDefault = () => {
        return (
            <button
                onClick={() => {
                    setShowResetPopup(true);
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                data-testid="resetToDefault"
                className="btn btn-sm my-3 border border-neutral-600 hover:border-neutral-600">
                <i className="pi pi-refresh text-primary" />
                {t('PV_SETTING.RATES.RESET_TO_DEFAULT')}
            </button>
        );
    };

    return (
        <PopupModal
            id={popupID}
            onClose={() => closeModal(TABLE_POP_IDS.CREATE_POPUP.EDIT_IP_RATES_FORMULA)}
            // title={title ?? serviceType.toUpperCase()}
            title={
                <>
                    <span className="text-xl mr-3">{title}</span>
                    <span className="text-xs mt-1 font-semibold text-neutral-200/80">
                        {`(${serviceType.toUpperCase()})`}
                    </span>
                </>
            }
            createButtonText={'Update'}
            renderCustomBtn={
                isCompany && !!resetFormulaValue?.formula ? renderResetToDefault : undefined
            }
            onSubmit={() => handleFormSubmit()}
            customReset={() => setFormula('')}
            disableSubmit={!formula}
            resetButtonText={'Clear'}
            isSubmitHide={true}
            isFormIo={false}
            isEdit={true}>
            <div className="p-4">
                {showResetPopup && isCompany && (
                    <ConfirmationPopup
                        onConfirm={() => {
                            setFormula(resetFormulaValue?.formula ?? '');
                            setShowResetPopup(false);
                        }}
                        onCancel={() => {
                            setShowResetPopup(false);
                        }}
                        visible={showResetPopup}
                        headerText={t('COMMON.CONFIRMATION')}
                        description={t('PV_SETTING.RATES.RESET_CONFIRMATION_DESCRIPTION')}
                        acceptLabel={t('PV_SETTING.RATES.RESET_CONFIRMATION_BUTTON_YES')}
                        acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                        rejectClassName="!bg-error !text-white !border-none"
                        rejectLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_NO')}
                        popupID={'resetPopup'}
                    />
                )}
                <div className="mt-3">
                    {/* Formula Text area */}
                    <div className="flex justify-between">
                        <label className="field-required" htmlFor="Formula">
                            {t('PV_SETTING.RATES.FORMULA')}
                        </label>
                        <div className="bg-warning/40 w-fit px-2 rounded border border-warning text-neutral-700 flex gap-1 items-center">
                            <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                            <label className="">
                                {t('PV_SETTING.RATES.FORMULA_TEXTAREA_NOTE')}
                            </label>
                        </div>
                    </div>
                    <ReactTextareaAutocomplete
                        className="form-control formulaEditor mt-2 outline-none p-2 max-h-96"
                        value={formula}
                        onChange={(e) => {
                            setFormula(e.target.value);
                            if (validFormula.state === 'valid' || validFormula.state === 'invalid')
                                setValidFormula({ state: 'validate' });
                        }}
                        loadingComponent={() => <span>Loading</span>}
                        trigger={{
                            '{': {
                                dataProvider: (key: string) => filterFields(key),
                                component: Item,
                                output: (item: any) => '{' + item.char
                            }
                        }}
                    />
                    {validFormula?.error?.length && validFormula?.state === 'invalid' ? (
                        <label className="text-error">{validFormula.error}</label>
                    ) : (
                        <></>
                    )}
                    <div className="flex justify-end mt-3">
                        <button
                            className={`noButton btn button-primaryrate-outline ${buttonStyles[validFormula.state]} border-2 min-w-16 font-medium rounded-lg px-2`}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="validateFormula"
                            onClick={() => {
                                (async () => {
                                    await validateFormula();
                                })();
                            }}>
                            {validFormula.state === 'valid' ? (
                                <i className="pi pi-check-circle text-success pr-1 text-xl" />
                            ) : validFormula.state === 'invalid' ? (
                                <i className="pi pi-exclamation-triangle text-negative-tone pr-1 text-xl" />
                            ) : (
                                <></>
                            )}
                            {validFormula.state === 'validate'
                                ? t('PV_SETTING.RATES.VALIDATE')
                                : validFormula.state === 'valid'
                                  ? t('PV_SETTING.RATES.VALID_FORMULA')
                                  : t('PV_SETTING.RATES.INVALID_FORMULA')}
                        </button>
                    </div>
                </div>
            </div>
        </PopupModal>
    );
};

export const AgencyFee = ({
    rowData,
    company = false,
    readOnly = false
}: {
    rowData: DataValue;
    company?: boolean;
    readOnly?: boolean;
}) => {
    const { t } = useTranslation();
    const [inputValue, setInputValue] = useState(rowData?.agencyFeeInfo ?? 0);
    const [editMode, setEditMode] = useState(false);
    useEffect(() => {
        if (inputValue !== rowData?.agencyFeeInfo) {
            setInputValue(rowData?.agencyFeeInfo);
        }
    }, [rowData]);

    const customStyles = {
        input: {
            root: {
                className: 'max-w-full border-0 h-8 rounded-none'
            }
        }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const onSave = async (requestBody: TranslationFormulaUpdate) => {
        try {
            if (company) {
                const companyData = companyStepperStore.getData();
                const { stepperInfo } = companyData;
                const companyBody: CompanyTranslationFormulaUpdate = {
                    ...requestBody,
                    companyId: stepperInfo?.primaryId ?? 0,
                    agencyFee: requestBody.agencyFee ?? 0
                };
                const results: FormulaUpdateResponse =
                    await companiesService.updateEnglishTranslationFormula(companyBody);
                if (results?.isSuccess) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType.SUCCESS);
                    setEditMode(false);
                    return true;
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
                    return true;
                }
            } else {
                const results: FormulaUpdateResponse =
                    await PVSettingsService.updateEnglishTranslationFormula(requestBody);
                if (results) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType.SUCCESS);
                    setEditMode(false);
                    return true;
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
                    return true;
                }
            }
        } catch (error) {
            console.error('Error while updating Agency fee', error);
            showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
        }
    };

    const handleFormSubmit = () => {
        const requestBody: TranslationFormulaUpdate = {
            patentServiceId: rowData?.updateValues?.patentServiceId,
            sourceLanguageId: rowData?.updateValues?.sourceLanguageId,
            requestCurrencyId: rowData?.updateValues?.requestCurrencyId,
            agencyFee: inputValue,
            descriptionTranslationFormula: {
                formula: rowData?.descriptionTranslationFormulaModel?.formula ?? '',
                fee: rowData?.descriptionTranslationFormulaModel?.fee ?? 0,
                unitTypeId: rowData?.descriptionTranslationFormulaModel?.unitTypeId ?? 0,
                feeType: rowData?.descriptionTranslationFormulaModel?.feeType ?? ''
            }
        };
        onSave(requestBody).catch((error) => {
            console.error('Error during form submission:', error);
        });
    };

    return (
        <div className={`flex items-center ${company ? 'mr-2' : ''}`}>
            <div className="flex items-center">
                <span className="mr-2 font-medium">{t('PV_SETTING.RATES.AGENCY_FEE')}</span>
                <span className="p-2 bg-neutral-100 h-[2.1rem] grid place-items-center opacity-50 whitespace-nowrap">
                    {rowData?.descriptionTranslationFormulaModel?.feeType ?? 'Flat Fee'}
                </span>
                <div
                    onClick={() => {
                        if (company ? !readOnly : true) setEditMode(true);
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    data-testid="agencyFee"
                    tabIndex={0}>
                    <InputNumber
                        pt={customStyles}
                        mode="currency"
                        currency={(rowData?.currencyData?.currencyCode as string) || 'USD'}
                        value={inputValue}
                        readOnly={!editMode || (company ? readOnly : false)}
                        className="customInputNumber mr-2"
                        onChange={(e: any) => {
                            setInputValue(+e.value);
                        }}
                    />
                </div>
            </div>
            {editMode && (
                <div className="sm:whitespace-nowrap md:whitespace-normal">
                    <button
                        onClick={() => handleFormSubmit()}
                        data-testid="saveAgencyFee"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handleFormSubmit();
                            }
                        }}>
                        <i className="pi pi-check mr-2 text-success cursor-pointer" />
                    </button>
                    <button
                        onClick={() => {
                            setEditMode(false);
                            setInputValue(rowData?.agencyFeeInfo || 0.0);
                        }}
                        data-testid="cancelAgencyFee"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                setEditMode(false);
                                setInputValue(rowData?.agencyFeeInfo || 0.0);
                            }
                        }}>
                        <i className="pi pi-times text-error cursor-pointer" />
                    </button>
                </div>
            )}
        </div>
    );
};

export const IndirectTranslationRateComponent = ({
    rowData,
    company = false,
    readOnly = false
}: {
    rowData: DataValue;
    company?: boolean;
    readOnly?: boolean;
}) => {
    const { t } = useTranslation();
    const [inputValue, setInputValue] = useState(rowData?.indirectTranslationRate ?? 0);
    const [editMode, setEditMode] = useState(false);
    useEffect(() => {
        if (inputValue !== rowData?.indirectTranslationRate) {
            setInputValue(rowData?.indirectTranslationRate);
        }
    }, [rowData]);

    const customStyles = {
        input: {
            root: {
                className: 'max-w-full border-0 h-8 rounded-none'
            }
        }
    };

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const onSave = async (requestBody: TranslationFormulaUpdate) => {
        try {
            if (company) {
                const companyData = companyStepperStore.getData();
                const { stepperInfo } = companyData;
                const companyBody: CompanyTranslationFormulaUpdate = {
                    ...requestBody,
                    companyId: stepperInfo?.primaryId ?? 0
                };
                const results: FormulaUpdateResponse =
                    await companiesService.updateEnglishTranslationFormula(companyBody);
                if (results?.isSuccess) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType.SUCCESS);
                    setEditMode(false);
                    return true;
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
                    return true;
                }
            } else {
                const results: FormulaUpdateResponse =
                    await PVSettingsService.updateEnglishTranslationFormula(requestBody);
                if (results) {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.SUCCESS'), ToastType.SUCCESS);
                    setEditMode(false);
                    return true;
                } else {
                    showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
                    return true;
                }
            }
        } catch (error) {
            console.error('Error while updating Agency fee', error);
            showToastMessage(t('COMMON.FORMULA_UPDATE.FAILED'), ToastType.ERROR);
        }
    };

    const handleFormSubmit = () => {
        const requestBody: TranslationFormulaUpdate = {
            patentServiceId: rowData?.updateValues?.patentServiceId,
            sourceLanguageId: rowData?.updateValues?.sourceLanguageId,
            requestCurrencyId: rowData?.updateValues?.requestCurrencyId,
            translationRate: inputValue,

            descriptionTranslationFormula: {
                formula: rowData?.descriptionTranslationFormulaModel?.formula ?? '',
                fee: rowData?.descriptionTranslationFormulaModel?.fee ?? 0,
                unitTypeId: rowData?.descriptionTranslationFormulaModel?.unitTypeId ?? 0,
                feeType: rowData?.descriptionTranslationFormulaModel?.feeType ?? ''
            }
        };
        onSave(requestBody).catch((error) => {
            console.error('Error during form submission:', error);
        });
    };

    return (
        <div
            className={`flex items-center ${company ? 'justify-start flex-wrap lg:flex-nowrap mx-0 mt-3' : ''}`}>
            <div className="flex items-center">
                <span className="p-2 bg-neutral-100 h-[2.1rem] grid place-items-center opacity-50 whitespace-nowrap">
                    {rowData?.descriptionTranslationFormulaModel?.feeType ?? 'Translation Rate'}
                </span>
                <div
                    onClick={() => {
                        if (company ? !readOnly : true) setEditMode(true);
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    data-testid="agencyFee"
                    tabIndex={0}>
                    <InputNumber
                        pt={customStyles}
                        mode="currency"
                        currency={rowData?.currencyData?.currencyCode ?? 'USD'}
                        value={inputValue}
                        readOnly={!editMode || (company ? readOnly : false)}
                        className="customInputNumber mr-2"
                        onChange={(e: any) => {
                            setInputValue(+e.value);
                        }}
                    />
                </div>
            </div>
            {editMode && (
                <div className="sm:whitespace-nowrap md:whitespace-normal">
                    <button
                        onClick={() => handleFormSubmit()}
                        data-testid="saveAgencyFee"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handleFormSubmit();
                            }
                        }}>
                        <i className="pi pi-check mr-2 text-success cursor-pointer" />
                    </button>
                    <button
                        onClick={() => {
                            setEditMode(false);
                            setInputValue(rowData?.indirectTranslationRate || 0.0);
                        }}
                        data-testid="cancelAgencyFee"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                setEditMode(false);
                                setInputValue(rowData?.indirectTranslationRate || 0.0);
                            }
                        }}>
                        <i className="pi pi-times text-error cursor-pointer" />
                    </button>
                </div>
            )}
        </div>
    );
};
