import { render, screen, fireEvent } from '@testing-library/react';
import UnSelectedFilterDropdown from './unSelectedFilter';

const mockOnChange = jest.fn();

const sourceLanguagesData = [
    { value: 1, label: 'English' },
    { value: 2, label: 'Spanish' }
];

const requestCurrencyData = [
    { value: 1, label: 'USD' },
    { value: 2, label: 'EUR' }
];

const targetLanguageData = [
    { value: 1, label: 'French' },
    { value: 2, label: 'German' }
];

describe('UnSelectedFilterDropdown Component', () => {
    it('renders correctly with default props', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
            />
        );

        const sourceLanguageDropdown = screen.getByTestId('source-language-dropdown');
        const requestCurrencyDropdown = screen.getByTestId('request-currency-dropdown');
        const targetLanguageDropdown = screen.getByTestId('target-language-dropdown');

        expect(sourceLanguageDropdown).toBeInTheDocument();
        expect(requestCurrencyDropdown).toBeInTheDocument();
        expect(targetLanguageDropdown).toBeInTheDocument();
    });

    it('renders correctly when isVendorTranslation is true', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
                isVendorTranslation={true}
            />
        );

        const sourceLanguageDropdown = screen.getByTestId('source-language-dropdown');
        const vendorCurrencyDropdown = screen.getByTestId('vendor-currency-dropdown');
        const targetLanguageDropdown = screen.getByTestId('target-language-dropdown');

        expect(sourceLanguageDropdown).toBeInTheDocument();
        expect(vendorCurrencyDropdown).toBeInTheDocument();
        expect(targetLanguageDropdown).toBeInTheDocument();
    });

    it.skip('calls onChange when request currency is selected', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
            />
        );

        const requestCurrencyDropdown = screen.getByTestId('request-currency-dropdown');
        fireEvent.change(requestCurrencyDropdown, {
            target: { value: 1 }
        });

        expect(mockOnChange).toHaveBeenCalledTimes(1);
        expect(mockOnChange).toHaveBeenCalledWith({ requestCurrency: 1 });
    });

    it.skip('calls onChange when target language is selected', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
            />
        );

        const targetLanguageDropdown = screen.getByTestId('target-language-dropdown');
        fireEvent.change(targetLanguageDropdown, {
            target: { value: 1 }
        });

        expect(mockOnChange).toHaveBeenCalledTimes(1);
        expect(mockOnChange).toHaveBeenCalledWith({ targetLanguage: 1 });
    });

    it.skip('renders correctly with translations', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
            />
        );

        const sourceLanguagePlaceholder = screen.getByPlaceholderText('Source Language');
        const requestCurrencyPlaceholder = screen.getByPlaceholderText('Request Currency');
        const targetLanguagePlaceholder = screen.getByPlaceholderText('Target Language');

        expect(sourceLanguagePlaceholder).toBeInTheDocument();
        expect(requestCurrencyPlaceholder).toBeInTheDocument();
        expect(targetLanguagePlaceholder).toBeInTheDocument();
    });

    it.skip('renders correctly with vendor currency when isVendorTranslation is true', () => {
        render(
            <UnSelectedFilterDropdown
                sourceLanguagesData={sourceLanguagesData}
                requestCurrencyData={requestCurrencyData}
                targetLanguageData={targetLanguageData}
                onChange={mockOnChange}
                isVendorTranslation={true}
            />
        );

        const vendorCurrencyPlaceholder = screen.getByPlaceholderText('Vendor Currency');
        expect(vendorCurrencyPlaceholder).toBeInTheDocument();
    });
});
