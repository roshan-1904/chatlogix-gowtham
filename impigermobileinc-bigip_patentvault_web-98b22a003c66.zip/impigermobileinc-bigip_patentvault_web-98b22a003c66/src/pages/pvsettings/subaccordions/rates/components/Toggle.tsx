import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { InputSwitch } from 'primereact/inputswitch';
import { inputSwitchPT } from 'constants/styles.constant';
import { DataValue } from 'shared/dataTable/types/dataTable.types';

export interface ToggleEditProps {
    rowData: DataValue;
    fieldName: string;
    valueKey: string;
    editCell: (rowData: DataValue, fieldName: string, updatedValue?: number) => void;
    readOnly: boolean;
}
export default function Toggle({
    fieldName,
    rowData,
    readOnly,
    editCell,
    valueKey
}: Readonly<ToggleEditProps>) {
    const onSave = (value: boolean) => {
        try {
            editCell(rowData, fieldName, value ? 1 : 0);
            // setChecked(value);
        } catch (error: any) {
            showToastMessage({ message: error?.message, type: ToastType.ERROR });
        }
    };

    return (
        <>
            <div className="card flex justify-content-center">
                <InputSwitch
                    checked={valueKey in rowData ? Boolean(rowData[valueKey]) : false}
                    onChange={(e) => onSave(e.value)}
                    pt={inputSwitchPT}
                    disabled={readOnly}
                />
            </div>
        </>
    );
}
