import { useEffect, useLayoutEffect, useState } from 'react';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    breakDownComponentProps,
    breakdownProps,
    breakdownValues,
    companyDetailRateRequestBody,
    companyTranslations,
    directFeeRequestBody,
    editFormulaModalInitialValues,
    filterRequestModelType,
    IPRatesResponseType,
    listingDetailsList,
    paginationType,
    RatesListingResponseType,
    TableComponent
} from '../../types/pvsettings.types';
import { DataTableDefinition, DataValue } from 'shared/dataTable/types/dataTable.types';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import { useTranslation } from 'react-i18next';
import {
    PREFERRED_CURRENCY_MODULES_NAME,
    PV_SETTINGS_RATES,
    RATE_INLINE_EDIT_FIELDS,
    SOURCE_LANGUAGE_ID,
    TRANSLATION_MODULES
} from '../rates.const';
import PVSettingsService from '../../service/pvsettings.service';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { AddCountries, EditFormulaPopup } from './addCountriesPopup';
import { DATA_STORAGE_KEYS, TABLE_POP_IDS } from 'constants/dataTable.constant';
import { CompanyRatesResponseType } from 'pages/companies/types/createCompany.types';
import companiesService from 'pages/companies/service/companies.service';
import companyStepperStore from 'core/store/stepperStore/companyStore/company.store';
import CompanyTranslationsEditPopup from './companyTranslationsEditPopup';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { extractNumber, showToastMessage, toggleLoadingIndicator } from 'core/utils/utils';
import { Breakdown } from 'pages/users/types/users.types';
import FieldValue from 'components/inputs/fieldValue.label';

export default function TableData({
    sourceLanguageId,
    requestCurrencyId,
    columnSchema,
    moduleName,
    company = false,
    listingData,
    setListingData,
    unitOptionsValues,
    FormulaFields,
    expandedRows,
    readOnly,
    targetLanguage,
    serviceType,
    getPreferredCurrency,
    localStorageKey,
    isEnglishTranslationUpdated = false,
    activeIndex,
    leftHeaderSection
}: Readonly<TableComponent>) {
    const { t } = useTranslation();
    const [paginationInfo, setPaginationInfo] = useState<paginationType>();
    const [showModal, setShowModal] = useState(false);
    const data = companyStepperStore?.getData?.() || {};
    const { stepperInfo } = data;
    const [isApiFetching, setIsApiFetching] = useState(false);
    const hasCountry = columnSchema?.some(({ field }) => field === 'countryName');
    const {
        TRANSLATION_RATE,
        COMPANY_TRANSLATION_RATE,
        AI_TRANSLATION_RATE,
        COMPANY_AI_TRANSLATION_RATE,
        AI_TR_DIFFERENCE,
        AI_TR_DIFFERENCE_PERCENT,
        IS_AI_TRANSLATION
    } = RATE_INLINE_EDIT_FIELDS;
    const [globalBreakdownValues, setGlobalBreakdownValues] = useState<Breakdown[]>([]);
    const [showDeletePopup, setShowDeletePopup] = useState({
        visible: false,
        header: '',
        description: '',
        id: 0
    });
    const [showResetPopup, setShowResetPopup] = useState({
        visible: false,
        header: '',
        description: '',
        id: 0
    });

    const [editFormulaModal, setEditFormulaModal] = useState<editFormulaModalInitialValues>({
        opened: false,
        title: {
            countryIcon: null,
            countryName: null
        },
        rowData: {},
        feeType: '',
        editMode: false
    });

    const [showGroupedCountryPopup, setShowGroupedCountryPopup] = useState<{
        visible: boolean;
        postBody: directFeeRequestBody | companyDetailRateRequestBody;
        description?: JSX.Element;
        isTranslationRate?: boolean;
        isAITranslationRate?: boolean;
    }>({
        visible: false,
        postBody: {} as directFeeRequestBody,
        description: <></>
    });
    const defaultEditCTFormulaModal: editFormulaModalInitialValues = {
        opened: false,
        title: {
            countryIcon: null,
            countryName: null
        },
        rowData: {},
        feeType: '',
        editMode: false
    };
    const [editCTFormulaModal, setEditCTFormulaModal] =
        useState<editFormulaModalInitialValues>(defaultEditCTFormulaModal);

    const [requestBody, setRequestBody] = useState<IPRatesResponseType>({
        patentServiceId: TRANSLATION_MODULES.includes(moduleName)
            ? 0
            : PV_SETTINGS_RATES[moduleName],
        sourceLanguageId: sourceLanguageId ?? 0,
        requestCurrencyId: requestCurrencyId ?? 0,
        targetLanguageId: 0,
        filterRequestModel: {
            searchModels: [
                {
                    propertyName: '',
                    value: ''
                }
            ],
            sorting: {
                propertyName: hasCountry ? 'countryName' : '',
                value: hasCountry ? 'asc' : ''
            },
            pageNo: 1,
            pageCount: 10
        }
    });

    const [companyRequestBody, setCompanyRequestBody] = useState<CompanyRatesResponseType>({
        patentServiceId: TRANSLATION_MODULES.includes(moduleName)
            ? 0
            : PV_SETTINGS_RATES[moduleName],
        sourceLanguageId: sourceLanguageId ?? 0,
        requestCurrencyId: requestCurrencyId ?? 0,
        targetLanguageId: 0,
        companyId: stepperInfo?.primaryId ? stepperInfo.primaryId : 0,
        filterRequestModel: {
            searchModels: [
                {
                    propertyName: '',
                    value: ''
                }
            ],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        }
    });

    const [companyTranslationRequestBody, setCompanyTranslationRequestBody] = useState<
        Omit<CompanyRatesResponseType, 'patentServiceId'>
    >({
        sourceLanguageId: sourceLanguageId ?? 0,
        requestCurrencyId: requestCurrencyId ?? 0,
        targetLanguageId: targetLanguage ?? 0,
        filterRequestModel: {
            searchModels: [
                {
                    propertyName: '',
                    value: ''
                }
            ],
            sorting: {
                propertyName: '',
                value: ''
            },
            pageNo: 1,
            pageCount: 10
        }
    });

    const buttonChildren = () => {
        return company ? (
            <div>
                {TRANSLATION_MODULES.includes(moduleName) ? (
                    <></>
                ) : (
                    !readOnly && (
                        <button
                            onClick={() => {
                                setShowResetPopup({
                                    visible: true,
                                    header: t('COMMON.CONFIRMATION'),
                                    description: t(
                                        'PV_SETTING.RATES.RESET_CONFIRMATION_DESCRIPTION'
                                    ),
                                    id: 0
                                });
                            }}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="resetToDefault"
                            className="btn min-h-10 h-10 border-neutral-100">
                            <i className="pi pi-refresh text-primary"></i>
                            {t('PV_SETTING.RATES.RESET_TO_DEFAULT')}
                        </button>
                    )
                )}
            </div>
        ) : TRANSLATION_MODULES.includes(moduleName) ? (
            <button
                onClick={() => {
                    setEditCTFormulaModal({
                        ...editCTFormulaModal,
                        opened: true,
                        title: { countryIcon: null, countryName: null },
                        rowData: {},
                        feeType: '',
                        editMode: false
                    });
                    openModal(TABLE_POP_IDS.CREATE_POPUP.COMPANY_TRANSLATIONS);
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                data-testid="addCompanyTranslations"
                disabled={!TRANSLATION_MODULES.includes(moduleName)}
                className="btn min-h-[2.65rem] h-[2.65rem] text-white bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE')}
            </button>
        ) : (
            <div className="flex items-center gap-2">
                <button
                    onClick={() => {
                        openModal(TABLE_POP_IDS.CREATE_POPUP.ADD_COUNTRY);
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    data-testid="addCountry"
                    disabled={false}
                    className="btn min-h-[2.65rem] h-[2.65rem] text-white bg-primary hover:bg-primary-200">
                    <i className="pi pi-plus-circle"></i>
                    {t('PV_SETTING.RATES.ADD_COUNTRY')}
                </button>
            </div>
        );
    };

    const closeModal = (popupId: string) => {
        setShowModal(false);
        setEditCTFormulaModal(defaultEditCTFormulaModal);
        const modal: HTMLDialogElement | null = document.getElementById(
            popupId
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const openModal = async (popupId: string) => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            popupId
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const tableDefinition: DataTableDefinition = {
        title: '',
        filters: {},
        reOrderableColumns: !!company,
        tableType: TableTypes.CURRENCY_EXCHANGE_RATES,
        emptyMessage: '',
        localStorageKey: company
            ? localStorageKey || DATA_STORAGE_KEYS?.DATA_TABLE?.RATES?.[moduleName]
            : '',
        ...(company && { columnSelectorStyle: 'tableCustomHeight right-1' }),
        showFilter: false,
        tableCustomStyle: 'p-0 !pt-0',
        hideTableExport: false,
        buttonChildren: buttonChildren(),
        columns: columnSchema,
        hideColumnSelector: !company,
        leftHeaderSection
    };

    const getTableRequestBodyData = () => {
        if (company) {
            if (TRANSLATION_MODULES.includes(moduleName)) {
                return companyTranslationRequestBody.filterRequestModel;
            } else {
                return companyRequestBody.filterRequestModel;
            }
        } else if (TRANSLATION_MODULES.includes(moduleName)) {
            return companyTranslationRequestBody.filterRequestModel;
        } else {
            return requestBody.filterRequestModel;
        }
    };

    const handlePageUpdate = (updatedPage: filterRequestModelType) => {
        if (company) {
            if (TRANSLATION_MODULES.includes(moduleName)) {
                setCompanyTranslationRequestBody({
                    ...companyTranslationRequestBody,
                    filterRequestModel: updatedPage,
                    companyId: stepperInfo?.primaryId ? stepperInfo.primaryId : 0
                });
                getCompanyTranslations(updatedPage);
            } else
                setCompanyRequestBody({
                    ...companyRequestBody,
                    filterRequestModel: updatedPage,
                    companyId: stepperInfo?.primaryId ? stepperInfo.primaryId : 0
                });
        } else if (TRANSLATION_MODULES.includes(moduleName)) {
            setCompanyTranslationRequestBody({
                ...companyTranslationRequestBody,
                filterRequestModel: updatedPage
            });
            getCompanyTranslations(updatedPage);
        } else setRequestBody({ ...requestBody, filterRequestModel: updatedPage });
    };

    const getCompanyTranslations = async (paginationFilter?: any) => {
        try {
            if (!isApiFetching) {
                if (company) {
                    const response: RatesListingResponseType =
                        await PVSettingsService.getCompanyLevelTranslationsData(
                            paginationFilter
                                ? {
                                      ...companyRequestBody,
                                      sourceLanguageId: sourceLanguageId ?? 0,
                                      requestCurrencyId: requestCurrencyId ?? 0,
                                      targetLanguageId: targetLanguage ?? 0,
                                      filterRequestModel: paginationFilter
                                  }
                                : {
                                      ...companyRequestBody,
                                      sourceLanguageId: sourceLanguageId ?? 0,
                                      requestCurrencyId: requestCurrencyId ?? 0,
                                      targetLanguageId: targetLanguage ?? 0
                                  }
                        );
                    const structuredResponse = {
                        companyRateDetailList: response.companyLevelTranslationRatesList ?? []
                    };
                    setListingData(structuredResponse);
                    const pagination: paginationType = {
                        pageNo: response.pageNo ?? 2,
                        totalPages: response.totalPages ?? 4,
                        totalRecords: response.totalCount ?? 40
                    };
                    setPaginationInfo(pagination);
                } else {
                    const response: any = await PVSettingsService.getCompanyTranslationsData(
                        paginationFilter
                            ? {
                                  ...companyTranslationRequestBody,
                                  sourceLanguageId,
                                  targetLanguageId: Number(targetLanguage ?? 0),
                                  requestCurrencyId: Number(requestCurrencyId ?? 0),
                                  filterRequestModel: paginationFilter
                              }
                            : {
                                  ...companyTranslationRequestBody,
                                  sourceLanguageId,
                                  targetLanguageId: Number(targetLanguage ?? 0),
                                  requestCurrencyId: Number(requestCurrencyId ?? 0)
                              },
                        moduleName
                    );
                    const structuredResponse = {
                        ipRateDetailList:
                            moduleName === 'companytranslations'
                                ? (response.companyTranslationRatesList ?? [])
                                : (response.vendorTranslationRatesList ?? [])
                    };
                    setListingData(structuredResponse);
                    const pagination: paginationType = {
                        pageNo: response.pageNo ?? 2,
                        totalPages: response.totalPages ?? 4,
                        totalRecords: response.totalCount ?? 40
                    };
                    setPaginationInfo(pagination);
                }
                toggleLoadingIndicator(true);
                setIsApiFetching(false);
            }
        } catch (error) {
            let msg = 'GET_IP_RATES_DATA';
            if (TRANSLATION_MODULES.includes(moduleName)) {
                msg =
                    moduleName === 'companytranslations'
                        ? 'GET_COMPANY_TRANSLATION_RATES_DATA'
                        : 'GET_VENDOR_TRANSLATION_RATES_DATA';
            }
            showToastMessage({
                message: t(`PV_SETTING.RATES.ERROR_MESSAGE.${msg}`),
                type: ToastType?.ERROR
            });
        }
    };

    const getIPRates = async () => {
        setIsApiFetching(true);
        if (TRANSLATION_MODULES.includes(moduleName) || [5, 6]?.includes(+activeIndex)) {
            getCompanyTranslations();
        } else {
            try {
                let response: RatesListingResponseType = {
                    ipRateDetailList: [],
                    agencyFeeInfo: 0,
                    companyRateDetailList: [],
                    companyLevelTranslationRatesList: [],
                    companyTranslationRatesList: [],
                    pageNo: 0,
                    totalCount: 0,
                    descriptionTranslationFormulaModel: {
                        feeType: '',
                        unitTypeId: 0,
                        formula: '',
                        fee: 0
                    },
                    currencyData: {
                        currencyCode: '',
                        currencyId: 0,
                        currencyName: '',
                        currencySymbol: ''
                    },
                    totalPages: 0
                };
                if (company) {
                    response = await companiesService.getIPRequestData({
                        ...companyRequestBody,
                        sourceLanguageId: sourceLanguageId ?? 0,
                        requestCurrencyId: requestCurrencyId ?? 0
                    });
                    const filteredResponse = response.companyRateDetailList?.map(
                        (listingDetail: any) => {
                            return {
                                ...listingDetail,
                                translationRate: listingDetail.translationRate
                                    ? `${response.currencyData.currencySymbol} ${(+listingDetail.translationRate || 0)?.toFixed(2)}`
                                    : null,
                                translationRateNumber: listingDetail?.translationRate,
                                // companyTranslationRate: listingDetail.companyTranslationRate
                                //     ? `${response.currencyData.currencySymbol} ${listingDetail.companyTranslationRate === 0 ? '0.00' : (+listingDetail.companyTranslationRate || 0)?.toFixed(2)}`
                                //     : null,
                                companyTranslationRateNumber: listingDetail.companyTranslationRate,
                                requestCurrency: response.currencyData.currencyCode,
                                currencySymbol: response.currencyData.currencySymbol ?? null,
                                engIndirectTranslationRate: `${response.currencyData.currencySymbol} ${(+listingDetail.engIndirectTranslationRate || 0)?.toFixed(2)}`,
                                engIndirectTranslationRateNumber:
                                    listingDetail.engIndirectTranslationRate,
                                companyEngIndirectTranslationRate: `${response.currencyData.currencySymbol} ${(+listingDetail.companyEngIndirectTranslationRate || 0)?.toFixed(2)}`,
                                companyEngIndirectTranslationRateNumber:
                                    listingDetail.companyEngIndirectTranslationRate
                            };
                        }
                    );
                    const responseDetail: RatesListingResponseType = {
                        ...response,
                        companyRateDetailList: filteredResponse
                    };
                    setListingData(responseDetail);
                    if (PREFERRED_CURRENCY_MODULES_NAME.includes(moduleName))
                        getPreferredCurrency();
                    const pagination: paginationType = {
                        pageNo: response.pageNo ?? 2,
                        totalPages: response.totalPages ?? 4,
                        totalRecords: response.totalCount ?? 40
                    };
                    setPaginationInfo(pagination);
                    setIsApiFetching(false);
                } else {
                    response = await PVSettingsService.getIPRequestData({
                        ...requestBody,
                        sourceLanguageId: sourceLanguageId ?? 0,
                        requestCurrencyId: requestCurrencyId ?? 0
                    });
                    const filteredResponse = response.ipRateDetailList?.map(
                        (listingDetail: any) => {
                            return {
                                ...listingDetail,
                                translationRate: `${response.currencyData.currencySymbol} ${(+listingDetail.translationRate || 0)?.toFixed(2)}`,
                                requestCurrency: response.currencyData.currencyCode,
                                // companyTranslationRate: listingDetail.companyTranslationRate
                                //     ? `${response.currencyData.currencySymbol} ${listingDetail.companyTranslationRate === 0 ? '0.00' : listingDetail.companyTranslationRate}`
                                //     : null,
                                currencySymbol: response.currencyData.currencySymbol ?? null,
                                descriptionTranslationFormulaModel: response
                                    .descriptionTranslationFormulaModel.formula
                                    ? `${response.descriptionTranslationFormulaModel.formula}`
                                    : null,
                                engIndirectTranslationRate: `${response.currencyData.currencySymbol} ${(+listingDetail.engIndirectTranslationRate || 0)?.toFixed(2)}`,
                                translationRateNumber: listingDetail?.translationRate,
                                engIndirectTranslationRateNumber:
                                    listingDetail.engIndirectTranslationRate
                            };
                        }
                    );
                    const responseDetail: RatesListingResponseType = {
                        ...response,
                        ipRateDetailList: filteredResponse
                    };
                    setListingData(responseDetail);
                    setIsApiFetching(false);
                }
                const pagination: paginationType = {
                    pageNo: response.pageNo ?? 2,
                    totalPages: response.totalPages ?? 4,
                    totalRecords: response.totalCount ?? 40
                };
                setPaginationInfo(pagination);
            } catch (error) {
                if (company) setListingData({ ...listingData, companyRateDetailList: [] });
                else setListingData({ ...listingData, ipRateDetailList: [] });
                showToastMessage({
                    message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_IP_RATES_DATA'),
                    type: ToastType?.ERROR
                });
            }
        }
    };

    useLayoutEffect(() => {
        if (
            TRANSLATION_MODULES.includes(moduleName) ||
            (((requestBody.sourceLanguageId !== 0 && requestBody.requestCurrencyId !== 0) ||
                (companyRequestBody.sourceLanguageId !== 0 &&
                    companyRequestBody.requestCurrencyId !== 0 &&
                    !isApiFetching)) &&
                !isApiFetching)
        ) {
            getIPRates();
        }
    }, [
        requestBody,
        companyRequestBody,
        sourceLanguageId,
        targetLanguage,
        requestCurrencyId,
        isEnglishTranslationUpdated,
        moduleName,
        activeIndex
    ]);

    const formatBreakdownData = (breakdownData: any) => {
        return breakdownData.map((breakdowns: any) => {
            const percentageValue =
                moduleName === 'companytranslations'
                    ? breakdowns.companyPercentage
                    : breakdowns.vendorPercentage;
            return {
                value: percentageValue,
                id: breakdowns.id,
                breakdownName: breakdowns.breakdownName,
                vendorPercentage: percentageValue
            };
        });
    };

    useEffect(() => {
        const fetchBreakdowns = async () => {
            try {
                const breakdownResponse: any = await PVSettingsService.getBreakdowns();
                setGlobalBreakdownValues(
                    formatBreakdownData(breakdownResponse || []) as Breakdown[]
                );
            } catch (error) {
                console.error('Error fetching breakdowns data:', error);
            }
        };
        if (TRANSLATION_MODULES.includes(moduleName) || [5, 6]?.includes(+activeIndex)) {
            fetchBreakdowns();
        }
    }, [activeIndex]);
    const updateRequestBody = (body: any, setBody: (body: any) => void) => {
        setBody({
            ...body,
            sourceLanguageId: sourceLanguageId ?? 0,
            requestCurrencyId: requestCurrencyId ?? 0
        });
    };

    useLayoutEffect(() => {
        const updateTranslationRequestBody = () => {
            setCompanyTranslationRequestBody({
                ...companyTranslationRequestBody,
                sourceLanguageId: sourceLanguageId !== -1 ? Number(sourceLanguageId ?? 0) : 0,
                requestCurrencyId: requestCurrencyId !== -1 ? Number(requestCurrencyId ?? 0) : 0,
                targetLanguageId: targetLanguage !== -1 ? Number(targetLanguage ?? 0) : 0
            });
        };

        if (sourceLanguageId !== 0 && requestCurrencyId !== 0) {
            if (company) {
                updateRequestBody(companyRequestBody, setCompanyRequestBody);
            } else {
                updateRequestBody(requestBody, setRequestBody);
            }

            if (TRANSLATION_MODULES.includes(moduleName)) {
                updateTranslationRequestBody();
            }
        }
    }, [sourceLanguageId, requestCurrencyId, targetLanguage]);

    const updateTranslationRate = async (
        postBody: directFeeRequestBody,
        isTranslationRate: boolean
    ) => {
        try {
            const updateDetails = await PVSettingsService.updateIpRateDetail(postBody);
            if (updateDetails) {
                showToastMessage({
                    message: t(
                        `PV_SETTING.RATES.SUCCESS_MESSAGE.${
                            isTranslationRate
                                ? 'UPDATE_TRANSLATION_RATE'
                                : 'UPDATE_AI_TRANSLATION_RATE'
                        }`
                    ),
                    type: ToastType.SUCCESS
                });
                showGroupedCountryPopup.visible &&
                    setShowGroupedCountryPopup({
                        visible: false,
                        postBody: {} as directFeeRequestBody,
                        description: <></>
                    });
                getIPRates();
            }
        } catch {
            showToastMessage({
                message: t(
                    `PV_SETTING.RATES.ERROR_MESSAGE.${isTranslationRate ? 'UPDATE_TRANSLATION_RATE' : 'UPDATE_AI_TRANSLATION_RATE'}`
                ),
                type: ToastType?.ERROR
            });
        }
    };

    const updateCompanyInlineFields = async (
        postBody: companyDetailRateRequestBody,
        translateMsg = 'UPDATE_COMPANY_ENG_INDIRECT_TRANSLATION_RATE'
    ) => {
        try {
            const updateCompanyDetails = await PVSettingsService.updateCompanyRateDetail(postBody);
            if (updateCompanyDetails) {
                showToastMessage({
                    message: t(`PV_SETTING.RATES.SUCCESS_MESSAGE.${translateMsg}`),
                    type: ToastType.SUCCESS
                });
                setShowGroupedCountryPopup({
                    visible: false,
                    postBody: {} as directFeeRequestBody
                });
                getIPRates();
            }
        } catch {
            setShowGroupedCountryPopup({
                visible: false,
                postBody: {} as directFeeRequestBody
            });
            showToastMessage({
                message: t(`PV_SETTING.RATES.ERROR_MESSAGE.${translateMsg}`),
                type: ToastType?.ERROR
            });
        }
    };

    const validateIpRatesAiTranslationRate = (
        rowData: DataValue,
        value: number,
        id: keyof listingDetailsList
    ) => {
        if (value < 0) {
            throw new Error(t('COMMON.NEGATIVE_INPUT_ERROR'));
        }

        rowData = {
            ...rowData,
            translationRate: company
                ? extractNumber(rowData.companyTranslationRateNumber)
                : extractNumber(rowData.translationRate),
            engIndirectTranslationRate: company
                ? extractNumber(rowData.companyEngIndirectTranslationRateNumber)
                : extractNumber(rowData.engIndirectTranslationRate),
            aiTranslationRate: company
                ? extractNumber(rowData.aiCompanyTranslationRate)
                : extractNumber(rowData.aiTranslationRate)
        };

        id = id.replace('companyTranslationRate', 'translationRate') as keyof listingDetailsList;
        id = id.replace(
            'companyEngIndirectTranslationRate',
            'engIndirectTranslationRate'
        ) as keyof listingDetailsList;
        id = id.replace(
            'aiCompanyTranslationRate',
            'aiTranslationRate'
        ) as keyof listingDetailsList;

        const ids = [
            TRANSLATION_RATE,
            AI_TRANSLATION_RATE,
            AI_TR_DIFFERENCE,
            AI_TR_DIFFERENCE_PERCENT
        ];

        const newVal = value ?? 0;
        const translationRate = Number(rowData.translationRate ?? 0);
        const isTranslationRate = id === TRANSLATION_RATE;
        const isAiTranslationRate = id === AI_TRANSLATION_RATE;
        const isTrAiTrDifferencePercent = id === AI_TR_DIFFERENCE_PERCENT;
        const isTrAiTrDifference = id === AI_TR_DIFFERENCE;

        if (isTranslationRate && !rowData.isAiTranslation) {
            return true;
        }

        if (
            moduleName !== 'claims' &&
            id === IS_AI_TRANSLATION &&
            ((rowData.isDirectTranslation === false
                ? !rowData.aiEngIndirectTranslationRate
                : !rowData.aiTranslationRate) ||
                (rowData.isDirectTranslation === false
                    ? rowData.aiEngIndirectTranslationRate
                    : rowData.aiTranslationRate) === 0) &&
            newVal === 1
        ) {
            throw new Error(t('PV_SETTING.RATES.AI_TRANSLATION_RATE_REQUIRED_TO_ENABLE_AI_MODE'));
        } else if (moduleName === 'claims' && newVal === 1) {
            const listData = company
                ? listingData.companyRateDetailList
                : listingData?.ipRateDetailList;
            const otherLanguageData = listData.find((s) => s.languageId !== rowData.languageId);

            if (id === IS_AI_TRANSLATION && !rowData.aiTranslationRate && newVal === 1) {
                throw new Error(
                    t('PV_SETTING.RATES.AI_TRANSLATION_RATE_REQUIRED_TO_ENABLE_AI_MODE')
                );
            }

            if (otherLanguageData) {
                if (
                    company
                        ? !otherLanguageData.aiCompanyTranslationRate
                        : !otherLanguageData.aiTranslationRate
                ) {
                    throw new Error(
                        t(
                            'PV_SETTING.RATES.ERROR_MESSAGE.ANOTHER_LANGUAGE_TRANSLATION_NOT_CONFIGURED',
                            {
                                TARGET_LANGUAGE: otherLanguageData.targetLanguage || ''
                            }
                        )
                    );
                }
            }
        } else if (id === IS_AI_TRANSLATION && newVal === 0) {
            return true;
        }

        if (
            id === IS_AI_TRANSLATION &&
            rowData.aiTranslationRate >= rowData.translationRate &&
            newVal === 1
        ) {
            throw new Error(
                t('PV_SETTING.RATES.AI_TRANSLATION_RATE_SHOULD_BE_LESS_THAN_TRANSLATION_RATE', {
                    COMPANY: company ? 'Company' : ''
                })
            );
        }

        if (!ids.includes(id)) return true;

        if (isTranslationRate && newVal <= rowData.aiTranslationRate) {
            throw new Error(
                t('PV_SETTING.RATES.TRANSLATION_RATE_LESS_THAN_AI_TRANSLATION_RATE', {
                    COMPANY: company ? 'Company' : ''
                })
            );
        }

        if (isAiTranslationRate && newVal === 0) {
            throw new Error(
                t('PV_SETTING.RATES.AI_TRANSLATION_RATE_GREATER_THAN_ZERO', {
                    COMPANY: company ? 'Company' : ''
                })
            );
        }

        if (
            (isTrAiTrDifferencePercent && newVal > 100) ||
            (isTrAiTrDifference && translationRate === newVal)
        ) {
            throw new Error(
                t(
                    'PV_SETTING.RATES.AI_TRANSLATION_RATE_NOT_ZERO_OR_GREATER_THAN_TRANSLATION_RATE',
                    {
                        COMPANY: company ? 'Company' : ''
                    }
                )
            );
        }

        if (
            (!isTranslationRate && newVal === translationRate) ||
            translationRate - newVal === translationRate
        ) {
            throw new Error(
                t('PV_SETTING.RATES.AI_TRANSLATION_RATE_NOT_EQUAL_TO_TRANSLATION_RATE', {
                    COMPANY: company ? 'Company' : ''
                })
            );
        }

        if (!isTrAiTrDifferencePercent && !isTranslationRate && translationRate < newVal) {
            throw new Error(
                t('PV_SETTING.RATES.AI_TRANSLATION_RATE_CANNOT_BE_GREATER_THAN_TRANSLATION_RATE', {
                    COMPANY: company ? 'Company' : ''
                })
            );
        }

        if (
            isTrAiTrDifferencePercent &&
            Number((translationRate - (newVal / 100) * translationRate).toFixed(4)) === 0
        ) {
            throw new Error(
                t(
                    'PV_SETTING.RATES.AI_TRANSLATION_RATE_CANNOT_BE_ZERO_OR_GREATER_THAN_TRANSLATION_RATE',
                    {
                        COMPANY: company ? 'Company' : '',
                        ENGLISH_INDIRECT: isTrAiTrDifferencePercent ? '' : 'English Indirect'
                    }
                )
            );
        }
        return true;
    };

    const handleGroupedCountriesUpdate = async (
        postBody: directFeeRequestBody | companyDetailRateRequestBody,
        rowData: DataValue,
        isTranslationRate: boolean,
        isAITranslationRate: boolean
    ) => {
        try {
            const updateDetails: {
                name: string;
                iconName: string;
                id: number;
            }[] = await PVSettingsService.getGroupedCountries(
                requestBody?.patentServiceId ?? 0,
                (postBody?.groupId as number) ?? 0
            );
            if (updateDetails) {
                setShowGroupedCountryPopup({
                    visible: true,
                    postBody,
                    description: (
                        <div className="flex flex-col gap-2 [&>p]:leading-6">
                            <p>
                                {`You have updated the ${isTranslationRate ? 'Translation Rate' : 'AI Translation Rate/Mode'} for`}{' '}
                                <span className="font-medium">{rowData?.countryName}.</span>
                            </p>
                            <p className="flex flex-col justify-center items-center">
                                This change will also apply to all countries with the same target
                                language{' '}
                                <span className="font-medium">{rowData?.languageName}.</span>
                                <div
                                    className={`flex flex-wrap gap-2 justify-center mt-3.5 mb-6 p-3 rounded-lg max-h-40 overflow-y-auto  ${updateDetails.length > 1 ? ' border bg-lightBlue/15 border-primary/30 w-auto' : ''}`}>
                                    {updateDetails
                                        .filter((country) => country.id !== rowData.countryId)
                                        .map((country) => (
                                            <div
                                                key={country.name}
                                                data-testid="dataTable-FlagText-format"
                                                className="flex items-center w-fit text-midnight-blue bg-pale-blue border-soft-blue border p-[0px] px-2 rounded-[3px] font-medium text-sm py-1">
                                                <div
                                                    className={`h-[1rem] w-[1rem] rounded-full border overflow-hidden bg-no-repeat bg-center mr-2`}
                                                    style={{
                                                        backgroundImage:
                                                            'url(/images/country-flags/' +
                                                            (country.iconName ?? '') +
                                                            ')',
                                                        backgroundSize: '150%'
                                                    }}></div>
                                                {country.name}
                                            </div>
                                        ))}
                                </div>
                                <p className="text-[1.02rem]">
                                    Please confirm you want to update the rate for all these
                                    countries.
                                </p>
                            </p>
                        </div>
                    ),
                    isTranslationRate,
                    isAITranslationRate
                });
            }
        } catch (error) {
            throw new Error('Error fetching grouped countries data');
        }
    };

    const EditFormula = (rowData: DataValue, fieldName: string, updatedValue?: number) => {
        if (rowData) {
            rowData = {
                ...rowData,
                translationRateNumber: company
                    ? extractNumber(rowData?.companyTranslationRate)
                    : extractNumber(rowData?.translationRateNumber),
                engIndirectTranslationRateNumber: company
                    ? extractNumber(rowData?.companyEngIndirectTranslationRate)
                    : extractNumber(rowData?.engIndirectTranslationRate),
                aiTranslationRate: company
                    ? extractNumber(rowData?.aiCompanyTranslationRate)
                    : extractNumber(rowData?.aiTranslationRate)
            };

            // Ai Translation Rate Related Fields
            const isTranslationRate = company
                ? fieldName === COMPANY_TRANSLATION_RATE
                : fieldName === TRANSLATION_RATE;
            const isAITranslationRate = company
                ? fieldName === COMPANY_AI_TRANSLATION_RATE
                : fieldName === AI_TRANSLATION_RATE;
            const isAITrDifference = fieldName === AI_TR_DIFFERENCE;
            const isAITrDifferencePercent = fieldName === AI_TR_DIFFERENCE_PERCENT;
            const isIsAiTranslation = fieldName === IS_AI_TRANSLATION;

            // company related fields
            const companyRateFields = [
                COMPANY_TRANSLATION_RATE,
                COMPANY_AI_TRANSLATION_RATE,

                AI_TR_DIFFERENCE,
                AI_TR_DIFFERENCE_PERCENT,
                IS_AI_TRANSLATION
            ];

            const isCompanyRateField = companyRateFields.includes(fieldName);

            const isAITranslationRateFields =
                isAITranslationRate ||
                isAITrDifference ||
                isAITrDifferencePercent ||
                isIsAiTranslation;

            const translationRate = isTranslationRate
                ? updatedValue
                : rowData.translationRateNumber;

            const aiTranslationRate = isAITranslationRate
                ? updatedValue
                : isAITrDifference
                  ? rowData.translationRateNumber - (updatedValue ?? 0)
                  : isAITrDifferencePercent
                    ? rowData.translationRateNumber -
                          ((updatedValue ?? 0) / 100) * rowData.translationRateNumber || 0
                    : rowData.aiTranslationRate;

            const toFixed = (val: any, decimals: number) =>
                typeof val === 'number' ? Number(val.toFixed(decimals ?? 0)) : (val ?? 0);

            if ((isAITranslationRateFields || isTranslationRate) && !company) {
                const postBody: directFeeRequestBody = {
                    id: rowData.id,
                    translationRate: toFixed(translationRate, 4),
                    isDirectTranslation: rowData.isDirectTranslation,
                    isEngDescriptionTranslationRequired:
                        rowData.isEngDescriptionTranslationRequired,
                    aiTranslationRate: toFixed(aiTranslationRate, 4),
                    trAiTrDifference: toFixed(
                        isTranslationRate || isAITranslationRateFields
                            ? isAITrDifference
                                ? updatedValue
                                : translationRate - aiTranslationRate
                            : rowData.trAiTrDifference,
                        4
                    ),
                    trAiTrDifferencePercent: toFixed(
                        (isTranslationRate || isAITranslationRateFields) && updatedValue
                            ? isAITrDifferencePercent
                                ? updatedValue
                                : ((translationRate - aiTranslationRate) / translationRate) * 100
                            : rowData.trAiTrDifferencePercent,
                        4
                    ),
                    isAiTranslationFieldsModified: isAITranslationRateFields,
                    isAiTranslation: isIsAiTranslation
                        ? updatedValue === 1
                            ? true
                            : false
                        : rowData.isAiTranslation,
                    groupId: rowData.groupId
                };
                if (rowData.groupId) {
                    handleGroupedCountriesUpdate(
                        postBody,
                        rowData,
                        isTranslationRate,
                        isAITranslationRateFields
                    );
                } else {
                    updateTranslationRate(postBody, isTranslationRate);
                }
            } else if (company && isCompanyRateField) {
                const postBody: companyDetailRateRequestBody = {
                    id: rowData.id,
                    companyTranslationRate: toFixed(translationRate, 4),
                    aiTranslationRate: toFixed(aiTranslationRate, 4),
                    trAiTrDifference: toFixed(
                        isTranslationRate || isAITranslationRateFields
                            ? isAITrDifference
                                ? updatedValue
                                : translationRate - aiTranslationRate
                            : rowData.trAiTrDifference,
                        4
                    ),
                    trAiTrDifferencePercent: toFixed(
                        (isTranslationRate || isAITranslationRateFields) && updatedValue
                            ? isAITrDifferencePercent
                                ? updatedValue
                                : ((translationRate - aiTranslationRate) / translationRate) * 100
                            : rowData.trAiTrDifferencePercent,
                        4
                    ),
                    isAiTranslationFieldsModified: isAITranslationRateFields,
                    isAiTranslation: isIsAiTranslation
                        ? updatedValue === 1
                            ? true
                            : false
                        : rowData.isAiTranslation,
                    isDirectTranslation: rowData.isDirectTranslation,
                    isEngDescriptionTranslationRequired:
                        rowData.isEngDescriptionTranslationRequired,
                    groupId: rowData.groupId
                };
                if (rowData.groupId) {
                    handleGroupedCountriesUpdate(
                        postBody,
                        rowData,
                        isTranslationRate,
                        isAITranslationRateFields
                    );
                } else {
                    updateCompanyInlineFields(
                        postBody,
                        isAITranslationRateFields
                            ? 'UPDATE_COMPANY_AI_TRANSLATION_RATE'
                            : 'UPDATE_COMPANY_TRANSLATIONS'
                    );
                }
            } else {
                openModal(TABLE_POP_IDS.CREATE_POPUP.EDIT_FORMULA);
                setEditFormulaModal({
                    ...editFormulaModal,
                    opened: true,
                    title: { countryIcon: rowData.countryIcon, countryName: rowData.countryName },
                    rowData,
                    feeType: fieldName
                });
            }
        }
    };

    const handleIpRatesAiValuesValidation = (
        rowData: DataValue,
        fieldName: string,
        updatedValue?: number
    ) => {
        if (rowData) {
            const res = validateIpRatesAiTranslationRate(
                rowData,
                updatedValue || 0,
                fieldName as keyof listingDetailsList
            );
            if (res === true) {
                return EditFormula(rowData, fieldName, updatedValue);
            }
        }
    };

    const EditCompanyTranslations = (rowData: DataValue, fieldName: string) => {
        if (rowData) {
            openModal(TABLE_POP_IDS.CREATE_POPUP.COMPANY_TRANSLATIONS);
            setEditCTFormulaModal({
                ...editCTFormulaModal,
                opened: true,
                title: { countryIcon: rowData.countryIcon, countryName: rowData.countryName },
                rowData,
                feeType: fieldName,
                editMode: true
            });
        }
    };

    async function onDirectTranslationDropdownChange(
        dropdownValue: boolean,
        rowId: number,
        rowData: any
    ) {
        const isEP = moduleName === 'ep';
        const isFR = sourceLanguageId === SOURCE_LANGUAGE_ID?.FRE;
        const toastMsg = isFR
            ? 'UPDATE_FRE_ENG_DESCRIPTION_TRANSLATION_REQUIRED'
            : 'UPDATE_GER_ENG_DESCRIPTION_TRANSLATION_REQUIRED';
        const postBody = {
            id: rowId,
            isDirectTranslation: dropdownValue,
            isEngDescriptionTranslationRequired: dropdownValue,
            translationRate: rowData?.translationRateNumber ?? 0,
            engIndirectTranslationRate: rowData?.engIndirectTranslationRateNumber ?? 0
        };
        try {
            const updateDetails = await PVSettingsService.updateIpRateDetail(postBody);
            if (updateDetails) {
                showToastMessage({
                    message: t(
                        `PV_SETTING.RATES.SUCCESS_MESSAGE.${isEP ? toastMsg : 'UPDATE_DIRECT_TRANSLATION'}`
                    ),
                    type: ToastType.SUCCESS
                });
                getIPRates();
            }
        } catch (error) {
            showToastMessage({
                message: t(
                    `PV_SETTING.RATES.ERROR_MESSAGE.${isEP ? toastMsg : 'UPDATE_DIRECT_TRANSLATION'}`
                ),
                type: ToastType?.ERROR
            });
        }
    }

    const deleteTranslations = async (id: number) => {
        try {
            if (moduleName === 'companytranslations' && !company) {
                const deleteTranslation = await PVSettingsService.deleteCompanyTranslations(id);
                if (deleteTranslation) {
                    getIPRates();
                    return true;
                }
            } else {
                const deleteTranslation = await PVSettingsService.deleteVendorTranslations(id);
                if (deleteTranslation) {
                    getIPRates();
                    return true;
                }
            }
        } catch (error) {
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.DELETE_COMPANY_TRANSLATIONS'),
                type: ToastType?.ERROR
            });
        }
    };

    const resetToDefault = async () => {
        try {
            const reset = await PVSettingsService.resetToDefault(
                Number(companyRequestBody.companyId ?? 0),
                Number(companyRequestBody.patentServiceId ?? 0),
                Number(companyRequestBody.sourceLanguageId ?? 0),
                Number(companyRequestBody.requestCurrencyId ?? 0)
            );
            if (reset) return true;
        } catch (error) {
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.RESET_TO_DEFAULT'),
                type: ToastType?.ERROR
            });
        }
    };

    const handleConfirm = () => {
        setShowDeletePopup({ ...showDeletePopup, visible: false });
        deleteTranslations(showDeletePopup.id);
        showToastMessage({
            message: t(
                moduleName === 'companytranslations'
                    ? 'PV_SETTING.RATES.SUCCESS_MESSAGE.DELETE_COMPANY_TRANSLATIONS'
                    : 'PV_SETTING.RATES.SUCCESS_MESSAGE.DELETE_VENDOR_TRANSLATIONS'
            ),
            type: ToastType.SUCCESS
        });
    };

    const handleReset = () => {
        setShowResetPopup({ ...showResetPopup, visible: false });
        resetToDefault().then((response) => {
            if (response) getIPRates();
        });
    };

    return (
        <div>
            {showModal ? (
                <AddCountries
                    popupId={TABLE_POP_IDS.CREATE_POPUP.ADD_COUNTRY}
                    closeModal={() => closeModal(TABLE_POP_IDS.CREATE_POPUP.ADD_COUNTRY)}
                />
            ) : (
                <></>
            )}

            {editFormulaModal.opened ? (
                <EditFormulaPopup
                    closeModal={() => closeModal(TABLE_POP_IDS.CREATE_POPUP.EDIT_FORMULA)}
                    title={editFormulaModal.title}
                    feeType={editFormulaModal.feeType}
                    rowData={editFormulaModal.rowData}
                    unitOptionsValues={unitOptionsValues ?? []}
                    formulaFields={FormulaFields ?? []}
                    updateLocalTable={() => {
                        getIPRates();
                    }}
                    company={company}
                    popupId={TABLE_POP_IDS.CREATE_POPUP.EDIT_FORMULA}
                    serviceType={serviceType}
                />
            ) : (
                <></>
            )}

            {editCTFormulaModal.opened ? (
                <CompanyTranslationsEditPopup
                    rowData={editCTFormulaModal.rowData}
                    closeModal={() => closeModal(TABLE_POP_IDS.CREATE_POPUP.COMPANY_TRANSLATIONS)}
                    editMode={editCTFormulaModal.editMode}
                    moduleName={moduleName}
                    rowBreakdownValues={
                        editCTFormulaModal.editMode
                            ? formatBreakdownData(editCTFormulaModal?.rowData?.breakdowns || [])
                            : []
                    }
                    globalBreakdownValues={
                        company && editCTFormulaModal?.rowData?.pvBreakdowns?.length > 0
                            ? formatBreakdownData(editCTFormulaModal?.rowData?.pvBreakdowns || [])
                            : globalBreakdownValues
                    }
                    company={company}
                    updateListing={() => {
                        getCompanyTranslations();
                        if (moduleName === 'companytranslations')
                            showToastMessage({
                                message: t(
                                    `PV_SETTING.RATES.SUCCESS_MESSAGE.${editCTFormulaModal.editMode ? 'UPDATE_COMPANY_TRANSLATIONS' : 'CREATE_COMPANY_TRANSLATIONS'}`
                                ),
                                type: ToastType.SUCCESS
                            });
                        else
                            showToastMessage({
                                message: t(
                                    `PV_SETTING.RATES.SUCCESS_MESSAGE.${editCTFormulaModal.editMode ? 'UPDATE_VENDOR_TRANSLATIONS' : 'CREATE_VENDOR_TRANSLATIONS'}`
                                ),
                                type: ToastType.SUCCESS
                            });
                    }}
                    popupId={TABLE_POP_IDS.CREATE_POPUP.COMPANY_TRANSLATIONS}
                />
            ) : (
                <></>
            )}

            {showDeletePopup.visible && !company && (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleConfirm();
                    }}
                    onCancel={() => {
                        setShowDeletePopup({ ...showDeletePopup, visible: false });
                    }}
                    visible={showDeletePopup.visible}
                    headerText={showDeletePopup.header}
                    description={showDeletePopup.description}
                    acceptLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_YES')}
                    acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                    rejectClassName="!bg-error !text-white !border-none"
                    rejectLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_NO')}
                    popupID={'deleteTranslationPopup'}
                />
            )}

            {showResetPopup.visible && company && (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleReset();
                    }}
                    onCancel={() => {
                        setShowResetPopup({ ...showResetPopup, visible: false });
                    }}
                    visible={showResetPopup.visible}
                    headerText={showResetPopup.header}
                    description={showResetPopup.description}
                    acceptLabel={t('PV_SETTING.RATES.RESET_CONFIRMATION_BUTTON_YES')}
                    acceptClassName="!bg-neutral-800 !text-black !border-neutral-50"
                    rejectClassName="!bg-error !text-white !border-none"
                    rejectLabel={t('PV_SETTING.RATES.DELETE_CONFIRMATION_BUTTON_NO')}
                    popupID={'resetPopup'}
                />
            )}

            {showGroupedCountryPopup.visible && (
                <ConfirmationPopup
                    customWidth="w-11/12 md:w-7/12 lg:w-1/3"
                    onConfirm={() => {
                        if (company) {
                            updateCompanyInlineFields(
                                showGroupedCountryPopup.postBody as companyDetailRateRequestBody,
                                showGroupedCountryPopup.isAITranslationRate
                                    ? 'UPDATE_COMPANY_AI_TRANSLATION_RATE'
                                    : 'UPDATE_COMPANY_TRANSLATIONS'
                            );
                        } else {
                            updateTranslationRate(
                                showGroupedCountryPopup.postBody as directFeeRequestBody,
                                showGroupedCountryPopup.isTranslationRate || false
                            );
                        }
                    }}
                    onCancel={() => {
                        setShowGroupedCountryPopup({
                            visible: false,
                            postBody: {} as directFeeRequestBody,
                            description: <></>
                        });
                    }}
                    visible={showGroupedCountryPopup.visible}
                    headerText={'Update Settings for all related countries?'}
                    description={showGroupedCountryPopup.description}
                    acceptLabel={t('COMMON.CONFIRM')}
                    rejectLabel={t('COMMON.CANCEL')}
                    popupID={'groupedCountryPopup'}
                />
            )}

            <DataTableComponent
                tableData={
                    isApiFetching
                        ? [{}]
                        : company
                          ? (listingData?.['companyRateDetailList'] ?? [])
                          : (listingData?.['ipRateDetailList'] ?? [])
                }
                tableDefinition={tableDefinition}
                tableRequestBodyData={getTableRequestBodyData()}
                showPagination={true}
                rowExpansionTemplate={ViewBreakdown}
                expandedRows={expandedRows}
                dataKey={'id'}
                tablePaginationData={paginationInfo}
                handleSort={handlePageUpdate}
                handlePagination={handlePageUpdate}
                deleteRecord={(e: any) => {
                    if (TRANSLATION_MODULES.includes(moduleName)) {
                        setShowDeletePopup({
                            visible: true,
                            header: t('COMMON.CONFIRMATION'),
                            description: t('PV_SETTING.RATES.DELETE_CONFIRMATION_DESCRIPTION'),
                            id: Number(e.id)
                        });
                    }
                }}
                editCell={
                    moduleName === 'companytranslations' || moduleName === 'vendortranslations'
                        ? EditCompanyTranslations
                        : handleIpRatesAiValuesValidation
                }
                readOnly={readOnly}
                onDropDownChange={(dropdownValue: boolean, rowId: number) => {
                    (async () => {
                        let rowData = [];
                        if (company) {
                            rowData = listingData?.['companyRateDetailList'] ?? [];
                        } else {
                            rowData = listingData?.['ipRateDetailList'] ?? [];
                        }
                        await onDirectTranslationDropdownChange(
                            dropdownValue,
                            rowId,
                            (rowData || [])?.find((r: any) => r.id === rowId) || ({} as any)
                        );
                    })();
                }}
                toggleRowData={() => {}}
                loading={isApiFetching}
            />
        </div>
    );
}

export const ViewBreakdown = (data: companyTranslations) => {
    const breakdownData = data?.breakdowns?.map((breakDownValues: breakdownValues) => ({
        label: breakDownValues.breakdownName,
        percentageValue: breakDownValues.companyPercentage ?? breakDownValues.vendorPercentage,
        suffixValue: breakDownValues.translateRateValue,
        rateChanged: breakDownValues.rateChanged
    }));
    return <BreakDownComponent symbol={data?.currencySymbol || ''} breakdown={breakdownData} />;
};

export const BreakDownComponent = ({ symbol, breakdown }: breakDownComponentProps) => {
    return (
        <div className="px-2 w-4/5">
            <h6 className="font-medium mb-4">Breakdown</h6>
            <div className="flex gap-10 flex-wrap">
                {breakdown?.map((breakdownVals: breakdownProps) => (
                    <div key={breakdownVals.label}>
                        <p className="mb-3">{breakdownVals.label}</p>
                        <div className="flex border border-neutral-200 rounded">
                            <div
                                className={`flex items-center justify-between p-3 rounded-l-lg w-48 ${breakdownVals.rateChanged ? 'bg-cream-yellow' : 'bg-white'}`}>
                                <p className="font-medium"> {breakdownVals.percentageValue}</p>
                                <p>%</p>
                            </div>
                            <div className="p-3">
                                <FieldValue
                                    value={breakdownVals.suffixValue || 0}
                                    renderAs={'string'}
                                    decimalLength={4}
                                    currency={symbol ?? '$'}
                                    customClass={{ field: 'font-medium' }}
                                />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
