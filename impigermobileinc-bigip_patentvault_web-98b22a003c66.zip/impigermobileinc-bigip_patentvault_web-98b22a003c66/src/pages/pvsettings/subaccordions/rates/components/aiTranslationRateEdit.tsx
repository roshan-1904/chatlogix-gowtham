import { useState } from 'react';
import {
    listingData,
    listingDetailsList,
    RatesListingResponseType
} from '../../types/pvsettings.types';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';
import { InputNumber } from 'primereact/inputnumber';
import { pvSettingStore } from '../store/pvSetting.store';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';

interface AiTranslationRateEditProps {
    data: listingDetailsList;
    field: keyof listingDetailsList;
    isPercent?: boolean;
    onValueChange?: (data: listingData) => void;
}

const AiTranslationRateEdit: React.FC<AiTranslationRateEditProps> = ({
    data,
    field,
    isPercent = false,
    onValueChange
}) => {
    const [rateData, setRateData] = useState<RatesListingResponseType>(pvSettingStore.getData());
    pvSettingStore.subscribe(setRateData);

    const [inputValue, setInputValue] = useState<number>(Number(data[field]) || 0);
    const [editMode, setEditMode] = useState(false);

    const extractNumber = (val: string | number) =>
        Number(String(val).replace(/[^0-9.-]+/g, '')).toFixed(4) || 0;

    const translationRate = Number(extractNumber(data.translationRate));

    const onSave = (
        value: number,
        id:
            | 'aiTranslationRate'
            | 'aiEngIndirectTranslationRate'
            | 'trAiTrDifference'
            | 'trAiTrDifferencePercent'
            | keyof listingDetailsList
    ) => {
        const newVal = value ?? 0;

        if (
            newVal === translationRate ||
            translationRate - newVal === translationRate ||
            translationRate - (newVal / 100) * translationRate === translationRate
        ) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'AI Translation Rate should not be equal to Translation Rate'
            });
            return;
        }

        if ((id === 'aiTranslationRate' || id === 'aiEngIndirectTranslationRate') && newVal === 0) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'AI Translation Rate should be greater than zero'
            });
            return;
        }

        if (id === 'trAiTrDifference' && translationRate === newVal) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'AI Translation Rate cannot be zero or greater than Translation Rate'
            });
            return;
        }

        if (id !== 'trAiTrDifferencePercent' && translationRate < newVal) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'AI Translation Rate cannot be greater than Translation Rate'
            });
            return;
        }

        if (id === 'trAiTrDifferencePercent' && newVal > 100) {
            showToastMessage({
                type: ToastType.ERROR,
                message:
                    'AI Translation Rate should not be zero or greater than the Translation Rate.'
            });
            return;
        }

        if (
            id === 'trAiTrDifferencePercent' &&
            Number((translationRate - (newVal / 100) * translationRate).toFixed(4)) === 0
        ) {
            showToastMessage({
                type: ToastType.ERROR,
                message: 'AI Translation Rate cannot be zero or greater than Translation Rate'
            });
            return;
        }

        const updatedList: listingData[] = rateData.ipRateDetailList.map((item) => {
            if (item.id !== data.id) return item;

            switch (id) {
                case 'aiTranslationRate':
                    return {
                        ...item,
                        aiTranslationRate: newVal,
                        trAiTrDifference: translationRate - newVal,
                        trAiTrDifferencePercent:
                            ((translationRate - newVal) / translationRate) * 100,
                        isAiTranslation: true
                    };
                case 'trAiTrDifference':
                    return {
                        ...item,
                        aiTranslationRate: translationRate - newVal,
                        trAiTrDifference: newVal,
                        trAiTrDifferencePercent:
                            ((translationRate - newVal) / translationRate) * 100
                    };
                case 'trAiTrDifferencePercent':
                    return {
                        ...item,
                        trAiTrDifferencePercent: newVal,
                        trAiTrDifference: (newVal / 100) * translationRate,
                        aiTranslationRate: translationRate - (newVal / 100) * translationRate
                    };
                default:
                    return item;
            }
        });

        onValueChange && onValueChange(updatedList.find((item) => item.id === data.id)!);
    };

    return (
        <div className="min-w-40">
            {editMode ? (
                <div className="flex items-center gap-4">
                    <InputNumber
                        id={field}
                        value={inputValue || 0}
                        pt={{
                            root: { className: 'focus:shadow-none' },
                            input: {
                                root: { className: 'w-24 h-10 focus:shadow-none font-medium' }
                            }
                        }}
                        maxFractionDigits={isPercent ? 2 : 4}
                        onChange={(e) => setInputValue(e.value ?? 0)}
                        onKeyDown={(event) => {
                            if (event.key === 'Enter') {
                                onSave(inputValue, field);
                            }
                        }}
                    />
                    <div className="flex items-center gap-2">
                        <i
                            className="pi pi-check text-success cursor-pointer"
                            onClick={() => onSave(inputValue, field)}
                        />
                        <i
                            className="pi pi-times text-error cursor-pointer"
                            onClick={() => {
                                setInputValue(data[field] as number);
                                setEditMode(false);
                            }}
                        />
                    </div>
                </div>
            ) : (
                <p className="group w-full flex items-center justify-between">
                    {isPercent
                        ? `${Number(data[field] ?? 0).toFixed(2)}%`
                        : `${data?.currencySymbol ?? '$'} ${Number(data[field] ?? 0).toFixed(4)}`}
                    <EditIcon
                        onClick={() => setEditMode(true)}
                        className="h-4 w-5 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    />
                </p>
            )}
        </div>
    );
};

export default AiTranslationRateEdit;
