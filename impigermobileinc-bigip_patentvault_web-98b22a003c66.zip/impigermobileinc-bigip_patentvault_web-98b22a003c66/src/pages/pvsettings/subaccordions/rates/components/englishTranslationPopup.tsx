import { TABLE_POP_IDS } from 'constants/dataTable.constant';
import { inputSwitchPT } from 'constants/styles.constant';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import utils, { showToastMessage } from 'core/utils/utils';
import { t } from 'i18next';
import ReactTextareaAutocomplete from '@webscopeio/react-textarea-autocomplete';
import { InputNumber } from 'primereact/inputnumber';
import { InputSwitch } from 'primereact/inputswitch';
import { useEffect, useState } from 'react';
import {
    descriptionTranslationFormula,
    TranslationFormulaUpdate,
    validateFormulaTypes
} from '../../types/pvsettings.types';
import PVSettingsService from '../../service/pvsettings.service';
import PopupModal from 'components/popupModal/popupModal';

interface EnglishTranslationPopupProps {
    currencySymbol?: string;
    indirectTranslationRate: number;
    aiIndirectTranslationRate: number;
    indirectTrAiTrDifference: number;
    indirectTrAiTrDifferencePercent: number;
    isAiIndirectTranslation: boolean;
    descriptionTranslationFormulaModel: descriptionTranslationFormula;
    formulaFields: string[];
    patentServiceId: number;
    sourceLanguageId: number;
    requestCurrencyId: number;
    updatedSuccessfully?: () => void;
    isCompany?: boolean;
    companyId?: number;
    viewMode?: boolean;
}
const EnglishTranslationPopup = ({
    currencySymbol,
    indirectTranslationRate,
    aiIndirectTranslationRate,
    indirectTrAiTrDifference,
    indirectTrAiTrDifferencePercent,
    isAiIndirectTranslation,
    formulaFields,
    patentServiceId,
    sourceLanguageId,
    requestCurrencyId,
    descriptionTranslationFormulaModel,
    updatedSuccessfully,
    isCompany,
    companyId,
    viewMode
}: EnglishTranslationPopupProps) => {
    const [visible, setVisible] = useState(false);
    const [formula, setFormula] = useState<string>(
        `${descriptionTranslationFormulaModel?.formula ?? ''}`
    );
    const [validFormula, setValidFormula] = useState<validateFormulaTypes>({ state: 'validate' });
    const [validRates, setValidRates] = useState<{
        state: 'valid' | 'invalid' | 'validate';
        error?: string;
    }>({ state: 'validate' });
    const [englishTranslationFields, setEnglishTranslationFields] = useState({
        translationRate: 0,
        aiTranslationRate: 0,
        trAiTrDifference: 0,
        trAiTrDifferencePercent: 0,
        aiDefaultTranslationMode: false,
        descriptionTranslationFormula: descriptionTranslationFormulaModel
    });
    // Temporarily disable the AI fields
    const isAiFieldsDisable = true;

    useEffect(() => {
        setEnglishTranslationFields({
            translationRate: indirectTranslationRate || 0,
            aiTranslationRate: aiIndirectTranslationRate || 0,
            trAiTrDifference: indirectTrAiTrDifference || 0,
            trAiTrDifferencePercent: indirectTrAiTrDifferencePercent || 0,
            aiDefaultTranslationMode: isAiIndirectTranslation,
            descriptionTranslationFormula: descriptionTranslationFormulaModel
        });
    }, [
        indirectTranslationRate,
        aiIndirectTranslationRate,
        indirectTrAiTrDifference,
        indirectTrAiTrDifferencePercent,
        isAiIndirectTranslation,
        descriptionTranslationFormulaModel,
        visible
    ]);

    useEffect(() => {
        setFormula(descriptionTranslationFormulaModel?.formula || '');
    }, [descriptionTranslationFormulaModel]);

    const buttonStyles: any = {
        validate: 'border-primary/50 hover:border-primary/50 text-primary border',
        invalid:
            'bg-negative-tone bg-opacity-25 hover:bg-negative-tone hover:bg-opacity-25 border-none',
        valid: 'bg-positive-tone bg-opacity-25 hover:bg-positive-tone hover:bg-opacity-25 border-none'
    };

    const Item = ({ entity: { name } }: { entity: any }) => <div>{`${name}`}</div>;
    const filterFields = (key: string) => {
        return formulaFields
            .filter((fieldName) => fieldName.toLowerCase().includes(key.toLowerCase()))
            .map((fieldName) => {
                return { name: fieldName, char: fieldName };
            });
    };

    const validateFormula = async () => {
        try {
            const usedFieldsList = utils.extractWordsBetweenCurlyBraces(formula);
            const newFieldsList =
                usedFieldsList.filter((field) => !formulaFields.includes(field.trim())) || [];

            if (newFieldsList.length > 0) {
                const invalidFields = newFieldsList.join(', ');
                const errorMessage = t('PV_SETTING.RATES.FORMULA_NEWFIELDS_ERROR', {
                    invalidFields
                });
                setValidFormula({ state: 'invalid', error: errorMessage });
                return 'invalid';
            }

            const response: any = await PVSettingsService.validateFormula(formula);
            if (response?.formulaValue?.length) {
                setValidFormula({ state: 'valid' });
                return 'valid';
            } else if (response.error?.length) {
                setValidFormula({ state: 'invalid', error: response.error });
                return 'invalid';
            }
        } catch (error) {
            setValidFormula({ state: 'invalid' });
        }
    };
    const currencySymbolWidth = utils.getTextWidth(currencySymbol || '$');

    const inputStyle = {
        root: {
            className: `focus:shadow-none`
        },
        input: {
            root: {
                className: `h-10 focus:shadow-none font-medium  ${viewMode ? '' : 'text-black'}`,
                style: {
                    paddingLeft: `${currencySymbolWidth + (currencySymbolWidth > 6 ? 20 : 16)}px`
                }
            }
        }
    };
    const currencySymbolStyle = 'absolute left-2 h-full flex items-center pt-px font-medium';

    const validateRateField = (
        fieldName:
            | 'translationRate'
            | 'aiTranslationRate'
            | 'trAiTrDifference'
            | 'trAiTrDifferencePercent',
        newVal: number,
        fields = englishTranslationFields
    ): string | null => {
        const translationRate = fields.translationRate;

        const showError = (message: string) => {
            showToastMessage({
                type: ToastType.ERROR,
                message
            });
            setValidRates({
                state: 'invalid',
                error: message
            });
            return message;
        };

        if (isAiFieldsDisable) {
            setValidRates({ state: 'valid' });
            return null;
        }

        if (
            fieldName !== 'trAiTrDifferencePercent' &&
            fieldName !== 'translationRate' &&
            fieldName !== 'trAiTrDifference' &&
            newVal > translationRate
        ) {
            return showError(
                t('PV_SETTING.RATES.AI_TRANSLATION_RATE_GREATER_THAN_TRANSLATION_RATE')
            );
        }

        if (fieldName === 'translationRate' && newVal < fields.aiTranslationRate) {
            return showError(
                t('PV_SETTING.RATES.ENG_POPUP_TRANSLATION_RATE_LESS_THAN_AI_TRANSLATION_RATE')
            );
        }

        if (
            fieldName !== 'translationRate' &&
            (newVal === translationRate || translationRate - newVal === translationRate)
        ) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_NOT_ZERO_OR_EQUAL_TO_TRANSLATION_RATE'
                )
            );
        }

        if (fieldName === 'trAiTrDifferencePercent' && newVal > 100) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_GREATER_THAN_ZERO_AND_LESS_THAN_TRANSLATION_RATE'
                )
            );
        }

        if (fieldName === 'trAiTrDifference' && newVal === translationRate) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_GREATER_THAN_ZERO_AND_LESS_THAN_TRANSLATION_RATE'
                )
            );
        }

        if (fieldName === 'trAiTrDifference' && newVal >= translationRate) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_GREATER_THAN_ZERO_AND_LESS_THAN_TRANSLATION_RATE'
                )
            );
        }

        if (fieldName === 'aiTranslationRate' && newVal === 0) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_GREATER_THAN_ZERO_AND_LESS_THAN_TRANSLATION_RATE'
                )
            );
        }

        if (
            fieldName === 'trAiTrDifferencePercent' &&
            Number((translationRate - (newVal / 100) * translationRate).toFixed(4)) === 0
        ) {
            return showError(
                t(
                    'PV_SETTING.RATES.ENG_POPUP_AI_TRANSLATION_RATE_GREATER_THAN_ZERO_AND_LESS_THAN_TRANSLATION_RATE'
                )
            );
        }

        setValidRates({ state: 'valid' });
        return null;
    };

    const handleValueChange = (
        value: number,
        fieldName:
            | 'translationRate'
            | 'aiTranslationRate'
            | 'trAiTrDifference'
            | 'trAiTrDifferencePercent'
    ) => {
        const newVal = value ?? 0;
        const translationRate = englishTranslationFields.translationRate;

        switch (fieldName) {
            case 'translationRate':
                setEnglishTranslationFields((prev) => ({
                    ...prev,
                    translationRate: newVal,
                    trAiTrDifference: newVal - prev.aiTranslationRate,
                    trAiTrDifferencePercent: ((newVal - prev.aiTranslationRate) / newVal) * 100
                }));
                validateRateField(fieldName, newVal);
                break;

            case 'aiTranslationRate':
                setEnglishTranslationFields((prev) => ({
                    ...prev,
                    aiTranslationRate: newVal,
                    trAiTrDifference: translationRate - newVal,
                    trAiTrDifferencePercent: ((translationRate - newVal) / translationRate) * 100
                }));
                validateRateField(fieldName, newVal);
                break;

            case 'trAiTrDifference':
                setEnglishTranslationFields((prev) => ({
                    ...prev,
                    trAiTrDifference: newVal,
                    aiTranslationRate: translationRate - newVal,
                    trAiTrDifferencePercent: ((translationRate - newVal) / translationRate) * 100
                }));
                validateRateField(fieldName, newVal);
                break;

            case 'trAiTrDifferencePercent':
                setEnglishTranslationFields((prev) => ({
                    ...prev,
                    trAiTrDifferencePercent: newVal,
                    trAiTrDifference: (newVal / 100) * translationRate,
                    aiTranslationRate: translationRate - (newVal / 100) * translationRate
                }));
                validateRateField(fieldName, newVal);
                break;
            default:
                break;
        }
    };

    const openModal = async () => {
        setVisible(true);
        setEnglishTranslationFields((prev) => ({
            ...prev,
            reRenderFlag: new Date()
        }));
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.ENGLISH_TRANSLATION_FORMULA_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setVisible(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.ENGLISH_TRANSLATION_FORMULA_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
            setValidFormula({ state: 'validate' });
            setValidRates({ state: 'validate' });
        }
    };

    const handleUpdate = async () => {
        // without edit validate
        const fieldsToValidate = {
            translationRate: englishTranslationFields.translationRate,
            aiTranslationRate: englishTranslationFields.aiTranslationRate,
            trAiTrDifference: englishTranslationFields.trAiTrDifference,
            trAiTrDifferencePercent: englishTranslationFields.trAiTrDifferencePercent
        };

        for (const [fieldName, value] of Object.entries(fieldsToValidate)) {
            const error = validateRateField(fieldName as keyof typeof fieldsToValidate, value);
            if (error) {
                showToastMessage({ type: ToastType.ERROR, message: error });
                setValidRates({ state: 'invalid', error });
                return;
            }
        }

        setValidRates({ state: 'valid' });

        if (validRates.state === 'invalid') {
            showToastMessage({
                type: ToastType.ERROR,
                message: validRates.error || 'Please correct the rate fields before updating.'
            });
            return;
        }

        if (validFormula.state === 'validate') {
            const formulaValidationResult = await validateFormula();
            if (formulaValidationResult === 'invalid') {
                return;
            }
        }

        // Prepare the payload for update
        const payload: TranslationFormulaUpdate = {
            aiIndirectTranslationRate: englishTranslationFields.aiTranslationRate,
            indirectTrAiTrDifference: englishTranslationFields.trAiTrDifference,
            indirectTrAiTrDifferencePercent: englishTranslationFields.trAiTrDifferencePercent,
            isAiTranslation: englishTranslationFields.aiDefaultTranslationMode,
            isAiTranslationFieldsModified: true,
            patentServiceId,
            sourceLanguageId,
            requestCurrencyId,
            translationRate: englishTranslationFields.translationRate,
            descriptionTranslationFormula: englishTranslationFields.descriptionTranslationFormula
        };

        await PVSettingsService.updateEnglishTranslationFormula(payload, isCompany, companyId);
        updatedSuccessfully && updatedSuccessfully();
        closeModal();
    };

    return (
        <div>
            <button
                className="btn button-primary-outline min-h-10 h-10"
                onClick={() => {
                    openModal();
                }}>
                {!viewMode && <img src="/images/svgs/i-edit-blue-icon.svg" className="h-4 w-4" />}
                {t('PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA')}
            </button>
            {visible && (
                <PopupModal
                    key={TABLE_POP_IDS.CREATE_POPUP.ENGLISH_TRANSLATION_FORMULA_POPUP}
                    id={TABLE_POP_IDS.CREATE_POPUP.ENGLISH_TRANSLATION_FORMULA_POPUP}
                    title={t('PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA')}
                    resetButtonText={viewMode ? t('COMMON.CLOSE') : t('COMMON.CANCEL')}
                    createButtonText={t('COMMON.UPDATE')}
                    isEdit={true}
                    isFormIo={false}
                    onClose={() => closeModal()}
                    onSubmit={() => {
                        handleUpdate();
                    }}
                    isSubmitHide={!viewMode}>
                    <div className="p-6 font-normal grid grid-cols-3 gap-6 [&>div]:flex [&>div]:flex-col [&>div]:gap-1 [&>div>div]:relative text-black">
                        <div>
                            {t('PV_SETTING.RATES.TRANSLATION_RATE')}
                            <div>
                                <span className={currencySymbolStyle}>{currencySymbol || '$'}</span>
                                <InputNumber
                                    id="input-translationRate"
                                    pt={inputStyle}
                                    value={englishTranslationFields.translationRate}
                                    onChange={(e) =>
                                        handleValueChange(e.value as number, 'translationRate')
                                    }
                                    maxFractionDigits={4}
                                    disabled={viewMode}
                                />
                            </div>
                        </div>
                        <div>
                            {t('PV_SETTING.RATES.AI_TRANSLATION_RATE')}
                            <div>
                                <span className={currencySymbolStyle}>{currencySymbol || '$'}</span>
                                <InputNumber
                                    pt={inputStyle}
                                    value={englishTranslationFields.aiTranslationRate}
                                    onChange={(e) =>
                                        handleValueChange(e.value as number, 'aiTranslationRate')
                                    }
                                    maxFractionDigits={4}
                                    disabled={isAiFieldsDisable}
                                />
                            </div>
                        </div>
                        <div>
                            {t('PV_SETTING.RATES.TR-AI_TR')}
                            <div>
                                <span className={currencySymbolStyle}>{currencySymbol || '$'}</span>
                                <InputNumber
                                    pt={inputStyle}
                                    value={englishTranslationFields.trAiTrDifference}
                                    onChange={(e) =>
                                        handleValueChange(e.value as number, 'trAiTrDifference')
                                    }
                                    maxFractionDigits={4}
                                    disabled={isAiFieldsDisable}
                                />
                            </div>
                        </div>
                        <div>
                            {t('PV_SETTING.RATES.TR-AI_TR_PERCENTAGE')}
                            <div className="flex items-center w-full group">
                                <InputNumber
                                    pt={{
                                        ...inputStyle,
                                        root: {
                                            className: 'w-auto '
                                        },
                                        input: {
                                            root: {
                                                className:
                                                    inputStyle.input.root.className +
                                                    ' pl-2 w-48 border-r-0 rounded-r-none '
                                            }
                                        }
                                    }}
                                    value={englishTranslationFields.trAiTrDifferencePercent}
                                    onChange={(e) =>
                                        handleValueChange(
                                            e.value as number,
                                            'trAiTrDifferencePercent'
                                        )
                                    }
                                    maxFractionDigits={4}
                                    disabled={isAiFieldsDisable}
                                />
                                <span
                                    className={`${isAiFieldsDisable ? 'text-black/40' : 'border-gray-300 group-hover:border-primary group-hover:transition-colors group-hover:duration-200'} font-medium  border border-l-0 pr-2 rounded-r-md h-full flex items-center justify-center text-black/40`}>
                                    %
                                </span>
                            </div>
                        </div>
                        <div>
                            {t('PV_SETTING.RATES.AI_DEFAULT_TRANSLATION_MODE')}
                            <div className="mt-2">
                                <InputSwitch
                                    checked={englishTranslationFields.aiDefaultTranslationMode}
                                    onChange={(e) => {
                                        if (
                                            englishTranslationFields?.aiTranslationRate === 0 &&
                                            e.value
                                        ) {
                                            showToastMessage({
                                                type: ToastType.ERROR,
                                                message:
                                                    'AI Translation Rate should be greater than zero.'
                                            });
                                            setValidRates({
                                                state: 'invalid',
                                                error: 'AI Translation Rate should be greater than zero.'
                                            });
                                            return;
                                        } else {
                                            setEnglishTranslationFields((prev) => ({
                                                ...prev,
                                                aiDefaultTranslationMode: e.value
                                            }));
                                        }
                                    }}
                                    pt={inputSwitchPT}
                                    disabled
                                />
                            </div>
                        </div>
                        <div className="col-span-3">
                            <div className="mt-3">
                                {/* Formula Text area */}
                                <div className="flex justify-between">
                                    <label className="field-required" htmlFor="Formula">
                                        {t('PV_SETTING.RATES.FORMULA')}
                                    </label>
                                    <div className="bg-warning/40 w-fit px-2 rounded border border-warning text-neutral-700 flex gap-1 items-center">
                                        <i className="pi pi-info-circle text-warning-700 text-[0.90rem] font-semibold"></i>
                                        <label className="">
                                            {t('PV_SETTING.RATES.FORMULA_TEXTAREA_NOTE')}
                                        </label>
                                    </div>
                                </div>
                                <ReactTextareaAutocomplete
                                    className="form-control formulaEditor mt-2 outline-none p-2 max-h-96 disabled:!bg-transparent disabled:!text-black disabled:!opacity-40"
                                    value={formula}
                                    onChange={(e) => {
                                        setFormula(e.target.value);
                                        setEnglishTranslationFields((prev) => ({
                                            ...prev,
                                            descriptionTranslationFormula: {
                                                ...prev.descriptionTranslationFormula,
                                                formula: e.target.value
                                            }
                                        }));
                                        if (
                                            validFormula.state === 'valid' ||
                                            validFormula.state === 'invalid'
                                        )
                                            setValidFormula({ state: 'validate' });
                                    }}
                                    loadingComponent={() => <span>Loading</span>}
                                    trigger={{
                                        '{': {
                                            dataProvider: (key: string) => filterFields(key),
                                            component: Item,
                                            output: (item: any) => '{' + item.char
                                        }
                                    }}
                                    disabled={viewMode}
                                />

                                {validFormula?.error?.length &&
                                validFormula?.state === 'invalid' ? (
                                    <label className="text-error">{validFormula.error}</label>
                                ) : (
                                    <></>
                                )}
                                <div className="flex justify-end mt-3">
                                    <button
                                        className={`noButton btn button-primaryrate-outline ${buttonStyles[validFormula.state]} border min-w-16 min-h-10 h-10 font-medium rounded-lg px-3 ${viewMode ? 'hidden' : ''}`}
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        data-testid="validateFormula"
                                        onClick={() => {
                                            (async () => {
                                                await validateFormula();
                                            })();
                                        }}>
                                        {validFormula.state === 'valid' ? (
                                            <i className="pi pi-check-circle text-success pr-1 text-xl" />
                                        ) : validFormula.state === 'invalid' ? (
                                            <i className="pi pi-exclamation-triangle text-negative-tone pr-1 text-xl" />
                                        ) : (
                                            <></>
                                        )}
                                        {validFormula.state === 'validate'
                                            ? t('PV_SETTING.RATES.VALIDATE')
                                            : validFormula.state === 'valid'
                                              ? t('PV_SETTING.RATES.VALID_FORMULA')
                                              : t('PV_SETTING.RATES.INVALID_FORMULA')}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </PopupModal>
            )}
        </div>
    );
};

export default EnglishTranslationPopup;
