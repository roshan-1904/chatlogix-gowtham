import { useState } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { filterDropDownStyle } from 'constants/styles.constant';
import { useTranslation } from 'react-i18next';
import { defaultDropdownValues, dropdownValuesType } from '../../types/pvsettings.types';
import { ENGLISH_TRANSLATION_MODULES } from '../rates.const';

export interface FilterDropdownProps {
    sourceLanguagesData: dropdownValuesType[];
    requestCurrencyData: dropdownValuesType[];
    onChange: any;
    defaultSelections: defaultDropdownValues;
    moduleName: string;
    company?: boolean;
}

export default function FilterDropdown({
    sourceLanguagesData,
    requestCurrencyData,
    onChange,
    defaultSelections,
    moduleName,
    company = false
}: Readonly<FilterDropdownProps>) {
    const { t } = useTranslation();
    const [filteredSourceLanguage, setFilteredSourceLanguage] = useState<number | null>(null);
    const [filteredReqCurrencyData, setFilteredReqCurrencyData] = useState<number | null>(null);
    const defaultSourceLanguage = sourceLanguagesData?.filter(
        (language: dropdownValuesType) => language.label === 'English'
    )[0] ?? { label: '', value: 0 };
    const defaultCurrency = requestCurrencyData?.filter(
        (currency: dropdownValuesType) => currency.label === 'USD'
    )?.[0] ?? { label: '', value: 0 };
    return (
        <div
            className={`flex justify-start flex-wrap lg:flex-nowrap mx-0 ${ENGLISH_TRANSLATION_MODULES.includes(moduleName) || company ? '' : 'w-full'}`}>
            <div className="mr-2">
                <Dropdown
                    filter={true}
                    multiple
                    resetFilterOnHide
                    onChange={(e) => {
                        setFilteredSourceLanguage(e.value as number);
                        onChange({ sourceLanguage: e.value });
                    }}
                    data-testid="source-language-dropdown"
                    value={
                        filteredSourceLanguage ??
                        (+defaultSourceLanguage?.value || defaultSelections.sourceLanguage.value)
                    }
                    clearIcon={'pi pi-times'}
                    placeholder={t('COMPANY_DETAILS.SOURCE_LANGUAGE')}
                    filterPlaceholder={t('COMMON.TYPE_SEARCH')}
                    valueTemplate={`${t('COMPANY_DETAILS.SOURCE_LANGUAGE')}: ${sourceLanguagesData.filter((e) => e.value === filteredSourceLanguage)?.[0]?.label ?? defaultSelections.sourceLanguage.label}`}
                    pt={{
                        ...filterDropDownStyle,
                        root: {
                            className:
                                filterDropDownStyle.root.className +
                                ' items-center' +
                                (filteredSourceLanguage || defaultSelections.sourceLanguage.value
                                    ? ' bg-lightBlue'
                                    : '')
                        },
                        input: {
                            className:
                                filterDropDownStyle.input.className + ' text-black items-center'
                        },
                        trigger: {
                            className: 'mt-0.5 w-9'
                        }
                    }}
                    optionValue="value"
                    optionLabel="label"
                    options={sourceLanguagesData ?? []}
                />
            </div>
            <div>
                <Dropdown
                    filter={true}
                    multiple
                    resetFilterOnHide
                    onChange={(e) => {
                        setFilteredReqCurrencyData(e.value as number);
                        onChange({ requestCurrency: e.value });
                    }}
                    data-testid="request-currency-dropdown"
                    value={
                        filteredReqCurrencyData ??
                        (+defaultCurrency?.value || defaultSelections.requestCurrency.value)
                    }
                    clearIcon={'pi pi-times'}
                    placeholder={t('PV_SETTING.RATES.REQUEST_CURRENCY')}
                    filterPlaceholder={t('COMMON.TYPE_SEARCH')}
                    valueTemplate={`${t('PV_SETTING.RATES.REQUEST_CURRENCY')}: ${requestCurrencyData.filter((e) => e.value === filteredReqCurrencyData)?.[0]?.label ?? defaultSelections.requestCurrency.label}`}
                    pt={{
                        ...filterDropDownStyle,
                        root: {
                            className:
                                filterDropDownStyle.root.className +
                                ' items-center' +
                                (filteredReqCurrencyData || defaultSelections.sourceLanguage.value
                                    ? ' bg-lightBlue'
                                    : '')
                        },
                        input: {
                            className:
                                filterDropDownStyle.input.className + ' text-black  items-center'
                        },
                        trigger: {
                            className: 'mt-0.5 w-9'
                        }
                    }}
                    optionValue="value"
                    optionLabel="label"
                    options={requestCurrencyData ?? []}
                />
            </div>
        </div>
    );
}
