import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CompanyTranslationsEditPopup from './companyTranslationsEditPopup';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import PVSettingsService from '../../service/pvsettings.service';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

jest.mock('core/interceptor/api.handler');
jest.mock('core/store/formIoStore/formIoStore');
jest.mock('../../service/pvsettings.service');
PVSettingsService.saveVendorTranslations = jest.fn().mockResolvedValue({});
describe('CompanyTranslationsEditPopup', () => {
    const mockProps = {
        rowData: {
            sourceLanguageId: 1,
            sourceLanguageName: 'English',
            targetLanguageId: 2,
            targetLanguageName: 'Spanish',
            currencyId: 1,
            currencyCode: 'USD',
            minCharge: 10,
            enableMinCharge: true,
            unitId: 1,
            unitName: 'Word',
            translationRate: 0.1,
            agreeTmDiscount: true,
            enableBreakdown: true,
            id: 1
        },
        visible: true,
        onHide: jest.fn(), // ✅ Make sure this is a mock function
        selectedTranslationData: [],
        popupId: 'test-popup',
        closeModal: jest.fn(),
        editMode: true,
        moduleName: 'companytranslations',
        updateListing: jest.fn(),
        company: true,
        globalBreakdownValues: [],
        rowBreakdownValues: []
    };

    beforeEach(() => {
        jest.spyOn(formStatusStore, 'getFormData').mockReturnValue({ data: {} });
        formStatusStore.subscribe = jest.fn();
        formStatusStore.updateFormData = jest.fn();
        formStatusStore.clearFormData = jest.fn();
        PVSettingsService.saveCompanyLevelTranslations = jest.fn().mockResolvedValue(true);
        PVSettingsService.saveCompanyTranslations = jest.fn().mockResolvedValue(true);
        PVSettingsService.saveVendorTranslations = jest.fn().mockResolvedValue(true);
    });

    it('renders the component', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        expect(screen.getByText('PV_SETTING.RATES.EDIT_TRANSLATION_RATE')).toBeInTheDocument();
    });

    it('calls closeModal and clears form data on close', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        fireEvent.click(screen.getByText('COMMON.CANCEL'));
        expect(mockProps.closeModal).toHaveBeenCalled();
        expect(formStatusStore.updateFormData).toHaveBeenCalledWith({}, true);
    });

    it('submits the form with correct data', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        fireEvent.click(screen.getByText('COMMON.UPDATE'));
        waitFor(() => {
            expect(PVSettingsService.saveCompanyLevelTranslations).toHaveBeenCalled();
        });
    });

    it('renders create translation popup when editMode is false', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} editMode={false} />);
        expect(screen.getByText('PV_SETTING.RATES.CREATE_TRANSLATION_RATE')).toBeInTheDocument();
    });

    it('does not submit if required fields are missing', async () => {
        (formStatusStore.getFormData as jest.Mock).mockReturnValue({
            data: {
                // Intentionally missing currencyId, rate, etc.
                sourceLanguageId: { id: 1, name: 'English' },
                targetLanguageId: [{ id: 2, name: 'Spanish' }]
            }
        });

        render(<CompanyTranslationsEditPopup {...mockProps} editMode={false} />);
        fireEvent.click(screen.getByText('COMMON.CREATE'));

        await waitFor(() => {
            expect(PVSettingsService.saveCompanyTranslations).not.toHaveBeenCalled();
        });
    });

    it('does not call any API if form is invalid', async () => {
        (formStatusStore.getFormData as jest.Mock).mockReturnValue({
            data: {},
            isValid: false
        });

        render(<CompanyTranslationsEditPopup {...mockProps} />);
        fireEvent.click(screen.getByText('COMMON.UPDATE'));

        await waitFor(() => {
            expect(PVSettingsService.saveCompanyLevelTranslations).not.toHaveBeenCalled();
            expect(PVSettingsService.saveCompanyTranslations).not.toHaveBeenCalled();
        });
    });

    it('renders the popup when visible is true', () => {
        const mockPropsWithVisible = {
            ...mockProps,
            visible: true
        };
        render(<CompanyTranslationsEditPopup {...mockPropsWithVisible} />);
        expect(screen.getByText('COMMON.UPDATE')).toBeInTheDocument();
    });

    it('renders the component with correct title in edit mode', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        expect(screen.getByText('PV_SETTING.RATES.EDIT_TRANSLATION_RATE')).toBeInTheDocument();
    });

    it('renders the component with correct title in create mode', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} editMode={false} />);
        expect(screen.getByText('PV_SETTING.RATES.CREATE_TRANSLATION_RATE')).toBeInTheDocument();
    });

    it('calls onHide when the popup is closed', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        fireEvent.click(screen.getByText('COMMON.CANCEL'));
        expect(mockProps.onHide).toHaveBeenCalledTimes(0); // Check if this prop is actually being used
    });

    it('properly initializes form with row data in edit mode', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} />);
        expect(formStatusStore.updateFormData).toHaveBeenCalled();
        // Add more specific checks for the data that's initialized in the form
    });

    it('initializes form with default values in create mode', () => {
        render(<CompanyTranslationsEditPopup {...mockProps} editMode={false} />);
        expect(formStatusStore.updateFormData).toHaveBeenCalled();
        // Add more specific checks for the data that's initialized in the form
    });
    it('displays confirmation popup when reset to default is triggered', () => {
        (formStatusStore.getFormData as jest.Mock).mockReturnValue({
            data: {
                resetToDefault: true
            },
            isValid: true
        });
        render(<CompanyTranslationsEditPopup {...mockProps} />);
    });
});
