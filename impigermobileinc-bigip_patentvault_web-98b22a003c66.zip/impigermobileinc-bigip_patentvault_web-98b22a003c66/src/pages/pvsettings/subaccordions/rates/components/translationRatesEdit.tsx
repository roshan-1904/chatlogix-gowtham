import { useState } from 'react';
import { TranslationRateEditProps } from '../../types/pvsettings.types';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';
import { COMPANY_FEE_VALUES } from '../rates.const';
import { InputFieldTemplate } from 'components/reuseComponents/constructField';
import FieldValue from 'components/inputs/fieldValue.label';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';

export default function TranslationRateEdit({
    fieldName,
    rowData,
    inlineEditStyles = '',
    compareKey,
    inlineEdit,
    valueKey = 'translationRateNumber',
    editCell,
    readOnly = false,
    isPercentage = false
}: Readonly<TranslationRateEditProps>) {
    const [editMode, setEditMode] = useState(false);
    const [inputValue, setInputValue] = useState(rowData?.[valueKey] ?? 0.0);
    let canEdit = false;

    if (inlineEdit) {
        canEdit = true;
    }

    const onSave = () => {
        try {
            editCell(rowData, fieldName, +inputValue || 0);
            // setEditMode(false);
        } catch (error: any) {
            showToastMessage({ message: error?.message, type: ToastType.ERROR });
        }
    };

    let textColor = '';
    /* eslint-disable @typescript-eslint/no-unsafe-argument */
    if (Object.keys(COMPANY_FEE_VALUES).includes(fieldName)) {
        const deepEqual = (obj1: any, obj2: any) => JSON.stringify(obj1) === JSON.stringify(obj2);

        const valueA = rowData[COMPANY_FEE_VALUES[fieldName]];
        const valueB = rowData[fieldName];

        // Check if the values are objects
        if (typeof valueA === 'object' && typeof valueB === 'object') {
            // Scenario 2: Compare objects based on `feeType`
            if (valueA?.feeType === 'Formula' && valueB?.feeType === 'Formula') {
                // Compare only the formula strings
                textColor = valueA?.formula === valueB?.formula ? '' : 'bg-[#FEF5C7]';
            } else {
                // Compare both `feeType` and `fee` for non-formula fee types
                textColor =
                    valueA?.feeType === valueB?.feeType && valueA?.fee === valueB?.fee
                        ? ''
                        : 'bg-[#FEF5C7]';
            }
        } else {
            // Scenario 1: Compare numbers or primitive values
            textColor = deepEqual(valueA, valueB) ? '' : 'bg-[#FEF5C7]';
        }
    }

    const showEditIcon = () => {
        return (
            (Array.isArray(rowData[fieldName]) ? !!rowData[fieldName]?.length : true) && !readOnly
        );
    };

    return (
        <div
            className={`${inlineEditStyles} ${compareKey && rowData?.[valueKey] && rowData?.[compareKey] ? (rowData?.[compareKey] !== rowData?.[valueKey] ? 'bg-cream-yellow min-h-16 flex items-center' : '') : ''} min-w-40`}>
            {canEdit ? (
                <div className="container min-w-36">
                    {editMode ? (
                        <div className="grid grid-col-2 grid-flow-col gap-4 items-center">
                            <InputFieldTemplate
                                data={{
                                    fieldType: 'input',
                                    inputType: {
                                        type: 'number',
                                        isDecimal: true,
                                        decimalLength: 4,
                                        renderAs: 'string'
                                    },
                                    value: inputValue,
                                    fieldValue: null,
                                    fieldLabelName: null,
                                    placeholder: null,
                                    onChange: (value: string) => setInputValue(value),
                                    onkeyDown(e) {
                                        if (e.key === 'Enter') {
                                            onSave();
                                        }
                                    }
                                }}
                            />
                            <div>
                                <i
                                    className="pi pi-check mr-2 text-success"
                                    onClick={onSave}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            onSave();
                                        }
                                    }}
                                    data-testid="saveButton"
                                />
                                <i
                                    className="pi pi-times text-error"
                                    onClick={() => {
                                        setEditMode(false);
                                        setInputValue(rowData?.[valueKey] ?? 0.0);
                                    }}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            setEditMode(false);
                                            setInputValue(rowData?.[valueKey] ?? 0.0);
                                        }
                                    }}
                                    data-testid="cancelButton"
                                />
                            </div>
                        </div>
                    ) : (
                        <div className={`flex justify-between items-center group`}>
                            <FieldValue
                                value={inputValue || 0}
                                renderAs={'string'}
                                decimalLength={4}
                                currency={isPercentage ? '' : (rowData?.currencySymbol ?? '$')}
                                isPercentage={isPercentage}
                            />
                            {showEditIcon() && !readOnly && (
                                <EditIcon
                                    onClick={() => setEditMode(true)}
                                    onKeyDown={(e) => e.key === 'Enter' && setEditMode(true)}
                                    data-testid="editIcon"
                                    className={`h-4 w-5 opacity-0 group-hover:opacity-100 transition-opacity`}
                                />
                            )}
                        </div>
                    )}
                </div>
            ) : (
                <FieldValue
                    value={inputValue || 0}
                    renderAs={'string'}
                    decimalLength={4}
                    currency={rowData?.currencySymbol ?? '$'}
                    customClass={{
                        field: `${fieldName === 'translationRate' || fieldName === 'aiTranslationRate' ? 'opacity-50' : ''} ${textColor}`
                    }}
                />
            )}
        </div>
    );
}
