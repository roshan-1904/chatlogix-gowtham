import { TabView, TabPanel } from 'primereact/tabview';
import { useEffect, useState } from 'react';
import {
    CurrencyRequestResponseType,
    RatesListingResponseType,
    SourceLanguageResponseType,
    TargetLanguageResponse,
    defaultDropdownValues,
    dropdownValuesType,
    ratesTableColumnSchema,
    unitOptions
} from '../types/pvsettings.types';
import FilterDropDown from './components/filterDropdown';
import PVSettingsService from '../service/pvsettings.service';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { useTranslation } from 'react-i18next';
import { FilterType, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import TableData from './components/TableData';
import { ColumnDefinition } from 'shared/dataTable/types/dataTable.types';
import { tabViewPT, tabPanelPT } from 'constants/styles.constant';
import {
    ADDITIONAL_FIELDS_LANG,
    ADDITIONAL_FIELDS_TABS,
    DIRECT_TRANSLATIONS_OPTIONS,
    PV_SETTINGS_RATES,
    TRANSLATION_MODULES
} from './rates.const';
import { DataTableExpandedRows } from 'primereact/datatable';
import UnSelectedFilterDropdown from './components/unSelectedFilter';
import { AgencyFee, EnglishTranslationEditPopup } from './components/addCountriesPopup';
import { TABLE_POP_IDS } from 'constants/dataTable.constant';
import { pvSettingStore } from './store/pvSetting.store';
import EnglishTranslationPopup from './components/englishTranslationPopup';
import { isAdminUser, showToastMessage } from 'core/utils/utils';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
export default function Rates() {
    const [activeIndex, setActiveIndex] = useState<number>(0);
    const { t } = useTranslation();
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisAdminUser = isAdminUser(loggedInUserId);
    const readOnly = !isThisAdminUser;
    const [sourceLanguagesData, setSourceLanguagesData] = useState<dropdownValuesType[] | null>([]);
    const [requestCurrencyData, setRequestCurrencyData] = useState<dropdownValuesType[] | null>([]);
    const [vendorCurrencyData, setVendorCurrencyData] = useState<dropdownValuesType[] | null>([]);
    const [targetLanguageData, setTargetLanguageData] = useState<dropdownValuesType[] | null>([]);
    const [isEnglishTranslationUpdated, setIsEnglishTranslationUpdated] = useState<boolean>(false);
    const [filteredSourceLanguage, setFilteredSourceLanguage] = useState<number>(0);
    const [filteredReqCurrency, setFilteredReqCurrency] = useState<number>(0);
    const [filteredTargetLang, setFilteredTargetLang] = useState<number>(0);
    const [languageIds, setLanguageIds]: any = useState({});
    const [showModal, setShowModal] = useState(false);
    const defaultSelectionsData = {
        requestCurrency: { label: '', value: 0 },
        sourceLanguage: { label: '', value: 0 }
    };
    const [defaultSelections, setDefaultSelections] =
        useState<defaultDropdownValues>(defaultSelectionsData);
    const [unitOptionsValues, setUnitOptionsValue] = useState<unitOptions[]>();
    const [FormulaFields, setFormulaFields] = useState<Array<string>>();
    const [expandedRows, setExpandedRows] = useState<
        DataTableExpandedRows | Record<string, boolean>
    >({});
    const [listingData, setListingData] = useState<RatesListingResponseType>(
        pvSettingStore.getData()
    );
    pvSettingStore.subscribe(setListingData);

    const SourceLanguageTemplate = (data: Record<string, any>) => {
        return (
            <div
                className={
                    'p-[0px] px-2 rounded-[3px] font-medium text-sm py-1 inline-block text-golden-brown bg-cream-yellow border-soft-yellow border'
                }>
                {data?.sourceLanguageName || '-'}
            </div>
        );
    };

    const RowExpansionTemplate = (data: Record<string, any>) => {
        if (!Object.keys(data)?.length) return '-';
        const canExpand = data?.agreeTmDiscount ?? data?.enableBreakdown;
        return (
            <div
                data-testid="dataTable-link-format"
                className={`flex items-center ${canExpand ? '' : 'ml-6'}`}
                role="button"
                tabIndex={0}>
                {canExpand ? (
                    <button
                        type="button"
                        onClick={() => {
                            const expandedRowsCopy = { ...expandedRows };
                            if (expandedRowsCopy[data.id]) {
                                delete expandedRowsCopy[data.id];
                            } else {
                                expandedRowsCopy[data.id] = true;
                            }
                            setExpandedRows(expandedRowsCopy);
                        }}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        className="p-link mr-1">
                        <i
                            className={`text-primary pi pi-fw pi-chevron-${expandedRows[data.id] ? 'down' : 'right'} `}
                        />
                    </button>
                ) : (
                    ''
                )}
                <div>{data?.abilityName || '-'}</div>
            </div>
        );
    };

    const additionalFields: ColumnDefinition[] = [
        {
            field: 'isDirectTranslation',
            header: t('PV_SETTING.RATES.DIRECT_TRANSLATION'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Menu,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4',
            dropdownOption: DIRECT_TRANSLATIONS_OPTIONS
        }
    ];

    const commonSchema = {
        languageName: {
            field: 'languageName',
            header: t('PV_SETTING.RATES.LANGUAGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        sourceLanguageNameIP: {
            field: 'languageName',
            header: t('PV_SETTING.RATES.SOURCE_LANGUAGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        targetLanguage: {
            field: 'targetLanguage',
            header: t('PV_SETTING.RATES.TARGET_LANGUAGE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4'
        },
        translationRate: {
            field: 'translationRate',
            header: t('PV_SETTING.RATES.TRANSLATION_RATE'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.Rate,
            subFieldName: ['edit'],
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4'
        },
        translationFeeModel: {
            field: 'translationFeeModel',
            header: t('PV_SETTING.RATES.TRANSLATION_FEE'),
            sortable: false,
            subFieldName: ['feeType', 'formula'],
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.SubValue,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4 !p-0'
        },
        countryName: {
            field: 'countryName',
            header: t('COMMON.COUNTRY'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'countryIcon',
            columnNumber: 0,
            visibility: true,
            className: 'w-1/4'
        },
        currencyData: {
            field: 'currencyData',
            header: t('PV_SETTING.RATES.REQUEST_CURRENCY'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4'
        },
        agencyFeeModel: {
            field: 'agencyFeeModel',
            header: t('PV_SETTING.RATES.AGENCY_FEE'),
            sortable: false,
            subFieldName: ['feeType', 'formula'],
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.SubValue,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4 !p-0'
        },
        officialFeeModel: {
            field: 'officialFeeModel',
            header: t('PV_SETTING.RATES.OFFICIAL_FEE'),
            sortable: false,
            subFieldName: ['feeType', 'formula'],
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.SubValue,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4 !p-0'
        },
        abilityName: {
            field: 'abilityName',
            header: t('PV_SETTING.RATES.ABILITY'),
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: RowExpansionTemplate,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        sourceLanguageName: {
            field: 'sourceLanguageName',
            header: t('PV_SETTING.RATES.SOURCE_LANGUAGE'),
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: SourceLanguageTemplate,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        currencyCode: {
            field: 'currencyCode',
            header: t('PV_SETTING.RATES.CURRENCY'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        enableMinCharge: {
            field: 'enableMinCharge',
            header: t('PV_SETTING.RATES.ENABLE_MIN_CHARGE'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: 1,
            visibility: true
        },
        minCharge: {
            field: 'minCharge',
            header: t('PV_SETTING.RATES.MIN_CHARGE'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true
        },
        agreeTmDiscount: {
            field: 'agreeTmDiscount',
            header: t('PV_SETTING.RATES.TM'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: 1,
            visibility: true
        },
        unitName: {
            field: 'unitName',
            header: t('PV_SETTING.RATES.UNIT'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        breakdown: {
            field: 'agreeTmDiscount',
            header: t('PV_SETTING.RATES.BREAKDOWN'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.YesOrNoIcon,
            columnNumber: 2,
            visibility: true
        },
        targetLanguageName: {
            field: 'targetLanguageName',
            header: t('PV_SETTING.RATES.TARGET_LANGUAGE'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle:
                'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px] !normal-case',
            columnNumber: 1,
            visibility: true,
            className: 'w-1/4'
        },
        aiTranslationRate: {
            field: 'aiTranslationRate',
            header: t('PV_SETTING.RATES.AI_TRANSLATION_RATE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Rate,
            columnNumber: 2,
            visibility: true,
            valueKey: 'aiTranslationRate',
            subFieldName: ['edit']
        },
        trAiTrDifference: {
            field: 'trAiTrDifference',
            header: t('PV_SETTING.RATES.TR_AI_TR_DIFFERENCE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Rate,
            columnNumber: 2,
            visibility: true,
            valueKey: 'trAiTrDifference',
            subFieldName: ['edit']
        },
        trAiTrDifferencePercent: {
            field: 'trAiTrDifferencePercent',
            header: t('PV_SETTING.RATES.TR_AI_TR_DIFFERENCE_PERCENTAGE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Percentage,
            columnNumber: 2,
            visibility: true,
            valueKey: 'trAiTrDifferencePercent',
            subFieldName: ['edit']
        },
        isAiTranslation: {
            field: 'isAiTranslation',
            header: t('PV_SETTING.RATES.AI_DEFAULT_TRANSLATION_MODE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Toggle,
            columnNumber: 2,
            visibility: true,
            valueKey: 'isAiTranslation'
        },
        aiRateUpdatedBy: {
            field: 'aiRateUpdatedBy',
            header: t('PV_SETTING.RATES.AI_RATE_UPDATED_BY'),
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true
        },
        aiRateUpdatedAt: {
            field: 'aiRateUpdatedAt',
            header: t('PV_SETTING.RATES.AI_RATE_UPDATED_AT'),
            frozen: false,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 2,
            visibility: true
        }
    };

    const commonColumnSchema: ColumnDefinition[] = [
        {
            field: 'countryName',
            header: t('COMMON.COUNTRY'),
            sortable: true,
            filter: false,
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'countryIcon',
            columnNumber: 0,
            visibility: true,
            className: 'w-1/4',
            alignFrozen: 'left'
        },
        commonSchema.languageName,
        commonSchema.translationRate,
        {
            field: 'aiTranslationRate',
            header: t('PV_SETTING.RATES.AI_TRANSLATION_RATE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Rate,
            columnNumber: 2,
            visibility: true,
            valueKey: 'aiTranslationRate',
            subFieldName: ['edit']
        },
        {
            field: 'trAiTrDifference',
            header: t('PV_SETTING.RATES.TR_AI_TR_DIFFERENCE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Rate,
            columnNumber: 2,
            visibility: true,
            valueKey: 'trAiTrDifference',
            subFieldName: ['edit']
        },
        {
            field: 'trAiTrDifferencePercent',
            header: t('PV_SETTING.RATES.TR_AI_TR_DIFFERENCE_PERCENTAGE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Percentage,
            columnNumber: 2,
            visibility: true,
            valueKey: 'trAiTrDifferencePercent',
            subFieldName: ['edit']
        },
        {
            field: 'isAiTranslation',
            header: t('PV_SETTING.RATES.AI_DEFAULT_TRANSLATION_MODE'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Toggle,
            columnNumber: 2,
            visibility: true,
            valueKey: 'isAiTranslation'
        },
        {
            field: 'requestCurrency',
            header: t('PV_SETTING.RATES.REQUEST_CURRENCY'),
            sortable: false,
            filter: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 2,
            visibility: true,
            className: 'w-1/4'
        },
        commonSchema.translationFeeModel,
        commonSchema.agencyFeeModel,
        commonSchema.officialFeeModel,
        commonSchema.aiRateUpdatedAt,
        commonSchema.aiRateUpdatedBy
    ];

    const tabViewPTStyles = {
        ...tabViewPT,
        header: { clasname: 'border-neutral-100/50 border' },
        nav: { className: `${tabViewPT.nav.className} gap-3` }
    };

    const columnSchemaConst: ratesTableColumnSchema = {
        pct: commonColumnSchema,
        claims: [
            commonSchema.sourceLanguageNameIP,
            commonSchema.targetLanguage,
            commonSchema.translationRate,
            commonSchema.aiTranslationRate,
            commonSchema.trAiTrDifference,
            commonSchema.trAiTrDifferencePercent,
            commonSchema.isAiTranslation,
            commonSchema.translationFeeModel,
            commonSchema.aiRateUpdatedAt,
            commonSchema.aiRateUpdatedBy
        ],
        ep: [
            commonSchema.countryName,
            commonSchema.languageName,
            commonSchema.translationRate,
            commonSchema.currencyData,
            commonSchema.translationFeeModel,
            commonSchema.agencyFeeModel,
            commonSchema.officialFeeModel,
            commonSchema.aiRateUpdatedAt,
            commonSchema.aiRateUpdatedBy
        ],
        upc: [
            commonSchema.sourceLanguageNameIP,
            commonSchema.targetLanguage,
            commonSchema.translationRate,
            commonSchema.translationFeeModel
        ],
        pc: commonColumnSchema
    };
    const [columnSchema, setColumnSchema] = useState<ratesTableColumnSchema>(columnSchemaConst);

    function emptyTemplate(options: any) {
        return options.value;
    }

    const CompanySchema = [
        { ...commonSchema.sourceLanguageName, sortable: true },
        { ...commonSchema.targetLanguageName, sortable: true },
        { ...commonSchema.currencyCode, sortable: true },
        { ...commonSchema.enableMinCharge, sortable: true },
        {
            ...commonSchema.minCharge,
            sortable: true,
            body: (rowData: any) => (
                <span>
                    {rowData?.minCharge
                        ? `${rowData?.currencySymbol || ''} ${rowData?.minCharge}`
                        : '-'}
                </span>
            )
        },
        { ...commonSchema.agreeTmDiscount, sortable: true },
        {
            field: 'unitName',
            header: t('PV_SETTING.RATES.UNIT'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'translationRate',
            header: t('PV_SETTING.RATES.TRANSLATION_RATE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.TranslationRate,
            columnNumber: 2,
            visibility: true,
            className: '!p-0'
        },
        commonSchema.breakdown,
        {
            field: 'action',
            header: t('COMMON.ACTION'),
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.EditDelete,
            columnNumber: 4,
            visibility: true,
            onEdit: emptyTemplate
        }
    ];

    const vendorSchema = [
        { ...commonSchema.abilityName, sortable: true },
        { ...commonSchema.sourceLanguageName, sortable: true },
        { ...commonSchema.targetLanguageName, sortable: true },
        { ...commonSchema.currencyCode, sortable: true },
        { ...commonSchema.agreeTmDiscount, sortable: true, field: 'enableBreakdown' },
        { ...commonSchema.unitName, sortable: true },
        {
            field: 'translationRate',
            header: t('PV_SETTING.RATES.TRANSLATION_RATE'),
            sortable: true,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.TranslationRate,
            columnNumber: 2,
            visibility: true,
            className: '!p-0'
        },
        {
            field: 'enableBreakdown',
            header: t('PV_SETTING.RATES.BREAKDOWN'),
            sortable: false,
            frozen: false,
            filterType: FilterType.Default,
            valueType: ValueType.YesOrNoIcon,
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'action',
            header: t('COMMON.ACTION'),
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.EditDelete,
            columnNumber: 4,
            visibility: true,
            onEdit: emptyTemplate
        }
    ];

    // Fetch Source Language Data
    const getSourceLanguage = async () => {
        try {
            const response: SourceLanguageResponseType[] =
                await PVSettingsService.getSourceLanguages();
            const languageIdsData: any = {};
            const dropdownData: dropdownValuesType[] = response.map(
                (language: SourceLanguageResponseType) => {
                    languageIdsData[language.id] = {
                        name: language.name,
                        langCode: language.abbreviation
                    };
                    return { label: language.name, value: language.id };
                }
            );
            setLanguageIds(languageIdsData);
            setSourceLanguagesData(dropdownData);
            const TranslationModules = activeIndex === 5 || activeIndex === 6;
            if (dropdownData?.length && !TranslationModules) {
                setFilteredSourceLanguage(Number(dropdownData[0]?.value));
            }
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_SOURCE_LANGUAGES'),
                type: ToastType.ERROR
            });
        }
    };

    const changeSchema = (langId: any) => {
        if (
            ADDITIONAL_FIELDS_LANG.includes(`${languageIds[langId]?.langCode}`) &&
            ADDITIONAL_FIELDS_TABS.includes(Object.keys(PV_SETTINGS_RATES)[activeIndex])
        ) {
            // For PCT (tab index 0) and PC (tab index 4) show both FRE and GER additional fields
            const schemaMapping: ColumnDefinition[] =
                activeIndex === 0 || activeIndex === 4
                    ? additionalFields
                    : [
                          {
                              ...additionalFields[0],
                              header:
                                  languageIds[langId]?.langCode === 'fr'
                                      ? t('PV_SETTING.RATES.FRE_INDIRECT_TRANSLATION_RATE')
                                      : t('PV_SETTING.RATES.GER_INDIRECT_TRANSLATION_RATE'),
                              field: 'isEngDescriptionTranslationRequired'
                          }
                      ];
            setColumnSchema({
                ...columnSchema,
                [Object.keys(PV_SETTINGS_RATES)[activeIndex]]: [
                    ...commonColumnSchema.slice(0, 2),
                    ...schemaMapping,
                    ...commonColumnSchema.slice(2, commonColumnSchema?.length)
                ]
            });
        } else {
            if (ADDITIONAL_FIELDS_TABS.includes(Object.keys(PV_SETTINGS_RATES)[activeIndex]))
                setColumnSchema({
                    ...columnSchema,
                    [Object.keys(PV_SETTINGS_RATES)[activeIndex]]: commonColumnSchema
                });
            else setColumnSchema({ ...columnSchemaConst });
        }
    };

    const onDropdownChange = (event: any) => {
        /* eslint-disable @typescript-eslint/no-unsafe-argument */
        if (Object.keys(event)[0] === 'sourceLanguage') {
            setFilteredSourceLanguage(event.sourceLanguage ? Number(event.sourceLanguage) : 0);
            const langId: any = event.sourceLanguage;
            changeSchema(langId);
        } else if (Object.keys(event)[0] === 'requestCurrency')
            setFilteredReqCurrency(event.requestCurrency ? Number(event.requestCurrency) : 0);
        else if (Object.keys(event)[0] === 'targetLanguage')
            setFilteredTargetLang(event.targetLanguage ? Number(event.targetLanguage) : 0);
    };

    // Fetch Currency Units
    const getRequestCurrencyData = async () => {
        try {
            const response: CurrencyRequestResponseType[] =
                await PVSettingsService.getRequestCurrencyData();

            // Sort the response based on currencyCode
            const sortedResponse = [...response].sort((a, b) =>
                a.currencyCode.localeCompare(b.currencyCode)
            );

            const dropdownData: dropdownValuesType[] = sortedResponse.map(
                (language: CurrencyRequestResponseType) => ({
                    label: language.currencyCode,
                    value: language.currencyId
                })
            );
            setRequestCurrencyData(dropdownData);
            const TranslationModules = activeIndex === 5 || activeIndex === 6;
            if (dropdownData?.length && !TranslationModules) {
                setFilteredReqCurrency(
                    Number(dropdownData.filter((e) => e.label === 'USD')[0].value)
                );
            }
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('PV_SETTING.ERROR_MESSAGE.GET_CURRENCY_DATA'),
                type: ToastType.ERROR
            });
        }
    };

    // Fetch Currency Units
    const getVendorCurrency = async () => {
        try {
            const response: CurrencyRequestResponseType[] =
                await PVSettingsService.getVendorCurrency();
            const dropdownData: dropdownValuesType[] = response.map(
                (language: CurrencyRequestResponseType) => ({
                    label: language.currencyCode,
                    value: language.currencyId
                })
            );
            setVendorCurrencyData(dropdownData);
            const TranslationModules = activeIndex === 5 || activeIndex === 6;
            if (dropdownData?.length && !TranslationModules) {
                setFilteredReqCurrency(
                    Number(dropdownData.filter((e) => e.label === 'USD')[0].value)
                );
            }
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('PV_SETTING.ERROR_MESSAGE.GET_VENDOR_CURRENCY_DATA'),
                type: ToastType.ERROR
            });
        }
    };

    // Fetch Target Language
    const getTargetLanguageData = async () => {
        try {
            const response: TargetLanguageResponse[] = await PVSettingsService.getTargetLanguage();
            const dropdownData: dropdownValuesType[] = response.map(
                (language: TargetLanguageResponse) => ({
                    label: language.name,
                    value: language.id
                })
            );
            setTargetLanguageData(dropdownData);
        } catch (error) {
            console.error(error);
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_TARGET_LANGUAGES'),
                type: ToastType.ERROR
            });
        }
    };

    const getUnitTypes = async () => {
        try {
            const response: unitOptions[] = await PVSettingsService.getUnitTypes();
            setUnitOptionsValue(response);
        } catch (error) {
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_UNIT_TYPES'),
                type: ToastType.ERROR
            });
        }
    };

    const getFormulaFields = async () => {
        try {
            const response: Array<string> = await PVSettingsService.getFormulaFields();
            setFormulaFields(response);
        } catch (error) {
            showToastMessage({
                message: t('PV_SETTING.RATES.ERROR_MESSAGE.GET_FORMULA_FIELDS'),
                type: ToastType.ERROR
            });
        }
    };

    const getDefaultLanguageCurrencyId = () => {
        const defaultLanguageId =
            (sourceLanguagesData || [])?.filter(
                (language: dropdownValuesType) => language.label === 'English'
            )?.[0]?.value || 0;
        const defaultCurrencyId =
            (requestCurrencyData || [])?.filter(
                (currency: dropdownValuesType) => currency.label === 'USD'
            )?.[0]?.value || 0;
        return { defaultLanguageId, defaultCurrencyId };
    };

    const getTabPanelPT = (index: number) => {
        const pt = tabPanelPT(activeIndex === index, () => {
            setFilteredSourceLanguage(0);
            setFilteredReqCurrency(0);
            setFilteredTargetLang(0);
            setActiveIndex(index);
        });
        return {
            ...pt,
            content: {
                className: (pt.content?.className ?? '') + ' pt-4'
            }
        };
    };

    const closeModal = (popupId: string) => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            popupId
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const handleSubmit = () => {
        setIsEnglishTranslationUpdated(!isEnglishTranslationUpdated);
    };

    const EnglishTranslationFormulaTemplate = (patentId: number) => {
        return (
            <div key={patentId}>
                {ADDITIONAL_FIELDS_LANG.includes(
                    `${languageIds?.[filteredSourceLanguage]?.langCode}`
                ) &&
                    listingData?.descriptionTranslationFormulaModel?.formula?.length > 0 && (
                        <EnglishTranslationPopup
                            currencySymbol={listingData?.currencyData?.currencySymbol || ''}
                            indirectTranslationRate={listingData?.indirectTranslationRate || 0}
                            aiIndirectTranslationRate={listingData?.aiIndirectTranslationRate || 0}
                            indirectTrAiTrDifference={listingData?.indirectTrAiTrDifference || 0}
                            indirectTrAiTrDifferencePercent={
                                listingData?.indirectTrAiTrDifferencePercent || 0
                            }
                            isAiIndirectTranslation={listingData?.isAiIndirectTranslation || false}
                            descriptionTranslationFormulaModel={
                                listingData?.descriptionTranslationFormulaModel || {}
                            }
                            formulaFields={FormulaFields || []}
                            patentServiceId={patentId}
                            sourceLanguageId={filteredSourceLanguage || 0}
                            requestCurrencyId={filteredReqCurrency || 0}
                            updatedSuccessfully={() =>
                                setIsEnglishTranslationUpdated(!isEnglishTranslationUpdated)
                            }
                            viewMode={readOnly}
                        />
                    )}
            </div>
        );
    };

    useEffect(() => {
        getSourceLanguage();
        getRequestCurrencyData();
        getUnitTypes();
        getFormulaFields();
        getTargetLanguageData();
    }, []);

    useEffect(() => {
        // Change schema to original state when tabs changed.
        changeSchema(defaultSelections.sourceLanguage);
        const TranslationModules = activeIndex === 5 || activeIndex === 6;
        if (!TranslationModules) {
            setFilteredSourceLanguage(
                defaultSelections?.sourceLanguage?.value ||
                    getDefaultLanguageCurrencyId()?.defaultLanguageId ||
                    0
            );
            setFilteredReqCurrency(
                defaultSelections?.requestCurrency?.value ||
                    getDefaultLanguageCurrencyId()?.defaultCurrencyId ||
                    0
            );
        }
        if (vendorCurrencyData && vendorCurrencyData.length === 0 && activeIndex === 6) {
            getVendorCurrency();
        }
    }, [activeIndex]);

    useEffect(() => {
        if (requestCurrencyData?.length && sourceLanguagesData?.length && activeIndex !== 5) {
            const defaultLanguage: dropdownValuesType = sourceLanguagesData?.filter(
                (language: dropdownValuesType) => language.label === 'English'
            )[0] ?? { label: '', value: 0 };
            const defaultCurrency = requestCurrencyData?.filter(
                (currency: dropdownValuesType) => currency.label === 'USD'
            )?.[0] ?? { label: '', value: 0 };
            setDefaultSelections({
                ...defaultSelections,
                sourceLanguage: defaultLanguage,
                requestCurrency: defaultCurrency
            });
        }
    }, [requestCurrencyData]);

    return (
        <div className="p-3">
            <TabView
                activeIndex={activeIndex}
                pt={tabViewPTStyles}
                onTabChange={(e) => {
                    if (e.index !== activeIndex) {
                        setActiveIndex(e.index);
                    }
                }}>
                <TabPanel
                    className="border-1"
                    pt={getTabPanelPT(0)}
                    header={t('PV_SETTING.RATES.TAB_HEADERS.PCT')}>
                    {activeIndex === 0 && (
                        <TableData
                            readOnly={readOnly}
                            key={PV_SETTINGS_RATES.pct}
                            sourceLanguageId={
                                filteredSourceLanguage ||
                                getDefaultLanguageCurrencyId()?.defaultLanguageId
                            }
                            requestCurrencyId={
                                filteredReqCurrency ||
                                getDefaultLanguageCurrencyId()?.defaultCurrencyId
                            }
                            columnSchema={columnSchema['pct']}
                            moduleName={'pct'}
                            listingData={listingData}
                            setListingData={(data: any) => {
                                setListingData(data);
                                pvSettingStore.updatePage(undefined, undefined, data);
                            }}
                            FormulaFields={FormulaFields ?? []}
                            unitOptionsValues={unitOptionsValues ?? []}
                            isEnglishTranslationUpdated={isEnglishTranslationUpdated}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.PCT')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <div className="flex justify-between items-center w-full">
                                    <FilterDropDown
                                        sourceLanguagesData={sourceLanguagesData ?? []}
                                        requestCurrencyData={requestCurrencyData ?? []}
                                        defaultSelections={defaultSelections}
                                        moduleName={'pct'}
                                        onChange={onDropdownChange}
                                    />
                                    {showModal ? (
                                        <EnglishTranslationEditPopup
                                            formulaValue={
                                                listingData?.descriptionTranslationFormulaModel
                                            }
                                            formulaFields={FormulaFields ?? []}
                                            serviceType={'pct'}
                                            title={
                                                languageIds?.[filteredSourceLanguage]?.langCode ===
                                                'fr'
                                                    ? t(
                                                          'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_FRENCH'
                                                      )
                                                    : t(
                                                          'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_GERMAN'
                                                      )
                                            }
                                            closeModal={closeModal}
                                            onSubmit={handleSubmit}
                                            popupID={
                                                TABLE_POP_IDS.CREATE_POPUP.EDIT_IP_RATES_FORMULA
                                            }
                                            sourceLanguageId={filteredSourceLanguage ?? 0}
                                            requestCurrencyId={filteredReqCurrency ?? 0}
                                        />
                                    ) : (
                                        <></>
                                    )}
                                    {EnglishTranslationFormulaTemplate(PV_SETTINGS_RATES.pct)}
                                </div>
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel
                    pt={getTabPanelPT(1)}
                    header={t('PV_SETTING.RATES.TAB_HEADERS.71_3_CLAIMS')}>
                    {activeIndex === 1 && (
                        <TableData
                            readOnly={readOnly}
                            key={PV_SETTINGS_RATES.claims}
                            sourceLanguageId={
                                filteredSourceLanguage ||
                                getDefaultLanguageCurrencyId()?.defaultLanguageId
                            }
                            requestCurrencyId={
                                filteredReqCurrency ||
                                getDefaultLanguageCurrencyId()?.defaultCurrencyId
                            }
                            columnSchema={columnSchema['claims']}
                            moduleName={'claims'}
                            listingData={listingData}
                            setListingData={setListingData}
                            FormulaFields={FormulaFields ?? []}
                            unitOptionsValues={unitOptionsValues ?? []}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.71_3_CLAIMS')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <FilterDropDown
                                    sourceLanguagesData={sourceLanguagesData ?? []}
                                    requestCurrencyData={requestCurrencyData ?? []}
                                    onChange={onDropdownChange}
                                    moduleName={'claims'}
                                    defaultSelections={defaultSelections}
                                />
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel
                    pt={getTabPanelPT(2)}
                    header={t('PV_SETTING.RATES.TAB_HEADERS.EP_NON_UP')}>
                    {activeIndex === 2 && (
                        <TableData
                            readOnly={readOnly}
                            key={PV_SETTINGS_RATES.ep}
                            sourceLanguageId={
                                filteredSourceLanguage ||
                                getDefaultLanguageCurrencyId()?.defaultLanguageId
                            }
                            requestCurrencyId={
                                filteredReqCurrency ||
                                getDefaultLanguageCurrencyId()?.defaultCurrencyId
                            }
                            columnSchema={columnSchema['ep']}
                            moduleName={'ep'}
                            listingData={listingData}
                            setListingData={(data: any) => {
                                setListingData(data);
                                pvSettingStore.updatePage(undefined, undefined, data);
                            }}
                            FormulaFields={FormulaFields ?? []}
                            unitOptionsValues={unitOptionsValues ?? []}
                            isEnglishTranslationUpdated={isEnglishTranslationUpdated}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.EP_NON_UP')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <div className="flex justify-between items-center w-full">
                                    <FilterDropDown
                                        sourceLanguagesData={sourceLanguagesData ?? []}
                                        requestCurrencyData={requestCurrencyData ?? []}
                                        defaultSelections={defaultSelections}
                                        moduleName={'ep'}
                                        onChange={onDropdownChange}
                                    />
                                    {showModal &&
                                        listingData?.descriptionTranslationFormulaModel && (
                                            <EnglishTranslationEditPopup
                                                formulaValue={
                                                    listingData?.descriptionTranslationFormulaModel
                                                }
                                                formulaFields={FormulaFields ?? []}
                                                serviceType={'ep'}
                                                title={
                                                    languageIds?.[filteredSourceLanguage]
                                                        ?.langCode === 'fr'
                                                        ? t(
                                                              'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_FRENCH'
                                                          )
                                                        : t(
                                                              'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_GERMAN'
                                                          )
                                                }
                                                closeModal={closeModal}
                                                onSubmit={handleSubmit}
                                                popupID={
                                                    TABLE_POP_IDS.CREATE_POPUP.EDIT_IP_RATES_FORMULA
                                                }
                                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                                requestCurrencyId={filteredReqCurrency ?? 0}
                                            />
                                        )}
                                    {EnglishTranslationFormulaTemplate(PV_SETTINGS_RATES.ep)}
                                </div>
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel pt={getTabPanelPT(3)} header={t('PV_SETTING.RATES.TAB_HEADERS.UPC')}>
                    {activeIndex === 3 && (
                        <TableData
                            readOnly={readOnly}
                            key={PV_SETTINGS_RATES.upc}
                            sourceLanguageId={
                                filteredSourceLanguage ||
                                getDefaultLanguageCurrencyId()?.defaultLanguageId
                            }
                            requestCurrencyId={
                                filteredReqCurrency ||
                                getDefaultLanguageCurrencyId()?.defaultCurrencyId
                            }
                            columnSchema={columnSchema['upc']}
                            moduleName={'upc'}
                            listingData={listingData}
                            setListingData={setListingData}
                            FormulaFields={FormulaFields ?? []}
                            unitOptionsValues={unitOptionsValues ?? []}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.UPC')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <div className="flex justify-between items-center w-full">
                                    <FilterDropDown
                                        sourceLanguagesData={sourceLanguagesData ?? []}
                                        requestCurrencyData={requestCurrencyData ?? []}
                                        onChange={onDropdownChange}
                                        moduleName={'upc'}
                                        defaultSelections={defaultSelections}
                                    />
                                    <AgencyFee
                                        rowData={{
                                            currencyData: listingData.currencyData,
                                            agencyFeeInfo: listingData.agencyFeeInfo,
                                            updateValues: {
                                                sourceLanguageId: filteredSourceLanguage,
                                                requestCurrencyId: filteredReqCurrency,
                                                patentServiceId: PV_SETTINGS_RATES['upc']
                                            }
                                        }}
                                    />
                                </div>
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel pt={getTabPanelPT(4)} header={t('PV_SETTING.RATES.TAB_HEADERS.PC')}>
                    {activeIndex === 4 && (
                        <TableData
                            readOnly={readOnly}
                            key={PV_SETTINGS_RATES.pc}
                            sourceLanguageId={
                                filteredSourceLanguage ||
                                getDefaultLanguageCurrencyId()?.defaultLanguageId
                            }
                            requestCurrencyId={
                                filteredReqCurrency ||
                                getDefaultLanguageCurrencyId()?.defaultCurrencyId
                            }
                            columnSchema={columnSchema['pc']}
                            moduleName={'pc'}
                            listingData={listingData}
                            setListingData={(data: any) => {
                                setListingData(data);
                                pvSettingStore.updatePage(undefined, undefined, data);
                            }}
                            FormulaFields={FormulaFields ?? []}
                            unitOptionsValues={unitOptionsValues ?? []}
                            isEnglishTranslationUpdated={isEnglishTranslationUpdated}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.PC')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <div className="flex justify-between items-center w-full">
                                    <FilterDropDown
                                        sourceLanguagesData={sourceLanguagesData ?? []}
                                        requestCurrencyData={requestCurrencyData ?? []}
                                        defaultSelections={defaultSelections}
                                        moduleName={'pc'}
                                        onChange={onDropdownChange}
                                    />
                                    {showModal &&
                                        listingData?.descriptionTranslationFormulaModel && (
                                            <EnglishTranslationEditPopup
                                                formulaValue={
                                                    listingData?.descriptionTranslationFormulaModel
                                                }
                                                formulaFields={FormulaFields ?? []}
                                                serviceType={'pc'}
                                                title={
                                                    languageIds?.[filteredSourceLanguage]
                                                        ?.langCode === 'fr'
                                                        ? t(
                                                              'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_FRENCH'
                                                          )
                                                        : t(
                                                              'PV_SETTING.RATES.ENGLISH_TRANSLATION_FORMULA_GERMAN'
                                                          )
                                                }
                                                closeModal={closeModal}
                                                onSubmit={handleSubmit}
                                                popupID={
                                                    TABLE_POP_IDS.CREATE_POPUP.EDIT_IP_RATES_FORMULA
                                                }
                                                sourceLanguageId={filteredSourceLanguage ?? 0}
                                                requestCurrencyId={filteredReqCurrency ?? 0}
                                            />
                                        )}
                                    {EnglishTranslationFormulaTemplate(PV_SETTINGS_RATES.pc)}
                                </div>
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel
                    pt={getTabPanelPT(5)}
                    header={t('PV_SETTING.RATES.TAB_HEADERS.COMPANY_TRANSLATIONS')}>
                    {activeIndex === 5 && (
                        <TableData
                            readOnly={readOnly}
                            key={`${PV_SETTINGS_RATES.companytranslations}_${TRANSLATION_MODULES?.[0]}`}
                            sourceLanguageId={filteredSourceLanguage ?? 0}
                            requestCurrencyId={filteredReqCurrency ?? 0}
                            targetLanguage={filteredTargetLang ?? 0}
                            columnSchema={CompanySchema}
                            moduleName={'companytranslations'}
                            listingData={listingData}
                            setListingData={setListingData}
                            FormulaFields={FormulaFields ?? []}
                            expandedRows={expandedRows}
                            unitOptionsValues={unitOptionsValues ?? []}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.COMPANY_TRANSLATIONS')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <UnSelectedFilterDropdown
                                    sourceLanguagesData={sourceLanguagesData ?? []}
                                    requestCurrencyData={requestCurrencyData ?? []}
                                    onChange={onDropdownChange}
                                    targetLanguageData={targetLanguageData ?? []}
                                />
                            }
                        />
                    )}
                </TabPanel>
                <TabPanel
                    pt={getTabPanelPT(6)}
                    header={t('PV_SETTING.RATES.TAB_HEADERS.VENDOR_TRANSLATIONS')}>
                    {activeIndex === 6 && (
                        <TableData
                            readOnly={readOnly}
                            key={`${PV_SETTINGS_RATES.vendortranslations}_${TRANSLATION_MODULES?.[1]}`}
                            sourceLanguageId={filteredSourceLanguage ?? 0}
                            requestCurrencyId={filteredReqCurrency ?? 0}
                            targetLanguage={filteredTargetLang ?? 0}
                            columnSchema={vendorSchema}
                            moduleName={'vendortranslations'}
                            listingData={listingData}
                            setListingData={setListingData}
                            FormulaFields={FormulaFields ?? []}
                            expandedRows={expandedRows}
                            unitOptionsValues={unitOptionsValues ?? []}
                            serviceType={`${t('PV_SETTING.RATES.TAB_HEADERS.VENDOR_TRANSLATIONS')}`}
                            {...{ activeIndex }}
                            leftHeaderSection={
                                <UnSelectedFilterDropdown
                                    sourceLanguagesData={sourceLanguagesData ?? []}
                                    requestCurrencyData={vendorCurrencyData ?? []}
                                    onChange={onDropdownChange}
                                    targetLanguageData={targetLanguageData ?? []}
                                    isVendorTranslation
                                />
                            }
                        />
                    )}
                </TabPanel>
            </TabView>
        </div>
    );
}
