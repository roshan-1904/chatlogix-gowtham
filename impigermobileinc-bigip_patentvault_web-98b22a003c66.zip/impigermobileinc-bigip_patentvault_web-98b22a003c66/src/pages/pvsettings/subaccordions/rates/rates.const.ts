import { SERVICE_TYPE_ID, CATEGORY_TYPE_ID } from 'constants/progressStepper.constant';

export const PV_SETTINGS_RATES = {
    pct: SERVICE_TYPE_ID.patent_cooperation_treaty,
    claims: CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims'],
    ep: 2,
    upc: 23,
    pc: SERVICE_TYPE_ID.paris_convention_treaty,
    companytranslations: SERVICE_TYPE_ID.other_translations,
    vendortranslations: SERVICE_TYPE_ID.other_translations
};

export const PV_SETTINGS_RATES_TABS = {
    PCT: 'PCT',
    claims: '71[3] claims',
    EP: 'EP, NON-UP',
    UPC: 'UPC',
    PC: 'PC',
    translation: 'Translation (Non-Filing)'
};

export const PV_SETTINGS_FEE_MODALS: any = {
    translationFeeModel: 'Translation Fee',
    agencyFeeModel: 'Agency Fee',
    officialFeeModel: 'Official Fee',
    companyTranslationFeeModel: 'Company Translation Fee',
    companyAgencyFeeModel: 'Company Agency Fee',
    companyOfficialFeeModel: 'Company Official Fee'
};

export const DIRECT_TRANSLATIONS_OPTIONS = [
    { value: true, label: 'YES' },
    { value: false, label: 'NO' }
];

export const TRANSLATION_LANGUAGE: any = {
    ENG: 'English',
    FRE: 'French',
    GER: 'German'
};

export const SOURCE_LANGUAGE_ID = {
    ENG: 38,
    FRE: 51,
    GER: 59
};

export const RATE_INLINE_EDIT_FIELDS = {
    TRANSLATION_RATE: 'translationRate',
    COMPANY_TRANSLATION_RATE: 'companyTranslationRate',
    ENG_INDIRECT_TRANSLATION_RATE: 'engIndirectTranslationRate',
    COMPANY_ENG_INDIRECT_TRANSLATION_RATE: 'companyEngIndirectTranslationRate',
    AI_TRANSLATION_RATE: 'aiTranslationRate',
    AI_TR_DIFFERENCE: 'trAiTrDifference',
    AI_TR_DIFFERENCE_PERCENT: 'trAiTrDifferencePercent',
    IS_AI_TRANSLATION: 'isAiTranslation',
    COMPANY_AI_TRANSLATION_RATE: 'aiCompanyTranslationRate'
};

export const ADDITIONAL_FIELDS_LANG = ['fr', 'de'];
export const ADDITIONAL_FIELDS_TABS = ['pct', 'ep', 'pc'];

export const DEFAULT_FEE_MODAL = {
    translationFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    },
    officialFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    },
    agencyFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    }
};

export const DEFAULT_COMPANY_FEE_MODAL = {
    companyTranslationFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    },
    companyOfficialFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    },
    companyAgencyFeeModel: {
        feeType: '',
        unitTypeId: 0,
        formula: '',
        fee: 0
    }
};

export const PREFERRED_CURRENCY_MODULES = [0, 2, 4];
export const PREFERRED_CURRENCY_MODULES_NAME = ['pct', 'ep', 'pc'];

export const TRANSLATION_MODULES = ['companytranslations', 'vendortranslations'];
export const HEADER_LANGUAGE_MODULES = ['71[3] claims', 'UPC'];

export const TRANSLATION_TABS = [5, 6];

export const COMPANY_FEE_VALUES: any = {
    companyTranslationRate: 'translationRate',
    companyTranslationFeeModel: 'translationFeeModel',
    companyOfficialFeeModel: 'officialFeeModel',
    companyAgencyFeeModel: 'agencyFeeModel'
};

export const UNIT_FEE_MODEL = {
    PER_WORD: {
        unitId: 4,
        unitName: 'Per Word'
    }
};

export const ENGLISH_TRANSLATION_MODULES = ['pct', 'ep', 'upc', 'pc'];
