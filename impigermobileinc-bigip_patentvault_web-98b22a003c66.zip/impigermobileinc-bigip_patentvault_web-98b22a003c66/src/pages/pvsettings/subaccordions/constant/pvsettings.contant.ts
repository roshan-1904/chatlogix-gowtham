export const PV_SETTINGS_END_POINT = '/patentvaultsettings';
