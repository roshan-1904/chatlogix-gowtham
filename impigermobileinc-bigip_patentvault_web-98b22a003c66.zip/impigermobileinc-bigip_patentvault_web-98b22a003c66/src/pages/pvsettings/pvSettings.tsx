import { useTranslation } from 'react-i18next';

import AddressInformation from './subaccordions/addressInformation/addressInformation';
import CurrencyExchanges from './subaccordions/currencyExchanges/currencyExchanges';
import { useState } from 'react';
import Rates from './subaccordions/rates/rates';

const PVSettings: React.FC = () => {
    const { t } = useTranslation();
    const [visibility, setVisibility] = useState<boolean>(true);

    return (
        <div data-testid="PV-Settings-Page">
            <div className="h-[2.87rem] border-b-2 border-b-primary/70 bg-white pl-4">
                <div className="flex items-center h-full ">
                    <h4 className="font-semibold  cursor-pointer">
                        {t('MENU.PATENT_VAULT_SETTINGS')}
                    </h4>
                </div>
            </div>

            <div className="bg-neutral w-full ">
                <div className="p-2 md:p-2 md:px-3">
                    <div className="grid gap-y-1 md:grid md:gap-y-2 md:p-2">
                        <div className="collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg">
                            <input
                                type="checkbox"
                                className="py-1 min-h-0"
                                name="pv-settings"
                                defaultChecked
                            />
                            <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                                <span className=" text-xl font-medium text-primary">
                                    {t('COMMON.ADDRESS_INFORMATION')}
                                </span>
                            </div>
                            <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                <AddressInformation
                                    visibility={visibility}
                                    setVisibility={setVisibility}
                                />
                            </div>
                        </div>
                        <div className="collapse collapse-arrow bg-white border-neutral-50 border-2  rounded-lg">
                            <input type="checkbox" className="py-1 min-h-0" name="pv-settings" />
                            <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                <span className=" text-xl font-medium text-primary">
                                    {t('COMMON.CURRENCY_EXCHANGES')}
                                </span>
                            </div>
                            <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 w-full overflow-auto">
                                <CurrencyExchanges />
                            </div>
                        </div>
                        <div className="collapse collapse-arrow bg-white border-neutral-50 border-2  rounded-lg">
                            <input type="checkbox" className="py-1 min-h-0" name="pv-settings" />
                            <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                <span className=" text-xl font-medium text-primary">
                                    {t('COMMON.RATES')}
                                </span>
                            </div>
                            <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 w-full overflow-auto">
                                <Rates />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PVSettings;
