import { Form } from '@formio/react';
import { FC } from 'react';
import sampleData from './dynamicForm.mock.json';
import '../../../src/assets/css/bootstrap-grid.min.css';

export const FormRender: FC = () => {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    const formData = sampleData.formDesign;

    // const onFormChange = (schema: any) => {
    // };

    return (
        <div className="container p-5">
            <Form
                // onInitialized={(e: any) => onFormChange(e)}
                form={formData}
                // onChange={(e: any) => onFormChange(e)}
            />
            <div>
                <div className="d-flex justify-content-center">
                    <br />
                    <br />
                    <br />
                </div>
            </div>
        </div>
    );
};
