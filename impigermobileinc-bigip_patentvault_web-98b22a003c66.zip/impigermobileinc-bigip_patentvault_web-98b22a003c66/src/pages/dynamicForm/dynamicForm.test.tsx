import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // for better assertions
import { FormRender } from './dynamicForm';
import sampleData from './dynamicForm.mock.json';
import { Form } from '@formio/react';

// Mock the Form component from @formio/react
jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div data-testid="mock-form">Mock Form Component</div>)
}));

describe('FormRender Component', () => {
    test('should pass the form data correctly to the Form component', () => {
        render(<FormRender />);

        // Ensure that the Form component was called with the correct props
        expect(Form).toHaveBeenCalledWith(
            expect.objectContaining({
                form: sampleData.formDesign
            }),
            {}
        );
    });
});
