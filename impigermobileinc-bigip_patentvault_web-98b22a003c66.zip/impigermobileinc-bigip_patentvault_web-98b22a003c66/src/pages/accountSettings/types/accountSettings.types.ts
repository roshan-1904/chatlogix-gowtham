export interface AccountInfoModal {
    visible: boolean;
    modalDescription: string;
}
export interface AccountInfoFormData {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    email?: string;
    id?: number;
    userTypeId?: number | null;
}
export interface GetAccountInfoApiResponse {
    firstName: string;
    middleName: string | null;
    lastName: string;
    phoneNumber: string;
    companyPrimaryPhoneNumber: string;
    email: string;
    userTypeId: number;
    roleId: number;
    roleName: string;
    userTypeName: string | null;
    companyName: string;
    companyId: number;
    mailingAddressModel: {
        address1: string;
        address2: string;
        city: string;
        state: string;
        stateId: string | null;
        country: string;
        countryId: string | null;
        zip: string;
        billingEmail: string | null;
        ccRecipients: string | null;
        isSameAddress: boolean | null;
    } | null;
    companyMailingAddressModel: {
        address1: string;
        address2: string;
        city: string;
        state: string;
        stateId: string | null;
        country: string;
        countryId: string | null;
        zip: string;
        billingEmail: string;
        ccRecipients: string;
        isSameAddress: boolean | null;
    } | null;
    profileBillingModel: {
        paymentMethodId: number;
        paymentMethodName: string;
        currencyId: number;
        currencyName: string;
        taxId: string;
    } | null;
    id: number;
    createdBy: number;
    createdAt: string;
    updatedBy: number;
    updatedAt: string;
    isActive: boolean;
}
