import HttpService from 'core/interceptor/api.handler';
import accountSettingsService from './accountSettingsService';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getUpdateAccountInfo', () => {
        const requestBody = {
            firstName: 'John',
            lastName: 'Doe',
            phoneNumber: '1234567890',
            countryCode: 'US',
            email: 'test@gmail.com',
            id: 1,
            userTypeId: null
        };
        it('should fetch getUpdateAccountInfo successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await accountSettingsService.getUpdateAccountInfo(requestBody);
            expect(result).toEqual([]);
        });
    });
});
