import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import AuthStore from 'core/store/authStore/authStore';
import { AccountInfoFormData } from '../types/accountSettings.types';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

/**
 * Fetches/update user's account information based on userId.
 * @param requestBody
 */
export const getUpdateAccountInfo = async <GetAccountInfoApiResponse>(
    requestBody?: AccountInfoFormData
): Promise<GetAccountInfoApiResponse> => {
    const userId = AuthStore?.getUserInfo()?.userInfo?.userId;
    const apiUrl = `${END_POINT.ACCOUNT_SETTINGS.GET_USER_DETAILS}/${userId}`;
    try {
        const response: GetAccountInfoApiResponse = requestBody
            ? await httpService.post(apiUrl, requestBody)
            : await httpService.get<GetAccountInfoApiResponse>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching user profile data:', error);
        throw error;
    }
};

const accountSettingsService = {
    getUpdateAccountInfo
};

export default accountSettingsService;
