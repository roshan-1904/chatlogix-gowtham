import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AccountSettings from '../accountSettings';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({
        pathname: '/account-settings',
        state: { from: '/orders-quotes' }
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('core/utils/utils', () => ({
    ...jest.requireActual('core/utils/utils'),
    deepEqualValuesOnly: jest.fn(),
    focusOnFirstError: jest.fn(),
    isContactUser: jest.fn(),
    showToastMessage: jest.fn()
}));

jest.mock('core/store/authStore/authStore');
jest.mock('core/interceptor/api.handler');
jest.mock('../services/accountSettingsService', () => ({
    getUpdateAccountInfo: jest.fn()
}));
jest.mock('core/store/accountSettingsStore/accountSettingsStore', () => ({
    getData: jest.fn(),
    subscribe: jest.fn(),
    updateFormData: jest.fn()
}));

describe('AccountSettings Component', () => {
    let mockUserDetails;
    beforeEach(() => {
        mockUserDetails = {
            userInfo: {
                roleId: 1,
                userId: '12345',
                userFullName: 'John Doe'
            }
        };
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue(mockUserDetails);
    });

    test('renders the AccountSettings component without errors', () => {
        render(
            <MemoryRouter>
                <AccountSettings />
            </MemoryRouter>
        );
        expect(screen.getByTestId('account-settings')).toBeInTheDocument();
    });

    test('renders the personal information section', () => {
        render(<AccountSettings />);

        waitFor(() => {
            expect(screen.getByText('COMMON.PERSONAL_INFORMATION')).toBeInTheDocument();
            expect(screen.getByText('John')).toBeInTheDocument();
            expect(screen.getByText('Doe')).toBeInTheDocument();
        });
    });

    test('handles edit mode toggle', async () => {
        render(
            <MemoryRouter>
                <AccountSettings />
            </MemoryRouter>
        );

        const editButton = screen.getByTestId('edit-profile');
        expect(editButton).toBeInTheDocument();

        fireEvent.click(editButton);

        await waitFor(() => {
            expect(screen.getByText('COMMON.SAVE')).toBeInTheDocument();
        });
    });
});
