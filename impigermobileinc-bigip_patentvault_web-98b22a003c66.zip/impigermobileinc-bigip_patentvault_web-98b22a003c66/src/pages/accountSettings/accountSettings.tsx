import { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ROLE } from 'constants/app.constant';
import AuthStore from 'core/store/authStore/authStore';
import {
    deepEqualValuesOnly,
    focusOnFirstError,
    getAvatarName,
    isContactUser,
    showToastMessage
} from 'core/utils/utils';
import { renderLabel } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import { useTranslation } from 'react-i18next';
import keyIcon from 'assets/svgs/key-icon.svg';
import { getUpdateAccountInfo } from './services/accountSettingsService';
import {
    AccountInfoFormData,
    AccountInfoModal,
    GetAccountInfoApiResponse
} from './types/accountSettings.types';
import { useLocation, useNavigate } from 'react-router-dom';
import HttpService from 'core/interceptor/api.handler';
import AccountInfoFormBuilderData from './data/accountSettingsForm.json';
import { Form } from '@formio/react';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import accountInfoStore from 'core/store/accountSettingsStore/accountSettingsStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

export default function AccountSettings() {
    const navigate = useNavigate();
    const { pathname, state: locationState } = useLocation();
    const { t } = useTranslation();
    const httpService = new HttpService();
    const userDetails = AuthStore.getUserInfo();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(AccountInfoFormBuilderData);
    const [userInfo, setUserInfo] = useState<GetAccountInfoApiResponse>(
        {} as GetAccountInfoApiResponse
    );
    const [isError, setIsError] = useState<boolean>(false);
    const [editMode, setEditMode] = useState(false);
    const currentUserRole = userDetails?.userInfo?.roleId;
    const {
        firstName = '',
        lastName = '',
        companyName = '',
        companyMailingAddressModel = null,
        mailingAddressModel = null,
        profileBillingModel = null
    } = userInfo;
    const [accountStoreModuleData, setAccountStoreModuleData] = useState(
        accountInfoStore.getData()
    );
    const [editAvatar, setEditAvatar] = useState<string>(
        getAvatarName(
            firstName && lastName ? `${firstName} ${lastName}` : userDetails?.userInfo.userFullName
        ) || ''
    );
    const [defaultFormData, setDefaultFormData] = useState(accountStoreModuleData);
    const [showModal, setShowModal] = useState<AccountInfoModal>({
        visible: false,
        modalDescription: t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')
    });
    const initialData = {
        data: {
            ...accountStoreModuleData
        }
    };
    accountInfoStore.subscribe(setAccountStoreModuleData);
    const isFormValuesUpdated = !deepEqualValuesOnly(defaultFormData as object, {
        ...(accountStoreModuleData as object)
    });
    const canChangePassword = false;
    const valueStyle = 'text-base break-words md:break-normal font-semibold leading-5 pt-1';
    const personImg = '';

    const showErrMsg = () => {
        setIsError(true);
        showToastMessage({
            type: ToastType.ERROR,
            message: t('COMMON.GET_PERSONAL_INFORMATION_FAILURE')
        });
    };

    const getUserDetail = async () => {
        try {
            const response: GetAccountInfoApiResponse =
                await getUpdateAccountInfo<GetAccountInfoApiResponse>();
            if (response) {
                setUserInfo(response);
                const accountFormData = {
                    firstName: response?.firstName || '',
                    lastName: response?.lastName || '',
                    phoneNumber: response?.phoneNumber || '',
                    email: response?.email || '',
                    role: response?.roleName || '',
                    currentUserRole,
                    userTypeId: response?.userTypeId || null,
                    address1: response?.companyMailingAddressModel?.address1 || '',
                    address2: response?.companyMailingAddressModel?.address2 || '',
                    country: response?.companyMailingAddressModel?.country || '',
                    city: response?.companyMailingAddressModel?.city || '',
                    state: response?.companyMailingAddressModel?.state || '',
                    zip: response?.companyMailingAddressModel?.zip || ''
                };
                setDefaultFormData(accountFormData);
                accountInfoStore.updateFormData(accountFormData);
            } else {
                showErrMsg();
            }
        } catch (error) {
            showErrMsg();
            console.error('Error in fetching user details:', error);
        }
    };

    const updateUserDetail = async (requestBody: AccountInfoFormData) => {
        try {
            const response: GetAccountInfoApiResponse =
                await getUpdateAccountInfo<GetAccountInfoApiResponse>(requestBody);
            if (response) {
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('COMMON.PERSONAL_INFORMATION_SUCCESS')
                });
                setEditMode(false);
                getUserDetail();
            }
        } catch (error) {
            showToastMessage({
                type: ToastType.ERROR,
                message: t('COMMON.PERSONAL_INFORMATION_FAILURE')
            });
            console.error('Error in updating user details:', error);
        }
    };

    const handleUpdateAccount = async () => {
        document.getElementById('submit-account-info')?.click();
        await new Promise((r) => setTimeout(r, 100));
    };

    const onFormChange = (e: any) => {
        const updatedFormData: AccountInfoFormData = e.data;
        if (e.changed) {
            accountInfoStore.updateFormData(updatedFormData);
            setEditAvatar(
                getAvatarName(`${updatedFormData.firstName} ${updatedFormData.lastName}`) || ''
            );
        }
    };

    const onSubmitChange = async (e: any) => {
        const updatedFormData = e?.data as AccountInfoFormData;
        await updateUserDetail({
            firstName: updatedFormData?.firstName,
            lastName: updatedFormData?.lastName,
            phoneNumber: updatedFormData?.phoneNumber,
            email: updatedFormData?.email,
            userTypeId: accountStoreModuleData?.userTypeId,
            id: userDetails?.userInfo?.userId
        });
    };
    const getAddress = (getCompanyAddress = false) => {
        const addressModal = getCompanyAddress ? companyMailingAddressModel : mailingAddressModel;
        if (!addressModal) return '';
        const {
            address1 = '',
            address2 = '',
            city = '',
            state = '',
            country = '',
            zip: zipCode = ''
        } = addressModal;
        return `${address1}, ${address2}\n${city}, ${state}, ${country} - ${zipCode}`;
    };

    const handleModalChange = (
        show = false,
        description = t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')
    ) => {
        setShowModal((prev: AccountInfoModal) => ({
            ...prev,
            visible: show,
            modalDescription: description
        }));
    };

    const handleConfirm = () => {
        handleModalChange();
        if (showModal?.modalDescription === t('COMMON.CLOSE_INFORMATION')) setEditMode(false);
        accountInfoStore.updateFormData(defaultFormData);
    };

    const handleBack = () => {
        if (editMode) {
            isFormValuesUpdated
                ? handleModalChange(true, t('COMMON.CLOSE_INFORMATION'))
                : setEditMode(false);
        } else if (locationState?.from) {
            navigate(`${locationState.from}`);
        } else {
            navigate(
                userDetails.userInfo?.roleId === ROLE.VENDOR_SPECIALIST.roleId
                    ? '/task-management'
                    : '/orders-quotes',
                { replace: true }
            ); // Navigate and replace current entry
        }
    };

    const updateFormFields = (formJson: any) => {
        const updatedComponents = (formJson?.components || []).map((component: any) => {
            if (component.type === 'columns') {
                // Loop through the columns to find the fields to update
                component.columns = component?.columns.map((column: any) => {
                    column.components = column?.components?.map((field: any) => {
                        if (['firstName', 'lastName', 'phoneNumber'].includes(`${field.key}`)) {
                            field.disabled = !editMode; // Set disabled to true if not in edit mode
                            field.validateOn = editMode ? field.validateOn : 'blur';
                        }
                        return field;
                    });
                    return column;
                });
            }
            return component;
        });

        return { ...formJson, components: updatedComponents };
    };

    const renderEditForm = () => {
        return (
            <div data-testid="edit-profile-info-container" className="max-h-fit">
                <div className="flex align-center justify-between">
                    <h1 className="text-xl font-medium text-primary-500">
                        {t('COMMON.PERSONAL_INFORMATION')}
                    </h1>
                    <div className="flex gap-2 min-h-[2.5rem]">
                        {editMode ? (
                            <>
                                <button
                                    disabled={!isFormValuesUpdated}
                                    onClick={() => isFormValuesUpdated && handleModalChange(true)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            isFormValuesUpdated && handleModalChange(true);
                                        }
                                    }}
                                    className={'btn btn-sm button-neutral font-medium'}
                                    data-testid="cancel-account-info">
                                    {t('COMMON.CANCEL')}
                                </button>
                                <button
                                    disabled={!isFormValuesUpdated}
                                    className={'btn btn-sm button-primary font-medium'}
                                    onClick={() => {
                                        handleUpdateAccount().catch(console.error);
                                    }}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleUpdateAccount().catch(console.error);
                                        }
                                    }}
                                    data-testid="submit-account-info">
                                    {t('COMMON.SAVE')}
                                </button>{' '}
                            </>
                        ) : (
                            <button
                                data-testid="edit-profile"
                                className={`btn button-primary-outline min-h-[2rem] h-[2rem] !font-medium w-18 ${isError ? 'cursor-not-allowed opacity-75' : ''}`}
                                onClick={() => !isError && setEditMode(true)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !isError) {
                                        setEditMode(true);
                                    }
                                }}>
                                <i className="pi pi-pencil h-3 w-3"></i>
                                <span>{t('COMMON.EDIT')}</span>
                            </button>
                        )}
                    </div>
                </div>
                <div
                    className="mt-2 p-4 pt-2 pl-0 flex align-center"
                    data-testid="profile-image-container">
                    {/* Profile picture is on second phase that's why hidden as per Lydia feedback changes and BA Team */}
                    <div data-testid="image-container" className="hidden">
                        {personImg ? (
                            <img
                                className="w-[60px] h-[60px] rounded-full"
                                src={personImg}
                                alt="avatar"
                                data-testid="avatar"
                            />
                        ) : (
                            <div className="avatar placeholder">
                                <div className="bg-[url('/public/images/svgs/profile-bg.png')] bg-cover text-white rounded-full w-10 md:w-16">
                                    <span className="text-[14px] md:text-[16px]">{editAvatar}</span>
                                </div>
                            </div>
                        )}
                    </div>
                    {showModal?.visible && (
                        <ConfirmationPopup
                            onConfirm={handleConfirm}
                            onCancel={handleModalChange}
                            visible={showModal?.visible}
                            headerText={t('COMMON.CONFIRMATION')}
                            description={showModal?.modalDescription}
                            acceptLabel={t('COMMON.YES_DISCARD')}
                            rejectLabel={t('COMMON.NO_DON_T')}
                            rejectClassName={'!bg-error !px-6 !text-white'}
                            acceptClassName={'!bg-neutral-50 !px-5 !text-black !border-neutral-100'}
                        />
                    )}
                    <div className="ml-3 w-full">
                        <Form
                            form={updateFormFields(formBuilderData)}
                            submission={initialData}
                            onChange={(e: any) => onFormChange(e)}
                            onSubmit={(e: any) => onSubmitChange(e)}
                            onError={focusOnFirstError}
                        />
                    </div>
                </div>
            </div>
        );
    };

    useEffect(() => {
        getUserDetail();
    }, [pathname]);
    return (
        <div className="w-full h-full overflow-x-hidden" data-testid="account-settings">
            <div className="h-[3.87rem] border-b-2 border-b-primary/70 bg-white pl-4">
                <div
                    className="flex items-center h-full w-fit cursor-pointer"
                    data-testid="back-button-container"
                    onClick={handleBack}
                    tabIndex={0}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            handleBack();
                        }
                    }}>
                    <i className="pi pi-chevron-left text-base mt-0.5 mr-2" />
                    <h4 className="font-semibold">{t('COMMON.BACK')}</h4>
                </div>
            </div>
            <div className="flex flex-col justify-center items-center m-3">
                <div className="w-9/12 h-fit">
                    <div className="bg-white shadow-md border border-gray-300 rounded-lg p-5">
                        <div data-testid="profile-info-container" className="px-2">
                            {renderEditForm()}
                            {isContactUser(currentUserRole) && (
                                <div
                                    data-testid="company-info"
                                    className="py-3 mt-3 border-t-2 border-dashed">
                                    <h1 className="text-xl font-medium text-primary-500 pt-2">
                                        {t('COMMON.COMPANY_DETAILS')}
                                    </h1>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-9 mt-4 mb-5">
                                        <div>
                                            {renderLabel(t('COMPANY_DETAILS.COMPANY_NAME'))}
                                            <div className={valueStyle} data-testid="company-name">
                                                {companyName
                                                    ? companyName?.split(',')?.map((name) => (
                                                          <div
                                                              key={uuidv4()}
                                                              className="leading-[18px] pt-2">
                                                              {name}
                                                          </div>
                                                      ))
                                                    : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                            {currentUserRole === ROLE.VENDOR_SPECIALIST.roleId && (
                                <>
                                    {mailingAddressModel && (
                                        <div
                                            data-testid="mailing-info"
                                            className="border-t-2 border-dashed py-3">
                                            <h1 className="text-xl font-medium text-primary-500">
                                                {t('COMMON.MAILING_ADDRESS')}
                                            </h1>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-7 mt-4 mb-4">
                                                <div>
                                                    {renderLabel(t('COMMON.ADDRESS_INFORMATION'))}
                                                    <div
                                                        className={`${valueStyle} leading-[18px] whitespace-pre-wrap`}
                                                        data-testid="vendor-address-info">
                                                        {getAddress() || '-'}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    <div
                                        data-testid="billing-info"
                                        className="py-3 border-t-2 border-dashed">
                                        <h1 className="text-xl font-medium text-primary-500">
                                            {t('COMPANIES.BILLING_INFORMATION.TITLE')}
                                        </h1>
                                        <div
                                            className="grid grid-cols-1 md:grid-cols-4 gap-7 mt-3 pt-2"
                                            data-testid="vendor-billing-info">
                                            <div>
                                                {renderLabel(t('COMMON.PAYMENT_METHOD'))}
                                                <div
                                                    className={valueStyle}
                                                    data-testid="payment-method">
                                                    {profileBillingModel?.paymentMethodName ?? '-'}
                                                </div>
                                            </div>
                                            <div>
                                                {renderLabel(t('PV_SETTING.RATES.CURRENCY'))}
                                                <div
                                                    className={valueStyle}
                                                    style={{ fontSize: '1rem' }}
                                                    data-testid="currency-name">
                                                    {profileBillingModel?.currencyName ?? '-'}
                                                </div>
                                            </div>
                                            <div>
                                                {renderLabel(t('COMMON.TAX_ID'))}
                                                <div className={valueStyle} data-testid="tax-id">
                                                    {profileBillingModel?.taxId ?? '-'}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                    {canChangePassword && (
                        <div className="mt-3">
                            <button className="btn btn-sm text-primary-500 bg-white border-[#A2CFF2]">
                                <img
                                    src={keyIcon}
                                    className="h-4 w-4 cursor-pointer"
                                    alt="key-icon"
                                />
                                {t('COMMON.CHANGE_PASSWORD')}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
