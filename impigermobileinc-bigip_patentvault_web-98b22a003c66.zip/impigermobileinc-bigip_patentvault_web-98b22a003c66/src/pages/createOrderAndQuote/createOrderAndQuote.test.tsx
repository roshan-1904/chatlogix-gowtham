import { render, screen } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import CreateOrderAndQuote from './createOrderAndQuote';

// Mock dependencies
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

describe('CreateOrderAndQuote', () => {
    test('renders the component', () => {
        (useLocation as jest.Mock).mockReturnValue({
            pathname: '/test-path'
        });
        render(
            <MemoryRouter>
                <CreateOrderAndQuote />
            </MemoryRouter>
        );

        // Assert that the component renders without throwing an error
        expect(screen.getByTestId('CreateOrderAndOrder')).toBeInTheDocument();
    });
});
