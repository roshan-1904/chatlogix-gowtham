import FileUpload from 'components/fileUpload/fileUpload';
import { MODULE_TYPE } from 'constants/app.constant';
import { ORDER_QUOTE_MODULE, QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

const OrderAndQuoteFileUpload = () => {
    const selectedService = quoteOrderModuleStore.getData()?.info?.selectedService;
    const pcServiceType = quoteOrderModuleStore.getData()?.info?.selectedService;
    const isPCServiceType =
        pcServiceType?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty; // Check if selected service is Paris Convention
    const isStandardFlow = selectedService?.serviceTypeId === SERVICE_TYPE_ID.other_translations; // Check if selected service is standard
    const isMandatory = isPCServiceType || isStandardFlow; // Check if file upload is mandatory

    const moduleId = MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId;
    const azureFolderName = MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName;
    const primaryId = quoteOrderModuleStore.getData()?.info?.primaryId ?? 0; // Get primaryId from store
    const uploadFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPLOAD_FILE}${primaryId}&moduleType=${moduleId}`; // Upload file API URL
    const getFileListApiUrl = `${quoteBaseURL}${ORDER_QUOTE_MODULE.GET_FILE_LIST}${primaryId}`; // Get file list API URL
    const deleteFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`; // Delete file API URL
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`; // Get document type API URL
    const updateDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPDATE_DOCUMENT_TYPE}`; // Update document type API URL

    return (
        <div className="userProfilePage p-2" data-testid="userProfilePage">
            <FileUpload
                uploadFileApiUrl={uploadFileApiUrl}
                getFileListApiUrl={getFileListApiUrl}
                deleteFileApiUrl={deleteFileApiUrl}
                getDocumentTypeApiUrl={getDocumentTypeApiUrl}
                updateDocumentTypeApiUrl={updateDocumentTypeApiUrl}
                moduleType={{ moduleId, azureFolderName }}
                primaryId={primaryId}
                stepperModuleStore={quoteOrderModuleStore}
                documentUploadRequired={isMandatory}
                moduleName={'quoteOrder-' + primaryId}
                data-testid="fileUploadComponent"
            />
        </div>
    );
};

export default OrderAndQuoteFileUpload;
