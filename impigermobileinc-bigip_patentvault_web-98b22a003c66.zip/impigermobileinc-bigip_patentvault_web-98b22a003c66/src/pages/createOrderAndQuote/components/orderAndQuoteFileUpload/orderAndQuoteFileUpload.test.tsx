import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import OrderAndQuoteFileUpload from './orderAndQuoteFileUpload';
// import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';

// Mock environment variables
process.env.REACT_APP_QUOTE_BASE_URL = 'http://mock-api-url.com';

// Mock the data returned from the store
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn()
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

// Define the type of quoteOrderModuleStore
// const quoteOrderModuleStore: {
//     getData: jest.Mock;
// } = require('core/store/orderQuoteStore/orderQuote.store');

describe('OrderAndQuoteFileUpload', () => {
    beforeEach(() => {
        // Mocking the store's getData function
        // (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
        //     info: {
        //         selectedService: { serviceTypeId: SERVICE_TYPE_ID.other_translations },
        //         primaryId: 123
        //     }
        // });
    });

    test('should render the FileUpload component with the correct props when it is a standard flow', () => {
        render(<OrderAndQuoteFileUpload />);

        waitFor(() => {
            expect(screen.getByTestId('userProfilePage')).toBeInTheDocument();

            const fileUploadComponent = screen.getByTestId('fileUploadComponent');

            // Assert that the file upload component is rendered
            expect(fileUploadComponent).toBeInTheDocument();

            // Check if the uploadFileApiUrl is formed correctly
            const expectedUploadUrl =
                'http://mock-api-url.com/upload-file-api/123&moduleType=quote_order_module';
            expect(fileUploadComponent).toHaveAttribute('uploadFileApiUrl', expectedUploadUrl);
        });
    });

    test('should render the FileUpload component with optional document upload when it is not a standard flow', () => {
        // Mocking the store's getData function for a non-standard flow
        // quoteOrderModuleStore.getData.mockReturnValue({
        //     info: {
        //         selectedService: { serviceTypeId: 'some-other-service' },
        //         primaryId: 456
        //     }
        // });

        render(<OrderAndQuoteFileUpload />);

        waitFor(() => {
            const fileUploadComponent = screen.getByTestId('fileUploadComponent');

            // Check if documentUploadOptionalText is set to true (optional) when not standard flow
            expect(fileUploadComponent).toHaveAttribute('documentUploadOptionalText', 'true');
        });
    });
});
