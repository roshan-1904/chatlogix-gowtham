import { useMemo } from 'react';
import { Form } from '@formio/react';
import { useTranslation } from 'react-i18next';

import AdditionalInfoFormBuilderData from '../mocks/additionalInfoForm.mock.json';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { PATHS } from 'constants/routes.constant';
import HttpService from 'core/interceptor/api.handler';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { isContactUser } from 'core/utils/utils';

const AdditionalInfo = () => {
    const { t } = useTranslation();
    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(
        AdditionalInfoFormBuilderData
    );
    const isThisContactUser = isContactUser(loggedInUserRoleId, true);
    const isEditFlow: boolean = quoteOrderData?.info?.isEditFlow === true;
    const selectedService = quoteOrderData?.info.selectedService;
    const isPC = selectedService?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;

    if (!isEditFlow) {
        if (isThisContactUser) {
            if (quoteOrderData?.formData?.additionalInfoPage) {
                quoteOrderData.formData.additionalInfoPage.emailID = AuthStore.getUserInfo()
                    ? AuthStore.getUserInfo().userInfo.signinName
                    : '';
            }
        } else {
            if (
                quoteOrderData?.formData?.companyDetailsPage &&
                quoteOrderData?.formData?.companyDetailsPage.selectedContact &&
                quoteOrderData?.formData?.companyDetailsPage.selectedContact.email
            ) {
                if (quoteOrderData?.formData?.additionalInfoPage) {
                    quoteOrderData.formData.additionalInfoPage.emailID =
                        quoteOrderData?.formData.companyDetailsPage.selectedContact.email;
                }
            }
        }
    }

    /** We don't have 'Company-Page' for PC. So take company-id from Patent-Details page. */
    const selectedCompanyId = isPC
        ? quoteOrderData?.formData?.patentDetailsPage?.companyName
        : quoteOrderData?.formData?.companyDetailsPage?.selectedCompany?.id;

    const initialData = {
        data: {
            ...quoteOrderData?.formData.additionalInfoPage,

            // update hidden fields with real-time data
            selectedCategoryId: quoteOrderData?.info?.selectedCategory?.patentCategoryId,
            selectedCompanyId,
            mode: quoteOrderData?.info.mode,
            role: userDetails?.userInfo.roleId,
            selectedCompanyPoRequired:
                quoteOrderData?.formData.companyDetailsPage?.selectedCompany?.isPoRequired
        }
    };

    const onFormChange = (e: any) => {
        const { data } = e;
        const updatedFormData = data;
        const fetchFormData = quoteOrderData?.formData.additionalInfoPage;

        if (e.changed && JSON.stringify(updatedFormData) !== JSON.stringify(fetchFormData)) {
            updateStore(updatedFormData, false);
        }
    };

    const onSubmitChange = (e: any) => {
        const { data } = e;
        const updatedFormData = data;
        updateStore(updatedFormData);
    };

    // update store
    const updateStore = (updatedFormData: any, isValid = true) => {
        updateFormData(updatedFormData);
        updateIsFormValid(isValid);
    };
    const updateFormData = (updatedFormData: any) => {
        const updatedQuoteOrderFormData = {
            ...quoteOrderData.formData,
            additionalInfoPage: updatedFormData
        };

        quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
    };
    const updateIsFormValid = (isValid: boolean) => {
        const updatedQuoteOrderIsFormValid = {
            ...quoteOrderData.isFormValid,
            [PATHS.ADDITIONAL_INFO]: isValid
        };

        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
    };

    return (
        <div data-testid="additional-info-container" className="additionalInfoPage">
            <h4 className="font-semibold px-5 pt-4" data-testid="additional-info-title">
                {t('ADDITIONAL_INFO.TITLE')}
            </h4>
            <div className="p-3 additionalInfoStepper" data-testid="additional-info-form-container">
                <Form
                    form={formBuilderData}
                    submission={initialData}
                    onChange={(e: any) => onFormChange(e)}
                    onSubmit={(e: any) => onSubmitChange(e)}
                    data-testid="additional-info-form"
                />
            </div>
        </div>
    );
};

export default AdditionalInfo;
