import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import AdditionalInfo from './additionalInfo';
import { BrowserRouter as Router } from 'react-router-dom';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

// Mock dependencies
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(),
    updatePage: jest.fn()
}));
jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn().mockReturnValue({ userInfo: { roleId: 'roleId', userId: 'userId' } })
}));
jest.mock('core/interceptor/api.handler');

describe('AdditionalInfo', () => {
    beforeEach(() => {
        // Mock implementation
        jest.clearAllMocks();
    });

    it('should render the AdditionalInfo component', () => {
        render(
            <Router>
                <AdditionalInfo />
            </Router>
        );
        waitFor(() => {
            expect(screen.getByText('ADDITIONAL_INFO.TITLE')).toBeInTheDocument();
            expect(screen.getByTestId('AdditionalInformation')).toBeInTheDocument();
        });
    });

    it('should update emailID based on user role', () => {
        render(
            <Router>
                <AdditionalInfo />
            </Router>
        );
        waitFor(() => {
            expect(quoteOrderModuleStore.getData().formData.additionalInfoPage.emailID).toBe(
                'user@example.com'
            );
        });
    });
});
