import { FC, useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import logoPCT from 'assets/svgs/logo-pct.svg';
import logoEP from 'assets/svgs/logo-ep.svg';
import logoPC from 'assets/svgs/logo-pc.svg';
import logoSTD from 'assets/svgs/logo-std.svg';
import tickGreen from 'assets/svgs/tick-green.svg';

import serviceTypeService from '../services/serviceType.service';
import {
    EditFlowData,
    PatentCategories,
    ProjectManager,
    SalesRep,
    SelectedServiceDetails,
    ServiceAndCategoryType
} from '../types/serviceType.type';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import {
    QuoteOrderModuleStore,
    QuoteOrderModuleStoreFormData,
    QuoteOrderModuleStoreInfo,
    ServiceTypeData
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import {
    STEPPER_DATA_TYPE,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import { PATHS } from 'constants/routes.constant';
import {
    PATHS_FOR_STEPPER,
    SERVICE_TYPE_ID,
    STEPPER_DATA
} from 'constants/progressStepper.constant';
import { MODE, STATUS_MODE, YES_NO } from 'constants/app.constant';
import companyDetailsService from '../../companyDetails/services/companyDetails.service';
import { Company, ContactUser } from '../../companyDetails/types/companyDetails.type';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { LanguageSelectionDataItem } from '../../standard/languageSelection/types/languageSelection.type';
import { isContactUser } from 'core/utils/utils';

type ServiceAndCategory = 'service' | 'category';

const ServiceType = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;

    const [quoteOrderData, setQuoteOrderData] = useState<QuoteOrderModuleStore>(
        quoteOrderModuleStore.getData()
    );
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;

    const [serviceType, setServiceType] = useState<ServiceAndCategoryType[]>();
    const [selectedServiceDetails, setSelectedServiceDetails] = useState<SelectedServiceDetails>();
    const [isInitialRendering, setIsInitialRendering] = useState<boolean>(true);

    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const mode = quoteOrderData?.info?.mode;
    const isQuoteCreation = mode === MODE.CREATE_QUOTE;
    const isEditQuoteFlow: boolean = quoteOrderData?.info?.isEditFlow === true;

    // api
    const getServiceType = async (): Promise<ServiceAndCategoryType[] | null> => {
        try {
            const serviceTypeResponse: ServiceAndCategoryType[] =
                await serviceTypeService.getServiceType();
            if (serviceTypeResponse) {
                setServiceType(serviceTypeResponse);
            }

            return serviceTypeResponse ?? null;
        } catch (error) {
            console.error('Error in getServiceType:', error);
            return null;
        }
    };

    // function to handle the stepper update based on source language only for PC flow
    const handleStepperUpdate = () => {
        if (isThisContactUser) {
            removeLastStepInStepper();
        }
    };
    // function to remove the last step in stepper
    const removeLastStepInStepper = () => {
        try {
            const stepperData = stepperStore.getStepperData();
            const summaryStep: STEPPER_DATA_TYPE = STEPPER_DATA.SUMMARY;

            const quoteOrderDetails = quoteOrderModuleStore.getData();
            const statusId: number = quoteOrderDetails?.info?.approveStatus ?? 0;

            if (
                summaryStep &&
                stepperData?.stepperList &&
                statusId === STATUS_MODE.PREPARING_QUOTE
            ) {
                const updatedStepperList: STEPPER_DATA_TYPE[] = stepperData?.stepperList.filter(
                    (step: STEPPER_DATA_TYPE) => step.stepperId !== summaryStep.stepperId
                );
                if (isEditQuoteFlow && updatedStepperList) {
                    const updatedStepperData: STEPPER_STATE = {
                        ...stepperData,
                        stepperList: updatedStepperList
                    };

                    stepperStore?.updateStepper(updatedStepperData);
                }
            }
        } catch (error) {
            console.error(
                'Error while removing the last step in existing stepper (removeLastStepInStepper()): ',
                error
            );
        }
    };

    // helper
    const handlerSelectedCategoryWrapper = (
        service: ServiceAndCategoryType,
        category: PatentCategories,
        isEditFlowManualTrigger: boolean = false
    ) => {
        handlerSelectedCategory(service, category, isEditFlowManualTrigger).catch(() =>
            console.error('Error in handlerSelectedCategoryWrapper()')
        );
    };
    const handlerSelectedCategory = async (
        service: ServiceAndCategoryType,
        category: PatentCategories,
        isEditFlowManualTrigger: boolean = false
    ) => {
        try {
            const isThisEditFlow = isEditFlow();
            const updatedQuoteOrderData = quoteOrderModuleStore.getData();

            // get stepper data for selected category via api
            const stepperDataForSelectedCategory =
                progressStepperServices?.getStepperDataForSelectedCategory(
                    quoteOrderData.info,
                    userDetails.userInfo,
                    service.serviceTypeId,
                    category.patentCategoryId
                );

            if (!stepperDataForSelectedCategory || stepperDataForSelectedCategory.length === 0)
                return;

            /** reset the store, whe user select/change the category. 
             because we have different functionality foe each category. */
            stepperStore.resetStepperStore();
            !isEditFlowManualTrigger && quoteOrderModuleStore.resetQuoteOrderStore({ mode });

            // after choose service category, wait for few seconds to user see the selection then redirect to next page
            !isEditFlowManualTrigger && (await new Promise((r) => setTimeout(r, 800)));

            const customizedStepperList = customizedStepper(
                service,
                stepperDataForSelectedCategory
            );
            // update store - stepper
            const updatedStepperData: STEPPER_STATE = {
                /** set first value as 'currStep'.
                 *  so that it will redirect to next page when click continue after select category. */
                stepperInfo: { currStep: stepperDataForSelectedCategory[0], completedStepsIds: [] },
                stepperList: customizedStepperList
            };

            stepperStore?.updateStepper(updatedStepperData);
            handleStepperUpdate();
            // update store - quoteOrder
            const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                ...updatedQuoteOrderData?.info,
                selectedService: service,
                selectedCategory: category
            };
            const updatedQuoteOrderIsFormValid = {
                ...updatedQuoteOrderData.isFormValid,
                [PATHS.SERVICE_TYPE]: true
            };

            quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo);
            quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);

            // redirect to the first page automatically after few seconds of user once select the category
            const currStep = updatedStepperData?.stepperInfo?.currStep;
            const nextStepId = currStep?.stepperId ?? null;
            if (nextStepId) {
                const redirectTo = PATHS_FOR_STEPPER[nextStepId];
                navigate(
                    `/${PATHS.ORDER_QUOTE}/${isThisEditFlow ? PATHS.EDIT : PATHS.CREATE}/${redirectTo}`
                );
            } else throw Error('nextStepId is not available.');
        } catch (error) {
            console.error('Error in handlerSelectedCategory(): ', error);
        }
    };
    const customizedStepper = (
        service: ServiceAndCategoryType,
        stepperData: STEPPER_DATA_TYPE[]
    ): STEPPER_DATA_TYPE[] => {
        try {
            const isPC = service?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;

            return stepperData.map((item: STEPPER_DATA_TYPE) => {
                if (item.stepperId === STEPPER_DATA.SUMMARY.stepperId) {
                    return {
                        ...item,
                        stepperDesc: `${t(`COMMON.${mode === MODE.CREATE_QUOTE ? 'QUOTE' : 'ORDER'}`)} ${t('COMMON.SUMMARY')}`
                    };
                } else if (item.stepperId === STEPPER_DATA.ORDER_QUOTE_DETAILS.stepperId) {
                    return {
                        ...item,
                        stepperName: `${t(`COMMON.${mode === MODE.CREATE_QUOTE ? 'QUOTE' : 'ORDER'}`)} ${t('COMMON.DETAILS')}`,
                        stepperDesc: `${t('COMMON.ENTER')} ${t(`COMMON.${mode === MODE.CREATE_QUOTE ? 'QUOTE' : 'ORDER'}`)} ${t('COMMON.DETAILS')}`
                    };
                } else if (isPC && item.stepperId === STEPPER_DATA.DOCUMENT_UPLOAD.stepperId) {
                    return {
                        ...item,
                        stepperDesc: `${t(`COMMON.MANDATORY`)}`
                    };
                }
                return item;
            });
        } catch (error) {
            console.error(`error in customizedStepper(): ${error}`);
            return stepperData; // if error occurs, return the original data
        }
    };
    const getSelectedServiceCategory = (
        serviceList: ServiceAndCategoryType[],
        selectedServiceCategory: { [key: string]: number },
        type: ServiceAndCategory
    ) => {
        try {
            if (type === 'service') {
                return (
                    serviceList.find(
                        (service) => service.serviceTypeId === selectedServiceCategory.serviceId
                    ) ?? null
                );
            } else if (type === 'category') {
                const patentCategories =
                    serviceList.find(
                        (service) => service.serviceTypeId === selectedServiceCategory.serviceId
                    )?.patentCategories ?? null;

                if (patentCategories) {
                    return (
                        patentCategories?.find(
                            (category) =>
                                category?.patentCategoryId === selectedServiceCategory.categoryId
                        ) ?? null
                    );
                } else return null;
            }
        } catch (error) {
            console.error('Error in getSelectedServiceCategory(): ', error);
            return null;
        }
    };
    const handleEditFlow = async () => {
        try {
            const _quoteOrderData = quoteOrderModuleStore.getData();
            const requestIdFromDetailsPage = _quoteOrderData.info.primaryId;
            if (!requestIdFromDetailsPage)
                throw new Error('PrimaryId is not available in the store.');

            const isSTDFlow = _quoteOrderData.info.isSTDFlow ?? false;

            // api - edit
            const editFlowData: EditFlowData = await serviceTypeService.getDataForEditFlow(
                requestIdFromDetailsPage,
                isSTDFlow
            );
            if (!editFlowData) throw new Error('editFlowData is not available.');

            /** helper functions for 'Edit'. */
            const boolToNumber = (value: any): number | null => {
                if (typeof value === 'boolean') {
                    return value ? YES_NO.YES : YES_NO.NO;
                }
                return null;
            };
            const commaStringToNumberArray = (value: any): number[] | null => {
                if (typeof value === 'string' && value !== '') {
                    return value.split(',').map(Number);
                } else return value ?? null;
            };
            const constructSTDTableData = (formData: any): LanguageSelectionDataItem[] | null => {
                if (!isSTDFlow || !formData || formData.length === 0) return null;

                /** construct the response data into table data format. */
                return formData.map((item: any) => {
                    return {
                        id: item?.id ?? null,
                        fileId: item?.fileId ?? null,
                        fileName: item?.fileName ?? null,
                        sourceLanguage: item?.sourceLanguageId
                            ? parseInt(item.sourceLanguageId as string, 10)
                            : null,
                        targetLanguage: item?.targetLanguagesId
                            ? commaStringToNumberArray(item.targetLanguagesId)
                            : null,
                        wordCount: item?.wordCount ?? null,
                        // deliveryDate: item?.deliveryDate ?? null,
                        documentType: item?.documentType ?? null
                    };
                });
            };

            // variables
            const info = editFlowData.info;
            const formData = editFlowData.formData;
            const selectedCompanyId = formData.companyDetailsPage.selectedCompanyId;

            /** api - required API calls for Edit flow */
            const serviceList = await serviceTypeService.getServiceType();
            if (!serviceList) throw new Error('serviceTypeList is not available.');

            // prepare an array for the optional API calls
            const otherRequiredAPIs = await Promise.allSettled([
                companyDetailsService.getCompanyData<Company[]>(),
                companyDetailsService.getContactUserData<ContactUser[]>(selectedCompanyId),
                orderQuoteModuleService.getSalesRepList<SalesRep[]>(), // for STD
                orderQuoteModuleService.getProjectManagersList<ProjectManager[]>() // for STD
            ]);

            // Handle the results of the optional APIs
            const companyList =
                otherRequiredAPIs[0].status === 'fulfilled' ? otherRequiredAPIs[0].value : null;
            const contactUserList =
                otherRequiredAPIs[1].status === 'fulfilled' ? otherRequiredAPIs[1].value : null;
            const salesRepList =
                otherRequiredAPIs[2].status === 'fulfilled' ? otherRequiredAPIs[2].value : null;
            const projectManagersList =
                otherRequiredAPIs[3].status === 'fulfilled' ? otherRequiredAPIs[3].value : null;

            // form data
            const companyDetailsPageData = { ...formData.companyDetailsPage };
            const patentDetailsPageData = { ...(formData.patentDetailsPage ?? {}) };
            const additionalInfoPageData = { ...(formData.additionalInfoPage ?? {}) };
            const orderDetailsPageData = { ...(formData.orderQuoteDetailsPage ?? {}) };
            const languageSelectionTableData =
                constructSTDTableData(formData.languageSelectionPage) || [];
            const languageSelectionPageData = {
                uploadedFilesResData: null,
                tableData: languageSelectionTableData, // constructed data for language selection table
                savedFilesReceivedInEditMode: formData.languageSelectionPage,
                /** if any changes happened against the files which we got in edit api, we should pass 'isEdited: true' in payload.
                 *  so that we store the ids in the store to compare later. */
                savedFilesIdsReceivedInEditMode: languageSelectionTableData.length
                    ? languageSelectionTableData
                          .map((file) => file.id)
                          .filter((id): id is number => id !== null)
                    : null
            };

            /** without company id we can not proceed. */
            if (!selectedCompanyId) throw new Error('SelectedCompanyId is not available.');
            /** without quote order details we can not proceed STD flow. */
            if (!orderDetailsPageData) throw new Error('SelectedCompanyId is not available.');

            /** company and contact-user info */
            const selectedCompanyData =
                companyList?.find(
                    (company: any) => company.id === companyDetailsPageData?.selectedCompanyId
                ) ??
                (companyDetailsPageData?.companyName &&
                companyDetailsPageData?.companyName.length > 0
                    ? companyDetailsPageData?.companyName[0]
                    : null);
            const selectedContactUser =
                contactUserList?.find(
                    (user: any) => user.id === companyDetailsPageData?.selectedContactId
                ) ??
                (companyDetailsPageData?.contactUserName &&
                companyDetailsPageData?.contactUserName.length > 0
                    ? companyDetailsPageData?.contactUserName[0]
                    : null);

            /** some needed modifications to adapt the edit api response in UI designs */
            // modify - patent details page
            patentDetailsPageData.companyName = selectedCompanyId;
            patentDetailsPageData.contactUser = selectedContactUser;
            patentDetailsPageData.publicationNumber =
                companyDetailsPageData?.publicationNumber ?? null;
            patentDetailsPageData.applicationClaimsPriority = boolToNumber(
                patentDetailsPageData.applicationClaimsPriority
            );
            patentDetailsPageData.validationDeadlineUP = patentDetailsPageData?.upDeadLine || null;
            if (patentDetailsPageData?.upDeadLine) delete patentDetailsPageData.upDeadLine;

            // modify - additional info page
            additionalInfoPageData.projectManager =
                formData.additionalInfoPage?.projectManagerNames || [];
            additionalInfoPageData.salesRep = commaStringToNumberArray(
                additionalInfoPageData?.salesRep || ''
            );
            additionalInfoPageData.deliverTo = additionalInfoPageData?.deliverTo
                ? additionalInfoPageData.deliverTo.split(',')
                : null;
            additionalInfoPageData.emailID =
                additionalInfoPageData?.emailID || selectedContactUser?.email;
            // modify - order details page (STD)
            orderDetailsPageData.companyName = selectedCompanyData;
            orderDetailsPageData.contactUser = selectedContactUser;
            orderDetailsPageData.contactEmail = selectedContactUser?.email;
            orderDetailsPageData.alsoDeliverTo = orderDetailsPageData?.alsoDeliverTo
                ? orderDetailsPageData.alsoDeliverTo.split(',')
                : null;
            orderDetailsPageData.requestInvoiceStatus = boolToNumber(
                orderDetailsPageData.requestInvoiceStatus
            );
            // add empty array to the container component
            orderDetailsPageData.salesRepContainer = {};
            orderDetailsPageData.pmContainer = {};
            const selectedSalesRepOfSTD = commaStringToNumberArray(
                orderDetailsPageData?.salesRep || ''
            );
            // orderDetailsPageData.salesRepContainer.salesRep =
            //     salesRepList?.filter((rep) => selectedSalesRepOfSTD?.includes(rep.id)) ?? null;
            orderDetailsPageData.salesRepContainer.salesRep =
                selectedSalesRepOfSTD && selectedSalesRepOfSTD?.length > 0
                    ? salesRepList
                          ?.filter((rep) => selectedSalesRepOfSTD.includes(rep.id))
                          .map((rep) => rep.id) || null
                    : null;

            const selectedPMsOfSTD = commaStringToNumberArray(
                orderDetailsPageData?.projectManager || ''
            );
            // orderDetailsPageData.pmContainer.projectManager =
            //     projectManagersList?.filter((pm) => selectedPMsOfSTD?.includes(pm.id)) ?? null;
            orderDetailsPageData.pmContainer.projectManager =
                selectedPMsOfSTD && selectedPMsOfSTD?.length > 0
                    ? projectManagersList
                          ?.filter((pm) => selectedPMsOfSTD?.includes(pm.id))
                          .map((pm) => pm.id)
                    : null;
            orderDetailsPageData.requestCurrencyId = +orderDetailsPageData.requestCurrency || null;

            // construct - service page
            const serviceCategoryId: { [key: string]: number } = {
                serviceId: info.selectedCategoryId,
                categoryId: info.selectedServiceId
            };
            const existingSelectedService = getSelectedServiceCategory(
                serviceList,
                serviceCategoryId,
                'service'
            ) as ServiceAndCategoryType;
            const existingSelectedCategory = getSelectedServiceCategory(
                serviceList,
                serviceCategoryId,
                'category'
            ) as PatentCategories;
            if (!existingSelectedService || !existingSelectedCategory)
                throw new Error('SelectedService or SelectedCategory is not available to proceed.');

            const servicePageData: ServiceTypeData = {
                serviceType: serviceList,
                selectedServiceDetails: {
                    serviceTypeId: existingSelectedService?.serviceTypeId,
                    patentCategoryDisplay: existingSelectedCategory?.patentCategoryDisplay
                }
            };

            updateLocalStateWithStoreData(servicePageData);

            // construct - company details page
            const companyDetailsPage = {
                ...quoteOrderData.formData.companyDetailsPage,
                companyList,
                contactUserList,
                selectedCompany: selectedCompanyData,
                selectedContact: selectedContactUser,
                publicationNumber: companyDetailsPageData?.publicationNumber ?? null,
                patentDetails: patentDetailsPageData
            };

            // update store current and other forms
            const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                ...quoteOrderData.info,
                selectedService: existingSelectedService,
                selectedCategory: existingSelectedCategory,
                /** we have a 'orderId/id', when we edit the Quote from the "Order-Details / Listing" page.
                 *  this Id only we use to fetch the Edit-Api.
                 *  And after this Edit-Api success, please use the 'referenceNo' for the further process in Edit-flow.
                 *  moreover, use this 'orderId/id' for preview files. */
                primaryId: info.referenceNo,
                previewReferenceId: requestIdFromDetailsPage,
                documentId: info.documentId,
                requestCurrencyId: info.requestCurrencyId ?? null,
                isEditFlow: true,
                isUP: info.isUP ?? null,
                approveStatus: info.approveStatus ?? null,
                statusId: info.statusId ?? null,
                quoteStatus: info.approveStatus ?? null,
                requestNumber: info.requestNumber,
                stdPreviewType: info.stdPreviewType || null, // used '||' to restrict the empty string
                isBothDecideLater: info.isBothDecideLater ?? null
            };
            const updatedQuoteOrderFormData: QuoteOrderModuleStoreFormData = {
                ...quoteOrderData?.formData,
                serviceTypePage: servicePageData,
                companyDetailsPage,
                additionalInfoPage: additionalInfoPageData,
                patentDetailsPage: patentDetailsPageData,
                selectCountryPageEdit: formData.selectCountryPage ?? null,
                orderQuoteDetailsPage: orderDetailsPageData ?? null,
                languageSelectionPage: languageSelectionPageData
            };

            const updatedQuoteOrderFlags = {
                ...quoteOrderData?.flags,
                isBothDecideLaterDisableApprove: info.isBothDecideLater ?? null
            };

            quoteOrderModuleStore.updatePage('info', updatedQuoteOrderInfo);
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
            quoteOrderModuleStore.updatePage('editFlowResponseData', editFlowData);
            quoteOrderModuleStore.updatePage('flags', updatedQuoteOrderFlags);

            /** for edit flow we should trigger the process manually. since we know the selected item.
             * last param (optional) for skip the store reset activity for the first time trigger on edit mode.
             * or else the edit-flow data will loss which we have already stored in the store. */
            handlerSelectedCategory(existingSelectedService, existingSelectedCategory, true);

            /** pass the latest store data to this func to get backup data on store to compare later. */
            await new Promise((r) => setTimeout(r, 200));
            const updatedQuoteOrderData = quoteOrderModuleStore.getData();
            orderQuoteModuleService.backupDataToStore(updatedQuoteOrderData);
        } catch (error) {
            console.error('Error in handleEditFlow(): ', error);
            return null;
        }
    };
    const updateLocalStateWithStoreData = (data: ServiceTypeData) => {
        data?.serviceType && setServiceType(data.serviceType);
        data.selectedServiceDetails && setSelectedServiceDetails(data.selectedServiceDetails);
    };
    const isEditFlow = (): boolean => {
        const pathNameList = pathname.split('/');
        const isEdit = pathNameList.includes(PATHS.EDIT);
        return isEdit;
    };
    const getServiceTopLayerColor = (serviceId: number): string => {
        switch (serviceId) {
            case SERVICE_TYPE_ID.patent_cooperation_treaty:
                return 'bg-primary/30 ';
            case SERVICE_TYPE_ID.european_patent:
                return 'bg-secondary/25';
            case SERVICE_TYPE_ID.paris_convention_treaty:
                return 'bg-warning/80';
            case SERVICE_TYPE_ID.other_translations:
                return 'bg-black/15';
            default:
                return 'bg-primary-100 ';
        }
    };
    const getServiceLogo = (serviceId: number): string => {
        switch (serviceId) {
            case SERVICE_TYPE_ID.patent_cooperation_treaty:
                return logoPCT;
            case SERVICE_TYPE_ID.european_patent:
                return logoEP;
            case SERVICE_TYPE_ID.paris_convention_treaty:
                return logoPC;
            case SERVICE_TYPE_ID.other_translations:
                return logoSTD;
            default:
                return logoPCT;
        }
    };

    // component init
    useEffect(() => {
        const isThisEditFlow = isEditFlow();
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();

        /** in edit flow, we don't show 'service-type' page.
         *  also we don't show back button to come back to 'service-type' page.
         *  but user can reach this 'service-type' page by clicking browser back button.
         *  to restrict that navigation, we just redirect to listing page is enough. */
        if (isThisEditFlow && updatedQuoteOrderData?.info?.selectedService) {
            navigate(`/${PATHS.ORDER_QUOTE}`);
            console.error('Error: Service-Type page not allowed in Edit flow.');
            return;
        }

        const fetchFormData = updatedQuoteOrderData?.formData.serviceTypePage;

        if (isThisEditFlow) {
            handleEditFlow();
        } else if (fetchFormData?.serviceType && fetchFormData?.selectedServiceDetails) {
            updateLocalStateWithStoreData(fetchFormData);
        } else {
            getServiceType();
        }

        // update store - info
        const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
            ...updatedQuoteOrderData?.info,
            isEditFlow: isThisEditFlow
        };
        quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo);

        /** in edit mode we set data to local state from store.
         * that time we not need to update the store when states are update.
         * so we use this flag to skip the update activity and also it helps to avoid re-render. */
        setIsInitialRendering(false);
    }, []);

    // update form-data to store
    useEffect(() => {
        if (isInitialRendering) return;

        // get latest formData (all form to retain the same)
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();
        const updatedFormData = updatedQuoteOrderData?.formData;

        // company details page state list to retain the page while navigation
        const updatedServiceTypePage = {
            serviceType,
            selectedServiceDetails
        };

        // update the store
        if (updatedServiceTypePage?.serviceType && updatedServiceTypePage?.selectedServiceDetails) {
            // hold the other form data while update the store
            const updatedQuoteOrderFormData = {
                ...updatedFormData,
                serviceTypePage: updatedServiceTypePage
            };

            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    }, [serviceType, selectedServiceDetails]);

    return (
        <>
            {/* we hide this service page content in edit mode instead of router jump. */}
            {!isEditFlow() && serviceType && (
                <div
                    data-testid={'service-page'}
                    className="flex flex-col items-center px-10 h-full cursor-default">
                    <div
                        data-testid={'service-page-header'}
                        className="flex items-center font-medium text-[1.75rem] leading-9 h-1/4">
                        {isQuoteCreation ? t('SERVICE.QUOTE_TITLE') : t('SERVICE.ORDER_TITLE')}
                    </div>
                    <div className="h-3/4">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                            {serviceType?.map((service, index) => (
                                <ServiceTemplate
                                    key={service?.id ?? index + 1}
                                    service={service}
                                    serviceTopLayerColor={getServiceTopLayerColor(
                                        service.serviceTypeId
                                    )}
                                    serviceLogo={getServiceLogo(service.serviceTypeId)}
                                    actions={{
                                        handlerSelectedCategory: handlerSelectedCategoryWrapper,
                                        setSelectedServiceDetails
                                    }}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};
export default ServiceType;

interface ServiceTemplateModel {
    service: ServiceAndCategoryType;
    serviceTopLayerColor: string;
    serviceLogo: string;
    actions: {
        handlerSelectedCategory: (
            service: ServiceAndCategoryType,
            category: PatentCategories
        ) => void;
        setSelectedServiceDetails: ({
            serviceTypeId,
            patentCategoryDisplay
        }: {
            serviceTypeId: number;
            patentCategoryDisplay: string;
        }) => void;
    };
}
const ServiceTemplate: FC<ServiceTemplateModel> = ({
    service,
    serviceTopLayerColor,
    serviceLogo,
    actions: { handlerSelectedCategory, setSelectedServiceDetails }
}) => {
    const categories = service?.patentCategories;
    const isValidCategories = categories && categories.length > 0;

    return (
        <div
            data-testid={`service-box-${service.name}`}
            className="flex flex-col items-center border border-neutral-100 rounded-xl hover:shadow-lg">
            <div className={`${serviceTopLayerColor} w-4/5 h-2 rounded-b-2xl`}></div>
            <div className="flex flex-col items-start w-full">
                <div className="mx-8 my-6">
                    <img
                        data-testid={`service-logo-${service.name}`}
                        className=""
                        src={serviceLogo}
                        alt={''}
                    />
                    <div
                        data-testid={`service-text-${service.name}`}
                        className="text-xl font-medium pt-4 pb-2">
                        {service.displayText ?? 'N?A'}
                    </div>
                    {isValidCategories &&
                        categories.map((category, index) => (
                            <div
                                key={category?.patentCategoryId ?? index + 1}
                                className="flex gap-2 py-2 items-center">
                                <img
                                    data-testid={`category-logo-${category?.patentCategoryName}`}
                                    className="h-[0.625rem]"
                                    src={tickGreen}
                                    alt={''}
                                />
                                <div
                                    data-testid={`category-text-${category?.patentCategoryName}`}
                                    className={`font-medium cursor-pointer hover:text-[#0077D2]`}
                                    onClick={() => {
                                        handlerSelectedCategory(
                                            service,
                                            category as PatentCategories
                                        );
                                        setSelectedServiceDetails({
                                            serviceTypeId: service?.serviceTypeId,
                                            patentCategoryDisplay:
                                                category?.patentCategoryDisplay || ''
                                        });
                                    }}>
                                    {category?.patentCategoryDisplay ?? 'N/A'}
                                </div>
                            </div>
                        ))}
                </div>
            </div>
        </div>
    );
};
