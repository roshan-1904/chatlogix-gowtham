import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
// import { I18nextProvider } from 'react-i18next';
import ServiceType from './serviceType';
import serviceTypeService from '../services/serviceType.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('../services/serviceType.service');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('core/store/authStore/authStore');

describe('ServiceType Component', () => {
    const mockServiceTypes = [
        {
            serviceTypeId: 1,
            displayText: 'SERVICE_TYPE_1',
            imageIcon: 'icon1',
            patentCategories: [
                { patentCategoryId: 1, patentCategoryDisplay: 'CATEGORY_1' },
                { patentCategoryId: 2, patentCategoryDisplay: 'CATEGORY_2' }
            ]
        },
        {
            serviceTypeId: 2,
            displayText: 'SERVICE_TYPE_2',
            imageIcon: 'icon2',
            patentCategories: []
        }
    ];

    beforeEach(() => {
        jest.clearAllMocks();
        (serviceTypeService.getServiceType as jest.Mock).mockResolvedValue(mockServiceTypes);
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: { isEditFlow: false },
            formData: {}
        });
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: { roleId: 1 }
        });
    });

    test('renders ServiceType component', async () => {
        render(
            <Router>
                <ServiceType />
            </Router>
        );

        expect(screen.getByTestId('select-service')).toBeInTheDocument();
        await waitFor(() => expect(serviceTypeService.getServiceType).toHaveBeenCalled());
    });

    test('displays service types and categories', async () => {
        render(
            <Router>
                <ServiceType />
            </Router>
        );

        await waitFor(() => {
            expect(screen.getByText('SERVICE_TYPE_1')).toBeInTheDocument();
            expect(screen.getByText('SERVICE_TYPE_2')).toBeInTheDocument();
        });

        fireEvent.click(screen.getByText('SERVICE_TYPE_1'));
        await waitFor(() => {
            expect(screen.getByText('CATEGORY_1')).toBeInTheDocument();
            expect(screen.getByText('CATEGORY_2')).toBeInTheDocument();
        });
    });

    test('handles category selection', () => {
        render(
            <Router>
                <ServiceType />
            </Router>
        );

        waitFor(() => {
            expect(screen.getByText('SERVICE_TYPE_1')).toBeInTheDocument();
        });

        waitFor(() => {
            fireEvent.click(screen.getByText('SERVICE_TYPE_1'));
            expect(screen.getByText('CATEGORY_1')).toBeInTheDocument();
        });

        waitFor(() => {
            fireEvent.click(screen.getByText('CATEGORY_1'));
            expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith(
                'info',
                expect.objectContaining({
                    isEditFlow: false
                })
            );
            expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.any(Object)
            );
        });
    });
});
