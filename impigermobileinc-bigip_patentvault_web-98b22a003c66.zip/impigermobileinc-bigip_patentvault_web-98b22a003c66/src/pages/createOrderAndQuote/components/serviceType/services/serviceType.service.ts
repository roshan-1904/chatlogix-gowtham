import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { EditFlowData, ServiceAndCategoryType } from '../types/serviceType.type';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MODE } from 'constants/app.constant';
const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

const getServiceType = async (): Promise<ServiceAndCategoryType[]> => {
    const apiUrl = `${END_POINT.SERVICE_TYPE.GET_SERVICE_TYPE}`;
    try {
        const response = await httpService.get<ServiceAndCategoryType[]>(
            apiUrl,
            {},
            false,
            baseURL
        );

        let updatedResponse: ServiceAndCategoryType[] | null = null;
        const mode = quoteOrderModuleStore.getData()?.info?.mode;
        const isOrderMode: boolean = mode === MODE.CREATE_ORDER;

        if (response?.length && Array.isArray(response)) {
            /** here we can remove the 'Service' based on the conditions. */
            const serviceToRemove: number[] = [
                // SERVICE_TYPE_ID.sample_service_id
            ];
            updatedResponse = response.filter((service) => {
                if (!service) return true;

                // const isSTDFlow = service.serviceTypeId === SERVICE_TYPE_ID.other_translations;
                const isRemove = serviceToRemove.includes(service.serviceTypeId);

                // if (isSTDFlow) {
                //     /** 'STD' will be hidden only for ContactUsers. */
                //     return !(isRemove && isThisContactUser);
                // }

                return !isRemove; // if return false, then service will be removed while filter.
            });

            if (isOrderMode) {
                /** for 'Order' - we should remove "Recordal \ Renewal \ Annuities" manually (as temporarily). */
                const servicePCT = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty];
                const serviceEP = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent];
                const categoriesToRemove: number[] = [
                    servicePCT.recordal,
                    servicePCT.annuities,
                    serviceEP.recordal,
                    serviceEP.Renewals
                ];

                updatedResponse = updatedResponse.map((service) => ({
                    ...service,
                    patentCategories: service.patentCategories
                        ? service.patentCategories.filter(
                              (patentCategory) =>
                                  patentCategory &&
                                  !categoriesToRemove.includes(patentCategory.patentCategoryId)
                          )
                        : []
                }));
            }
        }

        return updatedResponse ?? response;
    } catch (error) {
        console.error('Error fetching service types:', error);
        throw error;
    }
};

const getDataForEditFlow = async (
    orderId: number,
    isSTD: boolean = false
): Promise<EditFlowData> => {
    const endpoint = isSTD
        ? END_POINT.ORDERS_AND_QUOTES_END_POINT.EDIT_STEPPER_STANDARD
        : END_POINT.ORDERS_AND_QUOTES_END_POINT.EDIT_STEPPER_ORDER_QUOTE;

    const apiUrl = `${endpoint}/${orderId}`;

    try {
        const response = await httpService.get<EditFlowData>(apiUrl, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error fetching service types:', error);
        throw error;
    }
};

const getDataForSTDEditFlow = async (orderId: number): Promise<EditFlowData> => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.EDIT_STEPPER_STANDARD}/${orderId}`;
    try {
        const response = await httpService.get<EditFlowData>(apiUrl, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error fetching service types:', error);
        throw error;
    }
};

const serviceTypeService = { getServiceType, getDataForEditFlow, getDataForSTDEditFlow };
export default serviceTypeService;
