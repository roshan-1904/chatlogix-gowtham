export const EditDataflow = {
    info: {
        mode: null,
        selectedServiceId: 123,
        selectedCategoryId: 456,
        referenceNo: null,
        requestCurrencyId: null,
        requestNumber: null,
        documentId: null,
        approveStatus: 1,
        serviceUniqueName: 'ServiceName',
        isEditFlow: true,
        isUP: false,
        statusId: null
    },
    formData: {
        companyDetailsPage: {
            companyName: 'Example Company',
            companyAddress: '123 Main St, City, Country'
        },
        additionalInfoPage: {
            someField: 'Additional Info'
        },
        patentDetailsPage: {
            patentNumber: '123456'
        },
        selectCountryPage: {
            selectedCountries: ['Country1', 'Country2']
        },
        orderQuoteDetailsPage: {
            orderNumber: 'ORD-12345',
            quoteAmount: 1000.0
        }
    }
};

export const serviceTypeData = {
    id: 1,
    name: 'Service Name',
    displayText: 'Display Text',
    displayOrder: 1,
    serviceTypeId: 101,
    patentType: 202,
    requestType: 303,
    imageIcon: 'icon.png',
    isRequestEntity: null,
    createdBy: null,
    createdAt: '2024-08-20T12:00:00Z',
    updatedBy: null,
    updatedAt: null,
    isActive: true,
    patentCategories: [
        {
            id: 11,
            categoryName: 'Patent Category 1'
        },
        {
            id: 12,
            categoryName: 'Patent Category 2'
        }
    ]
};
