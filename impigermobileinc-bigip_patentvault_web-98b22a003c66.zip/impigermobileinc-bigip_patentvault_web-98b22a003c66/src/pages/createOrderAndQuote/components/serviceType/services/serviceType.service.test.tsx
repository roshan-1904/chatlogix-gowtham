import serviceTypeService from './serviceType.service';
import HttpService from 'core/interceptor/api.handler';
import { EditDataflow, serviceTypeData } from './serviceType.service.test.mock';

// Mock dependencies
jest.mock('core/interceptor/api.handler');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('constants/endPoint');

describe('serviceTypeService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('getDataForEditFlow', () => {
        it('should fetch getDataForEditFlow data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(EditDataflow);
            const orderId = 1;
            const result = await serviceTypeService.getDataForEditFlow(orderId);
            expect(result).toEqual(EditDataflow);
        });

        it('should handle error while fetching getDataForEditFlow data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            const orderId = 3;
            await expect(serviceTypeService.getDataForEditFlow(orderId)).rejects.toThrow(mockError);
        });
    });

    describe('getServiceType', () => {
        it('should fetch getServiceType data successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(serviceTypeData);
            const result = await serviceTypeService.getServiceType();
            expect(result).toEqual(serviceTypeData);
        });

        it('should handle error while fetching getDataForEditFlow data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(serviceTypeService.getServiceType()).rejects.toThrow(mockError);
        });
    });
});
