import { SelectCountryDatasetForEdit } from 'pages/orders/selectCountry/types/country.type';

export interface PatentCategories {
    parentId: number;
    patentCategoryName: string;
    patentCategoryId: number;
    patentCategoryDisplay: string;
    patentCategoryDisplayOrder: number;
    patentCategoryIsRequestEntity: boolean;
    serviceUniqueName?: string;
}
export interface ServiceAndCategoryType {
    id: number;
    name: string;
    displayText: string;
    displayOrder: number;
    serviceTypeId: number;
    patentType: number;
    requestType: number;
    imageIcon: string;
    isRequestEntity: null;
    createdBy: null;
    createdAt: string | null;
    updatedBy: null;
    updatedAt: null;
    isActive: boolean | null;
    patentCategories?: (PatentCategories | null)[] | null;
}

export interface SelectedServiceDetails {
    serviceTypeId: number;
    patentCategoryDisplay: string | null;
}

export interface EditFlowData {
    info: EditFlowInfo;
    formData: EditFormData;
}

export interface EditFlowInfo {
    mode: number | null;
    selectedServiceId: number;
    selectedCategoryId: number;
    referenceNo: number | null;
    documentId: number | null;
    requestNumber?: string | null;
    requestCurrencyId?: number | null;
    serviceUniqueName?: string;
    isEditFlow?: boolean | null;
    isUP?: boolean | null;
    approveStatus?: number;
    statusId?: number | null;
    primaryId?: number | null;
    stdPreviewType?: string | null;
    isBothDecideLater?: boolean | null;
}
export interface EditFormData {
    companyDetailsPage: CompanyDetailsDataForEdit;
    additionalInfoPage?: any; // formioData
    patentDetailsPage?: any; // formioData
    selectCountryPage?: SelectCountryDatasetForEdit | null;
    orderQuoteDetailsPage?: any;
    languageSelectionPage?: any;
}
export interface CompanyDetailsDataForEdit {
    selectedCompanyId: number;
    selectedContactId: number;
    publicationNumber?: string;
    companyName?: any;
    contactUserName?: any;
}
export interface AdditionalInfoDataForEdit {
    emailID: string | null;
    deliverTo: string;
    cc: string | null;
    po: string | null;
    quoteTargetDate: string | null;
    quoteRequired: boolean | null;
    instructionByContactUser: string | null;
    instructionByProjectManager: string | null;
    projectManager: string | null;
}

export interface SalesRep {
    id: number;
    name: string;
}
export interface ProjectManager {
    id: number;
    roleId: number;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    fullName?: string;
}
