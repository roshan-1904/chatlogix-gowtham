import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { DropdownChangeEvent } from 'primereact/dropdown';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

import InstructionPopup from './components/instructionPopup';
import SummaryConfig from './components/summaryConfig';
import Disclaimer from './components/summaryDisclaimer';
import SummaryPageHeader from './components/summaryPageHeader';
import summaryService from './services/summary.service';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';

import {
    ADDITIONAL_FIELDS_LANG,
    CountryList,
    CurrencyResponse,
    DisclaimerList,
    Language,
    LanguageBasedFee,
    SummaryMetaData,
    SummaryResponse,
    Totals
} from './types/summary.type';
import { LANGUAGE_ID, YES_NO } from 'constants/app.constant';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { isStaffUser, isVendorUser, toggleLoadingIndicator } from 'core/utils/utils';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import {
    QuoteOrderModuleStoreFormData,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import orderQuoteDetailsService from '../standard/orderQuoteDetails/services/orderQuoteDetails.service';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { LanguageBasedFeeList } from 'pages/orders/selectCountry/types/country.type';

export const getSummaryInitData = (): SummaryMetaData => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);

    const initialSummary: SummaryMetaData = {
        instruction: '',
        customDisclaimer: null,
        selectedCurrency: null,
        selectedLanguage: null,
        totals: null,
        responseData: {
            summaryResponse: null,
            currencyResponse: null,
            languageResponse: null,
            languageList: null
        },
        info: {
            selectedServiceId: 0,
            selectedCategoryId: 0,
            isUPFlow: false,
            isEnglishFeeRequired: false
        },
        flags: {
            isCountryFeeEditMode: false,
            isMapViewOn: false,
            isHighRole: isThisStaffUser || isThisVendorUser,
            scrollHeightOfCountryConfigTableForEP: 310,
            IsUp: null,
            isBothDecideLater: null
        }
    };

    return initialSummary;
};

const Summary = () => {
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const { t } = useTranslation();
    const [summary, setSummary] = useState<SummaryMetaData>(getSummaryInitData());
    const [instruction, setInstruction] = useState<string>('');
    const [isInstructionError, setIsInstructionError] = useState(false);
    const [isFormInitialLoad, setIsFormInitialLoad] = useState<boolean>(true);
    const [checked, setChecked] = useState(false);
    const selectedServiceId = quoteOrderData.info.selectedService?.serviceTypeId as number;
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId as number;
    const isEPFlow = selectedServiceId === SERVICE_TYPE_ID.european_patent;
    const isEpTranslationAndValidation =
        quoteOrderData.info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];
    const isEpTranslationOnly =
        quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'];
    const isEditFlow = quoteOrderData.info.isEditFlow === true;
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;
    const isShowEstSeqListingInfoLabel = Boolean(
        quoteOrderData?.formData?.patentDetailsPage?.estimatedSequenceListing === YES_NO.YES
    );

    const isUPFeeAvailable = (summaryData: SummaryResponse | null): boolean => {
        if (summaryData && summaryData?.serviceBasedFee?.upFee) {
            return summaryData?.serviceBasedFee?.upFee?.length > 0;
        } else {
            return false;
        }
    };

    const formatEpTargetLanguage = (epTargetLanguages: LanguageBasedFeeList[]) => {
        if (!epTargetLanguages) return [];
        return epTargetLanguages.map((lang) => ({
            ...lang,
            id: lang.targetLanguageId,
            name: lang.targetLanguageName || ''
        }));
    };

    // api
    const fetchData = async (params: {
        updatedSummary: SummaryMetaData;
        updatedSummaryResponse?: SummaryResponse;
    }) => {
        try {
            toggleLoadingIndicator(true);

            const updatedQuoteOrderData = quoteOrderModuleStore.getData();
            const isEPTranslationValidation =
                updatedQuoteOrderData?.info?.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.['translation_&_validation'];

            const [summaryResponse, currencyResponse, languageListResponse] = await Promise.all([
                params?.updatedSummaryResponse ||
                    summaryService.getSummaryPageData(
                        isEPTranslationValidation
                            ? updatedQuoteOrderData.info.requestCurrencyId
                            : undefined
                    ),
                summaryService.getCurrencyList<CurrencyResponse[]>(false),
                OrdersAndQuotesService.getLanguageList<Language[]>()
            ]);

            if (!summaryResponse || !currencyResponse) {
                console.error('Summary data or currency list is null or empty');
                setTimeout(() => {
                    toggleLoadingIndicator(false);
                }, 1000);
                return null;
            }

            let defaultSelectedLanguage: Language | null = null;
            let languageListIDs: number[] | null = null;
            let filteredLanguageList: Language[] | null = null;
            let IsUp: boolean | null = null; // set isUP where we got in the edit-mode to select the default accordion
            let isBothDecideLater: boolean | null = null;

            const isUPFlow = selectedServiceId === SERVICE_TYPE_ID.european_patent;
            const sourceLanguage: string =
                updatedQuoteOrderData.formData.patentDetailsPage?.sourceLanguage || '';

            // modify currency
            const defaultSelectedCurrency =
                currencyResponse.find(
                    (currency) =>
                        currency.currencyId === updatedQuoteOrderData.info.requestCurrencyId
                ) || currencyResponse[0];

            // upFlow only required this functionalities
            if (isUPFlow && sourceLanguage) {
                // Filter the language list based on the source language
                filteredLanguageList = languageListResponse.filter((item: Language) =>
                    ADDITIONAL_FIELDS_LANG[sourceLanguage].includes(item?.abbreviation)
                );

                defaultSelectedLanguage =
                    languageListResponse?.find(
                        (item) =>
                            item.id ===
                            getDefaultSelectedLanguageId(
                                sourceLanguage,
                                summaryResponse.serviceBasedFee.upFee
                            )
                    ) ?? null;

                // modify summary
                languageListIDs = filteredLanguageList?.map((language) => language.id);

                // modify UPLits
                summaryResponse.serviceBasedFee.upFee.forEach((item: CountryList) => {
                    if (isEpTranslationAndValidation || isEpTranslationOnly) {
                        if (item.languageId) {
                            item.isSelected =
                                quoteOrderModuleStore?.getData()?.formData?.selectCountryPageForEP
                                    ?.epTranslationAndValidationData?.upTargetLanguage
                                    ?.targetLanguageId === item.languageId || item.defaultLanguage;
                        } else {
                            item.isSelected = true;
                        }
                    } else {
                        if (item.languageId && languageListIDs?.includes(item.languageId)) {
                            item.isSelected = defaultSelectedLanguage?.id === item.languageId;
                        } else {
                            item.isSelected = true;
                        }
                    }
                });

                IsUp = isEditFlow
                    ? (updatedQuoteOrderData.info.isUP ?? null)
                    : summaryResponse?.serviceBasedFee?.upFee?.length > 0;
                isBothDecideLater = isEditFlow
                    ? (updatedQuoteOrderData.info.isBothDecideLater ?? null)
                    : (quoteOrderData?.formData?.summaryPage?.flags?.isBothDecideLater ?? null);
            }

            // construct custom country list
            summaryResponse.customCountryList =
                (summaryResponse.customCountryList?.length > 0 &&
                    summaryResponse.customCountryList?.map((country: any) => ({
                        ...country,
                        agencyFee: country.agencyFee ?? null,
                        officialFee: country.officialFee ?? null,
                        translationFee: country.translationFee ?? null,
                        total:
                            country.total ??
                            +(country.agencyFee ?? 0) +
                                +(country.officialFee ?? 0) +
                                +(country.translationFee ?? 0)
                    }))) ||
                [];

            if (isUPFlow && isUPFeeAvailable(summaryResponse)) {
                const isUpSelected: boolean =
                    quoteOrderData?.formData?.summaryPage?.flags.IsUp === true;
                const updatedDisclaimer = await orderQuoteDetailsService.getDisclaimers(
                    quoteOrderData.info.primaryId as number,
                    true,
                    isUpSelected
                );
                if (updatedDisclaimer) {
                    summaryResponse.disclaimerList = updatedDisclaimer as DisclaimerList[];
                }
            }

            // custom disclaimer
            const existingCustomDisclaimer = params.updatedSummary?.customDisclaimer ?? null;

            let customDisclaimer = null;
            if (!existingCustomDisclaimer) {
                const customDisclaimerIndex =
                    summaryResponse?.disclaimerList?.findIndex(
                        (list: DisclaimerList) => list.isCustomDisclaimer === true
                    ) ?? null;
                if (customDisclaimerIndex && customDisclaimerIndex !== -1) {
                    customDisclaimer = summaryResponse.disclaimerList.splice(
                        customDisclaimerIndex,
                        1
                    )[0];
                }
            }
            // custom instruction
            const updatedInstruction = customDisclaimer?.customInstruction ?? '';

            const updatedData: SummaryMetaData = {
                ...params.updatedSummary,
                customDisclaimer: existingCustomDisclaimer ?? customDisclaimer,
                instruction: updatedInstruction,
                selectedCurrency: defaultSelectedCurrency,
                selectedLanguage: isEpTranslationAndValidation
                    ? summaryResponse?.epTargetLanguages?.find((lang) => lang.isDefault)
                          ?.targetLanguageId
                    : defaultSelectedLanguage?.id,
                info: {
                    selectedServiceId,
                    selectedCategoryId,
                    languageListIDs,
                    isUPFlow,
                    isEnglishFeeRequired: patentDetailsPage.noEnglishTranslationRequired ?? false
                },
                responseData: {
                    ...params.updatedSummary.responseData,
                    summaryResponse,
                    currencyResponse,
                    languageResponse: languageListResponse,
                    languageList:
                        isEpTranslationAndValidation || isEpTranslationOnly
                            ? formatEpTargetLanguage(summaryResponse?.epTargetLanguages ?? [])
                            : filteredLanguageList
                },
                flags: {
                    ...params.updatedSummary.flags,
                    IsUp: IsUp ?? null,
                    isBothDecideLater: isBothDecideLater ?? null
                },
                totals: sumTotal(summaryResponse)
            };

            // Update data to store
            updateFormData(updatedData); // store - formData

            // Update the local state
            setSummary(updatedData);

            await new Promise((r) => setTimeout(r, 200));
            const updatedOrderData = quoteOrderModuleStore.getData();
            orderQuoteModuleService.backupDataToStore(updatedOrderData);
            setTimeout(() => {
                toggleLoadingIndicator(false);
            }, 1000);
            // flag
            setIsFormInitialLoad(false);
        } catch (error) {
            toggleLoadingIndicator(false);
            console.error('Error fetching data in summary:', error);
        }
    };
    const updateCurrency = async (selectedCurrency: CurrencyResponse) => {
        try {
            const updatedQuoteOrderData = quoteOrderModuleStore.getData();

            /** ignore further actions if summary tables inline edit is in-progress. */
            if (quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
                showToastMessage({
                    message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                    type: ToastType.WARNING
                });
                return null;
            }

            const summaryResponse: SummaryResponse = await summaryService.getSummaryPageData(
                selectedCurrency.currencyId
            );
            const languageListResponse: Language[] =
                await OrdersAndQuotesService.getLanguageList<Language[]>();

            let defaultSelectedLanguage: Language | null = null;
            let languageListIDs: number[] | null = null;
            let filteredLanguageList: Language[] | null = null;

            // upFlow only required this functionalities
            const sourceLanguage: string =
                updatedQuoteOrderData.formData.patentDetailsPage?.sourceLanguage || '';
            if (isEPFlow && sourceLanguage) {
                // Filter the language list based on the source language
                filteredLanguageList = languageListResponse.filter((item: Language) =>
                    ADDITIONAL_FIELDS_LANG[sourceLanguage].includes(item?.abbreviation)
                );
                const patentLanguage =
                    sourceLanguage === 'EN' ? LANGUAGE_ID.SPANISH : LANGUAGE_ID.ENGLISH;
                const defaultSelectedLanguageId = summary.selectedLanguage
                    ? summary.selectedLanguage
                    : patentLanguage;
                defaultSelectedLanguage =
                    languageListResponse?.find((item) => item.id === defaultSelectedLanguageId) ??
                    null;

                // modify summary
                languageListIDs = filteredLanguageList?.map((language) => language.id);

                // modify UPLits
                summaryResponse.serviceBasedFee.upFee.forEach((item: CountryList) => {
                    if (isEpTranslationAndValidation || isEpTranslationOnly) {
                        if (item.languageId) {
                            item.isSelected = item.languageId === summary.selectedLanguage;
                        } else {
                            item.isSelected = true;
                        }
                    } else {
                        if (item.languageId && languageListIDs?.includes(item.languageId)) {
                            item.isSelected = defaultSelectedLanguage?.id === item.languageId;
                        } else {
                            item.isSelected = true;
                        }
                    }
                });
            }

            if (summary.responseData.summaryResponse !== null) {
                /** reset tables data before assigning new data to the tables to avoid the table cache(retaining exiting values) issues. */
                const updatedSummary = resetSummaryTablesData(summary);
                setSummary(updatedSummary);
                await new Promise((r) => setTimeout(r, 100)); // wait state to update

                const updatedData: SummaryMetaData = {
                    ...summary,
                    selectedCurrency,
                    totals: sumTotal(summaryResponse),
                    flags: {
                        ...summary.flags,
                        isCountryFeeEditMode: false
                    },
                    responseData: {
                        ...summary.responseData,
                        summaryResponse: {
                            ...summary.responseData.summaryResponse,
                            currencySymbol: summaryResponse.currencySymbol,
                            disclaimerList: summaryResponse.disclaimerList,
                            instantCountryList: summaryResponse.instantCountryList,
                            customCountryList: summaryResponse.customCountryList,
                            languageBasedFee: summaryResponse.languageBasedFee,
                            serviceBasedFee: summaryResponse.serviceBasedFee,
                            grandTotal: summaryResponse.grandTotal,
                            isAITranslationAvailable: summaryResponse.isAITranslationAvailable
                        }
                    }
                };

                // Update data to store
                updateFormData(updatedData); // store - formData
                const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                    ...quoteOrderData?.info,
                    requestCurrencyId: selectedCurrency.currencyId
                };
                quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo); // store - info

                // Update the local state
                setSummary(updatedData);
            }
            setTimeout(() => {
                toggleLoadingIndicator(false);
            }, 1000);
        } catch (error) {
            toggleLoadingIndicator(false);
            console.error('Error updateCurrency() in summary: ', error);
        }
    };
    const updatedSelectedLanguage = (data: DropdownChangeEvent) => {
        // selected target language handler
        if (!summary?.responseData?.summaryResponse) return;

        const summaryResponse = summary.responseData.summaryResponse;
        const languageListIDs = summary.info.languageListIDs as number[];
        const upList: CountryList[] = summaryResponse.serviceBasedFee.upFee ?? [];
        const selectedLanguageId = summary.selectedLanguage as number;

        // Update isSelected property based on selectedLanguageId
        if (isEpTranslationAndValidation || isEpTranslationOnly) {
            upList?.forEach((item: CountryList) => {
                item.isSelected = data.value === item.languageId || item.languageId === 0;
            });
        } else {
            upList?.forEach((item: CountryList) => {
                if (languageListIDs?.includes(item.languageId as number)) {
                    item.isSelected = (data.value || selectedLanguageId) === item.languageId;
                }
            });
        }

        // Construct updated summary object
        const updatedSummary: SummaryMetaData = {
            ...summary,
            selectedLanguage: data.value,
            responseData: {
                ...summary.responseData,
                summaryResponse: {
                    ...summary.responseData.summaryResponse,
                    serviceBasedFee: {
                        ...summary.responseData.summaryResponse.serviceBasedFee,
                        upFee: upList
                    }
                }
            },
            totals: sumTotal(summaryResponse, Number(data.value))
        };

        setSummary(updatedSummary);
    };
    const updateEnglishFeeRequiredChangeWrapper = (isEnglishFeeRequiredChecked: boolean) => {
        updateEnglishFeeRequiredChange(isEnglishFeeRequiredChecked);
    };
    const updateEnglishFeeRequiredChange = async (isEnglishFeeRequiredChecked: boolean) => {
        try {
            const summaryResponse: SummaryResponse =
                await summaryService.updateEnglishFeeRequiredChange(
                    quoteOrderData.info.primaryId as number,
                    isEnglishFeeRequiredChecked
                );

            if (summaryResponse) {
                // update Summary page data
                fetchData({ updatedSummary: summary, updatedSummaryResponse: summaryResponse });
            }
        } catch (error) {
            console.error('Error in updateEnglishFeeRequiredChange() in summary: ', error);
        }
    };

    // helper
    const updateFormData = (updatedData: SummaryMetaData) => {
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();
        const updatedQuoteOrderFormData: QuoteOrderModuleStoreFormData = {
            ...updatedQuoteOrderData.formData,
            summaryPage: updatedData
        };

        // update store - form data
        if (
            JSON.stringify(updatedQuoteOrderData.formData.summaryPage) !==
            JSON.stringify(updatedData)
        ) {
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    };
    const handleAddInstruction = (value: string) => {
        setInstruction(value);

        // Check if the number of words exceeds 200
        const wordCount = value.trim().split(/\s+/).length;
        setIsInstructionError(wordCount > 200);
    };
    const resetSummaryTablesData = (summaryPageData: SummaryMetaData): SummaryMetaData => {
        try {
            /** reset the all table while navigation. we should get all the table data from API for every navigation.(i.e. fetchData())  */
            const summaryResponse = summaryPageData?.responseData?.summaryResponse;

            if (summaryResponse) {
                summaryResponse.disclaimerList = [];
                summaryResponse.instantCountryList.countryFeeList = [];
                summaryResponse.customCountryList = [];
                summaryResponse.serviceBasedFee.upFee = [];
                summaryResponse.serviceBasedFee.nonupFee = [];
                summaryResponse.languageBasedFee = [];
            }

            return summaryPageData;
        } catch (error) {
            console.error('Error in resetSummaryTablesData():', error);
            return summaryPageData;
        }
    };
    const getDefaultSelectedLanguageId = (
        sourceLanguage: string,
        upCountryDetails: CountryList[]
    ) => {
        if (isEditFlow) {
            const defaultSelectedLanguageId = upCountryDetails.find(
                (item: CountryList) => item.defaultLanguage
            )?.languageId;
            if (defaultSelectedLanguageId) return defaultSelectedLanguageId; // return the default language id if it is available
            return sourceLanguage === 'EN' ? LANGUAGE_ID.SPANISH : LANGUAGE_ID.ENGLISH;
        }
        return sourceLanguage === 'EN' ? LANGUAGE_ID.SPANISH : LANGUAGE_ID.ENGLISH;
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const handleNonUPList = (data: SummaryResponse, selectedLanguageID: number) => {
        if (
            data?.epTargetLanguages?.some((lang) => lang.targetLanguageId === LANGUAGE_ID.SPANISH)
        ) {
            if (selectedLanguageID === LANGUAGE_ID.SPANISH) {
                return data?.serviceBasedFee?.nonupFee;
            } else {
                return data?.serviceBasedFee?.nonupFee?.filter(
                    (country) => country.countryId || country.languageId
                );
            }
        } else {
            return data?.serviceBasedFee?.nonupFee;
        }
    };

    // calc
    const sumTotal = (
        summaryResponseData: SummaryResponse,
        selectedLanguageID?: number | null
    ): Totals | null => {
        // construct the totals for 'EP' flow
        try {
            const countryFeeList = summaryResponseData?.instantCountryList.countryFeeList;
            const customCountryFeeList = summaryResponseData?.customCountryList;
            const languageBaseFeeList = summaryResponseData?.languageBasedFee;

            // up \ non-up list from 'languageBaseFeeList'
            const upList = summaryResponseData?.serviceBasedFee.upFee;
            const nonUPList =
                isEpTranslationAndValidation || isEpTranslationOnly
                    ? handleNonUPList(
                          summaryResponseData,
                          selectedLanguageID ||
                              quoteOrderModuleStore.getData()?.formData?.selectCountryPageForEP
                                  ?.epTranslationAndValidationData?.upTargetLanguage
                                  ?.targetLanguageId ||
                              summaryResponseData?.epTargetLanguages?.find((lang) => lang.isDefault)
                                  ?.targetLanguageId ||
                              0
                      )
                    : summaryResponseData?.serviceBasedFee.nonupFee;

            // national validation - up
            const up = upList && sumDecimalValues(upList, true);
            const nonUP = nonUPList && sumDecimalValues(nonUPList);
            const languageFeeTotal = languageBaseFeeList && sumDecimalValues(languageBaseFeeList);
            const grandTotalUP = (languageFeeTotal ?? 0) + (up ?? 0) + (nonUP ?? 0);

            // national validation
            const countryFeeTotal = countryFeeList && sumDecimalValues(countryFeeList);
            const grandTotal = (languageFeeTotal ?? 0) + (countryFeeTotal ?? 0);

            // custom country
            const customCountry = customCountryFeeList && sumDecimalValues(customCountryFeeList);

            const updatedTotalsForEP: Totals = {
                nationalValidationUP: {
                    up,
                    nonUP,
                    languageFeeTotal,
                    grandTotalUP
                },
                nationalValidation: {
                    countryFeeTotal,
                    languageFeeTotal,
                    grandTotal
                },
                customCountry
            };

            return updatedTotalsForEP;
        } catch (error) {
            console.error(`Error in sumTotal() - ${error}`);
            return null;
        }
    };
    const sumDecimalValues = (list: CountryList[] | LanguageBasedFee[], isUP: boolean = false) => {
        try {
            if (!list || list.length === 0) return 0.0;

            let totalSum = 0;
            for (const obj of list) {
                if (obj.total) {
                    if (isUP) {
                        if ((obj as CountryList).isSelected) {
                            totalSum += parseFloat(obj.total);
                        }
                    } else totalSum += parseFloat(obj.total);
                }
            }

            return totalSum;
        } catch (e) {
            console.error(`Error in sumDecimalValues() - ${e}`);
            return 0.0;
        }
    };

    // init - fetch data or set data from store
    useEffect(() => {
        toggleLoadingIndicator(true);
        /** for other page we retain the values what use has entered and avoid the api call. 
             but here we should make api call every time and just retain the other values. */
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();
        const summaryPageDataOnStore = updatedQuoteOrderData.formData.summaryPage;
        // const isSummaryAPICalledInit = quoteOrderData.flags.isSummaryAPICalledInit;

        const isDataAvailable = !!summaryPageDataOnStore?.responseData?.summaryResponse;

        if (isDataAvailable) {
            setSummary(summaryPageDataOnStore);
        }

        const summaryPageData = isDataAvailable ? { ...summaryPageDataOnStore } : { ...summary };
        const updatedSummaryPageData = resetSummaryTablesData(summaryPageData);
        quoteOrderData.info.primaryId && fetchData({ updatedSummary: updatedSummaryPageData });
    }, []);

    // update summary(one-data approach) state change to store
    useEffect(() => {
        // Skip 'summary' state update for the initial load
        if (isFormInitialLoad) return;

        // Update the page data to store
        updateFormData(summary);
    }, [summary]);

    // popup
    const handleSubmit = () => {
        // Update the page data to store
        const updatedData = { ...summary, instruction };
        updateFormData(updatedData);

        // clear local state to avoid keep old data
        setInstruction('');

        // Update the local state
        setSummary({ ...summary, instruction });

        instructionPopupOpenClose();
    };
    const instructionPopupOpenClose = (isShow: boolean = false) => {
        const modal = document.getElementById(
            t('SUMMARY.POPUP.POP_ID')
        ) as HTMLDialogElement | null;
        if (modal) {
            if (isShow) {
                setInstruction(summary.instruction);
                modal.showModal();
            } else {
                // clear local state to avoid keep old data
                setInstruction('');
                modal.close();
            }
        }
    };
    return (
        <div
            key={quoteOrderData.flags.storeUpdateWithSummaryData}
            data-testid={'SummaryPage'}
            className="grid gap-y-3 p-5 pt-4 pb-2">
            {/* Page Header */}
            <SummaryPageHeader
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                // instructionPopupOpenClose={instructionPopupOpenClose}
                updateCurrency={updateCurrency}
                checked={checked}
                setChecked={setChecked}
                isShowEstSeqListingInfoLabel={isShowEstSeqListingInfoLabel}
                data-testid="SummaryPageHeader"
            />
            {/* Summary and Country */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <div data-testid={'Disclaimer'} className="col-span-1">
                    <Disclaimer summary={summary} setSummary={setSummary} />
                </div>
                <div data-testid={'SummaryConfig'} className="col-span-1 md:col-span-2">
                    <SummaryConfig
                        summary={summary}
                        setSummary={setSummary}
                        updateCurrency={updateCurrency}
                        updateEnglishFeeRequiredChange={updateEnglishFeeRequiredChangeWrapper}
                        sumTotal={sumTotal}
                        isChecked={checked}
                        updatedSelectedLanguage={updatedSelectedLanguage}
                        data-testid="SummaryConfigComponent"
                    />
                </div>
            </div>

            {/* Popup */}
            <InstructionPopup
                id={t('SUMMARY.POPUP.POP_ID')}
                title={t(
                    `${summary.instruction === '' ? 'SUMMARY.ADD_INSTRUCTION' : 'SUMMARY.UPDATE_INSTRUCTION'}`
                )}
                onClose={instructionPopupOpenClose}
                onClear={() => setInstruction('')}
                onSubmit={handleSubmit}
                primaryButtonText={t(
                    `${summary.instruction === '' ? 'COMMON.ADD' : 'COMMON.UPDATE'}`
                )}
                secondaryButtonText={t('COMMON.CLEAR')}
                isInstructionEmpty={instruction === ''} // if input is empty then disable the submit button
                data-testid="InstructionPopup">
                <div className="p-4 bg-neutral-300">
                    <textarea
                        data-testid={'SummaryInstructionPopupTextarea'}
                        className="max-h-14 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        id="summary-instruction-textarea"
                        placeholder={t('SUMMARY.POPUP.PLACEHOLDER')}
                        value={instruction ?? ''}
                        onChange={(e) => handleAddInstruction(e.target.value)}
                    />
                    {isInstructionError && (
                        <ErrorLabel
                            message={`${t('SUMMARY.ADD_INSTRUCTION_WORD_LIMIT_ERROR')}`}
                            data-testid="InstructionErrorLabel"
                        />
                    )}
                </div>
            </InstructionPopup>
        </div>
    );
};

export default Summary;
