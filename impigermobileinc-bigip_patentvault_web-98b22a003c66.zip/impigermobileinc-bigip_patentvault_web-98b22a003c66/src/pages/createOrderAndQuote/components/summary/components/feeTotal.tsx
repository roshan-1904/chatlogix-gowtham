import { FC } from 'react';
import { SummaryListingTableName, SummaryMetaData } from '../types/summary.type';
import { useTranslation } from 'react-i18next';
import { formatCurrency } from 'core/utils/utils';

interface FeeTotalType {
    summary: SummaryMetaData;
    summaryListingTableName: SummaryListingTableName;
    isEPNationalValidation?: boolean;
}

const FeeTotal: FC<FeeTotalType> = ({
    summary,
    summaryListingTableName,
    isEPNationalValidation
}) => {
    const { t } = useTranslation();
    const currencySymbol = summary.responseData?.summaryResponse?.currencySymbol;

    const getListingTotal = () => {
        let total;

        if (summaryListingTableName === 'countryFeeList') {
            total = summary?.totals?.nationalValidation?.countryFeeTotal;
        } else if (summaryListingTableName === 'upCountryList') {
            total = summary?.totals?.nationalValidationUP?.up;
        } else if (summaryListingTableName === 'nonUPCountryList') {
            total = summary?.totals?.nationalValidationUP?.nonUP;
        } else if (summaryListingTableName === 'languageFeeList') {
            total = summary?.totals?.nationalValidation?.languageFeeTotal;
        }

        return formatCurrency(total ?? 0);
    };

    return (
        <div
            data-testid={'FeeTotalComponent'}
            // please check and remove the commented class karthick periyasami
            // className={`${summaryListingTableName === 'upCountryList' ? 'bg-primary-light-50' : 'bg-primary-100/60'} mt-auto flex justify-end items-center px-5 py-2 gap-12`}
            className={`${isEPNationalValidation ? '!bg-warning-50' : 'bg-primary-light-50'}  mt-auto flex justify-end items-center px-5 py-2 gap-12`}>
            <div className="font-semibold">{t('COMMON.TOTAL')}</div>

            <div className="font-semibold">{`${currencySymbol ?? '$'} ${getListingTotal()}`}</div>
        </div>
    );
};

export default FeeTotal;
