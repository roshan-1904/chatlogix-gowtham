import { render, fireEvent, screen } from '@testing-library/react';
import InstructionPopup from './instructionPopup';

describe('InstructionPopup Component', () => {
    const mockOnClose = jest.fn();
    const mockOnClear = jest.fn();
    const mockOnSubmit = jest.fn();

    const defaultProps = {
        id: 'test-popup',
        title: 'Test Popup',
        onClose: mockOnClose,
        onClear: mockOnClear,
        onSubmit: mockOnSubmit,
        primaryButtonText: 'Submit',
        secondaryButtonText: 'Clear',
        children: <div>Test Content</div>,
        isInstructionEmpty: false
    };

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders the popup with correct title and content', () => {
        render(<InstructionPopup {...defaultProps} />);

        expect(screen.getByTestId('modal-title')).toHaveTextContent('Test Popup');
        expect(screen.getByTestId('modal-content')).toHaveTextContent('Test Content');
    });

    it('calls onClose when the close button is clicked', () => {
        render(<InstructionPopup {...defaultProps} />);

        fireEvent.click(screen.getByTestId('Summary-Instruction-PopUp-Close'));
        expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it('calls onClear when the secondary button is clicked', () => {
        render(<InstructionPopup {...defaultProps} />);

        fireEvent.click(screen.getByTestId('modal-secondary-button'));
        expect(mockOnClear).toHaveBeenCalledTimes(1);
    });

    it('calls onSubmit when the primary button is clicked', () => {
        render(<InstructionPopup {...defaultProps} />);

        fireEvent.click(screen.getByTestId('submit-button-popup'));
        expect(mockOnSubmit).toHaveBeenCalledTimes(1);
    });

    it('disables the submit button when isInstructionEmpty is true', () => {
        const newProps = { ...defaultProps, isInstructionEmpty: true };

        render(<InstructionPopup {...newProps} />);

        expect(screen.getByTestId('submit-button-popup')).toBeDisabled();
    });

    it('enables the submit button when isInstructionEmpty is false', () => {
        render(<InstructionPopup {...defaultProps} />);

        expect(screen.getByTestId('submit-button-popup')).not.toBeDisabled();
    });
});
