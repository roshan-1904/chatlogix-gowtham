import { FC, useLayoutEffect, useState } from 'react';
import { CountryConfigType, CountryList } from '../types/summary.type';
import { useTranslation } from 'react-i18next';
import CountryConfigTable from './countryConfigTable';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS } from 'constants/routes.constant';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';

interface SummaryCustomCountryType {
    configDataset: CountryConfigType;
}

const SummaryCustomCountry: FC<SummaryCustomCountryType> = ({ configDataset }) => {
    const { t } = useTranslation();
    const customCountryLength =
        configDataset.summary.responseData.summaryResponse?.customCountryList.length;
    const customCountryList =
        configDataset.summary.responseData?.summaryResponse?.customCountryList ?? [];
    const isHighRole: boolean = configDataset.summary.flags.isHighRole;
    const quoteOrderModuleStoreData = quoteOrderModuleStore.getData();
    const quoteOrderModuleStoreInfo = quoteOrderModuleStoreData.info;
    const pagesMatchStatusWithBackupData =
        quoteOrderModuleStoreData.flags.pagesMatchStatusWithBackupData;
    const isCountOrCountryChanged: boolean =
        pagesMatchStatusWithBackupData.isCountsModified ||
        pagesMatchStatusWithBackupData.isCountriesModified;
    const getHeaderName = () => {
        const headerName =
            t(
                `SUMMARY.${customCountryLength && customCountryLength > 1 ? 'CUSTOM_QUOTES' : 'CUSTOM_QUOTE'}`
            ) + (customCountryLength ? ` (${customCountryLength})` : '');

        return headerName;
    };
    const [quoteOrderData, setQuoteOrderData] = useState<QuoteOrderModuleStore>(
        quoteOrderModuleStore.getData()
    );

    // subscribe the stores
    useLayoutEffect(() => {
        const subscriptionQuoteOrder = quoteOrderModuleStore.subscribe(setQuoteOrderData);
        quoteOrderModuleStore.init();
        return () => {
            subscriptionQuoteOrder.unsubscribe();
        };
    }, []);

    return (
        <div
            data-testid={'CustomCountryComponent'}
            className="border border-red-300 rounded-md bg-red-50 px-0 py-2 mt-2">
            <div className="md:flex justify-between mb-2 space-y-2 md:space-y-0 px-5">
                {/* country section header */}
                <div
                    data-testid={'CustomCountryLabel'}
                    className="flex items-center justify-center text-red-500">
                    <label className="text-base font-bold">{getHeaderName()}</label>
                    <div
                        className="flex justify-between items-center"
                        key={JSON.stringify(customCountryList)}>
                        {configDataset.summary.flags.isHighRole &&
                            quoteOrderData.isFormValid[PATHS.SUMMARY] &&
                            customCountryList.filter(
                                (country: CountryList) => country.hasNullValues
                            ).length > 0 && (
                                <p data-testid="EmptyFeeError" className="pl-2 custom-error-label">
                                    <i className="pi pi-exclamation-triangle form-text error"></i>
                                    <span className="form-text error">
                                        {t('SUMMARY.EMPTY_FEE_ERROR')}
                                    </span>
                                </p>
                            )}
                    </div>
                </div>

                {/* warning */}
                <div data-testid={'CustomCountryWarning'} className="flex">
                    <span className="flex justify-start items-center gap-2 text-sm px-2 py-1 w-fit bg-orange-50 border-2 rounded-md border-orange-100">
                        <i className="pi pi-exclamation-circle text-yellow-500"></i>
                        <span className="md:whitespace-nowrap">
                            {t('SUMMARY.CUSTOM_QUOTE_WARNING')}
                        </span>
                    </span>
                </div>
            </div>

            {(quoteOrderModuleStoreInfo.isEditFlow && !isCountOrCountryChanged) || isHighRole ? (
                <div
                    data-testid={'CustomCustomCountryTableView'}
                    className="w-full overflow-auto rounded-b-md">
                    <CountryConfigTable
                        summary={configDataset.summary}
                        setSummary={configDataset.setSummary}
                        tableData={customCountryList ?? []}
                        sumTotal={configDataset.sumTotal}
                        summaryListingTableName={'customCountry'}
                        editMode={configDataset.summary.flags.isCountryFeeEditMode}
                        tableScrollHeight={239}
                    />
                </div>
            ) : (
                <>
                    {/* this is container view for 'Contact-Users'. 
                        so, every country should have 'countryName'. */}
                    {customCountryList.length > 0 &&
                        !customCountryList.some((country) => !country.countryName) && (
                            <div
                                data-testid={'CustomCustomCountryListingView'}
                                className="flex flex-row flex-wrap mt-4 mb-2 px-3 gap-2 overflow-y-scroll max-h-[234px]">
                                {customCountryList.map((customCountry: any) => (
                                    <div
                                        key={`Disclaimer_CustomCountry_${customCountry.countryId}`}
                                        data-testid={`CustomCountry_${customCountry.countryId}`}
                                        className="bg-red-100 rounded-xl border border-red-200">
                                        <div className="text-xs font-normal leading-5 px-2 py-1">
                                            {customCountry.countryName || ''}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                </>
            )}
        </div>
    );
};

export default SummaryCustomCountry;
