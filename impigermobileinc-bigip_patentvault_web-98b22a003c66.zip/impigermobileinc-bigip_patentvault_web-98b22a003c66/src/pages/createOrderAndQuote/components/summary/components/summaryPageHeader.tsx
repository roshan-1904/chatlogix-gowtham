import { FC, useMemo, useState } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { useTranslation } from 'react-i18next';

import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

import { SummaryMetaData, SummaryResponse, Totals } from '../types/summary.type';
import { inputSwitchPT, summaryRequestCurrency } from 'constants/styles.constant';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { InputSwitch } from 'primereact/inputswitch';
import { SummaryTableActions } from './summaryTableActions';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { isContactUser } from 'core/utils/utils';

interface SummaryPageHeaderType {
    summary: SummaryMetaData;
    setSummary: any;
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
    updateCurrency: any;
    // instructionPopupOpenClose: any;
    checked: any;
    setChecked: any;
    isShowEstSeqListingInfoLabel: boolean;
}

const SummaryPageHeader: FC<SummaryPageHeaderType> = ({
    summary,
    setSummary,
    sumTotal,
    // instructionPopupOpenClose,
    updateCurrency,
    checked,
    setChecked,
    isShowEstSeqListingInfoLabel = false
}) => {
    const { t } = useTranslation();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const quoteOrderData = quoteOrderModuleStore.getData();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);

    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: 'Confirmation',
        description: t('SUMMARY.CHANGE_CURRENCY_CONFIRMATION'),
        value: null
    });

    // handlers
    const handleCurrencyChange = (value: any) => {
        const _quoteOrderData = quoteOrderModuleStore.getData();
        /** ignore further actions if summary tables inline edit is in-progress. */
        if (_quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        setShowPopup({ ...showPopup, visible: true, value });
    };

    // popup / toast
    const handleConfirm = () => {
        // country currency change
        if (showPopup.value) {
            updateCurrency(showPopup.value);
            setSummary({ ...summary, currency: showPopup.value });
            setShowPopup({ ...showPopup, visible: false });
        }
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false, value: null });
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    return (
        <>
            {showPopup.visible && (
                <ConfirmationPopup
                    key={'changeCurrency'}
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    data-testid="ConfirmationPopup"
                />
            )}
            <div data-testid={'SummaryPageHeaderComponent'} className="md:flex justify-between">
                <div className="flex items-center">
                    <div
                        data-testid={'SummaryPageHeaderTitle'}
                        className="flex justify-start items-center">
                        <h4 className="font-semibold">{t('SUMMARY.TITLE')}</h4>
                    </div>
                    {isShowEstSeqListingInfoLabel && (
                        <p className="bg-error-50 w-fit my-3 py-0.5 px-2 ml-5 rounded border border-error text-sm flex gap-1 items-center">
                            {t('SUMMARY.ESL_CUSTOMIZED_QUOTE')}
                        </p>
                    )}
                </div>
                <div className="flex md:justify-end items-center gap-2">
                    {quoteOrderData.info.selectedService?.serviceTypeId ===
                        SERVICE_TYPE_ID.european_patent && (
                        <SummaryTableActions
                            summary={summary}
                            setSummary={setSummary}
                            sumTotal={sumTotal}
                            data-testid="SummaryTableActions"
                        />
                    )}
                    {/* {isHighRole && (
                        <button
                            data-testid="SummaryPageHeaderInstruction"
                            className="flex justify-end items-center font-semibold gap-1 cursor-pointer"
                            onClick={() => instructionPopupOpenClose(true)}
                        >
                            <i className="pi pi-book" />
                            <p>
                                {t(
                                    `${summary.instruction === '' ? 'SUMMARY.ADD_INSTRUCTION' : 'SUMMARY.VIEW_INSTRUCTION'}`
                                )}
                            </p>
                        </button>
                    )} */}
                    {!isThisContactUser && (
                        <div
                            data-testid={'SummaryPageHeaderInstruction'}
                            className="flex justify-end items-center font-semibold gap-2 mr-1">
                            <p data-testid="MapViewLabel select-none">{t('SUMMARY.MAP_VIEW')}</p>
                            <InputSwitch
                                data-testid="MapViewInputSwitch"
                                pt={inputSwitchPT}
                                checked={checked}
                                onChange={(e) => setChecked(e.value)}
                            />
                        </div>
                    )}
                    {/* Target language */}
                    {/* show this only for EP service */}
                    {quoteOrderData.info.selectedService?.serviceTypeId ===
                        SERVICE_TYPE_ID.european_patent && (
                        <div className="hidden items-center justify-start gap-2">
                            <label
                                className="text-neutral-400 text-sm select-none"
                                data-testid="RequestCurrencyLabel">
                                {t('SUMMARY.REQUEST_CURRENCY')}
                            </label>
                            <Dropdown
                                data-testid="CurrencyDropdown"
                                id="currencyChangeDropdown"
                                value={summary.selectedCurrency}
                                onChange={(e) => handleCurrencyChange(e.value)}
                                options={summary.responseData?.currencyResponse ?? []}
                                optionLabel="currencyCode"
                                placeholder="Select Currency"
                                pt={summaryRequestCurrency}
                            />
                        </div>
                    )}
                    {!isThisContactUser && (
                        <div
                            data-testid={'SummaryMapViewToggleWrapper'}
                            className="hidden justify-end items-center gap-2">
                            <p>{t('SUMMARY.MAP_VIEW')}</p>
                            <div className="form-control">
                                <input
                                    data-testid={'SummaryMapViewToggle'}
                                    type="checkbox"
                                    className="toggle toggle-xs bg-gray-300 checked:bg-blue-400 hover:bg-gray-400 checked:hover:bg-blue-700 border-2 border-gray-300 checked:border-blue-400"
                                    checked={summary.flags?.isMapViewOn}
                                    onChange={() =>
                                        setSummary({
                                            ...summary,
                                            flags: {
                                                ...summary.flags,
                                                isMapViewOn: !summary.flags?.isMapViewOn
                                            }
                                        })
                                    }
                                />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default SummaryPageHeader;
