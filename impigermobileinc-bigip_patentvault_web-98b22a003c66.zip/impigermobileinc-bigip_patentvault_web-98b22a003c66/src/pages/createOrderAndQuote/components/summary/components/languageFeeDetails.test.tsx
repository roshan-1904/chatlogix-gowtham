import { render, screen, waitFor } from '@testing-library/react';
import LanguageFeeDetails from './languageFeeDetails';
import { SummaryMetaData, Totals } from '../types/summary.type';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

const mockSummary: SummaryMetaData = {
    responseData: {
        summaryResponse: null,
        currencyResponse: null,
        languageResponse: null
    },
    instruction: '',
    customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
    selectedCurrency: null,
    totals: {} as Totals,
    info: {
        selectedServiceId: 1,
        selectedCategoryId: 1,
        languageListIDs: null,
        isUPFlow: false,
        countriesWithNullValues: []
    }, // Add the missing 'info' property
    flags: {
        isCountryFeeEditMode: true,
        isMapViewOn: true,
        isHighRole: false,
        scrollHeightOfCountryConfigTableForEP: 1,
        IsUp: null
        // isHighRole: false // Add a default value for isHighRole
    }
};

describe('LanguageFeeDetails', () => {
    test('renders correctly with language fees', () => {
        render(<LanguageFeeDetails summary={mockSummary} />);

        waitFor(() => {
            expect(screen.getByTestId('LanguageFeeDetailsComponent')).toBeInTheDocument();

            // Check if the first language is displayed
            expect(screen.getByTestId('LanguageName-0')).toHaveTextContent('French');
            expect(screen.getByTestId('TranslationFee-0')).toHaveTextContent('€ 100');

            // Check if the second language is displayed
            expect(screen.getByTestId('LanguageName-1')).toHaveTextContent('German');
            expect(screen.getByTestId('TranslationFee-1')).toHaveTextContent('€ 200');
        });
    });

    test('renders correctly when there are no language fees', () => {
        const emptySummary: SummaryMetaData = {
            responseData: {
                summaryResponse: null,
                currencyResponse: null,
                languageResponse: null
            },
            instruction: '',
            customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
            selectedCurrency: null,
            totals: {} as Totals,
            info: {
                selectedServiceId: 1,
                selectedCategoryId: 1,
                languageListIDs: null,
                isUPFlow: false,
                countriesWithNullValues: []
            }, // Add the missing 'info' property
            flags: {
                isCountryFeeEditMode: true,
                isMapViewOn: true,
                isHighRole: false,
                scrollHeightOfCountryConfigTableForEP: 1,
                IsUp: null
                // isHighRole: false // Add a default value for isHighRole
            }
        };

        render(<LanguageFeeDetails summary={emptySummary} />);

        waitFor(() => {
            expect(screen.getByTestId('NoResultsFound')).toBeInTheDocument();
            expect(screen.getByTestId('NoResultsFound')).toHaveTextContent(
                'COMMON.NO_RESULTS_FOUND'
            );
        });
    });

    test('renders with correct background for EP National Validation', () => {
        render(<LanguageFeeDetails summary={mockSummary} isEPNationalValidation={true} />);

        const component = screen.getByTestId('LanguageFeeDetailsComponent');
        waitFor(() => {
            expect(component).toHaveClass('bg-warning-50');
        });
    });

    test('renders with default background when not EP National Validation', () => {
        render(<LanguageFeeDetails summary={mockSummary} isEPNationalValidation={false} />);

        waitFor(() => {
            const component = screen.getByTestId('LanguageFeeDetailsComponent');
            expect(component).toHaveClass('bg-primary-light-50');
        });
    });
});
