import selectCountryService from 'pages/orders/selectCountry/services/selectCountry.service';
import MapComponent from 'pages/users/steppers/vendorUserStepper/maps';
import { Tooltip } from 'primereact/tooltip';
import { useEffect, useState } from 'react';
import GrandTotal from './grandTotal';

type PropType = {
    summary: any;
    setSummary: any;
    updateCurrency: any;
};

type PositionType = {
    lat: number;
    lng: number;
};

export type MarkerType = {
    id: number;
    position: PositionType;
    type: string;
    color: string;
    country: string;
    agencyFee: string;
    officialFee: string;
    translationFee: string;
    total: string;
};

type CountryListType = {
    code: string;
    iconName: string;
    latitude: string;
    longitude: string;
    name: string;
};

export const MapView = ({ summary, setSummary, updateCurrency }: PropType) => {
    const [allCountries, setAllCountries] = useState<CountryListType[]>([]);
    const summaryResponse = summary?.responseData?.summaryResponse;
    const instantCountryList = summaryResponse?.instantCountryList?.countryFeeList;
    const customCountryList = summaryResponse?.customCountryList;
    const currencySymbol = summaryResponse?.currencySymbol;

    async function getCountriesListAPI() {
        const countryListResponse: CountryListType[] =
            await selectCountryService?.getCountriesData(1);
        setAllCountries(countryListResponse);
    }

    const getCountryPosition = (countryName: string) => {
        const country = allCountries?.find((c) => c?.name === countryName);
        if (country) {
            return {
                lat: parseFloat(country?.latitude),
                lng: parseFloat(country?.longitude)
            };
        }
        // Return default coordinates if country is not found
        return { lat: -3.755, lng: -38.533 };
    };

    const instantCountryFormat = instantCountryList?.map((item: any, index: number) => {
        const position = getCountryPosition(item?.countryName as string);
        return {
            id: index + 1,
            position,
            type: 'Instant',
            color: 'bg-blue-200',
            country: item?.countryName,
            agencyFee: item?.agencyFee || '00.00',
            officialFee: item?.officialFee || '00.00',
            translationFee: item?.translationFee || '00.00',
            total: item?.total || '00.00'
        };
    });

    const customCountryFormat = customCountryList?.map((item: any, index: number) => {
        const position = getCountryPosition(item?.countryName as string);
        return {
            id: index + 1,
            position,
            type: 'Custom',
            color: 'bg-rose-200',
            country: item?.countryName,
            agencyFee: item?.agencyFee || '00.00',
            officialFee: item?.officialFee || '00.00',
            translationFee: item?.translationFee || '00.00',
            total: item?.total || '00.00'
        };
    });

    const membersList = instantCountryFormat?.concat(customCountryFormat);

    useEffect(() => {
        getCountriesListAPI();
    }, []);

    return (
        <div data-testid={'SummaryConfig'} className="col-span-1 md:col-span-2">
            <div className="flex flex-col relative border-2 rounded-lg border-blue-300  mb-7">
                <div className="flex w-full content-end items-center justify-end mb-3 p-1 ">
                    <div className="flex ml-3 items-center mr-3">
                        <div className="w-3 h-3 bg-blue-200"></div>
                        <p className="text-sm ml-3">{'Instant'}</p>
                    </div>
                    <div className="flex ml-3 items-center mr-3">
                        <div className="w-3 h-3 bg-rose-200"></div>
                        <p className="text-sm ml-3">{'Custom'}</p>
                    </div>
                    <div className="ml-3 mr-3">
                        <Tooltip
                            target=".custom-target-icon"
                            content={
                                'Select other countries below and our team will prepare your customized quote'
                            }
                            position="top"
                            mouseTrack={false}
                            className="text-sm mr-5"
                        />
                        <i className="custom-target-icon pi pi-info-circle text-primary cursor-pointer text-[1rem]" />
                    </div>
                </div>
                <MapComponent markers={membersList} currencySymbol={currencySymbol} />
                <GrandTotal
                    summary={summary}
                    setSummary={setSummary}
                    updateCurrency={updateCurrency}
                />
            </div>
        </div>
    );
};
