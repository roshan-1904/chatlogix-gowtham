import { FC, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Dropdown } from 'primereact/dropdown';

import { summaryGrandTotal } from 'constants/styles.constant';
import { GrandTotalFor, SummaryMetaData } from '../types/summary.type';
import { formatCurrency } from 'core/utils/utils';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';

interface GrandTotalType {
    summary: SummaryMetaData;
    setSummary: any;
    updateCurrency: any;
    grandTotalFor?: GrandTotalFor;
}

const GrandTotal: FC<GrandTotalType> = ({ summary, setSummary, updateCurrency, grandTotalFor }) => {
    const { t } = useTranslation();
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: 'Confirmation',
        description: t('SUMMARY.CHANGE_CURRENCY_CONFIRMATION'),
        value: null
    });
    const summaryResponse = summary.responseData.summaryResponse;

    // handlers
    const getGrandTotal = () => {
        let total;

        if (summary.info?.isUPFlow) {
            if (grandTotalFor) {
                if (grandTotalFor === 'nationalValidation') {
                    total = summary?.totals?.nationalValidation?.grandTotal;
                } else if (grandTotalFor === 'nationalValidationUP') {
                    total = summary?.totals?.nationalValidationUP?.grandTotalUP;
                }
            } else {
                if (summary.flags.IsUp) {
                    total = summary?.totals?.nationalValidationUP?.grandTotalUP;
                } else {
                    total = summary?.totals?.nationalValidation?.grandTotal;
                }
            }
        } else {
            total =
                (summary?.totals?.nationalValidation?.countryFeeTotal ?? 0) +
                (summary?.totals?.customCountry ?? 0);
        }

        return formatCurrency(total as number);
    };
    const handleCurrencyChange = (value: any) => {
        const quoteOrderData = quoteOrderModuleStore.getData();
        /** ignore further actions if summary tables inline edit is in-progress. */
        if (quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        setShowPopup({ ...showPopup, visible: true, value });
    };

    // popup / toast
    const handleConfirm = () => {
        // country currency change
        if (showPopup.value) {
            updateCurrency(showPopup.value);
            setSummary({ ...summary, currency: showPopup.value });
            setShowPopup({ ...showPopup, visible: false });
        }
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false, value: null });
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    return (
        <>
            {showPopup.visible && (
                <ConfirmationPopup
                    key={'changeCurrency'}
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                />
            )}
            <div
                data-testid={'GrandTotalComponent'}
                className="mt-auto flex justify-end items-center bg-primary-100/60 px-5 py-2 gap-3 border-t-0 rounded">
                <h5 className="font-semibold">{t('SUMMARY.GRAND_TOTAL')}</h5>
                <Dropdown
                    id="currencyChangeDropdown"
                    value={summary.selectedCurrency}
                    onChange={(e) => handleCurrencyChange(e.value)}
                    options={summary.responseData?.currencyResponse ?? []}
                    optionLabel="currencyCode"
                    placeholder="Select Currency"
                    pt={summaryGrandTotal}
                    data-testid="currency-dropdown"
                />
                <h5
                    data-testid={'CommonGrandTotal'}
                    className="font-semibold md:pl-4 w-32 text-right">
                    {`${summaryResponse?.currencySymbol ?? '$'} ${getGrandTotal()}`}
                </h5>
            </div>
        </>
    );
};

export default GrandTotal;
