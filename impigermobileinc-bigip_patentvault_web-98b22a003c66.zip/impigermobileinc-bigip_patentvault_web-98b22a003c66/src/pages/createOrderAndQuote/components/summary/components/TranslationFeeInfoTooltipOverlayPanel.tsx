import { InputSwitch } from 'primereact/inputswitch';
import { OverlayPanel } from 'primereact/overlaypanel';
import { useRef } from 'react';
import tickGreen from 'assets/svgs/tick-green.svg';
import aiStarIcon from 'assets/svgs/aiStarIcon.svg';
import { t } from 'i18next';
import { translationFeeInputSwitchPT } from 'constants/styles.constant';

export default function TranslationFeeInfoTooltipOverlayPanel(props: {
    isHideTitle?: boolean;
    iconCustomStyle?: string;
    isAITranslationAvailable?: boolean;
}) {
    const op = useRef<OverlayPanel>(null);

    return (
        <>
            {props.isHideTitle ? undefined : (
                <span className="uppercase">{t('PV_SETTING.RATES.TRANSLATION_FEE')}</span>
            )}
            {props.isAITranslationAvailable && (
                <span
                    data-testid="translation-fee-info-tooltip-icon"
                    onMouseEnter={(e) => op.current?.show(e, e.currentTarget)}
                    onMouseLeave={() => op.current?.hide()}
                    style={{ cursor: 'pointer' }}
                    className={props.iconCustomStyle + ''}>
                    <i className="pi pi-info-circle text-blue-500" />
                </span>
            )}

            <OverlayPanel
                ref={op}
                id="translation-fee-info-tooltip-overlay-panel"
                data-testid="translation-fee-info-tooltip-overlay-panel"
                pt={{
                    root: { className: 'w-[40.625rem] p-0 shadow-lg border' },
                    content: { className: 'p-0' }
                }}
                showCloseIcon={false}>
                <div className="w-full text-black">
                    {/* Header */}
                    <div className="flex items-center font-medium px-4 py-2.5 shadow">
                        <h5 className="">{t('PV_SETTING.RATES.AI_TRANSLATION_AVAILABLE')}</h5>
                        <img className="ml-2 h-6" src={aiStarIcon} />
                    </div>
                    <div className="p-4 pb-5 flex flex-col gap-3">
                        <div>
                            <span className="w-fit flex justify-start gap-2 p-1.5 text-black/60 bg-warning/40  border rounded-md border-warning-800">
                                <i className="pi pi-info-circle text-warning-800 mt-1"></i>
                                <span className="md:whitespace-normal text-[0.88rem] leading-5">
                                    {t('PV_SETTING.RATES.AI_TRANSLATION_FEE_TOGGLE_INFO_CONTENT')}
                                </span>
                            </span>
                        </div>

                        <div className="flex flex-col">
                            <div className="flex gap-3 items-center translation-fee-cell">
                                <h5 className=" text-primary font-medium">
                                    {t('PV_SETTING.RATES.AI_TRANSLATION_TITLE')}
                                </h5>

                                <InputSwitch
                                    checked
                                    pt={{
                                        ...translationFeeInputSwitchPT,
                                        input: {
                                            className: ' cursor-default'
                                        }
                                    }}
                                />
                            </div>
                            <p className="leading-6 my-3">
                                <span className="font-medium">
                                    {t('PV_SETTING.RATES.AI_TRANSLATION_CONTENT_TITLE')}
                                </span>{' '}
                                {t('PV_SETTING.RATES.AI_TRANSLATION_CONTENT')}
                            </p>

                            <ul className="[&>li]:flex [&>li]:gap-3 flex flex-col gap-3 pl-4">
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.AI_TRANSLATION_CONTENT_POINT1')}</p>
                                </li>
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.AI_TRANSLATION_CONTENT_POINT2')}</p>
                                </li>
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.AI_TRANSLATION_CONTENT_POINT3')}</p>
                                </li>
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.TRANSLATION_CONTENT_BOTH')}</p>
                                </li>
                            </ul>
                        </div>
                        <div className="border"></div>
                        <div className="flex flex-col">
                            <div className="flex gap-3 items-center translation-fee-cell">
                                <h5 className="font-medium text-[#1D304F]">
                                    {t('PV_SETTING.RATES.HUMAN_TRANSLATION_TITLE')}
                                </h5>

                                <InputSwitch
                                    checked={false}
                                    pt={{
                                        ...translationFeeInputSwitchPT,
                                        input: {
                                            className: ' cursor-default'
                                        },
                                        slider: {
                                            className:
                                                translationFeeInputSwitchPT.slider.className +
                                                ' before:!top-50.5%]'
                                        }
                                    }}
                                />
                            </div>

                            <p className="leading-6 my-3">
                                <span className="font-medium">
                                    {t('PV_SETTING.RATES.HUMAN_TRANSLATION_CONTENT_TITLE')}
                                </span>{' '}
                                {t('PV_SETTING.RATES.HUMAN_TRANSLATION_CONTENT')}
                            </p>

                            <ul className="[&>li]:flex [&>li]:gap-3 flex flex-col gap-3 pl-4">
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.HUMAN_TRANSLATION_CONTENT_POINT1')}</p>
                                </li>
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.HUMAN_TRANSLATION_CONTENT_POINT2')}</p>
                                </li>
                                <li>
                                    <img src={tickGreen} />
                                    <p>{t('PV_SETTING.RATES.TRANSLATION_CONTENT_BOTH')}</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </OverlayPanel>
        </>
    );
}
