import { FC, useState } from 'react';
import { useTranslation } from 'react-i18next';

import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { QuoteOrderModuleStoreFormData } from 'core/store/orderQuoteStore/orderQuote.type.store';
import {
    SaveExistingTableDataType,
    SummaryMetaData,
    SummaryResponse,
    Totals
} from '../types/summary.type';

interface SummaryTableActionsType {
    summary: SummaryMetaData;
    setSummary: any;
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
}

export const SummaryTableActions: FC<SummaryTableActionsType> = ({
    summary,
    setSummary,
    sumTotal
}) => {
    const { t } = useTranslation();

    const [saveExistingTableData, setSaveExistingTableData] =
        useState<SaveExistingTableDataType | null>(null);
    const isHighRole = summary ? summary.flags.isHighRole : null;
    const isCountryFeeEditMode = summary.flags.isCountryFeeEditMode;

    // buttons
    const buttonEdit = () => {
        return (
            <button
                data-testid={'EditCountryFeeButtonEPFlow'}
                type="button"
                className="btn font-medium text-xs border-none min-h-0 h-6 shadow-none text-primary p-0"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() => {
                    updateActionMode(true);
                }}>
                <img alt="edit" src="/images/svgs/i-edit-blue-icon.svg" className="h-3 w-3" />
                <span className="font-medium">{t('COMMON.EDIT')}</span>
            </button>
        );
    };
    const buttonUpdate = () => {
        return (
            <button
                data-testid="UpdateCountryFeeButton"
                type="button"
                className="btn button-primary flex items-center justify-center rounded-md min-h-0 h-6 w-16 border-primary-500 hover:border-primary-500"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() => {
                    updateActionMode(false, true);
                }}>
                <span className="font-medium text-[12px]">{t('COMMON.UPDATE')}</span>
            </button>
        );
    };
    const buttonDiscard = () => {
        return (
            <button
                data-testid="DiscardCountryFeeButton"
                type="button"
                className="btn button-neutral-outline flex items-center justify-center rounded-md min-h-0 h-6 w-16"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() => {
                    updateActionMode(false, false, true);
                }}>
                <span className="font-medium text-[12px]">{t('COMMON.DISCARD')}</span>
            </button>
        );
    };

    // handler
    const updateStore = (updatedSummary: SummaryMetaData, isEdit: boolean) => {
        const quoteOrderData = quoteOrderModuleStore.getData();

        // update store - form data
        const updatedQuoteOrderFormData: QuoteOrderModuleStoreFormData = {
            ...quoteOrderData.formData,
            summaryPage: { ...updatedSummary }
        };
        if (
            JSON.stringify(quoteOrderData.formData.patentDetailsPage) !==
            JSON.stringify(updatedSummary)
        ) {
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }

        // update store - flags
        if (quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress !== isEdit) {
            const updatedQuoteOrderFlags = {
                ...quoteOrderData.flags,
                isSummaryPageTablesInlineEditInProgress: isEdit
            };
            quoteOrderModuleStore.updatePage('flags', updatedQuoteOrderFlags);
        }
    };
    const updateActionMode = async (
        isEdit: boolean,
        isUpdate: boolean = false,
        isDiscard: boolean = false
    ) => {
        let updatedSummary: SummaryMetaData = { ...summary };
        const summaryResponseData: SummaryResponse | null =
            updatedSummary.responseData.summaryResponse;

        try {
            if (isEdit) {
                const updatedSaveExistingTableData = {
                    countryFeeList: summaryResponseData?.instantCountryList.countryFeeList ?? [],
                    upFee: summaryResponseData?.serviceBasedFee.upFee ?? [],
                    nonupFee: summaryResponseData?.serviceBasedFee.nonupFee ?? [],
                    languageFeeList: summaryResponseData?.languageBasedFee ?? [],
                    customCountryFeeList: summaryResponseData?.customCountryList ?? []
                };

                setSaveExistingTableData(updatedSaveExistingTableData);
            } else if (isDiscard) {
                /** note: we update the local state 'summary' and 'store' in every table inline-edit change.
                 *  and we will reset the changes when user click discard \ cancel after edit. */

                // hold for 100ms to wait for the table update
                await new Promise((r) => setTimeout(r, 100));

                if (saveExistingTableData && summaryResponseData) {
                    updatedSummary = {
                        ...updatedSummary,
                        responseData: {
                            ...updatedSummary.responseData,
                            summaryResponse: {
                                ...summaryResponseData,
                                instantCountryList: {
                                    ...summaryResponseData.instantCountryList,
                                    countryFeeList: saveExistingTableData.countryFeeList // set prev countryFeeList
                                },
                                customCountryList: saveExistingTableData.customCountryFeeList, // set prev customCountryFeeList
                                languageBasedFee: saveExistingTableData.languageFeeList, // set prev languageBasedFee
                                serviceBasedFee: {
                                    ...summaryResponseData.serviceBasedFee,
                                    upFee: saveExistingTableData.upFee, // set prev upFee
                                    nonupFee: saveExistingTableData.nonupFee // set prev nonupFee
                                }
                            }
                        }
                    };

                    const updatedSummaryResponseData = updatedSummary.responseData.summaryResponse;
                    updatedSummary.totals = updatedSummaryResponseData
                        ? sumTotal(updatedSummaryResponseData)
                        : updatedSummary.totals;
                } else {
                    throw new Error('Existing table data not available to reset the table.');
                }
            }

            /** get the updated summary page data form store in the 'update' action. (also, give sometime out to update the store)
             *  because, the summary state in summary page have some delay when user clicks update action after in0line edit. */
            isUpdate && (await new Promise((r) => setTimeout(r, 100)));
            const updatedSummaryPageData = isUpdate
                ? ({ ...quoteOrderModuleStore.getData().formData.summaryPage } as SummaryMetaData)
                : { ...updatedSummary };

            // update 'Edit' flag
            updatedSummary = {
                ...updatedSummaryPageData,
                flags: {
                    ...updatedSummary.flags,
                    isCountryFeeEditMode: isEdit
                }
            };
            setSummary(updatedSummary); // update local state

            updateStore(updatedSummary, isEdit); // update store - 'form-data' & 'flags'

            /** trigger the table error if any cell has null values. */
            isUpdate &&
                orderQuoteModuleService.checkSummaryTablesHasInvalidValues(
                    quoteOrderModuleStore.getData()
                );
        } catch (error) {
            console.error('Error in updateActionMode(): ', error);
        }
    };

    return (
        <>
            {isHighRole && (
                <div
                    data-testid="SummaryTableActionsContainer"
                    className="flex items-center justify-end gap-3 px-4 py-0">
                    {isCountryFeeEditMode ? (
                        <>
                            {buttonDiscard()}
                            {buttonUpdate()}
                        </>
                    ) : (
                        buttonEdit()
                    )}
                </div>
            )}
        </>
    );
};
