import { render, screen } from '@testing-library/react';
import SummaryConfig, { SummaryListingType } from './summaryConfig';
import CountryConfig from './countryConfig';
import { MapView } from './mapView';
import { Totals } from '../types/summary.type';

jest.mock('./countryConfig', () =>
    jest.fn(() => <div data-testid="CountryConfig">CountryConfig</div>)
);
jest.mock('./mapView', () => jest.fn(() => <div data-testid="MapView">MapView</div>));

describe('SummaryConfig Component', () => {
    const mockSummary = { someField: 'value' }; // mock summary object
    const mockSetSummary = jest.fn();
    const mockUpdateCurrency = jest.fn();
    const mockSumTotal = jest.fn();
    const mockUpdatedSelectedLanguage = jest.fn();

    const defaultProps: SummaryListingType = {
        summary: {
            responseData: {
                summaryResponse: null,
                currencyResponse: null,
                languageResponse: null
            },
            instruction: '',
            customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
            selectedCurrency: null,
            totals: {} as Totals,
            info: {
                selectedServiceId: 1,
                selectedCategoryId: 1,
                languageListIDs: null,
                isUPFlow: false,
                countriesWithNullValues: []
            }, // Add the missing 'info' property
            flags: {
                isCountryFeeEditMode: true,
                isMapViewOn: true,
                isHighRole: false,
                scrollHeightOfCountryConfigTableForEP: 1,
                IsUp: null
                // isHighRole: false // Add a default value for isHighRole
            }
        },
        setSummary: mockSetSummary,
        updateCurrency: mockUpdateCurrency,
        updateEnglishFeeRequiredChange: jest.fn(),
        sumTotal: mockSumTotal,
        isChecked: false,
        updatedSelectedLanguage: mockUpdatedSelectedLanguage
    };

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders CountryConfig when isChecked is false', () => {
        render(<SummaryConfig {...defaultProps} />);

        const countryConfig = screen.getByTestId('CountryConfig');
        expect(countryConfig).toBeInTheDocument();
        expect(CountryConfig).toHaveBeenCalledWith(
            expect.objectContaining({
                summary: mockSummary,
                setSummary: mockSetSummary,
                updateCurrency: mockUpdateCurrency,
                sumTotal: mockSumTotal,
                updatedSelectedLanguage: mockUpdatedSelectedLanguage
            }),
            {}
        );
    });

    test('renders MapView when isChecked is true', () => {
        const updatedProps = { ...defaultProps, isChecked: true };
        render(<SummaryConfig {...updatedProps} />);

        const mapView = screen.getByTestId('MapView');
        expect(mapView).toBeInTheDocument();
        expect(MapView).toHaveBeenCalledWith(
            expect.objectContaining({
                summary: mockSummary,
                setSummary: mockSetSummary,
                updateCurrency: mockUpdateCurrency
            }),
            {}
        );
    });
});
