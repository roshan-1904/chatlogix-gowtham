import { FC } from 'react';
import CountryConfig from './countryConfig';
import { SummaryMetaData, SummaryResponse, Totals } from '../types/summary.type';
import { MapView } from './mapView';

export interface SummaryListingType {
    summary: SummaryMetaData;
    setSummary: any;
    updateCurrency: any;
    updateEnglishFeeRequiredChange: (isChecked: boolean) => void;
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
    isChecked: boolean;
    updatedSelectedLanguage: any;
}

const SummaryConfig: FC<SummaryListingType> = ({
    summary,
    setSummary,
    updateCurrency,
    updateEnglishFeeRequiredChange,
    sumTotal,
    isChecked,
    updatedSelectedLanguage
}) => {
    return (
        <>
            {isChecked ? (
                <MapView
                    data-testid="MapView"
                    summary={summary}
                    setSummary={setSummary}
                    updateCurrency={updateCurrency}
                />
            ) : (
                <CountryConfig
                    data-testid="CountryConfig"
                    summary={summary}
                    setSummary={setSummary}
                    updateCurrency={updateCurrency}
                    updateEnglishFeeRequiredChange={updateEnglishFeeRequiredChange}
                    sumTotal={sumTotal}
                    updatedSelectedLanguage={updatedSelectedLanguage}
                />
            )}
        </>
    );
};

export default SummaryConfig;
