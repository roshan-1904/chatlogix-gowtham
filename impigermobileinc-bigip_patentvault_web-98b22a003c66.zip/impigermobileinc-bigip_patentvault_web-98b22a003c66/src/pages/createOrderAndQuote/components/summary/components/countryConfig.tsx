import { FC, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Dropdown } from 'primereact/dropdown';

import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

import CountryConfigHeader from './countryConfigHeader';
import GrandTotal from './grandTotal';
import CountryConfigTable from './countryConfigTable';
import FeeTotal from './feeTotal';
import SummaryCustomCountry from './summaryCustomCountry';
import CustomAccordion from 'components/accordion/accordion';

import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { checkBoxStyle, summaryLanguage, summaryRequestCurrency } from 'constants/styles.constant';
import { AccordionMetaData, accordionType } from 'components/accordion/accordion.type';
import {
    CountryList,
    SummaryListingTableName,
    ConfigDatasetType,
    CountryFeeMetaList,
    CountryConfigType
} from '../types/summary.type';
import { formatCurrency } from 'core/utils/utils';
import { LANGUAGE_ID, MODE, PATENT_SOURCE_LANGUAGE } from 'constants/app.constant';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { Checkbox } from 'primereact/checkbox';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { serviceIncludedOptions } from 'pages/orders/selectCountry/constants/country.constant';

// Non-EP flow
const NonEPFlow: FC<ConfigDatasetType> = ({ configDataset }) => {
    const isCountryFeeEditMode = configDataset?.summary?.flags.isCountryFeeEditMode;
    return (
        <>
            <div className="mb-2 rounded">
                <GrandTotal
                    summary={configDataset?.summary}
                    setSummary={configDataset?.setSummary}
                    updateCurrency={configDataset.updateCurrency}
                    data-testid="grandTotal"
                />
            </div>
            <div
                data-testid={'CountryConfigHeaderNonEp'}
                id="summary-country-list-frozen"
                className="flex flex-col border border-b-0 border-blue-400 rounded-t-md">
                {/* header */}
                <CountryConfigHeader
                    summary={configDataset?.summary}
                    setSummary={configDataset?.setSummary}
                    sumTotal={configDataset.sumTotal}
                    countryList={configDataset.countryFeeMetaList?.instantCountryList}
                    data-testid="countryConfigHeader"
                />

                {/* grand total */}
            </div>

            <div
                data-testid={'CountryConfigListingNonEp'}
                className="grid overflow-auto md:max-h-[calc(100vh-254px)]">
                <div
                    id="summary-country-list-scrollable"
                    className="w-full overflow-auto border-x border-b border-blue-400 rounded-b-md"
                    data-testid="countryListScrollable">
                    {/* Country fee list table */}
                    <CountryConfigTable
                        summary={configDataset?.summary}
                        setSummary={configDataset?.setSummary}
                        tableData={configDataset?.countryFeeMetaList?.instantCountryList ?? []}
                        sumTotal={configDataset.sumTotal}
                        summaryListingTableName={'countryFeeList'}
                        editMode={isCountryFeeEditMode}
                        tableScrollHeight={341}
                        data-testid="countryConfigTable"
                    />
                </div>

                {/* custom counties */}
                {(configDataset.customCountryLength as number) > 0 && (
                    <div data-testid="summaryCustomCountry">
                        <SummaryCustomCountry configDataset={configDataset} />
                    </div>
                )}
            </div>
        </>
    );
};

// EP flow
const EPFlow: FC<ConfigDatasetType> = ({ configDataset }) => {
    const { t } = useTranslation();
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: 'Confirmation',
        description: t('SUMMARY.CHANGE_CURRENCY_CONFIRMATION'),
        value: null
    });
    const [englishFeeRequired, setEnglishFeeRequired] = useState(
        configDataset?.summary.info.isEnglishFeeRequired ?? false
    );
    const selectedCategoryId = configDataset?.summary.info?.selectedCategoryId;
    const languageFeeList = configDataset?.summary.responseData?.summaryResponse?.languageBasedFee;
    const totals = configDataset?.summary.totals;
    const grandTotal = {
        epTotal: formatCurrency(totals?.nationalValidation.grandTotal as number),
        upTotal: formatCurrency(totals?.nationalValidationUP.grandTotalUP as number),
        claimsTotal: formatCurrency(totals?.nationalValidationUP.grandTotalUP as number)
    };
    const currencySymbol =
        configDataset?.summary?.responseData?.summaryResponse?.currencySymbol ?? '';
    const isCountryFeeEditMode = configDataset?.summary?.flags.isCountryFeeEditMode;

    const patentDetailsPage = quoteOrderModuleStore.getData().formData.patentDetailsPage ?? null;
    const isEPTranslationAndFiling =
        selectedCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'] ||
        selectedCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];
    const isEnglishSL = patentDetailsPage?.sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH;
    const selectedLanguage = configDataset?.summary.selectedLanguage ?? null;
    const languageList = configDataset?.summary.responseData.languageList;
    const sourceLanguage: string = patentDetailsPage?.sourceLanguage || '';
    const isEnglishFeeRequiredShow = !isEnglishSL && isEPTranslationAndFiling;
    const isAgencyOnlyIncluded =
        quoteOrderModuleStore.getData()?.formData?.selectCountryPageForEP
            ?.epTranslationAndValidationData?.upAndNationalValidationsFeesID?.serviceIncludedId ===
        serviceIncludedOptions.agencyFee.id;

    // handler
    const is_71_3_claims = (): boolean => {
        // should hide tab\countryList for 71_3_claims
        return (
            selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims']
        );
    };
    const isEP71_3ClaimsRecordal = (): boolean => {
        const specialCategories = [
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims'],
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['recordal'],
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['Renewals']
        ];
        return specialCategories.includes(selectedCategoryId);
    };
    const isEPCategory = () => {
        return (
            quoteOrderModuleStore.getData().info.selectedCategory?.parentId ===
            SERVICE_TYPE_ID.european_patent
        );
    };
    const isUPFeeAvailable = () => {
        if (
            configDataset?.summary?.responseData?.summaryResponse?.serviceBasedFee?.upFee
            // || configDataset?.summary?.responseData?.summaryResponse?.serviceBasedFee?.nonupFee
        ) {
            return (
                configDataset?.summary?.responseData?.summaryResponse?.serviceBasedFee?.upFee
                    ?.length > 0
                // || configDataset?.summary?.responseData?.summaryResponse?.serviceBasedFee?.nonupFee
                //         ?.length > 0
            );
        } else {
            return false;
        }
    };
    const handleTargetLanguageChange = (value: any) => {
        const quoteOrderData = quoteOrderModuleStore.getData();
        /** ignore further actions if summary tables inline edit is in-progress. */
        if (quoteOrderData.flags?.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        configDataset.updatedSelectedLanguage(value);
    };
    const handleCurrencyChange = (value: any) => {
        const quoteOrderData = quoteOrderModuleStore.getData();
        /** ignore further actions if summary tables inline edit is in-progress. */
        if (quoteOrderData.flags.isSummaryPageTablesInlineEditInProgress) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS'),
                type: ToastType.WARNING
            });
            return null;
        }

        setShowPopup({ ...showPopup, visible: true, value });
    };
    const handleEnglishFeeRequiredChange = (isChecked: boolean) => {
        setEnglishFeeRequired(isChecked);
        configDataset.setSummary({ ...configDataset.summary, isEnglishFeeRequired: isChecked });
        configDataset?.updateEnglishFeeRequiredChange?.(isChecked);
    };

    // popup / toast
    const handleConfirm = () => {
        // country currency change
        if (showPopup.value) {
            configDataset.updateCurrency(showPopup.value);
            configDataset.setSummary({ ...configDataset.summary, currency: showPopup.value });
            setShowPopup({ ...showPopup, visible: false });
        }
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false, value: null });
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    // reusable code of accordion
    const sectionHeaderTitle = (data: { title: string; color: string; bgColor: string }) => {
        return (
            <div
                data-testid={`CountryConfigTableHeaderEPFlow${t(`SUMMARY.${data.title}`)}`.replace(
                    / /g,
                    ''
                )}
                className={`${data.bgColor} flex justify-between items-center pt-4 px-5`}>
                <div className={`${data.color} text-base font-semibold`}>
                    {t(`SUMMARY.${data.title}`)}
                </div>
            </div>
        );
    };

    const handleTableData = (data: CountryList[]) => {
        if (
            configDataset?.summary?.responseData?.languageList?.some(
                (lang) =>
                    'targetLanguageId' in lang && lang.targetLanguageId === LANGUAGE_ID.SPANISH
            ) &&
            isEPTranslationAndFiling
        ) {
            if (configDataset?.summary?.selectedLanguage === LANGUAGE_ID.SPANISH) {
                return data;
            } else {
                return data.filter((country) => country.countryId || country.languageId);
            }
        } else {
            return data;
        }
    };

    const contentForUP = (
        <div className="bg-primary-100/50 p-1 pt-0">
            {/* Target language */}
            <div
                className="flex items-center justify-start gap-3 bg-primary-light-50 px-4 pt-2 pb-2"
                data-testid="targetLanguageSection">
                <label className="text-neutral-400 text-sm">{t('SUMMARY.TARGET_LANGUAGE')}</label>
                <Dropdown
                    id="targetLanguage"
                    value={isAgencyOnlyIncluded ? null : selectedLanguage}
                    onChange={(e) => handleTargetLanguageChange(e)}
                    disabled={sourceLanguage !== 'EN' || isAgencyOnlyIncluded}
                    options={languageList ?? []}
                    optionLabel="name"
                    optionValue="id"
                    placeholder="Select Language"
                    pt={{
                        ...summaryLanguage,
                        root: {
                            className:
                                summaryLanguage.root.className +
                                ' !w-[11.5rem]' +
                                (isAgencyOnlyIncluded ? ' hover:border-neutral-100' : '')
                        }
                    }}
                />
            </div>

            <div className="overflow-y-scroll overflow-x-hidden max-h-96 max-2xl:max-h-56 max-4xl:max-h-[17rem] bg-primary-light-50">
                {/* Language fees details  */}
                {languageFeeList && languageFeeList.length > 0 && (
                    <>
                        {/* Language header */}
                        {sectionHeaderTitle({
                            title: 'LANGUAGE_TITLE',
                            color: 'text-primary ',
                            bgColor: 'bg-primary-light-50'
                        })}

                        <div
                            data-testid={'LanguageFeeDetailsEPFlow'}
                            className="w-full overflow-auto rounded-b-md">
                            <CountryConfigTable
                                summary={configDataset?.summary}
                                setSummary={configDataset?.setSummary}
                                tableData={languageFeeList ?? []}
                                sumTotal={configDataset.sumTotal}
                                summaryListingTableName={'languageFeeList'}
                                editMode={configDataset?.summary?.flags.isCountryFeeEditMode}
                            />
                        </div>

                        <FeeTotal
                            data-testid={'FeeTotalEPFlow01'}
                            summary={configDataset?.summary}
                            summaryListingTableName={'languageFeeList'}
                        />
                    </>
                )}

                {!is_71_3_claims() && (
                    <>
                        {Object.entries(
                            configDataset.countryFeeMetaList?.serviceBasedFee || {}
                        ).map(([key, countryList]: [string, CountryList[]], index: number) => (
                            <>
                                {countryList.length > 0 && (
                                    <div key={index + 1}>
                                        {/* Table header */}
                                        {sectionHeaderTitle({
                                            title: `${key.toUpperCase()}_TITLE`,
                                            color: 'text-primary',
                                            bgColor: 'bg-primary-light-50'
                                        })}

                                        {selectedLanguage && (
                                            <div
                                                data-testid={'CountryConfigTableEPFlow'}
                                                className="w-full overflow-auto">
                                                {/* Country fee list table */}
                                                <CountryConfigTable
                                                    summary={configDataset?.summary}
                                                    setSummary={configDataset?.setSummary}
                                                    tableData={
                                                        key === 'nonUPCountryList'
                                                            ? handleTableData(countryList)
                                                            : countryList
                                                    } // table data to render
                                                    sumTotal={configDataset.sumTotal}
                                                    summaryListingTableName={
                                                        key as SummaryListingTableName
                                                    }
                                                    editMode={isCountryFeeEditMode}
                                                    tableScrollHeight={
                                                        key === 'nonUPCountryList' ? 200 : null
                                                    }
                                                />
                                            </div>
                                        )}
                                        <FeeTotal
                                            summary={configDataset?.summary}
                                            summaryListingTableName={key as SummaryListingTableName}
                                        />
                                    </div>
                                )}
                            </>
                        ))}
                    </>
                )}
            </div>
        </div>
    );
    const contentForEP = (
        <div className="overflow-y-scroll overflow-x-hidden max-h-96 max-2xl:max-h-64 max-4xl:max-h-80 bg-warning/45 border-warning p-1 pt-0">
            {/* Language fees details  */}
            {languageFeeList && languageFeeList.length > 0 && (
                <>
                    {/* Language header */}
                    {sectionHeaderTitle({
                        title: 'LANGUAGE_TITLE',
                        color: 'text-warning-800',
                        bgColor: 'bg-warning-50'
                    })}

                    <div
                        data-testid={'LanguageFeeDetailsEPFlow2'}
                        className="w-full overflow-auto rounded-b-md">
                        <CountryConfigTable
                            summary={configDataset?.summary}
                            setSummary={configDataset?.setSummary}
                            tableData={languageFeeList ?? []}
                            sumTotal={configDataset.sumTotal}
                            summaryListingTableName={'languageFeeList'}
                            editMode={configDataset?.summary?.flags.isCountryFeeEditMode}
                            isEPNationalValidation={isEPCategory()}
                        />
                    </div>

                    <FeeTotal
                        data-testid={'FeeTotalEPFlow01'}
                        summary={configDataset?.summary}
                        summaryListingTableName={'languageFeeList'}
                        isEPNationalValidation={isEPCategory()}
                    />
                </>
            )}

            {/* Country config  */}
            {!is_71_3_claims() && (
                <>
                    {/* Table header */}
                    {sectionHeaderTitle({
                        title: 'NATIONAL_VALIDATIONS',
                        color: 'text-warning-800',
                        bgColor: 'bg-warning-50'
                    })}

                    <div
                        data-testid={'CountryConfigTableEPFlow01'}
                        className="w-full overflow-auto">
                        {/* Country fee list table */}
                        <CountryConfigTable
                            summary={configDataset?.summary}
                            setSummary={configDataset?.setSummary}
                            tableData={configDataset?.countryFeeMetaList?.instantCountryList ?? []}
                            sumTotal={configDataset.sumTotal}
                            editMode={isCountryFeeEditMode}
                            summaryListingTableName={'countryFeeList'}
                            tableScrollHeight={230}
                            isEPNationalValidation={isEPCategory()}
                        />
                    </div>

                    <FeeTotal
                        data-testid={'FeeTotalEPFlow01'}
                        summary={configDataset?.summary}
                        summaryListingTableName={'countryFeeList'}
                        isEPNationalValidation={isEPCategory()}
                    />
                </>
            )}
        </div>
    );

    // accordion meta data
    const epFlowData: AccordionMetaData[] = [
        {
            id: 1,
            component: 'IQSummary',
            header: {
                name: t('SUMMARY.UP_NATIONAL_VALIDATIONS'),
                currencySymbol,
                grandTotal: grandTotal.upTotal ?? 0
            },
            content: contentForUP,
            accordionType: accordionType.UP
        },
        {
            id: 2,
            component: 'IQSummary',
            header: {
                name: t('SUMMARY.NATIONAL_VALIDATION_ONLY'),
                currencySymbol,
                grandTotal: grandTotal.epTotal ?? 0
            },
            content: contentForEP,
            accordionType: accordionType.EP
        },
        {
            id: 3,
            component: 'IQSummary',
            header: {
                name: t('SUMMARY.BOTH_DECIDE_LATER'),
                currencySymbol,
                grandTotal: ''
            },
            content: undefined,
            accordionType: accordionType.BOTH_UP_EP
        }
    ];

    const restrictUPAndBothDecideLater = () =>
        epFlowData.filter(
            (item) =>
                item.accordionType !== accordionType.UP &&
                item.accordionType !== accordionType.BOTH_UP_EP
        );

    const restrictIfOrder = () => {
        const mode = quoteOrderModuleStore.getData().info.mode;
        if (mode === MODE.CREATE_ORDER || mode === MODE.EDIT_ORDER) {
            return epFlowData.filter((item) => item.accordionType !== accordionType.BOTH_UP_EP);
        } else {
            return epFlowData;
        }
    };

    // UP data should not show for the "71_3_claims" category.
    const processedEpFlowData = isUPFeeAvailable()
        ? restrictIfOrder()
        : restrictUPAndBothDecideLater();
    const modifiedEpFlowData = isEP71_3ClaimsRecordal()
        ? restrictUPAndBothDecideLater()
        : processedEpFlowData;
    return (
        <div data-testid={'CountryConfigEPFlow'}>
            {showPopup.visible && (
                <ConfirmationPopup
                    key={'changeCurrency'}
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    data-testid="ConfirmationPopup"
                />
            )}
            <div
                className={`${isEnglishFeeRequiredShow ? 'justify-between' : 'justify-end'} flex px-2 py-2 mb-2 border border-gray-200 rounded-md bg-gray-50`}>
                {/* English fee checkbox */}
                {isEnglishFeeRequiredShow && (
                    <div className="flex items-center gap-2">
                        <Checkbox
                            key={'englishFeeCheckbox'}
                            checked={englishFeeRequired}
                            onChange={(e: any) =>
                                handleEnglishFeeRequiredChange(e.target.checked as boolean)
                            }
                            pt={checkBoxStyle}
                        />
                        <label
                            data-testid="EnglishFeeRequiredLabel"
                            className="text-sm select-none cursor-pointer"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() => handleEnglishFeeRequiredChange(!englishFeeRequired)}>
                            {t('SUMMARY.ENGLISH_TRANSLATION_REQUIRED')}
                        </label>
                    </div>
                )}

                {isEPCategory() && (
                    <div className="flex items-center justify-start gap-2">
                        <label className="text-sm select-none" data-testid="RequestCurrencyLabel">
                            {t('SUMMARY.REQUEST_CURRENCY')}
                        </label>
                        <Dropdown
                            data-testid="CurrencyDropdown"
                            id="currencyChangeDropdown"
                            value={configDataset.summary.selectedCurrency}
                            onChange={(e) => handleCurrencyChange(e.value)}
                            options={configDataset.summary.responseData?.currencyResponse ?? []}
                            optionLabel="currencyCode"
                            placeholder="Select Currency"
                            pt={summaryRequestCurrency}
                        />
                    </div>
                )}
            </div>
            <CustomAccordion
                tabs={modifiedEpFlowData}
                summary={configDataset.summary}
                setSummary={configDataset.setSummary}
            />
        </div>
    );
};

const CountryConfig: FC<CountryConfigType> = ({
    summary,
    setSummary,
    updateCurrency,
    updateEnglishFeeRequiredChange,
    sumTotal,
    updatedSelectedLanguage
}) => {
    const getCountryFeeList = (): CountryFeeMetaList | null => {
        try {
            if (!summary.responseData?.summaryResponse) {
                console.warn('Error: getCountryFeeList() - Summary data is missing or invalid');
                return null;
            }

            const { serviceBasedFee, instantCountryList } = summary.responseData.summaryResponse;
            const isUPFlow = summary?.info?.isUPFlow;

            /** for UP, we should show selected language via dropdown.
             we handle this with isSelected flag. 
             (and we have one other item also in this list. for that we set true initially) */
            // upFlow only required this functionalities

            const isEpTranslationAndValidation =
                quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];
            const isEpTranslationOnly =
                quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'];

            let filteredUPList: CountryList[] | null = null;
            if (isUPFlow) {
                if (isEpTranslationAndValidation || isEpTranslationOnly) {
                    filteredUPList = serviceBasedFee?.upFee.filter(
                        (item) =>
                            item.languageId === summary.selectedLanguage || item.languageId === 0 // allow languageId 0 Because is this up Agency Fee
                    );
                } else {
                    filteredUPList = serviceBasedFee?.upFee.filter(
                        (item) => item.isSelected === true
                    );
                }
            }

            /** for English, enough to shows the 'Total' column only.
             * we handled hide & show against the columns only in the table component.
             * but for this 'English' we should hide the fees columns except 'translation', for only this row.
             * so, just set null for this row only. */
            const updatedInstantCountryList = instantCountryList?.countryFeeList.map(
                (country: CountryList) => {
                    if (
                        (!country.countryId || country.countryId === 0) &&
                        country.languageId === LANGUAGE_ID.ENGLISH
                    ) {
                        return {
                            ...country,
                            agencyFee: null,
                            officialFee: null
                        };
                    }
                    return country;
                }
            );

            const countryFeeMetaList: CountryFeeMetaList = {
                instantCountryList: updatedInstantCountryList || [],
                serviceBasedFee: {
                    upCountryList: filteredUPList || serviceBasedFee?.upFee || [],
                    nonUPCountryList: serviceBasedFee?.nonupFee || []
                }
            };
            return countryFeeMetaList;
        } catch (error) {
            console.error('Error: getCountryFeeList():', error);
            return null;
        }
    };
    const customCountryLength =
        summary?.responseData?.summaryResponse?.customCountryList.length ?? 0;

    const configDataset: CountryConfigType = {
        summary,
        setSummary,
        updateCurrency,
        updateEnglishFeeRequiredChange,
        sumTotal,
        countryFeeMetaList: getCountryFeeList(),
        customCountryLength,
        updatedSelectedLanguage
    };

    const isEPFlow = summary.info.selectedServiceId === SERVICE_TYPE_ID.european_patent;
    if (isEPFlow) {
        return <EPFlow configDataset={configDataset} />;
    } else {
        return <NonEPFlow configDataset={configDataset} />;
    }
};

export default CountryConfig;
