import { render, screen, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom';
import SummaryCustomCountry from './summaryCustomCountry';
// import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS } from 'constants/routes.constant';
import { Totals } from '../types/summary.type';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(() => ({
        info: { isEditFlow: false },
        isFormValid: { [PATHS.SUMMARY]: true },
        flags: {
            pagesMatchStatusWithBackupData: { isCountsModified: false, isCountriesModified: false }
        }
    })),
    subscribe: jest.fn(() => ({ unsubscribe: jest.fn() })),
    init: jest.fn()
}));

afterEach(cleanup);

const mockConfigDataset = {
    summary: {
        responseData: {
            summaryResponse: null,
            currencyResponse: null,
            languageResponse: null
        },
        instruction: '',
        customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
        selectedCurrency: null,
        totals: {} as Totals,
        info: {
            selectedServiceId: 1,
            selectedCategoryId: 1,
            languageListIDs: null,
            isUPFlow: false,
            countriesWithNullValues: []
        }, // Add the missing 'info' property
        flags: {
            isCountryFeeEditMode: true,
            isMapViewOn: true,
            isHighRole: false,
            scrollHeightOfCountryConfigTableForEP: 1,
            IsUp: null
            // isHighRole: false // Add a default value for isHighRole
        }
    },
    setSummary: {},
    updateCurrency: {},
    updatedSelectedLanguage: {},
    customCountryLength: 1,
    countryFeeMetaList: null,
    sumTotal: jest.fn()
    // sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
};

describe('SummaryCustomCountry', () => {
    test('should render the component with the correct header name', () => {
        render(<SummaryCustomCountry configDataset={mockConfigDataset} />);

        // Check if the header is rendered
        const headerLabel = screen.getByTestId('CustomCountryLabel');
        expect(headerLabel).toBeInTheDocument();

        // Ensure the header contains "CUSTOM_QUOTES" since customCountryLength > 1
        expect(headerLabel).toHaveTextContent('SUMMARY.CUSTOM_QUOTES (2)');
    });

    test('should display empty fee error when a country has null values and isHighRole is true', () => {
        render(<SummaryCustomCountry configDataset={mockConfigDataset} />);

        // Check if the empty fee error is displayed
        const emptyFeeError = screen.getByTestId('EmptyFeeError');
        expect(emptyFeeError).toBeInTheDocument();
        expect(emptyFeeError).toHaveTextContent('SUMMARY.EMPTY_FEE_ERROR');
    });

    test('should render custom country names in the country listing', () => {
        render(<SummaryCustomCountry configDataset={mockConfigDataset} />);

        // Check if custom countries are rendered
        const customCountry1 = screen.getByTestId('CustomCountry_1');
        const customCountry2 = screen.getByTestId('CustomCountry_2');

        expect(customCountry1).toBeInTheDocument();
        expect(customCountry1).toHaveTextContent('Country 1');

        expect(customCountry2).toBeInTheDocument();
        expect(customCountry2).toHaveTextContent('Country 2');
    });

    test('should not display empty fee error if no country has null values', () => {
        render(<SummaryCustomCountry configDataset={mockConfigDataset} />);

        // Check if empty fee error is not rendered
        const emptyFeeError = screen.queryByTestId('EmptyFeeError');
        expect(emptyFeeError).not.toBeInTheDocument();
    });

    // test('should unsubscribe when component is unmounted', () => {
    //     const unsubscribeMock = jest.fn();
    //     quoteOrderModuleStore.subscribe = jest.fn(() => ({ unsubscribe: unsubscribeMock }));

    //     const { unmount } = render(<SummaryCustomCountry configDataset={mockConfigDataset} />);
    //     unmount();

    //     expect(unsubscribeMock).toHaveBeenCalled();
    // });
});
