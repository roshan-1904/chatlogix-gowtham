import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import CountryConfig from './countryConfig';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { useTranslation } from 'react-i18next';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import NotificationStore from 'core/store/notificationStore/notificationStore';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: jest.fn()
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

describe('CountryConfig Component', () => {
    const mockTranslation = { t: (key: string) => key };

    beforeEach(() => {
        (useTranslation as jest.Mock).mockReturnValue(mockTranslation);
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            formData: {
                patentDetailsPage: {
                    sourceLanguage: 'EN'
                }
            },
            info: {
                selectedCategory: { parentId: SERVICE_TYPE_ID.european_patent }
            },
            flags: {
                isSummaryPageTablesInlineEditInProgress: false
            }
        });
    });

    const mockSummary = {
        flags: {
            isCountryFeeEditMode: true
        },
        info: {
            selectedCategoryId: CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims'],
            isUPFlow: true,
            selectedServiceId: SERVICE_TYPE_ID.european_patent
        },
        totals: {
            nationalValidation: { grandTotal: 1000 },
            nationalValidationUP: { grandTotalUP: 2000 }
        },
        responseData: {
            summaryResponse: {
                currencySymbol: '$',
                serviceBasedFee: {
                    upFee: [{ isSelected: true }],
                    nonupFee: []
                },
                instantCountryList: { countryFeeList: [] },
                customCountryList: []
            },
            languageList: [{ name: 'English', id: 1 }]
        }
    };

    const mockSetSummary = jest.fn();
    const mockUpdateCurrency = jest.fn();
    const mockSumTotal = jest.fn();
    const mockUpdatedSelectedLanguage = jest.fn();

    test('renders EPFlow when selectedServiceId is european_patent', () => {
        render(
            <CountryConfig
                summary={mockSummary as any}
                setSummary={mockSetSummary}
                updateCurrency={mockUpdateCurrency}
                sumTotal={mockSumTotal}
                updatedSelectedLanguage={mockUpdatedSelectedLanguage}
            />
        );

        // Check that EPFlow components are rendered
        waitFor(() => {
            expect(screen.getByTestId('CountryConfigEPFlow')).toBeInTheDocument();
            expect(screen.getByText('SUMMARY.UP_NATIONAL_VALIDATIONS')).toBeInTheDocument();
            expect(screen.getByText('SUMMARY.NATIONAL_VALIDATION_ONLY')).toBeInTheDocument();
        });
    });

    test('handles currency change in EPFlow', () => {
        render(
            <CountryConfig
                summary={mockSummary as any}
                setSummary={mockSetSummary}
                updateCurrency={mockUpdateCurrency}
                sumTotal={mockSumTotal}
                updatedSelectedLanguage={mockUpdatedSelectedLanguage}
            />
        );

        waitFor(() => {
            const dropdown = screen.getByPlaceholderText('Select Language');
            fireEvent.change(dropdown, { target: { value: '1' } });

            // Ensure the currency change handler is called
            expect(mockUpdatedSelectedLanguage).toHaveBeenCalledWith('1');
        });
    });

    test('shows warning message when editing is in progress', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValueOnce({
            flags: {
                isSummaryPageTablesInlineEditInProgress: true
            }
        });

        render(
            <CountryConfig
                summary={mockSummary as any}
                setSummary={mockSetSummary}
                updateCurrency={mockUpdateCurrency}
                sumTotal={mockSumTotal}
                updatedSelectedLanguage={mockUpdatedSelectedLanguage}
            />
        );

        waitFor(() => {
            const dropdown = screen.getByPlaceholderText('Select Language');
            fireEvent.change(dropdown, { target: { value: '1' } });

            // Ensure warning message is shown
            expect(NotificationStore.showAlert).toHaveBeenCalledWith({
                message: 'QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS',
                type: 'warning'
            });
        });
    });
});
