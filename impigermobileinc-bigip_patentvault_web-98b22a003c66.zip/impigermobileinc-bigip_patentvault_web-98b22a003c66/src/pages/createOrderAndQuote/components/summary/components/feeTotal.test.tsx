import { render, screen, waitFor } from '@testing-library/react';
import FeeTotal from './feeTotal';
import { SummaryMetaData, SummaryListingTableName, Totals } from '../types/summary.type';

// Mock useTranslation hook
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

// Mock formatCurrency
jest.mock('core/utils/utils', () => ({
    formatCurrency: (value: number) => `$${value}`
}));

describe('FeeTotal Component', () => {
    const summaryMock: SummaryMetaData = {
        responseData: {
            summaryResponse: null,
            currencyResponse: null,
            languageResponse: null
        },
        instruction: '',
        customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
        selectedCurrency: null,
        totals: {} as Totals,
        info: {
            selectedServiceId: 1,
            selectedCategoryId: 1,
            languageListIDs: null,
            isUPFlow: false,
            countriesWithNullValues: []
        }, // Add the missing 'info' property
        flags: {
            isCountryFeeEditMode: true,
            isMapViewOn: true,
            isHighRole: false,
            scrollHeightOfCountryConfigTableForEP: 1,
            IsUp: null
            // isHighRole: false // Add a default value for isHighRole
        }
    };

    const renderComponent = (
        summaryListingTableName: SummaryListingTableName,
        isEPNationalValidation = false
    ) => {
        return render(
            <FeeTotal
                summary={summaryMock}
                summaryListingTableName={summaryListingTableName}
                isEPNationalValidation={isEPNationalValidation}
            />
        );
    };

    test('renders total for countryFeeList', () => {
        renderComponent('countryFeeList');

        waitFor(() => {
            expect(screen.getByText('COMMON.TOTAL')).toBeInTheDocument();
            expect(screen.getByText('€ $1000')).toBeInTheDocument();
        });
    });

    test('renders total for upCountryList', () => {
        renderComponent('upCountryList');

        waitFor(() => {
            expect(screen.getByText('COMMON.TOTAL')).toBeInTheDocument();
            expect(screen.getByText('€ $3000')).toBeInTheDocument();
        });
    });

    test('renders total for nonUPCountryList', () => {
        renderComponent('nonUPCountryList');

        waitFor(() => {
            expect(screen.getByText('COMMON.TOTAL')).toBeInTheDocument();
            expect(screen.getByText('€ $4000')).toBeInTheDocument();
        });
    });

    test('renders total for languageFeeList', () => {
        renderComponent('languageFeeList');

        waitFor(() => {
            expect(screen.getByText('COMMON.TOTAL')).toBeInTheDocument();
            expect(screen.getByText('€ $2000')).toBeInTheDocument();
        });
    });

    test('applies isEPNationalValidation class', () => {
        const { container } = renderComponent('countryFeeList', true);

        waitFor(() => {
            expect(container.firstChild).toHaveClass('!bg-warning-50');
        });
    });

    test('applies default class when isEPNationalValidation is false', () => {
        const { container } = renderComponent('countryFeeList', false);
        waitFor(() => {
            expect(container.firstChild).toHaveClass('bg-primary-light-50');
        });
    });

    // test('renders default currency symbol when none is provided', () => {
    //     const summaryNoCurrencyMock = {
    //         ...summaryMock,
    //         responseData: {
    //             summaryResponse: {
    //                 currencySymbol: null
    //             }
    //         }
    //     };
    //     const renderComponent = (
    //         summaryListingTableName: SummaryListingTableName,
    //         isEPNationalValidation = false
    //     ) => {
    //         return render(
    //             <FeeTotal
    //                 summary={summaryMock}
    //                 summaryListingTableName={summaryListingTableName}
    //                 isEPNationalValidation={isEPNationalValidation}
    //             />
    //         );
    //     };

    //     expect(screen.getByText('$ $1000')).toBeInTheDocument();
    // });
});
