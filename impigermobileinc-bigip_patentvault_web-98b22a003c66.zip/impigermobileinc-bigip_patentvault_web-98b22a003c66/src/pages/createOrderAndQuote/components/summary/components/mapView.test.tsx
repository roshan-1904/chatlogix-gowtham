import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { MapView } from './mapView'; // Adjust import path as needed
import selectCountryService from 'pages/orders/selectCountry/services/selectCountry.service';
import MapComponent from 'pages/users/steppers/vendorUserStepper/maps';

// Mocking services and components
jest.mock('pages/orders/selectCountry/services/selectCountry.service');
jest.mock('pages/users/steppers/vendorUserStepper/maps', () =>
    jest.fn(() => <div>MapComponent</div>)
);
jest.mock('./grandTotal', () => jest.fn(() => <div>GrandTotal</div>));

describe('MapView Component', () => {
    const mockSummary = {
        responseData: {
            summaryResponse: {
                instantCountryList: {
                    countryFeeList: [
                        {
                            countryName: 'Brazil',
                            agencyFee: '100.00',
                            officialFee: '50.00',
                            translationFee: '20.00',
                            total: '170.00'
                        }
                    ]
                },
                customCountryList: [
                    {
                        countryName: 'Argentina',
                        agencyFee: '200.00',
                        officialFee: '100.00',
                        translationFee: '50.00',
                        total: '350.00'
                    }
                ],
                currencySymbol: '$'
            }
        }
    };

    const mockCountriesData = [
        {
            code: 'BR',
            iconName: 'brazil',
            latitude: '-14.2350',
            longitude: '-51.9253',
            name: 'Brazil'
        },
        {
            code: 'AR',
            iconName: 'argentina',
            latitude: '-38.4161',
            longitude: '-63.6167',
            name: 'Argentina'
        }
    ];

    beforeEach(() => {
        selectCountryService.getCountriesData = jest.fn().mockResolvedValue(mockCountriesData);
    });

    test('should render the component and invoke getCountriesListAPI', async () => {
        render(<MapView summary={mockSummary} setSummary={jest.fn()} updateCurrency={jest.fn()} />);

        // Check if MapComponent and GrandTotal render correctly
        waitFor(() => {
            expect(screen.getByText('MapComponent')).toBeInTheDocument();
            expect(screen.getByText('GrandTotal')).toBeInTheDocument();
        });
        // Wait for getCountriesListAPI to be called and the data to be set
        await waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalledTimes(1);
        });
    });

    test('should render the correct number of markers for instant and custom countries', async () => {
        render(<MapView summary={mockSummary} setSummary={jest.fn()} updateCurrency={jest.fn()} />);

        // Wait for the API to resolve and the data to be set
        await waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalled();
        });

        // Verify the markers passed to MapComponent
        const markersProp = (MapComponent as jest.Mock).mock.calls[0][0].markers;
        expect(markersProp).toHaveLength(2);

        const [instantCountry, customCountry] = markersProp;
        expect(instantCountry.country).toBe('Brazil');
        expect(customCountry.country).toBe('Argentina');
    });

    test('should display the correct currency symbol', async () => {
        render(<MapView summary={mockSummary} setSummary={jest.fn()} updateCurrency={jest.fn()} />);

        // Wait for the API to resolve and the data to be set
        await waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalled();
        });

        // Verify the currency symbol is passed to MapComponent
        const currencySymbolProp = (MapComponent as jest.Mock).mock.calls[0][0].currencySymbol;
        expect(currencySymbolProp).toBe('$');
    });
});
