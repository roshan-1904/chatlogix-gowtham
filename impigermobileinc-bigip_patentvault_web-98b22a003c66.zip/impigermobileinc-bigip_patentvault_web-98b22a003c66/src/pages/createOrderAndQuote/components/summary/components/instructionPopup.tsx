import { FunctionComponent } from 'react';
interface PopupModalProps {
    id: string;
    title: string;
    onClose: () => void;
    onClear?: () => void;
    onSubmit?: () => void;
    primaryButtonText: string;
    secondaryButtonText: string;
    isInstructionEmpty?: boolean;
    children: React.ReactNode;
}

const InstructionPopup: FunctionComponent<PopupModalProps> = ({
    id,
    title,
    onClose,
    onClear,
    onSubmit,
    primaryButtonText,
    secondaryButtonText,
    isInstructionEmpty,
    children
}) => {
    return (
        <dialog id={id} className="modal modal-bottom sm:modal-middle">
            <div className="fixed inset-0 flex items-center justify-center z-50">
                <div className="bg-white w-10/12 md:w-5/12 shadow-lg rounded-md">
                    {/* Header */}
                    <div className="flex items-center justify-between bg-white drop-shadow p-4 px-6 rounded-t-lg">
                        <h2
                            className="text-xl font-medium text-primary-200"
                            data-testid="modal-title">
                            {title}
                        </h2>
                        <button
                            onClick={() => onClose()}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="Summary-Instruction-PopUp-Close"
                            className="text-gray-500 hover:text-gray-800">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-6 w-6"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2"
                                    d="M6 18L18 6M6 6l12 12"
                                />
                            </svg>
                        </button>
                    </div>
                    {/* Content */}
                    <div data-testid="modal-content">{children}</div>
                    {/* Footer */}
                    <div className="flex items-center bg-white border-t border-gray-300 shadow-md px-6 py-3 rounded-b-lg justify-end">
                        <div className="flex gap-2">
                            <button
                                data-testid="modal-secondary-button"
                                className="btn btn-sm button-neutral font-medium"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={onClear}>
                                {secondaryButtonText}
                            </button>
                            <button
                                data-testid={'submit-button-popup'}
                                className={'btn btn-sm button-primary font-medium'}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={onSubmit}
                                disabled={isInstructionEmpty}>
                                {primaryButtonText}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>
    );
};

export default InstructionPopup;
