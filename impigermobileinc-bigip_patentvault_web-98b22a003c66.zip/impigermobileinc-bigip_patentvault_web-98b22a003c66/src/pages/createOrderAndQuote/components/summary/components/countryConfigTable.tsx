import { FC, useRef, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';

import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { formatCurrency } from 'core/utils/utils';
import {
    ColumnMeta,
    CountryList,
    SummaryListingTableName,
    SummaryMetaData,
    SummaryResponse,
    Totals
} from '../types/summary.type';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { ENTITY_SIZE_TYPE } from 'pages/orders/selectCountry/constants/country.constant';
import { LANGUAGE_ID } from 'constants/app.constant';
import { InputSwitch } from 'primereact/inputswitch';
import { translationFeeInputSwitchPT } from 'constants/styles.constant';
import TranslationFeeInfoTooltipOverlayPanel from './TranslationFeeInfoTooltipOverlayPanel';
interface CountryConfigTableType {
    summary: SummaryMetaData;
    setSummary: any;
    tableData: CountryList[];
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
    summaryListingTableName: SummaryListingTableName;
    editMode: boolean;
    tableScrollHeight?: number | null; // country config table height for EP
    isEPNationalValidation?: boolean;
}

const CountryConfigTable: FC<CountryConfigTableType> = ({
    summary,
    setSummary,
    tableData,
    sumTotal,
    summaryListingTableName,
    editMode = false,
    isEPNationalValidation = false
}) => {
    const inputRef = useRef<HTMLInputElement>(null);
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);

    // #region - variables
    const info = quoteOrderData.info;
    const selectedCategoryId = info.selectedCategory?.patentCategoryId as number;
    const PCT: { [key: string]: number } =
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty];
    const EP: { [key: string]: number } = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent];
    const PC: { [key: string]: number } = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty];

    const summaryResponse = summary.responseData?.summaryResponse;
    const currencySymbol = summaryResponse?.currencySymbol;
    const serviceBasedFee = summaryResponse?.serviceBasedFee;

    const countryListingColumns: ColumnMeta[] = [
        {
            field: 'countryName',
            header: 'COUNTRY',
            type: 'name',
            editable: false,
            tooltip: false,
            tooltipText: null,
            notApplicableFor: []
        },
        {
            field: 'agencyFee',
            header: 'AGENCY FEE',
            type: 'number',
            editable: true,
            tooltip: true,
            tooltipText: serviceBasedFee?.agencyFeeTooltip ?? null,
            notApplicableFor: [
                'upCountryList',
                'languageFeeList',
                PCT.translation_only,
                EP.translation_only,
                PC.translation_only
            ]
        },
        {
            field: 'officialFee',
            header: 'OFFICIAL FEE',
            type: 'number',
            editable: true,
            tooltip: false,
            tooltipText: null,
            notApplicableFor: [
                'upCountryList',
                'languageFeeList',
                PCT.translation_only,
                EP.translation_only,
                PC.translation_only
            ]
        },
        {
            field: 'translationFee',
            header: 'TRANSLATION FEE',
            type: 'number',
            editable: true,
            tooltip: true,
            tooltipText: serviceBasedFee?.translationFeeTooltip ?? null,
            notApplicableFor: [
                'upCountryList',
                'languageFeeList',
                PCT.recordal,
                PCT.annuities,
                EP.recordal,
                EP.Renewals,
                EP.annuities
            ]
        },
        {
            field: 'total',
            header: 'TOTAL',
            type: 'number',
            editable:
                summaryListingTableName === 'upCountryList' ||
                summaryListingTableName === 'languageFeeList',
            tooltip: false,
            tooltipText: null,
            notApplicableFor: []
        }
    ];
    // #endregion

    // #region - helper functions
    const body = (rowData: any, field: any, type: string, editable: boolean) => {
        let bodyCell = '';
        const isCurrentCellEditable: boolean = isCellEditable(rowData, field, editable);

        if (type === 'number') {
            if (Is_AnnuitiesRecordalRenewals() && !rowData[field]) {
                bodyCell = '--';
            } else if (rowData[field]) {
                bodyCell = `${currencySymbol ?? '$'} ${formatCurrency(rowData[field] as number)}`;
            } else if (
                !rowData[field] &&
                !(
                    (!rowData['countryId'] || rowData['countryId'] === 0) &&
                    rowData['languageId'] === LANGUAGE_ID.ENGLISH
                )
            ) {
                bodyCell =
                    rowData['countryId'] === null && rowData['languageId'] === null ? '' : '--';
            }
        } else if (type === 'name' && field === 'countryName' && rowData['entityType'] !== '0') {
            if (!rowData[field] && rowData['languageName']) {
                bodyCell = rowData['languageName']; // language name
            } else bodyCell = rowData[field]; // country name

            if (rowData['entityType'] === ENTITY_SIZE_TYPE.SMALL.toString()) {
                bodyCell += ` (Small)`;
            } else if (rowData['entityType'] === ENTITY_SIZE_TYPE.LARGE.toString()) {
                bodyCell += ` (Large)`;
            }
        } else bodyCell = rowData[field];

        return (
            <div
                data-testid={`${field}-${rowData['countryId'] ?? rowData['languageId']}`}
                className={`${type === 'number' ? 'justify-end' : 'justify-start'} flex items-center translation-fee-cell`}>
                {(field === 'translationFee' ||
                    (rowData['isClaim'] && !rowData['countryId'] && field === 'total')) &&
                    (rowData.isAiTranslationConfiguration ||
                        rowData.isUserPreferredAiTranslationPrimary) &&
                    (EP.translation_only === selectedCategoryId ||
                    EP['71_3_claims'] === selectedCategoryId
                        ? true
                        : EP['translation_&_validation'] === selectedCategoryId
                          ? !rowData['countryId']
                              ? true
                              : rowData.includeTranslationFee
                          : true) && (
                        <InputSwitch
                            data-testid={`toggle-ai-translation-${rowData['countryId'] ?? rowData['languageId']}`}
                            checked={isChecked(rowData, 'isUserPreferredAiTranslation')}
                            className="mr-2"
                            pt={translationFeeInputSwitchPT}
                            disabled={
                                !rowData['isAiTranslationConfiguration'] &&
                                !rowData['isUserPreferredAiTranslation']
                            }
                            onChange={(e) => {
                                const newRowData = {
                                    ...rowData,
                                    ['isUserPreferredAiTranslation']: toggleBooleanValue(
                                        rowData['isUserPreferredAiTranslation']
                                    )
                                };
                                return onCellEditComplete(
                                    {
                                        rowData,
                                        field,
                                        newValue: e.value,
                                        newRowData
                                    },
                                    true /* isToggleButtonChange */
                                );
                            }}
                        />
                    )}

                {/* VIEW MODE */}
                {!(
                    summary.flags.isCountryFeeEditMode &&
                    editable &&
                    field !== 'boolean' &&
                    isCurrentCellEditable
                ) && (
                    <span
                        className={
                            editMode && isCurrentCellEditable
                                ? ' flex items-center justify-end text-base h-10 p-0 px-3 w-[100px] leading-[30px] truncate bg-white text-left border rounded-md'
                                : rowData['hasNullValues']
                                  ? ' text-error'
                                  : field === 'translationFee' || field === 'total'
                                    ? 'min-w-[5.5rem]'
                                    : ''
                        }>
                        {bodyCell}
                    </span>
                )}

                {/* EDIT MODE (inside body) */}
                {summary.flags.isCountryFeeEditMode &&
                    editable &&
                    field !== 'boolean' &&
                    isCurrentCellEditable &&
                    cellEditor(rowData, field, editable)}
            </div>
        );
    };
    const getFieldType = (field: any) => {
        const fieldType = countryListingColumns.find((column) => column.field === field)?.type;
        return fieldType ?? '';
    };
    const Is_AnnuitiesRecordalRenewals = (): boolean => {
        const specialCategories = [
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]['recordal'],
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]['annuities'],
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['Renewals'],
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['recordal']
        ];
        return specialCategories.includes(selectedCategoryId);
    };
    const filterCountryFeeColumns = () => {
        const filteredColumns: ColumnMeta[] = countryListingColumns.filter(
            (field: ColumnMeta) =>
                !field.notApplicableFor.includes(selectedCategoryId) &&
                !field.notApplicableFor.includes(summaryListingTableName)
        );

        return filteredColumns;
    };

    const isFrozenColumn = (field: string) => {
        const isFrozen = field === 'countryName' || field === 'total';
        return isFrozen;
    };
    const isCellEditable = (rowData: any, field: any, editable: boolean): boolean => {
        /** we handled hide & show against the columns only in this table component.
         * but for language rows, we should hide the fees columns except 'translation'.
         * so, for hide we set 'null' while in config 'configDataset'.
         * now to remove the 'edit' option. (currently this only for 'national validation table') */
        const isLanguageRow: boolean =
            (!rowData['countryId'] || rowData['countryId'] === 0) &&
            rowData['languageId'] === LANGUAGE_ID.ENGLISH;

        const isRestrictEditModeAgainstThisCell =
            summaryListingTableName === 'countryFeeList' &&
            isLanguageRow &&
            field !== 'translationFee';

        return isRestrictEditModeAgainstThisCell ? false : editable;
    };
    // #endregion

    // #region - table inline edit
    const cellEditor = (rowData: any, field: any, editable: boolean) => {
        const normalizeInputValue = (e: any) => {
            const inputValue = e.target.value;
            const filteredValue = inputValue
                .replace(/[^0-9.]/g, '') // remove non-numeric characters except dots
                .replace(/\.{2,}/g, '.') // replace multiple consecutive dots with a single dot
                .replace(/^(\d*\.?\d*).*$/, '$1'); // Ensure only one decimal point and handle leading/trailing dots

            onCellEditComplete({
                rowData,
                field,
                newValue: filteredValue,
                newRowData: { ...rowData, [field]: filteredValue }
            });
        };
        const handleFocus = () => {
            // When the input field receives focus, set the cursor position to the beginning
            if (inputRef.current) {
                inputRef.current.selectionStart = 0;
                inputRef.current.selectionEnd = 0;
            }
        };

        return isCellEditable(rowData, field, editable) ? (
            <div className="flex items-center justify-end">
                {field !== 'isUserPreferredAiTranslation' && (
                    <InputText
                        data-testid={`input-${field}-${rowData['countryId'] ?? rowData['languageId']}`}
                        type="text"
                        value={rowData[field]}
                        onChange={(e) => normalizeInputValue(e)}
                        onFocus={handleFocus}
                        ref={inputRef}
                        autoComplete="off"
                        pt={celEditorInputPT}
                    />
                )}
            </div>
        ) : null;
    };
    const onCellEditComplete = (e: any, isToggleButtonChange?: boolean | null) => {
        try {
            if (e.newValue === e.value) return null; // do not proceed if no change in value

            const updatedSummaryFormStore = quoteOrderModuleStore.getData().formData.summaryPage;
            let updatedSummary: SummaryMetaData = JSON.parse(
                JSON.stringify(updatedSummaryFormStore)
            );

            const summaryResponseData: SummaryResponse | null = JSON.parse(
                JSON.stringify(updatedSummary.responseData.summaryResponse)
            );
            if (!summaryResponseData) throw new Error('No summary response data found.');

            const rowData: CountryList = e.newRowData;

            // table lists
            const countryFeeList = summaryResponseData?.instantCountryList.countryFeeList ?? null;
            const upFee = summaryResponseData?.serviceBasedFee.upFee ?? null;
            const nonupFee = summaryResponseData?.serviceBasedFee.nonupFee ?? null;
            const customCountryList = summaryResponseData?.customCountryList ?? null;
            const languageFeeList = summaryResponseData?.languageBasedFee ?? null;

            const getListToUpdate = () => {
                switch (summaryListingTableName) {
                    case 'countryFeeList':
                        return countryFeeList;
                    case 'upCountryList':
                        return upFee;
                    case 'nonUPCountryList':
                        return nonupFee;
                    case 'languageFeeList':
                        return languageFeeList;
                    case 'customCountry':
                        return customCountryList;
                    default:
                        return null;
                }
            };
            const listToUpdate = getListToUpdate();

            if (listToUpdate) {
                let updatedList = updateTableList(listToUpdate, e, isToggleButtonChange);

                if (
                    updatedList &&
                    Array.isArray(updatedList) &&
                    updatedList.length > 0 &&
                    summaryResponseData
                ) {
                    // update the summary with updated list
                    const updateTableData = (
                        list: CountryList[],
                        tableName: SummaryListingTableName
                    ) => {
                        switch (tableName) {
                            case 'countryFeeList':
                                summaryResponseData.instantCountryList.countryFeeList = [...list];
                                break;
                            case 'upCountryList':
                                summaryResponseData.serviceBasedFee.upFee = [...list];
                                break;
                            case 'nonUPCountryList':
                                summaryResponseData.serviceBasedFee.nonupFee = [...list];
                                break;
                            case 'languageFeeList':
                                summaryResponseData.languageBasedFee = [...list];
                                break;
                            case 'customCountry':
                                summaryResponseData.customCountryList = [...list];
                                break;
                            default:
                                break;
                        }
                    };

                    // row total calc - this will return actual "list" without update total, is any error occurs.
                    updatedList = updateRowTotal(updatedList, rowData);
                    updateTableData(updatedList, summaryListingTableName);

                    /** feature ->  we should sync the data b/w national-validation(countryFeeList) & non-up(nonUPCountryList) tables.
                     *  i.e. when we update the fee in one table, it should reflect in another table.
                     *  this is only for 'translation_only' and 'translation_&_validation' categories of EP service.
                     *  because, 713 claims have only languages. Recordal and Renewal have only one Accordion. */
                    const isSyncNeeded =
                        (selectedCategoryId === EP.translation_only ||
                            selectedCategoryId === EP['translation_&_validation']) &&
                        (summaryListingTableName === 'countryFeeList' ||
                            summaryListingTableName === 'nonUPCountryList');

                    if (isSyncNeeded) {
                        let listToSync: CountryList[] = [];
                        if (summaryListingTableName === 'countryFeeList') {
                            listToSync = [...nonupFee]; // get opposite table list
                        } else if (summaryListingTableName === 'nonUPCountryList') {
                            listToSync = [...countryFeeList]; // get opposite table list
                        }

                        /** this flag to avoid the unnecessary updates to updateTableData().
                         *  if no row matched with the updated row, then no need to update the opposite table. */
                        let isAnyRowMatchedAndUpdated: boolean = false;

                        let syncedList = listToSync.map((country) => {
                            if (
                                (country.countryId &&
                                    e.rowData.countryId &&
                                    country.countryId === e.rowData.countryId) ||
                                (country.groupId && country.groupId === e.rowData.groupId)
                            ) {
                                isAnyRowMatchedAndUpdated = true;
                                if (isToggleButtonChange) {
                                    return {
                                        ...country,
                                        isUserPreferredAiTranslation: e.newValue,
                                        translationFee: e.newValue
                                            ? (country?.aiTranslationFee ?? 0).toString()
                                            : (country?.translationFormulaFee ?? 0).toString(),
                                        total: String(
                                            Number(
                                                e.newValue
                                                    ? (country?.aiTranslationFee ?? 0)
                                                    : (country?.translationFormulaFee ?? 0)
                                            ) +
                                                Number(country.officialFee) +
                                                Number(country.agencyFee)
                                        )
                                    };
                                }
                                return { ...country, [e.field]: e.newValue.toString() };
                            }
                            return country;
                        });

                        if (isAnyRowMatchedAndUpdated) {
                            const tableNameToSync =
                                summaryListingTableName === 'countryFeeList'
                                    ? 'nonUPCountryList'
                                    : 'countryFeeList'; // just take opposite table name

                            // row total calc - this will return actual "list" without update total, is any error occurs.
                            syncedList = updateRowTotal(syncedList, rowData);
                            updateTableData(syncedList, tableNameToSync);
                        }
                    }

                    updatedSummary = {
                        ...updatedSummary,
                        responseData: {
                            ...updatedSummary.responseData,
                            summaryResponse: summaryResponseData // updated summary response data
                        }
                    };

                    // update summary state
                    if (JSON.stringify(summary) !== JSON.stringify(updatedSummary)) {
                        updatedSummary.totals =
                            sumTotal(summaryResponseData) ?? updatedSummary.totals;

                        setSummary(updatedSummary);
                    }
                }
            }
        } catch (error) {
            console.error('Error in onCellEditComplete()', error);
        }
    };
    const updateTableList = (
        list: CountryList[],
        e: any,
        isToggleButtonChange?: boolean | null
    ) => {
        try {
            // get unique column to compare the row
            const uniqueColumn = getUniqueColumn(e.rowData as CountryList);

            /** in UI we are enabling the 'total' column to update the fee for UP and Language list
             * so, change here as per the business logic. */
            if (summaryListingTableName === 'upCountryList') {
                if (e.rowData.languageName.includes('Agency')) {
                    e.field = 'agencyFee';
                } else {
                    e.field = 'translationFee';
                }
            } else if (summaryListingTableName === 'languageFeeList') {
                e.field = 'translationFee';
            }

            const updatedList = list.map((country) => {
                if (
                    (country[uniqueColumn] === e.rowData[uniqueColumn] &&
                        country.groupId === null) ||
                    (country.groupId === e.rowData.groupId && country.groupId !== null) ||
                    (country.languageId && !country.countryId)
                ) {
                    if (e.field === 'isUserPreferredAiTranslation' || isToggleButtonChange) {
                        const newTr =
                            e.newValue === true
                                ? (country?.aiTranslationFee ?? 0)
                                : (country?.translationFormulaFee ?? 0); // just for testing purpose
                        return {
                            ...country,
                            isUserPreferredAiTranslation: e.newValue,
                            translationFee:
                                country.languageId && !country.countryId
                                    ? String(country?.translationFee ?? 0)
                                    : newTr.toString(),
                            total:
                                country.languageId && !country.countryId
                                    ? String(country?.translationFee ?? 0)
                                    : String(
                                          Number(newTr) +
                                              Number(country.officialFee || 0) +
                                              Number(country.agencyFee || 0)
                                      )
                        };
                    } else if (country[uniqueColumn] === e.rowData[uniqueColumn]) {
                        return {
                            ...country,
                            [e.field]: e.newValue.toString()
                        };
                    }
                }
                return country;
            });

            return updatedList;
        } catch (error) {
            console.error('Error in updateTableList()', error);
        }
    };
    const updateRowTotal = (list: CountryList[], rowData: CountryList) => {
        try {
            // get unique column to compare the row
            const uniqueColumn = getUniqueColumn(rowData);

            // get the row to update row total
            const updatedRowData =
                list.find((updatedRow) => updatedRow[uniqueColumn] === rowData[uniqueColumn]) ??
                rowData; // after updateTableList() we should use the updated row data

            // sum total
            const total =
                +(updatedRowData.translationFee ?? 0) +
                +(updatedRowData.officialFee ?? 0) +
                +(updatedRowData.agencyFee ?? 0);

            // replace the total value in the list on the respective row
            list =
                list?.map((row) => {
                    if (row[uniqueColumn] === updatedRowData[uniqueColumn]) {
                        row.total = JSON.stringify(total);
                    }
                    return row;
                }) ?? list;

            return list; // return the updated list (or actual list)
        } catch (error) {
            console.error('Error in updateRowTotal(): ', error);
            return list;
        }
    };
    const getUniqueColumn = (rowData: CountryList) => {
        let uniqueColumn: keyof CountryList | null = null; // default column

        // for UP and Language list, we need to use the 'languageId' to compare the row
        if (rowData?.countryId) {
            uniqueColumn = 'countryId';
        } else if (rowData?.languageId?.toString() && rowData.languageId >= 0) {
            // sometimes languageId come as 0
            uniqueColumn = 'languageId';
        } else {
            uniqueColumn = 'countryId';
        }

        return uniqueColumn;
    };
    // #endregion

    // #region - PT styles and styles
    const getTableStyles = () => {
        const tableStyles = {
            root: {
                className: `w-full ${getTableBGColor()}`
            },
            table: { className: `min-w-[40rem] ${getTableBGColor()}` },
            wrapper: { className: 'mx-2' },
            scrollable: { className: 'w-[200px]' },
            tbody: {
                className: `${summaryListingTableName === 'customCountry' ? 'bg-transparent' : `${getTableBGColor()}`}`
            },
            bodyrow: { className: `${getTableBGColor()}` }
        };
        return tableStyles;
    };
    const getTableColumnStyles = (field: any, type: string, editable: boolean) => {
        let bodyCellStyles = 'text-base py-2 px-[.80rem] text-nowrap';
        if (field === 'countryName') {
            bodyCellStyles += ' font-semibold';
        } else if (field === 'total') {
            bodyCellStyles += 'font-medium';
        }
        if (type === 'number') {
            // right align for 'currencies'
            bodyCellStyles += `${editMode && editable ? '' : ' text-right'}`;
        }

        const columnStyles = {
            root: { className: `${getTableBGColor()}` },
            headerCell: {
                className: `text-neutral-200/80 font-semibold px-[.80rem] ${getTableBGColor()}`
            },
            headerContent: {
                className: `${type === 'number' ? 'justify-end' : ''}`
            },
            headerTitle: {
                className: `flex gap-2`
            },
            bodyCell: { className: `${bodyCellStyles} ${getTableBGColor()}` }
        };
        return columnStyles;
    };
    const celEditorInputPT = {
        root: {
            className:
                ' flex items-center justify-start inline-block h-10 w-[100px] bg-white p-1.5 pl-3 pr-3 text-left text-base leading-35px border-primary/50 hover:border-primary/50 focus:shadow-none truncate'
        }
    };
    const getHeaderStyle = () => {
        const isShowHeader =
            summaryListingTableName === 'upCountryList' ||
            summaryListingTableName === 'languageFeeList';

        return {
            ...(isShowHeader && {
                display: 'none'
            })
        };
    };
    const getTableBGColor = (): string => {
        let bgColor = '';
        if (isEPNationalValidation) {
            bgColor = '!bg-warning-50';
        } else if (summaryListingTableName === 'customCountry') {
            bgColor = '!bg-red-50';
        } else {
            bgColor = 'bg-primary-light-50';
        }

        return bgColor;
    };
    function isChecked(rowData: any, field: any): boolean {
        return (rowData[field] as boolean) ?? false;
    }
    function toggleBooleanValue(value: any): boolean {
        return !(value ?? false);
    }
    // #endregion

    return (
        <div data-testid={'CountryConfigTableComponent'} className={`card p-fluid rounded-none`}>
            <DataTable
                id="summary-list"
                value={tableData}
                editMode="cell"
                scrollable
                pt={getTableStyles()}>
                {filterCountryFeeColumns().map(({ field, header, editable }) => {
                    const fieldType: string = getFieldType(field);

                    return (
                        <Column
                            key={field}
                            field={field}
                            header={
                                field === 'translationFee' ? (
                                    <TranslationFeeInfoTooltipOverlayPanel
                                        isAITranslationAvailable={
                                            summaryResponse?.isAITranslationAvailable
                                        }
                                    />
                                ) : (
                                    header
                                )
                            }
                            headerStyle={getHeaderStyle()}
                            frozen={isFrozenColumn(field)}
                            alignFrozen={field === 'total' ? 'right' : 'left'}
                            data-testid={`column-${field}`}
                            pt={getTableColumnStyles(field, fieldType, editable)}
                            body={(rowData: CountryList) => {
                                // Default cell rendering
                                return body(rowData, field, fieldType, editable);
                            }}
                        />
                    );
                })}
            </DataTable>
        </div>
    );
};

export default CountryConfigTable;
