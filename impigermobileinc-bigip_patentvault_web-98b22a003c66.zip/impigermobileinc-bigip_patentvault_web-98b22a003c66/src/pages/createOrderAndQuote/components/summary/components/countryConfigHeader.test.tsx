import { render, screen, cleanup } from '@testing-library/react';
import CountryConfigHeader from './countryConfigHeader';
// import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS } from 'constants/routes.constant';
import { CountryList, SummaryMetaData, Totals } from '../types/summary.type';
import '@testing-library/jest-dom/extend-expect';

// Mock translation hook
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key // return the key directly for simplicity
    })
}));

// Mock the store
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(),
    subscribe: jest.fn(() => ({ unsubscribe: jest.fn() })),
    init: jest.fn()
}));

describe('CountryConfigHeader', () => {
    let summary: SummaryMetaData = {
        responseData: {
            summaryResponse: null,
            currencyResponse: null,
            languageResponse: null,
            languageList: null
        },
        instruction: '',
        customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
        selectedCurrency: null,
        totals: {} as Totals,
        info: {
            selectedServiceId: 1,
            selectedCategoryId: 1,
            languageListIDs: null,
            isUPFlow: false,
            countriesWithNullValues: []
        }, // Add the missing 'info' property
        flags: {
            isCountryFeeEditMode: true,
            isMapViewOn: true,
            isHighRole: false,
            scrollHeightOfCountryConfigTableForEP: 1,
            IsUp: null
            // isHighRole: false // Add a default value for isHighRole
        }
    };
    let setSummary: jest.Mock;
    let sumTotal: jest.Mock;
    let countryList: any;

    beforeEach(() => {
        summary = {
            responseData: {
                summaryResponse: null
            }
        } as SummaryMetaData;

        setSummary = jest.fn();
        sumTotal = jest.fn().mockReturnValue(null);

        countryList = [
            { id: 1, hasNullValues: true },
            { id: 2, hasNullValues: false }
        ];

        // Mock initial data for quoteOrderModuleStore
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            isFormValid: {
                [PATHS.SUMMARY]: true
            }
        });
    });

    afterEach(() => {
        cleanup();
    });

    test.skip('renders CountryConfigHeader with correct header name', () => {
        render(
            <CountryConfigHeader
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                countryList={countryList}
            />
        );

        const headerElement = screen.getByText(/SUMMARY.INSTANT_QUOTES/i);
        expect(headerElement).toBeInTheDocument();
    });

    test.skip('displays the correct error message when country list has null values', () => {
        render(
            <CountryConfigHeader
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                countryList={countryList}
            />
        );

        const errorElement = screen.getByText(/SUMMARY.EMPTY_FEE_ERROR/i);
        expect(errorElement).toBeInTheDocument();
    });

    test.skip('does not display the error message when country list has no null values', () => {
        const newCountryList: CountryList[] = [
            {
                // id: 1,
                hasNullValues: false,
                groupId: null,
                agencyFee: '',
                translationFee: '',
                officialFee: '',
                total: ''
            },
            {
                // id: 2,
                hasNullValues: false,
                agencyFee: '',
                groupId: null,
                translationFee: '',
                officialFee: '',
                total: ''
            }
        ];

        render(
            <CountryConfigHeader
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                countryList={newCountryList}
            />
        );

        const errorElement = screen.queryByText(/SUMMARY.EMPTY_FEE_ERROR/i);
        expect(errorElement).not.toBeInTheDocument();
    });

    test.skip('subscribes to the quoteOrderModuleStore and cleans up on unmount', () => {
        const unsubscribeMock = jest.fn();

        // Mock the subscription
        (quoteOrderModuleStore.subscribe as jest.Mock).mockReturnValue({
            unsubscribe: unsubscribeMock
        });

        const { unmount } = render(
            <CountryConfigHeader
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                countryList={countryList}
            />
        );

        unmount();

        expect(unsubscribeMock).toHaveBeenCalled();
    });
});
