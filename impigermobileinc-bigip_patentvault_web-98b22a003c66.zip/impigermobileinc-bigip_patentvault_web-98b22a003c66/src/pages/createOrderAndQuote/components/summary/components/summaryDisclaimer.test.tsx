import { fireEvent, render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Disclaimer from './summaryDisclaimer';
import summaryPageMockData from '../mocks/summary.mock';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('Summary Disclaimer Component', () => {
    test('Add some disclaimer', () => {
        render(
            <BrowserRouter>
                <Disclaimer summary={summaryPageMockData.summaryMetaData} setSummary={jest.fn()} />
            </BrowserRouter>
        );

        const disclaimerField: HTMLElement = screen.getByTestId('CustomDisclaimerTextArea');
        expect(disclaimerField).toBeInTheDocument();
        expect(disclaimerField.tagName).toBe('TEXTAREA');

        fireEvent.change(disclaimerField, { target: { value: 'Test Disclaimer' } });
    });
});
