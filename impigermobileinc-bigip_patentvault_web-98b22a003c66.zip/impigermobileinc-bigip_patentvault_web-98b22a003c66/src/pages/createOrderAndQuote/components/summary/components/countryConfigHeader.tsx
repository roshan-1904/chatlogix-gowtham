import { FC, useLayoutEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CountryList, SummaryMetaData, SummaryResponse, Totals } from '../types/summary.type';
import { SummaryTableActions } from './summaryTableActions';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS } from 'constants/routes.constant';

interface CountryConfigHeaderType {
    summary: SummaryMetaData;
    setSummary: any;
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
    countryList?: CountryList[];
}

const CountryConfigHeader: FC<CountryConfigHeaderType> = ({
    summary,
    setSummary,
    sumTotal,
    countryList
}) => {
    const { t } = useTranslation();
    const [quoteOrderData, setQuoteOrderData] = useState<QuoteOrderModuleStore>(
        quoteOrderModuleStore.getData()
    );

    const instantCountryLength =
        summary?.responseData?.summaryResponse?.instantCountryList?.countryFeeList?.length ?? null;

    const getHeaderName = () => {
        const headerName =
            t(
                `SUMMARY.${instantCountryLength && instantCountryLength > 1 ? 'INSTANT_QUOTES' : 'INSTANT_QUOTE'}`
            ) + (instantCountryLength ? ` (${instantCountryLength})` : '');

        return headerName;
    };

    // subscribe the stores
    useLayoutEffect(() => {
        const subscriptionQuoteOrder = quoteOrderModuleStore.subscribe(setQuoteOrderData);
        quoteOrderModuleStore.init();
        return () => {
            subscriptionQuoteOrder?.unsubscribe();
        };
    }, []);

    return (
        <div
            data-testid={'countryConfigHeaderComponent'}
            className="flex justify-between items-center bg-primary-light-50 pl-5 py-2">
            <label className="text-base font-semibold text-primary flex">
                {getHeaderName()}
                <div
                    className="flex justify-between items-center"
                    key={JSON.stringify(countryList)}
                    data-testid="country-config-validation">
                    {quoteOrderData.isFormValid[PATHS.SUMMARY] &&
                        countryList &&
                        countryList.filter((country: CountryList) => country.hasNullValues).length >
                            0 && (
                            <p className="pl-2 custom-error-label">
                                <i className="pi pi-exclamation-triangle form-text error"></i>
                                <span className="form-text error">
                                    {t('SUMMARY.EMPTY_FEE_ERROR')}
                                </span>
                            </p>
                        )}
                </div>
            </label>
            <SummaryTableActions
                summary={summary}
                setSummary={setSummary}
                sumTotal={sumTotal}
                data-testid="summary-table-actions"
            />
        </div>
    );
};

export default CountryConfigHeader;
