import { FC } from 'react';
import { SummaryMetaData } from '../types/summary.type';
import { useTranslation } from 'react-i18next';
import { formatCurrency } from 'core/utils/utils';

interface CountryConfigTableType {
    summary: SummaryMetaData;
    isEPNationalValidation?: boolean;
}

const LanguageFeeDetails: FC<CountryConfigTableType> = ({
    summary,
    isEPNationalValidation = false
}) => {
    const { t } = useTranslation();
    const currencySymbol = summary.responseData?.summaryResponse?.currencySymbol;
    const languageBasedFee = summary.responseData?.summaryResponse?.languageBasedFee;

    return (
        <div
            data-testid={'LanguageFeeDetailsComponent'}
            className={`px-4 py-3  ${isEPNationalValidation ? 'bg-warning-50' : 'bg-primary-light-50'}`}>
            {/* <div
                data-testid={'LanguageFeeDetailsHeader'}
                className="flex justify-between items-center mb-2">
                <div className="text-base font-semibold text-primary">
                    {t('SUMMARY.LANGUAGE.TITLE')}
                </div>
                <p className="text-sm font-semibold text-neutral-200/80">
                    {t('SUMMARY.LANGUAGE.TRANSLATION_FEE')}
                </p>
            </div> */}

            {languageBasedFee && languageBasedFee.length > 0 ? (
                languageBasedFee.map((language, index) => (
                    <div
                        data-testid={'LanguageFeeDetailsBody'}
                        key={`${language.languageId} ${index}`}>
                        <div className="flex justify-between items-center">
                            <div
                                className="text-base font-semibold"
                                data-testid={`LanguageName-${index}`}>
                                {language.languageName}
                            </div>
                            <div
                                className="text-base font-semibold"
                                data-testid={`TranslationFee-${index}`}>{`${currencySymbol ?? '$'} ${formatCurrency(Number(language.translationFee ?? 0))}`}</div>
                        </div>
                        {index !== languageBasedFee.length - 1 && (
                            <hr
                                data-testid={`Divider-${index}`}
                                className="border-neutral-100 my-2"
                            />
                        )}
                    </div>
                ))
            ) : (
                <div data-testid="NoResultsFound" className="text-gray-500 pl-4">
                    {t('COMMON.NO_RESULTS_FOUND')}
                </div>
            )}
        </div>
    );
};

export default LanguageFeeDetails;
