import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import GrandTotal from './grandTotal';
// import { useTranslation } from 'react-i18next';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import NotificationStore from 'core/store/notificationStore/notificationStore';
import { SummaryMetaData, Totals } from '../types/summary.type';

// Mocking the dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn()
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

// jest.mock('components/confirmationPopup/confirmationPopup', () => ({
//     __esModule: true,
//     default: ({
//         onConfirm,
//         onCancel,
//         visible,
//         headerText,
//         description,
//         acceptLabel,
//         rejectLabel
//     }) => {
//         return visible ? (
//             <div>
//                 <p>{headerText}</p>
//                 <p>{description}</p>
//                 <button onClick={onConfirm}>{acceptLabel}</button>
//                 <button onClick={onCancel}>{rejectLabel}</button>
//             </div>
//         ) : null;
//     }
// }));

const setup = () => {
    const setSummary = jest.fn();
    const updateCurrency = jest.fn();
    const summary: SummaryMetaData = {
        responseData: {
            summaryResponse: null,
            currencyResponse: null,
            languageResponse: null
        },
        instruction: '',
        customDisclaimer: null, // Assign null or provide a valid value of type DisclaimerList
        selectedCurrency: null,
        totals: {} as Totals,
        info: {
            selectedServiceId: 1,
            selectedCategoryId: 1,
            languageListIDs: null,
            isUPFlow: false,
            countriesWithNullValues: []
        }, // Add the missing 'info' property
        flags: {
            isCountryFeeEditMode: true,
            isMapViewOn: true,
            isHighRole: false,
            scrollHeightOfCountryConfigTableForEP: 1,
            IsUp: null
            // isHighRole: false // Add a default value for isHighRole
        }
    };

    return render(
        <GrandTotal
            summary={summary}
            setSummary={setSummary}
            updateCurrency={updateCurrency}
            grandTotalFor="nationalValidation"
        />
    );
};

describe('GrandTotal Component', () => {
    it('should render grand total and dropdown', () => {
        setup();

        waitFor(() => {
            expect(screen.getByText('SUMMARY.GRAND_TOTAL')).toBeInTheDocument();
            expect(screen.getByTestId('currency-dropdown')).toBeInTheDocument();
            expect(screen.getByText('$ 1,000.00')).toBeInTheDocument();
        });
    });

    it('should open confirmation popup when currency is changed', () => {
        setup();

        waitFor(() => {
            const currencyDropdown = screen.getByTestId('currency-dropdown');
            fireEvent.change(currencyDropdown, { target: { value: 'EUR' } });

            expect(screen.getByText('Confirmation')).toBeInTheDocument();
            expect(screen.getByText('SUMMARY.CHANGE_CURRENCY_CONFIRMATION')).toBeInTheDocument();
        });
    });

    it('should confirm and update currency when confirmation is accepted', () => {
        const { getByText } = setup();

        // Trigger currency change
        waitFor(() => {
            fireEvent.change(screen.getByTestId('currency-dropdown'), { target: { value: 'EUR' } });

            // Confirm action
            fireEvent.click(getByText('COMMON.YES'));

            expect(NotificationStore.showAlert).not.toHaveBeenCalled();
            expect(quoteOrderModuleStore.getData).toHaveBeenCalled();
        });
    });

    it('should cancel the currency change when confirmation is rejected', () => {
        const { getByText } = setup();

        // Trigger currency change
        waitFor(() => {
            fireEvent.change(screen.getByTestId('currency-dropdown'), { target: { value: 'EUR' } });

            // Cancel action
            fireEvent.click(getByText('COMMON.NO'));

            expect(
                screen.queryByText('SUMMARY.CHANGE_CURRENCY_CONFIRMATION')
            ).not.toBeInTheDocument();
        });
    });

    it('should display warning message if table edit is in progress', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            flags: { isSummaryPageTablesInlineEditInProgress: true }
        });

        setup();

        // Trigger currency change
        waitFor(() => {
            fireEvent.change(screen.getByTestId('currency-dropdown'), { target: { value: 'EUR' } });

            expect(NotificationStore.showAlert).toHaveBeenCalledWith({
                message: 'QUOTE_AND_ORDER.WARNING.TABLE_EDIT_IN_PROGRESS',
                type: 'warning'
            });
        });
    });
});
