import { useTranslation } from 'react-i18next';
import { FC } from 'react';
import { DisclaimerList, SummaryMetaData } from '../types/summary.type';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MODE } from 'constants/app.constant';

interface DisclaimerType {
    summary: SummaryMetaData;
    setSummary: any;
}

const Disclaimer: FC<DisclaimerType> = ({ summary, setSummary }) => {
    const { t } = useTranslation();
    const { customDisclaimer } = summary;
    const isHighRole: boolean = summary.flags.isHighRole;
    // this is for UI only. not need to send in payload
    const disclaimerTooltip = summary.responseData?.summaryResponse?.disclaimerToolTip || null;
    const quoteOrderData = quoteOrderModuleStore.getData();
    const mode = quoteOrderData?.info.mode;
    const isQuoteCreationMode = mode === MODE.CREATE_QUOTE;

    const setSummaryCustomDisclaimer = (value: string) => {
        const disclaimerList: DisclaimerList[] =
            summary.responseData?.summaryResponse?.disclaimerList ?? [];

        const updatedCustomDisclaimer: DisclaimerList = {
            sNo: disclaimerList ? disclaimerList.length + 1 : 1,
            disclaimer: value,
            isCustomDisclaimer: true
        };

        setSummary({ ...summary, customDisclaimer: updatedCustomDisclaimer });
    };

    return (
        <div
            data-testid={'SummaryDisclaimerComponent'}
            className="border border-gray-200 rounded-md bg-gray-50">
            <div>
                <div className="flex justify-start items-center px-3 py-2 gap-2">
                    <img
                        data-testid={'DisclaimerHeaderImage'}
                        alt="disclaimer"
                        src="/images/svgs/summary-disclaimer.svg"
                        className="h-5"
                    />
                    <h6 data-testid={'DisclaimerHeaderLabel'} className="font-semibold">
                        {t('SUMMARY.DISCLAIMER')}
                    </h6>
                </div>
                <div
                    data-testid={'SummaryDisclaimerContent'}
                    className="px-3 overflow-y-scroll text-justify"
                    style={{
                        maxHeight: `calc(100vh - ${isHighRole ? '341px' : '222px'})`
                    }}>
                    {isQuoteCreationMode && disclaimerTooltip && (
                        <p key={'disclaimerTooltip'} className="leading-5 mb-3 text-sm">
                            {disclaimerTooltip}
                        </p>
                    )}
                    {summary.responseData?.summaryResponse?.disclaimerList?.map(
                        (disclaimer: DisclaimerList, index: number) =>
                            disclaimer.disclaimer !== '' && (
                                <p
                                    key={index + 1}
                                    className="leading-5 mb-3 text-sm"
                                    // rendering the content as html element
                                    dangerouslySetInnerHTML={{
                                        __html: disclaimer.disclaimer
                                    }}
                                />
                            )
                    )}
                </div>
            </div>
            {isHighRole && (
                <div data-testid={'CustomDisclaimer'} className="border-t border-gray-200 p-2 pb-1">
                    <p className="text-slate-700 text-sm pb-1">{t('SUMMARY.CUSTOM_DISCLAIMER')}</p>
                    <textarea
                        data-testid={'CustomDisclaimerTextArea'}
                        className="shadow appearance-none border rounded w-full min-h-20 max-h-20 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm px-2 py-1"
                        id="summary-instruction-textarea"
                        placeholder={t('SUMMARY.CUSTOM_DISCLAIMER_PLACEHOLDER')}
                        value={customDisclaimer?.disclaimer ?? ''}
                        onChange={(e) => setSummaryCustomDisclaimer(e.target.value)}
                    />
                </div>
            )}
        </div>
    );
};

export default Disclaimer;
