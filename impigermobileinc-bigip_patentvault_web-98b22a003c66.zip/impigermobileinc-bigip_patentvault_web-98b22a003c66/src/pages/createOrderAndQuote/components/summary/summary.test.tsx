import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Summary from './summary';
import AuthStore from 'core/store/authStore/authStore';
import summaryService from './services/summary.service';
import summaryPageMockData from './mocks/summary.mock';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { BrowserRouter } from 'react-router-dom';

// Mock dependencies
jest.mock('./services/summary.service');
jest.mock('pages/ordersAndQuotes/service/ordersAndQuotes.service');
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));
jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn()
}));
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    init: jest.fn(),
    subscribe: jest.fn(),
    updateData: jest.fn(),
    getData: jest.fn(),
    resetQuoteOrderStore: jest.fn()
}));

describe('Summary Component', () => {
    const mockAuthStore = {
        userInfo: {
            userId: 'user123',
            roleId: 'role123',
            companyId: 'company123',
            userFullName: 'John Doe'
        }
    };

    beforeEach(() => {
        // mock AuthStore
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue(mockAuthStore);

        // mock QuoteOrderStore
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            ...summaryPageMockData.updatedCompleteStoreInfo
        });

        // mock summary service methods
        jest.spyOn(summaryService, 'getCurrencyList').mockResolvedValue(
            summaryPageMockData.currencyList
        );
        jest.spyOn(OrdersAndQuotesService, 'getLanguageList').mockResolvedValue(
            summaryPageMockData.languageList
        );
    });

    test('renders Summary component with updated data', async () => {
        render(
            <BrowserRouter>
                <Summary />
            </BrowserRouter>
        );

        await waitFor(() => expect(screen.getByTestId('SummaryPage')).toBeInTheDocument());
        waitFor(() => expect(summaryService.getSummaryPageData).toHaveBeenCalled());
        waitFor(() => expect(summaryService.getCurrencyList).toHaveBeenCalled());
        waitFor(() => expect(OrdersAndQuotesService.getLanguageList).toHaveBeenCalled());
    });

    test('handles currency update', async () => {
        render(
            <BrowserRouter>
                <Summary />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByTestId('SummaryPage')).toBeInTheDocument();

            const currencyDropdown = screen.getByTestId('currency-dropdown');
            expect(currencyDropdown).toBeInTheDocument();
            fireEvent.click(currencyDropdown);

            const option: HTMLElement = screen.getByText('GBP');
            expect(option).toBeInTheDocument();
            fireEvent.click(option);

            const popupYesButton = screen.getByRole('button', { name: /yes/i });
            fireEvent.click(popupYesButton);

            waitFor(() => expect(summaryService.getCurrencyList).toHaveBeenCalled());
        });
    });
});
