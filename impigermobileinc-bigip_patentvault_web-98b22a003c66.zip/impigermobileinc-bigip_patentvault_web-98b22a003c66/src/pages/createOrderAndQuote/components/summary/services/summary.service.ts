import HttpService from 'core/interceptor/api.handler';
import { END_POINT } from 'constants/endPoint';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { toggleLoadingIndicator } from 'core/utils/utils';
import { SummaryResponse } from '../types/summary.type';

const baseUrlIQ: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseUrlIQ) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

/**
 * Fetches summary page data for the given order request ID.
 * @returns A promise that resolves with the fetched summary page data.
 */

const getSummaryPageData = async (
    selectedRequestCurrencyId: number | null = null
): Promise<SummaryResponse> => {
    toggleLoadingIndicator(true);
    const quoteOrderData = quoteOrderModuleStore.getData();
    const primaryId = quoteOrderData.info.primaryId;
    const isEpTranslationAndValidation =
        quoteOrderData.info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];
    const isEpTranslationOnly =
        quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'];
    let apiUrl = `${END_POINT.SUMMARY.GET_SUMMARY}/${primaryId}`;

    selectedRequestCurrencyId &&
        (apiUrl += `?selectedRequestCurrencyId=${selectedRequestCurrencyId}`);

    try {
        const params = {
            data: { hideLoader: isEpTranslationAndValidation || isEpTranslationOnly }
        };
        const response: SummaryResponse = await httpService.get(apiUrl, params, false, baseUrlIQ);
        toggleLoadingIndicator(true);
        const formattedResponse = {
            ...response,
            instantCountryList: {
                ...response['instantCountryList'],
                countryFeeList:
                    response['instantCountryList']?.countryFeeList?.map((country) => ({
                        ...country,
                        isUserPreferredAiTranslationPrimary: country.isUserPreferredAiTranslation
                    })) || []
            },
            serviceBasedFee: {
                ...response['serviceBasedFee'],
                nonupFee:
                    response['serviceBasedFee']?.nonupFee?.map((fee) => ({
                        ...fee,
                        isUserPreferredAiTranslationPrimary: fee.isUserPreferredAiTranslation
                    })) || []
            },
            languageBasedFee:
                response['languageBasedFee']?.map((fee) => ({
                    ...fee,
                    isUserPreferredAiTranslationPrimary: fee.isUserPreferredAiTranslation
                })) || []
        };
        return formattedResponse;
    } catch (error) {
        console.error('Error fetching summary page data:', error);
        toggleLoadingIndicator(false);
        throw error;
    }
};

const getCurrencyList = async <T>(showLoader: boolean = false): Promise<T> => {
    const apiUrl = `${END_POINT.SUMMARY.GET_CURRENCY}`;
    try {
        const params = { data: { hideLoader: !showLoader } };
        const response = await httpService.get<T>(apiUrl, params);
        return response;
    } catch (error) {
        console.error('Error fetching currency list data:', error);
        throw error;
    }
};

const updateEnglishFeeRequiredChange = async <T>(
    orderRequestId: number,
    isChecked: boolean = false
): Promise<T> => {
    const apiUrl = `${END_POINT.SUMMARY.ENGLISH_FEE_REQUIRED}?orderRequestDraftId=${orderRequestId}&isChecked=${isChecked}`;

    try {
        const response = await httpService.post<T, any>(apiUrl, {}, undefined, false, baseUrlIQ);
        return response;
    } catch (error) {
        console.error('Error while updating English fee required status:', error);
        throw error;
    }
};

const summaryService = {
    getSummaryPageData,
    getCurrencyList,
    updateEnglishFeeRequiredChange
};

export default summaryService;
