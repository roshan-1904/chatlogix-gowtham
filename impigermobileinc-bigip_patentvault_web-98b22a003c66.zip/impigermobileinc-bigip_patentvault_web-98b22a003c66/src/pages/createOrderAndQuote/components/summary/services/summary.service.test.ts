import HttpService from 'core/interceptor/api.handler';
import summaryService from './summary.service';

jest.mock('core/interceptor/api.handler');

describe('summaryService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getSummaryPageData', () => {
        const selectedRequestCurrencyId = 1;
        it('should fetch getSummaryPageData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await summaryService.getSummaryPageData(selectedRequestCurrencyId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                summaryService.getSummaryPageData(selectedRequestCurrencyId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getCurrencyList', () => {
        const showLoader = false;

        it('should fetch getCurrencyList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await summaryService.getCurrencyList(showLoader);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(summaryService.getCurrencyList(showLoader)).rejects.toThrow(mockError);
        });
    });
});
