import { LanguageBasedFeeList } from 'pages/orders/selectCountry/types/country.type';

export type SummaryListingTableName =
    | 'countryFeeList'
    | 'upCountryList'
    | 'nonUPCountryList'
    | 'languageFeeList'
    | 'customCountry';
export type GrandTotalFor = 'nationalValidation' | 'nationalValidationUP';

export const ADDITIONAL_FIELDS_LANG: { [key: string]: string[] } = {
    EN: ['es', 'de'],
    DE: ['en'],
    FR: ['en']
};

export const CountsFieldsList: string[] = [
    'countryCount',
    'countryList',
    'abstractWordCount',
    'drawingsWordCount',
    'descriptionWordCount',
    'numberOfDrawings',
    'claimsWordCount',
    'drawingsPageCount',
    'numberOfPriorityClaims',
    'numberOfClaims',
    'numberOfIndependentClaims',
    'estimatedNumberOfTotalPages',
    'estimatedSequenceListing'
];

export type CountryList = {
    countryId?: number | null;
    languageId?: number | null;
    entityType?: string | number | null;
    countryName?: string | null;
    languageName?: string | null;
    agencyFee: string | null;
    translationFee: string | null;
    officialFee: string | null;
    total: string | null;
    isSelected?: boolean; // remove for save API
    languageFee?: string | null;
    hasNullValues?: boolean;
    defaultLanguage?: boolean;
    groupId: number | null;
    isUserPreferredAiTranslation?: boolean | null;
    isUserPreferredAiTranslationPrimary?: boolean | null;
    isAiTranslationConfiguration?: boolean | null;
    aiTranslationFee?: number | null;
    translationFormulaFee?: number | null;
    includeTranslationFee?: boolean;
};
export type DisclaimerList = {
    sNo: number;
    disclaimer: string;
    isCustomDisclaimer?: boolean | null;
    customInstruction?: string | null;
};
export type InstantCountryList = {
    countryFeeList: CountryList[];
};
export type LanguageBasedFee = {
    languageFee: string | null;
    languageId: number | null;
    languageName: string | null;
    total: string | null;
    translationFee: string | null;
};
export type ServiceBasedFee = {
    upFee: CountryList[] | [];
    nonupFee: CountryList[] | [];
    agencyFeeTooltip: string | null;
    translationFeeTooltip: string | null;
};
export interface Flag {
    isCountryFeeEditMode: boolean;
    isMapViewOn: boolean;
    isHighRole: boolean;
    scrollHeightOfCountryConfigTableForEP: number;
    IsUp: boolean | null;
    isBothDecideLater?: boolean | null;
}
export interface Info {
    selectedServiceId: number;
    selectedCategoryId: number;
    languageListIDs?: number[] | null;
    isUPFlow: boolean;
    isEnglishFeeRequired?: boolean;
    countriesWithNullValues?: number[];
    selectedLanguageID?: number | null;
}
export type SummaryResponse = {
    currencySymbol: string;
    customCountryList: CountryList[];
    customCountryMessage: string | null;
    disclaimerList: DisclaimerList[];
    disclaimerToolTip?: string | null;
    grandTotal: number;
    instantCountryList: InstantCountryList;
    languageBasedFee: CountryList[];
    serviceBasedFee: ServiceBasedFee;
    epTargetLanguages?: LanguageBasedFeeList[];
    isAITranslationAvailable?: boolean;
};
export type Totals = {
    nationalValidation: {
        countryFeeTotal: number;
        languageFeeTotal: number;
        grandTotal: number;
    };
    nationalValidationUP: {
        up: number | null;
        nonUP: number;
        languageFeeTotal: number;
        grandTotalUP: number;
    };
    customCountry: number;
};
export type CurrencyResponse = {
    currencyId: number;
    currencyName: string;
    currencyIcon: string | null;
    concatCode: string;
    currencyCode: string;
    currencySymbol?: string | null;
    isPreferredCurrency?: boolean | null;
};
export interface SummaryPageResponseType {
    summaryResponse: SummaryResponse | null;
    currencyResponse: CurrencyResponse[] | null;
    languageResponse: Language[] | null;
    languageList?: Language[] | LanguageBasedFeeList[] | null;
}
// Summary meta data
export type SummaryMetaData = {
    instruction: string;
    customDisclaimer: DisclaimerList | null;
    selectedCurrency: CurrencyResponse | null;
    selectedLanguage?: number | null;
    totals: Totals | null;
    responseData: SummaryPageResponseType;
    info: Info;
    flags: Flag;
};

export type ColumnMeta = {
    field: string;
    header: string;
    type: string;
    editable: boolean;
    tooltip: boolean;
    tooltipText: string | null;
    notApplicableFor: (SummaryListingTableName | number)[];
};
export type CountryFeeMetaList = {
    instantCountryList: CountryList[];
    serviceBasedFee: { [key: string]: CountryList[] };
};
export type CountryConfigType = {
    summary: SummaryMetaData;
    setSummary: any;
    updateCurrency: any;
    updateEnglishFeeRequiredChange?: (isChecked: boolean) => void;
    sumTotal: (summaryResponseData: SummaryResponse) => Totals | null;
    updatedSelectedLanguage: any;
    customCountryLength?: number;
    countryFeeMetaList?: CountryFeeMetaList | null;
};
export type ConfigDatasetType = {
    configDataset: CountryConfigType;
};

export interface Language {
    abbreviation: string;
    id: number;
    isSource: any; // Adjust the type as needed
    isoCode: string;
    name: string;
}

export interface SaveExistingTableDataType {
    countryFeeList: CountryList[];
    customCountryFeeList: CountryList[];
    upFee: CountryList[] | [];
    nonupFee: CountryList[] | [];
    languageFeeList: CountryList[];
}
