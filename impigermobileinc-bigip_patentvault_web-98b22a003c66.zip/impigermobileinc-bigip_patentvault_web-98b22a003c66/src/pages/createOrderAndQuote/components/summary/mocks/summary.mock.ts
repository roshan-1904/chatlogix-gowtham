import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';

// summary Page updated store data (full)
const updatedCompleteStoreInfo: QuoteOrderModuleStore = {
    info: {
        mode: 1,
        selectedService: {
            name: 'patent_cooperation_treaty',
            displayText: 'Patent Cooperation Treaty',
            displayOrder: 1,
            serviceTypeId: 1,
            patentType: 1,
            requestType: 1,
            isRequestEntity: null,
            imageIcon: 'i-Note-icon',
            patentCategories: [
                {
                    parentId: 1,
                    patentCategoryName: 'translation_only',
                    patentCategoryId: 6,
                    patentCategoryDisplay: 'Translation',
                    patentCategoryDisplayOrder: 1,
                    patentCategoryIsRequestEntity: false
                },
                {
                    parentId: 1,
                    patentCategoryName: 'translation_&_filing',
                    patentCategoryId: 7,
                    patentCategoryDisplay: 'Translation & Filing',
                    patentCategoryDisplayOrder: 2,
                    patentCategoryIsRequestEntity: true
                },
                {
                    parentId: 1,
                    patentCategoryName: 'recordal',
                    patentCategoryId: 9,
                    patentCategoryDisplay: 'Recordals',
                    patentCategoryDisplayOrder: 4,
                    patentCategoryIsRequestEntity: true
                },
                {
                    parentId: 1,
                    patentCategoryName: 'annuities',
                    patentCategoryId: 10,
                    patentCategoryDisplay: 'Annuities',
                    patentCategoryDisplayOrder: 5,
                    patentCategoryIsRequestEntity: true
                }
            ],
            id: 0,
            createdBy: null,
            createdAt: '0001-01-01T00:00:00',
            updatedBy: null,
            updatedAt: null,
            isActive: false
        },
        selectedCategory: {
            parentId: 1,
            patentCategoryName: 'translation_&_filing',
            patentCategoryId: 7,
            patentCategoryDisplay: 'Translation & Filing',
            patentCategoryDisplayOrder: 2,
            patentCategoryIsRequestEntity: true
        },
        primaryId: 9519,
        requestCurrencyId: 2,
        requestNumber: 'R240916-3',
        documentId: null,
        isEditFlow: true,
        isSTDFlow: true,
        isUP: null,
        approveStatus: 1,
        statusId: 2,
        quoteStatus: 2
    },
    flags: {
        storeUpdateWithSummaryData: null,
        isCountriesSyncedCompletedInEditMode: true,
        isSummaryPageTablesInlineEditInProgress: false,
        pagesMatchStatusWithBackupData: {
            isCompanyModified: false,
            isLanguagesModified: false,
            isCountsModified: false,
            isCountriesModified: true
        }
    },
    isFormValid: {
        'service-type': true,
        'company-details': false,
        'additional-info': true,
        'patent-details': false,
        'select-country': true,
        'file-upload': true,
        summary: true,
        'order-quote-details': null,
        'language-selection': true
    },
    formData: {
        serviceTypePage: {
            serviceType: [
                {
                    name: 'patent_cooperation_treaty',
                    displayText: 'Patent Cooperation Treaty',
                    displayOrder: 1,
                    serviceTypeId: 1,
                    patentType: 1,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-Note-icon',

                    patentCategories: [
                        {
                            parentId: 1,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 6,
                            patentCategoryDisplay: 'Translation',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: false
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'translation_&_filing',
                            patentCategoryId: 7,
                            patentCategoryDisplay: 'Translation & Filing',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'recordal',
                            patentCategoryId: 9,
                            patentCategoryDisplay: 'Recordals',
                            patentCategoryDisplayOrder: 4,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'annuities',
                            patentCategoryId: 10,
                            patentCategoryDisplay: 'Annuities',
                            patentCategoryDisplayOrder: 5,
                            patentCategoryIsRequestEntity: true
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'european_patent',
                    displayText: 'European Grant and Validations',
                    displayOrder: 2,
                    serviceTypeId: 2,
                    patentType: 2,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-write-icon',

                    patentCategories: [
                        {
                            parentId: 2,
                            patentCategoryName: '71_3_claims',
                            patentCategoryId: 11,
                            patentCategoryDisplay: '71(3) Claims',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 12,
                            patentCategoryDisplay: '71(3) Claims and Translation (EP,UP)',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: false
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'translation_&_validation',
                            patentCategoryId: 13,
                            patentCategoryDisplay:
                                '71(3) Claims and Translation & Validation/Filing (EP,UP)',
                            patentCategoryDisplayOrder: 3,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'recordal',
                            patentCategoryId: 15,
                            patentCategoryDisplay: 'Recordals (EP)',
                            patentCategoryDisplayOrder: 5,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'Renewals',
                            patentCategoryId: 16,
                            patentCategoryDisplay: 'Renewals (EP,UP)',
                            patentCategoryDisplayOrder: 6,
                            patentCategoryIsRequestEntity: true
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'paris_convention_treaty',
                    displayText: 'Paris Convention Treaty',
                    displayOrder: 3,
                    serviceTypeId: 3,
                    patentType: 3,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-book-icon',

                    patentCategories: [
                        {
                            parentId: 3,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 17,
                            patentCategoryDisplay: 'Translation',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true
                        },
                        {
                            parentId: 3,
                            patentCategoryName: 'translation_&_filing',
                            patentCategoryId: 18,
                            patentCategoryDisplay: 'Translation & Filing ',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: true
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'other_translations',
                    displayText: 'Other',
                    displayOrder: 5,
                    serviceTypeId: 5,
                    patentType: 4,
                    requestType: 0,
                    isRequestEntity: null,
                    imageIcon: 'i-other-icon',

                    patentCategories: [
                        {
                            parentId: 5,
                            patentCategoryName: 'patent_non_filing',
                            patentCategoryId: 24,
                            patentCategoryDisplay: 'Patent Non-Filing',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                }
            ],
            selectedServiceDetails: {
                serviceTypeId: 1,
                patentCategoryDisplay: 'Translation & Filing'
            }
        },
        companyDetailsPage: {
            companyList: [
                {
                    id: 647,
                    name: 'ABC child1',
                    companyType: 1,
                    parentCompanyId: null,
                    salesRep: null,
                    salesRepName: null,
                    requestCurrencyId: 1,
                    isPoRequired: false
                },
                {
                    id: 40,
                    name: 'ABC Technologies',
                    companyType: 0,
                    parentCompanyId: null,
                    salesRep: 18,
                    salesRepName: null,
                    requestCurrencyId: 2,
                    isPoRequired: true
                },
                {
                    id: 747,
                    name: 'ABC Test Ltd',
                    companyType: 0,
                    parentCompanyId: null,
                    salesRep: null,
                    salesRepName: null,
                    requestCurrencyId: 2,
                    isPoRequired: false
                }
            ],
            selectedCompany: {
                id: 40,
                name: 'ABC Technologies',
                companyType: 0,
                parentCompanyId: null,
                salesRep: 18,
                salesRepName: null,
                requestCurrencyId: 2,
                isPoRequired: true
            },
            selectedContact: {
                id: 70,
                firstName: 'CUSER 1',
                lastName: '',
                middleName: '',
                fullName: 'CUSER 1  ',
                roleId: 6,
                email: 'cuser1@gmail.com',
                salesRepName: '',
                salesRepId: 0,
                contactInformation: null
            },
            contactUserList: [
                {
                    id: 70,
                    firstName: 'CUSER 1',
                    lastName: '',
                    middleName: '',
                    fullName: 'CUSER 1  ',
                    roleId: 6,
                    email: 'cuser1@gmail.com',
                    salesRepName: '',
                    salesRepId: 0,
                    contactInformation: null
                },
                {
                    id: 72,
                    firstName: 'CUSER 3',
                    lastName: '',
                    middleName: '',
                    fullName: 'CUSER 3  ',
                    roleId: 6,
                    email: 'cuser3@gmail.com',
                    salesRepName: 'fhkklkllllll  test name',
                    salesRepId: 185,
                    contactInformation: null
                },
                {
                    id: 77,
                    firstName: 'CM 3',
                    lastName: '',
                    middleName: '',
                    fullName: 'CM 3  ',
                    roleId: 5,
                    email: 'cm3@gmail.com',
                    salesRepName: '',
                    salesRepId: 0,
                    contactInformation: null
                }
            ],
            publicationNumber: 'WO/2008/000014',
            patentDetails: {
                title: 'GUIDE VANE ARRANGEMENT FOR A DRIVING MECHANISM',
                pctReference: 'PCT/AT2007/000325',
                patentPublicationNumber: 'WO/2008/000014',
                patentApplicationNumber: 'PCT/AT2007/000325',
                upDeadLine: '',
                referenceNo: '',
                applicantName: 'FACC AG',
                sourceLanguage: 'DE',
                sourceLanguageName: 'German',
                textthirtyMonthsDeadline: '2008-12-30',
                validationDeadline: '',
                kind: '',
                abstractWordCount: 188,
                drawingsWordCount: 0,
                descriptionWordCount: 1971,
                numberOfDrawings: 0,
                claimsWordCount: 524,
                drawingsPageCount: 0,
                specificationWordCount: 0,
                numberOfPriorityClaims: 1,
                numberOfClaims: 17,
                descriptionPageCount: 0,
                claimsPageCount: 0,
                estTotalPages: 1,
                numberOfIndependentClaims: 0,
                originalAbstractWordCount: 188,
                originalDrawingsWordCount: 0,
                originalDescriptionWordCount: 1971,
                originalNumberOfDrawings: 0,
                originalClaimsWordCount: 524,
                originalDrawingsPageCount: 0,
                originalSpecificationWordCount: 0,
                originalNumberOfPriorityClaims: 0,
                originalNumberOfClaims: 17,
                originalClaimsPageCount: 0,
                originalNumberOfIndependentClaims: 0,
                originalEstTotalPages: 1,
                applicationClaimsPriority: 2,
                filingDeadLine: '',
                requestedFilingDeadLine: '',
                requestedById: '95',
                requestedByName: 'Gopikrishna Saravana',
                salesRepId: 0,
                salesRepName: '',
                companyName: {
                    id: 40,
                    name: 'ABC Technologies',
                    companyType: 0,
                    parentCompanyId: null,
                    salesRep: 18,
                    salesRepName: null,
                    requestCurrencyId: 2,
                    isPoRequired: true
                },
                contactUser: {
                    id: 70,
                    firstName: 'CUSER 1',
                    lastName: '',
                    middleName: '',
                    fullName: 'CUSER 1  ',
                    roleId: 6,
                    email: 'cuser1@gmail.com',
                    salesRepName: '',
                    salesRepId: 0,
                    contactInformation: null
                }
            },
            isFormSubmitting: true,
            formData: {
                companyName: {
                    isReadonly: true,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                contactUser: {
                    isShow: true,
                    isReadonly: true,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                publicationNumber: {
                    isReadonly: true,
                    isError: false
                },
                patentDetails: {
                    isShow: false,
                    dataNotFoundForPatent: false
                },
                isDuplicate: {
                    isError: false
                }
            }
        },
        additionalInfoPage: {
            emailID: '',
            deliverTo: [''],
            cc: '',
            instructionByContactUser: '',
            role: 1,
            mode: 1,
            selectedCompanyPoRequired: true,
            selectedCompanyId: 40,
            submit: true,
            po: '123',
            quoteDateTime: null,
            targetDateTime: '2024-09-17T00:00:00',
            instructionByProjectManager: '',
            projectManager: [4, 12],
            quoteRequired: true,
            salesRep: null,
            selectedCategoryId: 7
        },
        patentDetailsPage: {
            referenceNo: '',
            applicationClaimsPriority: 2,
            ifEpGrantedYesNo: false,
            selectedCategoryId: 7,
            mode: 1,
            roleId: 1,
            sourceLanguageFlag: 'DE',
            flow: 2,
            quoteStatus: 2,
            submit: true,
            companyName: 40,
            salesRepId: 0,
            salesRepName: '',
            contactUser: {
                id: 70,
                firstName: 'CUSER 1',
                lastName: '',
                middleName: '',
                fullName: 'CUSER 1  ',
                roleId: 6,
                email: 'cuser1@gmail.com',
                salesRepName: '',
                salesRepId: 0,
                contactInformation: null
            },
            requestedBy: 'Test  Admin 1',
            applicantName: 'FACC AG',
            sourceLanguage: 'DE',
            abstractWordCount: 188,
            originalAbstractWordCount: 188,
            drawingsWordCount: 0,
            originalDrawingsWordCount: 0,
            descriptionWordCount: 1971,
            originalDescriptionWordCount: 1971,
            numberOfDrawings: 0,
            originalNumberOfDrawings: 0,
            claimsWordCount: 524,
            originalClaimsWordCount: 524,
            drawingsPageCount: 0,
            originalDrawingsPageCount: 0,
            specificationWordCount: 0,
            originalSpecificationWordCount: 0,
            numberOfPriorityClaims: 1,
            originalNumberOfPriorityClaims: 0,
            numberOfClaims: 17,
            originalNumberOfClaims: 17,
            descriptionPageCount: 0,
            originalDescriptionPageCount: 0,
            claimsPageCount: 0,
            originalClaimsPageCount: 0,
            numberOfIndependentClaims: 0,
            originalNumberOfIndependentClaims: 0,
            estTotalPages: 1,
            originalEstTotalPages: 1,
            estimatedSequenceListing: 2,
            specialInstructions: null,
            english: false,
            german: false,
            french: false,
            title: 'GUIDE VANE ARRANGEMENT FOR A DRIVING MECHANISM',
            pctReference: 'PCT/AT2007/000325',
            patentPublicationNumber: 'WO/2008/000014',
            patentApplicationNumber: 'PCT/AT2007/000325',
            upDeadLine: null,
            requestedDeliveryDate: null,
            applicantId: 0,
            sourceLanguageId: 59,
            sourceLanguageName: 'German',
            textthirtyMonthsDeadline: '2008-12-30',
            validationDeadline: null,
            kind: null,
            europeanFilingDate: null,
            requestedDeliveryDateForClaimsTranslation: null,
            statutoryDeadline: null,
            claimsPriority: null,
            filingDeadLine: '',
            requestedFilingDeadLine: '',
            requestedById: 95,
            requestedByName: 'Gopikrishna Saravana',
            publicationNumber: 'WO/2008/000014',
            statutoryDeadlineDate: null,
            selectedCompanyPoRequired: true
        },
        selectCountryPage: {
            instantCountries: [
                {
                    isSelected: true,
                    isUpSelected: false,
                    selectedWipoEntityId: 0,
                    data: {
                        id: 2,
                        name: 'ARIPO',
                        code: 'AP',
                        iconName: 'ARIPO.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'ARIPO (AP)'
                    }
                },
                {
                    isSelected: true,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 1,
                        name: 'Algeria',
                        code: 'DZ',
                        iconName: '126-algeria.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: 0,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Algeria (DZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 3,
                        name: 'Australia',
                        code: 'AU',
                        iconName: '130-australia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: 0,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Australia (AU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 46,
                        name: 'Austria',
                        code: 'AT',
                        iconName: '189-austria.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: 0,
                        languageId: 59,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Austria (AT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 4,
                        name: 'Bahrain',
                        code: 'BH',
                        iconName: '116-bahrain.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: 0,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bahrain (BH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 5,
                        name: 'Brazil',
                        code: 'BR',
                        iconName: '250-brazil.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 110,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Brazil (BR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 6,
                        name: 'Cambodia',
                        code: 'KH',
                        iconName: '132-cambodia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 79,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cambodia (KH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 7,
                        name: 'Canada',
                        code: 'CA',
                        iconName: '206-canada.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [1, 2],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Canada (CA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 8,
                        name: 'Chile',
                        code: 'CL',
                        iconName: '051-chile.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Chile (CL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 9,
                        name: 'China',
                        code: 'CN',
                        iconName: '261-china.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 21,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'China (CN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 10,
                        name: 'Colombia',
                        code: 'CO',
                        iconName: '062-colombia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Colombia (CO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 59,
                        name: 'Denmark',
                        code: 'DK',
                        iconName: '072-denmark.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 30,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Denmark (DK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 11,
                        name: 'Ecuador',
                        code: 'EC',
                        iconName: '049-ecuador.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Ecuador (EC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 12,
                        name: 'Egypt',
                        code: 'EG',
                        iconName: '079-egypt.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Egypt (EG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 13,
                        name: 'Eurasia',
                        code: 'EA',
                        iconName: 'Eurasia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Eurasia (EA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 14,
                        name: 'Europe',
                        code: 'EP',
                        iconName: '022-european-union.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Europe (EP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 64,
                        name: 'Finland',
                        code: 'FI',
                        iconName: '052-finland.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 49,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Finland (FI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 15,
                        name: 'Germany',
                        code: 'DE',
                        iconName: '066-germany.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 59,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Germany (DE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 16,
                        name: 'India',
                        code: 'IN',
                        iconName: '217-india.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [1, 2],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'India (IN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 17,
                        name: 'Indonesia',
                        code: 'ID',
                        iconName: '078-indonesia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 69,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Indonesia (ID)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 18,
                        name: 'Israel',
                        code: 'IL',
                        iconName: '060-israel.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Israel (IL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 72,
                        name: 'Italy',
                        code: 'IT',
                        iconName: '011-italy.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 71,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Italy (IT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 19,
                        name: 'Japan',
                        code: 'JP',
                        iconName: '033-japan.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 72,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Japan (JP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 73,
                        name: 'Jordan',
                        code: 'JO',
                        iconName: '042-jordan.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Jordan (JO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 20,
                        name: 'Korea',
                        code: 'KR',
                        iconName: '037-north-korea.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 81,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Korea (KR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 21,
                        name: 'Kuwait',
                        code: 'KW',
                        iconName: '178-kuwait.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kuwait (KW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 22,
                        name: 'Laos',
                        code: 'LA',
                        iconName: '069-laos.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 84,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Laos (LA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 79,
                        name: 'Libya',
                        code: 'LY',
                        iconName: '225-libya.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Libya (LY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 23,
                        name: 'Malaysia',
                        code: 'MY',
                        iconName: '056-malaysia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Malaysia (MY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 24,
                        name: 'Mexico',
                        code: 'MX',
                        iconName: '239-mexico.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mexico (MX)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 25,
                        name: 'Morocco',
                        code: 'MA',
                        iconName: '086-morocco.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Morocco (MA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 26,
                        name: 'New Zealand',
                        code: 'NZ',
                        iconName: '048-new-zealand.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'New Zealand (NZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 91,
                        name: 'Norway',
                        code: 'NO',
                        iconName: '058-norway.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 99,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Norway (NO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 27,
                        name: 'OAPI',
                        code: 'OA',
                        iconName: 'OAPI.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'OAPI (OA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 28,
                        name: 'Oman',
                        code: 'OM',
                        iconName: '002-oman.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Oman (OM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 29,
                        name: 'Peru',
                        code: 'PE',
                        iconName: '074-peru.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Peru (PE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 30,
                        name: 'Philippines',
                        code: 'PH',
                        iconName: '076-philippines.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Philippines (PH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 31,
                        name: 'Qatar',
                        code: 'QA',
                        iconName: '019-qatar.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Qatar (QA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 32,
                        name: 'Russia',
                        code: 'RU',
                        iconName: '228-russia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Russia (RU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 33,
                        name: 'Saudi Arabia',
                        code: 'SA',
                        iconName: '059-saudi-arabia.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saudi Arabia (SA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 34,
                        name: 'Singapore',
                        code: 'SG',
                        iconName: '141-singapore.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Singapore (SG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 36,
                        name: 'South Africa',
                        code: 'ZA',
                        iconName: '075-south-africa.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'South Africa (ZA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 106,
                        name: 'Spain',
                        code: 'ES',
                        iconName: '044-spain.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 130,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Spain (ES)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 109,
                        name: 'Sweden',
                        code: 'SE',
                        iconName: '073-sweden.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 133,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sweden (SE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 37,
                        name: 'Thailand',
                        code: 'TH',
                        iconName: '184-thailand.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 138,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Thailand (TH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 39,
                        name: 'Ukraine',
                        code: 'UA',
                        iconName: '065-ukraine.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 142,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Ukraine (UA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 38,
                        name: 'United Arab Emirates (UAE)',
                        code: 'AE',
                        iconName: '068-united-arab-emirates.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'United Arab Emirates (UAE) (AE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 118,
                        name: 'United Kingdom',
                        code: 'GB',
                        iconName: '262-united-kingdom.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'United Kingdom (GB)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 40,
                        name: 'United States',
                        code: 'US',
                        iconName: '153-united-states-of-america.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [1, 2],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'United States (US)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    selectedWipoEntityId: null,
                    data: {
                        id: 41,
                        name: 'Vietnam',
                        code: 'VN',
                        iconName: '164-vietnam.svg',
                        wipoIq: 1,
                        up: null,
                        pcIq: null,
                        languageId: 145,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Vietnam (VN)'
                    }
                }
            ],
            customCountries: [
                {
                    isSelected: true,
                    isUpSelected: false,
                    data: {
                        id: 138,
                        name: 'Afghanistan',
                        code: 'AF',
                        iconName: '122-afghanistan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 104,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Afghanistan (AF)'
                    },
                    selectedWipoEntityId: 0
                },
                {
                    isSelected: true,
                    isUpSelected: false,
                    data: {
                        id: 197,
                        name: 'Aland Islands',
                        code: 'AX',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Aland Islands (AX)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 42,
                        name: 'Albania',
                        code: 'AL',
                        iconName: '117-albania.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 2,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Albania (AL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 195,
                        name: 'American Samoa',
                        code: 'AS',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'American Samoa (AS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 137,
                        name: 'Andorra',
                        code: 'AD',
                        iconName: '102-andorra.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 18,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Andorra (AD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 43,
                        name: 'Angola',
                        code: 'AO',
                        iconName: '124-angola.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 109,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Angola (AO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 192,
                        name: 'Anguilla',
                        code: 'AI',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Anguilla (AI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 194,
                        name: 'Antarctica',
                        code: 'AQ',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Antarctica (AQ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 44,
                        name: 'Antigua and Barbuda',
                        code: 'AG',
                        iconName: '104-antigua-and-barbuda.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Antigua and Barbuda (AG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 128,
                        name: 'Argentina',
                        code: 'AR',
                        iconName: '064-argentina.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Argentina (AR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 45,
                        name: 'Armenia',
                        code: 'AM',
                        iconName: '121-armenia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 6,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Armenia (AM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 196,
                        name: 'Aruba',
                        code: 'AW',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Aruba (AW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 47,
                        name: 'Azerbaijan',
                        code: 'AZ',
                        iconName: '125-azerbaijan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 7,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Azerbaijan (AZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 144,
                        name: 'Bahamas',
                        code: 'BS',
                        iconName: '194-bahamas.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bahamas (BS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 129,
                        name: 'Bangladesh',
                        code: 'BD',
                        iconName: '128-bangladesh.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bangladesh (BD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 48,
                        name: 'Barbados',
                        code: 'BB',
                        iconName: '111-barbados.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Barbados (BB)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 49,
                        name: 'Belarus',
                        code: 'BY',
                        iconName: '110-belarus.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Belarus (BY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 139,
                        name: 'Belgium',
                        code: 'BE',
                        iconName: '054-belgium.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Belgium (BE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 50,
                        name: 'Belize',
                        code: 'BZ',
                        iconName: '115-belize.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Belize (BZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 142,
                        name: 'Benin',
                        code: 'BJ',
                        iconName: '098-benin.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Benin (BJ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 199,
                        name: 'Bermuda',
                        code: 'BM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bermuda (BM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 145,
                        name: 'Bhutan',
                        code: 'BT',
                        iconName: '094-bhutan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bhutan (BT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 143,
                        name: 'Bolivia',
                        code: 'BO',
                        iconName: '133-bolivia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 125,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bolivia (BO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 200,
                        name: 'Bonaire, Sint Eustatius and Saba',
                        code: 'BQ',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bonaire, Sint Eustatius and Saba (BQ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 51,
                        name: 'Bosnia & Herzegovina',
                        code: 'BA',
                        iconName: '113-bosnia-and-herzegovina.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 151,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bosnia & Herzegovina (BA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 52,
                        name: 'Botswana',
                        code: 'BW',
                        iconName: '127-botswana.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Botswana (BW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 201,
                        name: 'Bouvet Island',
                        code: 'BV',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bouvet Island (BV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 223,
                        name: 'British Indian Ocean Territory',
                        code: 'IO',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'British Indian Ocean Territory (IO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 53,
                        name: 'Brunei Darussalam',
                        code: 'BN',
                        iconName: '107-brunei.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 89,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Brunei Darussalam (BN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 54,
                        name: 'Bulgaria',
                        code: 'BG',
                        iconName: '135-bulgaria.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 15,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Bulgaria (BG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 140,
                        name: 'Burkina Faso',
                        code: 'BF',
                        iconName: '118-burkina-faso.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Burkina Faso (BF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 141,
                        name: 'Burundi',
                        code: 'BI',
                        iconName: '103-burundi.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Burundi (BI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 204,
                        name: 'Cabo Verde',
                        code: 'CV',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cabo Verde (CV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 150,
                        name: 'Cameroon',
                        code: 'CM',
                        iconName: '106-cameroon.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cameroon (CM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 226,
                        name: 'Cayman Islands',
                        code: 'KY',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cayman Islands (KY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 147,
                        name: 'Central African Republic',
                        code: 'CF',
                        iconName: '091-central-african-republic.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Central African Republic (CF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 188,
                        name: 'Chad',
                        code: 'TD',
                        iconName: '095-chad.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Chad (TD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 206,
                        name: 'Christmas Island',
                        code: 'CX',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Christmas Island (CX)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 202,
                        name: 'Cocos (Keeling) Islands',
                        code: 'CC',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cocos (Keeling) Islands (CC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 166,
                        name: 'Comoros',
                        code: 'KM',
                        iconName: '090-comoros.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Comoros (KM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 148,
                        name: 'Congo',
                        code: 'CG',
                        iconName: '240-republic-of-the-congo.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Congo (CG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 203,
                        name: 'Cook Islands',
                        code: 'CK',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cook Islands (CK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 55,
                        name: 'Costa Rica',
                        code: 'CR',
                        iconName: '131-costa-rica.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Costa Rica (CR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 56,
                        name: 'Croatia',
                        code: 'HR',
                        iconName: '134-croatia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 27,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Croatia (HR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 57,
                        name: 'Cuba',
                        code: 'CU',
                        iconName: '129-cuba.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cuba (CU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 205,
                        name: 'Curaçao',
                        code: 'CW',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Curaçao (CW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 151,
                        name: 'Cyprus',
                        code: 'CY',
                        iconName: '030-cyprus.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 60,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Cyprus (CY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 58,
                        name: 'Czech Republic',
                        code: 'CZ',
                        iconName: '061-czech-republic.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 28,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Czech Republic (CZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 149,
                        name: 'Côte d’Ivoire',
                        code: 'CI',
                        iconName: '245-ivory-coast.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Côte d’Ivoire (CI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 167,
                        name: 'Democratic People’s Republic of Korea',
                        code: 'KP',
                        iconName: 'Not Found',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 81,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Democratic People’s Republic of Korea (KP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 146,
                        name: 'Democratic Republic of the Congo',
                        code: 'CD',
                        iconName: '258-democratic-republic-of-congo.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Democratic Republic of the Congo (CD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 60,
                        name: 'Djibouti',
                        code: 'DJ',
                        iconName: '211-djibouti.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Djibouti (DJ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 61,
                        name: 'Dominica',
                        code: 'DM',
                        iconName: '018-dominican-republic.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Dominica (DM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 122,
                        name: 'Dominican Republic',
                        code: 'DO',
                        iconName: '018-dominican-republic.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Dominican Republic (DO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 130,
                        name: 'EPO',
                        code: 'EP',
                        iconName: 'EPO.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'EPO (EP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 62,
                        name: 'El Salvador',
                        code: 'SV',
                        iconName: '015-el-salvador.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'El Salvador (SV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 156,
                        name: 'Equatorial Guinea',
                        code: 'GQ',
                        iconName: '241-equatorial-guinea.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Equatorial Guinea (GQ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 208,
                        name: 'Eritrea',
                        code: 'ER',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Eritrea (ER)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 63,
                        name: 'Estonia',
                        code: 'EE',
                        iconName: '257-estonia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 43,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Estonia (EE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 187,
                        name: 'Eswatini',
                        code: 'SZ',
                        iconName: 'Royal_Standard_of_Eswatini.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Eswatini (SZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 209,
                        name: 'Ethiopia',
                        code: 'ET',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Ethiopia (ET)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 211,
                        name: 'Falkland Islands (Malvinas)',
                        code: 'FK',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Falkland Islands (Malvinas) (FK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 213,
                        name: 'Faroe Islands',
                        code: 'FO',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Faroe Islands (FO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 210,
                        name: 'Fiji',
                        code: 'FJ',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Fiji (FJ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 131,
                        name: 'France',
                        code: 'FR',
                        iconName: '077-france.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'France (FR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 214,
                        name: 'French Guiana',
                        code: 'GF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'French Guiana (GF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 238,
                        name: 'French Polynesia',
                        code: 'PF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'French Polynesia (PF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 252,
                        name: 'French Southern Territories',
                        code: 'TF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'French Southern Territories (TF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 65,
                        name: 'Gabon',
                        code: 'GA',
                        iconName: '186-gabon.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Gabon (GA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 153,
                        name: 'Gambia',
                        code: 'GM',
                        iconName: '159-gambia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Gambia (GM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 66,
                        name: 'Georgia',
                        code: 'GE',
                        iconName: '256-georgia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 58,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Georgia (GE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 67,
                        name: 'Ghana',
                        code: 'GH',
                        iconName: '255-ghana.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Ghana (GH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 216,
                        name: 'Gibraltar',
                        code: 'GI',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Gibraltar (GI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 157,
                        name: 'Greece',
                        code: 'GR',
                        iconName: '071-greece.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 60,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Greece (GR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 217,
                        name: 'Greenland',
                        code: 'GL',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Greenland (GL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 68,
                        name: 'Grenada',
                        code: 'GD',
                        iconName: '182-grenada.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Grenada (GD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 218,
                        name: 'Guadeloupe',
                        code: 'GP',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guadeloupe (GP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 220,
                        name: 'Guam',
                        code: 'GU',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guam (GU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 123,
                        name: 'Guatemala',
                        code: 'GT',
                        iconName: '040-guatemala.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guatemala (GT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 215,
                        name: 'Guernsey',
                        code: 'GG',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guernsey (GG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 154,
                        name: 'Guinea',
                        code: 'GN',
                        iconName: '154-guinea.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guinea (GN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 159,
                        name: 'Guinea–Bissau',
                        code: 'GW',
                        iconName: '209-guinea-bissau.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guinea–Bissau (GW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 160,
                        name: 'Guyana',
                        code: 'GY',
                        iconName: 'Flag_of_Guyana.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Guyana (GY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 161,
                        name: 'Haiti',
                        code: 'HT',
                        iconName: '247-haiti.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Haiti (HT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 221,
                        name: 'Heard Is. & Mcdonald Islands',
                        code: 'HM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Heard Is. & Mcdonald Islands (HM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 190,
                        name: 'Holy See',
                        code: 'VA',
                        iconName: 'Emblem_Holy_See.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Holy See (VA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 69,
                        name: 'Honduras',
                        code: 'HN',
                        iconName: '027-honduras.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Honduras (HN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 124,
                        name: 'Hong Kong',
                        code: 'HK',
                        iconName: '067-hong-kong.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Hong Kong (HK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 70,
                        name: 'Hungary',
                        code: 'HU',
                        iconName: '053-hungary.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 67,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Hungary (HU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 164,
                        name: 'Iceland',
                        code: 'IS',
                        iconName: '041-iceland.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 68,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Iceland (IS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 71,
                        name: 'Iran',
                        code: 'IR',
                        iconName: '063-iran.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 46,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Iran (IR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 163,
                        name: 'Iraq',
                        code: 'IQ',
                        iconName: '007-iraq.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Iraq (IQ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 162,
                        name: 'Ireland',
                        code: 'IE',
                        iconName: '070-ireland.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Ireland (IE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 222,
                        name: 'Isle of Man',
                        code: 'IM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Isle of Man (IM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 165,
                        name: 'Jamaica',
                        code: 'JM',
                        iconName: '026-jamaica.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Jamaica (JM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 224,
                        name: 'Jersey',
                        code: 'JE',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Jersey (JE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 74,
                        name: 'Kazakhstan',
                        code: 'KZ',
                        iconName: '034-kazakhstan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kazakhstan (KZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 75,
                        name: 'Kenya',
                        code: 'KE',
                        iconName: '029-kenya.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kenya (KE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 225,
                        name: 'Kiribati',
                        code: 'KI',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kiribati (KI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 262,
                        name: 'Kosovo',
                        code: 'XK',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kosovo (XK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 76,
                        name: 'Kyrgyzstan',
                        code: 'KG',
                        iconName: '208-kyrgyzstan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Kyrgyzstan (KG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 171,
                        name: 'Latvia',
                        code: 'LV',
                        iconName: '032-latvia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 86,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Latvia (LV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 132,
                        name: 'Lebanon',
                        code: 'LB',
                        iconName: '008-lebanon.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Lebanon (LB)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 77,
                        name: 'Lesotho',
                        code: 'LS',
                        iconName: '244-lesotho.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Lesotho (LS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 78,
                        name: 'Liberia',
                        code: 'LR',
                        iconName: '218-liberia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Liberia (LR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 169,
                        name: 'Liechtenstein',
                        code: 'LI',
                        iconName: '216-liechtenstein.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Liechtenstein (LI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 170,
                        name: 'Lithuania',
                        code: 'LT',
                        iconName: '025-lithuania.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 87,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Lithuania (LT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 80,
                        name: 'Luxembourg',
                        code: 'LU',
                        iconName: '023-luxembourg.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Luxembourg (LU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 174,
                        name: 'Macao, China',
                        code: 'MO',
                        iconName: '144-macao.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 21,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Macao, China (MO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 82,
                        name: 'Madagascar',
                        code: 'MG',
                        iconName: '253-madagascar.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Madagascar (MG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 83,
                        name: 'Malawi',
                        code: 'MW',
                        iconName: '252-malawi.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Malawi (MW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 233,
                        name: 'Maldives',
                        code: 'MV',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Maldives (MV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 173,
                        name: 'Mali',
                        code: 'ML',
                        iconName: '162-somaliland.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mali (ML)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 176,
                        name: 'Malta',
                        code: 'MT',
                        iconName: '012-malta.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Malta (MT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 228,
                        name: 'Marshall Islands',
                        code: 'MH',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Marshall Islands (MH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 231,
                        name: 'Martinique',
                        code: 'MQ',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Martinique (MQ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 175,
                        name: 'Mauritania',
                        code: 'MR',
                        iconName: '177-mauritania.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mauritania (MR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 177,
                        name: 'Mauritius',
                        code: 'MU',
                        iconName: '021-mauritius.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mauritius (MU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 263,
                        name: 'Mayotte',
                        code: 'YT',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mayotte (YT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 212,
                        name: 'Micronesia',
                        code: 'FM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Micronesia (FM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 172,
                        name: 'Monaco',
                        code: 'MC',
                        iconName: '043-monaco.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Monaco (MC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 85,
                        name: 'Mongolia',
                        code: 'MN',
                        iconName: '251-mongolia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 94,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mongolia (MN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 86,
                        name: 'Montenegro',
                        code: 'ME',
                        iconName: '230-montenegro.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 151,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Montenegro (ME)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 232,
                        name: 'Montserrat',
                        code: 'MS',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Montserrat (MS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 87,
                        name: 'Mozambique',
                        code: 'MZ',
                        iconName: '006-mozambique.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 109,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Mozambique (MZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 229,
                        name: 'Myanmar',
                        code: 'MM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Myanmar (MM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 88,
                        name: 'Namibia',
                        code: 'NA',
                        iconName: '020-namibia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Namibia (NA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 236,
                        name: 'Nauru',
                        code: 'NR',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Nauru (NR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 180,
                        name: 'Nepal',
                        code: 'NP',
                        iconName: '249-nepal.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Nepal (NP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 179,
                        name: 'Netherlands',
                        code: 'NL',
                        iconName: '195-netherlands.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 34,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Netherlands (NL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 193,
                        name: 'Netherlands Antilles',
                        code: 'AN',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 34,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Netherlands Antilles (AN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 234,
                        name: 'New Caledonia',
                        code: 'NC',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'New Caledonia (NC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 89,
                        name: 'Nicaragua',
                        code: 'NI',
                        iconName: '014-nicaragua.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 125,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Nicaragua (NI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 178,
                        name: 'Niger',
                        code: 'NE',
                        iconName: '010-nigeria.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Niger (NE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 90,
                        name: 'Nigeria',
                        code: 'NG',
                        iconName: '010-nigeria.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Nigeria (NG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 237,
                        name: 'Niue',
                        code: 'NU',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Niue (NU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 235,
                        name: 'Norfolk Island',
                        code: 'NF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Norfolk Island (NF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 81,
                        name: 'North Macedonia',
                        code: 'MK',
                        iconName: '223-republic-of-macedonia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 152,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'North Macedonia (MK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 230,
                        name: 'Northern Mariana Islands',
                        code: 'MP',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Northern Mariana Islands (MP)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 133,
                        name: 'Pakistan',
                        code: 'PK',
                        iconName: '031-pakistan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Pakistan (PK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 243,
                        name: 'Palau',
                        code: 'PW',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Palau (PW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 242,
                        name: 'Palestinian Territory, Occupied',
                        code: 'PS',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Palestinian Territory, Occupied (PS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 126,
                        name: 'Panama',
                        code: 'PA',
                        iconName: '047-panama.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 127,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Panama (PA)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 92,
                        name: 'Papua New Guinea',
                        code: 'PG',
                        iconName: '229-papua-new-guinea.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Papua New Guinea (PG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 182,
                        name: 'Paraguay',
                        code: 'PY',
                        iconName: '260-paraguay.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Paraguay (PY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 240,
                        name: 'Pitcairn',
                        code: 'PN',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Pitcairn (PN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 93,
                        name: 'Poland',
                        code: 'PL',
                        iconName: '108-poland.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 108,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Poland (PL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 94,
                        name: 'Portugal',
                        code: 'PT',
                        iconName: '174-portugal.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 111,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Portugal (PT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 241,
                        name: 'Puerto Rico',
                        code: 'PR',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Puerto Rico (PR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 84,
                        name: 'Republic of Moldova',
                        code: 'MD',
                        iconName: '231-moldova.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Republic of Moldova (MD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 244,
                        name: 'Reunion',
                        code: 'RE',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Reunion (RE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 95,
                        name: 'Romania',
                        code: 'RO',
                        iconName: '050-romania.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Romania (RO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 96,
                        name: 'Rwanda',
                        code: 'RW',
                        iconName: '243-rwanda.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 51,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Rwanda (RW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 219,
                        name: 'S.Georgia & S.Sandwich Is',
                        code: 'GS',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 58,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'S.Georgia & S.Sandwich Is (GS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 198,
                        name: 'Saint Barthelemy',
                        code: 'BL',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Barthelemy (BL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 246,
                        name: 'Saint Helena',
                        code: 'SH',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Helena (SH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 97,
                        name: 'Saint Kitts and Nevis',
                        code: 'KN',
                        iconName: '167-saint-kitts-and-nevis.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Kitts and Nevis (KN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 98,
                        name: 'Saint Lucia',
                        code: 'LC',
                        iconName: '139-st-lucia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Lucia (LC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 227,
                        name: 'Saint Martin',
                        code: 'MF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Martin (MF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 239,
                        name: 'Saint Pierre and Miquelon',
                        code: 'PM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Pierre and Miquelon (PM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 99,
                        name: 'Saint Vincent and the Grenadines',
                        code: 'VC',
                        iconName: '160-st-vincent-and-the-grenadines.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Saint Vincent and the Grenadines (VC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 100,
                        name: 'Samoa',
                        code: 'WS',
                        iconName: '085-american-samoa.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Samoa (WS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 184,
                        name: 'San Marino',
                        code: 'SM',
                        iconName: '214-san-marino.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 71,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'San Marino (SM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 101,
                        name: 'Sao Tome and Principe',
                        code: 'ST',
                        iconName: '201-sao-tome-and-principe.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 109,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sao Tome and Principe (ST)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 185,
                        name: 'Senegal',
                        code: 'SN',
                        iconName: '259-senegal.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Senegal (SN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 102,
                        name: 'Serbia',
                        code: 'RS',
                        iconName: '035-serbia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 151,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Serbia (RS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 103,
                        name: 'Seychelles',
                        code: 'SC',
                        iconName: '150-seychelles.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Seychelles (SC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 104,
                        name: 'Sierra Leone',
                        code: 'SL',
                        iconName: '149-sierra-leone.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sierra Leone (SL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 250,
                        name: 'Sint Maarten',
                        code: 'SX',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sint Maarten (SX)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 105,
                        name: 'Slovakia',
                        code: 'SK',
                        iconName: '045-slovakia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 121,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Slovakia (SK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 183,
                        name: 'Slovenia',
                        code: 'SI',
                        iconName: '004-slovenia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 122,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Slovenia (SI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 245,
                        name: 'Solomon Islands',
                        code: 'SB',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Solomon Islands (SB)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 248,
                        name: 'Somalia',
                        code: 'SO',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Somalia (SO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 249,
                        name: 'South Sudan',
                        code: 'SS',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'South Sudan (SS)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 107,
                        name: 'Sri Lanka',
                        code: 'LK',
                        iconName: '238-sri-lanka.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sri Lanka (LK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 108,
                        name: 'Sudan',
                        code: 'SD',
                        iconName: '161-south-sudan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Sudan (SD)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 186,
                        name: 'Suriname',
                        code: 'SR',
                        iconName: '197-suriname.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Suriname (SR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 247,
                        name: 'Svalbard and Jan Mayen',
                        code: 'SJ',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Svalbard and Jan Mayen (SJ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 110,
                        name: 'Switzerland & Liechtenstein',
                        code: 'CH',
                        iconName: '097-switzerland.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Switzerland & Liechtenstein (CH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 111,
                        name: 'Syrian Arab Republic',
                        code: 'SY',
                        iconName: '039-syria.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Syrian Arab Republic (SY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 134,
                        name: 'Taiwan',
                        code: 'TW',
                        iconName: '080-taiwan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Taiwan (TW)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 112,
                        name: 'Tajikistan',
                        code: 'TJ',
                        iconName: '236-tajikistan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Tajikistan (TJ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 254,
                        name: 'Timor-Leste',
                        code: 'TL',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Timor-Leste (TL)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 189,
                        name: 'Togo',
                        code: 'TG',
                        iconName: '193-togo.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Togo (TG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 253,
                        name: 'Tokelau',
                        code: 'TK',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Tokelau (TK)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 255,
                        name: 'Tonga',
                        code: 'TO',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Tonga (TO)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 114,
                        name: 'Trinidad and Tobago',
                        code: 'TT',
                        iconName: '235-trinidad-and-tobago.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Trinidad and Tobago (TT)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 125,
                        name: 'Tunisia',
                        code: 'TN',
                        iconName: '013-tunisia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 5,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Tunisia (TN)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 115,
                        name: 'Turkey',
                        code: 'TR',
                        iconName: '119-turkey.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 141,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Turkey (TR)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 116,
                        name: 'Turkmenistan',
                        code: 'TM',
                        iconName: '192-turkmenistan.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Turkmenistan (TM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 251,
                        name: 'Turks and Caicos Islands',
                        code: 'TC',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Turks and Caicos Islands (TC)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 256,
                        name: 'Tuvalu',
                        code: 'TV',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Tuvalu (TV)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 257,
                        name: 'US Minor Outlying Islands',
                        code: 'UM',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'US Minor Outlying Islands (UM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 117,
                        name: 'Uganda',
                        code: 'UG',
                        iconName: '009-uganda.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Uganda (UG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 113,
                        name: 'United Republic of Tanzania',
                        code: 'TZ',
                        iconName: '003-tanzania.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'United Republic of Tanzania (TZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 135,
                        name: 'Uruguay',
                        code: 'UY',
                        iconName: '038-uruguay.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Uruguay (UY)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 119,
                        name: 'Uzbekistan',
                        code: 'UZ',
                        iconName: '220-uzbekistn.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 114,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Uzbekistan (UZ)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 260,
                        name: 'Vanuatu',
                        code: 'VU',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Vanuatu (VU)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 136,
                        name: 'Venezuela',
                        code: 'VE',
                        iconName: '057-venezuela.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Venezuela (VE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 258,
                        name: 'Virgin Islands, British',
                        code: 'VG',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Virgin Islands, British (VG)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 259,
                        name: 'Virgin Islands, U.S.',
                        code: 'VI',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Virgin Islands, U.S. (VI)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 261,
                        name: 'Wallis and Futuna',
                        code: 'WF',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Wallis and Futuna (WF)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 207,
                        name: 'Western Sahara',
                        code: 'EH',
                        iconName: '',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Western Sahara (EH)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 35,
                        name: 'Yemen',
                        code: 'YE',
                        iconName: '219-yemen.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: null,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Yemen (YE)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 120,
                        name: 'Zambia',
                        code: 'ZM',
                        iconName: '016-zambia.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Zambia (ZM)'
                    }
                },
                {
                    isSelected: false,
                    isUpSelected: false,
                    data: {
                        id: 121,
                        name: 'Zimbabwe',
                        code: 'ZW',
                        iconName: '242-zimbabwe.svg',
                        wipoIq: 0,
                        up: null,
                        pcIq: null,
                        languageId: 38,
                        wipoEntitySize: [],
                        pcEntitySize: [],
                        epoState: null,
                        concatCode: 'Zimbabwe (ZW)'
                    }
                }
            ],
            isCheckedSelectAllInstantCheckbox: false,
            isCheckedSelectAllCustomCheckbox: false
        },
        selectCountryPageEdit: {
            instantCountries: [
                {
                    countryId: 2,
                    isInstantQuote: true,
                    languageId: 38,
                    countryName: 'ARIPO',
                    languageName: null,
                    entityType: 0,
                    agencyFee: 1300,
                    officialFee: 2098,
                    translationFee: 10,
                    total: 3408,
                    ep: null,
                    up: null,
                    isprimary: false,
                    isCustomCountry: null,
                    isClaim: null
                }
            ],
            customCountries: [
                {
                    countryId: 0,
                    isInstantQuote: false,
                    languageId: 38,
                    countryName: null,
                    languageName: null,
                    entityType: null,
                    agencyFee: 0,
                    officialFee: 0,
                    translationFee: 10,
                    total: 3408,
                    ep: null,
                    up: null,
                    isprimary: false,
                    isCustomCountry: null,
                    isClaim: null
                },
                {
                    countryId: 138,
                    isInstantQuote: false,
                    languageId: 104,
                    countryName: 'Afghanistan',
                    languageName: null,
                    entityType: 0,
                    agencyFee: 1,
                    officialFee: 1,
                    translationFee: 1,
                    total: 3,
                    ep: null,
                    up: null,
                    isprimary: false,
                    isCustomCountry: true,
                    isClaim: null
                }
            ],
            epCountries: []
        },
        selectCountryPageForEP: null,
        summaryPage: {
            instruction: '',
            customDisclaimer: {
                sNo: 7,
                disclaimer: '',
                isCustomDisclaimer: true,
                customInstruction: ''
            },
            selectedCurrency: {
                currencyId: 2,
                currencyName: 'US Dollar',
                currencyIcon: '153-united-states-of-america.svg',
                concatCode: 'US Dollar - USD ($)',
                currencyCode: 'USD',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            totals: {
                nationalValidationUP: {
                    up: null,
                    nonUP: 0,
                    languageFeeTotal: 0,
                    grandTotalUP: 0
                },
                nationalValidation: {
                    countryFeeTotal: 5033.998,
                    languageFeeTotal: 0,
                    grandTotal: 5033.998
                },
                customCountry: 3
            },
            responseData: {
                summaryResponse: {
                    disclaimerList: [
                        {
                            sNo: 1,
                            disclaimer: 'Aripo: The official fee assumes all 18 states will.',
                            isCustomDisclaimer: null,
                            customInstruction: null
                        },
                        {
                            sNo: 2,
                            disclaimer: 'The same English translation can be used for ARIPO.',
                            isCustomDisclaimer: null,
                            customInstruction: null
                        },
                        {
                            sNo: 3,
                            disclaimer:
                                'In order to ensure a quality translation certain languages.',
                            isCustomDisclaimer: null,
                            customInstruction: null
                        },
                        {
                            sNo: 4,
                            disclaimer:
                                'If final requirements are different from the above or if materials.',
                            isCustomDisclaimer: true,
                            customInstruction: 'Custom Instruction'
                        }
                    ],
                    languageBasedFee: [],
                    instantCountryList: {
                        countryFeeList: [
                            {
                                countryId: 1,
                                languageId: 5,
                                countryName: 'Algeria',
                                languageName: null,
                                entityType: '0',
                                agencyFee: '1025.0',
                                officialFee: '259.038',
                                translationFee: '341.96',
                                total: '1625.998',
                                groupId: null
                            },
                            {
                                countryId: 2,
                                languageId: 38,
                                countryName: 'ARIPO',
                                languageName: null,
                                entityType: '0',
                                agencyFee: '0.0',
                                officialFee: '0.0',
                                translationFee: '10.0',
                                total: '3408.0',
                                groupId: null
                            },
                            {
                                countryId: 0,
                                languageId: 38,
                                countryName: null,
                                languageName: 'English Translation',
                                entityType: '',
                                agencyFee: '',
                                officialFee: '',
                                translationFee: '0.0',
                                total: '0.0',
                                groupId: null
                            }
                        ]
                    },
                    customCountryList: [
                        {
                            countryId: 138,
                            countryName: 'Afghanistan',
                            agencyFee: '1.0',
                            officialFee: '1.0',
                            translationFee: '1.0',
                            total: '3.0',
                            groupId: null
                        },
                        {
                            countryId: 197,
                            countryName: 'Aland Islands',
                            agencyFee: '',
                            officialFee: '',
                            translationFee: '',
                            total: '',
                            groupId: null
                        }
                    ],
                    customCountryMessage: '',
                    serviceBasedFee: {
                        upFee: [],
                        nonupFee: [],
                        agencyFeeTooltip: null,
                        translationFeeTooltip: null
                    },
                    grandTotal: 5024.0,
                    currencySymbol: '$'
                },
                currencyResponse: [
                    {
                        currencyId: 1,
                        currencyName: 'Australian Dollar',
                        currencyIcon: '130-australia.svg',
                        concatCode: 'Australian Dollar - AUD (AU$)',
                        currencyCode: 'AUD',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    },
                    {
                        currencyId: 5,
                        currencyName: 'Canadian Dollar',
                        currencyIcon: '206-canada.svg',
                        concatCode: 'Canadian Dollar - CAD (C$)',
                        currencyCode: 'CAD',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    },
                    {
                        currencyId: 6,
                        currencyName: 'Euro',
                        currencyIcon: '022-european-union.svg',
                        concatCode: 'Euro - EUR (€)',
                        currencyCode: 'EUR',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    },
                    {
                        currencyId: 4,
                        currencyName: 'New Zealand Dollar',
                        currencyIcon: '048-new-zealand.svg',
                        concatCode: 'New Zealand Dollar - NZD (NZ$)',
                        currencyCode: 'NZD',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    },
                    {
                        currencyId: 3,
                        currencyName: 'Pound Sterling',
                        currencyIcon: '262-united-kingdom.svg',
                        concatCode: 'Pound Sterling - GBP (£)',
                        currencyCode: 'GBP',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    },
                    {
                        currencyId: 2,
                        currencyName: 'US Dollar',
                        currencyIcon: '153-united-states-of-america.svg',
                        concatCode: 'US Dollar - USD ($)',
                        currencyCode: 'USD',
                        currencySymbol: null,
                        isPreferredCurrency: null
                    }
                ],
                languageResponse: [
                    {
                        id: 1,
                        name: 'Afrikaan',
                        isoCode: 'AFR',
                        abbreviation: 'af',
                        isSource: null
                    },
                    {
                        id: 2,
                        name: 'Albanian',
                        isoCode: 'SQI',
                        abbreviation: 'sq',
                        isSource: null
                    },
                    {
                        id: 3,
                        name: 'American Sign Languages',
                        isoCode: 'ASL',
                        abbreviation: '',
                        isSource: null
                    },
                    {
                        id: 4,
                        name: 'Amharic ',
                        isoCode: 'TES',
                        abbreviation: 'am',
                        isSource: null
                    },
                    {
                        id: 5,
                        name: 'Arabic',
                        isoCode: 'ARA',
                        abbreviation: 'ar',
                        isSource: null
                    },
                    {
                        id: 6,
                        name: 'Armenian',
                        isoCode: 'HYE',
                        abbreviation: 'hy',
                        isSource: null
                    },
                    {
                        id: 7,
                        name: 'Azerbaijani',
                        isoCode: 'AZER',
                        abbreviation: 'az ',
                        isSource: null
                    },
                    {
                        id: 8,
                        name: 'Azeri',
                        isoCode: 'AZE',
                        abbreviation: '',
                        isSource: null
                    },
                    {
                        id: 9,
                        name: 'Baluchi',
                        isoCode: 'BAL',
                        abbreviation: '',
                        isSource: null
                    },
                    {
                        id: 10,
                        name: 'Basque',
                        isoCode: 'SPA-EUS',
                        abbreviation: 'eu',
                        isSource: null
                    }
                ],
                languageList: null
            },
            info: {
                selectedServiceId: 1,
                selectedCategoryId: 7,
                languageListIDs: null,
                isUPFlow: false
            },
            flags: {
                isCountryFeeEditMode: false,
                isMapViewOn: false,
                isHighRole: true,
                scrollHeightOfCountryConfigTableForEP: 310,
                IsUp: null
            }
        },
        uploadAndLanguageSelectionPage: null,
        orderQuoteDetailsPage: null,
        languageSelectionPage: null,
        upcOptOutPage: null
        // standardPageForEdit: {
        //     selectedCompanyId: 40,
        //     selectedContactId: 70,
        //     contactEmail: '',
        //     title: 'GUIDE VANE ARRANGEMENT FOR A DRIVING MECHANISM',
        //     requestedDeliveryDate: null,
        //     quoteTargetDateTime: null,
        //     poNumber: '',
        //     referenceNumber: null,
        //     alsoDeliverTo: '',
        //     quoteRequired: true,
        //     cc: '',
        //     projectManager: '4,12',
        //     salesRep: '0',
        //     requestCurrency: null,
        //     requestInvoiceStatus: null,
        //     instructionsCommentsContactUser: '',
        //     instructionsCommentsProjectManager: ''
        // }
    },
    editFlowResponseData: {
        info: {
            mode: 1,
            selectedServiceId: 7,
            selectedCategoryId: 1,
            requestCurrencyId: 2,
            documentId: null,
            approveStatus: 2,
            isEditFlow: true,
            isUP: null,
            referenceNo: 9519,
            statusId: 2,
            requestNumber: 'R240916-3'
        },
        formData: {
            additionalInfoPage: {
                emailID: '',
                deliverTo: [''],
                cc: '',
                po: '',
                quoteDateTime: null,
                targetDateTime: '2024-09-17T00:00:00',
                quoteRequired: true,
                instructionByContactUser: '',
                instructionByProjectManager: '',
                projectManager: [4, 12],
                salesRep: null
            },
            companyDetailsPage: {
                selectedCompanyId: 40,
                selectedContactId: 70,
                publicationNumber: 'WO/2008/000014'
            },
            selectCountryPage: {
                instantCountries: [
                    {
                        countryId: 2,
                        isInstantQuote: true,
                        languageId: 38,
                        countryName: 'ARIPO',
                        languageName: null,
                        entityType: 0,
                        agencyFee: 1300,
                        officialFee: 2098,
                        translationFee: 10,
                        total: 3408,
                        ep: null,
                        up: null,
                        isprimary: false,
                        isCustomCountry: null,
                        isClaim: null
                    }
                ],
                customCountries: [
                    {
                        countryId: 0,
                        isInstantQuote: false,
                        languageId: 38,
                        countryName: null,
                        languageName: null,
                        entityType: null,
                        agencyFee: 0,
                        officialFee: 0,
                        translationFee: 10,
                        total: 3408,
                        ep: null,
                        up: null,
                        isprimary: false,
                        isCustomCountry: null,
                        isClaim: null
                    },
                    {
                        countryId: 138,
                        isInstantQuote: false,
                        languageId: 104,
                        countryName: 'Afghanistan',
                        languageName: null,
                        entityType: 0,
                        agencyFee: 1,
                        officialFee: 1,
                        translationFee: 1,
                        total: 3,
                        ep: null,
                        up: null,
                        isprimary: false,
                        isCustomCountry: true,
                        isClaim: null
                    }
                ],
                epCountries: []
            },
            orderQuoteDetailsPage: {
                selectedCompanyId: 40,
                selectedContactId: 70,
                contactEmail: '',
                title: 'GUIDE VANE ARRANGEMENT FOR A DRIVING MECHANISM',
                requestedDeliveryDate: null,
                quoteTargetDateTime: null,
                poNumber: '',
                referenceNumber: null,
                alsoDeliverTo: '',
                quoteRequired: true,
                cc: '',
                projectManager: '4,12',
                salesRep: '0',
                requestCurrency: null,
                requestInvoiceStatus: null,
                instructionsCommentsContactUser: '',
                instructionsCommentsProjectManager: ''
            },
            patentDetailsPage: {
                title: 'GUIDE VANE ARRANGEMENT FOR A DRIVING MECHANISM',
                pctReference: 'PCT/AT2007/000325',
                patentPublicationNumber: 'WO/2008/000014',
                patentApplicationNumber: 'PCT/AT2007/000325',
                upDeadLine: null,
                requestedDeliveryDate: null,
                referenceNo: '',
                applicantId: 0,
                applicantName: 'FACC AG',
                sourceLanguage: 'DE',
                sourceLanguageId: 59,
                sourceLanguageName: 'German',
                textthirtyMonthsDeadline: '2008-12-30',
                validationDeadline: null,
                kind: null,
                europeanFilingDate: null,
                abstractWordCount: 188,
                drawingsWordCount: 0,
                descriptionWordCount: 1971,
                numberOfDrawings: 0,
                claimsWordCount: 524,
                drawingsPageCount: 0,
                specificationWordCount: 0,
                numberOfPriorityClaims: 1,
                numberOfClaims: 17,
                descriptionPageCount: 0,
                claimsPageCount: 0,
                estTotalPages: 1,
                numberOfIndependentClaims: 0,
                originalAbstractWordCount: 188,
                originalDrawingsWordCount: 0,
                originalDescriptionWordCount: 1971,
                originalNumberOfDrawings: 0,
                originalClaimsWordCount: 524,
                originalDrawingsPageCount: 0,
                originalSpecificationWordCount: 0,
                originalNumberOfPriorityClaims: 0,
                originalNumberOfClaims: 17,
                originalDescriptionPageCount: 0,
                originalClaimsPageCount: 0,
                originalNumberOfIndependentClaims: 0,
                originalEstTotalPages: 1,
                estimatedSequenceListing: 2,
                applicationClaimsPriority: 2,
                specialInstructions: null,
                ifEpGrantedYesNo: false,
                english: false,
                german: false,
                french: false,
                requestedDeliveryDateForClaimsTranslation: null,
                statutoryDeadline: null,
                claimsPriority: null,
                filingDeadLine: '',
                requestedFilingDeadLine: '',
                requestedById: 95,
                requestedByName: 'Gopikrishna Saravana',
                salesRepId: '0',
                salesRepName: '',
                companyName: 40,
                contactUser: {
                    id: 70,
                    firstName: 'CUSER 1',
                    lastName: '',
                    middleName: '',
                    fullName: 'CUSER 1  ',
                    roleId: 6,
                    email: 'cuser1@gmail.com',
                    salesRepName: '',
                    salesRepId: 0,
                    contactInformation: null
                },
                publicationNumber: 'WO/2008/000014'
            }
        }
    },
    backupDataToCompare: {
        companyName: {
            id: 40,
            name: 'ABC Technologies',
            companyType: 0,
            parentCompanyId: null,
            salesRep: 18,
            salesRepName: null,
            requestCurrencyId: 2,
            isPoRequired: true
        },
        languages: {
            english: null,
            german: null,
            french: null
        },
        counts: {
            countryCount: null,
            countryList: null,
            abstractWordCount: 188,
            drawingsWordCount: 0,
            descriptionWordCount: 1971,
            numberOfDrawings: 0,
            claimsWordCount: 524,
            drawingsPageCount: 0,
            numberOfPriorityClaims: 1,
            numberOfClaims: 17,
            numberOfIndependentClaims: 0,
            estimatedNumberOfTotalPages: null,
            estimatedSequenceListing: 2
        },
        countries: [0, 2, 138],
        selectedCurrency: {
            currencyId: 2,
            currencyName: 'US Dollar',
            currencyIcon: '153-united-states-of-america.svg',
            concatCode: 'US Dollar - USD ($)',
            currencyCode: 'USD',
            currencySymbol: null,
            isPreferredCurrency: null
        }
    }
};

// getSummaryPageData
const summaryMetaData = {
    instruction: '',
    customDisclaimer: {
        sNo: 7,
        disclaimer: '',
        isCustomDisclaimer: true,
        customInstruction: ''
    },
    selectedCurrency: {
        currencyId: 2,
        currencyName: 'US Dollar',
        currencyIcon: '153-united-states-of-america.svg',
        concatCode: 'US Dollar - USD ($)',
        currencyCode: 'USD',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    totals: {
        nationalValidationUP: {
            up: null,
            nonUP: 0,
            languageFeeTotal: 0,
            grandTotalUP: 0
        },
        nationalValidation: {
            countryFeeTotal: 5033.998,
            languageFeeTotal: 0,
            grandTotal: 5033.998
        },
        customCountry: 3
    },
    responseData: {
        summaryResponse: {
            disclaimerList: [
                {
                    sNo: 1,
                    disclaimer: 'Aripo: The official fee assumes all 18 states will.',
                    isCustomDisclaimer: null,
                    customInstruction: null
                },
                {
                    sNo: 2,
                    disclaimer: 'The same English translation can be used for ARIPO.',
                    isCustomDisclaimer: null,
                    customInstruction: null
                },
                {
                    sNo: 3,
                    disclaimer: 'In order to ensure a quality translation certain languages.',
                    isCustomDisclaimer: null,
                    customInstruction: null
                },
                {
                    sNo: 4,
                    disclaimer:
                        'If final requirements are different from the above or if materials.',
                    isCustomDisclaimer: true,
                    customInstruction: 'Custom Instruction'
                }
            ],
            languageBasedFee: [],
            instantCountryList: {
                countryFeeList: [
                    {
                        countryId: 1,
                        languageId: 5,
                        countryName: 'Algeria',
                        languageName: null,
                        entityType: '0',
                        agencyFee: '1025.0',
                        officialFee: '259.038',
                        translationFee: '341.96',
                        total: '1625.998',
                        groupId: null
                    },
                    {
                        countryId: 2,
                        languageId: 38,
                        countryName: 'ARIPO',
                        languageName: null,
                        entityType: '0',
                        agencyFee: '0.0',
                        officialFee: '0.0',
                        translationFee: '10.0',
                        total: '3408.0',
                        groupId: null
                    },
                    {
                        countryId: 0,
                        languageId: 38,
                        countryName: null,
                        languageName: 'English Translation',
                        entityType: '',
                        agencyFee: '',
                        officialFee: '',
                        translationFee: '0.0',
                        total: '0.0',
                        groupId: null
                    }
                ]
            },
            customCountryList: [
                {
                    countryId: 138,
                    countryName: 'Afghanistan',
                    agencyFee: '1.0',
                    officialFee: '1.0',
                    translationFee: '1.0',
                    total: '3.0',
                    groupId: null
                },
                {
                    countryId: 197,
                    countryName: 'Aland Islands',
                    agencyFee: '',
                    officialFee: '',
                    translationFee: '',
                    total: '',
                    groupId: null
                }
            ],
            customCountryMessage: '',
            serviceBasedFee: {
                upFee: [],
                nonupFee: [],
                agencyFeeTooltip: null,
                translationFeeTooltip: null
            },
            grandTotal: 5024.0,
            currencySymbol: '$'
        },
        currencyResponse: [
            {
                currencyId: 1,
                currencyName: 'Australian Dollar',
                currencyIcon: '130-australia.svg',
                concatCode: 'Australian Dollar - AUD (AU$)',
                currencyCode: 'AUD',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            {
                currencyId: 5,
                currencyName: 'Canadian Dollar',
                currencyIcon: '206-canada.svg',
                concatCode: 'Canadian Dollar - CAD (C$)',
                currencyCode: 'CAD',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            {
                currencyId: 6,
                currencyName: 'Euro',
                currencyIcon: '022-european-union.svg',
                concatCode: 'Euro - EUR (€)',
                currencyCode: 'EUR',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            {
                currencyId: 4,
                currencyName: 'New Zealand Dollar',
                currencyIcon: '048-new-zealand.svg',
                concatCode: 'New Zealand Dollar - NZD (NZ$)',
                currencyCode: 'NZD',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            {
                currencyId: 3,
                currencyName: 'Pound Sterling',
                currencyIcon: '262-united-kingdom.svg',
                concatCode: 'Pound Sterling - GBP (£)',
                currencyCode: 'GBP',
                currencySymbol: null,
                isPreferredCurrency: null
            },
            {
                currencyId: 2,
                currencyName: 'US Dollar',
                currencyIcon: '153-united-states-of-america.svg',
                concatCode: 'US Dollar - USD ($)',
                currencyCode: 'USD',
                currencySymbol: null,
                isPreferredCurrency: null
            }
        ],
        languageResponse: [
            {
                id: 1,
                name: 'Afrikaan',
                isoCode: 'AFR',
                abbreviation: 'af',
                isSource: null
            },
            {
                id: 2,
                name: 'Albanian',
                isoCode: 'SQI',
                abbreviation: 'sq',
                isSource: null
            },
            {
                id: 3,
                name: 'American Sign Languages',
                isoCode: 'ASL',
                abbreviation: '',
                isSource: null
            },
            {
                id: 4,
                name: 'Amharic ',
                isoCode: 'TES',
                abbreviation: 'am',
                isSource: null
            },
            {
                id: 5,
                name: 'Arabic',
                isoCode: 'ARA',
                abbreviation: 'ar',
                isSource: null
            },
            {
                id: 6,
                name: 'Armenian',
                isoCode: 'HYE',
                abbreviation: 'hy',
                isSource: null
            },
            {
                id: 7,
                name: 'Azerbaijani',
                isoCode: 'AZER',
                abbreviation: 'az ',
                isSource: null
            },
            {
                id: 8,
                name: 'Azeri',
                isoCode: 'AZE',
                abbreviation: '',
                isSource: null
            },
            {
                id: 9,
                name: 'Baluchi',
                isoCode: 'BAL',
                abbreviation: '',
                isSource: null
            },
            {
                id: 10,
                name: 'Basque',
                isoCode: 'SPA-EUS',
                abbreviation: 'eu',
                isSource: null
            }
        ],
        languageList: null
    },
    info: {
        selectedServiceId: 1,
        selectedCategoryId: 7,
        languageListIDs: null,
        isUPFlow: false
    },
    flags: {
        isCountryFeeEditMode: false,
        isMapViewOn: false,
        isHighRole: true,
        scrollHeightOfCountryConfigTableForEP: 310,
        IsUp: null
    }
};

// getCurrencyList
const currencyList = [
    {
        currencyId: 1,
        currencyName: 'Australian Dollar',
        currencyIcon: '130-australia.svg',
        concatCode: 'Australian Dollar - AUD (AU$)',
        currencyCode: 'AUD',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    {
        currencyId: 5,
        currencyName: 'Canadian Dollar',
        currencyIcon: '206-canada.svg',
        concatCode: 'Canadian Dollar - CAD (C$)',
        currencyCode: 'CAD',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    {
        currencyId: 6,
        currencyName: 'Euro',
        currencyIcon: '022-european-union.svg',
        concatCode: 'Euro - EUR (€)',
        currencyCode: 'EUR',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    {
        currencyId: 4,
        currencyName: 'New Zealand Dollar',
        currencyIcon: '048-new-zealand.svg',
        concatCode: 'New Zealand Dollar - NZD (NZ$)',
        currencyCode: 'NZD',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    {
        currencyId: 3,
        currencyName: 'Pound Sterling',
        currencyIcon: '262-united-kingdom.svg',
        concatCode: 'Pound Sterling - GBP (£)',
        currencyCode: 'GBP',
        currencySymbol: null,
        isPreferredCurrency: null
    },
    {
        currencyId: 2,
        currencyName: 'US Dollar',
        currencyIcon: '153-united-states-of-america.svg',
        concatCode: 'US Dollar - USD ($)',
        currencyCode: 'USD',
        currencySymbol: null,
        isPreferredCurrency: null
    }
];

// getLanguageList
const languageList = [
    {
        id: 1,
        name: 'Afrikaan',
        isoCode: 'AFR',
        abbreviation: 'af',
        isSource: null
    },
    {
        id: 2,
        name: 'Albanian',
        isoCode: 'SQI',
        abbreviation: 'sq',
        isSource: null
    },
    {
        id: 3,
        name: 'American Sign Languages',
        isoCode: 'ASL',
        abbreviation: '',
        isSource: null
    },
    {
        id: 4,
        name: 'Amharic ',
        isoCode: 'TES',
        abbreviation: 'am',
        isSource: null
    },
    {
        id: 5,
        name: 'Arabic',
        isoCode: 'ARA',
        abbreviation: 'ar',
        isSource: null
    }
];

const summaryPageMockData = {
    updatedCompleteStoreInfo,
    summaryMetaData,
    currencyList,
    languageList
};
export default summaryPageMockData;
