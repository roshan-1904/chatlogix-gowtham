import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { FileUploadPayload } from './epUpcOptOut.types';
import utils from 'core/utils/utils';

const baseUrlIQ: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseUrlIQ) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

const getUploadedFilePatentNumbers = async (payload: FileUploadPayload, hideLoader?: boolean) => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.EP_FILE_VALIDATE_PATENT_NUMBERS}`;
    try {
        const response = await httpService.postFile<any>(
            apiUrl,
            payload,
            {
                data: { hideLoader: hideLoader ?? true }
            },
            baseUrlIQ
        );
        return response;
    } catch (error) {
        console.error('Error fetching uploaded file patent numbers:', error);
        throw error;
    }
};

const downloadSamplePatentExcel = async () => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.DOWNLOAD_UPC_OPT_OUT_EMPTY_EXCEL}`;
    try {
        const blob = await httpService.downloadFile(apiUrl, false, baseUrlIQ);
        utils.downloadBlob(blob, `UPC_Opt_Out_Sample_Template.xlsx`);
    } catch (error) {
        console.error('Error downloading file:', error);
        throw error;
    }
};

export { getUploadedFilePatentNumbers, downloadSamplePatentExcel };
