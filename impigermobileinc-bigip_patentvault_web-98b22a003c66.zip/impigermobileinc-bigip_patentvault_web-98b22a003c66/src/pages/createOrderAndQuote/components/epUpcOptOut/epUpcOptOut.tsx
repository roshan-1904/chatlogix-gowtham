import { t } from 'i18next';
import { inputStyleText, inputTextArea } from 'constants/styles.constant';
import { Calendar } from 'primereact/calendar';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { useEffect, useState } from 'react';
import { calendarStyles } from 'shared/dataTable/constant/dataTable.styles';
import { downloadSamplePatentExcel, getUploadedFilePatentNumbers } from './epUpcOptOut.service';
import { FileUploadResponse, UpcOptOutFormData } from './epUpcOptOut.types';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';
import { DOCUMENT_TYPE, MODULE_TYPE } from 'constants/app.constant';
import { QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import FileUpload from 'components/fileUpload/fileUpload';
import { getSasUrl } from 'components/fileUpload/services/azureStorage.service';
import { Skeleton } from 'primereact/skeleton';
import { isAdminUser, isContactUser, isProjectManagerUser } from 'core/utils/utils';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { Editor } from 'primereact/editor';

const UpcOptOut = ({
    setPatentNumbers
}: {
    setPatentNumbers: (patentNumbers: string[]) => void;
}) => {
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const initialFormData: UpcOptOutFormData = {
        companyName: '',
        requestedDeliveryDate: null,
        referenceNumber: '',
        instructionsAndCommentsAdminPMUsers: '',
        instructionsAndCommentsContactUsers: '',
        patentNumbers: [],
        fileName: ''
    };
    const [formData, setFormData] = useState<UpcOptOutFormData>(
        quoteOrderData.formData.upcOptOutPage || initialFormData
    );
    const [isValidatingFile, setIsValidatingFile] = useState(false);
    const [uploadedFileData, setUploadedFileData] = useState<{
        file: File;
        primaryId: number;
        uploadFileApiUrl: string;
    } | null>(null);
    const patentNumbers = (isValid?: boolean) =>
        formData.patentNumbers.filter((item) =>
            isValid === undefined ? true : item.isValid === isValid
        );

    quoteOrderModuleStore.subscribe((data) => {
        setFormData(data.formData.upcOptOutPage || initialFormData);
    });
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserId = userDetails.userInfo.roleId;
    const isAdminPmUsers = isAdminUser(loggedInUserId) || isProjectManagerUser(loggedInUserId);
    const isContactUsers = isContactUser(loggedInUserId);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        quoteOrderModuleStore.updatePage('formData', {
            ...quoteOrderData.formData,
            upcOptOutPage: {
                ...formData,
                [name]: value
            }
        });
    };

    const handleFileUploadAndGetData = async (e: React.ChangeEvent<HTMLInputElement>) => {
        setIsValidatingFile(true);
        setPatentNumbers([]);
        setUploadedFileData(null);
        const file = e.target.files?.[0];
        if (file) {
            const resetFileInput = document.getElementById(
                'upload-completed-Template'
            ) as HTMLInputElement;
            resetFileInput.value = '';
            const payload = {
                file,
                draftId: quoteOrderData.info.primaryId || undefined
            };
            try {
                const response: FileUploadResponse = await getUploadedFilePatentNumbers(payload);
                if (response) {
                    const primaryId = response.draftId ?? 0;
                    quoteOrderModuleStore.updatePage('formData', {
                        ...quoteOrderData.formData,
                        upcOptOutPage: {
                            ...formData,
                            patentNumbers: response.patentNumbers,
                            fileName: file.name
                        }
                    });
                    await new Promise((r) => setTimeout(r, 100));
                    quoteOrderModuleStore.updatePage('info', {
                        ...quoteOrderData.info,
                        primaryId
                    });

                    setPatentNumbers(response.patentNumbers.map((item) => item.patentNumber));
                    setUploadedFileData({
                        file,
                        primaryId,
                        uploadFileApiUrl: `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPLOAD_FILE}${primaryId}&moduleType=${MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId}` // Upload file API URL
                    });
                }
            } catch {
                quoteOrderModuleStore.updatePage('formData', {
                    ...quoteOrderData.formData,
                    upcOptOutPage: {
                        ...formData,
                        patentNumbers: [],
                        fileName: undefined
                    }
                });
                await new Promise((resolve) => setTimeout(resolve, 500));
                setIsValidatingFile(false);
            }
        }
        await new Promise((resolve) => setTimeout(resolve, 1000));
        setIsValidatingFile(false);
    };

    const skeletonTemplate = (
        type: string,
        customStyle?: {
            height?: string;
            width?: string;
        }
    ) => {
        switch (type) {
            case 'patentItem':
                return [...Array(6)].map((_, index) => (
                    <Skeleton
                        key={index}
                        width={customStyle?.width || '6.8rem'}
                        height={customStyle?.height || '2.15rem'}
                        className="skeleton "
                        pt={{
                            root: {
                                className: 'rounded-2xl !mb-0'
                            }
                        }}
                    />
                ));
            case 'circle':
                return (
                    <Skeleton
                        width={customStyle?.width || '1.4rem'}
                        height={customStyle?.height || '1.4rem'}
                        className="skeleton "
                        pt={{
                            root: {
                                className: 'rounded-full !mb-0'
                            }
                        }}
                    />
                );
            case 'text':
                return (
                    <Skeleton
                        width={customStyle?.width || '12rem'}
                        height={customStyle?.height || '1rem'}
                        className="skeleton "
                        pt={{
                            root: {
                                className: 'rounded-lg !mb-0'
                            }
                        }}
                    />
                );
            default:
                return null;
        }
    };

    useEffect(() => {
        getSasUrl();
    }, []);

    return (
        <div className="p-5 pt-4">
            <FileUpload
                className="hidden"
                uploadFileApiUrl={uploadedFileData?.uploadFileApiUrl || ''}
                moduleType={{
                    moduleId: MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName
                }}
                primaryId={uploadedFileData?.primaryId || 0}
                documentTypeId={DOCUMENT_TYPE.SOURCE.id}
                deleteFileApiUrl={null}
                getDocumentTypeApiUrl={null}
                updateDocumentTypeApiUrl={null}
                multipleFiles={false}
                moduleName={`upcOptOut-${uploadedFileData?.primaryId}`}
                acceptedFileTypes={['.xlsx', '.xls']}
                triggerHandleFiles={
                    uploadedFileData
                        ? (handleFiles: (files: File[]) => void) => {
                              handleFiles([uploadedFileData.file]);
                              setUploadedFileData(null);
                          }
                        : undefined
                }
                isEpUPCOptOut={true}
            />

            <h4 className="font-semibold leading-none">
                {t('COMPANY_DETAILS.UPC_OPT_OUT_DETAILS')}
            </h4>
            <div className="flex flex-col gap-1.5">
                <div className="grid grid-cols-3 gap-x-6 gap-y-1.5 [&>div]:flex [&>div]:flex-col [&>div]:gap-1.5 mt-3 [&>div>label]:text-black/70">
                    <div>
                        <label htmlFor="requestedDeliveryDate">
                            {t('DATE_AND_DEADLINES.REQUESTED_DELIVERY_DATE')}
                        </label>
                        <Calendar
                            showIcon
                            id="buttondisplay"
                            icon="pi pi-calendar text-black/50"
                            pt={{
                                ...calendarStyles,
                                root: {
                                    className:
                                        'h-10 border rounded-md border-neutral-100 hover:border-primary [&>button]:pt-2.5 [&>button]:px-3 [&>button]:bg-transparent [&>button]:hover:bg-transparent [&>button]:!shadow-none [&>button]:h-10 [&>button]:border-0'
                                },
                                input: {
                                    root: {
                                        className: ' w-full border-r-0 rounded-r-none border-0'
                                    }
                                }
                            }}
                            name="requestedDeliveryDate"
                            placeholder="Select Date"
                            value={formData.requestedDeliveryDate}
                            onChange={(e) =>
                                quoteOrderModuleStore.updatePage('formData', {
                                    ...quoteOrderData.formData,
                                    upcOptOutPage: {
                                        ...formData,
                                        requestedDeliveryDate: e.value
                                    }
                                })
                            }
                        />
                    </div>
                    <div>
                        <label htmlFor="referenceNumber">
                            {t('ADDITIONAL_INFO.REFERENCE_NUMBER')}
                        </label>
                        <InputText
                            pt={{
                                ...inputStyleText,
                                root: {
                                    className:
                                        inputStyleText.root.className +
                                        ' placeholder:font-normal w-full '
                                }
                            }}
                            name="referenceNumber"
                            placeholder="Enter Reference Number"
                            value={formData.referenceNumber}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-span-3 !flex-row !gap-6 !grid grid-cols-3 gap-x-6">
                        <div
                            className={`flex flex-col gap-1.5 mt-3 [&>label]:text-black/70 col-span-2 ${isContactUsers ? '' : 'cursor-not-allowed'}`}>
                            <label htmlFor="instructionsAndCommentsContactUsers">
                                {t('COMPANY_DETAILS.INSTRUCTION_AND_COMMENTS')}
                            </label>
                            <InputTextarea
                                pt={{
                                    ...inputTextArea,
                                    root: {
                                        className:
                                            ' focus:shadow-none w-full font-auto text-black disabled:bg-black/5 max-h-[250px]'
                                    }
                                }}
                                name="instructionsAndCommentsContactUsers"
                                placeholder="Enter Instructions & Comments"
                                value={formData.instructionsAndCommentsContactUsers}
                                onChange={handleInputChange}
                                disabled={!isContactUsers}
                            />
                        </div>
                        {/* As per the client request, temporarily hidden. */}
                        <div className="hidden">
                            <div
                                className={`flex flex-col gap-1.5 mt-3 [&>label]:text-black/70 col-span-2 ${isAdminPmUsers ? '' : 'cursor-not-allowed'}`}>
                                <label htmlFor="instructionsAndCommentsAdminPMUsers">
                                    {t('INSTRUCTIONS_AND_COMMENTS.INTERNAL_INSTRUCTION_COMMENTS')}
                                </label>
                                <Editor
                                    name="instructionsAndCommentsAdminPMUsers"
                                    value={formData.instructionsAndCommentsAdminPMUsers}
                                    pt={{
                                        toolbar: {
                                            className: `bg-gray-100 rounded-t-md border border-gray-300 box-border font-sans px-2 py-1 ${isAdminPmUsers ? '' : 'pointer-events-none cursor-not-allowed rounded-t-md '}`
                                        },
                                        root: {
                                            className: `bg-white w-full`
                                        },
                                        formats: {
                                            className: 'inline-block align-middle mr-4'
                                        },
                                        content: {
                                            className: `rounded-b-md ${isAdminPmUsers ? '' : 'pointer-events-none cursor-not-allowed bg-black/10 rounded-b-md '}`
                                        }
                                    }}
                                    onTextChange={(e) =>
                                        quoteOrderModuleStore.updatePage('formData', {
                                            ...quoteOrderData.formData,
                                            upcOptOutPage: {
                                                ...formData,
                                                instructionsAndCommentsAdminPMUsers:
                                                    e.htmlValue || ''
                                            }
                                        })
                                    }
                                    style={{
                                        maxHeight: '250px',
                                        minHeight: '70px',
                                        height: 'auto',
                                        overflow: 'auto'
                                    }}
                                    disabled={!isAdminPmUsers}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex flex-col gap-2 mt-3">
                    <div className="flex items-center gap-4">
                        <h4 className="font-medium text-primary">
                            {t('COMPANY_DETAILS.EP_PATENTS_TO_BE_OPTED_OUT')}
                        </h4>
                        <div className="flex items-center gap-2 bg-warning/30 border border-warning-200/80 py-1.5 px-2 w-fit rounded-md mt-1 text-[0.875rem]">
                            <i className="pi pi-info-circle text-warning-200" />
                            <span className=" text-[0.875rem] font-medium">
                                {t('COMPANY_DETAILS.EP_PATENTS_TO_BE_OPTED_OUT_INSTRUCTION')}{' '}
                            </span>
                        </div>
                    </div>
                    <div className="flex gap-4 mt-2">
                        <button
                            className="btn button-primary-outline min-h-10 h-10"
                            onClick={() => {
                                downloadSamplePatentExcel();
                            }}>
                            1. {t('COMMON.DOWNLOAD_TEMPLATE')}
                        </button>
                        <div className="flex items-center gap-2">
                            <label className="btn button-primary-outline min-h-10 h-10 cursor-pointer">
                                2. {t('COMMON.UPLOAD_COMPLETED_TEMPLATE')}{' '}
                                <input
                                    type="file"
                                    id="upload-completed-Template"
                                    hidden
                                    accept=".xlsx, .xls"
                                    onChange={(e) => {
                                        handleFileUploadAndGetData(e);
                                    }}
                                />
                            </label>
                        </div>
                    </div>

                    <div className="mt-2 w-fit">
                        <h5
                            className={
                                'text-black/55 font-medium flex items-center gap-0.5 text-sm [&>img]:h-4 mb-3 group w-fit' +
                                (formData.fileName ? ' cursor-pointer' : '')
                            }
                            title={formData.fileName ? 'Copy to clipboard' : ''}
                            onClick={() => {
                                if (!formData.fileName) return;
                                navigator.clipboard.writeText(formData.fileName);
                                NotificationStore.showAlert({
                                    type: ToastType.SUCCESS,
                                    message: t('COMMON.COPY_TO_CLIPBOARD')
                                });
                            }}>
                            <span className="after:content-['*'] after:ml-0.5 after:text-secondary">
                                Uploaded File
                            </span>
                            :{fileTypeIcon('ms-excel')}
                            {formData.fileName ? (
                                formData.fileName
                            ) : (
                                <>
                                    No file uploaded —{' '}
                                    <button
                                        type="button"
                                        className="text-primary underline cursor-pointer"
                                        onClick={() => {
                                            const input = document.getElementById(
                                                'upload-completed-Template'
                                            ) as HTMLInputElement | null;
                                            input?.click();
                                        }}>
                                        click here
                                    </button>{' '}
                                    to upload an (.xlsx) file
                                    <input
                                        type="file"
                                        id="upload-completed-Template"
                                        hidden
                                        accept=".xlsx, .xls"
                                        onChange={(e) => {
                                            handleFileUploadAndGetData(e);
                                        }}
                                    />
                                </>
                            )}
                            {formData.fileName && (
                                <i className="pi pi-copy group-hover:visible invisible ml-1" />
                            )}
                        </h5>

                        <div
                            className="flex gap-6 [&>ul]:w-96 [&>ul]:border [&>ul]:rounded-lg [&>ul]:shadow-md [&>ul>div]:p-3  [&>ul>div]:flex [&>ul>div]:flex-wrap [&>ul>div]:gap-3 [&>ul>h4]:text-md [&>ul>h4]:rounded-t-lg [&>ul>h4]:p-2.5 [&>ul>h4]:px-4 [&>ul>h4]:border-b [&>ul>h4]:font-medium [&>ul>div>li]:py-1 [&>ul>div>li]:px-2
                                    [&>ul>div>li]:border [&>ul>div>li]:cursor-pointer [&>ul>div>li]:w-fit [&>ul>div>li]:rounded-2xl [&>ul>h4]:flex [&>ul>h4]:items-center [&>ul>h4]:justify-between [&>ul>h4>i]:after:text-[1rem] [&>ul>h4>i]:after:font-semibold [&>ul>h4>i]:after:absolute 
                                    [&>ul>h4>i]:after:top-1/2 [&>ul>h4>i]:after:left-1/2 [&>ul>h4>i]:after:-translate-y-1/2 [&>ul>h4>i]:after:-translate-x-1/2 [&>ul>div>span]:text-black/40 [&>ul>div>span]:font-medium [&>ul>div>span]:py-2 [&>ul>div>span]:px-1
                                ">
                            <ul className="border-success-green/40">
                                <h4 className="text-success-green bg-success-green/5 border-b-success-green/40">
                                    {t('COMPANY_DETAILS.VALID_PATENTS')}
                                    {isValidatingFile
                                        ? skeletonTemplate('circle')
                                        : patentNumbers() && (
                                              <i
                                                  className={`pi pi-circle-fill relative text-success-green/20 text-2xl after:text-success-green after:content-[attr(data-count)] `}
                                                  data-count={patentNumbers(true).length}
                                                  style={{
                                                      lineHeight: 'normal'
                                                  }}
                                              />
                                          )}
                                </h4>
                                <div>
                                    {!isValidatingFile &&
                                        patentNumbers(true).map((item, index) => (
                                            <li
                                                className="hover:bg-success-green/10 border-success-green/60"
                                                key={index}
                                                title="Copy to clipboard"
                                                onClick={() => {
                                                    navigator.clipboard.writeText(
                                                        item.patentNumber
                                                    );
                                                    NotificationStore.showAlert({
                                                        type: ToastType.SUCCESS,
                                                        message: t('COMMON.COPY_TO_CLIPBOARD')
                                                    });
                                                }}>
                                                {item.patentNumber}
                                            </li>
                                        ))}
                                    {!isValidatingFile && patentNumbers(true).length === 0 && (
                                        <span>{t('COMPANY_DETAILS.NO_PATENTS_FOUND')}</span>
                                    )}
                                    {isValidatingFile && skeletonTemplate('patentItem')}
                                </div>
                            </ul>
                            <ul className="border-secondary-dark-red/30">
                                <h4 className="text-secondary-dark-red bg-secondary-dark-red/5 border-b-secondary-dark-red/30">
                                    {t('COMPANY_DETAILS.INVALID_PATENTS')}
                                    {isValidatingFile
                                        ? skeletonTemplate('circle')
                                        : patentNumbers() && (
                                              <i
                                                  className={`pi pi-circle-fill relative text-2xl text-secondary-dark-red/15 after:text-secondary-dark-red after:content-[attr(data-count)] `}
                                                  data-count={patentNumbers(false).length}
                                                  style={{
                                                      lineHeight: 'normal'
                                                  }}
                                              />
                                          )}
                                </h4>
                                <div>
                                    {!isValidatingFile &&
                                        patentNumbers(false).map((item, index) => (
                                            <li
                                                className="hover:bg-secondary-dark-red/10 border-secondary-dark-red/50"
                                                key={index}
                                                title="Copy to clipboard"
                                                onClick={() => {
                                                    navigator.clipboard.writeText(
                                                        item.patentNumber
                                                    );
                                                    NotificationStore.showAlert({
                                                        type: ToastType.SUCCESS,
                                                        message: t('COMMON.COPY_TO_CLIPBOARD')
                                                    });
                                                }}>
                                                {item.patentNumber}
                                            </li>
                                        ))}
                                    {!isValidatingFile && patentNumbers(false).length === 0 && (
                                        <span>{t('COMPANY_DETAILS.NO_PATENTS_FOUND')}</span>
                                    )}
                                    {isValidatingFile && skeletonTemplate('patentItem')}
                                </div>
                            </ul>
                        </div>
                        <p className="flex justify-center mt-3 text-[0.80rem] text-black/40 font-medium">
                            {isValidatingFile
                                ? skeletonTemplate('text', { height: '0.80rem' })
                                : `Total: ${patentNumbers().length} patents - ${patentNumbers(true).length} valid - ${patentNumbers(false).length} invalid`}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default UpcOptOut;
