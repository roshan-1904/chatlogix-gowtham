export interface UpcOptOutFormData {
    companyName: string;
    requestedDeliveryDate: Date | null;
    referenceNumber: string;
    instructionsAndCommentsAdminPMUsers: string;
    instructionsAndCommentsContactUsers: string;
    patentNumbers: {
        patentNumber: string;
        isValid: boolean;
    }[];
    fileName: string;
}

export interface FileUploadPayload {
    file: File;
    requestId?: number;
    companyId?: number;
    contactUserId?: number;
    PatentPublicationNumbers?: string;
    orderId?: number;
}

export interface FileUploadResponse {
    draftId: number;
    patentNumbers: {
        patentNumber: string;
        isValid: boolean;
    }[];
}
