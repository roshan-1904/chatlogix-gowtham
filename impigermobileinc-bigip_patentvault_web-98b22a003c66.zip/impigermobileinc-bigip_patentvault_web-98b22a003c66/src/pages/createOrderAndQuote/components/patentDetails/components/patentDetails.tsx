import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Form } from '@formio/react';

import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import HttpService from 'core/interceptor/api.handler';

import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_DATA
} from 'constants/progressStepper.constant';
import { PATHS } from 'constants/routes.constant';
import patentDetailsFormBuilderData from '../mocks/patentDetailsForm.mock.json';
import { FLOW, MODE, PATENT_SOURCE_LANGUAGE, ROLE } from 'constants/app.constant';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import {
    STEPPER_DATA_TYPE,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import orderQuoteModuleService, {
    stepperNavigation
} from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { isContactUser } from 'core/utils/utils';
import usersService from 'pages/users/service/users.service';
import { UserInformationType } from 'pages/users/types/createUser.types';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';

const PatentDetails = () => {
    const httpService = new HttpService();
    const navigate = useNavigate();
    const { t } = useTranslation();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const formBuilderData = httpService?.updateJsonDataWithDynamicValues(
        patentDetailsFormBuilderData
    );
    const [initialValue, setInitialValue] = useState<any>(null);
    const loggedInUserId = userDetails.userInfo.userId;
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const loggedInUserCompanyId = userDetails.userInfo.companyId;
    const loggedInUserName = userDetails.userInfo.userFullName;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const selectedCategoryId = quoteOrderData?.info?.selectedCategory?.patentCategoryId;
    const is713Claims =
        selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims'];
    const isEditFlow = quoteOrderData?.info.isEditFlow === true;

    const isAutoPopulate = (field: string) => {
        if (field === 'companyName') {
            const autoPopulate = loggedInUserRoleId === ROLE.CONTACT_USER.roleId;

            return autoPopulate;
        }
    };
    const formData = quoteOrderData?.formData;
    const deliveryDateForClaimsTranslation = formData.patentDetailsPage
        ?.requestedDeliveryDateForClaimsTranslation
        ? new Date(formData.patentDetailsPage?.requestedDeliveryDateForClaimsTranslation as string)
        : null;

    // api
    const getUserDetails = async () => {
        try {
            const userDetailsResponse =
                await usersService.getUserById<UserInformationType>(loggedInUserId);

            if (!userDetailsResponse) return null;

            const salesRepId = userDetailsResponse.userContactInformation?.salesRep ?? null;
            const salesRepName = userDetailsResponse.userContactInformation?.salesRepName ?? null;
            return { salesRepId, salesRepName };
        } catch (error) {
            console.error('Error in fetching getUserDetails(): ', error);
        }
    };

    // handlers
    const onFormChange = (e: any) => {
        const { data } = e;

        const changedField = e.changed?.instance?.component?.key;
        const fetchFormData = JSON.parse(
            JSON.stringify(quoteOrderModuleStore.getData().formData.patentDetailsPage)
        );
        const updatedFormData = data;

        const getCompanyName = () => {
            let companyName;

            if (isEditFlow) {
                companyName = updatedFormData.companyName;
            } else {
                companyName = isAutoPopulate('companyName')
                    ? loggedInUserCompanyId
                    : updatedFormData.companyName;
            }

            return companyName;
        };

        // checkpoint - to avoid unnecessary re-renders
        if (
            changedField === 'ifEpGrantedYesNo' &&
            fetchFormData.ifEpGrantedYesNo === updatedFormData.ifEpGrantedYesNo
        )
            return;

        updatedFormData.companyName = getCompanyName();

        if (!isThisContactUser) {
            /** for ContactUser we do API call to get the SalesRep info. Since they don't have ContactUser DD in UI. */
            updatedFormData.salesRepId = updatedFormData?.contactUser?.salesRepId ?? null;
            updatedFormData.salesRepName = updatedFormData?.contactUser?.salesRepName ?? null;
        }
        if (changedField === 'sourceLanguageData') {
            const { sourceLanguageData } = data;
            updatedFormData.sourceLanguage = sourceLanguageData.id;
            updatedFormData.sourceLanguageName = sourceLanguageData.label;
        }

        if (e.changed && JSON.stringify(updatedFormData) !== JSON.stringify(fetchFormData)) {
            /** set always 'isFormValid' to false when form on change.
                 we set true user once submitted. we can use this for navigation\other purpose.
                 because, the form builder returns 'isValid' flag as true even form is invalid while init rendering.
                 so we handled like this. */
            handleStepperUpdate(updatedFormData?.sourceLanguage as string);
            updateStore(updatedFormData, false);
        }
    };
    const onSubmitChange = (e: any) => {
        /** note: this submit function will be only call when user clicks the 'next' button without any field error.\
             if error means, this function will not be call, rather than form-builder trigger the fields validation (errors). */
        const updatedFormData = e.data;
        const isEpGranted = Boolean(updatedFormData.ifEpGrantedYesNo);

        if (
            isEpGranted &&
            !updatedFormData?.english &&
            !updatedFormData?.french &&
            !updatedFormData?.german
        ) {
            /** if no language is selected in 'EP Granted Claims Translation', then show toast.
             * this checkbox alone cannot handle in formio. so, we handle here. */
            showToastMessage(t('COMMON.EP_CLAIM_TRANSLATION'), ToastType.ERROR);
        } else {
            updateStore(updatedFormData);
            navigateNextPage();
        }
    };
    const navigateNextPage = async () => {
        if (quoteOrderModuleStore?.getData()?.info?.primaryId && !is713Claims) {
            stepperNavigation();
            const currentFlow = isEditFlow ? PATHS.EDIT : PATHS.CREATE;
            const redirectTo: string | null =
                `/${PATHS.ORDER_QUOTE}/${currentFlow}/${stepperStore.getStepperData().stepperInfo.currStep?.stepperPath}`;
            return navigate(redirectTo);
        }

        const redirectTo: string | null = await orderQuoteModuleService.saveDraft();
        if (redirectTo) navigate(redirectTo);
    };

    // update store
    const updateStore = (updatedFormData: any, isValid = true) => {
        const updatedOrderQuoteData = quoteOrderModuleStore.getData();

        updateFormData(updatedOrderQuoteData, updatedFormData);
        updateIsFormValid(updatedOrderQuoteData, isValid);
    };
    const updateFormData = (_quoteOrderData: QuoteOrderModuleStore, updatedFormData: any) => {
        const updatedQuoteOrderFormData = {
            ..._quoteOrderData.formData,
            patentDetailsPage: updatedFormData
        };

        if (
            JSON.stringify(_quoteOrderData.formData.patentDetailsPage) !==
            JSON.stringify(updatedFormData)
        ) {
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    };
    const updateIsFormValid = (_quoteOrderData: QuoteOrderModuleStore, isValid: boolean) => {
        const updatedQuoteOrderIsFormValid = {
            ..._quoteOrderData.isFormValid,
            [PATHS.PATENT_DETAILS]: isValid
        };

        if (_quoteOrderData.isFormValid?.[PATHS.PATENT_DETAILS] !== isValid) {
            quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
        }
    };

    // stepper steps update
    const handleStepperUpdate = (sourceLanguage: string) => {
        // function to handle the stepper update based on source language only for PC flow
        if (
            quoteOrderData?.info.mode === MODE.CREATE_QUOTE &&
            isThisContactUser &&
            selectedCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty]['translation_only']
        ) {
            if (sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH.toLowerCase()) {
                addMoreStepInStepper();
            } else {
                removeLastStepInStepper();
            }
        }
    };
    const addMoreStepInStepper = () => {
        // function to add the summary step in stepper
        try {
            const stepperData = stepperStore.getStepperData();

            const summaryStep: STEPPER_DATA_TYPE = STEPPER_DATA.SUMMARY;
            const isSummaryExists = stepperData?.stepperList?.some(
                (step) => step.stepperId === summaryStep.stepperId
            );
            if (summaryStep && stepperData?.stepperList && !isSummaryExists) {
                const updatedStepperList: STEPPER_DATA_TYPE[] = [
                    ...stepperData.stepperList,
                    summaryStep
                ];

                const updatedStepperData: STEPPER_STATE = {
                    ...stepperData,
                    stepperList: updatedStepperList
                };

                stepperStore?.updateStepper(updatedStepperData);
            }
        } catch (error) {
            console.error(
                'Error while adding the more step in existing stepper (addMoreStepInStepper()): ',
                error
            );
        }
    };
    const removeLastStepInStepper = () => {
        // function to remove the last step in stepper
        try {
            const stepperData = stepperStore.getStepperData();

            if (stepperData?.stepperList?.length === 4) {
                const updatedStepperList: STEPPER_DATA_TYPE[] = [...stepperData.stepperList];
                updatedStepperList.pop();

                const updatedStepperData: STEPPER_STATE = {
                    ...stepperData,
                    stepperList: updatedStepperList
                };

                stepperStore?.updateStepper(updatedStepperData);
            }
        } catch (error) {
            console.error(
                'Error while removing the last step in existing stepper (removeLastStepInStepper()): ',
                error
            );
        }
    };

    // effects
    useEffect(() => {
        const patentFormData = quoteOrderData.formData.patentDetailsPage;
        const isSalesRepAvailable: boolean = Boolean(
            patentFormData?.salesRepId && patentFormData?.salesRepName
        );

        const getInitialData = async () => {
            let moreUserDetails = null;

            if (!isEditFlow && isThisContactUser) {
                if (!isSalesRepAvailable) {
                    /** we shows the 'sales-rep' using selected contact-user.
                     *  but, as ContactUsers(CM/CU) don't have the 'contact-user' field in the form.
                     *  so, we need to get that using API call.
                     *  Note: we could get this field on edit mode via 'Edit-API'. so skip this process on edit mode. */
                    moreUserDetails = await getUserDetails();
                }
            }
            const getSLData = () => {
                interface SourceLanguageData {
                    id: string;
                    label: string;
                }
                const slData: SourceLanguageData | null =
                    patentFormData?.sourceLanguageData ?? null;
                if (slData?.id) return slData; // if already selected, then return that (init load time, we have to set this).

                const { sourceLanguageId, sourceLanguage } = patentFormData || {};
                if (sourceLanguageId && sourceLanguage) {
                    return {
                        id: patentFormData?.sourceLanguage,
                        label: patentFormData?.sourceLanguageName
                    };
                }
            };

            const statutoryDeadline = patentFormData?.statutoryDeadline;
            const statutoryDeadlineDate = patentFormData?.statutoryDeadlineDate;

            const initData = {
                data: {
                    ...patentFormData,

                    // update hidden fields with real-time data
                    selectedCategoryId,
                    roleId: loggedInUserRoleId,
                    mode: quoteOrderData?.info?.mode,
                    flow: isEditFlow ? FLOW.EDIT : FLOW.CREATE,
                    ifEpGrantedYesNo: is713Claims ? true : patentFormData?.ifEpGrantedYesNo, // default value for 713 claims.
                    quoteStatus: quoteOrderData?.info?.statusId, // quote status
                    requestedBy: loggedInUserName,
                    salesRepId: patentFormData?.salesRepId ?? moreUserDetails?.salesRepId,
                    salesRepName: patentFormData?.salesRepName ?? moreUserDetails?.salesRepName,
                    sourceLanguageFlag: formData.companyDetailsPage?.patentDetails?.sourceLanguage,
                    sourceLanguageData: getSLData(),
                    statutoryDeadlineDate: statutoryDeadlineDate ?? statutoryDeadline ?? null,
                    requestedDeliveryDateForClaimsTranslation: deliveryDateForClaimsTranslation,
                    selectedCompanyPoRequired:
                        formData.companyDetailsPage?.selectedCompany?.isPoRequired
                }
            };

            setInitialValue(initData);
        };

        getInitialData();

        const updatedQuoteOrderIsFormValid = {
            ...quoteOrderData.isFormValid,
            [PATHS.COMPANY_DETAILS]: false
        };
        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);

        /** set PM for Additional-Info page earlier. */
        orderQuoteModuleService.setAdditionalInfoPM();
    }, []);

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const isEpClaimTranslationValidationFlag =
        quoteOrderData?.info?.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'] ||
        quoteOrderData?.info?.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];

    return (
        <div
            key={initialValue}
            className={`patentDetailsPage ${isEpClaimTranslationValidationFlag ? 'epClaimTranslationValidation' : ''}`}
            data-testid="patentDetailsPage">
            <Form
                form={formBuilderData}
                submission={initialValue}
                onChange={(e: any) => onFormChange(e)}
                onSubmit={(e: any) => onSubmitChange(e)}
                data-testid="formComponent"
            />
        </div>
    );
};

export default PatentDetails;
