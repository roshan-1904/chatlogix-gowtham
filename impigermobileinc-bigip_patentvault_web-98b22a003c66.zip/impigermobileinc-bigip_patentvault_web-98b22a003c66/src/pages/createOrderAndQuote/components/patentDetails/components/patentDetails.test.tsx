import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import PatentDetails from './patentDetails';
import AuthStore from 'core/store/authStore/authStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import HttpService from 'core/interceptor/api.handler';
import { useNavigate } from 'react-router-dom';
import usersService from 'pages/users/service/users.service';
import stepperStore from 'core/store/stepperStore/progressStepper.store';

jest.mock('@formio/react', () => ({
    Form: jest.fn(() => <div>Mock Form</div>)
}));
jest.mock('core/interceptor/api.handler');
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));
jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn()
}));
jest.mock('core/store/authStore/authStore');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('core/store/stepperStore/progressStepper.store');
jest.mock('pages/createOrderAndQuote/services/orderQuoteModule.service');
jest.mock('pages/users/service/users.service');

describe('PatentDetails Component', () => {
    let mockAuthStore: any;
    let mockQuoteOrderStore: any;
    let mockStepperStore: any;
    let mockHttpService: any;

    beforeEach(() => {
        mockAuthStore = {
            getUserInfo: jest.fn(() => ({
                userInfo: {
                    userId: 'user123',
                    roleId: 'role123',
                    companyId: 'company123',
                    userFullName: 'John Doe'
                }
            }))
        };
        AuthStore.getUserInfo = mockAuthStore.getUserInfo;

        mockQuoteOrderStore = {
            getData: jest.fn(() => ({
                info: {
                    selectedCategory: { patentCategoryId: 'category123' },
                    isEditFlow: false,
                    mode: 'CREATE_QUOTE'
                },
                formData: {
                    patentDetailsPage: {}
                },
                isFormValid: {}
            })),
            subscribe: jest.fn(),
            updatePage: jest.fn()
        };
        quoteOrderModuleStore.getData = mockQuoteOrderStore.getData;
        quoteOrderModuleStore.subscribe = mockQuoteOrderStore.subscribe;

        mockStepperStore = {
            getStepperData: jest.fn(() => ({
                stepperList: [{ stepperId: 1 }, { stepperId: 2 }, { stepperId: 3 }]
            })),
            updateStepper: jest.fn()
        };
        stepperStore.getStepperData = mockStepperStore.getStepperData;
        stepperStore.updateStepper = mockStepperStore.updateStepper;

        mockHttpService = {
            updateJsonDataWithDynamicValues: jest.fn((data) => data)
        };
        HttpService.prototype.updateJsonDataWithDynamicValues =
            mockHttpService.updateJsonDataWithDynamicValues;

        jest.clearAllMocks();
    });

    test('renders the component with initial form data', () => {
        render(<PatentDetails />);

        waitFor(() => {
            expect(mockAuthStore.getUserInfo).toHaveBeenCalled();
        });
        waitFor(() => {
            expect(screen.getByText('Mock Form')).toBeInTheDocument();
            expect(mockQuoteOrderStore.getData).toHaveBeenCalled();
        });
    });

    test('handles form change correctly', () => {
        render(<PatentDetails />);

        const form = screen.getByTestId('patentDetailsPage');

        waitFor(() => {
            fireEvent.change(form);
            expect(mockQuoteOrderStore.updatePage).toHaveBeenCalled();
        });
    });

    test('handles form submission correctly', () => {
        const navigate = useNavigate as jest.Mock;
        const mockNavigate = jest.fn();
        navigate.mockReturnValue(mockNavigate);
        render(<PatentDetails />);
        waitFor(() => {
            const form = screen.getByTestId('patentDetailsPage');
            fireEvent.submit(form);
            expect(mockQuoteOrderStore.updatePage).toHaveBeenCalled();
        });
    });

    test('handles effect logic and sets initial data correctly', () => {
        const mockGetUserDetails = jest.fn();
        usersService.getUserById = mockGetUserDetails.mockResolvedValue({
            userContactInformation: { salesRep: 'salesRep123', salesRepName: 'Sales Rep' }
        });

        render(<PatentDetails />);
        waitFor(() => {
            expect(mockGetUserDetails).toHaveBeenCalled();
        });

        waitFor(() => {
            expect(mockQuoteOrderStore.updatePage).toHaveBeenCalledWith(
                'isFormValid',
                expect.any(Object)
            );
        });
    });

    test('adds step to the stepper based on language', () => {
        render(<PatentDetails />);

        waitFor(() => {
            fireEvent.change(screen.getByText('Mock Form'), { target: { value: 'english' } });
            expect(mockStepperStore.updateStepper).toHaveBeenCalled();
        });
    });
});
