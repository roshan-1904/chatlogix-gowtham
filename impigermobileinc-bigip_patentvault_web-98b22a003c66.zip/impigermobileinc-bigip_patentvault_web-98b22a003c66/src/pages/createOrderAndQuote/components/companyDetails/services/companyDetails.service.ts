import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { PatentDetails } from '../types/companyDetails.type';
import { ROLE } from 'constants/app.constant';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

/**
 * Fetches company data for the given user ID.
 * @param {number} loggedInUserId
 * @returns {Promise<T>} A promise that resolves with the fetched company data.
 */
const getCompanyData = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANY_DETAILS.GET_COMPANY_LIST}`;
    try {
        const response = await httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching company data:', error);
        throw error;
    }
};

/**
 * Fetches contact user data for the given company ID.
 * @param {number} companyId
 * @returns {Promise<T>} A promise that resolves with the fetched contact user data.
 */
const getContactUserData = async <T>(companyId: number): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANY_DETAILS.GET_CONTACT_USER_LIST}/${companyId}/${ROLE.CONTACT_MANAGER.roleId},${ROLE.CONTACT_USER.roleId}`;
    try {
        const response = await httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching contact user data:', error);
        throw error;
    }
};

/**
 * Fetches patent details for the given company ID.
 * @param {string} publicationNumber
 * @returns {Promise<T>} A promise that resolves with the fetched patent details.
 */
const getPatentDetails = async (
    publicationNumber: string,
    serviceTypeCategoryId: number
): Promise<PatentDetails> => {
    const apiUrl = `${END_POINT.COMPANY_DETAILS.GET_PATENT_DETAILS}?publicationNumber=${publicationNumber}&serviceTypeId=${serviceTypeCategoryId}`;
    try {
        const response = await httpService.get<PatentDetails>(apiUrl, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error fetching patent details:', error);
        throw error;
    }
};

const companyDetailsService = {
    getCompanyData,
    getContactUserData,
    getPatentDetails
};

export default companyDetailsService;
