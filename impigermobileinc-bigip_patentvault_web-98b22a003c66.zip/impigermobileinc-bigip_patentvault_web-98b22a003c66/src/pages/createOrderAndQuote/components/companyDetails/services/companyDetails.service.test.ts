import HttpService from 'core/interceptor/api.handler';
import {
    CompanyListResponse,
    ContactUserListResponse,
    PatentDetailsResponse
} from './companyDetails.service.test.mock';
import companyDetailsService from './companyDetails.service';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getCompanyData', () => {
        it('should fetch getCompanyData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(CompanyListResponse);
            const result = await companyDetailsService.getCompanyData();
            expect(result).toEqual(CompanyListResponse);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(companyDetailsService.getCompanyData()).rejects.toThrow(mockError);
        });
    });

    describe('getContactUserData', () => {
        const companyId = 1;
        it('should fetch getContactUserData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(ContactUserListResponse);
            const result = await companyDetailsService.getContactUserData(companyId);
            expect(result).toEqual(ContactUserListResponse);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(companyDetailsService.getContactUserData(companyId)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getPatentDetails', () => {
        const publicationNumber = '123456';
        const serviceTypeCategoryId = 1;
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue(PatentDetailsResponse);
            const result = await companyDetailsService.getPatentDetails(
                publicationNumber,
                serviceTypeCategoryId
            );
            expect(result).toEqual(PatentDetailsResponse);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                companyDetailsService.getPatentDetails(publicationNumber, serviceTypeCategoryId)
            ).rejects.toThrow(mockError);
        });
    });
});
