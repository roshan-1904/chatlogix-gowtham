export const CompanyListResponse = [
    {
        id: 1,
        name: 'Company 1',
        companyType: 'Company Type 1',
        parentCompanyId: null,
        subCompanyId: null,
        isPoRequired: true
    }
];

export const ContactUserListResponse = [
    {
        firstName: 'test',
        fullName: 'test user',
        id: 1,
        email: 'test@gmail.com',
        lastName: 'user',
        middleName: 'test1',
        roleId: 1,
        salesRepId: 1,
        salesRepName: 'user2'
    }
];

export const PatentDetailsResponse = [
    {
        salesRepId: 1,
        salesRepName: 'test'
    }
];
