import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';

export const PATENT_WARNING = {
    [SERVICE_TYPE_ID.patent_cooperation_treaty]: 'COMPANY_DETAILS.PATENT_WARNING_PCT', // PCT
    [SERVICE_TYPE_ID.european_patent]: 'COMPANY_DETAILS.PATENT_WARNING_EP', // EP
    [SERVICE_TYPE_ID.paris_convention_treaty]: 'COMPANY_DETAILS.PATENT_WARNING_PC' // PC
};

export const SAMPLE_PUB_NUMBER = {
    [SERVICE_TYPE_ID.patent_cooperation_treaty]: 'COMPANY_DETAILS.SAMPLE_PUB_NUMBER_FOR_PCT', // PCT
    [SERVICE_TYPE_ID.european_patent]: 'COMPANY_DETAILS.SAMPLE_PUB_NUMBER_FOR_EP', // EP
    [SERVICE_TYPE_ID.paris_convention_treaty]: 'COMPANY_DETAILS.SAMPLE_PUB_NUMBER_FOR_PC' // PC
};

export const INSTRUCTION_FOR_RECORDAL = {
    [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
        [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty]?.recordal}`]:
            'COMPANY_DETAILS.INSTRUCTION_FOR_RECORDAL_PCT'
    },
    [SERVICE_TYPE_ID.european_patent]: {
        [`${CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]?.recordal}`]:
            'COMPANY_DETAILS.INSTRUCTION_FOR_RECORDAL_EP'
    }
};
