import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CompanyDetails from './companyDetails';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore from 'core/store/authStore/authStore';
import SelectCompanyDetailsService from '../services/companyDetails.service';

// Mock the necessary modules and functions
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(),
    updatePage: jest.fn()
}));

jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn()
}));

jest.mock('../services/companyDetails.service', () => ({
    getCompanyData: jest.fn(),
    getContactUserData: jest.fn(),
    getPatentDetails: jest.fn()
}));

jest.mock('pages/users/service/users.service', () => ({
    getUserById: jest.fn()
}));

describe('CompanyDetails Component', () => {
    const mockQuoteOrderData = {
        info: {
            isEditFlow: false,
            selectedService: { serviceTypeId: 1 },
            selectedCategory: { patentCategoryId: 1 },
            mode: 'CREATE_QUOTE'
        },
        formData: {
            companyDetailsPage: null
        },
        isFormValid: {}
    };

    const mockUserDetails = {
        userInfo: {
            userId: 1,
            roleId: 1,
            companyId: 1,
            userFullName: 'Test User'
        }
    };

    beforeEach(() => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue(mockQuoteOrderData);
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue(mockUserDetails);
    });

    test('renders CompanyDetails component', () => {
        render(<CompanyDetails />);
        expect(screen.getByTestId('companyDetailsPage')).toBeInTheDocument();
    });

    test('renders company name dropdown', () => {
        render(<CompanyDetails />);
        expect(screen.getByTestId('companyNameDropdown')).toBeInTheDocument();
    });

    test('renders contact user dropdown', () => {
        render(<CompanyDetails />);
        expect(screen.getByTestId('contactUserDropdown')).toBeInTheDocument();
    });

    test('renders publication number input', () => {
        render(<CompanyDetails />);
        expect(screen.getByTestId('publicationNumberInput')).toBeInTheDocument();
    });

    test('renders verify button', () => {
        render(<CompanyDetails />);
        expect(screen.getByTestId('verifyButton')).toBeInTheDocument();
    });

    test('renders patent details section when formDetails.patentDetails.isShow is true', () => {
        render(<CompanyDetails />);

        waitFor(() => {
            fireEvent.click(screen.getByTestId('verifyButton'));
            expect(screen.getByTestId('patentDetailsContainer')).toBeInTheDocument();
        });
    });

    test('handles company selection', () => {
        const mockCompanyList = [{ id: 1, name: 'Test Company' }];
        (SelectCompanyDetailsService.getCompanyData as jest.Mock).mockResolvedValue(
            mockCompanyList
        );

        render(<CompanyDetails />);

        waitFor(() => {
            fireEvent.change(screen.getByTestId('companyNameDropdown'), {
                target: { value: mockCompanyList[0] }
            });
            expect(screen.getByTestId('companyNameDropdown')).toHaveValue(mockCompanyList[0].id);
        });
    });

    test('handles contact user selection', () => {
        const mockContactUserList = [{ id: 1, fullName: 'Test User' }];
        (SelectCompanyDetailsService.getContactUserData as jest.Mock).mockResolvedValue(
            mockContactUserList
        );

        render(<CompanyDetails />);

        waitFor(() => {
            fireEvent.change(screen.getByTestId('contactUserDropdown'), {
                target: { value: mockContactUserList[0] }
            });
            expect(screen.getByTestId('contactUserDropdown')).toHaveValue(
                mockContactUserList[0].id
            );
        });
    });

    test('handles publication number input change', () => {
        render(<CompanyDetails />);
        const input = screen.getByTestId('publicationNumberInput');
        fireEvent.change(input, { target: { value: '123456' } });
        expect(input).toHaveValue('123456');
    });

    test('displays error message for duplicate publication number', () => {
        render(<CompanyDetails />);
        const input = screen.getByTestId('publicationNumberInput');
        waitFor(() => {
            fireEvent.change(input, { target: { value: '123456, 123456' } });
            fireEvent.keyUp(input);
            expect(screen.getByTestId('duplicatePublicationNumberError')).toBeInTheDocument();
        });
    });

    test('displays error message for missing publication number', () => {
        render(<CompanyDetails />);
        waitFor(() => {
            fireEvent.click(screen.getByTestId('verifyButton'));
            waitFor(() => {
                expect(screen.getByTestId('patentVerificationError')).toBeInTheDocument();
            });
        });
    });

    test('calls getPatentDetails on verify button click', async () => {
        render(<CompanyDetails />);
        fireEvent.change(screen.getByTestId('publicationNumberInput'), {
            target: { value: '123456' }
        });
        fireEvent.click(screen.getByTestId('verifyButton'));
        await waitFor(() => {
            expect(SelectCompanyDetailsService.getPatentDetails).toHaveBeenCalled();
        });
    });

    test('handles form submission', async () => {
        render(<CompanyDetails />);
        fireEvent.click(screen.getByTestId('submitCompanyDetailsButton'));
        await waitFor(() => {
            expect(screen.getByTestId('companyDetailsPage')).toBeInTheDocument();
        });
    });
});
