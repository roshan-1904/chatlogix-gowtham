import { useEffect, useMemo, useState } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { useTranslation } from 'react-i18next';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import SelectCompanyDetailsService from '../services/companyDetails.service';
import {
    Company,
    ContactUser,
    CompanyDetailsForm,
    PatentDetails
} from '../types/companyDetails.type';
import {
    COMMON_CONSTANTS,
    MODE,
    PATENT_SOURCE_LANGUAGE,
    ROLE,
    SERVICE_TYPE_CATEGORY_ID
} from 'constants/app.constant';
import { PATHS } from 'constants/routes.constant';
import { formatDate, isContactUser } from 'core/utils/utils';

import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_DATA
} from 'constants/progressStepper.constant';
import {
    INSTRUCTION_FOR_RECORDAL,
    PATENT_WARNING,
    SAMPLE_PUB_NUMBER
} from '../constants/companyDetails.constant';
import { dropDownStyle, inputStyle } from 'constants/styles.constant';
import { CompanyDetailsData } from 'core/store/orderQuoteStore/orderQuote.type.store';
import alertRedIcon from 'assets/images/alert-red-icon.svg';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import {
    STEPPER_DATA_TYPE,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import { UserInformationType } from 'pages/users/types/createUser.types';
import usersService from 'pages/users/service/users.service';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import UpcOptOut from '../../epUpcOptOut/epUpcOptOut';
import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';

// eslint-disable-next-line complexity
const CompanyDetails = () => {
    const formDetailsInit: CompanyDetailsForm = {
        companyName: {
            isReadonly: false,
            isAutoPopulate: true,
            isMandatory: true,
            isError: false
        },
        contactUser: {
            isShow: true,
            isReadonly: false,
            isAutoPopulate: false,
            isMandatory: true,
            isError: false
        },
        publicationNumber: {
            isReadonly: false,
            isMandatory: true,
            isError: false
        },
        patentDetails: {
            isShow: true,
            dataNotFoundForPatent: false
        }
    };

    const { t } = useTranslation();
    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const [companyList, setCompanyList] = useState<Company[]>([]);
    const [contactUserList, setContactUserList] = useState<ContactUser[]>([]);
    const [selectedCompany, setSelectedCompany] = useState<Company | null>();
    const [selectedContact, setSelectedContact] = useState<ContactUser | null>();
    const [publicationNumber, setPublicationNumber] = useState<string | null>();
    const [patentDetails, setPatentDetails] = useState<PatentDetails | null>();
    const [publicationNumberExampleText, setPublicationNumberExampleText] = useState<string>();
    const [formDetails, setFormDetails] = useState<CompanyDetailsForm>(formDetailsInit);
    const [isFormSubmitting, setIsFormSubmitting] = useState<boolean>();
    const [isInitialRendering, setIsInitialRendering] = useState<boolean>(true);
    const [patentVerificationError, setPatentVerificationError] = useState<{
        hasError: boolean;
        errorMessage: string;
    }>({ hasError: false, errorMessage: '' });
    const [hasDuplicates, setHasDuplicates] = useState(false);
    const [invalidFormat, setInvalidFormat] = useState(false);
    const [upcOptOutPatentNumbers, setUpcOptOutPatentNumbers] = useState<string[]>([]);

    const loggedInUserId = userDetails.userInfo.userId;
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isThisCUserExcludedSalesRep = isContactUser(loggedInUserRoleId, true);
    const isEditFlow = quoteOrderData.info.isEditFlow === true;
    const isThisQuoteCreation = quoteOrderData.info.mode === MODE.CREATE_QUOTE;
    const selectedService = quoteOrderData?.info.selectedService;
    const selectedCategory = quoteOrderData.info.selectedCategory?.patentCategoryId;
    const EP = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent];
    const isEP = selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent;
    const isPCT = selectedService?.serviceTypeId === SERVICE_TYPE_ID.patent_cooperation_treaty;
    const isEpUpcOptOut = isEP && selectedCategory === EP.upc_opt_out;

    // init
    const formDataSetup = (): CompanyDetailsForm => {
        let updatedFormData = { ...formDetails };

        updatedFormData = {
            ...formDetails,
            companyName: {
                ...formDetails?.companyName,
                // do not Auto-Populate the 'CompanyName' for the staff-users. they can select by himself.
                isAutoPopulate: userDetails.userInfo.roleId === ROLE.CONTACT_USER.roleId,
                // isAutoPopulate: !isThisStaffUser,
                isReadonly: isEditFlow || userDetails.userInfo.roleId === ROLE.CONTACT_USER.roleId
            },
            contactUser: {
                ...formDetails?.contactUser,
                // hide the 'ContactUser' for the 'CM/CU'.
                isShow: !isThisCUserExcludedSalesRep,
                isMandatory: !isThisCUserExcludedSalesRep,
                isReadonly: isEditFlow
            },
            publicationNumber: {
                isReadonly: isEditFlow
            },
            patentDetails: {
                ...formDetails?.patentDetails,
                isShow: false // make True when user click verify button with 'PublicationNumber'.
            }
        };
        setFormDetails(updatedFormData);
        return updatedFormData;
    };

    // api
    const getCompanyData = async (): Promise<Company[] | null> => {
        try {
            /** BE will send 'company-list' based on the logged-in user-id with help of token. 
                 we not need to send any param. */
            const companyListResponse: Company[] =
                await SelectCompanyDetailsService?.getCompanyData();

            setCompanyList(companyListResponse);

            return companyListResponse;
        } catch (error) {
            console.error('Error in fetching company list:', error);
            return null;
        }
    };
    const getContactUserData = async (companyId: number) => {
        try {
            const data: ContactUser[] =
                await SelectCompanyDetailsService?.getContactUserData(companyId);
            setContactUserList(data);
        } catch (error) {
            console.error('Error in fetching contact user list:', error);
        }
    };
    const getPatentDetails = async () => {
        const serviceTypeCategoryId = handleServiceTypeCategoryId();

        if (!publicationNumber) {
            // Set 'PublicationNumber' as Error if user clicks Verify button without input.
            setFormDetails({
                ...formDetails,
                publicationNumber: { ...formDetails.publicationNumber, isError: true }
            });
            return;
        }

        try {
            const isPatentVerificationReq: boolean = isPatentVerificationRequired();
            if (isPatentVerificationReq) {
                const patentData: PatentDetails =
                    await SelectCompanyDetailsService?.getPatentDetails(
                        publicationNumber.trim(),
                        serviceTypeCategoryId
                    );

                if (patentData) {
                    handlePatentData(patentData);
                } else {
                    // show the UI - no data found
                    setFormDetails({
                        ...formDetails,
                        patentDetails: {
                            ...formDetails.patentDetails,
                            dataNotFoundForPatent: true
                        }
                    });

                    return;
                }
            } else {
                patentDetailsSection(true);
            }
        } catch (error) {
            console.error('Error in fetching patent details:', error);
        }
    };
    const getUserDetails = async (existingPatentDetailsData: any) => {
        try {
            const userDetailsResponse: UserInformationType =
                await usersService.getUserById<UserInformationType>(loggedInUserId);

            if (userDetailsResponse) {
                const salesRepId = userDetailsResponse.userContactInformation?.salesRep ?? null;
                const salesRepName =
                    userDetailsResponse.userContactInformation?.salesRepName ?? null;

                const updatedPatentDetails: PatentDetails = {
                    ...(existingPatentDetailsData ?? {}),
                    salesRepId: salesRepId ?? null,
                    salesRepName: (salesRepName !== '' && salesRepName) || null
                };
                setPatentDetails(updatedPatentDetails);
            }
        } catch (error) {
            console.error('Error in fetching getUserDetails(): ', error);
        }
    };

    // action handlers
    const handlePatentData = (patentData: PatentDetails) => {
        // set API data to hidden duplicate fields to handle the dirty against count fields
        patentData.originalAbstractWordCount = patentData?.abstractWordCount;
        patentData.originalDrawingsWordCount = patentData?.drawingsWordCount;
        patentData.originalNumberOfDrawings = patentData?.numberOfDrawings;
        patentData.originalDescriptionWordCount = patentData?.descriptionWordCount;
        patentData.originalSpecificationWordCount = patentData?.specificationWordCount;
        patentData.originalNumberOfClaims = patentData?.numberOfClaims;
        patentData.originalNumberOfIndependentClaims = patentData?.numberOfIndependentClaims;
        patentData.originalApplicationClaimsPriority = patentData?.applicationClaimsPriority;
        patentData.originalEstSequenceListing = patentData?.estSequenceListing;
        patentData.originalClaimsWordCount = patentData?.claimsWordCount;
        patentData.originalDrawingsPageCount = patentData?.drawingsPageCount;
        patentData.originalClaimsPageCount = patentData?.claimsPageCount;
        patentData.originalApplicantCount = patentData?.applicantCount;
        patentData.originalEstTotalPages = patentData?.estTotalPages;
        patentData.originalStatutoryDeadline = patentData?.statutoryDeadlineDate;
        patentData.originalNumberOfPriorityClaims = patentData?.numberOfPriorityClaims;

        if (patentData?.sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH) {
            patentData.patentTitleWordCount = patentData?.title
                ? patentData.title.split(/[\s-]+/).length
                : 0;
        } else if (patentData?.sourceLanguage === PATENT_SOURCE_LANGUAGE.FRENCH) {
            patentData.patentTitleWordCount = patentData?.titleFR
                ? patentData.titleFR.split(/[\s-]+/).length
                : 0;
        } else if (patentData?.sourceLanguage === PATENT_SOURCE_LANGUAGE.GERMANY) {
            patentData.patentTitleWordCount = patentData?.titleDE
                ? patentData.titleDE.split(/[\s-]+/).length
                : 0;
        }

        if (
            selectedCategory === EP.translation_only ||
            selectedCategory === EP['translation_&_validation']
        ) {
            if (
                (patentData.validationDeadlineUP === null ||
                    patentData.validationDeadlineUP === undefined ||
                    patentData.validationDeadlineUP === '') &&
                patentData?.patentPublicationDate !== null &&
                patentData?.patentPublicationDate !== undefined &&
                patentData?.patentPublicationDate !== ''
            ) {
                const value = futureDate1Mon(patentData?.patentPublicationDate);
                patentData.validationDeadlineUP = value;
            }
        }
        setPatentDetails({ ...patentDetails, ...patentData });

        patentDetailsSection(true);

        const updatedCompanyDetailsPage = {
            /** can't use state(this form state for store). we don't subscribe store.
                 so we can't get the latest data to update. 
                better to mention all the form state while update store. */
            companyList,
            selectedCompany,
            selectedContact,
            contactUserList,
            publicationNumber,
            formData: formDetails,
            patentDetails: patentData
        };

        const updatedPatentDetailsPageData = {
            /** some fields has value on API response, but those fields may 'Enter by user' option.
                     so, remove values for those */
            ...patentData
            // estTotalPages: null,
            // originalEstTotalPages: null
        };

        // update store - hold the other form data while update the store
        const updatedQuoteOrderFormData = {
            ...quoteOrderData?.formData, // keep other forms data
            companyDetailsPage: updatedCompanyDetailsPage,
            additionalInfoPage: {
                ...quoteOrderModuleStore.getData().formData.additionalInfoPage,
                ...patentData
            },
            patentDetailsPage: updatedPatentDetailsPageData
        };
        quoteOrderModuleStore?.updatePage('formData', updatedQuoteOrderFormData);
    };
    const handlerSelectedCompany = (value: Company) => {
        setSelectedCompany(value);
        getContactUserData(value?.id);

        // reset the contact user after company change
        resetContactUserAfterCompanyChange();
        const infoUpdate = {
            ...quoteOrderData?.info,
            requestCurrencyId: value?.requestCurrencyId
        };
        quoteOrderModuleStore.updatePage('info', infoUpdate);
    };
    const handlerSelectedContact = (value: ContactUser) => {
        setSelectedContact(value);

        const updatedPatentDetails: PatentDetails = {
            ...patentDetails,
            salesRepId: value.salesRepId ?? null,
            salesRepName: (value.salesRepName !== '' && value.salesRepName) || null
        };
        setPatentDetails(updatedPatentDetails);
    };
    const publicationNumberChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const currentPublicationNumber = event.target.value;
        setPublicationNumber(currentPublicationNumber);

        /* we should clear the error msg while user enter the Pub-Num. 
            but the user once trigger the submission, then leave this error handling here. 
            instead, we handle the same process in useEffect for all the fields. */
        if (isFormSubmitting) return;

        setFormDetails({
            ...formDetails,
            publicationNumber: {
                ...formDetails.publicationNumber,
                isError: currentPublicationNumber === '' ? true : false
            }
        });
    };
    const isFormValid = () => {
        /* since we using custom form fields, check form is valid on each onChange event.
        this function should be called in every onChange and update the boolean result to the Store. */

        /** in this validation 'selectedContact' is optional for only 'CM/CU'. 
        because the 'CM/CU' dd is hidden for these roles. */
        /** patentDetails is we shows initially without any validation for only Recordal (isPatentVerificationRequired()).
         *  so we can skip this validation for Recordal category.
         *  and, we have some values initially in the 'patentDetails{}', so, check the '.title' property
         *  to ensure the API call is happen and the value are stored correctly in this 'patentDetails{}' instead just check 'patentDetails' alone.   */
        const isPatentVerificationReq: boolean = isPatentVerificationRequired();
        const isValid: boolean =
            !!selectedCompany && // company name
            (isThisCUserExcludedSalesRep ? true : !!selectedContact) && // contact user
            !!publicationNumber && // publication number input
            hasDuplicates === false && // publication should not contain duplicates
            invalidFormat === false && // publication should not contain invalid format
            (isPatentVerificationReq ? !!patentDetails?.title : true); // patent details section

        const isUpcOptOutValid =
            !!selectedCompany && // company name
            (isThisCUserExcludedSalesRep ? true : !!selectedContact) &&
            (upcOptOutPatentNumbers?.length ?? 0) > 0;
        // contact user

        const updatedQuoteOrderIsFormValid = {
            ...quoteOrderData.isFormValid,
            [PATHS.COMPANY_DETAILS]: isEpUpcOptOut ? isUpcOptOutValid : isValid
        };

        if (
            JSON.stringify(quoteOrderModuleStore.getData().isFormValid[PATHS.COMPANY_DETAILS]) !==
            JSON.stringify(isEpUpcOptOut ? isUpcOptOutValid : isValid)
        ) {
            quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
        }
    };
    const formFieldsValidations = () => {
        const updatedFormData: CompanyDetailsForm = {
            ...formDetails,
            companyName: {
                ...formDetails.companyName,
                isError: !selectedCompany
            },
            contactUser: {
                ...formDetails.contactUser,
                isError: !selectedContact
            },
            publicationNumber: {
                ...formDetails.publicationNumber,
                isError: !publicationNumber
            },
            isDuplicate: {
                ...formDetails.isDuplicate,
                isError: hasDuplicates
            }
        };

        if (JSON.stringify(updatedFormData) !== JSON.stringify(formDetails)) {
            setFormDetails(updatedFormData);
        }
    };
    const resetContactUserAfterCompanyChange = () => {
        // reset the contact user
        setSelectedContact(null);

        // reset the selected contact user in the store
        const updatedQuoteOrderData = { ...quoteOrderData };
        if (
            updatedQuoteOrderData.formData.companyDetailsPage &&
            updatedQuoteOrderData.formData.companyDetailsPage.selectedContact !== null
        ) {
            updatedQuoteOrderData.formData.companyDetailsPage.selectedContact = null;
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderData.formData);
        }
    };
    const handleServiceTypeCategoryId = () => {
        const selectedServiceTypeId = quoteOrderData.info.selectedService?.serviceTypeId;
        if (selectedServiceTypeId === SERVICE_TYPE_ID.european_patent) {
            const serviceTypeCategoryId = SERVICE_TYPE_CATEGORY_ID.Epo;
            return serviceTypeCategoryId;
        } else {
            const serviceTypeCategoryId = SERVICE_TYPE_CATEGORY_ID.Wipo;
            return serviceTypeCategoryId;
        }
    };
    const handleDuplicatePublicationNumber = () => {
        if (!publicationNumber) {
            return;
        }
        const values = publicationNumber.split(',').map((item) => item.trim().toLowerCase());

        const uniqueValues = new Set(values);
        const hasDuplicatesValues = uniqueValues.size !== values.length;
        setHasDuplicates(hasDuplicatesValues);
        if (hasDuplicatesValues) return;

        if (!isRecordalCategory()) return;
        const avoidForPCT = ['ep'];
        const avoidForEP = ['pct', 'wo'];
        const isInvalidFormat = values.some((value) =>
            isPCT
                ? avoidForPCT.some((prefix) => value.startsWith(prefix))
                : avoidForEP.some((prefix) => value.startsWith(prefix))
        );
        setInvalidFormat(isInvalidFormat);
        isFormValid();
    };
    const onSubmit = () => {
        setIsFormSubmitting(true);
        // update 'formData' state on Submit event
        formFieldsValidations();

        // specific validation for UPC Opt-Out
        if (isEpUpcOptOut && (upcOptOutPatentNumbers?.length ?? 0) <= 0) {
            NotificationStore.showAlert({
                type: ToastType.ERROR,
                message: t('COMPANY_DETAILS.UPC_OPT_OUT_PATENT_NUM_REQUIRED')
            });
        }
    };
    const handleSubmit = (event: { preventDefault: () => void }) => {
        event.preventDefault();
        getPatentDetails();
    };

    // helper functions
    const patentDetailsSection = (
        isShow: boolean,
        existingFormDetails?: CompanyDetailsForm | null
    ) => {
        const updatedFormDetails = existingFormDetails ?? formDataSetup();
        setFormDetails({
            ...updatedFormDetails,
            patentDetails: { ...updatedFormDetails, isShow }
        });
    };
    const getPubNumExampleText = (): string => {
        const serviceId = quoteOrderData.info.selectedService?.serviceTypeId;
        const categoryId = quoteOrderData.info.selectedCategory?.patentCategoryId;

        let exampleText: string = '';

        if (
            serviceId &&
            categoryId &&
            (categoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].recordal ||
                categoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal)
        ) {
            exampleText = INSTRUCTION_FOR_RECORDAL[serviceId][categoryId];
        } else if (serviceId) {
            exampleText = SAMPLE_PUB_NUMBER[serviceId];
        }

        return exampleText;
    };
    const isPatentVerificationRequired = (): boolean => {
        /** we don't API call for 'recordal' categories. so hide the warning for 'recordal' categories.
             this warning indicates, 'system will fetch details by given patent number'. */
        /** currently this function will return false for Recordal category */
        const isRequired: boolean =
            quoteOrderData.info.selectedCategory?.patentCategoryId !==
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].recordal &&
            quoteOrderData.info.selectedCategory?.patentCategoryId !==
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal;

        return isRequired;
    };
    const isPatentError = () => {
        // determine if there is an errors
        const hasError =
            formDetails.publicationNumber?.isError ||
            formDetails.patentDetails.dataNotFoundForPatent ||
            (isFormSubmitting && !patentDetails?.title);

        let errorMessage: string = '';
        // set error message based on different conditions
        if (formDetails.publicationNumber?.isError) {
            errorMessage = 'COMPANY_DETAILS.PUBLICATION_NUMBER_ERROR_LABEL';
        } else if (formDetails.patentDetails.dataNotFoundForPatent) {
            errorMessage = 'COMPANY_DETAILS.PUBLICATION_NUMBER_NOT_FOUND';
        } else if (isFormSubmitting && !patentDetails?.title && isPatentVerificationRequired()) {
            errorMessage = 'COMPANY_DETAILS.VERIFICATION_PENDING_ERROR_LABEL';
        }

        const updatedPatentVerificationError = { hasError: hasError ?? false, errorMessage };

        // update state only if the message has changed
        if (
            JSON.stringify(updatedPatentVerificationError) !==
            JSON.stringify(patentVerificationError)
        ) {
            setPatentVerificationError(updatedPatentVerificationError);
        }
    };
    const autoPopulateCompanyName = () => {
        if (companyList?.length > 0 && formDetails?.companyName?.isAutoPopulate) {
            if (userDetails.userInfo.companyId) {
                const userCompany: Company | null =
                    companyList?.find(
                        (company) => company?.id === userDetails.userInfo.companyId
                    ) ?? null;

                if (userCompany) {
                    setSelectedCompany(userCompany); // Auto-populate Company-Name
                    getContactUserData(userCompany?.id); // Trigger Contact-List
                }
            }
        }
    };
    const futureDate1Mon = (publicationDate: string | number | Date) => {
        // Check if publicationDate is a valid date
        if (!publicationDate || isNaN(new Date(publicationDate).getTime())) {
            return '-';
        }

        // Adding 1 month to the date
        const futureDate = new Date(publicationDate);
        futureDate.setMonth(futureDate.getMonth() + 1);

        // Format the date string
        return formatDate(futureDate.toISOString());
    };
    const futureDate3Mon = (publicationDate: string | number | Date) => {
        // Check if publicationDate is a valid date
        if (!publicationDate || isNaN(new Date(publicationDate).getTime())) {
            return '-';
        }

        // Adding 3 months to the date
        const futureDate = new Date(publicationDate);
        futureDate.setMonth(futureDate.getMonth() + 3);

        // Format the date string
        return formatDate(futureDate.toISOString());
    };
    const isRecordalCategory = () => {
        if (
            quoteOrderData.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].recordal ||
            quoteOrderData.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal
        ) {
            return true;
        }
        return false;
    };
    const isRenewalsAnnuitiesCategory = () => {
        if (
            quoteOrderData.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].annuities ||
            quoteOrderData.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].Renewals
        ) {
            return true;
        }
        return false;
    };
    const isShowThisPatentField = (fieldName: string): boolean => {
        switch (fieldName) {
            case 'validationDeadlines':
            case 'upDeadlines':
                return (
                    selectedCategory === EP.translation_only ||
                    selectedCategory === EP['translation_&_validation']
                );
            // case 'europeanDeadlines':
            //     return selectedCategory == EP.Renewals;
            case 'kindCode':
                return (
                    (selectedCategory === EP.translation_only ||
                        selectedCategory === EP['translation_&_validation']) &&
                    (patentDetails?.kind === 'A1' || patentDetails?.kind === 'A2')
                );
            case 'KindCodeField':
                return (
                    selectedCategory === EP['71_3_claims'] ||
                    selectedCategory === EP.translation_only ||
                    selectedCategory === EP['translation_&_validation']
                );
            default:
                return false;
        }
    };
    const getFieldValue = (fieldName: string): string => {
        let result = '--'; // Default value

        if (fieldName === 'upDeadlines') {
            if (patentDetails?.kind === 'B1') {
                if (isEditFlow) {
                    result = patentDetails?.validationDeadlineUP
                        ? formatDate(patentDetails.validationDeadlineUP || '')
                        : '--';
                } else {
                    result = patentDetails?.patentPublicationDate
                        ? futureDate1Mon(patentDetails.patentPublicationDate)
                        : '--';
                }
            }
        }

        return result;
    };

    // component initial configuration
    useEffect(() => {
        const fetchFormData: CompanyDetailsData | null = quoteOrderData.formData.companyDetailsPage;

        if (userDetails.userInfo.roleId) {
            const isSalesRepAvailable: boolean = Boolean(
                fetchFormData?.patentDetails &&
                    fetchFormData.patentDetails.salesRepId &&
                    fetchFormData.patentDetails.salesRepName
            );

            if (fetchFormData?.formData) {
                setFormDetails(fetchFormData.formData);
            } else {
                formDataSetup();
            }

            if (fetchFormData?.companyList && fetchFormData?.companyList?.length > 0) {
                setCompanyList(fetchFormData.companyList);
                setSelectedCompany(fetchFormData.selectedCompany);
            } else {
                getCompanyData();
            }

            setContactUserList(fetchFormData?.contactUserList ?? []);
            setSelectedContact(fetchFormData?.selectedContact);
            setPublicationNumber(fetchFormData?.publicationNumber);
            setPatentDetails(fetchFormData?.patentDetails ?? null);
            setIsFormSubmitting(Boolean(fetchFormData?.isFormSubmitting));

            if (!isEditFlow && isThisCUserExcludedSalesRep) {
                if (!isSalesRepAvailable) {
                    /** we shows the 'sales-rep' using selected contact-user.
                     *  but, as ContactUsers(CM/CU) don't have the 'contact-user' field in the form.
                     *  so, we need to get that using API call.
                     *  Note: we could get this field on edit mode via 'Edit-API'. so skip this process on edit mode. */
                    getUserDetails(fetchFormData?.patentDetails ?? {});
                }
            }
        }

        const exampleText = getPubNumExampleText();
        setPublicationNumberExampleText(t(exampleText));

        isEditFlow && patentDetailsSection(true, fetchFormData?.formData);

        /** in edit mode we set data to local state from store.
         * that time we not need to update the store when states are update.
         * so we use this flag to skip the update activity and also it helps to avoid re-render. */
        const setInitialRenderingAsCompleted = async () => {
            await new Promise((r) => setTimeout(r, 200));
            autoPopulateCompanyName();
            setIsInitialRendering(false);
        };
        setInitialRenderingAsCompleted();

        /** set PM for Additional-Info page earlier. */
        orderQuoteModuleService.setAdditionalInfoPM();
    }, [userDetails]);

    // update store in every onChange event
    useEffect(() => {
        if (isInitialRendering) return;

        // get latest formData (all form to retain the same)
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();
        const updatedFormData = updatedQuoteOrderData.formData;

        // 'company-details' page states list to retain the page while navigation
        const updatedCompanyDetailsPage = {
            companyList,
            selectedCompany,
            selectedContact,
            contactUserList,
            publicationNumber,
            patentDetails,
            isFormSubmitting,
            formData: formDetails
        };

        // update the store
        if (updatedCompanyDetailsPage) {
            // hold the other form data while update the store
            const updatedQuoteOrderFormData = {
                ...updatedFormData,
                companyDetailsPage: updatedCompanyDetailsPage
            };

            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    }, [
        companyList,
        selectedCompany,
        selectedContact,
        contactUserList,
        publicationNumber,
        patentDetails,
        formDetails,
        isFormSubmitting
    ]);

    useEffect(() => {
        if (
            userDetails.userInfo.roleId === ROLE.CONTACT_USER.roleId &&
            companyList?.length === 1 &&
            !quoteOrderModuleStore.getData()?.info?.requestCurrencyId
        ) {
            const infoUpdate = {
                ...quoteOrderData?.info,
                requestCurrencyId: selectedCompany?.requestCurrencyId ?? null
            };
            quoteOrderModuleStore.updatePage('info', infoUpdate);
        }
    }, [selectedCompany]);

    // update form valid status for onChange event
    useEffect(() => {
        // for form validation
        isFormValid();

        // form validation for show errors
        if (isFormSubmitting) formFieldsValidations();
    }, [
        selectedCompany,
        selectedContact,
        publicationNumber,
        patentDetails,
        isFormSubmitting,
        upcOptOutPatentNumbers
    ]);

    // update patent error status for onChange event
    useEffect(() => {
        isPatentError();
    }, [formDetails]);

    useEffect(() => {
        // Auto Pupulate company users.
        autoPopulateCompanyName();
    }, [companyList, userDetails]);

    // publicationNumber onChange handler
    useEffect(() => {
        const clearPatentNoDataWarning = () => {
            if (!formDetails.patentDetails.dataNotFoundForPatent) return;

            /** set 'dataNotFoundForPatent' false, when user re-enter the 'Publication-Number'.
                 based on this we can show/hide the 'data not fount' msg in UI */
            setFormDetails({
                ...formDetails,
                patentDetails: { ...formDetails.patentDetails, dataNotFoundForPatent: false }
            });
        };

        clearPatentNoDataWarning();
    }, [publicationNumber]);

    useEffect(() => {
        isPCTSummaryPageHideShow();
    }, [patentDetails?.sourceLanguage]);

    const isPCTSummaryPageHideShow = () => {
        if (isEditFlow) {
            return;
        }

        if (
            isPCT &&
            isThisQuoteCreation &&
            !isRecordalCategory() &&
            !isRenewalsAnnuitiesCategory() &&
            patentDetails?.sourceLanguage
        ) {
            const stepperData = stepperStore.getStepperData();
            const summaryStep: STEPPER_DATA_TYPE = STEPPER_DATA.SUMMARY;
            if (isThisContactUser) {
                if (
                    summaryStep &&
                    stepperData?.stepperList &&
                    !Object.values(PATENT_SOURCE_LANGUAGE).includes(patentDetails.sourceLanguage)
                ) {
                    const updatedStepperList: STEPPER_DATA_TYPE[] = stepperData?.stepperList.filter(
                        (step: STEPPER_DATA_TYPE) => step.stepperId !== summaryStep.stepperId
                    );
                    if (updatedStepperList) {
                        const updatedStepperData: STEPPER_STATE = {
                            ...stepperData,
                            stepperList: updatedStepperList
                        };
                        stepperStore?.updateStepper(updatedStepperData);
                    }
                } else {
                    orderQuoteModuleService.addMoreStepInStepper();
                }
            }
        }
    };

    return (
        <div className="companyDetailsPage" data-testid="companyDetailsPage">
            <div
                className="company-details-section p-5 pt-4 pb-6 border-b-[1.5px] rounded-t-md bg-primary-50"
                data-testid="companyDetailsSection">
                <h4 className="font-semibold mb-1" data-testid="companyDetailsTitle">
                    {t('COMPANY_DETAILS.TITLE')}
                </h4>
                <div
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 md:gap-6 min-h-16 mt-2"
                    data-testid="companyDetailsGrid">
                    <div className="col-span-1" data-testid="companyNameContainer">
                        <div
                            id="companyName"
                            className="flex flex-col gap-px relative"
                            data-testid="companyName">
                            <label className="text-slate-gray mb-1" data-testid="companyNameLabel">
                                {t('COMPANY_DETAILS.COMPANY_NAME')}
                                <span className="text-red-500" data-testid="companyNameRequired">
                                    {' '}
                                    *
                                </span>
                            </label>
                            <div
                                className="flex flex-col"
                                data-testid="companyNameDropdownContainer">
                                <div
                                    className="flex justify-start items-center"
                                    data-testid="companyNameDropdownWrapper">
                                    {formDetails?.companyName?.isReadonly ? (
                                        <input
                                            type="text"
                                            readOnly={
                                                formDetails.publicationNumber?.isReadonly
                                                // quoteOrderModuleStore.getData().info.isEditFlow ?? false
                                            }
                                            style={{
                                                // opacity: quoteOrderModuleStore.getData().info.isEditFlow
                                                opacity: formDetails.publicationNumber?.isReadonly
                                                    ? '0.6'
                                                    : '1'
                                            }}
                                            value={selectedCompany?.name ?? ''}
                                            className={inputStyle}
                                            data-testid="companyNameDropdown"
                                        />
                                    ) : (
                                        <Dropdown
                                            id="companyName"
                                            value={selectedCompany}
                                            className="disabled:cursor-not-allowed"
                                            onChange={(e) =>
                                                handlerSelectedCompany(e.value as Company)
                                            }
                                            options={companyList}
                                            filter={true}
                                            optionLabel="name"
                                            disabled={
                                                formDetails?.companyName?.isReadonly

                                                // ||
                                                // (quoteOrderModuleStore.getData().info.isEditFlow ??
                                                //     false) ||
                                                // AuthStore.getUserInfo().userInfo.roleId ===
                                                //     ROLE.CONTACT_USER.roleId
                                            }
                                            placeholder="Select a Company"
                                            pt={{
                                                ...dropDownStyle,
                                                input: {
                                                    className:
                                                        dropDownStyle.input.className + '!text-sm'
                                                }
                                            }}
                                            data-testid="companyNameDropdown"
                                        />
                                    )}
                                </div>
                            </div>
                            {formDetails?.companyName?.isError && (
                                <ErrorLabel
                                    customStyle="absolute -bottom-5 right-0 [&>span]:text-[0.85rem] [&>span]:!leading-none"
                                    message={`${t('COMPANY_DETAILS.COMPANY_ERROR')}`}
                                    data-testid="companyNameErrorLabel"
                                />
                            )}
                        </div>
                    </div>
                    <div className="col-span-1" data-testid="contactUserContainer">
                        {formDetails?.contactUser?.isShow && (
                            <div
                                id="companyName"
                                className="mb-0 flex flex-col gap-px relative"
                                data-testid="contactUser">
                                <label
                                    className="text-slate-gray mb-1"
                                    data-testid="contactUserLabel">
                                    {t('COMPANY_DETAILS.CONTACT_USER')}
                                    <span
                                        className="text-red-500"
                                        data-testid="contactUserRequired">
                                        {' '}
                                        *
                                    </span>
                                </label>
                                <div
                                    className="flex flex-col"
                                    data-testid="contactUserDropdownContainer">
                                    <div
                                        className="flex justify-start items-center"
                                        data-testid="contactUserDropdownWrapper">
                                        {formDetails?.companyName?.isReadonly ? (
                                            <input
                                                type="text"
                                                readOnly={
                                                    formDetails.publicationNumber?.isReadonly
                                                    // quoteOrderModuleStore.getData().info.isEditFlow ?? false
                                                }
                                                style={{
                                                    // opacity: quoteOrderModuleStore.getData().info.isEditFlow
                                                    opacity: formDetails.publicationNumber
                                                        ?.isReadonly
                                                        ? '0.6'
                                                        : '1'
                                                }}
                                                value={selectedContact?.fullName ?? ''}
                                                className={inputStyle}
                                                data-testid="companyNameDropdown"
                                            />
                                        ) : (
                                            <Dropdown
                                                id="contactUser"
                                                filter={true}
                                                value={selectedContact}
                                                onChange={(e) =>
                                                    handlerSelectedContact(e.value as ContactUser)
                                                }
                                                options={contactUserList}
                                                optionLabel="fullName"
                                                // disabled={
                                                //     // formDetails?.contactUser?.isReadonly
                                                //     //  ||
                                                //     // (quoteOrderModuleStore.getData().info.isEditFlow ??
                                                //     //     false)
                                                // }
                                                placeholder="Select Contact User"
                                                pt={{
                                                    ...dropDownStyle,
                                                    input: {
                                                        className:
                                                            dropDownStyle.input.className +
                                                            '!text-sm'
                                                    }
                                                }}
                                                data-testid="contactUserDropdown"
                                            />
                                        )}
                                    </div>
                                </div>
                                {formDetails?.contactUser?.isError && (
                                    <ErrorLabel
                                        customStyle="absolute -bottom-5 right-0 [&>span]:text-[0.85rem] [&>span]:!leading-none"
                                        message={`${t('COMPANY_DETAILS.CONTACT_ERROR')}`}
                                        data-testid="contactUserErrorLabel"
                                    />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {/* patent authentication */}
            {isEpUpcOptOut ? (
                <UpcOptOut setPatentNumbers={setUpcOptOutPatentNumbers} />
            ) : (
                <div
                    id="patent-authentication-section"
                    className="p-5 pt-2 pb-0"
                    data-testid="patentAuthenticationSection">
                    <h4 className="font-semibold mb-2" data-testid="patentAuthenticationTitle">
                        {t('COMPANY_DETAILS.PATENT_AUTHENTICATION')}
                    </h4>
                    {/* Patent warning label */}
                    {isPatentVerificationRequired() && (
                        <div data-testid="patentWarningLabel">
                            <span className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1 bg-orange-50 border-2 rounded-md border-orange-100">
                                <i className="pi pi-info-circle text-yellow-500"></i>
                                <span className="md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                                    {t(
                                        `${PATENT_WARNING[quoteOrderData.info.selectedService?.serviceTypeId ?? 1]}`
                                    )}
                                </span>
                            </span>
                        </div>
                    )}
                    <div className="flex lg:w-7/12 w-9/12 my-4" data-testid="patentInputContainer">
                        <div
                            id="PCT-input-box"
                            className="flex flex-col gap-1 w-full"
                            data-testid="patentInputBox">
                            <div className="flex justify-between items-center">
                                <label
                                    className="text-slate-gray text-xxs mb-1 whitespace-nowrap"
                                    data-testid="patentInputLabel">
                                    {quoteOrderModuleStore.getData().info.selectedService
                                        ?.serviceTypeId !== SERVICE_TYPE_ID.european_patent
                                        ? t('COMPANY_DETAILS.PUBLICATION_NUMBER')
                                        : t('COMPANY_DETAILS.EP_PUBLICATION_NUMBER')}
                                    <span
                                        className="text-red-500"
                                        data-testid="patentInputRequired">
                                        {' '}
                                        *
                                    </span>
                                </label>
                                {invalidFormat && publicationNumber !== '' && (
                                    <ErrorLabel
                                        customStyle="!justify-start [&>span]:text-[0.85rem]"
                                        message={t('COMPANY_DETAILS.INVALID_PUBLICATION_NUMBER')}
                                        data-testid="invalidPublicationNumberError"
                                    />
                                )}
                            </div>

                            <div className="flex gap-2 w-full" data-testid="patentInputWrapper">
                                <div
                                    className="flex flex-col w-full gap-1 mb-3"
                                    data-testid="patentInputFieldContainer">
                                    <form
                                        className="w-full"
                                        onSubmit={handleSubmit}
                                        data-testid="patentInputForm">
                                        <input
                                            type="text"
                                            readOnly={
                                                formDetails.publicationNumber?.isReadonly
                                                // quoteOrderModuleStore.getData().info.isEditFlow ?? false
                                            }
                                            style={{
                                                // opacity: quoteOrderModuleStore.getData().info.isEditFlow
                                                opacity: formDetails.publicationNumber?.isReadonly
                                                    ? '0.6'
                                                    : '1'
                                            }}
                                            value={publicationNumber ?? ''}
                                            onChange={(e) => publicationNumberChange(e)}
                                            className={inputStyle}
                                            // disabled={formDetails?.publicationNumber?.isReadonly}
                                            placeholder={
                                                t('COMMON.ENTER_THE') +
                                                ' ' +
                                                (quoteOrderModuleStore.getData().info
                                                    .selectedService?.serviceTypeId !==
                                                SERVICE_TYPE_ID.european_patent
                                                    ? t('COMPANY_DETAILS.PUBLICATION_NUMBER')
                                                    : t('COMPANY_DETAILS.EP_PUBLICATION_NUMBER'))
                                            }
                                            onKeyUp={handleDuplicatePublicationNumber}
                                            data-testid="publicationNumberInput"
                                        />
                                    </form>
                                    <div
                                        className="w-full lg:flex mt-1 gap-2"
                                        data-testid="patentInputErrorContainer">
                                        {publicationNumberExampleText && (
                                            <label
                                                className="text-slate-gray flex-1 items-center text-xxs whitespace-nowrap"
                                                data-testid="publicationNumberExample">
                                                {`${t(`COMMON.EG`)} ${publicationNumberExampleText}`}
                                            </label>
                                        )}
                                        {hasDuplicates && publicationNumber !== '' && (
                                            <ErrorLabel
                                                customStyle="!justify-start [&>span]:text-[0.85rem]"
                                                message={t(
                                                    'COMPANY_DETAILS.DUPLICATE_PUBLICATION_NUMBER'
                                                )}
                                                data-testid="duplicatePublicationNumberError"
                                            />
                                        )}
                                        {patentVerificationError.hasError && !hasDuplicates && (
                                            <ErrorLabel
                                                customStyle="!justify-start [&>span]:text-[0.85rem]"
                                                message={t(patentVerificationError.errorMessage)}
                                                data-testid="patentVerificationError"
                                            />
                                        )}
                                    </div>
                                </div>
                                {!isRecordalCategory() && (
                                    <div data-testid="verifyButtonContainer" className="flex">
                                        <label
                                            className="text-neutral-200"
                                            data-testid="verifyButtonLabel">
                                            &nbsp;
                                        </label>
                                        <button
                                            className="px-4 btn h-10 min-h-10 button-primary"
                                            disabled={isEditFlow}
                                            onClick={() => {
                                                if (!hasDuplicates) {
                                                    getPatentDetails();
                                                }
                                            }}
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            data-testid="verifyButton">
                                            {t('COMPANY_DETAILS.VERIFY')}
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Patent - Details */}
                    {(formDetails.patentDetails.isShow || isRecordalCategory()) && (
                        <div
                            className="border rounded-md border-primary-100 bg-primary-50 w-full lg:w-3/4 my-2 p-3 px-4"
                            data-testid="patentDetailsContainer">
                            <h4
                                className="text-[#1D8ADE] font-medium  mb-1"
                                data-testid="patentDetailsTitle">
                                {t('COMPANY_DETAILS.PATENT_DETAILS')}
                            </h4>
                            <div
                                className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-6"
                                data-testid="patentDetailsGrid">
                                <div className="col-span-4">
                                    <div>
                                        {!isRecordalCategory() && (
                                            <div
                                                className="flex flex-col"
                                                data-testid="patentTitleContainer">
                                                <label
                                                    className="text-slate-gray"
                                                    data-testid="patentTitleLabel">
                                                    {t('COMPANY_DETAILS.PATENT_TITLE')}
                                                </label>
                                                <label
                                                    className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                                    data-testid="patentTitle">
                                                    {patentDetails?.title ?? '--'}
                                                </label>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div
                                    className={`flex flex-col ${!isPatentVerificationRequired() ? 'col-span-4' : null}`}
                                    data-testid="patentPublicationNumberContainer">
                                    <label
                                        className="text-slate-gray"
                                        data-testid="patentPublicationNumberLabel">
                                        {t('COMPANY_DETAILS.PATENT_PUBLICATION_NUMBER')}
                                    </label>
                                    <label
                                        className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                        data-testid="patentPublicationNumber">
                                        {isPatentVerificationRequired()
                                            ? (patentDetails?.patentPublicationNumber ?? '--')
                                            : (publicationNumber ?? '--')}
                                    </label>
                                </div>
                                <div
                                    className="flex flex-col"
                                    data-testid="sourceLanguageContainer">
                                    <label
                                        className="text-slate-gray"
                                        data-testid="sourceLanguageLabel">
                                        {t('COMPANY_DETAILS.SOURCE_LANGUAGE')}
                                    </label>
                                    <label
                                        className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                        data-testid="sourceLanguage">
                                        {isRecordalCategory()
                                            ? COMMON_CONSTANTS.NOT_APPLICABLE
                                            : (patentDetails?.sourceLanguageName ?? '--')}
                                    </label>
                                </div>
                                <div className="flex flex-col" data-testid="requestedByContainer">
                                    <label
                                        className="text-slate-gray"
                                        data-testid="requestedByLabel">
                                        {t('COMPANY_DETAILS.REQUESTED_BY')}
                                    </label>
                                    <label
                                        className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                        data-testid="requestedBy">
                                        {isEditFlow
                                            ? (patentDetails?.requestedByName ?? '--')
                                            : (userDetails.userInfo.userFullName ?? '--')}
                                    </label>
                                </div>
                                <div
                                    className="flex flex-col"
                                    data-testid="salesRepresentativeContainer">
                                    <label
                                        className="text-slate-gray"
                                        data-testid="salesRepresentativeLabel">
                                        {t('COMPANY_DETAILS.SALES_REPRESENTATIVE')}
                                    </label>
                                    <div
                                        className="flex justify-start items-center gap-4"
                                        data-testid="salesRepresentativeWrapper">
                                        <label
                                            className="font-medium truncate text-wrap whitespace-normal text-title-header"
                                            data-testid="salesRepresentative">
                                            {patentDetails?.salesRepName &&
                                            patentDetails.salesRepName !== ''
                                                ? patentDetails.salesRepName
                                                : '--'}
                                        </label>
                                        {patentDetails?.salesRepName && (
                                            <>
                                                <i
                                                    className="pi pi-envelope text-primary-200 text-sm"
                                                    data-testid="salesRepresentativeIcon"></i>
                                                {/* TODO: MailTo yet to configure
                                            <a
                                                href={`mailto:${'karthick.periyaswamy@ctg.com'}`}
                                                title={`Email ${patentDetails.salesRepName}`}>
                                                <i
                                                    className="pi pi-envelope text-primary-200 text-sm"
                                                    data-testid="salesRepresentativeIcon"></i>
                                            </a> */}
                                            </>
                                        )}
                                    </div>
                                </div>
                                {!isRecordalCategory() && (
                                    <>
                                        <div
                                            className="flex flex-col"
                                            data-testid="patentApplicationNumberContainer">
                                            <label
                                                className="text-slate-gray"
                                                data-testid="patentApplicationNumberLabel">
                                                {t('COMPANY_DETAILS.PATENT_APP_NUMBER')}
                                            </label>
                                            <label
                                                className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                                data-testid="patentApplicationNumber">
                                                {isPCT && (patentDetails?.pctReference ?? '--')}
                                                {isEP &&
                                                    (patentDetails?.patentApplicationNumber ??
                                                        '--')}
                                            </label>
                                        </div>
                                        <div
                                            className="flex flex-col"
                                            data-testid="applicantContainer">
                                            <label
                                                className="text-slate-gray"
                                                data-testid="applicantLabel">
                                                {t('COMPANY_DETAILS.APPLICANT')}
                                            </label>
                                            <label
                                                className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                                data-testid="applicant">
                                                {patentDetails?.applicantName ?? '--'}
                                            </label>
                                        </div>
                                    </>
                                )}
                                {isPCT && isPatentVerificationRequired() && (
                                    <div className="flex flex-col" data-testid="deadlineContainer">
                                        <label
                                            className="text-slate-gray"
                                            data-testid="deadlineLabel">
                                            {t('COMPANY_DETAILS.30_MONTH_DEADLINE')}
                                        </label>
                                        <label
                                            className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                            data-testid="deadline">
                                            {patentDetails?.textthirtyMonthsDeadline
                                                ? formatDate(
                                                      patentDetails?.textthirtyMonthsDeadline
                                                  )
                                                : '--'}
                                        </label>
                                    </div>
                                )}
                                {isShowThisPatentField('validationDeadlines') &&
                                    isPatentVerificationRequired() && (
                                        <div
                                            className="flex flex-col"
                                            data-testid="validationDeadlinesContainer">
                                            <label
                                                className="text-slate-gray"
                                                data-testid="validationDeadlinesLabel">
                                                {t('COMPANY_DETAILS.VALIDATION_DEADLINES')}
                                            </label>
                                            <label
                                                className="font-medium truncate text-wrap whitespace-normal text-[#333333]"
                                                data-testid="validationDeadlines">
                                                {patentDetails?.kind === 'B1'
                                                    ? isEditFlow
                                                        ? patentDetails?.validationDeadline
                                                            ? formatDate(
                                                                  patentDetails.validationDeadline ??
                                                                      ''
                                                              )
                                                            : '--'
                                                        : patentDetails?.patentPublicationDate
                                                          ? futureDate3Mon(
                                                                patentDetails.patentPublicationDate
                                                            )
                                                          : '--'
                                                    : '--'}
                                            </label>
                                        </div>
                                    )}
                                {isShowThisPatentField('upDeadlines') &&
                                    isPatentVerificationRequired() && (
                                        <div
                                            className="flex flex-col"
                                            data-testid="upDeadlinesContainer">
                                            <label
                                                className="text-slate-gray"
                                                data-testid="upDeadlinesLabel">
                                                {t('COMPANY_DETAILS.UP_DEADLINES')}
                                            </label>
                                            <label
                                                className="font-medium truncate text-wrap whitespace-normal"
                                                data-testid="upDeadlines">
                                                {getFieldValue('upDeadlines')}
                                            </label>
                                        </div>
                                    )}
                                {isShowThisPatentField('europeanDeadlines') &&
                                    isPatentVerificationRequired() && (
                                        <div
                                            className="flex flex-col"
                                            data-testid="europeanDeadlinesContainer">
                                            <label
                                                className="text-slate-gray"
                                                data-testid="europeanDeadlinesLabel">
                                                {t('COMPANY_DETAILS.EUROPEAN_DEADLINES')}
                                            </label>
                                            <label
                                                className="font-medium truncate text-wrap whitespace-normal"
                                                data-testid="europeanDeadlines">
                                                {'--'}
                                            </label>
                                        </div>
                                    )}
                                {isShowThisPatentField('KindCodeField') && patentDetails?.kind && (
                                    <div
                                        className="flex flex-col"
                                        data-testid="kindCodeFieldContainer">
                                        <label
                                            className="text-slate-gray"
                                            data-testid="kindCodeLabel">
                                            {t('COMPANY_DETAILS.KIND')}
                                        </label>
                                        <label
                                            className="font-medium truncate text-wrap whitespace-normal"
                                            data-testid="kindCode">
                                            {patentDetails?.kind ?? '--'}
                                        </label>
                                    </div>
                                )}
                            </div>
                            {isShowThisPatentField('kindCode') &&
                                isPatentVerificationRequired() && (
                                    <div
                                        className="border border-secondary/40 p-2 px-3 bg-secondary/5 mt-4 mb-2 rounded"
                                        data-testid="kindCodeContainer">
                                        <p
                                            className="text-secondary flex items-center gap-2"
                                            data-testid="kindCodeText">
                                            <span>
                                                <img
                                                    alt=""
                                                    src={alertRedIcon}
                                                    className=""
                                                    data-testid="kindCodeIcon"
                                                />
                                            </span>
                                            {`${t('COMPANY_DETAILS.KIND_CODE')} ${patentDetails?.kind}.`}
                                        </p>
                                    </div>
                                )}
                        </div>
                    )}
                </div>
            )}
            {/* submit */}
            <button
                type="button"
                id={`submit-${PATHS.COMPANY_DETAILS}`}
                onClick={onSubmit}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                data-testid="submitCompanyDetailsButton"
            />
        </div>
    );
};

export default CompanyDetails;
