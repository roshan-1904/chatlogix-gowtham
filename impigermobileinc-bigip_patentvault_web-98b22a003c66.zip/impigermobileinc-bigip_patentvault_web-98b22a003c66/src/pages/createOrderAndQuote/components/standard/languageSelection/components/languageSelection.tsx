import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import DataTableComponent from 'shared/dataTable/dataTable';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import {
    LanguageSelectionDataItem,
    DataToPreviewDownloadType
} from '../types/languageSelection.type';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import { MenuItem } from 'primereact/menuitem';
import { InputNumber } from 'primereact/inputnumber';
import { QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { DOCUMENT_TYPE, DropdownSelection, MODULE_TYPE } from 'constants/app.constant';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import {
    GetUploadedDocumentListResponse,
    UploadedDocumentInfo
} from 'components/fileUpload/types/fileUpload.types';
import {
    AllLanguageResponse,
    AllLanguageResponseType
} from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import DropdownInline from 'components/dropdownInline/dropdownInline';
import { FilterMatchMode } from 'primereact/api';
import languageSelectionService from '../services/languageSelection.service';
import { Dialog } from 'primereact/dialog';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import utils from 'core/utils/utils';
import { QuoteOrderModuleStoreFormData } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { Tooltip } from 'primereact/tooltip';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { previewDialogPopup } from 'constants/styles.constant';
import standardModuleService, {
    ActionParamsLanguageSelection
} from '../services/standardModule.service';
import { useNavigate } from 'react-router-dom';
import stdConstants from '../../constants/standard.constant';
import { PATHS } from 'constants/routes.constant';
interface InlineInputNumberDataType {
    index?: number;
    field: string;
    rowData: any;
}
interface InlineDropdownDataType {
    index?: number;
    field: string;
    optionValue?: string;
    optionLabel?: string;
    selectionType: DropdownSelection;
    rowData: any;
    dropdownFor: InlineDropdownType;
}
type InlineDropdownType = 'fileSelection' | 'languageSelection';

const LanguageSelection = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [toggleRowData, setToggleRowData] = useState<LanguageSelectionDataItem>();
    const [dataToPreviewDownload, setDataToPreviewDownload] = useState<DataToPreviewDownloadType>(
        {}
    );
    const [isPreviewFile, setIsPreviewFile] = useState<boolean>(false);
    const [isPreviewSTD, setIsPreviewSTD] = useState<boolean>(false);
    const [previewSTDUrl, setPreviewSTDUrl] = useState<string>('');
    const [showFileDeletePopup, setShowFileDeletePopup] = useState({
        visible: false,
        header: '',
        description: ''
    });
    const [uploadedFiles, setUploadedFiles] = useState<UploadedDocumentInfo[]>([]); // response data
    const [tableData, setTableData] = useState<LanguageSelectionDataItem[]>([]);
    const [languageList, setLanguageList] = useState<AllLanguageResponseType[]>([]);
    const [fileSelectionList, setFileSelectionList] = useState<UploadedDocumentInfo[]>([]);
    const isEditFlow: boolean = quoteOrderData?.info?.isEditFlow === true;
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const defaultItemsToService = { translate: t, navigateTo: navigate };

    // api
    const getUploadedFiles = async () => {
        try {
            const primaryId = quoteOrderData?.info?.primaryId;
            const updatedPrimaryId = primaryId && primaryId !== 0 ? primaryId : 0;
            const moduleId = MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId;

            const uploadFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_FILE_LIST}${updatedPrimaryId}/${moduleId}/${false}`;
            const response: GetUploadedDocumentListResponse =
                await fileUploadService.getUploadedDocumentList(uploadFileApiUrl);

            const uploadedFilesResData =
                response?.documentReturnsModel?.filter(
                    (doc) => doc.documentType === DOCUMENT_TYPE.SOURCE.id
                ) ?? [];

            if (uploadedFilesResData.length > 0) {
                const languageSelectionPageTableData: LanguageSelectionDataItem[] =
                    quoteOrderData?.formData.languageSelectionPage?.tableData ?? [];

                // Getting document id from uploaded files for final save API
                const currentDocumentId = uploadedFilesResData.find(
                    (file) => file.documentId
                )?.documentId;

                /** `tableData` should contain only those items present in `responseData`. Or can be empty row. */
                const updatedTableData = languageSelectionPageTableData
                    .filter((file) => {
                        return uploadedFilesResData.some(
                            (uploadedFile) =>
                                file.fileId === uploadedFile.fileId || file.fileId === null
                        );
                    })
                    .map((file) => {
                        const selectedFileData = uploadedFilesResData.find(
                            (uploadedFile) => uploadedFile.fileId === file.fileId
                        );

                        /** just return the file if not found in uploaded files.
                            because they are empty rows. no mapping needed for those. */
                        if (!selectedFileData) return file;

                        // const deliveryDate =
                        //     quoteOrderData?.formData.orderQuoteDetailsPage?.requestedDeliveryDate ??
                        //     null; // get updated date from order details page
                        const documentType =
                            Object.values(DOCUMENT_TYPE).find(
                                (type) => type.id === selectedFileData.documentType
                            )?.name ?? '-';

                        return {
                            ...file,
                            rowIndex: file.rowIndex ?? generateRandomId(),
                            documentType,
                            // deliveryDate,
                            isError:
                                false /** remove error flag. validate and set while submit. that's enough */,
                            /** other buffer fields to sync (this is for edit mode. otherwise it will be available in navigation). */
                            fileName: selectedFileData.fileName,
                            fileSize: selectedFileData.fileSize ?? '',
                            fileType: selectedFileData.fileType ?? '',
                            documentTypeId: selectedFileData.documentType,
                            blobFileName: selectedFileData.blobFileName ?? ''

                            // below fields are available in (...file)
                            // fileId, sourceLanguage, targetLanguage
                        };
                    });

                updatedTableData.forEach((file) => (file.isError = false));

                quoteOrderModuleStore.updatePage('info', {
                    ...quoteOrderData.info,
                    documentId: currentDocumentId
                });
                setUploadedFiles(uploadedFilesResData); // update uploaded files info to local state
                setTableData(updatedTableData); // update form table data to local state
                updateFormData({ uploadedFilesResData, updatedTableData }); // update 'uploaded files info' & 'updated form table data' to store
                updateFileSelectionList({ uploadedFilesResData, updatedTableData }); // update file selection list (to show only non-selected files)

                // get sas token for the uploaded files
                const sasToken = await getSasUrlApi();

                // update local state to handle the download \ preview
                setDataToPreviewDownload({
                    ...dataToPreviewDownload,
                    blobUri: response.blobUri,
                    sasURL: sasToken ?? null
                });
            }
        } catch (error) {
            console.error(`Error in 'getUploadedFiles() in language-selection: `, error);
            return null;
        }
    };
    const getSourceLanguages = async () => {
        try {
            const requestBodySorting = { propertyName: 'id', value: 'asc' };
            const response: AllLanguageResponse =
                await PVSettingsService.getAllLanguages(requestBodySorting);
            if (response?.data) {
                const list: AllLanguageResponseType[] = response.data;
                setLanguageList(list);
            }
        } catch (error) {
            console.error(`Error in 'getSourceLanguages()':`, error);
            return null;
        }
    };
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();

            if (!response) return;
            const sasToken = response.split('?')[1];
            return sasToken ?? null;
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
            return null;
        }
    };

    // handlers - actions
    const deleteFile = async (rowData: LanguageSelectionDataItem | null) => {
        const primaryId: number | null = quoteOrderData.editFlowResponseData?.info.primaryId ?? 0; // to send in api
        const savedFileId: number | null = rowData?.id ?? null; // to send in api (this unique id created in BED against the files)
        const rowIndex: number | null = rowData?.rowIndex ?? null; // to handle local delete
        try {
            const errMsg = 'Something went wrong. Error deleting file!';
            if (!rowData || !rowIndex) throw new Error(errMsg);

            if (isEditFlow && primaryId && savedFileId) {
                /** this api to delete the configured file at BED before user submit the form. */
                const responseOfDeletedFile = await languageSelectionService.deleteConfiguredFile(
                    primaryId,
                    savedFileId
                );

                if (!responseOfDeletedFile && responseOfDeletedFile !== '') {
                    throw new Error(errMsg);
                }
            } else {
                showToastMessage(t('File_UPLOAD.DELETE_FILE_LOCAL_ERROR'), ToastType.ERROR);
            }

            let updatedTableData = [...tableData];
            updatedTableData = tableData.filter((file) => file.rowIndex !== rowData?.rowIndex);

            setTableData(updatedTableData);
            updateFileSelectionList({ updatedTableData }); // update file selection list
            showToastMessage(t('File_UPLOAD.DELETE_SUCCESS_TOAST'), ToastType.SUCCESS);
        } catch (error) {
            console.error('Error in deleteFile():', error);
            return null;
        }
    };
    const updateFormData = ({
        uploadedFilesResData = uploadedFiles,
        updatedTableData = tableData
    }: {
        uploadedFilesResData?: UploadedDocumentInfo[];
        updatedTableData?: LanguageSelectionDataItem[];
    }) => {
        const languageSelectionPage = quoteOrderData?.formData.languageSelectionPage ?? {};

        const updatedQuoteOrderFormData: QuoteOrderModuleStoreFormData = {
            ...quoteOrderData?.formData,
            languageSelectionPage: {
                ...quoteOrderData?.formData.languageSelectionPage,
                uploadedFilesResData,
                tableData: updatedTableData
            }
        };

        if (
            JSON.stringify(languageSelectionPage) !==
            JSON.stringify(updatedQuoteOrderFormData.languageSelectionPage)
        ) {
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const handleApprove = () => {
        const actionParams: ActionParamsLanguageSelection = {
            ...defaultItemsToService,
            updateLanguageSelectionTableData: setTableData
        };

        standardModuleService.handleApproveAction(actionParams);
    };
    const handleSave = (exportType?: number) => {
        const actionParams: ActionParamsLanguageSelection = {
            ...defaultItemsToService,
            updateLanguageSelectionTableData: setTableData
        };

        standardModuleService.handleSaveAction(actionParams, exportType);
    };
    const handleDiscard = () => {
        navigate(`/${PATHS.ORDER_QUOTE}`);
    };
    const handlePreview = () => {
        const actionParams: ActionParamsLanguageSelection = {
            ...defaultItemsToService,
            setIsPreviewSTD,
            setPreviewSTDUrl
        };

        standardModuleService.stdPreviewPDF(actionParams);
    };

    // inline dropdown (single \ multiple)
    const handleAddedNewFileChange = (selectedFileId: any, rowData: any) => {
        try {
            /** get selected file data from api response data. */
            const selectedFileData =
                uploadedFiles.find((file) => file.fileId === selectedFileId) ?? null;
            if (!selectedFileData) throw new Error('Selected file data not found!');

            const updatedTableData = [...(tableData ?? [])];

            const modifiedAt = updatedTableData.findIndex(
                (file) => file.rowIndex === rowData.rowIndex
            );
            if (modifiedAt === -1) throw Error('Modified file not found!');

            const documentType =
                Object.values(DOCUMENT_TYPE).find(
                    (type) => type.id === selectedFileData.documentType
                )?.name ?? '-';

            let id = null;
            if (isEditFlow) {
                const languageSelectionPageData =
                    quoteOrderModuleStore.getData()?.formData?.languageSelectionPage;
                const savedFilesReceivedInEditMode =
                    languageSelectionPageData?.savedFilesReceivedInEditMode ?? [];

                /** scenario, in edit-mode, 
                    if user cleared all the old records and add again same existing / newly added record in language-selection page,
                    then, we should check and add the 'id' if it is exists. (this 'id' available only in saved files.) */
                id =
                    savedFilesReceivedInEditMode.find(
                        (file: any) => file?.fileId === selectedFileId
                    )?.id ?? null;
            }

            updatedTableData[modifiedAt] = {
                ...rowData,
                id,
                fileId: selectedFileData.fileId,
                fileName: selectedFileData.fileName,
                sourceLanguage: null,
                targetLanguage: null,
                wordCount: null,
                // deliveryDate: orderDetailsPageFormData.requestedDeliveryDate || null,
                documentType,
                documentTypeId: selectedFileData.documentType,
                fileSize: selectedFileData.fileSize,
                blobFileName: selectedFileData.blobFileName,
                fileType: selectedFileData.fileType
            };

            setTableData(updatedTableData); // update table data with selected file data
            updateFileSelectionList({ uploadedFilesResData: uploadedFiles, updatedTableData }); // update file selection list
        } catch (error) {
            console.error('Error in handleFilesChange():', error);
            return null;
        }
    };
    const handleLanguageChange = (value: number | number[], rowData: any) => {
        try {
            const savedFileId: number = rowData?.id ?? null;
            const updatedFileId: number = rowData.fileId;
            if (!updatedFileId) throw new Error('File ID not found to update the file!');

            const isMultiSelect = Array.isArray(value);
            const languageSelectionPageData =
                quoteOrderModuleStore.getData()?.formData?.languageSelectionPage;
            const existingSavedIds =
                languageSelectionPageData?.savedFilesIdsReceivedInEditMode ?? [];
            const isEdited = isEditFlow && !!savedFileId && existingSavedIds.includes(savedFileId);

            const updatedTableData = tableData.map((file) => {
                if (file.fileId === updatedFileId) {
                    if (isMultiSelect) {
                        /** Source and Target languages cannot be same */
                        const hasMatchWithSourceLanguage = Boolean(
                            file.sourceLanguage && (value ?? []).includes(file.sourceLanguage)
                        );
                        if (hasMatchWithSourceLanguage) {
                            showToastMessage(
                                t('LANGUAGE_SELECTION.LANGUAGE_SELECTION_WARNING'),
                                ToastType.WARNING
                            );
                            return file;
                        }

                        file.targetLanguage = value; // update the new value
                    } else {
                        /** Source and Target languages cannot be same */
                        const hasMatchWithTargetLanguage = (file.targetLanguage ?? []).includes(
                            value
                        );
                        if (hasMatchWithTargetLanguage) {
                            showToastMessage(
                                t('LANGUAGE_SELECTION.LANGUAGE_SELECTION_WARNING'),
                                ToastType.WARNING
                            );
                            return file;
                        }

                        file.sourceLanguage = value; // update the new value
                    }
                    return { ...file, isEdited };
                }
                return file;
            });

            setTableData(updatedTableData);
        } catch (error) {
            console.error('Error in handleDropdownChange:', error);
            return null;
        }
    };
    const handleAddWordCount = (rowData: any, count: number = 0) => {
        const savedFileId: number = rowData?.id ?? null;
        const updatedFileId: number = rowData.fileId;
        if (!updatedFileId) throw new Error('File ID not found to update the file!');

        const languageSelectionPageData =
            quoteOrderModuleStore.getData()?.formData?.languageSelectionPage;
        const existingSavedIds = languageSelectionPageData?.savedFilesIdsReceivedInEditMode ?? [];
        const isEdited = isEditFlow && !!savedFileId && existingSavedIds.includes(savedFileId);

        const updatedTableData = tableData.map((file) => {
            if (file.fileId === updatedFileId) {
                return { ...file, wordCount: count, isEdited };
            }
            return file;
        });

        setTableData(updatedTableData);
    };
    const renderInlineDropdown = (params: InlineDropdownDataType) => {
        const isLanguageSelectionDisabled =
            params.dropdownFor === 'languageSelection' && !params.rowData.fileId;

        const checkFieldError = (): boolean => {
            const isError =
                params.rowData.fileId &&
                (!params.rowData[params.field] ||
                    (Array.isArray(params.rowData[params.field]) &&
                        params.rowData[params.field].length === 0)) &&
                params.rowData.isError;

            return isError;
        };

        return (
            <>
                {params.dropdownFor === 'fileSelection' && (
                    <DropdownInline
                        selectedValue={params.rowData[params.field]}
                        options={fileSelectionList}
                        optionValue="fileId"
                        optionLabel="fileName"
                        onChange={(value: number | number[]) =>
                            handleAddedNewFileChange(value, params.rowData)
                        }
                        selectionType={params.selectionType}
                        disabled={isLanguageSelectionDisabled}
                        isError={checkFieldError()}
                        showClear={false}
                    />
                )}
                {params.dropdownFor === 'languageSelection' && (
                    <DropdownInline
                        selectedValue={params.rowData[params.field]}
                        options={languageList}
                        onChange={(value: number | number[]) =>
                            handleLanguageChange(value, params.rowData)
                        }
                        selectionType={params.selectionType}
                        disabled={isLanguageSelectionDisabled}
                        isError={checkFieldError()}
                        showClear={true}
                    />
                )}
            </>
        );
    };
    const renderInlineTextBox = (params: InlineInputNumberDataType) => {
        return (
            <div className="card flex justify-content-center">
                <InputNumber
                    className="h-8"
                    value={params.rowData[params.field]}
                    onChange={(e) => handleAddWordCount(params.rowData, e.value as number)}
                    disabled={!params.rowData.fileId}
                    useGrouping={false}
                    minFractionDigits={0}
                    maxFractionDigits={0}
                />
            </div>
        );
    };

    // functions
    const addNewEmptyRowToTable = () => {
        const rowData: LanguageSelectionDataItem = {
            rowIndex: generateRandomId(),
            fileId: null,
            fileName: null,
            fileSize: '',
            sourceLanguage: null,
            targetLanguage: null,
            wordCount: null,
            // deliveryDate: '',
            documentType: '',
            documentTypeId: null,
            blobFileName: '',
            fileType: ''
        };
        const updatedTableData = [...tableData, rowData];

        updateFormData({ updatedTableData });
        setTableData(updatedTableData); // update table data to state
    };
    const updateFileSelectionList = ({
        uploadedFilesResData = uploadedFiles,
        updatedTableData = tableData
    }: {
        uploadedFilesResData?: UploadedDocumentInfo[];
        updatedTableData?: LanguageSelectionDataItem[];
    }) => {
        /** this function helps to disable the option which is already selected. */
        const updatedFilesList: UploadedDocumentInfo[] = uploadedFilesResData.map(
            (file: UploadedDocumentInfo) => {
                const shouldDisable: boolean = updatedTableData.some(
                    (tableFile) => file.fileId === tableFile.fileId
                );

                return {
                    ...file,
                    disabled: shouldDisable
                };
            }
        );

        setFileSelectionList(updatedFilesList); // updated unique list to load in files selection dropdown
    };
    const documentNameWithSizeTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileId + ' flex gap-2'}>
                    <p
                        className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        data-testid="documentName"
                        tabIndex={0}>
                        {rowData.fileName}
                    </p>
                    <p className="text-base text-neutral-200">{rowData.fileSize}</p>
                </div>
            </div>
        );
    };
    const handlePreviewDocument = (data: any, isDownload: boolean = false) => {
        if (!data) return;

        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(dataToPreviewDownload.sasURL as string).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${dataToPreviewDownload.blobUri}/${blobFileName}?${newSasUrl}`;

            if (isDownload) {
                utils.handleDownloadPngSvg(previewURL, fileName as string);
            } else {
                // Extract the file extension from the file type
                const fileExtension = (fileType || '').toLowerCase().split('/')[1];

                // Define an array of allowed file extensions for preview
                const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

                // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
                const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

                if (isImageOrPdf) {
                    // Extract file name without extension
                    const fileNameWithoutExtension = fileName.split('.')[0];

                    setDataToPreviewDownload({
                        ...dataToPreviewDownload,
                        previewImage: previewURL, // Set preview image name
                        previewImageName: fileNameWithoutExtension // Set preview image URL
                    });

                    // Show preview dialog
                    setIsPreviewFile(true);
                } else {
                    // Redirect to the file URL for non-preview files
                    window.open(previewURL, '_blank');
                }
            }
        });
    };
    const generateRandomId = (): number => {
        return Math.floor(1000 + Math.random() * 9000);
    };

    // table configuration
    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.DOWNLOAD'),
                    icon: () => <i className="pi pi-download text-primary" />,
                    disabled: !toggleRowData?.fileId,
                    className: `${!toggleRowData?.fileId ? 'hidden' : ''}`,
                    command() {
                        handlePreviewDocument(toggleRowData ?? null, true);
                    }
                },
                {
                    label: t('COMMON.DELETE'),
                    icon: () => <i className="pi pi-trash text-secondary" />,
                    command() {
                        toggleRowData?.rowIndex && handleDeleteRecord();
                    }
                }
            ]
        }
    ];
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'fileName',
            header: 'File Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            valueType: ValueType.Link,
            columnNumber: 0,
            visibility: true,
            body(rowData: any): any {
                return rowData.fileId
                    ? documentNameWithSizeTemplate(rowData)
                    : renderInlineDropdown({
                          field: 'fileName',
                          optionValue: 'fileId',
                          optionLabel: 'fileName',
                          selectionType: 'singleSelect',
                          rowData,
                          dropdownFor: 'fileSelection'
                      });
            },
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: false,
            filter: false,
            filterType: FilterType.Default,
            columnNumber: 1,
            visibility: true,
            body: (rowData: any) =>
                renderInlineDropdown({
                    field: 'sourceLanguage',
                    selectionType: 'singleSelect',
                    rowData,
                    dropdownFor: 'languageSelection'
                })
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: false,
            filter: false,
            filterType: FilterType.Default,
            columnNumber: 2,
            visibility: true,
            body: (rowData: any) =>
                renderInlineDropdown({
                    field: 'targetLanguage',
                    selectionType: 'multiSelect',
                    rowData,
                    dropdownFor: 'languageSelection'
                })
        },
        {
            field: 'wordCount',
            header: 'Word Count',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true,
            body: (rowData: any) =>
                renderInlineTextBox({
                    field: 'wordCount',
                    rowData
                })
        },
        // {
        //     field: 'deliveryDate',
        //     header: 'Delivery Date',
        //     sortable: false,
        //     filter: false,
        //     filterType: FilterType.Default,
        //     valueType: ValueType.Date,
        //     columnNumber: 3,
        //     visibility: true
        // },
        {
            field: 'documentType',
            header: 'Document Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            valueType: ValueType.Action,
            columnNumber: 5,
            visibility: true
        }
    ];
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.LANGUAGE_SELECTION,
        filters: {
            fileName: { value: null, matchMode: FilterMatchMode.CONTAINS },
            sourceLanguage: { value: null, matchMode: FilterMatchMode.IN },
            targetLanguage: { value: null, matchMode: FilterMatchMode.IN },
            wordCount: { value: null, matchMode: FilterMatchMode.CONTAINS },
            // deliveryDate: { value: null, matchMode: FilterMatchMode.DATE_IS },
            documentType: { value: null, matchMode: FilterMatchMode.CONTAINS }
        },
        reOrderableColumns: true,
        title: t('MENU.LANGUAGE_SELECTION'),
        customerHeader: (
            <div className="flex items-center justify-between mb-2 bg-white">
                <div>
                    <h4 className="font-semibold mb-3"> {t('MENU.LANGUAGE_SELECTION')}</h4>
                    <p className="bg-warning/40 w-fit my-3 py-0.5 px-2 rounded border-2 border-warning text-sm text-neutral-700 flex gap-1 items-center font-medium">
                        <i className="pi pi-info-circle text-warning-200 text-[0.90rem] font-semibold"></i>
                        {t(`LANGUAGE_SELECTION.WARNING`)}
                    </p>
                </div>
                <button
                    onClick={addNewEmptyRowToTable}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    data-testid="addNewRowButton"
                    className="btn button-primary font-medium rounded-md min-h-10 h-10"
                    disabled={uploadedFiles?.length === tableData?.length}>
                    <i className="pi pi-plus-circle text-base pt-0.5"></i>
                    <span className="font-medium">{t('COMMON.ADD')}</span>
                </button>
            </div>
        ),
        emptyMessage: t('LANGUAGE_SELECTION.EMPTY_MESSAGE'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.LANGUAGE_SELECTION_COLUMN_ORDERS,
        columns: columnSchema,
        items: menuItems,
        renderChildrenAlone: true,
        customTableHeight: true
    };

    // handlers - confirmation popup
    const handleDeleteRecord = () => {
        setShowFileDeletePopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t('File_UPLOAD.DELETE_CONFIRMATION')
        });
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            deleteFile(toggleRowData ?? null);
            setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
        }
    };
    const handleCancel = () => {
        setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
    };

    // toast
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    // helpers
    const registerFunctionsToStore = () => {
        /** register the functions on store while trigger the action buttons from footer component. */
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.PREVIEW,
            handlePreview
        );
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.DISCARD,
            handleDiscard
        );
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.SAVE, handleSave);
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.APPROVE,
            handleApprove
        );
    };
    const resetRegisteredFunctionsOnStore = () => {
        /** remove the registered function on store to avoid unwanted calls. */
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.PREVIEW, () => {});
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.DISCARD, () => {});
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.SAVE, () => {});
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.APPROVE, () => {});
    };

    // effects
    useEffect(() => {
        // initial api call
        getSourceLanguages();
        getUploadedFiles();
    }, []);

    useEffect(() => {
        updateFormData({ updatedTableData: tableData });
    }, [tableData]);

    useEffect(() => {
        registerFunctionsToStore();
        return () => {
            resetRegisteredFunctionsOnStore();
        };
    }, []);

    return (
        <>
            <div data-testid="TableComponent" className="tableComponent languageSelectionTable">
                {showFileDeletePopup.visible ? (
                    <ConfirmationPopup
                        onConfirm={handleConfirm}
                        onCancel={handleCancel}
                        visible={showFileDeletePopup.visible}
                        headerText={showFileDeletePopup.header}
                        description={showFileDeletePopup.description}
                        acceptLabel={t('COMMON.YES')}
                        rejectLabel={t('COMMON.NO')}
                        popupID={'deleteFileConfirmationPopup'}
                        data-testid="confirmationPopup"
                    />
                ) : null}
                {/* dialog box for 'Preview' */}
                {isPreviewSTD && (
                    <Dialog
                        header={t('COMMON.PREVIEW')}
                        style={{
                            minWidth: '60vw',
                            width: 'auto',
                            maxWidth: '80vw',
                            padding: '20px'
                        }}
                        visible={isPreviewSTD}
                        onHide={() => setIsPreviewSTD(false)}>
                        <iframe
                            src={`${previewSTDUrl}#toolbar=0&page=1&zoom=100,1,1`}
                            style={{ width: '100%', minHeight: '80vh' }}
                        />
                    </Dialog>
                )}
                {dataToPreviewDownload?.previewImage && (
                    <Dialog
                        header={
                            <div className="w-full flex justify-between items-center">
                                {dataToPreviewDownload.previewImageName}
                                <i
                                    className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                                    onClick={() =>
                                        utils.handleDownloadPngSvg(
                                            dataToPreviewDownload.previewImage as string,
                                            dataToPreviewDownload.previewImageName as string
                                        )
                                    }
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    data-test="downloadButton"
                                />
                            </div>
                        }
                        visible={isPreviewFile}
                        pt={previewDialogPopup}
                        style={{
                            minWidth: '60vw',
                            width: 'auto',
                            maxWidth: '80vw',
                            padding: '20px'
                        }}
                        onHide={() => setIsPreviewFile(false)}
                        data-testid="previewDialog">
                        <iframe
                            src={`${dataToPreviewDownload.previewImage}#toolbar=0&page=1&zoom=100,1,1`}
                            style={{ width: '100%', minHeight: '80vh' }}
                        />
                    </Dialog>
                )}

                <DataTableComponent
                    tableData={tableData}
                    tableRequestBodyData={requestBody}
                    tableDefinition={tableDefinition}
                    handleFilter={handleFilter}
                    isLazy={false}
                    toggleRowData={(rowData) => {
                        setToggleRowData(rowData as LanguageSelectionDataItem);
                    }}
                    data-testid="dataTableComponent"
                />
            </div>
        </>
    );
};

export default LanguageSelection;
