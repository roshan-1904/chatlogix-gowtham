import languageSelectionService from './languageSelection.service';
import HttpService from 'core/interceptor/api.handler';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { DOCUMENT_TYPE, SAVE_APPROVE_NUM } from 'constants/app.constant';

// Mock the dependencies
jest.mock('core/interceptor/api.handler');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('constants/endPoint', () => ({
    END_POINT: {
        ORDERS_AND_QUOTES_END_POINT: {
            STANDARD_SUBMISSION: '/update-language-selection'
        }
    }
}));
jest.mock('constants/app.constant', () => ({
    DOCUMENT_TYPE: {
        REFERENCE: { id: 1 }
    },
    NUMBER_TO_BOOLEAN: {
        0: false,
        1: true
    }
}));

describe('languageSelectionService', () => {
    const mockPost = jest.fn();
    const mockGetData = jest.fn();

    beforeEach(() => {
        (HttpService as jest.Mock).mockImplementation(() => ({
            post: mockPost
        }));
        (quoteOrderModuleStore.getData as jest.Mock).mockImplementation(mockGetData);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should save language selection successfully', async () => {
        const mockData = {
            info: {
                primaryId: 123,
                mode: 1,
                documentId: 456,
                selectedService: { patentType: 1 },
                selectedCategory: { patentCategoryId: 2 }
            },
            formData: {
                orderQuoteDetailsPage: {
                    companyName: { id: 789 },
                    requestCurrency: 1,
                    contactUser: { id: 987 },
                    poNumber: 'PO123',
                    referenceNumber: 'REF123',
                    deliverTo: [{ email: 'test@example.com' }],
                    cc: 'cc@example.com',
                    title: 'Test Title',
                    projectManager: [1, 2, 3],
                    salesRep: [4, 5, 6],
                    requestInvoiceStatus: 1,
                    instructionsCommentsContactUser: 'Contact Instructions',
                    instructionsCommentsProjectManager: 'PM Instructions',
                    quoteTargetDateTime: '2024-08-20T12:00:00',
                    requestedDeliveryDate: '2024-08-25T12:00:00',
                    quoteRequired: true
                },
                languageSelectionPage: [
                    {
                        fileId: 1,
                        sourceLanguage: 1,
                        targetLanguage: [2, 3],
                        documentType: DOCUMENT_TYPE.REFERENCE.id
                    }
                ]
            }
        };

        mockGetData.mockReturnValue(mockData);
        mockPost.mockResolvedValue({ status: 200, data: { success: true } });

        await languageSelectionService.saveLanguageSelection(SAVE_APPROVE_NUM.SAVE);

        expect(mockGetData).toHaveBeenCalled();
    });

    it('should throw an error if API call fails', async () => {
        const mockError = new Error('API Error');
        mockGetData.mockReturnValue({});
        mockPost.mockRejectedValue(mockError);

        await languageSelectionService.saveLanguageSelection(SAVE_APPROVE_NUM.SAVE);
    });
});
