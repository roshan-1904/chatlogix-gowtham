export interface LanguageSelectionDataItem {
    rowIndex?: number | null;
    id?: number | null;
    fileId: number | null;
    fileName: string | null;
    sourceLanguage: number | null;
    targetLanguage: number[] | null;
    wordCount: number | null;
    // deliveryDate: string;
    documentTypeId: number | null;
    documentType: string;
    fileType?: string;
    fileSize?: string;
    blobFileName?: string;
    isError?: boolean;
    isEdited?: boolean;
}

export interface LanguageSelectionSave {
    id: number;
    quoteStatus: number;
    requestNumber: string | null;
    requestTypeId: number | null;
    companyId: number;
    documentId: number | null;
    requestCurrencyId: number;
    contactUserId: number | null;
    patentCategoryId: number | null;
    patentServiceTypeId: number | null;
    quoteDateTime: string | null;
    requestedDeliveryDate: string | null;
    poNumber: string;
    referenceNumber: string;
    cc: string;
    title: string;
    projectManagers: string;
    salesRep: string;
    requestInvoiceStatus: boolean;
    instructionsContactUser: string;
    instructionsProjectManagers: string;
    alsoDeliverTo: string;
    isQuote: boolean;
    languageSections?: LanguageSections[] | null;
    disclaimerInfoList: any[];
    stdPreviewType: string | null;
}
export interface LanguageSections {
    fileId: number;
    sourceLanguageId: number | null;
    targetLanguagesId: string | null;
    // deliveryDate: string | null;
    documentType: number;
}

export interface DataToPreviewDownloadType {
    sasURL?: string | null;
    blobUri?: string | null;
    previewImage?: string | null;
    previewImageName?: string | null;
}
