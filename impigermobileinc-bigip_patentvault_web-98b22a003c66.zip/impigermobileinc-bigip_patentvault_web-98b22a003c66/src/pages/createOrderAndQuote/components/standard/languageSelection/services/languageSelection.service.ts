import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import {
    LanguageSections,
    LanguageSelectionDataItem,
    LanguageSelectionSave
} from '../types/languageSelection.type';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { NUMBER_TO_BOOLEAN } from 'constants/app.constant';
import orderQuoteDetailsService from '../../orderQuoteDetails/services/orderQuoteDetails.service';
import { formatDateYYMMDD, isContactUser } from 'core/utils/utils';
import { DisclaimerList } from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import AuthStore from 'core/store/authStore/authStore';
import { OrderSaveResponse } from 'pages/ordersAndQuotes/types/ordersAndQuotes.types';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

const deleteConfiguredFile = async <T>(primaryId: number, id: number): Promise<T> => {
    try {
        /** primaryId - id for edited quote got from edit api.
         *  id - that they append unique id to each file item after create. */

        const apiUrl = `${baseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STANDARD_DELETE_RECORD}/${primaryId}?languageSectionId=${id}`;
        const response = await httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

const saveLanguageSelection = async (
    status: number,
    exportType: number | null = null
): Promise<OrderSaveResponse<{ requestId: number; orderRequestNumber: string }> | null> => {
    const quoteOrderData = quoteOrderModuleStore.getData();
    const info = quoteOrderData.info;
    const loggedInUserId = AuthStore.getUserInfo()?.userInfo.userId;
    const loggedInUserRole = AuthStore.getUserInfo()?.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRole);
    const selectedCategory = quoteOrderData?.info?.selectedCategory;
    const oqDetailsPageData = quoteOrderData?.formData?.orderQuoteDetailsPage;
    const languageSelectionPageData = quoteOrderData?.formData?.languageSelectionPage;
    const alsoDeliverTo = oqDetailsPageData?.alsoDeliverTo as any[];

    // helpers
    const getDateTime = (key: string) => {
        const date = oqDetailsPageData ? oqDetailsPageData[key] : null;
        if (date && date !== '') return formatDateYYMMDD(date as string);
        return null;
    };
    const getDisclaimerList = async (): Promise<DisclaimerList[]> => {
        const referenceNo =
            quoteOrderData.editFlowResponseData?.info.referenceNo || quoteOrderData.info.primaryId; // this id logic only for STD flow
        let summaryDisclaimer: DisclaimerList[] =
            (await orderQuoteDetailsService.getStandardDisclaimers(referenceNo ?? 0)) ?? [];
        const customDisclaimer = oqDetailsPageData.customDisclaimerSTD;

        if (customDisclaimer?.length) {
            summaryDisclaimer = [
                ...summaryDisclaimer,
                {
                    sNo: summaryDisclaimer?.length > 0 ? summaryDisclaimer.length + 1 : 1,
                    disclaimer: customDisclaimer,
                    isCustomDisclaimer: true
                }
            ];
        }

        return summaryDisclaimer;
    };
    const getLanguageSelectionData = () => {
        const languageSections: LanguageSections[] =
            languageSelectionPageData?.tableData
                ?.filter(
                    (file): file is LanguageSelectionDataItem & { fileId: number } =>
                        typeof file.fileId === 'number' && file.fileId > 0
                )
                .map((file: LanguageSelectionDataItem & { fileId: number }) => {
                    return {
                        languageSectionId: file?.id ?? 0,
                        fileId: file?.fileId,
                        sourceLanguageId: file?.sourceLanguage ?? null,
                        targetLanguagesId: file?.targetLanguage?.join(', ') ?? null, // number[] to "1, 2, 3"
                        wordCount: file?.wordCount ?? 0,
                        // deliveryDate: getDateTime('requestedDeliveryDate') ?? null,
                        documentType: file?.documentTypeId ?? 0,
                        isEdited: file?.isEdited ?? false
                    };
                }) ?? [];

        return languageSections ?? [];
    };
    const pm: number[] =
        Array.isArray(oqDetailsPageData?.pmContainer?.projectManager) &&
        oqDetailsPageData?.pmContainer?.projectManager.length > 0
            ? oqDetailsPageData?.pmContainer?.projectManager
            : [];
    const salesRep: number[] =
        Array.isArray(oqDetailsPageData?.salesRepContainer?.salesRep) &&
        oqDetailsPageData?.salesRepContainer?.salesRep.length > 0
            ? oqDetailsPageData?.salesRepContainer?.salesRep
            : [];

    const dataToSave: LanguageSelectionSave = {
        id: quoteOrderData.editFlowResponseData?.info.primaryId ?? 0, // this id logic only for STD flow
        quoteStatus: status,
        requestNumber: info?.primaryId?.toString() ?? null, // referenceNo - which got in EDIT api
        documentId: info?.documentId ?? 0,
        requestTypeId: info?.mode ?? 0,
        companyId: oqDetailsPageData?.companyName.id ?? 0,
        contactUserId: isThisContactUser
            ? loggedInUserId
            : (oqDetailsPageData?.contactUser?.id ?? 0),
        requestCurrencyId: isThisContactUser
            ? (oqDetailsPageData.companyName?.requestCurrencyId ?? 0)
            : (oqDetailsPageData.requestCurrencyId ?? 0),
        patentCategoryId: selectedCategory?.parentId ?? 0,
        patentServiceTypeId: selectedCategory?.patentCategoryId ?? 0,
        quoteDateTime: getDateTime('quoteTargetDateTime'),
        requestedDeliveryDate: getDateTime('requestedDeliveryDate'),
        poNumber: oqDetailsPageData?.poNumber?.toString() ?? null,
        referenceNumber: oqDetailsPageData?.referenceNumber?.toString() ?? null,
        cc: oqDetailsPageData?.cc ?? null,
        title: oqDetailsPageData?.title ?? null,
        alsoDeliverTo: alsoDeliverTo?.join(', ') ?? null,
        projectManagers: pm.join(', '), // number[] to "1, 2, 3"
        salesRep: salesRep?.join(', '), // number[] to "1, 2, 3"
        requestInvoiceStatus: NUMBER_TO_BOOLEAN[oqDetailsPageData?.requestInvoiceStatus] ?? false,
        instructionsContactUser: oqDetailsPageData?.instructionByContactUser ?? null,
        instructionsProjectManagers: oqDetailsPageData?.instructionByProjectManager ?? null,
        isQuote: info?.mode === 1,
        // isQuote: oqDetailsPageData?.quoteRequired ?? false,
        languageSections: getLanguageSelectionData(),
        disclaimerInfoList: await getDisclaimerList(),
        stdPreviewType: quoteOrderData.info.stdPreviewType ?? null
    };

    try {
        const queryString = exportType ? `?fileExportType=${exportType}` : '';
        const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.STANDARD_SUBMISSION}${queryString}`;

        const response: OrderSaveResponse<{ requestId: number; orderRequestNumber: string }> =
            await httpService.post(apiUrl, dataToSave, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error while saving language selection', error);
        return null;
    }
};

const languageSelectionService = {
    deleteConfiguredFile,
    saveLanguageSelection
};

export default languageSelectionService;
