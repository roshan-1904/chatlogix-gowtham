import languageSelectionService from './languageSelection.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { LanguageSelectionDataItem } from '../types/languageSelection.type';
import { MODE, STATUS_MODE, SAVE_APPROVE_NUM, DOCUMENT_TYPE } from 'constants/app.constant';
import { NavigateFunction } from 'react-router-dom';
import orderQuoteServices, {
    exportActions
} from 'pages/createOrderAndQuote/services/createOrderAndQuote.service';
import { getOrderDetails } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { ViewOrderType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { isContactUser, isStaffUser, isVendorUser } from 'core/utils/utils';
import AuthStore from 'core/store/authStore/authStore';
import {
    DocumentGroupModel,
    GroupedResultModel,
    GroupErrors
} from '../../uploadAndLanguageSelection/types/uploadAndLanguageSelection.type';
import { FilePayload, TransformedObject } from 'components/fileUpload/types/fileUpload.types';

export interface ActionParamsLanguageSelection {
    translate: (key: string) => string;
    navigateTo: NavigateFunction;
    requestId?: string;
    updateLanguageSelectionTableData?: React.Dispatch<
        React.SetStateAction<LanguageSelectionDataItem[]>
    >;
    setIsPreviewSTD?: React.Dispatch<React.SetStateAction<boolean>>;
    setPreviewSTDUrl?: React.Dispatch<React.SetStateAction<string>>;
}

// STD
export interface HandleLanguageChangeModel {
    group: DocumentGroupModel;
    fieldName: 'sourceLanguage' | 'targetLanguage';
    updatedLanguage: number[];
    isStoreAsTempData?: boolean;
}

const getStaticVariables = () => {
    const quoteOrderData = quoteOrderModuleStore.getData();
    const loggedInUserRoleId = AuthStore.getUserInfo().userInfo.roleId;
    const mode = quoteOrderData.info.mode;

    return {
        quoteOrderData,
        loggedInUserRoleId,
        mode,
        isThisStaffUser: isStaffUser(loggedInUserRoleId),
        isThisVendorUser: isVendorUser(loggedInUserRoleId),
        isThisContactUser: isContactUser(loggedInUserRoleId),
        isQuoteCreationMode: mode === MODE.CREATE_QUOTE,
        isEditFlow: quoteOrderData.info.isEditFlow === true,
        isWFA: quoteOrderData.info.statusId === STATUS_MODE.WAITING_FOR_APPROVAL,
        isPreparingQuote: quoteOrderData.info.statusId === STATUS_MODE.PREPARING_QUOTE,
        stdPreviewType: quoteOrderData.info.stdPreviewType
    };
};

// toast
const showToastMessage = (toastMsg: string, errorType: ToastType) => {
    const message: notificationModel = {
        message: toastMsg,
        type: errorType
    };
    NotificationStore.showAlert(message);
};

// api
const triggerToSaveLanguageSelection = async (
    userTriggerActionTo: number, // this will decide the action to save / approve
    exportType?: number
) => {
    try {
        // this function to trigger the submission to save / approve
        const response = await languageSelectionService.saveLanguageSelection(
            userTriggerActionTo,
            exportType
        );
        return response?.orderResponse?.requestId ? response : null;
    } catch (error) {
        console.error('Error saving language selection:', error);
        return null;
    }
};

// helper functions
const validateLanguageSelectionTable = (params: ActionParamsLanguageSelection): boolean | null => {
    try {
        const languageSelectionPageData =
            quoteOrderModuleStore.getData()?.formData?.languageSelectionPage;
        const {
            isQuoteCreationMode,
            isThisStaffUser,
            isThisVendorUser,
            isEditFlow,
            isPreparingQuote,
            stdPreviewType
        } = getStaticVariables();

        /** check-point 01: restrict the submission if table is empty. */
        if (
            !languageSelectionPageData?.tableData ||
            languageSelectionPageData.tableData.length === 0 ||
            languageSelectionPageData.tableData.every((file) => file.fileId === null)
        ) {
            showToastMessage(
                params?.translate('LANGUAGE_SELECTION.WARNING_EMPTY_TABLE_DATA'),
                ToastType.ERROR
            );
            return null;
        }

        /** check-point 02: restrict the submission if table has incomplete data. */
        const updatedTableData: LanguageSelectionDataItem[] =
            languageSelectionPageData.tableData.map((file) => {
                const isError =
                    file.fileId !== null &&
                    (!file.sourceLanguage ||
                        !file.targetLanguage ||
                        file.targetLanguage.length === 0);
                return { ...file, isError };
            });
        const isTableInError = updatedTableData.some((file) => file.isError);
        if (isTableInError) {
            showToastMessage(
                params?.translate('LANGUAGE_SELECTION.WARNING_INCOMPLETE_DATA'),
                ToastType.ERROR
            );
            params?.updateLanguageSelectionTableData &&
                params.updateLanguageSelectionTableData(updatedTableData);
            return false;
        }

        /** check-point 03: restrict submission if preview template not selected. */
        if (
            isQuoteCreationMode &&
            (isThisStaffUser || isThisVendorUser) &&
            (!isEditFlow || (isEditFlow && isPreparingQuote)) &&
            !stdPreviewType
        ) {
            showToastMessage(
                params?.translate(
                    'LANGUAGE_SELECTION.WARNING_EMPTY_PREVIEW_TEMPLATE_ON_SAVE_QUOTE'
                ),
                ToastType.ERROR
            );
            return null;
        }

        return true; // proceed language selection page submission
    } catch (error) {
        console.error('Error in onSubmit():', error);
        return null;
    }
};
const isDocumentsModified = (): boolean => {
    /** 'id' is unique. this id available only in saved files. we can compare and find out 
        that the user modified (add/delete) the selected documents or not. */
    const languageSelectionPageData =
        quoteOrderModuleStore.getData()?.formData?.languageSelectionPage;

    const existingSavedIds = languageSelectionPageData?.savedFilesIdsReceivedInEditMode ?? [];
    // id -> saved file ids in db. fileId -> it will create against the document id from No1.
    const currentIds: number[] =
        languageSelectionPageData?.tableData
            ?.map((doc) => (doc && typeof doc === 'object' ? doc.id : null))
            .filter((id): id is number => id !== null && id !== undefined) ?? [];

    const isModified: boolean =
        existingSavedIds.length !== currentIds.length ||
        !currentIds.every((id) => existingSavedIds.includes(id));

    return isModified;
};
const isApproveButtonDisable = (): boolean => {
    const isModified = isDocumentsModified();

    const { isThisStaffUser, isThisVendorUser, isThisContactUser, mode, isEditFlow, isWFA } =
        getStaticVariables();

    const isEnable: boolean =
        isThisStaffUser ||
        isThisVendorUser ||
        (isThisContactUser && (mode === MODE.CREATE_ORDER || (isEditFlow && isWFA && !isModified)));

    return !isEnable;
};

// actions handlers
const handleApproveAction = async (params: ActionParamsLanguageSelection) => {
    try {
        const isProceed = validateLanguageSelectionTable(params);
        if (!isProceed) throw new Error('Sorry, Cannot proceed handleApproveAction');

        const response = await triggerToSaveLanguageSelection(SAVE_APPROVE_NUM.APPROVE);
        if (response?.orderResponse?.requestId) {
            // toast
            const { isQuoteCreationMode } = getStaticVariables();
            const toastMsg = isQuoteCreationMode
                ? 'LANGUAGE_SELECTION.HEADER_QUOTE_SUBMISSION'
                : 'LANGUAGE_SELECTION.HEADER_ORDER_SUBMISSION';
            showToastMessage(params.translate(toastMsg), ToastType.SUCCESS);

            quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', {
                action: 'approve',
                requestId: response?.orderResponse?.requestId,
                requestNumber: response?.orderResponse?.orderRequestNumber,
                isActionResolved: true
            }); // to trigger popup (for completion)
        }
    } catch (e) {
        console.error('Error in handleApproveAction():', e);
        return null;
    }
};
const handleSaveAction = async (params: ActionParamsLanguageSelection, exportType?: number) => {
    try {
        const isProceed = validateLanguageSelectionTable(params);
        if (!isProceed) throw new Error('Sorry, Cannot proceed handleSaveAction');

        const response = await triggerToSaveLanguageSelection(SAVE_APPROVE_NUM.SAVE, exportType);
        if (response?.orderResponse?.requestId) {
            const { isQuoteCreationMode, isEditFlow } = getStaticVariables();

            let toastMsg = '';
            if (isQuoteCreationMode && isEditFlow)
                toastMsg = 'LANGUAGE_SELECTION.HEADER_QUOTE_SUBMISSION_EDIT';
            else if (isQuoteCreationMode) toastMsg = 'LANGUAGE_SELECTION.HEADER_QUOTE_SUBMISSION';
            else toastMsg = 'LANGUAGE_SELECTION.HEADER_ORDER_SUBMISSION';
            showToastMessage(params.translate(toastMsg), ToastType.SUCCESS);

            if (exportType) exportActions(response);

            quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', {
                action: 'save',
                requestId: response?.orderResponse?.requestId,
                requestNumber: response?.orderResponse?.orderRequestNumber,
                isActionResolved: true
            }); // to trigger popup (for completion)
        }
    } catch (e) {
        console.error('Error in handleSaveAction():', e);
        return null;
    }
};
const stdPreviewPDF = async (params: ActionParamsLanguageSelection) => {
    if (!params?.requestId) {
        alert('Preview is in-progress');
        return;
    }

    try {
        const viewPageResponse = await getOrderDetails<ViewOrderType>(params.requestId);
        if (!viewPageResponse) throw new Error();

        const templateName: string | null = viewPageResponse?.stdPreviewType || null;
        // const referenceNo = viewPageResponse?.headers?.requestId;
        if (templateName) {
            const response = await orderQuoteServices.getPDFData(templateName);

            if (response) {
                params?.setPreviewSTDUrl && params.setPreviewSTDUrl(response);
                params?.setIsPreviewSTD && params.setIsPreviewSTD(true);
            }
        }
    } catch (error) {
        showToastMessage(
            params?.translate('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
            ToastType.ERROR
        );
    }
};

// new STD functions
const isGroupContainsErrors = (groupErrors: GroupErrors) => {
    const isInvalid = Object.entries(groupErrors)
        .filter(([key]) => key !== 'isInvalidReference')
        .some(([_, errorValue]) => errorValue);

    return isInvalid;
};
const setErrorForInvalidItems = (
    group: DocumentGroupModel,
    addingFilesToExistingCombination: boolean // existing section already has min one source file
) => {
    const { sourceLanguage, targetLanguage } = group;
    const isValidSource =
        group.documentList.length > 0 &&
        group.documentList.some((document) => document.documentType === DOCUMENT_TYPE.SOURCE.id);
    const isValidReference =
        group.documentList.length > 0 &&
        group.documentList.some((document) => document.documentType === DOCUMENT_TYPE.REFERENCE.id);

    // any one of the document is valid
    const hasSomeValidDocuments = isValidSource || isValidReference;

    const groupError: GroupErrors = {
        isInvalidSL: !sourceLanguage?.length,
        isInvalidTL: !targetLanguage?.length,
        isInvalidSource: addingFilesToExistingCombination ? !hasSomeValidDocuments : !isValidSource,
        isInvalidReference: addingFilesToExistingCombination ? !hasSomeValidDocuments : false
        // isInvalidSource: !isValidSource,
        // isInvalidReference: !isValidReference
    };
    return { ...group, errors: groupError };
};
const validateLanguageSelection = ({
    group,
    fieldName,
    updatedLanguage
}: HandleLanguageChangeModel) => {
    const oppositeField = fieldName === 'sourceLanguage' ? 'targetLanguage' : 'sourceLanguage';
    const oppositeValues = group[oppositeField];

    // Validation 1: Both SL & TL fields should not have multiple values.
    if (updatedLanguage.length > 1 && oppositeValues.length > 1) {
        showToastMessage(
            'Either the source or target language can have multiple values.',
            ToastType.WARNING
        );
        return false;
    }

    // Validation 2: Both SL & TL fields should not have the same value.
    const commonValues = updatedLanguage.filter((value) => oppositeValues.includes(value));
    if (commonValues.length > 0) {
        showToastMessage('The source and target languages cannot be the same.', ToastType.WARNING);
        return false;
    }

    return true;
};
const validateGroupsAndSetError = (
    type: 'single-group' | 'multiple-groups',
    groups: DocumentGroupModel[],
    isAddingToExistingSectionOnDetailsPage: boolean = false
): { isInvalid: boolean; groups: DocumentGroupModel[] } => {
    /** this statement validate the given group(s) and set the errors to selectedGroup/pageData.groups.
        also this function returns the updatedGroupList[] & invalidStatus */
    switch (type) {
        case 'single-group': {
            const validatedGroup: DocumentGroupModel =
                standardModuleService.setErrorForInvalidItems(
                    groups[0],
                    isAddingToExistingSectionOnDetailsPage
                );

            const isThisInvalidGroup = standardModuleService.isGroupContainsErrors(
                validatedGroup.errors
            );

            return { isInvalid: isThisInvalidGroup, groups: [validatedGroup] };
        }

        case 'multiple-groups': {
            // get only active groups
            const activeGroups = groups.filter((group) => !group.isGroupInActive);
            const validatedGroupList: DocumentGroupModel[] = activeGroups.map((group) =>
                standardModuleService.setErrorForInvalidItems(
                    group,
                    isAddingToExistingSectionOnDetailsPage
                )
            );

            const isAnyInvalidGroupFromList = validatedGroupList.some((group) =>
                standardModuleService.isGroupContainsErrors(group.errors)
            );

            return { isInvalid: isAnyInvalidGroupFromList, groups: validatedGroupList };
        }
        default:
            return { isInvalid: true, groups };
    }
};
const getFilesList = (
    prevLength: number,
    prevStateDoctList: FilePayload[],
    newDoctList: FilePayload[],
    defaultNotes?: string
) => {
    /** set the unique id for each file. */
    newDoctList.forEach((file, index) => {
        file.fileUniqueId = prevLength + index + 1;
        if (defaultNotes) file.fileNotes = defaultNotes;
    });

    const filesList = [...prevStateDoctList, ...newDoctList];
    return filesList;
};
const constructUploadedFIlesToAdd = (files: TransformedObject[]) => {
    const result: { [key: string]: GroupedResultModel } = {};

    files.forEach((item) => {
        const { primaryId, stdGroupId, filePayload, notesForUploadedFiles } = item;
        if (!(stdGroupId === 0 || stdGroupId))
            throw new Error('Group Id is missing in the payload.');

        const key = `${primaryId}-${stdGroupId}`;

        if (!result[key]) {
            result[key] = { primaryId, stdGroupId, notesForUploadedFiles, file: [] };
        }

        result[key].file.push(filePayload);
    });

    const uploadedFilesGroup = Object.values(result)[0];
    return uploadedFilesGroup;
};

const standardModuleService = {
    // actions handlers
    handleApproveAction,
    handleSaveAction,
    stdPreviewPDF,
    validateLanguageSelectionTable,

    // helper
    getStaticVariables,
    isApproveButtonDisable,

    // new STD
    // helpers
    isGroupContainsErrors,
    setErrorForInvalidItems,
    validateLanguageSelection,
    validateGroupsAndSetError,
    getFilesList,
    constructUploadedFIlesToAdd
};
export default standardModuleService;
