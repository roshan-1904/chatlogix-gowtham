import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import LanguageSelection from './languageSelection';
import { BrowserRouter as Router } from 'react-router-dom';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('../services/languageSelection.service');
jest.mock('components/fileUpload/services/fileUpload.service');
jest.mock('pages/pvsettings/subaccordions/service/pvsettings.service');
jest.mock('components/fileUpload/services/fileUpload.service', () => ({
    getUploadedDocumentList: jest.fn()
}));
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

// Mock dependencies
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    __esModule: true,
    default: {
        subscribe: jest.fn(),
        getData: jest.fn(),
        updatePage: jest.fn()
    },
    subscribe: jest.fn()
}));

jest.mock('../services/languageSelection.service', () => ({
    saveLanguageSelection: jest.fn()
}));

jest.mock('../../../../../../components/fileUpload/services/azureStorage.service.tsx', () => ({
    getSasUrl: jest.fn()
}));

jest.mock('core/interceptor/api.handler');

describe('LanguageSelection Component', () => {
    beforeEach(() => {
        // Mock implementation
        jest.clearAllMocks();
    });

    test('renders LanguageSelection component', async () => {
        render(
            <Router>
                <LanguageSelection />
            </Router>
        );

        await waitFor(() => {
            expect(screen.getByTestId('TableComponent')).toBeInTheDocument();
            expect(PVSettingsService.getAllLanguages).toHaveBeenCalled();
            expect(fileUploadService.getUploadedDocumentList).toHaveBeenCalled();
        });
    });

    it('subscribes to NotificationStore on mount', () => {
        render(
            <Router>
                <LanguageSelection />
            </Router>
        );
        expect(quoteOrderModuleStore.subscribe).toHaveBeenCalledTimes(1);
    });

    test('submits the form', async () => {
        render(
            <Router>
                <LanguageSelection />
            </Router>
        );

        await waitFor(() => {
            expect(screen.getByTestId('TableComponent')).toBeInTheDocument();
        });
    });
});
