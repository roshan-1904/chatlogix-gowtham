import { ActionToProceedSTD } from 'pages/createOrderAndQuote/createOrderAndQuote';

const STD_STEPPER_ACTIONS = {
    PREVIEW: 'STD_Stepper_Action_Preview',
    DISCARD: 'STD_Stepper_Action_Discard',
    CONFIRM_B4_SUBMIT: 'STD_Stepper_Action_Confirm_Before_Submit',
    SAVE: 'STD_Stepper_Action_Save',
    APPROVE: 'STD_Stepper_Action_Approve'
};

const stdActionButtonStatusInit: ActionToProceedSTD = {
    isPreview: false,
    isDiscard: false,
    isSave: false,
    isApprove: false
};

const stdConstants = { STD_STEPPER_ACTIONS, stdActionButtonStatusInit };
export default stdConstants;
