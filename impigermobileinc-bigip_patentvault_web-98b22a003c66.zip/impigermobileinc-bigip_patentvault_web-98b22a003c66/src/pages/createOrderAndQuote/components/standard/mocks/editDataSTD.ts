// const payloadData = {
//     id: 0,
//     requestNumber: '8021',
//     requestTypeId: 1,
//     companyId: 40,
//     documentId: 1696,
//     requestCurrencyId: 2,
//     contactUserId: 72,
//     patentCategoryId: 24,
//     patentServiceTypeId: 4,
//     quoteDateTime: '2024-08-24T10:14:49.554Z',
//     requestedDeliveryDate: '2024-08-23T00:00:00+05:30',
//     poNumber: '123',
//     referenceNumber: '123',
//     alsoDeliverTo: 'cuser1@gmail.com,cuser3@gmail.com',
//     cc: 'cc@mail.com,cc2@mail.com',
//     title: 'Title',
//     projectManagers: '124, 399',
//     salesRep: '2, 623',
//     requestInvoiceStatus: false,
//     instructionsContactUser: '',
//     instructionsProjectManagers: 'PM - Internal Instructions & Comments',
//     isQuote: true
// };

export const editDataSTD = {
    info: {
        mode: 1, // number - quote / order
        selectedServiceId: 24, // number - **CATEGORY (Ulta)
        selectedCategoryId: 5, // number - **SERVICE (Ulta)
        referenceNo: 8021, // number (Edit flow - id)
        documentId: 1696 // against uploaded document
    },
    formData: {
        companyDetailsPage: {
            selectedCompanyId: 40, // number / null
            selectedContactId: 72 // number / null
        },
        orderQuoteDetailsPage: {
            title: 'Title', // string / null
            requestedDeliveryDate: '2024-08-23T00:00:00+05:30', // string / null
            quoteTargetDateTime: '2024-08-24T10:14:49.554Z', // string / null
            poNumber: '123', // string / null
            referenceNumber: '123', // string / null
            deliverTo: 'cuser1@gmail.com,cuser3@gmail.com', // NUMBERWithCommaSeparated / null
            quoteRequired: true, // boolean
            cc: 'cc@mail.com,cc2@mail.com', // STRING-MailWithCommaSeparated / null
            projectManager: '124, 399', // NUMBERWithCommaSeparated / null
            salesRep: '2, 623', // NUMBERWithCommaSeparated / null
            requestCurrency: 2, // number / null
            requestInvoiceStatus: false, // boolean
            instructionByContactUser: '', // string / null,
            instructionByProjectManager: 'PM - Internal Instructions & Comments' // string / null,
        },
        // languageSections -> just send what we have sent in the payload
        languageSelectionPage: {
            tableData: [
                {
                    fileId: 1,
                    sourceLanguageId: 161,
                    targetLanguagesId: '161, 160',
                    deliveryDate: '2024-08-31T00:00:00+05:30',
                    documentType: 2,
                    isEdited: false
                },
                {
                    fileId: 2,
                    sourceLanguageId: 159,
                    targetLanguagesId: '159, 160',
                    deliveryDate: '2024-08-31T00:00:00+05:30',
                    documentType: 1,
                    isEdited: false
                }
            ]
        }
    }
};
