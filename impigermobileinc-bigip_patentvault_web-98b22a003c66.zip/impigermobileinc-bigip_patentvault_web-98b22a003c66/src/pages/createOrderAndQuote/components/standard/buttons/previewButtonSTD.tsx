import { MODE } from 'constants/app.constant';
import { previewDialogPopup } from 'constants/styles.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import utils, { getWindowSize, isStaffUser, isVendorUser } from 'core/utils/utils';
import CustomPreviewTemplate from 'pages/ViewOrderAndQuote/components/billsAndInvoices/customPreviewTemplate';
import { getPDFData } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { Dialog } from 'primereact/dialog';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

const visibilityInit = {
    isShowPreviewSelection: false,
    isFilePreview: false
};

const PreviewButtonSTD = () => {
    const { t } = useTranslation();
    const [visibility, setVisibility] = useState<{ [key: string]: boolean }>(visibilityInit);
    const [previewPDFUrl, setPreviewPDFUrl] = useState<string>('');

    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    const loggedInUserRoleId = userDetails?.userInfo?.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isEditFlow = quoteOrderData?.info?.isEditFlow === true;
    const isQuoteCreationMode = quoteOrderData?.info?.mode === MODE.CREATE_QUOTE;
    const previewReferenceId: number | null = quoteOrderData?.info?.previewReferenceId ?? null;
    const stdPreviewType = quoteOrderData?.info?.stdPreviewType ?? null;

    // helpers
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const isShowPreviewIcon = (): boolean => {
        return (
            (isThisStaffUser || isThisVendorUser) &&
            isEditFlow &&
            !!previewReferenceId /** without this 'refId' can't make preview. we got this only from saved quotes. */
        );
    };

    // handlers
    const downloadPDF = async (templateName: string, _requestNo: number) => {
        try {
            if (!templateName || !previewReferenceId)
                throw new Error('Invalid data to download file.');

            const response = await getPDFData(templateName, previewReferenceId);
            if (response) {
                setPreviewPDFUrl(response);
                setVisibility({ ...visibility, isFilePreview: true });
            }
        } catch (error) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
                type: ToastType.ERROR
            });
            console.error('Error in DownloadPDF(): ', error);
            return null;
        }
    };
    const updatePreviewTypeInStore = async (documentType: string) => {
        const updatedQuoteOrderInfo = {
            ...quoteOrderData.info,
            stdPreviewType: documentType
        };
        setQuoteOrderData({ ...quoteOrderData, info: updatedQuoteOrderInfo }); // local state update
        quoteOrderModuleStore.updatePage('info', updatedQuoteOrderInfo); // store update

        await new Promise((r) => setTimeout(r, 250)); // delay to show updated preview after selection
        setVisibility({ ...visibility, isShowPreviewSelection: false });
    };

    // preview selection data
    const previewTemplateData = {
        orderId: previewReferenceId ?? null,
        documentList: [
            {
                previewTypeId: 'BIGIP_Quote',
                previewTypeName: t('PDF_TYPES_INVOICE.QUOTE')
            },
            {
                previewTypeId: 'BIGIP_Quote_SalesOrder_NoRate_Qty',
                previewTypeName: t('PDF_TYPES_INVOICE.NO_RATE_QUANTITY')
            }
        ],
        currentDocumentType: stdPreviewType,
        updateCurrentDocumentType: updatePreviewTypeInStore,
        download: downloadPDF,
        visibility: { isShowPreviewIcon: isShowPreviewIcon(), isShowSaveButton: false } // save button not needed in STD stepper
    };

    return (
        <>
            {visibility.isFilePreview && (
                <Dialog
                    header={
                        <div className="w-full flex justify-between items-center">
                            {(isQuoteCreationMode
                                ? t('COMMON.QUOTE') + ' - '
                                : t('COMMON.ORDER') + ' - ') + 'Preview'}
                            <i
                                className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                                onClick={() =>
                                    utils.handleDownloadPngSvg(
                                        previewPDFUrl,
                                        (isQuoteCreationMode
                                            ? t('COMMON.QUOTE') + ' - '
                                            : t('COMMON.ORDER') + ' - ') + 'Preview'
                                    )
                                }
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                data-testid="downloadPDFButtonSTD"
                            />
                        </div>
                    }
                    visible={visibility.isFilePreview}
                    pt={previewDialogPopup}
                    style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                    onHide={() => setVisibility({ ...visibility, isFilePreview: false })}>
                    <iframe
                        src={`${previewPDFUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                        style={{ width: '100%', minHeight: '80vh' }}
                    />
                </Dialog>
            )}

            <button
                data-testid="previewButtonSTD"
                className="btn button-primary-outline min-h-[2.40rem] h-[2.40rem] !font-medium"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() =>
                    setVisibility({
                        ...visibility,
                        isShowPreviewSelection: !visibility.isShowPreviewSelection
                    })
                }>
                {t('COMMON.PREVIEW')}
            </button>
            <div
                data-testid="customPreviewTemplateSTD"
                className="absolute right-54 bottom-14 z-10 flex flex-col items-start justify-end ">
                {visibility.isShowPreviewSelection && (
                    <CustomPreviewTemplate templateData={previewTemplateData} />
                )}
            </div>
        </>
    );
};

export default PreviewButtonSTD;
