import { render, screen, fireEvent } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import { SplitButton } from 'primereact/splitbutton';
import SplitButtonSTD from '../splitButtonSTD';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MODE } from 'constants/app.constant';
import { PATHS } from 'constants/routes.constant';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

// Mock necessary modules and components
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));
jest.mock('react-router-dom', () => ({
    useNavigate: jest.fn()
}));
jest.mock('primereact/splitbutton', () => ({
    SplitButton: jest.fn(() => <button data-testid="mock-split-button">SplitButton</button>)
}));
jest.mock('components/confirmationPopup/confirmationPopup', () => {
    return jest.fn(() => <div data-testid="mock-confirmation-popup">ConfirmationPopup</div>);
});
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(() => ({
        info: {
            mode: MODE.CREATE_QUOTE,
            isEditFlow: false
        }
    })),
    registerFunction: jest.fn()
}));
jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn(() => ({
        userInfo: {
            roleId: 1
        }
    }))
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => {
    const mockData = {
        info: {
            mode: 1,
            isEditFlow: false
        },
        refs: {}
    };
    const mockRegisterFunction = jest.fn();
    const mockInvokeFunction = jest.fn();
    const mockUpdatePage = jest.fn();
    const mockResetQuoteOrderStore = jest.fn();

    return {
        getData: jest.fn(() => mockData),
        registerFunction: mockRegisterFunction,
        invokeFunction: mockInvokeFunction,
        updatePage: mockUpdatePage,
        resetQuoteOrderStore: mockResetQuoteOrderStore,
        init: jest.fn(),
        subscribe: jest.fn(),
        __esModule: true
    };
});

describe('SplitButtonSTD Component', () => {
    let handleButtonClick: jest.Mock;
    let navigate: jest.Mock;

    beforeEach(() => {
        handleButtonClick = jest.fn();
        navigate = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(navigate);
        (ConfirmationPopup as jest.Mock).mockImplementation(() => (
            <div data-testid="mock-confirmation-popup">ConfirmationPopup</div>
        ));
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('renders SplitButtonSTD component in Quote Creation Mode', () => {
        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);
        expect(screen.getByTestId('splitButtonSTD')).toBeInTheDocument();
    });

    it('renders SplitButtonSTD component in Quote Creation Mode', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: { mode: MODE.CREATE_ORDER, isEditFlow: false }
        });
        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);
        expect(screen.queryByTestId('splitButtonSTD')).not.toBeInTheDocument();
    });

    it('handles save quote', () => {
        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);
        const splitButton = screen.getByTestId('splitButtonSTD');
        fireEvent.click(splitButton);
        expect(handleButtonClick).toHaveBeenCalled();
    });

    it('triggers popup when discard is clicked', () => {
        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);

        // Mock SplitButton to simulate menu item click
        (SplitButton as jest.Mock).mockImplementation(({ model }: any) => {
            return (
                <>
                    <button data-testid="mock-split-button">SplitButton</button>
                    <button data-testid="discard-button" onClick={() => model[2].command()}>
                        Discard
                    </button>
                </>
            );
        });

        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);

        const discardButton = screen.getByTestId('discard-button');
        fireEvent.click(discardButton);

        expect(ConfirmationPopup).toHaveBeenCalled();
    });

    it('navigates to listing page when popup is confirmed and action is resolved', () => {
        (ConfirmationPopup as jest.Mock).mockImplementation(({ onConfirm }: any) => {
            return (
                <>
                    <div data-testid="mock-confirmation-popup">ConfirmationPopup</div>
                    <button data-testid="confirm-button" onClick={() => onConfirm()}>
                        Confirm
                    </button>
                </>
            );
        });

        const mockRegisterFunction = jest.fn();
        const mockInvokeFunction = jest.fn(); // Changed from mockExecuteFunction

        (quoteOrderModuleStore.registerFunction as jest.Mock).mockImplementation(
            mockRegisterFunction
        );
        (quoteOrderModuleStore.invokeFunction as jest.Mock).mockImplementation(mockInvokeFunction); // Changed from executeFunction

        const params = {
            isActionResolved: true,
            action: 'save',
            requestId: 123,
            requestNumber: '123'
        };

        mockRegisterFunction.mockImplementation((_key, callback) => {
            callback(params);
        });

        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);

        quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', params); // Changed from executeFunction

        const confirmButton = screen.getByTestId('confirm-button');
        fireEvent.click(confirmButton);

        expect(navigate).toHaveBeenCalledWith(`/${PATHS.ORDER_QUOTE}`);
        expect(quoteOrderModuleStore.invokeFunction).toHaveBeenCalledWith(
            'STDFinalPagePopupTrigger',
            params
        ); // Changed from executeFunction
    });

    it('calls handleButtonClick when popup is confirmed and action is not resolved', () => {
        (ConfirmationPopup as jest.Mock).mockImplementation(({ onConfirm }: any) => {
            return (
                <>
                    <div data-testid="mock-confirmation-popup">ConfirmationPopup</div>
                    <button data-testid="confirm-button" onClick={() => onConfirm()}>
                        Confirm
                    </button>
                </>
            );
        });

        const mockRegisterFunction = jest.fn();
        const mockInvokeFunction = jest.fn();

        (quoteOrderModuleStore.registerFunction as jest.Mock).mockImplementation(
            mockRegisterFunction
        );
        (quoteOrderModuleStore.invokeFunction as jest.Mock).mockImplementation(mockInvokeFunction);

        const params = {
            isActionResolved: false,
            action: 'save'
        };

        mockRegisterFunction.mockImplementation((_key, callback) => {
            callback(params);
        });

        render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);

        quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', params);

        const confirmButton = screen.getByTestId('confirm-button');
        fireEvent.click(confirmButton);

        expect(handleButtonClick).toHaveBeenCalled();
        expect(quoteOrderModuleStore.invokeFunction).toHaveBeenCalledWith(
            'STDFinalPagePopupTrigger',
            params
        );
    });

    it('resets popup config when popup is canceled', () => {
        (ConfirmationPopup as jest.Mock).mockImplementation(({ onCancel }: any) => {
            return (
                <>
                    <div data-testid="mock-confirmation-popup">ConfirmationPopup</div>
                    <button data-testid="cancel-button" onClick={() => onCancel()}>
                        Cancel
                    </button>
                </>
            );
        });

        const mockRegisterFunction = jest.fn();
        const mockInvokeFunction = jest.fn();

        (quoteOrderModuleStore?.registerFunction as jest.Mock)?.mockImplementation(
            mockRegisterFunction
        );
        (quoteOrderModuleStore?.invokeFunction as jest.Mock)?.mockImplementation(
            mockInvokeFunction
        );

        const params = {
            action: 'discard'
        };

        mockRegisterFunction?.mockImplementation((_key, callback) => {
            callback(params);
        });

        const { rerender } = render(<SplitButtonSTD handleButtonClick={handleButtonClick} />);

        quoteOrderModuleStore?.invokeFunction('STDFinalPagePopupTrigger', params);

        const cancelButton = screen.getByTestId('cancel-button');
        fireEvent.click(cancelButton);

        expect(quoteOrderModuleStore.invokeFunction).toHaveBeenCalledWith(
            'STDFinalPagePopupTrigger',
            params
        );

        rerender(<SplitButtonSTD handleButtonClick={handleButtonClick} />);
    });
});
