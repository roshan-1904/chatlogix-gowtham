import { render, screen, fireEvent } from '@testing-library/react';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MODE } from 'constants/app.constant';
import SubmitButtonSTD from '../submitButtonSTD';

// Mock necessary modules and components
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(() => ({
        info: {
            mode: MODE.CREATE_QUOTE,
            isEditFlow: false
        }
    })),
    invokeFunction: jest.fn()
}));

describe('SubmitButtonSTD Component', () => {
    let handleInvokeFunction: jest.Mock;

    beforeEach(() => {
        handleInvokeFunction = jest.fn();
        (quoteOrderModuleStore.invokeFunction as jest.Mock).mockImplementation(
            handleInvokeFunction
        );
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('renders SubmitButtonSTD component in Quote Creation Mode', () => {
        render(<SubmitButtonSTD isDisableApproveButton={false} />);
        expect(screen.getByTestId('submitButtonSTD')).toBeInTheDocument();
        // expect(screen.getByText('Request Quote')).toBeInTheDocument();
    });

    it('renders SubmitButtonSTD component in Order Creation Mode', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                mode: MODE.CREATE_ORDER,
                isEditFlow: false
            }
        });
        render(<SubmitButtonSTD isDisableApproveButton={false} />);
        expect(screen.getByTestId('submitButtonSTD')).toBeInTheDocument();
        expect(screen.getByText('QUOTE_AND_ORDER.APPROVE_QUOTE')).toBeInTheDocument();
    });

    it('handles approve button click', () => {
        render(<SubmitButtonSTD isDisableApproveButton={false} />);
        const submitButton = screen.getByTestId('submitButtonSTD');
        fireEvent.click(submitButton);
        expect(handleInvokeFunction).toHaveBeenCalledTimes(1);
        expect(handleInvokeFunction).toHaveBeenCalledWith('STDFinalPagePopupTrigger', {
            action: 'approve'
        });
    });

    it('disables button when isDisableApproveButton is true', () => {
        render(<SubmitButtonSTD isDisableApproveButton={true} />);
        const submitButton = screen.getByTestId('submitButtonSTD');
        expect(submitButton).toBeDisabled();
    });

    it('triggers button click on Enter key press', () => {
        render(<SubmitButtonSTD isDisableApproveButton={false} />);
        const submitButton = screen.getByTestId('submitButtonSTD');
        fireEvent.keyDown(submitButton, { key: 'Enter' });
        expect(handleInvokeFunction).toHaveBeenCalledTimes(1);
        expect(handleInvokeFunction).toHaveBeenCalledWith('STDFinalPagePopupTrigger', {
            action: 'approve'
        });
    });
});
