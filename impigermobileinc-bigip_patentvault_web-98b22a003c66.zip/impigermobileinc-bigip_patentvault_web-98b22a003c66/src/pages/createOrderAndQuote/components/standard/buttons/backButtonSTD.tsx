import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

import stepperStore from 'core/store/stepperStore/progressStepper.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

import { PATHS_FOR_STEPPER, STEPPER_TYPE_ID } from 'constants/progressStepper.constant';
import { PATHS } from 'constants/routes.constant';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';

const BackButtonSTD = () => {
    const { t } = useTranslation();
    const navigate = useNavigate();

    const [stepper, setStepper] = useState<STEPPER_STATE>(stepperStore.getStepperData());
    stepperStore.subscribe(setStepper);

    const redirectToPreviousPage = () => {
        try {
            if (!stepper?.stepperInfo?.currStep || !stepper?.stepperList) return;

            let pageRedirection: number = 1; // default value
            let updatedCurrStepId: number;
            let updatedCurrStep: STEPPER_DATA_TYPE;

            /** for previous page - remove the last item from the 'completedStepsIds'.
             and, set that removed item as 'currStepId' */
            const completedPages: number[] = stepper?.stepperInfo?.completedStepsIds;
            const currPage: STEPPER_DATA_TYPE = stepper?.stepperInfo?.currStep;

            if (completedPages && completedPages.length > 0) {
                updatedCurrStepId = completedPages[completedPages?.length - 1];
                updatedCurrStep = stepper.stepperList.find(
                    (step) => step.stepperId === updatedCurrStepId
                ) as STEPPER_DATA_TYPE;

                const updatedCompletedStepsIds: number[] = completedPages?.slice(0, -1);

                // update store with new data for upcoming page
                const updatedStepperInfo: STEPPER_INFO = {
                    currStep: updatedCurrStep,
                    completedStepsIds: updatedCompletedStepsIds
                };
                if (updatedStepperInfo) {
                    stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
                }

                pageRedirection = updatedCurrStep?.stepperId;
            } else if (currPage) {
                pageRedirection = STEPPER_TYPE_ID.SELECT_SERVICE;
            }

            /* when a user clicks the 'back' button on the 'service-type' page, 
                they will return to the 'orders-quotes' list page. */
            const isEditFlow = quoteOrderModuleStore.getData().info.isEditFlow;
            const flowType = isEditFlow ? PATHS.EDIT : PATHS.CREATE;

            const redirectTo = `/${PATHS.ORDER_QUOTE}/${flowType}/${PATHS_FOR_STEPPER[pageRedirection]}`;

            // redirect to the previous page
            navigate(redirectTo);
        } catch (error) {
            console.error('Error on redirectToPreviousPage:', error);
        }
    };

    return (
        <button
            data-testid="backButtonSTD"
            onClick={redirectToPreviousPage}
            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
            className="btn font-medium rounded-md min-h-10 h-10 button-neutral px-2 md:px-4">
            <i className="pi pi-chevron-left"></i>
            <span className="font-medium hidden md:block">{t('COMMON.BACK')}</span>
        </button>
    );
};

export default BackButtonSTD;
