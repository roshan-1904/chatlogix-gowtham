import { render, fireEvent } from '@testing-library/react';
import ContinueButtonSTD from '../continueButtonSTD';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('ContinueButtonSTD Component', () => {
    it('renders the continue button', () => {
        const handleButtonClick = jest.fn();
        const { getByTestId } = render(<ContinueButtonSTD handleButtonClick={handleButtonClick} />);
        expect(getByTestId('continueButtonSTD')).toBeInTheDocument();
    });

    it('calls handleButtonClick on button click', () => {
        const handleButtonClick = jest.fn();
        const { getByTestId } = render(<ContinueButtonSTD handleButtonClick={handleButtonClick} />);
        const button = getByTestId('continueButtonSTD');
        fireEvent.click(button);
        expect(handleButtonClick).toHaveBeenCalledTimes(1);
    });

    it('calls handleButtonClick on Enter key press', () => {
        const handleButtonClick = jest.fn();
        const { getByTestId } = render(<ContinueButtonSTD handleButtonClick={handleButtonClick} />);
        const button = getByTestId('continueButtonSTD');
        fireEvent.keyDown(button, { key: 'Enter' });
        expect(handleButtonClick).toHaveBeenCalledTimes(1);
    });

    it('renders the correct button text', () => {
        const handleButtonClick = jest.fn();
        const { getByText } = render(<ContinueButtonSTD handleButtonClick={handleButtonClick} />);
        expect(getByText('COMMON.CONTINUE')).toBeInTheDocument();
    });
});
