import { FILE_EXPORT_TYPE, MODE } from 'constants/app.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MenuItem } from 'primereact/menuitem';
import { SplitButton } from 'primereact/splitbutton';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import stdConstants from '../constants/standard.constant';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import successImage from 'assets/images/successTickIcon.svg';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { isContactUser } from 'core/utils/utils';

type PrimaryButtonLabel = 'Yes' | 'Close' | '--';
type SecondaryButtonLabel = 'Cancel' | '--';
export type Actions = 'save' | 'discard' | 'approve' | '';
interface PopupConfig {
    isShowPopup: boolean;
    header: JSX.Element | string;
    description: string;
    headerImage: string;
    primaryButtonLabel: PrimaryButtonLabel;
    secondaryButtonLabel: SecondaryButtonLabel;
    buttonsVisibility: {
        popupPrimaryButton: boolean;
        popupSecondaryButton: boolean;
    };
}
interface TriggerPopupType {
    action: Actions;
    requestId?: number | null;
    requestNumber?: string | null;
    isActionResolved?: boolean;
    exportType?: number | null;
}

const SplitButtonSTD = ({ handleButtonClick }: any) => {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const mode = quoteOrderModuleStore?.getData()?.info?.mode;
    const userDetails: UserInfoModal = AuthStore?.getUserInfo();
    const loggedInUserRoleId = userDetails?.userInfo?.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isEditFlow = quoteOrderModuleStore?.getData().info.isEditFlow === true;
    const isQuoteCreationMode = mode === MODE.CREATE_QUOTE;

    const currentActionsStatusInit: TriggerPopupType = {
        action: '',
        requestNumber: null,
        isActionResolved: false,
        exportType: null
    };
    const popupConfigInit: PopupConfig = {
        isShowPopup: false,
        header: '',
        description: '',
        headerImage: '',
        primaryButtonLabel: '--',
        secondaryButtonLabel: '--',
        buttonsVisibility: {
            popupPrimaryButton: false,
            popupSecondaryButton: false
        }
    };

    // popup
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);
    const [currentActionsStatus, setCurrentActionsStatus] = useState(currentActionsStatusInit);

    // popup config
    const triggerPopup = (params: TriggerPopupType) => {
        const { action, requestId = null, requestNumber = null, isActionResolved = false } = params;

        const getPopupHeaderImage = (): string => {
            const headerImage = isActionResolved ? successImage : ConfirmationRedImage;
            return headerImage;
        };
        const getPopupHeader = (): JSX.Element | '' => {
            let elementHeader: JSX.Element | '' = '';

            const handleReqNumClick = () => {
                if (requestNumber) {
                    // redirect to the request details page
                    const redirectTo = `/${PATHS.ORDER_QUOTE}/${PATHS.STANDARD}/${PATHS.DETAILS}/${requestId}`;
                    navigate(redirectTo);
                }
            };

            // header content
            switch (mode) {
                case MODE.CREATE_QUOTE: {
                    let text = 'COMMON.CONFIRMATION';
                    // TODO:
                    // if (action === 'save' && isActionResolved && isEditFlow)
                    //     text = 'COMMON.QUOTE_SAVED_SUCCESS_MESSAGE_STD_EDIT';
                    if (action === 'save' && isActionResolved)
                        text = 'COMMON.QUOTE_REQUEST_MESSAGE';
                    else if (action === 'approve' && isActionResolved)
                        text = 'COMMON.QUOTE_SAVED_SUCCESS_MESSAGE_STD';

                    elementHeader = (
                        <h4 className={`${isActionResolved ? 'text-success' : 'text-secondary'}`}>
                            {t(text)}
                        </h4>
                    );
                    break;
                }
                case MODE.CREATE_ORDER: {
                    let text = 'COMMON.CONFIRMATION';
                    if (action === 'approve' && isActionResolved)
                        text = 'COMMON.ORDER_SUCCESS_MESSAGE';

                    elementHeader = (
                        <h4 className={`${isActionResolved ? 'text-success' : 'text-secondary'}`}>
                            {t(text)}
                        </h4>
                    );
                    break;
                }
                default:
                    break;
            }

            // request number from response
            const elementRequestNumber = (
                <h6 className="text-black">
                    {t('COMMON.FINAL_POPUP_HEADER_2')}{' '}
                    <span
                        className={`${requestNumber ? 'text-primary cursor-pointer underline' : 'text-primary'}`}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        data-testid="requestNumber"
                        onClick={handleReqNumClick}>
                        {requestNumber ?? '{Request Number}'}
                    </span>
                </h6>
            );

            return (
                <>
                    {elementHeader}
                    {Boolean(requestNumber) && elementRequestNumber}
                </>
            );
        };
        const getPopupDescription = (): string => {
            let desc = '';
            if (action === 'approve' && isActionResolved) return '';

            switch (action) {
                case 'save':
                    desc = isThisContactUser
                        ? 'Our team will prepare your customized quote and get back to you.'
                        : ''; // resolved state
                    break;
                case 'approve':
                    desc = `Are you sure you want to ${isQuoteCreationMode ? 'request' : 'approve'} this ${isQuoteCreationMode ? 'quote' : 'order'}?`; // confirmation state
                    break;
                case 'discard':
                    desc = 'Are you sure you want to discard this quote?'; // confirmation state
                    break;
                default:
                    desc = 'Invalid action for quote mode.';
            }

            return desc;
        };

        const updatedPopupConfig: PopupConfig = {
            ...popupConfig,
            isShowPopup: true,
            headerImage: getPopupHeaderImage(),
            header: getPopupHeader(),
            description: getPopupDescription(),
            primaryButtonLabel: isActionResolved ? 'Close' : 'Yes',
            secondaryButtonLabel: 'Cancel',
            buttonsVisibility: {
                popupPrimaryButton: true,
                popupSecondaryButton: !isActionResolved // if action state is completed, then hide secondary button.
            }
        };
        setPopupConfig(updatedPopupConfig);
        setCurrentActionsStatus(params);
    };
    const handlerPopupPrimaryButtonClick = () => {
        if (currentActionsStatus.isActionResolved) {
            // if action is resolved, redirect to listing page
            navigate(`/${PATHS.ORDER_QUOTE}`);
        } else {
            const updatedAction = getActionButtonStatus(currentActionsStatus.action);
            resetPopupConfig();
            handleButtonClick({ actions: updatedAction });
        }
    };
    const resetPopupConfig = () => {
        setPopupConfig(popupConfigInit);
        setCurrentActionsStatus(currentActionsStatusInit);
    };

    // handlers
    const handleSaveQuote = (exportType: number | null = null) => {
        const updatedStatus = getActionButtonStatus('save');
        handleButtonClick({ actions: updatedStatus, exportType });
    };

    // helper functions
    const getSplitButtonName = () => {
        return isEditFlow ? 'COMMON.UPDATE_QUOTE_REQUEST' : 'COMMON.CREATE_QUOTE_REQUEST';
    };
    const getSplitButtonItems = (): MenuItem[] => {
        const getIcon = (fileType: string): JSX.Element => {
            const getIconName = (): string | null => {
                switch (fileType) {
                    case 'pdf':
                        return 'i-pdf-icon';
                    case 'excel':
                        return 'i-excel-blue-icon';
                    default:
                        return null;
                }
            };

            return (
                <img
                    src={`/images/svgs/${getIconName()}.svg`}
                    alt={`${fileType} icon`}
                    className="h-4 mr-2"
                />
            );
        };

        const items: MenuItem[] = [
            {
                label: 'Save & Export To PDF',
                icon: getIcon('pdf'),
                command() {
                    handleSaveQuote(FILE_EXPORT_TYPE.PDF);
                }
            },
            {
                label: 'Save & Export To Excel',
                icon: getIcon('excel'),
                command() {
                    handleSaveQuote(FILE_EXPORT_TYPE.EXCEL);
                }
            },
            {
                label: 'Discard',
                icon: 'pi pi-exclamation-circle text-secondary !font-medium',
                command() {
                    triggerPopup({ action: 'discard' });
                }
            }
        ];

        return items;
    };
    const getActionButtonStatus = (action: Actions) => {
        const status = { ...stdConstants.stdActionButtonStatusInit }; // Start with the initial state

        switch (action) {
            case 'discard':
                status.isDiscard = true;
                break;
            case 'save':
                status.isSave = true;
                break;
            case 'approve':
                status.isApprove = true;
                break;
            default:
                console.error('Invalid action');
        }

        return status;
    };

    // // side effects
    useEffect(() => {
        // register the function to call on store
        quoteOrderModuleStore?.registerFunction('STDFinalPagePopupTrigger', triggerPopup);
        return () => {
            // remove the registered function on store to avoid unwanted calls.
            quoteOrderModuleStore?.registerFunction('STDFinalPagePopupTrigger', triggerPopup);
        };
    }, []);

    return (
        <>
            {popupConfig.isShowPopup && (
                <ConfirmationPopup
                    popupID="popupSTDStepper"
                    image={popupConfig.headerImage}
                    visible={popupConfig.isShowPopup}
                    headerText={popupConfig.header}
                    description={popupConfig.description}
                    acceptLabel={popupConfig.primaryButtonLabel}
                    rejectLabel={popupConfig.secondaryButtonLabel}
                    isShowAcceptButton={popupConfig.buttonsVisibility.popupPrimaryButton}
                    isShowRejectButton={popupConfig.buttonsVisibility.popupSecondaryButton}
                    onConfirm={handlerPopupPrimaryButtonClick}
                    onCancel={resetPopupConfig}
                />
            )}

            {isQuoteCreationMode && (
                <SplitButton
                    className="!hidden"
                    data-testid="splitButtonSTD"
                    dropdownIcon="pi pi-bars"
                    menuStyle={{ whiteSpace: 'nowrap' }}
                    buttonClassName="!bg-primary !hover:bg-primary-100 !font-medium h-[2.40rem] !focus:outline-none !focus:shadow-none text-white"
                    menuButtonClassName="!bg-primary !hover:bg-primary-100 border-l border-l-white hover:border-l-white h-[2.40rem] !font-medium !focus:outline-none !focus:shadow-none !focus:shadow-transparent text-white"
                    icon={<p className="font-medium">{t(getSplitButtonName())}</p>}
                    appendTo={'self'}
                    model={getSplitButtonItems()}
                    onClick={() => handleSaveQuote()}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    severity="contrast"
                />
            )}
        </>
    );
};

export default SplitButtonSTD;
