import { MODE } from 'constants/app.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { useTranslation } from 'react-i18next';
import stdConstants from '../constants/standard.constant';

const SubmitButtonSTD = ({ isDisableApproveButton }: any) => {
    const { t } = useTranslation();
    const mode = quoteOrderModuleStore?.getData()?.info?.mode;
    const isQuoteCreationMode = mode === MODE.CREATE_QUOTE;
    const isOrderCreationMode = mode === MODE.CREATE_ORDER;

    let submitButtonLabelName = '';
    if (isQuoteCreationMode) {
        submitButtonLabelName = 'QUOTE_AND_ORDER.REQUEST_QUOTE';
    } else if (isOrderCreationMode) {
        submitButtonLabelName = 'QUOTE_AND_ORDER.APPROVE_ORDER';
    }

    const handleApproveButtonClick = () => {
        // const defaultItemsToService = { translate: t, navigateTo: navigate };
        // const isLanguageSelectionTableValid =
        //     standardModuleService.validateLanguageSelectionTable(defaultItemsToService);

        // if (isLanguageSelectionTableValid) {
        // quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', {
        //     action: 'approve'
        // });
        // }

        quoteOrderModuleStore.invokeFunction(stdConstants.STD_STEPPER_ACTIONS.CONFIRM_B4_SUBMIT);
    };

    return (
        <button
            data-testid="submitButtonSTD"
            className="btn button-primary font-medium rounded-md min-h-10 h-10"
            disabled={Boolean(isDisableApproveButton)}
            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
            onClick={handleApproveButtonClick}>
            <span className="font-medium">{t(submitButtonLabelName)}</span>{' '}
            <i className="pi pi-chevron-right"></i>
        </button>
    );
};

export default SubmitButtonSTD;
