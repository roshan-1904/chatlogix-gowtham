import { render, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, useNavigate } from 'react-router-dom';
import BackButtonSTD from '../backButtonSTD';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { PATHS_FOR_STEPPER, STEPPER_TYPE_ID } from 'constants/progressStepper.constant';
import { PATHS } from 'constants/routes.constant';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: jest.fn()
}));

describe('BackButtonSTD Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders the back button', () => {
        const navigateMock = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(navigateMock);

        const { getByTestId } = render(
            <MemoryRouter>
                <BackButtonSTD />
            </MemoryRouter>
        );

        expect(getByTestId('backButtonSTD')).toBeInTheDocument();
    });

    it('calls redirectToPreviousPage on button click', async () => {
        const navigateMock = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(navigateMock);

        stepperStore.updateStepper({
            stepperInfo: {
                currStep: {
                    stepperId: 2,
                    stepperName: '',
                    stepperDesc: ''
                },
                completedStepsIds: [1, 2]
            },
            stepperList: [
                {
                    stepperId: 1,
                    stepperName: 'Step 1',
                    stepperDesc: ''
                },
                {
                    stepperId: 2,
                    stepperName: 'Step 2',
                    stepperDesc: ''
                }
            ]
        });

        const { getByTestId } = render(
            <MemoryRouter>
                <BackButtonSTD />
            </MemoryRouter>
        );

        const backButton = getByTestId('backButtonSTD');
        fireEvent.click(backButton);

        await waitFor(() => {
            expect(navigateMock).toHaveBeenCalledTimes(1);
            expect(navigateMock).toHaveBeenCalledWith(
                `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS_FOR_STEPPER[1]}`
            );
        });
    });

    it('handles edge case when no completed steps', async () => {
        const navigateMock = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(navigateMock);

        stepperStore.updateStepper({
            stepperInfo: {
                currStep: {
                    stepperId: 1,
                    stepperName: '',
                    stepperDesc: ''
                },
                completedStepsIds: []
            },
            stepperList: [
                {
                    stepperId: 1,
                    stepperName: 'Step 1',
                    stepperDesc: ''
                }
            ]
        });

        const { getByTestId } = render(
            <MemoryRouter>
                <BackButtonSTD />
            </MemoryRouter>
        );

        const backButton = getByTestId('backButtonSTD');
        fireEvent.click(backButton);

        await waitFor(() => {
            expect(navigateMock).toHaveBeenCalledTimes(1);
            expect(navigateMock).toHaveBeenCalledWith(
                `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS_FOR_STEPPER[STEPPER_TYPE_ID.SELECT_SERVICE]}`
            );
        });
    });

    it('handles edit flow correctly', async () => {
        const navigateMock = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(navigateMock);

        stepperStore.updateStepper({
            stepperInfo: {
                currStep: {
                    stepperId: 2,
                    stepperName: '',
                    stepperDesc: ''
                },
                completedStepsIds: [1, 2]
            },
            stepperList: [
                {
                    stepperId: 1,
                    stepperName: 'Step 1',
                    stepperDesc: ''
                },
                {
                    stepperId: 2,
                    stepperName: 'Step 2',
                    stepperDesc: ''
                }
            ]
        });

        const currentInfo = quoteOrderModuleStore.getData().info;
        const updatedInfo = { ...currentInfo, isEditFlow: true };
        quoteOrderModuleStore.updatePage('info', updatedInfo);

        const { getByTestId } = render(
            <MemoryRouter>
                <BackButtonSTD />
            </MemoryRouter>
        );

        const backButton = getByTestId('backButtonSTD');
        fireEvent.click(backButton);

        await waitFor(() => {
            expect(navigateMock).toHaveBeenCalledTimes(1);
            expect(navigateMock).toHaveBeenCalledWith(
                `/${PATHS.ORDER_QUOTE}/${PATHS.EDIT}/${PATHS_FOR_STEPPER[1]}`
            );
        });
    });
});
