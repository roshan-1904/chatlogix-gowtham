import { useTranslation } from 'react-i18next';

const ContinueButtonSTD = ({ handleButtonClick }: any) => {
    const { t } = useTranslation();

    return (
        <button
            onClick={handleButtonClick}
            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
            data-testid="continueButtonSTD"
            className="btn button-primary font-medium rounded-md min-h-10 h-10">
            <span className="font-medium">{t('COMMON.CONTINUE')}</span>{' '}
            <i className="pi pi-chevron-right"></i>
        </button>
    );
};

export default ContinueButtonSTD;
