import { render, fireEvent } from '@testing-library/react';
import PreviewButtonSTD from '../previewButtonSTD';
import { MODE } from 'constants/app.constant';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

jest.mock('core/store/authStore/authStore', () => ({
    __esModule: true,
    default: {
        getUserInfo: jest.fn(() => ({
            userInfo: {
                roleId: 1
            }
        }))
    }
}));

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    __esModule: true,
    default: {
        getData: jest.fn(() => ({
            info: {
                isEditFlow: true,
                mode: MODE.CREATE_QUOTE,
                previewReferenceId: 1,
                stdPreviewType: null
            }
        })),
        updatePage: jest.fn()
    }
}));

jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService', () => ({
    __esModule: true,
    getPDFData: jest.fn(() => Promise.resolve('https://example.com/preview.pdf'))
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    __esModule: true,
    default: {
        showAlert: jest.fn()
    }
}));

describe('PreviewButtonSTD Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders the preview button', () => {
        const { getByTestId } = render(<PreviewButtonSTD />);
        expect(getByTestId('previewButtonSTD')).toBeInTheDocument();
    });

    it('toggles preview selection dialog', () => {
        const { getByTestId } = render(<PreviewButtonSTD />);
        const previewButton = getByTestId('previewButtonSTD');

        fireEvent.click(previewButton);
        expect(getByTestId('customPreviewTemplateSTD')).toBeInTheDocument();
        expect(getByTestId('preview-dropdown')).toBeVisible();

        fireEvent.click(previewButton);
    });

    it('downloads PDF when download button is clicked', () => {
        const { getByTestId } = render(<PreviewButtonSTD />);

        const previewButton = getByTestId('previewButtonSTD');
        fireEvent.click(previewButton);

        const previewDialog = getByTestId('customPreviewTemplateSTD');
        expect(previewDialog).toBeInTheDocument();

        // Download the PDF
        fireEvent.click(previewDialog);
    });
});
