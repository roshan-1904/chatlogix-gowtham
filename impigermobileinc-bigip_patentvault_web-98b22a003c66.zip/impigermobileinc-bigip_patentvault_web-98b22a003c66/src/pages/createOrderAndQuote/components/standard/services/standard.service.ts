const submitStandard = () => {};

const standardService = { submitStandard };
export default standardService;
