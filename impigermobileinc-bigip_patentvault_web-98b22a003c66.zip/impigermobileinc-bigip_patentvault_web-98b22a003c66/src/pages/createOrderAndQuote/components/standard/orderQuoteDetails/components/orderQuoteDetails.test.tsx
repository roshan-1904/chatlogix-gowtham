import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import OrderQuoteDetails from './orderQuoteDetails';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import orderQuoteDetailsService from '../services/orderQuoteDetails.service';
import companyDetailsService from 'pages/createOrderAndQuote/components/companyDetails/services/companyDetails.service';
import summaryService from 'pages/createOrderAndQuote/components/summary/services/summary.service';
import AuthStore from 'core/store/authStore/authStore';
import { act } from 'react-dom/test-utils';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import { ROLE } from 'constants/app.constant';

jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(),
    subscribe: jest.fn(),
    updatePage: jest.fn(),
    registerFunction: jest.fn()
}));

jest.mock('../services/orderQuoteDetails.service', () => ({
    oqDetailsSaveDraft: jest.fn()
}));

jest.mock(
    'pages/createOrderAndQuote/components/companyDetails/services/companyDetails.service',
    () => ({
        getCompanyData: jest.fn()
    })
);

jest.mock('pages/createOrderAndQuote/components/summary/services/summary.service', () => ({
    getCurrencyList: jest.fn()
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: jest.fn()
}));

jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn()
}));
interface MockFormProps {
    'data-testid'?: string;
}

jest.mock('@formio/react', () => ({
    Form: ({ 'data-testid': testId }: MockFormProps) => <div data-testid={testId}>Mocked Form</div>
}));

describe('OrderQuoteDetails Component', () => {
    let mockNavigate: jest.Mock<any, any>;

    beforeEach(() => {
        jest.clearAllMocks();
        mockNavigate = jest.fn();
        (useNavigate as jest.Mock).mockReturnValue(mockNavigate);
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                primaryId: 0,
                documentId: 0,
                selectedService: { patentType: 1 },
                selectedCategory: { patentCategoryId: 2 },
                isEditFlow: false,
                mode: 'test'
            },
            formData: {
                orderQuoteDetailsPage: {}
            },
            isFormValid: {},
            saveAPIResponseData: {
                currencyList: []
            }
        });
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: {
                roleId: 1,
                userId: 123,
                signinName: 'test@example.com',
                companyId: 1
            }
        });
    });

    it('should render the OrderQuoteDetails component', () => {
        render(<OrderQuoteDetails />);
        expect(screen.getByTestId('quoteDetailsPage')).toBeInTheDocument();
    });

    it('should render the form component', async () => {
        render(<OrderQuoteDetails />);
        const quoteDetailsPage = await screen.findByTestId('quoteDetailsPage');
        expect(quoteDetailsPage).toBeInTheDocument();
        expect(quoteDetailsPage.children).toHaveLength(1); // Assuming only one child, which is the Form
    });

    it('should render the form component', async () => {
        render(<OrderQuoteDetails />);
        const formComponent = await screen.findByTestId('formComponent');
        expect(formComponent).toBeInTheDocument();
    });
    it.skip('should call oqDetailsSaveDraft when draftSave is triggered', async () => {
        const mockResponse = {
            referenceNo: 123,
            requestCurrencyId: 1
        };
        (orderQuoteDetailsService.oqDetailsSaveDraft as jest.Mock).mockResolvedValue(mockResponse);

        // Render and wait for component to settle
        const { findByTestId } = render(<OrderQuoteDetails />);

        // Wait for form to be rendered
        const formComponent = await findByTestId('formComponent');

        const mockEvent = {
            data: {
                companyName: { id: 1 },
                title: 'Test Title',
                requestCurrencyId: 1
            }
        };

        act(() => {
            fireEvent.submit(formComponent, { target: mockEvent });
        });

        await waitFor(() => {
            expect(orderQuoteDetailsService.oqDetailsSaveDraft).toHaveBeenCalledTimes(1);
            expect(orderQuoteDetailsService.oqDetailsSaveDraft).toHaveBeenCalledWith(
                expect.objectContaining({
                    requestId: 0,
                    documentId: 0,
                    requestCurrencyId: 1
                })
            );
            expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith(
                'info',
                expect.anything()
            );
            expect(mockNavigate).toHaveBeenCalled();
        });
    });

    it('should fetch currency list on component mount', async () => {
        (summaryService.getCurrencyList as jest.Mock).mockResolvedValue([{ id: 1, name: 'USD' }]);

        render(<OrderQuoteDetails />);

        await waitFor(() => {
            expect(summaryService.getCurrencyList).toHaveBeenCalledTimes(1);
            expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith(
                'saveAPIResponseData',
                expect.objectContaining({
                    currencyList: [{ id: 1, name: 'USD' }]
                })
            );
        });
    });

    it('should fetch company data and set initial data when user is a contact user and not in edit flow', async () => {
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: {
                roleId: ROLE.CONTACT_USER.roleId,
                userId: 123,
                signinName: 'test@example.com',
                companyId: 1
            }
        });
        (companyDetailsService.getCompanyData as jest.Mock).mockResolvedValue([
            { id: 1, name: 'Test Company' }
        ]);
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                primaryId: 0,
                documentId: 0,
                selectedService: { patentType: 1 },
                selectedCategory: { patentCategoryId: 2 },
                isEditFlow: false,
                mode: 'test'
            },
            formData: {
                orderQuoteDetailsPage: {}
            },
            isFormValid: {},
            saveAPIResponseData: {
                currencyList: []
            }
        });

        render(<OrderQuoteDetails />);

        await waitFor(() => {
            expect(companyDetailsService.getCompanyData).toHaveBeenCalledTimes(1);
            expect(screen.getByTestId('formComponent')).toBeInTheDocument();
        });
    });

    it.skip('should register and unregister triggerFormSubmission function on component mount and unmount', () => {
        const { unmount } = render(<OrderQuoteDetails />);

        expect(quoteOrderModuleStore.registerFunction).toHaveBeenCalledWith(
            PATHS.ORDER_QUOTE_DETAILS,
            expect.any(Function)
        );

        unmount();
        expect(quoteOrderModuleStore.registerFunction).toHaveBeenCalledWith(
            PATHS.ORDER_QUOTE_DETAILS,
            expect.any(Function)
        );
    });

    it('should not trigger store update when form changes with flags fromBlur', () => {
        const { getByTestId } = render(<OrderQuoteDetails />);

        // Mock form change event
        const formComponent = getByTestId('formComponent');
        const mockEvent = {
            changed: { component: { key: 'companyName', flags: { fromBlur: true } } },
            data: {
                companyName: { salesRep: 5 },
                salesRep: [],
                contactEmail: 'test@example.com'
            }
        };

        act(() => {
            fireEvent.change(formComponent, { target: mockEvent });
        });

        expect(quoteOrderModuleStore.updatePage).not.toHaveBeenCalled();
    });
});
