import { useMemo, useState, useEffect } from 'react';
import { Form } from '@formio/react';

import HttpService from 'core/interceptor/api.handler';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

import OrderQuoteDetailsFormBuilderData from '../mocks/orderQuoteDetailsForm.mock.json';
import { PATHS } from 'constants/routes.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import orderQuoteDetailsService from '../services/orderQuoteDetails.service';
import {
    APIResponseData,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import { useNavigate } from 'react-router-dom';
import { isContactUser } from 'core/utils/utils';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { PATHS_FOR_STEPPER } from 'constants/progressStepper.constant';
import { ROLE, YES_NO } from 'constants/app.constant';
import { CurrencyResponse } from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import summaryService from 'pages/createOrderAndQuote/components/summary/services/summary.service';
import { Company } from 'pages/createOrderAndQuote/components/companyDetails/types/companyDetails.type';
import companyDetailsService from 'pages/createOrderAndQuote/components/companyDetails/services/companyDetails.service';

const OrderQuoteDetails = () => {
    const navigate = useNavigate();
    const httpService = new HttpService();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(
        OrderQuoteDetailsFormBuilderData
    );
    const [initialData, setInitialData] = useState<any>({});
    const loggedInUserRole = userDetails?.userInfo.roleId;
    const loggedInUserCompanyId = userDetails.userInfo.companyId;
    const isThisContactUser = isContactUser(loggedInUserRole);
    const selectedCategory = quoteOrderData?.info?.selectedCategory;
    const isEditFlow = quoteOrderData.info.isEditFlow === true;
    const orderQuoteDetailsPageData = quoteOrderData.formData.orderQuoteDetailsPage ?? null;

    // handle form data
    const onFormChange = (e: any) => {
        if (!e.changed || e.changed?.flags?.fromBlur === true) return; // to avoid re-renders

        const { data } = e;
        const updatedFormData = JSON.parse(JSON.stringify(data));
        const fetchFormData = JSON.parse(
            JSON.stringify(quoteOrderModuleStore.getData().formData.orderQuoteDetailsPage)
        );

        // fields manipulation
        if (isThisContactUser) {
            /** for CM/CU don't have contact-user field to get the email-id.
             *  so then use the 'signInName' instead of that. */
            updatedFormData.contactEmail = userDetails?.userInfo.signinName ?? '';
        }
        delete updatedFormData.submit; // remove delete button

        if (e.changed && updatedFormData !== fetchFormData) {
            updateStore(updatedFormData, false); // update form data to store
        }
    };
    const onSubmitChange = (e: any) => {
        const updatedFormData = e.data;
        updateStore(updatedFormData);

        // temporary save API
        draftSave(updatedFormData);
    };

    // functions
    const triggerFormSubmission = () => {
        // navigationProcess();
        document.getElementById(`submit-${PATHS.ORDER_QUOTE_DETAILS}`)?.click();
    };
    const navigationProcess = () => {
        try {
            const updatedStepperInfo = orderQuoteModuleService.stepperNavigation();

            if (!updatedStepperInfo?.currStep) throw new Error();
            const currStep = updatedStepperInfo?.currStep;
            const redirectTo = PATHS_FOR_STEPPER[currStep?.stepperId];
            navigate(
                `/${PATHS.ORDER_QUOTE}/${isEditFlow ? PATHS.EDIT : PATHS.CREATE}/${redirectTo}`
            );
        } catch (error) {
            console.error('Error in navigationProcess(): ', error);
        }
    };

    // update store
    const updateStore = (updatedFormData: any, isValid = true) => {
        updateFormData(updatedFormData);
        updateIsFormValid(isValid);
    };
    const updateFormData = (updatedFormData: any) => {
        const updatedQuoteOrderFormData = {
            ...quoteOrderData.formData,
            orderQuoteDetailsPage: updatedFormData
        };
        quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
    };
    const updateIsFormValid = (isValid: boolean) => {
        const updatedQuoteOrderIsFormValid = {
            ...quoteOrderData.isFormValid,
            [PATHS.ORDER_QUOTE_DETAILS]: isValid
        };
        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
    };

    // draft save API
    const draftSave = async (updatedFormData: any) => {
        try {
            const info = quoteOrderData?.info;
            const preparedData = {
                requestId: info.primaryId && info.primaryId !== 0 ? info.primaryId : 0,
                documentId: info.documentId && info.documentId !== 0 ? info.documentId : 0,
                requestTypeId: 0,
                patentCategoryId: selectedCategory?.parentId,
                patentServiceTypeId: selectedCategory?.patentCategoryId,
                companyAuthentication: {
                    companyId: updatedFormData.companyName.id,
                    contactUserId: 0,
                    patentDetails: {
                        applicant: '',
                        patentTitle: updatedFormData.title,
                        requestByUserId: userDetails?.userInfo.userId,
                        requestedBy: userDetails?.userInfo.signinName
                    }
                },
                totalWordCount: 0,
                grandTotal: 0,
                requestCurrencyId: updatedFormData.requestCurrencyId ?? null
            };

            const response: { referenceNo: number; requestCurrencyId: number } =
                await orderQuoteDetailsService.oqDetailsSaveDraft(preparedData);

            if (response) {
                const primaryId = response.referenceNo;
                const requestCurrencyId = response.requestCurrencyId;

                /** in edit flow don't consider the ids, which we got in save-draft api response.
                 *  keep the existing ids as it is. */
                const updatedPrimaryId = isEditFlow ? quoteOrderData?.info.primaryId : primaryId;
                const updatedRequestCurrencyId = isEditFlow
                    ? quoteOrderData?.info.requestCurrencyId
                    : requestCurrencyId;

                // update store - info
                const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                    ...quoteOrderData?.info,
                    primaryId: updatedPrimaryId,
                    requestCurrencyId: updatedRequestCurrencyId
                };
                quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo); // update store - info

                navigationProcess();
            }
        } catch (error) {
            console.error('Error in order-quote details DraftSave:', error);
        }
    };
    const getCurrencyList = async () => {
        try {
            const response: CurrencyResponse[] = await summaryService.getCurrencyList();
            if (response) {
                const updatedQuoteOrderSaveAPIResponseData: APIResponseData = {
                    ...quoteOrderData.saveAPIResponseData,
                    currencyList: response
                };
                quoteOrderModuleStore.updatePage(
                    'saveAPIResponseData',
                    updatedQuoteOrderSaveAPIResponseData
                );
            }
        } catch (error) {
            console.error('Error in getCurrencyList(): ', error);
        }
    };

    // side effects
    useEffect(() => {
        // get currency list to populate in the dropdown while selecting the company
        getCurrencyList();

        const isAutoPopulate = (field: string) => {
            if (field === 'companyName') {
                const autoPopulate = loggedInUserRoleId === ROLE.CONTACT_USER.roleId;

                return autoPopulate;
            }
        };
        const getCompanyName = (companyList: Company[]): Company | null => {
            let companyName;

            if (isEditFlow) {
                companyName = orderQuoteDetailsPageData.companyName;
            } else {
                const userCompany = companyList?.find(
                    (company: Company) => company.id === loggedInUserCompanyId
                );
                companyName = isAutoPopulate('companyName')
                    ? (userCompany ?? null)
                    : (orderQuoteDetailsPageData.companyName ?? null);
            }

            return companyName || null;
        };

        const getInitialData = async () => {
            const initData = {
                data: {
                    ...orderQuoteDetailsPageData,

                    // update hidden fields with real-time data
                    mode: quoteOrderData.info.mode,
                    roleId: userDetails.userInfo.roleId,
                    isEditFlow: isEditFlow === true ? YES_NO.YES : YES_NO.NO
                }
            };

            let companyList: Company[] | null = null;
            if (
                !isEditFlow &&
                loggedInUserRoleId === ROLE.CONTACT_USER.roleId &&
                !initData.data.companyList
            ) {
                companyList = await companyDetailsService.getCompanyData();
                initData.data.companyList = companyList;
                initData.data.companyName = getCompanyName(companyList ?? []);
            }

            setInitialData(initData);
        };
        getInitialData();

        // register the function to call on store
        quoteOrderModuleStore.registerFunction(PATHS.ORDER_QUOTE_DETAILS, triggerFormSubmission);
        return () => {
            /** remove the registered function on store to avoid unwanted calls. */
            quoteOrderModuleStore.registerFunction(PATHS.ORDER_QUOTE_DETAILS, () => {});
        };
    }, []);

    return (
        <div data-testid="quoteDetailsPage" className="quoteDetailsPage">
            <Form
                data-testid="formComponent"
                form={formBuilderData}
                submission={initialData}
                onChange={(e: any) => onFormChange(e)}
                onSubmit={(e: any) => onSubmitChange(e)}
            />
        </div>
    );
};

export default OrderQuoteDetails;
