import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import { toggleLoadingIndicator } from 'core/utils/utils';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

const oqDetailsSaveDraft = async <T>(data: any): Promise<T> => {
    const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.STANDARD_SAVE_DRAFT}`;

    try {
        const response = await httpService.post<T, T>(apiUrl, data as T, {}, false, baseURL);
        return response as T & { requestId: number };
    } catch (error) {
        console.error('Error saving QO details draft:', error);
        throw error;
    }
};

const getDisclaimers = async <T>(
    orderRequestId: number,
    isEPService = false,
    isUP = false
): Promise<T> => {
    let apiUrl = `${baseURL}${END_POINT.ORDER_SAVE}${END_POINT.GET_DISCLAIMERS}/${orderRequestId}`;
    if (isEPService) {
        apiUrl += `?isUP=${isUP}`;
    }
    try {
        const params = { data: { hideLoader: true } };
        const response = await httpService.get<T>(apiUrl, params);
        setTimeout(() => {
            // Call the function to hide the loader
            toggleLoadingIndicator(false);
        }, 1000);
        return response as T & { requestId: number };
    } catch (error) {
        setTimeout(() => {
            // Call the function to hide the loader
            toggleLoadingIndicator(false);
        }, 1000);
        console.error('Error saving QO details draft:', error);
        throw error;
    }
};

const getStandardDisclaimers = async <T>(
    orderRequestId: number,
    isEPService = false,
    isUP = false
): Promise<T> => {
    let apiUrl = `${baseURL}${END_POINT.STANDARD_ORDER_SAVE}${END_POINT.GET_DISCLAIMERS}/${orderRequestId}`;
    if (isEPService) {
        apiUrl += `?isUP=${isUP}`;
    }
    try {
        const params = { data: { hideLoader: true } };
        const response = await httpService.get<T>(apiUrl, params);
        return response as T & { requestId: number };
    } catch (error) {
        console.error('Error saving QO details draft:', error);
        throw error;
    }
};

const orderQuoteDetailsService = {
    oqDetailsSaveDraft,
    getDisclaimers,
    getStandardDisclaimers
};
export default orderQuoteDetailsService;
