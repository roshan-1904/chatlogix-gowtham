import HttpService from 'core/interceptor/api.handler';
import orderQuoteDetailsService from './orderQuoteDetails.service';

jest.mock('core/interceptor/api.handler');

describe('orderQuoteDetailsService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('oqDetailsSaveDraft', () => {
        const data = {};
        it('should fetch oqDetailsSaveDraft successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await orderQuoteDetailsService.oqDetailsSaveDraft(data);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(orderQuoteDetailsService.oqDetailsSaveDraft(data)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getDisclaimers', () => {
        const orderRequestId = 1;
        const isEPService = false;
        const isUP = false;
        it('should fetch getContactUserData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await orderQuoteDetailsService.getDisclaimers(
                orderRequestId,
                isEPService,
                isUP
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                orderQuoteDetailsService.getDisclaimers(orderRequestId, isEPService, isUP)
            ).rejects.toThrow(mockError);
        });
    });
});
