import { FilePayload } from 'components/fileUpload/types/fileUpload.types';
import { AllLanguageResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { STDDocumentSectionData } from '../services/uploadAndLanguageSelection.service';

// ## Start STD Create page types
export type PageVisibilityTypes =
    | 'landing-page-add'
    | 'upload-dialog-add'
    | 'upload-dialog-close'
    | 'upload-dialog-clear'
    | 'group-listing-add'
    | 'group-listing-select'
    | 'group-listing-delete'
    | 'group-listing-view-file' // future
    | 'stay-on-page';
export type GroupCRUDActivityTypes =
    | 'landing-page-add'
    | 'upload-dialog-add'
    | 'group-listing-add'
    | 'group-listing-select'
    | 'group-listing-change'
    | 'group-listing-delete';

export interface GroupedResultModel {
    primaryId: number;
    stdGroupId: number;
    notesForUploadedFiles: string;
    file: FilePayload[];
}
export interface DocumentGroupModel {
    groupId: number;
    primaryId: number;
    sourceLanguage: number[];
    targetLanguage: number[];
    documentList: FilePayload[];
    documentType: number; // user input sets the default type for all files, changeable later.
    tempNotes: string; // user input sets the default type for all files, changeable later.
    isGroupInActive?: boolean; // dev can find the deleted groups with this.
    errors: GroupErrors;
    groupUpdatedLastAt?: string | null; // we create this initially and use this flag to show/hide the group fields, which are only displayed during the first creation.
}
export interface GroupErrors {
    isInvalidSL: boolean;
    isInvalidTL: boolean;
    isInvalidSource: boolean;
    isInvalidReference: boolean;
}
export interface STDPageDataModel {
    responseData: { languageList: AllLanguageResponseType[] };
    groups: DocumentGroupModel[];
    flags: {
        // show
        isShowLandingPage: boolean;
        isShowUploadDialog: boolean;
        isShowGroupListing: boolean;

        // triggered submissions
        isSubmittingPopup: boolean;
        isSubmittingGroupsList: boolean;
    };
}

export interface GroupHandlerModel {
    selectedGroup?: DocumentGroupModel;
    isCreateNewGroup?: boolean;
}
export const groupDataInit: DocumentGroupModel = {
    groupId: 0,
    primaryId: 0,
    sourceLanguage: [],
    targetLanguage: [],
    documentList: [],
    documentType: 1,
    tempNotes: '',
    groupUpdatedLastAt: null,
    isGroupInActive: false,
    errors: {
        isInvalidSL: false,
        isInvalidTL: false,
        isInvalidSource: false,
        isInvalidReference: false
    }
};
// ## End STD Create page types

// ## Start STD Details page types
export interface SaveSTDDetailsPageFilesModel {
    orderId: number;
    documents: STDDocumentSectionData[];
}
export interface STDUpdateNotesModel {
    orderId: number;
    documentId: number;
    notes: string;
}
export interface STDUpdateDocumentWordCountModel {
    orderId: number;
    documentId: number;
    wordCount: number;
}
// ## End STD Details page types
