import { render, screen, fireEvent } from '@testing-library/react';
import { LandingPage } from './landingPage';
import { DocumentGroupModel, STDPageDataModel } from '../types/uploadAndLanguageSelection.type';

describe('LandingPage Component', () => {
    const mockGroupUpdate = jest.fn();
    const mockFlags: STDPageDataModel['flags'] = {
        isShowLandingPage: true,
        isShowUploadDialog: false,
        isShowGroupListing: false,
        isSubmittingPopup: false,
        isSubmittingGroupsList: false
    };

    const mockStdFunctions = {
        updatePageData: jest.fn(),
        groupCreate: jest.fn(),
        groupUpdate: jest.fn(),
        groupDelete: jest.fn(),
        groupSelect: jest.fn(),
        fileDelete: jest.fn(),
        handlePageVisibility: jest.fn(),
        handleLanguageChange: jest.fn(),
        storeFilesAgainstGroup: jest.fn(),
        validateGroupsAndSetError: jest.fn()
    };

    const mockSelectedGroup: DocumentGroupModel = {
        groupId: 1,
        primaryId: 1,
        sourceLanguage: [],
        targetLanguage: [],
        documentList: [],
        documentType: 1,
        tempNotes: '',
        isGroupInActive: true,
        groupUpdatedLastAt: null,
        errors: {
            isInvalidSL: false,
            isInvalidTL: false,
            isInvalidReference: false,
            isInvalidSource: false
        }
    };

    const renderComponent = () =>
        render(
            <LandingPage
                flags={mockFlags}
                selectedGroup={mockSelectedGroup}
                stdFunctions={mockStdFunctions}
            />
        );

    it('should render the landing page when isShowLandingPage is true', () => {
        renderComponent();

        expect(screen.getByTestId('std-landing-page')).toBeInTheDocument();
        expect(screen.getByTestId('std-landing-page-header')).toBeInTheDocument();
        expect(screen.getByTestId('std-landing-page-info')).toBeInTheDocument();
    });

    it('should display the correct title and description', () => {
        renderComponent();

        expect(screen.getByTestId('std-landing-page-header-title')).toHaveTextContent(
            'STD_UPLOAD_SELECTION.LANDING_PAGE_TITLE'
        );
        expect(screen.getByTestId('std-landing-page-title')).toHaveTextContent(
            'STD_UPLOAD_SELECTION.LANDING_PAGE_INFO_HEADER'
        );
        expect(screen.getByTestId('std-landing-page-desc')).toHaveTextContent(
            'STD_UPLOAD_SELECTION.LANDING_PAGE_INFO_DESC'
        );
    });

    it('should call groupUpdate with the correct arguments when the button is clicked', () => {
        renderComponent();

        const button = screen.getByTestId('std-create-landing-page-add-document-button');
        fireEvent.click(button);

        expect(mockGroupUpdate).toHaveBeenCalledWith({ ...mockSelectedGroup }, 'landing-page-add');
    });

    it('should not render the landing page when isShowLandingPage is false', () => {
        render(
            <LandingPage
                flags={{
                    isShowLandingPage: false,
                    isShowUploadDialog: false,
                    isShowGroupListing: false,
                    isSubmittingPopup: false,
                    isSubmittingGroupsList: false
                }}
                selectedGroup={mockSelectedGroup}
                stdFunctions={mockStdFunctions}
            />
        );

        expect(screen.queryByTestId('std-landing-page')).not.toBeInTheDocument();
    });
});
