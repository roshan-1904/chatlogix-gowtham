import { FC, useEffect, useState } from 'react';
import { STDFunctionsModel } from './uploadAndLanguageSelection';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import { t } from 'i18next';
import UploadDialogSTDTemplate from './uploadDialogSTDTemplate';
import { TransformedObject } from 'components/fileUpload/types/fileUpload.types';
import standardModuleService from '../../languageSelection/services/standardModule.service';
import { DocumentGroupModel, STDPageDataModel } from '../types/uploadAndLanguageSelection.type';

interface ExtendedUploadSTDCreatePageModal extends STDPageDataModel {
    setSelectedGroup: (group: DocumentGroupModel) => void;
    selectedGroup: DocumentGroupModel;
    stdFunctions: STDFunctionsModel;
}

export const UploadSTDCreatePage: FC<ExtendedUploadSTDCreatePageModal> = ({
    responseData,
    stdFunctions,
    setSelectedGroup,
    selectedGroup,
    flags
}) => {
    const onDialogSubmit = () => {
        // error will shows only when popup submission is in progress ('isSubmittingPopup').
        stdFunctions.updatePageData('flags', { ...flags, isSubmittingPopup: true });

        const validationResult = validateCurrentGroup(); // validate and set/remove errors
        const { isInvalid, groups } = validationResult;
        const errors = groups[0].errors;

        // documents for 'Popup-Add' are not needed because the upload might be asynchronous at times.
        const isProceedToAdd =
            !isInvalid ||
            (isInvalid &&
                !errors.isInvalidSL &&
                !errors.isInvalidTL &&
                (errors.isInvalidSource || errors.isInvalidReference));

        if (isProceedToAdd) stdFunctions.groupUpdate(selectedGroup, 'upload-dialog-add');
    };

    // toast / popup
    type PrimaryButtonLabel = 'Yes' | 'Close';
    type SecondaryButtonLabel = 'Cancel';
    interface PopupConfig {
        isShowPopup: boolean;
        header: JSX.Element | string;
        description: string;
        headerImage: string;
        primaryButtonLabel: PrimaryButtonLabel;
        secondaryButtonLabel: SecondaryButtonLabel;
        buttonsVisibility: {
            popupPrimaryButton: boolean;
            popupSecondaryButton: boolean;
        };
        holdInfoToProceed?: {
            selectedFileId: string | number;
        } | null;
    }
    const popupConfigInit: PopupConfig = {
        isShowPopup: false,
        header: t('COMMON.CONFIRMATION'),
        description: 'Are you sure you want to delete this document?',
        headerImage: ConfirmationRedImage,
        primaryButtonLabel: 'Yes',
        secondaryButtonLabel: 'Cancel',
        buttonsVisibility: {
            popupPrimaryButton: true,
            popupSecondaryButton: true
        }
    };
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);
    const triggerPopup = (data: PopupConfig['holdInfoToProceed']) => {
        setPopupConfig({ ...popupConfig, isShowPopup: true, holdInfoToProceed: data ?? null });
    };
    const resetPopupConfig = () => setPopupConfig(popupConfigInit);
    const handlerPopupPrimaryButtonClick = () => {
        const selectedFileToDelete = popupConfig.holdInfoToProceed?.selectedFileId ?? null;

        if (selectedFileToDelete) {
            stdFunctions.fileDelete('popup', selectedGroup.groupId, +selectedFileToDelete);
            resetPopupConfig();
        } else {
            console.error('Error: selectedChipsToDelete is not found in the popupConfig.');
        }
    };

    // side effects
    const validateCurrentGroup = () => {
        const validationResult = standardModuleService.validateGroupsAndSetError('single-group', [
            selectedGroup
        ]);
        setSelectedGroup(validationResult.groups[0]);

        return validationResult;
    };

    useEffect(() => {
        validateCurrentGroup();
    }, [selectedGroup.sourceLanguage, selectedGroup.targetLanguage, selectedGroup.documentList]);

    return (
        <>
            {popupConfig.isShowPopup && (
                <ConfirmationPopup
                    popupID="popup-std-confirmation"
                    data-testid="popup-std-confirmation"
                    image={popupConfig.headerImage}
                    visible={popupConfig.isShowPopup}
                    headerText={popupConfig.header}
                    description={popupConfig.description}
                    acceptLabel={popupConfig.primaryButtonLabel}
                    rejectLabel={popupConfig.secondaryButtonLabel}
                    isShowAcceptButton={popupConfig.buttonsVisibility.popupPrimaryButton}
                    isShowRejectButton={popupConfig.buttonsVisibility.popupSecondaryButton}
                    onConfirm={handlerPopupPrimaryButtonClick}
                    onCancel={resetPopupConfig}
                />
            )}
            <UploadDialogSTDTemplate
                languageList={responseData.languageList}
                selectedGroup={selectedGroup}
                actions={{
                    setSelectedGroup(group: DocumentGroupModel) {
                        setSelectedGroup(group);
                    },
                    onDialogClear: () => stdFunctions.handlePageVisibility('upload-dialog-clear'),
                    onDialogClose: () => stdFunctions.handlePageVisibility('upload-dialog-close'),
                    onDialogSubmit,
                    onFileDelete: (selectedFileId: string | number) =>
                        triggerPopup({ selectedFileId }),
                    onLanguageChange(value) {
                        stdFunctions.handleLanguageChange({
                            group: selectedGroup,
                            fieldName: value.fieldName,
                            updatedLanguage: value.updatedLanguage,
                            isStoreAsTempData: true
                        });
                    },
                    handleUploadFiles: (files: TransformedObject[]) =>
                        stdFunctions.storeFilesAgainstGroup(files)
                }}
                flags={{
                    isDialogShow: flags.isShowUploadDialog,
                    isInvalidSL: flags.isSubmittingPopup && selectedGroup.errors.isInvalidSL,
                    isInvalidTL: flags.isSubmittingPopup && selectedGroup.errors.isInvalidTL
                }}
            />
        </>
    );
};
