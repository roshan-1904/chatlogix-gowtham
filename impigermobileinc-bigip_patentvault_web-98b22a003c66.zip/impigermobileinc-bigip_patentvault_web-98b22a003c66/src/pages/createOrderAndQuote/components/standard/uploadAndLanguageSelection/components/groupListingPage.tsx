import { FC, useEffect, useState } from 'react';
import { t } from 'i18next';
import ReuseSTD from './reuseComponentsSTD';
import { STDFunctionsModel } from './uploadAndLanguageSelection';
import { InputFieldTemplate } from 'components/reuseComponents/constructField';
import { AllLanguageResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import PrimeButton from 'components/buttons/primeButton';
import { FilterMatchMode } from 'primereact/api';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { MenuItem } from 'primereact/menuitem';
import DataTableComponent from 'shared/dataTable/dataTable';
import { FilePayload } from 'components/fileUpload/types/fileUpload.types';
import { DOCUMENT_TYPE } from 'constants/app.constant';
import standardModuleService from '../../languageSelection/services/standardModule.service';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import { DocumentGroupModel, STDPageDataModel } from '../types/uploadAndLanguageSelection.type';
import { Dialog } from 'primereact/dialog';
import {
    DataToPreviewDownloadType,
    LanguageSelectionDataItem
} from '../../languageSelection/types/languageSelection.type';
import { Tooltip } from 'primereact/tooltip';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import utils from 'core/utils/utils';
import { previewDialogPopup } from 'constants/styles.constant';
import { formatFileSize } from 'components/fileUpload/uploadingFileStatus/uploadingFileStatus';
import PrimeSelect from 'components/inputs/primeSelect.input';
import FieldValue from 'components/inputs/fieldValue.label';
interface ExtendedGroupListingModal extends STDPageDataModel {
    stdFunctions: STDFunctionsModel;
}

const GroupListingPage: FC<ExtendedGroupListingModal> = ({
    responseData,
    groups,
    flags,
    stdFunctions
}) => {
    return flags.isShowGroupListing ? (
        <>
            <div
                data-testid="std-group-listing-page"
                className="flex items-center justify-between px-6 pt-3">
                {/* header */}
                <ReuseSTD.STDHeaderLabelAndWarning
                    headerName={t('STD_UPLOAD_SELECTION.LANDING_PAGE_TITLE')}
                    testId={'std-group-listing-page-header'}
                />
                <PrimeButton
                    testid="std-group-listing-add-button"
                    label={'Add Document & Language'}
                    type="primary"
                    className=""
                    icon="pi pi-plus-circle"
                    size="medium"
                    onClick={() => stdFunctions.groupUpdate(null, 'group-listing-add')}
                />
            </div>

            <div className="flex flex-col gap-4 px-6 py-3">
                {/* group listing */}
                {groups.map(
                    (group, index) =>
                        // deleted groups are not shown
                        !group.isGroupInActive && (
                            <GroupListingTemplate
                                key={index + 1}
                                flags={flags}
                                group={group}
                                languageList={responseData.languageList}
                                stdFunctions={stdFunctions}
                            />
                        )
                )}
            </div>
        </>
    ) : (
        <></>
    );
};

interface GroupListingTemplateModal {
    flags: STDPageDataModel['flags'];
    group: DocumentGroupModel;
    languageList: AllLanguageResponseType[];
    stdFunctions: STDFunctionsModel;
}
const GroupListingTemplate: FC<GroupListingTemplateModal> = ({
    flags,
    group,
    languageList,
    stdFunctions
}) => {
    const uploadedDocumentsCount = group.documentList.length;
    const [toggleRowData, setToggleRowData] = useState<FilePayload>();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    // handlers
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const renderInlineField = (params: {
        fieldType: 'text' | 'number' | 'toggle';
        fieldName: string;
        rowData: any;
    }) => {
        try {
            const isReferenceDocument = params.rowData.documentType === DOCUMENT_TYPE.REFERENCE.id;

            const handleInputValueChange = (data: {
                fileUniqueid: number;
                fieldName: 'wordCount' | 'fileNotes' | 'documentType';
                updatedValue: string | number;
            }) => {
                const updatedDocumentList = group.documentList.map((file) => {
                    if (file.fileUniqueId === data.fileUniqueid) {
                        return { ...file, [data.fieldName]: data.updatedValue };
                    }
                    return file;
                });

                stdFunctions.groupUpdate(
                    { ...group, documentList: updatedDocumentList },
                    'group-listing-change'
                );
            };

            return (
                <>
                    {params.fieldType === 'number' && (
                        <InputFieldTemplate
                            data={{
                                fieldType: 'input',
                                inputType: {
                                    type: 'number',
                                    isDecimal: false
                                },
                                value: isReferenceDocument
                                    ? null
                                    : params.rowData[params.fieldName],
                                fieldValue: isReferenceDocument
                                    ? null
                                    : params.rowData[params.fieldName],
                                fieldLabelName: null,
                                disabled: Boolean(isReferenceDocument),
                                placeholder: 'Word Count',
                                onChange: (value: string) =>
                                    handleInputValueChange({
                                        fileUniqueid: params.rowData.fileUniqueId,
                                        fieldName: 'wordCount',
                                        updatedValue: value
                                    })
                            }}
                        />
                    )}
                    {params.fieldType === 'text' && (
                        <InputFieldTemplate
                            data={{
                                fieldType: 'input',
                                inputType: { type: 'text' },
                                fieldLabelName: null,
                                value: params.rowData[params.fieldName],
                                fieldValue: null,
                                invalid: false,
                                placeholder: 'Notes',
                                onChange: (value: number) =>
                                    handleInputValueChange({
                                        fileUniqueid: params.rowData.fileUniqueId,
                                        fieldName: 'fileNotes',
                                        updatedValue: value
                                    })
                            }}
                        />
                    )}
                    {params.fieldType === 'toggle' && (
                        <div className="flex items-center justify-start gap-4">
                            <FieldValue
                                value={
                                    params.rowData[params.fieldName] === DOCUMENT_TYPE.REFERENCE.id
                                        ? 'Yes'
                                        : 'No'
                                }
                                renderAs={'string'}
                                customClass={{ field: 'font-normal' }}
                            />
                            <InputFieldTemplate
                                data={{
                                    fieldType: 'toggle',
                                    inputType: { type: 'others' },
                                    fieldLabelName: null,
                                    value:
                                        params.rowData[params.fieldName] ===
                                        DOCUMENT_TYPE.REFERENCE.id,
                                    fieldValue: null,
                                    customClass: {
                                        fieldWrapperClass: ''
                                    },
                                    disabled: false,
                                    invalid: false,
                                    onChange(value: boolean) {
                                        handleInputValueChange({
                                            fileUniqueid: params.rowData.fileUniqueId,
                                            fieldName: 'documentType',
                                            updatedValue: value
                                                ? DOCUMENT_TYPE.REFERENCE.id
                                                : DOCUMENT_TYPE.SOURCE.id
                                        });
                                    }
                                }}
                            />
                        </div>
                    )}
                </>
            );
        } catch (error) {
            console.error('Error in STD listing page table renderInlineField(): ', error);
        }
    };

    // helpers
    const isGroupError = () => {
        const isError = flags.isSubmittingGroupsList
            ? standardModuleService.isGroupContainsErrors(group.errors)
            : false;

        return isError;
    };

    // preview & downloads
    const [isPreviewFile, setIsPreviewFile] = useState<boolean>(false);
    const [dataToPreviewDownload, setDataToPreviewDownload] = useState<DataToPreviewDownloadType>(
        {}
    );

    const documentNameWithSizeTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileUniqueId}
                    content={rowData.name}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileUniqueId + ' flex gap-2'}>
                    <p
                        data-testid="documentName"
                        className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                        {rowData.name}
                    </p>
                    <p className="text-base text-neutral-200">
                        {formatFileSize(rowData.size as number)}
                    </p>
                </div>
            </div>
        );
    };
    const handlePreviewDocument = (data: any, isDownload: boolean = false) => {
        if (!data) return;

        const { azureBlobFileName, type, name, azureBlobFolderPath } = data;

        isSasUrlExpired(dataToPreviewDownload.sasURL as string).then((newSasUrl) => {
            newSasUrl = newSasUrl?.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${dataToPreviewDownload.blobUri}/${azureBlobFolderPath}/${azureBlobFileName}?${newSasUrl}`;

            if (isDownload) {
                utils.handleDownloadPngSvg(previewURL, name as string);
            } else {
                // Extract the file extension from the file type
                const fileExtension = (type || '').toLowerCase().split('/')[1];

                // Define an array of allowed file extensions for preview
                const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

                // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
                const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

                if (isImageOrPdf) {
                    // Extract file name without extension
                    const fileNameWithoutExtension = name.split('.')[0];

                    setDataToPreviewDownload({
                        ...dataToPreviewDownload,
                        previewImage: previewURL, // Set preview image name
                        previewImageName: fileNameWithoutExtension // Set preview image URL
                    });

                    // Show preview dialog
                    setIsPreviewFile(true);
                } else {
                    // Redirect to the file URL for non-preview files
                    window.open(previewURL, '_blank');
                }
            }
        });
    };
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();

            if (!response) return;
            const [blobUri, sasToken] = response.split('?');
            setDataToPreviewDownload({
                ...dataToPreviewDownload,
                blobUri,
                sasURL: sasToken ?? null
            });
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
            return null;
        }
    };

    useEffect(() => {
        // get sas token for the uploaded files
        getSasUrlApi();
    }, []);

    // table configs
    const menuItems: MenuItem[] = [
        {
            items: [
                // TODO:
                // {
                //     label: t('COMMON.DOWNLOAD'),
                //     icon: () => <i className="pi pi-download text-primary" />,
                //     disabled: false,
                //     className: `${''}`,
                //     command() {
                //         // handlePreviewDocument(toggleRowData ?? null, true);
                //     }
                // },
                {
                    label: t('COMMON.DELETE'),
                    icon: () => <i className="pi pi-trash text-secondary" />,
                    command() {
                        toggleRowData && triggerPopup('delete-file');
                    }
                }
            ]
        }
    ];
    let columns = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'name',
            header: 'Document Name',
            sortable: true,
            filter: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            // valueType: ValueType.Link,
            columnNumber: columns++,
            className: 'w-80 max-w-80 truncate',
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            body: (rowData: LanguageSelectionDataItem) => documentNameWithSizeTemplate(rowData)
        },
        {
            field: 'documentType',
            header: 'Reference Document',
            sortable: false,
            filter: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: columns++,
            visibility: true,
            body: (rowData: any) =>
                renderInlineField({ fieldType: 'toggle', fieldName: 'documentType', rowData })
        },
        {
            field: 'wordCount',
            header: 'Word Count',
            sortable: false,
            filter: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: columns++,
            visibility: true,
            body: (rowData: any) =>
                renderInlineField({ fieldType: 'number', fieldName: 'wordCount', rowData })
        },
        {
            field: 'fileNotes',
            header: 'Notes',
            sortable: false,
            filter: false,
            filterType: FilterType.Default,
            valueType: ValueType.Text,
            columnNumber: columns++,
            visibility: true,
            body: (rowData: any) =>
                renderInlineField({ fieldType: 'text', fieldName: 'fileNotes', rowData })
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            valueType: ValueType.Action,
            columnNumber: columns++,
            visibility: true
        }
    ];
    const tableCustomHeader = () => {
        return (
            <div className="flex items-center justify-between px-4 py-2 bg-white">
                <div className="flex items-center gap-4 font-medium ">
                    <h5>
                        {'Uploaded Document(s)'}
                        {uploadedDocumentsCount > 0 ? ` (${uploadedDocumentsCount})` : ''}
                    </h5>
                    {flags.isSubmittingGroupsList && group.errors.isInvalidSource && (
                        <p className="text-secondary">
                            {'At least one source document is required.'}
                        </p>
                    )}
                </div>
                <PrimeButton
                    testid="std-group-listing-group-add-button"
                    label={'Add'}
                    type="primary"
                    className=""
                    icon="pi pi-plus-circle"
                    size="medium"
                    onClick={() => stdFunctions.groupSelect(group)}
                />
            </div>
        );
    };
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.LANGUAGE_SELECTION,
        reOrderableColumns: true,
        title: t('MENU.LANGUAGE_SELECTION'),
        showFilter: false,
        filters: {
            documentName: { value: null, matchMode: FilterMatchMode.CONTAINS },
            documentType: { value: null, matchMode: FilterMatchMode.CONTAINS },
            notes: { value: null, matchMode: FilterMatchMode.CONTAINS }
        },
        customerHeader: tableCustomHeader(),
        emptyMessage: t('LANGUAGE_SELECTION.EMPTY_MESSAGE'),
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.LANGUAGE_SELECTION_COLUMN_ORDERS,
        columns: columnSchema,
        items: menuItems,
        renderChildrenAlone: true,
        customTableHeight: true
    };

    // toast / popup
    type PrimaryButtonLabel = 'Yes' | 'Close';
    type SecondaryButtonLabel = 'Cancel';
    interface PopupConfig {
        isShowPopup: boolean;
        header: JSX.Element | string;
        description: string;
        headerImage: string;
        primaryButtonLabel: PrimaryButtonLabel;
        secondaryButtonLabel: SecondaryButtonLabel;
        buttonsVisibility: {
            popupPrimaryButton: boolean;
            popupSecondaryButton: boolean;
        };
        holdInfoToProceed?: {
            action: 'delete-file' | 'delete-group';
        } | null;
    }
    const popupConfigInit: PopupConfig = {
        isShowPopup: false,
        headerImage: ConfirmationRedImage,
        header: t('COMMON.CONFIRMATION'),
        description: '',
        primaryButtonLabel: 'Yes',
        secondaryButtonLabel: 'Cancel',
        buttonsVisibility: {
            popupPrimaryButton: true,
            popupSecondaryButton: true
        }
    };
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);
    const triggerPopup = (action: 'delete-file' | 'delete-group') => {
        const description =
            action === 'delete-file'
                ? 'Are you sure you want to delete this document?'
                : 'Are you sure you want to delete this section?';

        setPopupConfig({
            ...popupConfig,
            isShowPopup: true,
            description,
            holdInfoToProceed: { action }
        });
    };
    const resetPopupConfig = () => setPopupConfig(popupConfigInit);
    const handlerPopupPrimaryButtonClick = () => {
        const action = popupConfig.holdInfoToProceed?.action ?? null;

        if (action === 'delete-file' && toggleRowData?.fileUniqueId) {
            stdFunctions.fileDelete('listing-action', group.groupId, toggleRowData?.fileUniqueId);
            resetPopupConfig();
        } else if (action === 'delete-group') {
            stdFunctions.groupDelete({ ...group, isGroupInActive: true });
        } else {
            console.error('Error: No fileUniqueId found in toggleRowData');
        }
    };

    return (
        <>
            {popupConfig.isShowPopup && (
                <ConfirmationPopup
                    popupID="popup-std-confirmation"
                    data-testid="popup-std-confirmation"
                    image={popupConfig.headerImage}
                    visible={popupConfig.isShowPopup}
                    headerText={popupConfig.header}
                    description={popupConfig.description}
                    acceptLabel={popupConfig.primaryButtonLabel}
                    rejectLabel={popupConfig.secondaryButtonLabel}
                    isShowAcceptButton={popupConfig.buttonsVisibility.popupPrimaryButton}
                    isShowRejectButton={popupConfig.buttonsVisibility.popupSecondaryButton}
                    onConfirm={handlerPopupPrimaryButtonClick}
                    onCancel={resetPopupConfig}
                />
            )}

            {/* PDF preview */}
            {dataToPreviewDownload?.previewImage && (
                <Dialog
                    header={
                        <div className="w-full flex justify-between items-center">
                            {dataToPreviewDownload.previewImageName}
                            <i
                                className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                                onClick={() =>
                                    utils.handleDownloadPngSvg(
                                        dataToPreviewDownload.previewImage as string,
                                        dataToPreviewDownload.previewImageName as string
                                    )
                                }
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                data-test="downloadButton"
                            />
                        </div>
                    }
                    visible={isPreviewFile}
                    pt={previewDialogPopup}
                    style={{
                        minWidth: '60vw',
                        width: 'auto',
                        maxWidth: '80vw',
                        padding: '20px'
                    }}
                    onHide={() => setIsPreviewFile(false)}
                    data-testid="previewDialog">
                    <iframe
                        title="iframe-std-preview-02"
                        src={`${dataToPreviewDownload.previewImage}#toolbar=0&page=1&zoom=100,1,1`}
                        style={{ width: '100%', minHeight: '80vh' }}
                    />
                </Dialog>
            )}

            {/* Group Listing */}
            <div
                className={`${isGroupError() ? 'border-secondary' : 'border-neutral-700/20'} relative min-h-8 bg-neutral-bg px-4 pt-2 pb-0 rounded-lg border `}>
                <i
                    className="absolute cursor-pointer -top-2 -right-3 pi pi-times border p-2 bg-neutral-100 text-black/50 text-[0.85rem] rounded-2xl"
                    onClick={() => triggerPopup('delete-group')}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <PrimeSelect
                        testId={'primeSelect'}
                        fieldLabelName={'Source Language'}
                        value={group.sourceLanguage ?? []}
                        options={languageList}
                        optionLabel="name"
                        optionValue="id"
                        placeholder="Select"
                        invalid={flags.isSubmittingGroupsList && group.errors.isInvalidSL}
                        required={true}
                        disabled={false}
                        showInputLabelName={true}
                        isMultiSelect={true}
                        isFilterEnabled={true}
                        isClearEnabled={true}
                        isRenderAsChip={false}
                        errorMsg="Source Language is required"
                        customClass={{ wrapper: 'max-w-[80%]' }}
                        onChange={(selectedValue) =>
                            stdFunctions.handleLanguageChange({
                                group,
                                fieldName: 'sourceLanguage',
                                updatedLanguage: selectedValue as number[],
                                isStoreAsTempData: false
                            })
                        }
                    />
                    <PrimeSelect
                        testId={'primeSelect'}
                        fieldLabelName={'Target Language'}
                        value={group.targetLanguage ?? []}
                        options={languageList}
                        optionLabel="name"
                        optionValue="id"
                        placeholder="Select"
                        invalid={flags.isSubmittingGroupsList && group.errors.isInvalidTL}
                        required={true}
                        disabled={false}
                        showInputLabelName={true}
                        isMultiSelect={true}
                        isFilterEnabled={true}
                        isClearEnabled={true}
                        isRenderAsChip={false}
                        errorMsg="Target Language is required"
                        customClass={{ wrapper: 'max-w-[80%]' }}
                        onChange={(selectedValue) =>
                            stdFunctions.handleLanguageChange({
                                group,
                                fieldName: 'targetLanguage',
                                updatedLanguage: selectedValue as number[],
                                isStoreAsTempData: false
                            })
                        }
                    />
                </div>
                <div data-testid="std-dataTable-component" className="my-4">
                    <DataTableComponent
                        tableData={group.documentList}
                        tableRequestBodyData={requestBody}
                        tableDefinition={tableDefinition}
                        handleFilter={handleFilter}
                        isLazy={false}
                        toggleRowData={(rowData) => {
                            setToggleRowData(rowData as FilePayload);
                        }}
                    />
                </div>
            </div>
        </>
    );
};

export default GroupListingPage;
