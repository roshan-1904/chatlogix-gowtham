import { render, screen } from '@testing-library/react';
import ReuseSTD from './reuseComponentsSTD';

describe('STDHeaderLabelAndWarning', () => {
    const { STDHeaderLabelAndWarning } = ReuseSTD;

    it('renders the header name and warning label correctly', () => {
        render(
            <STDHeaderLabelAndWarning
                headerName="Test Header"
                content={{ warning: 'Test Warning' }}
                testId="test-id"
            />
        );

        const wrapper = screen.getByTestId('test-id');
        expect(wrapper).toBeInTheDocument();
        expect(wrapper).toHaveTextContent('Test Header');
        expect(wrapper).toHaveTextContent('Test Warning');
    });

    it('applies custom class names correctly', () => {
        render(
            <STDHeaderLabelAndWarning
                headerName="Test Header"
                content={{ warning: 'Test Warning' }}
                testId="test-id"
                className={{
                    wrapper: 'custom-wrapper',
                    header: 'custom-header',
                    warning: 'custom-warning'
                }}
            />
        );

        const wrapper = screen.getByTestId('test-id');
        expect(wrapper).toHaveClass('custom-wrapper');
        expect(wrapper.querySelector('h4')).toHaveClass('custom-header');
        expect(wrapper.querySelector('.custom-warning')).toBeInTheDocument();
    });

    it('handles missing optional className props gracefully', () => {
        render(
            <STDHeaderLabelAndWarning
                headerName="Test Header"
                content={{ warning: 'Test Warning' }}
                testId="test-id"
            />
        );

        const wrapper = screen.getByTestId('test-id');
        expect(wrapper).toBeInTheDocument();
        expect(wrapper).not.toHaveClass('undefined');
    });
});
