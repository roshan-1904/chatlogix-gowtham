import { render, screen } from '@testing-library/react';
import STDFileUpload from './stdFileUpload';
import FileUpload from 'components/fileUpload/fileUpload';

jest.mock('components/fileUpload/fileUpload', () =>
    jest.fn(() => <div data-testid="file-upload-mock"></div>)
);
jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
    getData: jest.fn(() => ({
        info: { primaryId: 123 }
    }))
}));

describe('STDFileUpload Component', () => {
    const mockStoreDocumentsAgainstGroup = jest.fn();

    const defaultProps = {
        stdGroupId: 1,
        documentType: 2,
        notesForUploadedFiles: '',
        storeDocumentsAgainstGroup: mockStoreDocumentsAgainstGroup,
        errorMsgForFiles: 'Document is mandatory'
    };

    it('should render the component with required props', () => {
        render(
            <STDFileUpload
                storeFilesAgainstGroup={function (): void {
                    throw new Error('Function not implemented.');
                }}
                {...defaultProps}
            />
        );

        // Check if the main container is rendered
        const container = screen.getByTestId('std-file-upload');
        expect(container).toBeInTheDocument();

        // Check if the FileUpload component is rendered
        const fileUploadComponent = screen.getByTestId('file-upload-mock');
        expect(fileUploadComponent).toBeInTheDocument();
    });

    it('should pass the correct props to FileUpload component', () => {
        render(
            <STDFileUpload
                storeFilesAgainstGroup={() => {
                    throw new Error('Function not implemented.');
                }}
                {...defaultProps}
            />
        );

        expect(FileUpload).toHaveBeenCalledWith(
            expect.objectContaining({
                uploadFileApiUrl: 'STD_Restrict_File_Upload_API',
                moduleType: {
                    moduleId: 'QUOTE_ORDER_MODULE',
                    azureFolderName: 'QUOTE_ORDER_MODULE'
                },
                primaryId: 123,
                documentUploadRequired: true,
                ifStandardDocumentUpload: {
                    isStandardDoc: true,
                    documentType: 2,
                    stdGroupId: 1,
                    storeDocumentsAgainstGroup: mockStoreDocumentsAgainstGroup
                }
            }),
            {}
        );
    });

    it('should display the correct title for the upload section', () => {
        render(
            <STDFileUpload
                storeFilesAgainstGroup={function (): void {
                    throw new Error('Function not implemented.');
                }}
                {...defaultProps}
            />
        );

        const titleElement = screen.getByText('Upload Document');
        expect(titleElement).toBeInTheDocument();

        const requiredIndicator = screen.getByText('*');
        expect(requiredIndicator).toBeInTheDocument();
    });
});
