import { render, screen } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import UploadAndLanguageSelection from './uploadAndLanguageSelection';

jest.mock('core/store/notificationStore/notificationStore', () => ({
    ...jest.requireActual('core/store/notificationStore/notificationStore'),
    showAlert: jest.fn()
}));

describe('UploadAndLanguageSelection Component', () => {
    it('should render the component without crashing', () => {
        render(<UploadAndLanguageSelection />);
        expect(screen.getByText(/STD landing page/i)).toBeInTheDocument();
    });

    it('should call NotificationStore.showAlert with correct parameters', () => {
        const testMessage = 'Test notification message';
        const testType = ToastType.SUCCESS;

        act(() => {
            const message: notificationModel = {
                message: testMessage,
                type: testType
            };
            NotificationStore.showAlert(message);
        });

        expect(NotificationStore.showAlert).toHaveBeenCalledWith({
            message: testMessage,
            type: testType
        });
    });
});
