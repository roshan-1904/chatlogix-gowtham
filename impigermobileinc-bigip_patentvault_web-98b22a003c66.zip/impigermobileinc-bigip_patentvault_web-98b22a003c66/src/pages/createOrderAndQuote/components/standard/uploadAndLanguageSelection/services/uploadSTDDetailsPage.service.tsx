import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import {
    SaveSTDDetailsPageFilesModel,
    STDUpdateDocumentWordCountModel,
    STDUpdateNotesModel
} from '../types/uploadAndLanguageSelection.type';

// variables
const httpService = new HttpService();
const baseURL: string | null = process.env.REACT_APP_QUOTE_BASE_URL ?? null;
if (!baseURL)
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');

const updateNotes = async (payload: STDUpdateNotesModel) => {
    try {
        const apiUrl = END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_UPDATE_NOTES;

        const response = await httpService.post(apiUrl, payload, {}, false, baseURL);
        if (response) return response;
    } catch (error: any) {
        console.error('Error while updating the notes in STD details page.');
        return null;
    }
};

const updateDocumentWordCount = async (payload: STDUpdateDocumentWordCountModel) => {
    try {
        const apiUrl: string = END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_UPDATE_WORD_COUNT;

        const response = await httpService.put(apiUrl, payload, {}, false, baseURL);
        if (response) return response;
    } catch (error: any) {
        console.error('Error while updating the word count in STD details page.');
        return null;
    }
};

const validateUpdateWordCount = async (payload: STDUpdateDocumentWordCountModel) => {
    try {
        const apiUrl: string = END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_VALIDATE_UPDATE_WORD_COUNT;

        const response = await httpService.post(apiUrl, payload, {}, false, baseURL);
        if (response) return response;
    } catch (error: any) {
        console.error('Error while validating the word count in STD details page.');
        return null;
    }
};

const saveSTDDetailsPageFiles = async (payload: SaveSTDDetailsPageFilesModel) => {
    try {
        const sectionId = payload.documents[0].sectionId;
        const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT[sectionId ? 'STD_UPLOAD_SINGLE_DOCUMENT' : 'STD_UPLOAD_DOCUMENT_SECTION']}`;

        const response = await httpService.post(apiUrl, payload, {}, false, baseURL);
        return response;
    } catch (error: any) {
        console.error('Error while saving files.');
        return null;
    }
};

const uploadSTDDetailsPageService = {
    updateNotes,
    updateDocumentWordCount,
    validateUpdateWordCount,
    saveSTDDetailsPageFiles
};
export default uploadSTDDetailsPageService;
