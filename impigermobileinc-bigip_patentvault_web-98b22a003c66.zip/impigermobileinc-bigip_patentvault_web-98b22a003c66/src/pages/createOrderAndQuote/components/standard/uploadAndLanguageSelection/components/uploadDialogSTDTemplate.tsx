import { PrimeRadioGroup } from 'components/inputs/primeRadio.input';
import STDFileUpload from './stdFileUpload';
import { PrimeDialogBox } from 'components/dialog/primeDialogBox';
import { DOCUMENT_TYPE } from 'constants/app.constant';
import { FC } from 'react';
import { AllLanguageResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { TransformedObject } from 'components/fileUpload/types/fileUpload.types';
import { DocumentGroupModel } from '../types/uploadAndLanguageSelection.type';
import PrimeTextArea from 'components/inputs/primeTextArea.input';
import PrimeSelect from 'components/inputs/primeSelect.input';
import FieldValue from 'components/inputs/fieldValue.label';

interface UploadDialogSTDTemplateModel {
    languageList: AllLanguageResponseType[];
    selectedGroup: DocumentGroupModel;
    actions: {
        setSelectedGroup: (group: DocumentGroupModel) => void;
        onDialogClear: () => void;
        onDialogClose: () => void;
        onDialogSubmit: () => void;
        onFileDelete: (fileId: string | number) => void;
        onLanguageChange: (value: {
            fieldName: 'sourceLanguage' | 'targetLanguage';
            updatedLanguage: number[];
        }) => void;
        handleUploadFiles: (files: TransformedObject[]) => void;
    };
    flags: {
        isDialogShow: boolean;
        isInvalidSL: boolean;
        isInvalidTL: boolean;
        isInvalidFiles?: boolean;
        isDisableLanguages?: boolean;
        errorMsgForFiles?: string;
    };
}
const UploadDialogSTDTemplate: FC<UploadDialogSTDTemplateModel> = ({
    languageList,
    selectedGroup,
    actions,
    flags
}) => {
    // helpers
    const onNotesChange = (value: string) => {
        const updatedDocumentList = selectedGroup.documentList.map((doc) => {
            return { ...doc, fileNotes: value };
        });

        actions.setSelectedGroup({
            ...selectedGroup,
            documentList: updatedDocumentList,
            tempNotes: value
        });
    };

    // components
    const bodyContent = () => {
        const uploadedFiles: { id: number; value: string }[] =
            selectedGroup.documentList
                .filter((doc) => doc.fileUniqueId)
                .map((doc) => ({
                    id: doc.fileUniqueId!,
                    value: doc.name
                })) ?? [];

        return (
            <>
                {/* document-type (radio) */}
                <PrimeRadioGroup
                    labelName="Document Type"
                    options={[
                        { key: DOCUMENT_TYPE.SOURCE.id, name: DOCUMENT_TYPE.SOURCE.name },
                        { key: DOCUMENT_TYPE.REFERENCE.id, name: DOCUMENT_TYPE.REFERENCE.name }
                    ]}
                    groupName="std-document-type"
                    selectedValue={selectedGroup.documentType}
                    required={true}
                    customClass={{ fieldWrapper: 'mt-2 mb-4' }}
                    actions={{
                        onChange(value: number) {
                            actions.setSelectedGroup({
                                ...selectedGroup,
                                documentType: value
                            });
                        }
                    }}
                />
                {/* languages (multi-select) */}
                <div className="flex gap-3 my-5">
                    <PrimeSelect
                        testId={'primeSelect'}
                        fieldLabelName={'Source Language'}
                        value={selectedGroup.sourceLanguage ?? []}
                        options={languageList}
                        optionLabel="name"
                        optionValue="id"
                        placeholder="Select"
                        invalid={flags.isInvalidSL}
                        required={true}
                        disabled={
                            flags.isDisableLanguages ||
                            (!!selectedGroup.groupUpdatedLastAt &&
                                selectedGroup.sourceLanguage?.length > 0)
                        }
                        showInputLabelName={true}
                        isMultiSelect={true}
                        isFilterEnabled={true}
                        isClearEnabled={true}
                        isRenderAsChip={false}
                        errorMsg="Source Language is required"
                        customClass={{ wrapper: 'max-w-[50%]' }}
                        onChange={(selectedValue) =>
                            actions.onLanguageChange({
                                fieldName: 'sourceLanguage',
                                updatedLanguage: selectedValue as number[]
                            })
                        }
                    />
                    <PrimeSelect
                        testId={'primeSelect'}
                        fieldLabelName={'Target Language'}
                        value={selectedGroup.targetLanguage ?? []}
                        options={languageList}
                        optionLabel="name"
                        optionValue="id"
                        placeholder="Select"
                        invalid={flags.isInvalidTL}
                        required={true}
                        disabled={
                            flags.isDisableLanguages ||
                            (!!selectedGroup.groupUpdatedLastAt &&
                                selectedGroup.targetLanguage?.length > 0)
                        }
                        showInputLabelName={true}
                        isMultiSelect={true}
                        isFilterEnabled={true}
                        isClearEnabled={true}
                        isRenderAsChip={false}
                        errorMsg="Target Language is required"
                        customClass={{ wrapper: 'max-w-[50%]' }}
                        onChange={(selectedValue) =>
                            actions.onLanguageChange({
                                fieldName: 'targetLanguage',
                                updatedLanguage: selectedValue as number[]
                            })
                        }
                    />
                </div>
                {/* file-upload (upload component) */}
                <div className="mb-4">
                    <STDFileUpload
                        stdGroupId={selectedGroup.groupId}
                        documentType={selectedGroup.documentType}
                        notesForUploadedFiles={selectedGroup.tempNotes}
                        storeFilesAgainstGroup={actions.handleUploadFiles}
                        isShowErrorMsg={flags.isInvalidFiles}
                        errorMsgForFiles={flags.errorMsgForFiles}
                    />
                </div>
                {/* selected files names (chips with delete) */}
                {uploadedFiles.length > 0 && (
                    <FieldValue
                        value={uploadedFiles}
                        renderAs={'string'}
                        chips={{
                            isTemplateChips: true,
                            chipsContent: uploadedFiles,
                            isChipsDeletable: true,
                            action: (selectedFileId: string | number) =>
                                actions.onFileDelete(selectedFileId)
                        }}
                        customClass={{ wrapper: 'gap-3 my-4' }}
                    />
                )}
                {/* common-notes (text-area) */}
                <PrimeTextArea
                    fieldLabelName={'Document Notes'}
                    value={selectedGroup.tempNotes}
                    testId={'primeTextArea'}
                    placeholder={''}
                    disabled={false}
                    invalid={false}
                    onChange={(value) => onNotesChange(value)}
                    showInputLabelName={true}
                    customClass={{
                        wrapper: 'mt-4 mb-2'
                    }}
                />
            </>
        );
    };

    return (
        <PrimeDialogBox
            isShowDialog={flags.isDialogShow}
            header={'Add Document & Language'}
            body={<>{bodyContent()}</>}
            actions={{
                onClose: actions.onDialogClose,
                onDialogClear: actions.onDialogClear,
                onDialogSubmit: actions.onDialogSubmit
            }}
        />
    );
};

export default UploadDialogSTDTemplate;
