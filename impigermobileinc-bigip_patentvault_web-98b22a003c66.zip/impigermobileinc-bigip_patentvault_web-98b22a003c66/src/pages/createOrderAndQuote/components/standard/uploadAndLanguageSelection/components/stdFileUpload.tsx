import FileUpload from 'components/fileUpload/fileUpload';
import { TransformedObject } from 'components/fileUpload/types/fileUpload.types';
import LabelName from 'components/inputs/labelName';
import { MODULE_TYPE } from 'constants/app.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

interface STDFileUploadModel {
    stdGroupId: number;
    documentType: number;
    notesForUploadedFiles: string;
    storeFilesAgainstGroup: (files: TransformedObject[]) => void;
    isShowErrorMsg?: boolean;
    errorMsgForFiles?: string;
}

const STDFileUpload = (params: STDFileUploadModel) => {
    const moduleId = MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId;
    const azureFolderName = MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName;
    const primaryId = quoteOrderModuleStore.getData()?.info?.primaryId ?? 0; // Get primaryId from store
    const uploadFileApiUrl = 'STD_Restrict_File_Upload_API'; // Upload file API URL

    return (
        <div className="stdFileUpload" data-testid="std-file-upload">
            <FileUpload
                uploadFileApiUrl={uploadFileApiUrl}
                deleteFileApiUrl={null}
                getDocumentTypeApiUrl={null}
                updateDocumentTypeApiUrl={null}
                moduleType={{ moduleId, azureFolderName }}
                primaryId={primaryId}
                stepperModuleStore={quoteOrderModuleStore}
                documentUploadTitle={false}
                documentUploadOptionalText={false}
                uploadedDocumentListTable={false}
                documentUploadRequired={false}
                documentTypeFlag={false}
                moduleName={'std-' + primaryId}
                ifStandardDocumentUpload={{
                    isStandardDoc: true,
                    documentType: params.documentType,
                    stdGroupId: params.stdGroupId,
                    notesForUploadedFiles: params.notesForUploadedFiles,
                    storeFilesAgainstGroup: params.storeFilesAgainstGroup
                }}
                data-testid="stdFileUploadComponent"
                titleForUploadSection={
                    <LabelName
                        name={'Upload Document(s)'}
                        required={true}
                        description={params.isShowErrorMsg ? params.errorMsgForFiles : null}
                    />
                }
            />
        </div>
    );
};

export default STDFileUpload;
