import { FC } from 'react';
import { t } from 'i18next';
import stdLandingPageIcon from 'assets/svgs/std-landing-page-icon.svg';
import { STDFunctionsModel } from './uploadAndLanguageSelection';
import PrimeButton from 'components/buttons/primeButton';
import WarningLabel from 'components/reuseComponents/warningLabel';
import { DocumentGroupModel, STDPageDataModel } from '../types/uploadAndLanguageSelection.type';

interface LandingPageModal {
    flags: STDPageDataModel['flags'];
    selectedGroup: DocumentGroupModel;
    stdFunctions: STDFunctionsModel;
}

export const LandingPage: FC<LandingPageModal> = ({ flags, selectedGroup, stdFunctions }) => {
    const { isShowLandingPage } = flags ?? {};

    return isShowLandingPage ? (
        <div className="h-[88%]" data-testid="std-landing-page">
            {/* header */}
            <div
                data-testid="std-landing-page-header"
                className="flex items-center justify-start gap-5 px-6 py-4">
                {/* title */}
                <h4 data-testid="std-landing-page-header-title" className="font-medium">
                    {t('STD_UPLOAD_SELECTION.LANDING_PAGE_TITLE')}
                </h4>
                {/* warning msg */}
                <WarningLabel content={t('STD_UPLOAD_SELECTION.LANDING_PAGE_HEADER_WARNING')} />
            </div>

            {/* body content - info */}
            <div
                data-testid="std-landing-page-info"
                className="flex justify-center items-center h-full">
                <div
                    data-testid="std-landing-page-info-header"
                    className="flex flex-col items-center justify-between justify-items-center gap-2">
                    {/* icon */}
                    <img className="h-full my-3" src={stdLandingPageIcon} alt="Confirmation" />
                    {/* header */}
                    <h4 data-testid="std-landing-page-title" className="font-medium">
                        {t('STD_UPLOAD_SELECTION.LANDING_PAGE_INFO_HEADER')}
                    </h4>
                    {/* desc */}
                    <p data-testid="std-landing-page-desc" className="">
                        {t('STD_UPLOAD_SELECTION.LANDING_PAGE_INFO_DESC')}
                    </p>
                    <PrimeButton
                        testid="std-create-landing-page-add-document-button"
                        label={t('STD_UPLOAD_SELECTION.LANDING_PAGE_ADD_DOCUMENT_BUTTON')}
                        type="primary"
                        className="my-3"
                        icon="pi pi-plus-circle"
                        size="large"
                        onClick={() =>
                            stdFunctions.groupUpdate({ ...selectedGroup }, 'landing-page-add')
                        }
                    />
                </div>
            </div>
        </div>
    ) : (
        <></>
    );
};
