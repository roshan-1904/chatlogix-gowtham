import uploadAndLanguageSelectionService from './uploadAndLanguageSelection.service';
import HttpService from 'core/interceptor/api.handler';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('core/interceptor/api.handler');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('core/store/authStore/authStore');
jest.mock('constants/endPoint', () => ({
    END_POINT: {
        ORDERS_AND_QUOTES_END_POINT: {
            STANDARD_SUBMISSION: '/standard-submission'
        }
    }
}));

describe('uploadAndLanguageSelectionService', () => {
    const mockHttpService = new HttpService() as jest.Mocked<HttpService>;
    const mockQuoteOrderModuleStore = quoteOrderModuleStore as jest.Mocked<
        typeof quoteOrderModuleStore
    >;
    const mockAuthStore = AuthStore as jest.Mocked<typeof AuthStore>;

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('stdSubmission', () => {
        it('should successfully submit the payload and return the response', async () => {
            const mockResponse = { requestNumber: 12345 };
            mockHttpService.post.mockResolvedValue(mockResponse);

            mockQuoteOrderModuleStore.getData.mockReturnValue({
                info: {
                    selectedCategory: {
                        parentId: 1,
                        patentCategoryId: 2,
                        patentCategoryName: '',
                        patentCategoryDisplay: '',
                        patentCategoryDisplayOrder: 0,
                        patentCategoryIsRequestEntity: false
                    },
                    mode: null,
                    selectedService: null,
                    primaryId: 0,
                    documentId: null,
                    requestCurrencyId: null,
                    isEditFlow: null,
                    isSTDFlow: null,
                    isUP: null,
                    approveStatus: null,
                    statusId: null
                },
                formData: {
                    orderQuoteDetailsPage: {
                        companyName: { id: 3, requestCurrencyId: 4 },
                        contactUser: { id: 5 },
                        contactEmail: 'test@example.com',
                        poNumber: 'PO123',
                        cc: 'cc@example.com',
                        pmContainer: { projectManager: [6] },
                        salesRepContainer: { salesRep: [7] },
                        quoteRequired: true,
                        title: 'Test Patent',
                        requestedDeliveryDate: '2023-01-01',
                        quoteTargetDateTime: '2023-01-02',
                        referenceNumber: 'REF123'
                    },
                    uploadAndLanguageSelectionPage: {
                        pageData: {
                            groups: [
                                {
                                    groupId: 1,
                                    primaryId: 1,
                                    tempNotes: '',
                                    sourceLanguage: [1],
                                    targetLanguage: [2],
                                    errors: {
                                        isInvalidSL: false,
                                        isInvalidTL: false,
                                        isInvalidReference: false,
                                        isInvalidSource: false
                                    },
                                    documentList: [
                                        {
                                            name: 'file1',
                                            type: 'pdf',
                                            size: 1024,
                                            azureBlobFileName: 'blob1',
                                            documentType: 1,
                                            fileNotes: 'notes',
                                            wordCount: 100,
                                            progress: '',
                                            file: {},
                                            azureBlobFolderPath: '',
                                            moduleName: '',
                                            ifFormalDocumentUpload: {
                                                isFormalDoc: false,
                                                isExistingDocReplace: false
                                            },
                                            formalDocumentFields: undefined,
                                            ifFiledDocumentUpload: {
                                                isFiledDoc: false,
                                                isExistingDocReplace: false
                                            },
                                            filedDocumentFields: undefined,
                                            executeFormalDocumentFields: undefined
                                        }
                                    ],
                                    documentType: 0
                                }
                            ],
                            responseData: {
                                languageList: []
                            },
                            flags: {
                                isShowLandingPage: false,
                                isShowUploadDialog: false,
                                isShowGroupListing: false,
                                isSubmittingPopup: false,
                                isSubmittingGroupsList: false
                            }
                        },
                        selectedGroup: {
                            groupId: 0,
                            primaryId: 0,
                            tempNotes: '',
                            sourceLanguage: [],
                            targetLanguage: [],
                            documentList: [],
                            documentType: 0,
                            errors: {
                                isInvalidSL: false,
                                isInvalidTL: false,
                                isInvalidReference: false,
                                isInvalidSource: false
                            }
                        }
                    },
                    serviceTypePage: null,
                    companyDetailsPage: null,
                    additionalInfoPage: undefined,
                    patentDetailsPage: undefined,
                    selectCountryPage: null,
                    selectCountryPageForEP: null,
                    selectCountryPageEdit: null,
                    summaryPage: null,
                    languageSelectionPage: null,
                    upcOptOutPage: null
                },
                flags: {
                    storeUpdateWithSummaryData: null,
                    isCountriesSyncedCompletedInEditMode: false,
                    isSummaryPageTablesInlineEditInProgress: false,
                    pagesMatchStatusWithBackupData: {}
                },
                isFormValid: { value: false }
            });

            mockAuthStore.getUserInfo.mockReturnValue({
                userInfo: {
                    userId: 8,
                    roleId: 9,
                    permissions: [],
                    userFullName: '',
                    role: ''
                },
                authToken: '',
                expiresOn: 0,
                isAuthenticated: false
            });

            const result = await uploadAndLanguageSelectionService.stdSubmission();

            expect(mockHttpService.post).toHaveBeenCalledWith(
                '/standard-submission',
                expect.objectContaining({
                    patentCategoryId: 1,
                    patentServiceTypeId: 2,
                    companyId: 3,
                    contactUserId: 8,
                    contactEmail: '',
                    po: 'PO123',
                    deliverTo: null,
                    mailCC: 'cc@example.com',
                    assignPM: [6],
                    assignSalesRep: [7],
                    requestCurrencyId: 4,
                    isQuote: true,
                    quoteDetails: {
                        patentTitle: 'Test Patent',
                        requestedDeliveryDate: '2023-01-01',
                        quoteDatetime: '2023-01-02',
                        referenceNumber: 'REF123'
                    },
                    documents: [
                        {
                            sectionId: 1,
                            sourceLanguageIds: [1],
                            targetLanguageIds: [2],
                            saveDocuments: [
                                {
                                    fileName: 'file1',
                                    fileType: 'pdf',
                                    fileSize: '1024',
                                    blobFileName: 'blob1',
                                    documentType: 1,
                                    notes: 'notes',
                                    wordCount: 100,
                                    blobUrl: '',
                                    documentKey: '',
                                    extension: ''
                                }
                            ]
                        }
                    ]
                }),
                {},
                false,
                process.env.REACT_APP_QUOTE_BASE_URL
            );
            expect(result).toEqual(mockResponse);
        });

        it('should return null and log an error if an exception occurs', async () => {
            const mockError = new Error('Test error');
            mockHttpService.post.mockRejectedValue(mockError);

            const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

            const result = await uploadAndLanguageSelectionService.stdSubmission();

            expect(consoleErrorSpy).toHaveBeenCalledWith(
                'Error while saving language selection',
                mockError
            );
            expect(result).toBeNull();

            consoleErrorSpy.mockRestore();
        });
    });
});
