import { FC, useEffect, useState } from 'react';
import { t } from 'i18next';
import UploadDialogSTDTemplate from './uploadDialogSTDTemplate';
import { AllLanguageResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { FilePayload, TransformedObject } from 'components/fileUpload/types/fileUpload.types';
import standardModuleService, {
    HandleLanguageChangeModel
} from '../../languageSelection/services/standardModule.service';
import ConfirmationRedImage from 'assets/images/alert-red-icon.svg';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import {
    DocumentGroupModel,
    groupDataInit,
    SaveSTDDetailsPageFilesModel
} from '../types/uploadAndLanguageSelection.type';
import { STDDocumentData } from '../services/uploadAndLanguageSelection.service';

import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { DocumentGroup } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import uploadSTDDetailsPageService from '../services/uploadSTDDetailsPage.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { formatFileSize } from 'components/fileUpload/uploadingFileStatus/uploadingFileStatus';

interface UploadSTDDetailsPageModel {
    orderId: number;
    sectionId: number;
    responseData: { languageList: AllLanguageResponseType[]; documentList: DocumentGroup[] };
    setIsRenderUploadDialog: (isRenderUploadDialog: boolean) => void;
    toRefreshPage: {
        stdDetails: () => void;
        documentAndLanguageList: () => void;
    };
}
interface DetailsPageDataModel {
    flags: {
        isShowUploadDialog: boolean;
        isSubmittingPopup: boolean;
    };
}

// constants
const detailsPageDataInit: DetailsPageDataModel = {
    flags: {
        isShowUploadDialog: true,
        isSubmittingPopup: false
    }
};

const UploadSTDDetailsPage: FC<UploadSTDDetailsPageModel> = ({
    orderId,
    sectionId,
    responseData,
    setIsRenderUploadDialog,
    toRefreshPage
}) => {
    // if the sectionId is unavailable, then it’s an individual 'Add',
    // meaning a global 'Add' rather than a section-specific 'Add'.
    const isAddingFilesToExistingSection = !!sectionId;

    const getGroupInitData = () => {
        const selectedSection =
            responseData.documentList.find((doc) => doc.sectionId === sectionId) ?? null;
        if (selectedSection) {
            const sourceLanguage = selectedSection.sourceLanguageIds ?? [];
            const targetLanguage = selectedSection.targetLanguageIds ?? [];

            const updatedSelectedGroup = { ...groupDataInit, sourceLanguage, targetLanguage };
            return updatedSelectedGroup;
        }
    };
    const [selectedGroup, setSelectedGroup] = useState<DocumentGroupModel>(
        getGroupInitData() ?? groupDataInit
    );
    const [detailsPageData, setDetailsPageData] = useState<DetailsPageDataModel>({
        ...detailsPageDataInit
    });

    // functions
    const handleLanguageChange = (value: HandleLanguageChangeModel) => {
        try {
            const { fieldName, updatedLanguage } = value;
            const isProceedToUpdate = standardModuleService.validateLanguageSelection({
                ...value
            });

            if (!isProceedToUpdate) throw new Error('Language validation failed.');

            const updatedGroup = { ...selectedGroup, [fieldName]: updatedLanguage };
            setSelectedGroup(updatedGroup);
        } catch (error) {
            console.error(`Error in handleLanguageChange(): `, error);
        }
    };
    const onDialogClear = () => {
        setSelectedGroup({ ...groupDataInit });
    };
    const onDialogClose = () => {
        setDetailsPageData({
            flags: { ...detailsPageData.flags, isShowUploadDialog: false }
        });
        setSelectedGroup({ ...groupDataInit });
        setIsRenderUploadDialog(false);
    };
    const onDialogSubmitWrapper = () => {
        onDialogSubmit().catch((error) => {
            console.error('Error: ', error);
        });
    };
    const onDialogSubmit = async () => {
        try {
            setDetailsPageData({ flags: { ...detailsPageData.flags, isSubmittingPopup: true } });
            const validationResult = validateCurrentGroup();
            setSelectedGroup(validationResult.groups[0]);

            if (validationResult.isInvalid) {
                showToastMessage('Please fill in all mandatory fields.', ToastType.WARNING);
                console.error('Error: Validation failed to submit onDialogSubmit().');
            } else {
                const getDocumentList = () => {
                    const documentList: STDDocumentData[] = [];

                    const savedDocuments: STDDocumentData[] = selectedGroup.documentList?.map(
                        (file: FilePayload) => {
                            return {
                                fileName: file.name,
                                fileType: file.type,
                                fileSize: formatFileSize(file.size),
                                blobFileName: `${file.azureBlobFolderPath}/${file.azureBlobFileName}`,
                                documentType: file.documentType,
                                notes: file.fileNotes ?? '',
                                wordCount: file.wordCount ?? 0,
                                blobUrl: '',
                                documentKey: '',
                                extension: ''
                            };
                        }
                    );

                    savedDocuments.forEach((document) => {
                        documentList.push(document);
                    });
                    return documentList;
                };

                // api
                const payload: SaveSTDDetailsPageFilesModel = {
                    orderId,
                    documents: [
                        {
                            sectionId,
                            sourceLanguageIds: selectedGroup.sourceLanguage,
                            targetLanguageIds: selectedGroup.targetLanguage,
                            saveDocuments: getDocumentList()
                        }
                    ]
                };

                const response = await uploadSTDDetailsPageService.saveSTDDetailsPageFiles(payload);

                if (response) {
                    // reset popup
                    setDetailsPageData({
                        flags: {
                            ...detailsPageData.flags,
                            isSubmittingPopup: false,
                            isShowUploadDialog: false
                        }
                    });
                    setIsRenderUploadDialog(false);

                    // refresh details page
                    toRefreshPage.stdDetails();
                    toRefreshPage.documentAndLanguageList();
                    quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                    quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
                } else {
                    showToastMessage('Failed to save files.', ToastType.ERROR);
                }
            }
        } catch (error) {
            console.error(`Error in onDialogSubmit() in STD details page: ${error}`);
        }
    };
    const fileDelete = (fileUniqueId: number) => {
        const updatedDocumentList = selectedGroup.documentList.filter(
            (file) => file.fileUniqueId !== fileUniqueId
        );
        setSelectedGroup((prevState) => ({
            ...prevState,
            documentList: updatedDocumentList
        }));
    };
    const validateCurrentGroup = () => {
        const validationResult = standardModuleService.validateGroupsAndSetError(
            'single-group',
            [selectedGroup],
            isAddingFilesToExistingSection
        );
        return validationResult;
    };
    const storeFilesAgainstGroup = (files: TransformedObject[]) => {
        // constructed format to add the uploaded files to the respective group.
        const uploadedFilesGroup = standardModuleService.constructUploadedFIlesToAdd(files);

        if (detailsPageData.flags.isShowUploadDialog) {
            setSelectedGroup((prevState) => ({
                ...prevState,
                primaryId: uploadedFilesGroup.primaryId,
                documentList: standardModuleService.getFilesList(
                    prevState.documentList.length, // length of overall existing list.
                    // ### [...existingDocumentList, ...prevState.documentList].length, // length of overall existing list.
                    prevState.documentList, // existing list of current opened(selected) group.
                    uploadedFilesGroup.file, // newly added doct list to merge.
                    prevState.tempNotes
                )
            }));
        } else {
            // have to handle async ###
        }
    };

    // toast / popup
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };
    type PrimaryButtonLabel = 'Yes' | 'Close';
    type SecondaryButtonLabel = 'Cancel';
    interface PopupConfig {
        isShowPopup: boolean;
        header: JSX.Element | string;
        description: string;
        headerImage: string;
        primaryButtonLabel: PrimaryButtonLabel;
        secondaryButtonLabel: SecondaryButtonLabel;
        buttonsVisibility: {
            popupPrimaryButton: boolean;
            popupSecondaryButton: boolean;
        };
        holdInfoToProceed?: {
            selectedFileId: string | number;
        } | null;
    }
    const popupConfigInit: PopupConfig = {
        isShowPopup: false,
        header: t('COMMON.CONFIRMATION'),
        description: 'Are you sure you want to delete this document?',
        headerImage: ConfirmationRedImage,
        primaryButtonLabel: 'Yes',
        secondaryButtonLabel: 'Cancel',
        buttonsVisibility: {
            popupPrimaryButton: true,
            popupSecondaryButton: true
        }
    };
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);
    const triggerPopup = (data: PopupConfig['holdInfoToProceed']) => {
        setPopupConfig({ ...popupConfig, isShowPopup: true, holdInfoToProceed: data ?? null });
    };
    const resetPopupConfig = () => setPopupConfig(popupConfigInit);
    const handlerPopupPrimaryButtonClick = () => {
        const selectedFileToDelete = popupConfig.holdInfoToProceed?.selectedFileId ?? null;

        if (selectedFileToDelete) {
            fileDelete(+selectedFileToDelete);
            resetPopupConfig();
        } else {
            console.error('Error: selectedFileId is not found to remove the file.');
        }
    };

    // side effects
    useEffect(() => {
        const validationResult = validateCurrentGroup();
        setSelectedGroup(validationResult.groups[0]);
    }, [selectedGroup.sourceLanguage, selectedGroup.targetLanguage, selectedGroup.documentList]);

    return (
        <>
            {popupConfig.isShowPopup && (
                <ConfirmationPopup
                    popupID="popup-std-confirmation"
                    data-testid="popup-std-confirmation"
                    image={popupConfig.headerImage}
                    visible={popupConfig.isShowPopup}
                    headerText={popupConfig.header}
                    description={popupConfig.description}
                    acceptLabel={popupConfig.primaryButtonLabel}
                    rejectLabel={popupConfig.secondaryButtonLabel}
                    isShowAcceptButton={popupConfig.buttonsVisibility.popupPrimaryButton}
                    isShowRejectButton={popupConfig.buttonsVisibility.popupSecondaryButton}
                    onConfirm={handlerPopupPrimaryButtonClick}
                    onCancel={resetPopupConfig}
                />
            )}
            <UploadDialogSTDTemplate
                languageList={responseData.languageList}
                selectedGroup={selectedGroup}
                actions={{
                    setSelectedGroup(group: DocumentGroupModel) {
                        setSelectedGroup(group);
                    },
                    onDialogClear: () => onDialogClear(),
                    onDialogClose: () => onDialogClose(),
                    onDialogSubmit: () => onDialogSubmitWrapper(),
                    onFileDelete: (selectedFileId: string | number) =>
                        triggerPopup({ selectedFileId }),
                    onLanguageChange(value) {
                        handleLanguageChange({
                            group: selectedGroup,
                            fieldName: value.fieldName,
                            updatedLanguage: value.updatedLanguage
                        });
                    },
                    handleUploadFiles(files: TransformedObject[]) {
                        storeFilesAgainstGroup(files);
                    }
                }}
                flags={{
                    isDialogShow: detailsPageData.flags.isShowUploadDialog,
                    isInvalidSL:
                        detailsPageData.flags.isSubmittingPopup && selectedGroup.errors.isInvalidSL,
                    isInvalidTL:
                        detailsPageData.flags.isSubmittingPopup && selectedGroup.errors.isInvalidTL,
                    isInvalidFiles:
                        detailsPageData.flags.isSubmittingPopup &&
                        selectedGroup.errors.isInvalidSource,
                    errorMsgForFiles: isAddingFilesToExistingSection
                        ? 'Uploading a document is mandatory'
                        : 'Uploading a source document is mandatory.',
                    isDisableLanguages:
                        isAddingFilesToExistingSection &&
                        selectedGroup.sourceLanguage.length !== 0 &&
                        selectedGroup.targetLanguage.length !== 0
                }}
            />
        </>
    );
};

export default UploadSTDDetailsPage;
