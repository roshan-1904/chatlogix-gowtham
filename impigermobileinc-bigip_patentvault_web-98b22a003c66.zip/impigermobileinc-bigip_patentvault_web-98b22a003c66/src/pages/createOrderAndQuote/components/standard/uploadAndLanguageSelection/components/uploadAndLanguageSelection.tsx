import { useCallback, useEffect, useState } from 'react';

import { LandingPage } from './landingPage';
import { UploadSTDCreatePage } from './uploadSTDCreatePage';
import GroupListingPage from './groupListingPage';

import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import uploadAndLanguageSelectionService from '../services/uploadAndLanguageSelection.service';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';

import {
    AllLanguageResponse,
    AllLanguageResponseType
} from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import { TransformedObject } from 'components/fileUpload/types/fileUpload.types';
import stdConstants from '../../constants/standard.constant';
import standardModuleService, {
    HandleLanguageChangeModel
} from '../../languageSelection/services/standardModule.service';
import {
    DocumentGroupModel,
    GroupCRUDActivityTypes,
    groupDataInit,
    GroupedResultModel,
    PageVisibilityTypes,
    STDPageDataModel
} from '../types/uploadAndLanguageSelection.type';
import { MODE } from 'constants/app.constant';

export interface STDFunctionsModel {
    updatePageData: <T extends keyof STDPageDataModel>(key: T, value: STDPageDataModel[T]) => void;
    groupCreate: () => void;
    groupUpdate: (modifiedGroup: DocumentGroupModel | null, page: GroupCRUDActivityTypes) => void;
    groupDelete: (modifiedGroup: DocumentGroupModel) => void;
    groupSelect: (modifiedGroup: DocumentGroupModel) => void;
    fileDelete: (
        deletedFrom: 'popup' | 'listing-action',
        groupId: number,
        fileUniqueId: number
    ) => void;
    handlePageVisibility: (action: PageVisibilityTypes, groups?: DocumentGroupModel[]) => void;
    handleLanguageChange: (params: HandleLanguageChangeModel) => void;
    storeFilesAgainstGroup: (files: TransformedObject[]) => void;
}
const stdFunctionsInit: STDFunctionsModel = {
    updatePageData() {},
    groupCreate() {},
    groupUpdate() {},
    groupDelete() {},
    groupSelect() {},
    fileDelete() {},
    handlePageVisibility() {},
    handleLanguageChange() {},
    storeFilesAgainstGroup() {}
};
const PageDataInit: STDPageDataModel = {
    responseData: { languageList: [] },
    flags: {
        isShowLandingPage: false,
        isShowUploadDialog: false,
        isShowGroupListing: false,
        isSubmittingPopup: false,
        isSubmittingGroupsList: false
    },
    groups: [{ ...groupDataInit }]
};

const UploadAndLanguageSelection = () => {
    const [pageData, setPageData] = useState<STDPageDataModel>(PageDataInit); // this is all-in-one state (mostly)
    const [stdFunctions, setSTDFunctions] = useState<STDFunctionsModel>(stdFunctionsInit);
    const [selectedGroup, setSelectedGroup] = useState<DocumentGroupModel>({
        ...groupDataInit
    });
    const [isInitialPageLoadCompleted, setIsInitialPageLoadCompleted] = useState(false); // to prevent the data loss in initial page navigation

    // api
    const getLanguageList = async () => {
        try {
            const requestBodySorting = { propertyName: 'id', value: 'asc' };
            const response: AllLanguageResponse =
                await PVSettingsService.getAllLanguages(requestBodySorting);

            if (response?.data) {
                const languageList: AllLanguageResponseType[] = response.data;
                updatePageData('responseData', { ...pageData.responseData, languageList });
            }
        } catch (error) {
            console.error(`Error in 'getSourceLanguages()':`, error);
            return null;
        }
    };

    // handlers
    const updatePageData = useCallback(
        <T extends keyof STDPageDataModel>(key: T, value: STDPageDataModel[T]) => {
            // this is all-in-one state
            setPageData((prevState) => ({
                ...prevState,
                [key]: value
            }));
        },
        []
    );
    const groupCreate = () => {
        // adding a new group to the list
        const newGroup: DocumentGroupModel = {
            ...groupDataInit,
            groupId: pageData.groups.length + 1
        };
        return newGroup;
    };
    const groupUpdate = (
        modifiedGroup: DocumentGroupModel | null,
        page: GroupCRUDActivityTypes
    ) => {
        if (page === 'landing-page-add') {
            handlePageVisibility('landing-page-add');

            /** create a new group and set it to the 'selectedGroup' state when the user clicks 'Add Document' on the landing page. 
            coz, after the 'Add Document' click, a popup will open and render the state which is stored in 'selectedGroup'. 
            this is because, user may cancel the popup, so we don't update the original state until the user clicks 'Add' in the popup. */
            /** and if the default-group already available then skip these all the processes. 
            coz, initially first time we added default group and also set to the 'selectedGroup'. */
            const { isDefaultGroupOnlyExists } = getActiveGroupInfo();
            if (!isDefaultGroupOnlyExists) {
                const newGroup = groupCreate();
                setSelectedGroup(newGroup);
            }
        } else if (page === 'upload-dialog-add' && modifiedGroup) {
            const existingGroup =
                pageData.groups.find((group) => group.groupId === modifiedGroup.groupId) ?? null;
            const existingDocumentList = existingGroup?.documentList ?? [];

            /** we don't show the existing doct list to the popup when the group is selected to modify.
                so, we need to merge the existing document list with the new document list on the 'modifiedGroup'. */
            modifiedGroup.documentList.push(...existingDocumentList);
            modifiedGroup.tempNotes = '';

            const latestGroup = findAndReplaceGroup(pageData, modifiedGroup);
            handlePageVisibility(page, latestGroup);
        } else if (page === 'group-listing-change' && modifiedGroup) {
            const latestGroup = findAndReplaceGroup(pageData, modifiedGroup);
            handlePageVisibility('stay-on-page', latestGroup); // not need to navigate when user update the group on listing page

            // validate and update the listing page error on field change, when submission in progress ('isSubmittingGroupsList').
            if (pageData.flags.isSubmittingGroupsList) {
                const validationResult = standardModuleService.validateGroupsAndSetError(
                    'multiple-groups',
                    latestGroup
                );

                updatePageData('groups', validationResult.groups);
            }
        } else if (page === 'group-listing-add') {
            handlePageVisibility('group-listing-add');
            const newGroup = groupCreate();
            setSelectedGroup(newGroup);

            // validate and update the listing page error on field change, when submission in progress ('isSubmittingGroupsList').
            if (pageData.flags.isSubmittingGroupsList) {
                const validationResult = standardModuleService.validateGroupsAndSetError(
                    'multiple-groups',
                    pageData.groups
                );

                updatePageData('groups', validationResult.groups);
            }
        }
    };
    const groupDelete = (modifiedGroup: DocumentGroupModel) => {
        const latestGroup = findAndReplaceGroup(pageData, modifiedGroup);
        handlePageVisibility('group-listing-delete', latestGroup);
    };
    const groupSelect = (modifiedGroup: DocumentGroupModel) => {
        // selected group from the 'group-listing' page via '+Add' button.
        setSelectedGroup({ ...modifiedGroup, documentList: [] }); // we do not need to take the existing document to the popup.
        handlePageVisibility('group-listing-select');
    };
    const fileDelete = (
        deletedFrom: 'popup' | 'listing-action',
        groupId: number,
        fileUniqueId: number
    ) => {
        try {
            const existingGroups = [...pageData.groups];
            const modifiedGroup = existingGroups.find((group) => group.groupId === groupId);
            if (deletedFrom === 'listing-action' && modifiedGroup) {
                const updatedDocumentList = modifiedGroup.documentList.filter(
                    (file) => file.fileUniqueId !== fileUniqueId
                );
                modifiedGroup.documentList = updatedDocumentList;

                // update the group with the modified document list
                findAndReplaceGroup(pageData, modifiedGroup);
            } else if (deletedFrom === 'popup') {
                const updatedDocumentList = selectedGroup.documentList.filter(
                    (file) => file.fileUniqueId !== fileUniqueId
                );
                setSelectedGroup((prevState) => ({
                    ...prevState,
                    documentList: updatedDocumentList
                }));
            } else {
                throw new Error('Group not found to delete the file.');
            }
        } catch (error) {
            console.error(`Error in 'fileDelete()':`, error);
            return null;
        }
    };
    const handleLanguageChange = (params: HandleLanguageChangeModel) => {
        try {
            const { group, fieldName, updatedLanguage, isStoreAsTempData } = params;
            const isProceedToUpdate = standardModuleService.validateLanguageSelection(params);

            if (!isProceedToUpdate) throw new Error('Language validation failed.');

            const updatedGroup = { ...group, [fieldName]: updatedLanguage };
            if (isStoreAsTempData) {
                // in this scenario, popup is in open state, so store the data in 'selectedGroup' state.
                setSelectedGroup(updatedGroup);
            } else {
                // in this scenario, we can modify the original 'pageData' state.
                groupUpdate(updatedGroup, 'group-listing-change');
            }
        } catch (error) {
            console.error(`Error in 'handleLanguageChange()':`, error);
            return null;
        }
    };
    const storeFilesAgainstGroup = (files: TransformedObject[]) => {
        try {
            // constructed format to add the uploaded files to the respective group.
            const uploadedFilesGroup = standardModuleService.constructUploadedFIlesToAdd(files);

            // Note:
            // scenario 1: update 'selectedGroup', if the user still in the same 'upload-popup'.
            // scenario 2: find & update the respective group, if user closed the 'upload-popup'.
            // scenario 3: show the toast message, if the group is deleted while background uploading.

            // due to some slowness of 'pageData'(local-state), we are using 'store' to get the latest page data.
            const formData =
                quoteOrderModuleStore.getData().formData.uploadAndLanguageSelectionPage;
            const updatedPageData = formData?.pageData;
            const updatedFlags = formData?.pageData.flags;
            const updatedGroups = formData?.pageData.groups ?? null;
            const updatedSelectedGroup = formData?.selectedGroup;

            // scenario 1
            if (
                updatedFlags?.isShowUploadDialog &&
                updatedSelectedGroup?.groupId === uploadedFilesGroup.stdGroupId
            ) {
                addFilesToCurrentGroup(uploadedFilesGroup);
            }
            // scenario 2
            else if (updatedPageData && updatedGroups) {
                addFilesToGroup(uploadedFilesGroup, updatedPageData, updatedGroups);
            }
        } catch (error) {
            console.error(`Error in 'storeFilesAgainstGroup()':`, error);
            return null;
        }
    };
    const addFilesToCurrentGroup = (uploadedFilesGroup: GroupedResultModel) => {
        const existingGroup =
            pageData.groups.find((group) => group.groupId === selectedGroup.groupId) ?? null;
        const existingDocumentList = existingGroup?.documentList ?? [];

        setSelectedGroup((prevState) => ({
            ...prevState,
            primaryId: uploadedFilesGroup.primaryId,
            documentList: standardModuleService.getFilesList(
                [...existingDocumentList, ...prevState.documentList].length, // length of overall existing list.
                prevState.documentList, // existing list of current opened(selected) group.
                uploadedFilesGroup.file, // newly added doct list to merge.
                prevState.tempNotes
            )
        }));
    };
    const addFilesToGroup = (
        uploadedFilesGroup: GroupedResultModel,
        updatedPageData: STDPageDataModel,
        updatedGroups: DocumentGroupModel[]
    ) => {
        const updatedUploadedFilesGroupId =
            uploadedFilesGroup.stdGroupId === 0 ? 1 : uploadedFilesGroup.stdGroupId;
        const updatedGroup = updatedGroups
            ? updatedGroups.find((group) => group.groupId === updatedUploadedFilesGroupId)
            : null;
        const isGroupAliveToUpdate = updatedGroup && !updatedGroup.isGroupInActive;

        if (isGroupAliveToUpdate) {
            const filesList = standardModuleService.getFilesList(
                updatedGroup.documentList.length,
                updatedGroup.documentList,
                uploadedFilesGroup.file,
                uploadedFilesGroup.notesForUploadedFiles
            );
            updatedGroup.primaryId = uploadedFilesGroup.primaryId;
            updatedGroup.documentList = filesList;

            if (updatedPageData) {
                const latestGroup = findAndReplaceGroup(updatedPageData, updatedGroup);
                handlePageVisibility('upload-dialog-add', latestGroup);
            }
        } else {
            // scenario 3
            showToastMessage(
                'Oops! File uploaded successfully, but the combination is not available for update.',
                ToastType.WARNING
            );
            throw new Error('The group is not found to merge the uploaded documents.');
        }
    };
    const findAndReplaceGroup = (
        updatedPageData: STDPageDataModel,
        updatedGroup: DocumentGroupModel
    ) => {
        try {
            /** this field is to show/hide the group fields, which are only displayed during the first creation.
                this field will be null for the first creation. */
            updatedGroup.groupUpdatedLastAt = new Date().toISOString();

            const existingGroupsToModify = [...updatedPageData.groups]; // take a copy of groups
            const { isDefaultGroupOnlyExists } = getActiveGroupInfo();

            // find the modified group index in the groupsList to replace with existing.
            const modifiedGroupIndex = existingGroupsToModify.findIndex(
                (group) => group.groupId === updatedGroup.groupId
            );

            // if the group is the default one, update the groupId to 1. (only initial time)
            if (updatedGroup.groupId === 0 && isDefaultGroupOnlyExists) {
                updatedGroup.groupId = 1;
            }

            // && JSON.stringify(updatedGroup) !== JSON.stringify(selectedGroup);

            const canReplaceGroup = modifiedGroupIndex !== -1;
            if (canReplaceGroup) {
                // replace the modified group with matched existing group.
                existingGroupsToModify[modifiedGroupIndex] = updatedGroup;
            } else if (updatedGroup.groupId) {
                // add the new group to the list if it's not in the list to replace.
                existingGroupsToModify.push(updatedGroup);
            }

            updatePageData('groups', existingGroupsToModify);

            /** this will return the latest state instance before the state is updated. */
            return existingGroupsToModify;
        } catch (error) {
            console.error(`Error in 'findAndReplaceGroup()':`, error);
            return [];
        }
    };
    const handlePageVisibility = (action: PageVisibilityTypes, groups?: DocumentGroupModel[]) => {
        const { isDefaultGroupOnlyExists, isAllGroupsDeleted } = getActiveGroupInfo(groups);

        switch (action) {
            case 'landing-page-add': {
                updatePageData('flags', {
                    ...pageData.flags,
                    isShowLandingPage: isDefaultGroupOnlyExists || isAllGroupsDeleted,
                    isShowUploadDialog: true,
                    isShowGroupListing: !isDefaultGroupOnlyExists && !isAllGroupsDeleted
                });
                break;
            }
            case 'group-listing-add':
            case 'group-listing-select': {
                updatePageData('flags', {
                    ...pageData.flags,
                    isShowUploadDialog: true,

                    // user started to interact. so, clear the submission flag to hide the error.
                    isSubmittingPopup: false,
                    isSubmittingGroupsList: false
                });
                break;
            }
            case 'upload-dialog-add': {
                setSelectedGroup({ ...groupDataInit }); // reset the 'selectedGroup' state
                updatePageData('flags', {
                    ...pageData.flags,
                    isShowLandingPage: isDefaultGroupOnlyExists || isAllGroupsDeleted,
                    isShowUploadDialog: false,
                    isShowGroupListing: !isDefaultGroupOnlyExists && !isAllGroupsDeleted,

                    // user started to interact. so, clear the submission flag to hide the error.
                    isSubmittingPopup: false,
                    isSubmittingGroupsList: false
                });
                break;
            }
            case 'group-listing-delete': {
                updatePageData('flags', {
                    ...pageData.flags,
                    isShowLandingPage: isDefaultGroupOnlyExists || isAllGroupsDeleted,
                    isShowUploadDialog: false,
                    isShowGroupListing: !isDefaultGroupOnlyExists && !isAllGroupsDeleted
                });
                break;
            }
            case 'upload-dialog-close': {
                setSelectedGroup({ ...groupDataInit }); // reset the 'selectedGroup' state
                updatePageData('flags', {
                    ...pageData.flags,
                    isShowUploadDialog: false,

                    // clear the submission flag while closing the popup.
                    isSubmittingPopup: false,
                    isSubmittingGroupsList: false
                });
                break;
            }
            case 'upload-dialog-clear': {
                setSelectedGroup({ ...groupDataInit }); // reset the 'selectedGroup' state
                updatePageData('flags', {
                    ...pageData.flags,

                    // clear the submission flag while closing the popup.
                    isSubmittingPopup: false,
                    isSubmittingGroupsList: false
                });
                break;
            }
            default:
                break;
        }
    };

    // helper functions
    const isAllGroupsInActive = (groups?: DocumentGroupModel[]) => {
        const isAllGroupsDeleted = (groups ?? pageData.groups).every(
            (group) => group.isGroupInActive
        );
        return isAllGroupsDeleted;
    };
    const isListPageOnlyHasDefaultGroup = (groups?: DocumentGroupModel[]) => {
        const isDefaultGroupOnlyExists =
            (groups ?? pageData.groups).length === 1 &&
            (groups ?? pageData.groups)[0].groupId === 0;
        return isDefaultGroupOnlyExists;
    };
    const getActiveGroupInfo = (groups?: DocumentGroupModel[]) => {
        const isDefaultGroupOnlyExists = isListPageOnlyHasDefaultGroup(groups);
        const isAllGroupsDeleted = isAllGroupsInActive(groups);

        return { isDefaultGroupOnlyExists, isAllGroupsDeleted };
    };
    const validateAndGetConfirmationBeforeSubmit = () => {
        // error will shows only when listing page submission is in progress ('isSubmittingGroupsList').
        updatePageData('flags', { ...pageData.flags, isSubmittingGroupsList: true });

        const validationResult = standardModuleService.validateGroupsAndSetError(
            'multiple-groups',
            pageData.groups
        );
        updatePageData('groups', validationResult.groups);

        if (validationResult.isInvalid) {
            showToastMessage('Please fill in all mandatory fields.', ToastType.WARNING);
            return;
        }

        quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', {
            action: 'approve'
        });
    };
    const handleSubmission = () => {
        const isQuote = quoteOrderModuleStore.getData().info.mode === MODE.CREATE_QUOTE;
        const successMsg = isQuote
            ? 'Quote requested successfully.'
            : 'Order created successfully.';

        // submission API
        uploadAndLanguageSelectionService
            .stdSubmission()
            .then((response: { id: number; requestNumber: number } | null) => {
                if (response?.requestNumber) {
                    showToastMessage(successMsg, ToastType.SUCCESS);
                    quoteOrderModuleStore.invokeFunction('STDFinalPagePopupTrigger', {
                        action: 'approve',
                        requestId: response?.id,
                        requestNumber: response?.requestNumber,
                        isActionResolved: true
                    }); // to trigger popup (for completion)
                }
            })
            .catch((error) => {
                console.error(`Error in 'handleSubmission()':`, error);
            });
    };

    // toast / popup
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    // side effects
    const initPageSetup = () => {
        const quoteOrderData = quoteOrderModuleStore.getData();
        // get the data from the store if already exists otherwise call the API.
        const uploadAndLanguageSelectionPageData =
            quoteOrderData.formData.uploadAndLanguageSelectionPage ?? null;

        if (uploadAndLanguageSelectionPageData) {
            setPageData(uploadAndLanguageSelectionPageData.pageData ?? { ...PageDataInit });

            setSelectedGroup(
                uploadAndLanguageSelectionPageData.selectedGroup ?? { ...groupDataInit }
            );
            setIsInitialPageLoadCompleted(true);
        } else {
            getLanguageList();
            updatePageData('flags', { ...pageData.flags, isShowLandingPage: true });
            setIsInitialPageLoadCompleted(true);
        }
    };
    const registerFunctionsToStore = () => {
        /** register the functions on store while trigger the action buttons from footer component. */
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.APPROVE,
            handleSubmission
        );
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.CONFIRM_B4_SUBMIT,
            validateAndGetConfirmationBeforeSubmit
        );
    };
    const resetRegisteredFunctionsOnStore = () => {
        /** remove the registered function on store to avoid unwanted calls. */
        quoteOrderModuleStore.registerFunction(stdConstants.STD_STEPPER_ACTIONS.APPROVE, () => {});
        quoteOrderModuleStore.registerFunction(
            stdConstants.STD_STEPPER_ACTIONS.CONFIRM_B4_SUBMIT,
            () => {}
        );
    };
    const updateFormData = () => {
        // save data in the store to prevent data loss in page navigation
        const quoteOrderData = quoteOrderModuleStore.getData();
        const updatedQuoteOrderFormData = {
            ...quoteOrderData.formData,
            uploadAndLanguageSelectionPage: { pageData, selectedGroup }
        };

        // compare and update the store if the data is updated
        if (
            JSON.stringify(quoteOrderData.formData.uploadAndLanguageSelectionPage) !==
            JSON.stringify(pageData)
        ) {
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    };
    const savePageFunctions = () => {
        setSTDFunctions({
            updatePageData: (key, value) => updatePageData(key, value),
            groupCreate: () => groupCreate(),
            groupUpdate: (modifiedGroup, page) => groupUpdate(modifiedGroup, page),
            groupDelete: (modifiedGroup) => groupDelete(modifiedGroup),
            groupSelect: (modifiedGroup) => groupSelect(modifiedGroup),
            fileDelete: (deletedFrom, groupId, fileUniqueId) =>
                fileDelete(deletedFrom, groupId, fileUniqueId),
            handlePageVisibility: (action, groups) => handlePageVisibility(action, groups),
            handleLanguageChange: (params) => handleLanguageChange(params),
            storeFilesAgainstGroup: (files) => storeFilesAgainstGroup(files)
        });
    };
    useEffect(() => {
        initPageSetup();
    }, []);
    useEffect(() => {
        isInitialPageLoadCompleted && updateFormData();
    }, [pageData]);
    useEffect(() => {
        // functions register
        /** Note: We store functions in one place to reduce 'params' and 'boilerplate' code.
         *  In this scenario, if the function contains any local state, we should re-register the function whenever that state gets updated.
         *  Otherwise, the function will retain the old state value from the time of registration. */
        savePageFunctions(); // save on local state to use locally
        registerFunctionsToStore(); // save on store to use globally
        return () => {
            // deregister on store
            resetRegisteredFunctionsOnStore();
        };
    }, [pageData.groups, selectedGroup]);

    // components
    const getComponent = (component: 'upload-dialog' | 'landing-page' | 'group-listing') => {
        switch (component) {
            case 'upload-dialog':
                return (
                    <UploadSTDCreatePage
                        responseData={pageData.responseData}
                        selectedGroup={selectedGroup}
                        setSelectedGroup={setSelectedGroup}
                        groups={pageData.groups}
                        flags={pageData.flags}
                        stdFunctions={stdFunctions}
                    />
                );
            case 'landing-page':
                return (
                    <LandingPage
                        flags={pageData.flags}
                        selectedGroup={selectedGroup}
                        stdFunctions={stdFunctions}
                    />
                );
            case 'group-listing':
                return (
                    <GroupListingPage
                        responseData={pageData.responseData}
                        groups={pageData.groups}
                        flags={pageData.flags}
                        stdFunctions={stdFunctions}
                    />
                );
            default:
                return <></>;
        }
    };

    return (
        <>
            {/* STD landing page */}
            {pageData.flags.isShowLandingPage && getComponent('landing-page')}
            {/* STD dialog box to upload */}
            {pageData.flags.isShowUploadDialog && getComponent('upload-dialog')}
            {/* STD group listing page */}
            {pageData.flags.isShowGroupListing && getComponent('group-listing')}
        </>
    );
};

export default UploadAndLanguageSelection;
