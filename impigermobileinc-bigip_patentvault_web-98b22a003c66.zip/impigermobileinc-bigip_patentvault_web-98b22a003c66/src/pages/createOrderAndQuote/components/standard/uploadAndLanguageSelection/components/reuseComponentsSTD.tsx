import WarningLabel from 'components/reuseComponents/warningLabel';

interface STDHeaderLabelAndWarningModal {
    headerName: string;
    content?: { warning?: string; error?: string };
    className?: { wrapper?: string; header?: string; warning?: string };
    visibility?: { isShowWarning?: boolean; isShowErrorTemplate?: boolean };
    testId: string;
}
const STDHeaderLabelAndWarning = ({
    headerName,
    content,
    className,
    visibility,
    testId
}: STDHeaderLabelAndWarningModal) => {
    return (
        <div
            data-testid={testId}
            className={`${className?.wrapper ?? ''} flex items-center justify-start gap-5`}>
            {/* title */}
            <h4 className={`${className?.header ?? ''} font-medium`}>{headerName}</h4>
            {/* warning msg */}
            {visibility?.isShowWarning && (
                <WarningLabel
                    content={content?.error ?? ''}
                    className={{ wrapperContent: className?.warning }}
                />
            )}
            {visibility?.isShowErrorTemplate && (
                <div className="flex gap-1 items-center justify-center text-secondary font-medium">
                    <i className="pi pi-exclamation-triangle text-sm" />
                    <p>{content?.warning ?? 'Something went wrong.'}</p>
                </div>
            )}
        </div>
    );
};

const ReuseSTD = { STDHeaderLabelAndWarning };
export default ReuseSTD;
