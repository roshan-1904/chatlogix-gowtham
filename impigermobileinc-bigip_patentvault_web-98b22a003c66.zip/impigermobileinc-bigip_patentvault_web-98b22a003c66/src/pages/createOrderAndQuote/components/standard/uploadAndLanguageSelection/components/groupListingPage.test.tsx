import { render, screen, fireEvent } from '@testing-library/react';
import GroupListingPage from './groupListingPage';
import { DocumentGroupModel } from '../types/uploadAndLanguageSelection.type';

describe('GroupListingPage', () => {
    const mockAction = {
        updatePageData: jest.fn(),
        groupCreate: jest.fn(),
        groupUpdate: jest.fn(),
        groupDelete: jest.fn(),
        groupSelect: jest.fn(),
        fileDelete: jest.fn(),
        handleLanguageChange: jest.fn()
    };

    const mockStdFunctions = {
        updatePageData: jest.fn(),
        groupCreate: jest.fn(),
        groupUpdate: jest.fn(),
        groupDelete: jest.fn(),
        groupSelect: jest.fn(),
        fileDelete: jest.fn(),
        handlePageVisibility: jest.fn(),
        handleLanguageChange: jest.fn(),
        storeFilesAgainstGroup: jest.fn(),
        validateGroupsAndSetError: jest.fn()
    };

    const mockGroups: DocumentGroupModel[] = [
        {
            groupId: 1,
            isGroupInActive: false,
            sourceLanguage: [],
            targetLanguage: [],
            documentList: [
                {
                    fileUniqueId: 1,
                    name: 'Document 1',
                    wordCount: 100,
                    fileNotes: '',
                    documentType: 1,
                    size: 1024,
                    type: 'application/pdf',
                    progress: '100',
                    file: new File([''], 'Document 1.pdf', { type: 'application/pdf' }),
                    azureBlobFolderPath: '',
                    azureBlobFileName: '',
                    moduleName: '',
                    ifFormalDocumentUpload: { isFormalDoc: false, isExistingDocReplace: false },
                    formalDocumentFields: null,
                    ifFiledDocumentUpload: { isFiledDoc: false, isExistingDocReplace: false },
                    filedDocumentFields: null,
                    executeFormalDocumentFields: null
                }
            ],
            primaryId: 0,
            tempNotes: '',
            documentType: 0,
            errors: {
                isInvalidSL: false,
                isInvalidTL: false,
                isInvalidReference: false,
                isInvalidSource: false
            }
        }
    ];

    const mockResponseData = {
        languageList: [
            { id: 1, name: 'English', isocode: 'en', abbreviation: 'ENG' },
            { id: 2, name: 'Spanish', isocode: 'es', abbreviation: 'SPA' }
        ]
    };

    const mockFlags = {
        isShowLandingPage: false,
        isShowUploadDialog: false,
        isShowGroupListing: true,
        isSubmittingPopup: false,
        isSubmittingGroupsList: false
    };

    it('renders the group listing page with header and add button', () => {
        render(
            <GroupListingPage
                responseData={mockResponseData}
                groups={mockGroups}
                flags={mockFlags}
                stdFunctions={mockStdFunctions}
            />
        );

        expect(screen.getByTestId('std-group-listing-page')).toBeInTheDocument();
        expect(screen.getByText('Add Document & Language')).toBeInTheDocument();
    });

    it('calls groupUpdate when the add button is clicked', () => {
        render(
            <GroupListingPage
                responseData={mockResponseData}
                groups={mockGroups}
                flags={mockFlags}
                stdFunctions={mockStdFunctions}
            />
        );

        const addButton = screen.getByTestId('std-group-listing-add-button');
        fireEvent.click(addButton);

        expect(mockAction.groupUpdate).toHaveBeenCalledWith(null, 'group-listing-add');
    });

    it('renders group listing templates for active groups', () => {
        render(
            <GroupListingPage
                responseData={mockResponseData}
                groups={mockGroups}
                flags={mockFlags}
                stdFunctions={mockStdFunctions}
            />
        );

        expect(screen.getByText('Uploaded Documents (1)')).toBeInTheDocument();
    });

    it('calls groupDelete when the delete icon is clicked', () => {
        render(
            <GroupListingPage
                responseData={mockResponseData}
                groups={mockGroups}
                flags={mockFlags}
                stdFunctions={mockStdFunctions}
            />
        );

        const deleteIcon = screen.getByRole('button', { name: /pi-times/i });
        fireEvent.click(deleteIcon);

        expect(mockAction.groupDelete).toHaveBeenCalledWith({
            ...mockGroups[0],
            isGroupInActive: true
        });
    });

    it('renders dropdowns for source and target languages', () => {
        render(
            <GroupListingPage
                responseData={mockResponseData}
                groups={mockGroups}
                flags={mockFlags}
                stdFunctions={mockStdFunctions}
            />
        );

        expect(screen.getByLabelText('Source Language')).toBeInTheDocument();
        expect(screen.getByLabelText('Target Language')).toBeInTheDocument();
    });
});
