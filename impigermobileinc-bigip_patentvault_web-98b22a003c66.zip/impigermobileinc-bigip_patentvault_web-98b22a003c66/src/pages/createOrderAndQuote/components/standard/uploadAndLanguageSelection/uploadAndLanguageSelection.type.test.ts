import { Test } from './uploadAndLanguageSelection.type';

describe('Test Interface', () => {
    it('should be defined', () => {
        const testInstance: Test = {};
        expect(testInstance).toBeDefined();
    });
});
