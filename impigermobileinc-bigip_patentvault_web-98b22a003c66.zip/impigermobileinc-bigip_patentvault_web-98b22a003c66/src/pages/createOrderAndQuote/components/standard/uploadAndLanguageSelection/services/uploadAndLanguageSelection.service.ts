import { FilePayload } from 'components/fileUpload/types/fileUpload.types';
import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import AuthStore from 'core/store/authStore/authStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { formatDateYYMMDD, isContactUser } from 'core/utils/utils';
import { DocumentGroupModel } from '../types/uploadAndLanguageSelection.type';
import { formatFileSize } from 'components/fileUpload/uploadingFileStatus/uploadingFileStatus';

interface QuoteDetails {
    patentTitle: string;
    requestedDeliveryDate: string | null;
    // quoteDatetime: string | null;
    referenceNumber: string;
}
export interface STDDocumentData {
    fileName: string;
    fileType: string;
    fileSize: string;
    blobFileName: string;
    documentType: number;
    blobUrl: string; // optional
    documentKey: string; // optional
    extension: string; // optional

    // std fields
    notes: string | null;
    wordCount: number;
}
export interface STDDocumentSectionData {
    sectionId: number;
    sourceLanguageIds: number[];
    targetLanguageIds: number[];
    saveDocuments: STDDocumentData[];
}
interface STDUploadAndSelectionPayload {
    patentCategoryId: number;
    patentServiceTypeId: number;
    companyId: number;
    contactUserId: number;
    contactEmail: string;
    po: string;
    deliverTo: string;
    mailCC: string;
    assignPM: number[];
    assignSalesRep: number[];
    requestCurrencyId: number;
    requestTypeId: number;
    instructionsByContactUser: string;
    instructionsByProjectManager: string;
    isQuote: boolean;
    quoteDetails: QuoteDetails;
    documents: STDDocumentSectionData[];
    orderRequestReferenceNo: number;
    turnAroundTime: string | null;
}

// variables
const httpService = new HttpService();
const baseURL: string | null = process.env.REACT_APP_QUOTE_BASE_URL ?? null;
if (!baseURL)
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');

// helpers
const getInfo = () => {
    const quoteOrderData = quoteOrderModuleStore.getData();
    const info = quoteOrderData.info;
    const loggedInUser = AuthStore.getUserInfo()?.userInfo;
    const loggedInUserRole = AuthStore.getUserInfo()?.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRole);
    const selectedCategory = quoteOrderData?.info?.selectedCategory;
    const oqDetailsPageData = quoteOrderData?.formData?.orderQuoteDetailsPage ?? null;
    const uploadPageDataGroups: DocumentGroupModel[] | null =
        quoteOrderData?.formData?.uploadAndLanguageSelectionPage?.pageData.groups ?? null;
    const uploadPageData = uploadPageDataGroups?.filter((group) => !group.isGroupInActive) ?? [];
    const alsoDeliverTo = oqDetailsPageData?.alsoDeliverTo as any[];

    const pm: number[] =
        Array.isArray(oqDetailsPageData?.pmContainer?.projectManager) &&
        oqDetailsPageData?.pmContainer?.projectManager.length > 0
            ? oqDetailsPageData?.pmContainer?.projectManager
            : [];
    const salesRep: number[] =
        Array.isArray(oqDetailsPageData?.salesRepContainer?.salesRep) &&
        oqDetailsPageData?.salesRepContainer?.salesRep.length > 0
            ? oqDetailsPageData?.salesRepContainer?.salesRep
            : [];

    const orderReferenceNo = quoteOrderData.info?.primaryId ?? 0;
    const referenceNo = oqDetailsPageData.referenceNumber || null;

    return {
        quoteOrderData,
        info,
        loggedInUser,
        loggedInUserRole,
        isThisContactUser,
        selectedCategory,
        oqDetailsPageData,
        uploadPageData,
        alsoDeliverTo,
        pm,
        salesRep,
        orderReferenceNo,
        referenceNo
    };
};
const getDateTime = (key: string) => {
    const { oqDetailsPageData } = getInfo();

    const date = oqDetailsPageData ? oqDetailsPageData[key] : null;
    if (date && date !== '') return formatDateYYMMDD(date as string);
    return null;
};

// payload data preparation
const getOrderDetailsPageData = () => {
    const {
        info,
        loggedInUser,
        isThisContactUser,
        selectedCategory,
        oqDetailsPageData,
        alsoDeliverTo,
        pm,
        salesRep,
        orderReferenceNo,
        referenceNo
    } = getInfo();

    const detailsPageData: Omit<STDUploadAndSelectionPayload, 'documents'> = {
        patentCategoryId: selectedCategory?.parentId ?? 0,
        patentServiceTypeId: selectedCategory?.patentCategoryId ?? 0,
        companyId: oqDetailsPageData?.companyName.id ?? 0,
        contactUserId: isThisContactUser
            ? loggedInUser.userId
            : (oqDetailsPageData?.contactUser?.id ?? 0),
        contactEmail: isThisContactUser ? '' : (oqDetailsPageData?.contactEmail ?? 0),
        po: oqDetailsPageData?.poNumber?.toString() ?? null,
        deliverTo: alsoDeliverTo?.join(', ') ?? null,
        mailCC: oqDetailsPageData?.cc ?? null,
        assignPM: pm,
        assignSalesRep: salesRep,
        requestCurrencyId: oqDetailsPageData.requestCurrencyId ?? 0,
        requestTypeId: info.mode ?? 1,
        instructionsByContactUser: oqDetailsPageData?.instructionByContactUser ?? null,
        instructionsByProjectManager: oqDetailsPageData?.instructionByProjectManager ?? null,
        isQuote: info?.mode === 1,
        quoteDetails: {
            patentTitle: oqDetailsPageData?.title ?? null,
            requestedDeliveryDate: getDateTime('requestedDeliveryDate'),
            // quoteDatetime: getDateTime('quoteTargetDateTime'),
            referenceNumber: referenceNo?.toString() ?? null
        },
        orderRequestReferenceNo: orderReferenceNo,
        turnAroundTime: oqDetailsPageData?.turnAroundTime ?? null
    };

    return detailsPageData;
};
const getSTDDocumentData = () => {
    try {
        const { uploadPageData } = getInfo();
        const documentList: STDDocumentSectionData[] = [];

        if (!uploadPageData)
            throw new Error(`No data found in 'uploadPageData' to construct STD document data.`);

        for (const doct of uploadPageData) {
            const savedDocuments: STDDocumentData[] = doct.documentList?.map(
                (file: FilePayload) => {
                    return {
                        fileName: file.name,
                        fileType: file.type,
                        fileSize: formatFileSize(file.size),
                        blobFileName: `${file.azureBlobFolderPath}/${file.azureBlobFileName}`,
                        documentType: file.documentType,
                        notes: file.fileNotes ?? '',
                        wordCount: file.wordCount ?? 0,
                        blobUrl: '',
                        documentKey: '',
                        extension: ''
                    };
                }
            );

            const document: STDDocumentSectionData = {
                sectionId: doct.groupId,
                sourceLanguageIds: doct.sourceLanguage,
                targetLanguageIds: doct.targetLanguage,
                saveDocuments: savedDocuments
            };
            documentList.push(document);
        }

        return documentList;
    } catch (error) {
        console.error('Error in getSTDDocumentData() service:', error);
        return [];
    }
};
const stdSubmission = async () => {
    try {
        const orderQuoteDetails = { ...getOrderDetailsPageData() };
        const documentList = getSTDDocumentData();

        const payload: STDUploadAndSelectionPayload = {
            ...orderQuoteDetails,
            documents: documentList
        };

        const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.STANDARD_SUBMISSION}`;
        const response: { requestNumber: number; id: number } = await httpService.post(
            apiUrl,
            payload,
            {},
            false,
            baseURL
        );
        return response;
    } catch (error) {
        console.error('Error while saving language selection', error);
        return null;
    }
};

const uploadAndLanguageSelectionService = { stdSubmission };
export default uploadAndLanguageSelectionService;
