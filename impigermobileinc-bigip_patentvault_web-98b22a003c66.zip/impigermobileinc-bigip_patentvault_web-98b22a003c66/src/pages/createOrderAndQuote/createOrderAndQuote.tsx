import { FC, useEffect, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import ProgressStepper from 'pages/components/progressStepper/progressStepper';
import PrimaryButtons from 'pages/components/primaryButtons/primaryButtons';
import BackButton from 'pages/components/backButton/backButton';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { MODE } from 'constants/app.constant';
import { PATHS } from 'constants/routes.constant';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { PATHS_FOR_STEPPER, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import edit from 'assets/images/edit-pencil.svg';
import BackButtonSTD from './components/standard/buttons/backButtonSTD';
import SubmitButtonSTD from './components/standard/buttons/submitButtonSTD';
import ContinueButtonSTD from './components/standard/buttons/continueButtonSTD';
import SplitButtonSTD from './components/standard/buttons/splitButtonSTD';
import stdConstants from './components/standard/constants/standard.constant';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';
// import standardModuleService from './components/standard/languageSelection/services/standardModule.service';
export interface ActionToProceedSTD {
    isPreview: boolean;
    isDiscard: boolean;
    isSave: boolean;
    isApprove: boolean;
}
// type ButtonName = 'SubmitSTD' | 'SaveSTD' | 'PreviewSTD' | 'DiscardSTD';

const CreateOrderAndQuote = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const location = useLocation();
    const { pathname } = location;

    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const [currentPage, setCurrentPage] = useState<string>('');
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: 'Confirmation',
        description: t('QUOTE_AND_ORDER.WARNING.DATA_LOSS_FOR_THIS_ACTION')
    });

    const mode = quoteOrderData?.info?.mode;
    const formData = quoteOrderData?.formData;
    const selectedService = quoteOrderData.info.selectedService;
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId;
    const isEditFlow: boolean = quoteOrderData?.info?.isEditFlow === true;
    const isSTDFlow = selectedService?.serviceTypeId === SERVICE_TYPE_ID.other_translations;
    const isServicePage: boolean = pathname?.includes(PATHS.SERVICE_TYPE);
    const isFinalPageOfSTDFlow: boolean = pathname?.includes(PATHS.LANGUAGE_SELECTION);
    const isSTDLandingPage: boolean =
        formData.uploadAndLanguageSelectionPage?.pageData.flags.isShowLandingPage ?? false;
    const requestNumber = quoteOrderData?.info?.requestNumber ?? null;
    const visibility: { [key: string]: boolean } = {
        isStepperShow: !isServicePage,
        isFooterShow: !isServicePage,
        isSelectedServiceCategoryShow: !isServicePage && !!selectedService && !!selectedCategoryId
    };

    // helpers
    const getLabelName = (): string => {
        let labelName = '';

        if (mode === MODE.CREATE_QUOTE) {
            labelName = isEditFlow ? 'COMMON.QUOTE' : 'LAYOUT.CREATE_QUOTE';
        } else if (mode === MODE.CREATE_ORDER) {
            labelName = isEditFlow ? 'COMMON.ORDER' : 'LAYOUT.CREATE_ORDER';
        }
        return labelName;
    };
    const isBackButtonVisible = (): boolean => {
        const stepperData = stepperStore.getStepperData();
        let isFirstPage = false;
        /** in Edit-Flow we restrict back button for the first page. */
        const currStep = stepperData.stepperInfo.currStep;
        isFirstPage = currStep?.id === 1;

        return !(isEditFlow && isFirstPage);
    };

    // actions
    const proceedFurther = (params: { actions: ActionToProceedSTD; exportType?: number }) => {
        const { actions, exportType = null } = params;
        let functionKey: string | null = null;

        switch (currentPage) {
            case PATHS.ORDER_QUOTE_DETAILS: {
                functionKey = PATHS.ORDER_QUOTE_DETAILS;
                break;
            }
            // case PATHS.STD_UPLOAD_AND_SELECTION: {
            //     functionKey = PATHS.STD_UPLOAD_AND_SELECTION;
            //     break;
            // }
            case PATHS.STD_UPLOAD_AND_SELECTION: {
                if (actions.isPreview) functionKey = stdConstants.STD_STEPPER_ACTIONS.PREVIEW;
                else if (actions.isDiscard) functionKey = stdConstants.STD_STEPPER_ACTIONS.DISCARD;
                else if (actions.isSave) functionKey = stdConstants.STD_STEPPER_ACTIONS.SAVE;
                else if (actions.isApprove) functionKey = stdConstants.STD_STEPPER_ACTIONS.APPROVE;
                break;
            }
            default:
                break;
        }

        if (functionKey) {
            quoteOrderModuleStore.invokeFunction(functionKey, exportType ?? undefined);
        } else if (currentPage === PATHS.QO_FILE_UPLOAD) {
            document.getElementById(`submit-${PATHS.QO_FILE_UPLOAD}`)?.click();
        } else {
            console.warn('No function registered for:', currentPage);
        }
    };

    // popup
    const handleConfirm = () => {
        // reset the store, when user click this back button
        stepperStore.resetStepperStore();
        quoteOrderModuleStore.resetQuoteOrderStore();
        navigate(
            isServicePage
                ? `/${PATHS.ORDER_QUOTE}`
                : `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`
        );
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleBackToListingPage = () => {
        setShowPopup({ ...showPopup, visible: true });
    };

    // handle side effects
    useEffect(() => {
        // redirection while hard refresh
        const redirectToListingPage = async () => {
            // set timeout to wait for store update while select mode in listing page
            await new Promise((r) => setTimeout(r, 100));

            const updatedQuoteOrderModuleStore = quoteOrderModuleStore.getData();
            if (updatedQuoteOrderModuleStore?.info?.mode === null) {
                navigate(`/${PATHS.ORDER_QUOTE}`);
            }
        };
        redirectToListingPage();
    }, []);
    useEffect(() => {
        /** get current page name from pathname. */
        const pathNameList = pathname.split('/');
        const currentPageUrl = pathNameList[pathNameList.length - 1];
        if (currentPageUrl) {
            setCurrentPage(currentPageUrl);
        }
    }, [pathname]);

    return (
        <div data-testid="CreateOrderAndOrder">
            {showPopup.visible && (
                <ConfirmationPopup
                    key={'goBackConfirmationPopup'}
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    data-testid="ConfirmationPopup"
                />
            )}

            {/* top layer of layout */}
            <div className="h-[2.87rem] bg-white border-b-2 border-b-primary" data-testid="Header">
                <div className="flex justify-between h-full">
                    <TopNavigationStep
                        backNavigationPath={
                            isServicePage
                                ? `/${PATHS.ORDER_QUOTE}`
                                : `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`
                        }
                        onBackClick={() => handleBackToListingPage()}
                        steps={[
                            {
                                label:
                                    mode === MODE.CREATE_ORDER
                                        ? t('COMMON.SELECT_ORDER')
                                        : t('COMMON.SELECT_QUOTE'),
                                isCurrent: false,
                                isPrevious: true,
                                navigationPath: isServicePage
                                    ? `/${PATHS.ORDER_QUOTE}`
                                    : `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`,
                                navigationPathName: isServicePage
                                    ? t('COMMON.ORDERS_QUOTES')
                                    : t('COMMON.SERVICE_TYPE'),
                                onClick() {
                                    handleBackToListingPage();
                                }
                            },
                            {
                                label: isEditFlow
                                    ? t(`${getLabelName()}`) +
                                      ' ' +
                                      (requestNumber ?? '') +
                                      ' ' +
                                      `(${t('COMMON.EDIT')})`
                                    : t(`${getLabelName()}`),
                                isCurrent: true,
                                isPrevious: false
                            }
                        ]}
                    />

                    {visibility.isSelectedServiceCategoryShow && (
                        <SelectedServiceCategoryDetails params={{ isEditFlow }} />
                    )}
                </div>
            </div>

            <div className="lg:flex w-full" data-testid="MainContainer">
                {/* Stepper */}
                {visibility.isStepperShow && (
                    <div
                        className="lg:w-1/5 p-3 pb-0 md:p-4 md:px-5 md:h-full progressStepperHeight"
                        data-testid="ProgressStepperContainer">
                        <ProgressStepper pathsForStepper={PATHS_FOR_STEPPER} />
                    </div>
                )}
                <div
                    id="content-container"
                    className={`${!isServicePage ? 'lg:w-4/5' : ''} w-full h-full`}
                    data-testid="ContentContainer">
                    {/* Body */}
                    <div
                        className={`border border-gray-300 m-2 mb-0 md:m-3 md:mb-0 rounded-md rounded-b-none overflow-hidden  md:rounded-lg  ${isServicePage ? 'h-[calc(100vh-105px)] 2xl:h-[calc(100vh-123px)] 4xl:h-[calc(100vh-139px)]' : 'h-[calc(100vh-140px)] 2xl:h-[calc(100vh-164px)] 4xl:h-[calc(100vh-188px)] md:rounded-b-none  border-b-0'}`}
                        data-testid="FormContainer">
                        <div
                            className="createOrderQuoteSelection"
                            id="scrollTarget"
                            data-testid="FormContent">
                            <Outlet />
                        </div>
                    </div>

                    {/* Footer */}
                    {visibility.isFooterShow && (
                        <div
                            className={`${isBackButtonVisible() ? 'justify-between' : 'justify-end'} flex items-center px-2 mb-2 lg:mb-0 md:px-6 py-2 mx-2 md:mx-3 border bg-white border-neutral-100/50`}
                            data-testid="Footer">
                            {/* Due to reduce the complexity we keep the separate buttons only for the Standard flow. */}
                            {isSTDFlow ? (
                                <>
                                    {isBackButtonVisible() && <BackButtonSTD />}
                                    {isFinalPageOfSTDFlow ? (
                                        <span className="flex gap-3">
                                            <SplitButtonSTD handleButtonClick={proceedFurther} />
                                            {!isSTDLandingPage && (
                                                <SubmitButtonSTD
                                                    handleButtonClick={proceedFurther}
                                                    isDisableApproveButton={false}
                                                />
                                            )}
                                        </span>
                                    ) : (
                                        <ContinueButtonSTD handleButtonClick={proceedFurther} />
                                    )}
                                </>
                            ) : (
                                <>
                                    {isBackButtonVisible() && (
                                        <BackButton
                                            isServicePage={isServicePage}
                                            data-testid="BackButton"
                                        />
                                    )}
                                    <PrimaryButtons data-testid="PrimaryButtons" />
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const SelectedServiceCategoryDetails: FC<{ params: { isEditFlow: boolean } }> = ({ params }) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const quoteOrderData = quoteOrderModuleStore.getData();
    const { pathname } = useLocation();
    const isServicePage: boolean = pathname?.includes('service-type');
    const isCompanyDetailsPage: boolean = pathname?.includes('company-details');

    return (
        <div className="hidden lg:flex items-center h-full mr-4 gap-4 bg-primary-50 px-3 border">
            <div className="text-nowrap" data-testid="CategoryInfo">
                <label className="text-gray-700 font-medium">{`${t('COMPANY_DETAILS.CATEGORY')}: `}</label>
                <label className="text-primary font-medium">
                    {quoteOrderData.info.selectedService?.displayText}
                </label>
            </div>
            <div className="flex items-center gap-2 text-nowrap">
                <label className="text-gray-700 font-medium">{`${t('COMPANY_DETAILS.SERVICE')}: `}</label>
                <label className="text-primary font-medium">
                    {quoteOrderData.info.selectedCategory?.patentCategoryDisplay}
                </label>
                {quoteOrderData.formData.companyDetailsPage?.publicationNumber &&
                    !isServicePage &&
                    !isCompanyDetailsPage && (
                        <div className="text-nowrap">
                            <label className="text-gray-700 font-medium">{`${t('COMPANY_DETAILS.PATENT_NUMBER')}: `}</label>
                            <label className="text-primary font-medium">
                                {quoteOrderData.formData.companyDetailsPage?.publicationNumber}
                            </label>
                        </div>
                    )}
                {!params.isEditFlow && (
                    <a
                        className="cursor-pointer w-4"
                        data-testid="edit-quote-order"
                        href={`/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`}
                        onClick={(e) => {
                            e.preventDefault();
                            const redirectTo = `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`;
                            navigate(redirectTo);
                            stepperStore.resetStepperStore();
                            quoteOrderModuleStore.resetQuoteOrderStore({
                                mode: quoteOrderData.info.mode
                            });
                        }}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                const redirectTo = `/${PATHS.ORDER_QUOTE}/${PATHS.CREATE}/${PATHS.SERVICE_TYPE}`;
                                navigate(redirectTo);
                                stepperStore.resetStepperStore();
                                quoteOrderModuleStore.resetQuoteOrderStore({
                                    mode: quoteOrderData.info.mode
                                });
                            }
                        }}
                        tabIndex={0}>
                        <img src={edit} alt="" className="h-[1rem]" data-testid="EditIcon" />
                    </a>
                )}
            </div>
        </div>
    );
};

export default CreateOrderAndQuote;
