import orderQuoteServices from './createOrderAndQuote.service';
import { END_POINT } from 'constants/endPoint';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import HttpService from 'core/interceptor/api.handler';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import utils from 'core/utils/utils';
import { OrderSave, OrderSaveResponse } from 'pages/ordersAndQuotes/types/ordersAndQuotes.types';
import { waitFor } from '@testing-library/react';

jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('core/interceptor/api.handler');
jest.mock('../components/summary/services/summary.service');
jest.mock('../components/orderQuoteDetails/services/orderQuoteDetails.service');
jest.mock('core/store/stepperStore/progressStepper.store');
jest.mock('core/utils/utils');

describe('orderQuoteServices', () => {
    const mockHttpService = new HttpService();
    const mockQuoteOrderData = {
        info: {
            primaryId: 1,
            approveStatus: 2,
            selectedService: { serviceTypeId: 1 },
            requestCurrencyId: 1,
            mode: 'CREATE_ORDER',
            selectedCategory: { patentCategoryId: 1 },
            isEditFlow: false
        },
        formData: {
            additionalInfoPage: {
                emailID: 'test@example.com',
                deliverTo: [{ email: 'deliver@example.com' }],
                cc: 'cc@example.com',
                po: 'PO123',
                instructionByContactUser: 'Contact User Instructions',
                instructionByProjectManager: 'PM Instructions',
                projectManager: 'Project Manager',
                quoteTargetDate: '2023-01-01'
            },
            patentDetailsPage: {
                validationDeadline: '2023-01-01',
                filingDeadLine: '2023-01-02',
                totalWordCount: 1000,
                specialInstructions: 'Special Instructions',
                referenceNo: 'REF123',
                requestedDeliveryDate: '2023-01-03',
                ifEpGrantedYesNo: false,
                english: true,
                german: true,
                french: true
            },
            summaryPage: {
                selectedCurrency: { currencyId: 1 },
                flags: { IsUp: true },
                responseData: {
                    summaryResponse: {
                        instantCountryList: { countryFeeList: [] },
                        customCountryList: [],
                        serviceBasedFee: { nonupFee: [], upFee: [] },
                        languageBasedFee: []
                    }
                },
                totals: {
                    nationalValidationUP: {
                        up: 100,
                        nonUP: 200,
                        languageFeeTotal: 300
                    },
                    nationalValidation: {
                        countryFeeTotal: 400,
                        languageFeeTotal: 500
                    }
                }
            },
            selectCountryPage: {
                instantCountries: [],
                customCountries: []
            },
            selectCountryPageForEP: {
                countryList: []
            }
        }
    };

    beforeEach(() => {
        jest.clearAllMocks();
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue(mockQuoteOrderData);
        (stepperStore.getStepperData as jest.Mock).mockReturnValue({ stepperList: [] });
    });

    describe('orderSave', () => {
        it('should save order and download files', async () => {
            const mockResponse: OrderSaveResponse<OrderSave> = {
                pdfFiles: [
                    {
                        pdfFile: 'base64pdf',
                        fileName: ''
                    }
                ],
                excelFiles: [
                    {
                        excelFile: 'base64excel',
                        fileName: ''
                    }
                ],
                orderResponse: {
                    orderRequestNumber: 'ORDER123',
                    requestId: 0,
                    orderNumber: 0,
                    totalWordCount: 0,
                    claimsPriority: false,
                    specialInstructions: '',
                    isClaims71_3: false,
                    orderDate: '',
                    completedDate: undefined,
                    instructionByContactUser: '',
                    assignPM: '',
                    requestCurrencyId: 0,
                    grandTotal: 0,
                    additionalInfo: {},
                    disclaimerInfoList: [],
                    patentCountrySummaryList: [],
                    quoteStatus: 0,
                    requestedDeliveryDate: undefined,
                    referenceNumber: '',
                    emailID: '',
                    deliverto: '',
                    mailcc: '',
                    po: '',
                    quoteDatetime: undefined,
                    targetDateTime: undefined,
                    instructionByContanctUser: '',
                    instructionByPM: '',
                    disclaimer: '',
                    customInstruction: '',
                    countryId: 0,
                    languageId: 0,
                    countryName: undefined,
                    entityType: 0,
                    agencyFee: 0,
                    officialFee: 0,
                    translationFee: 0,
                    total: 0,
                    isprimary: false,
                    groupId: undefined,
                    ep: false,
                    up: undefined,
                    isBothDecideLater: false
                },
                generatePDFStatus: ''
            };

            (mockHttpService.post as jest.Mock).mockResolvedValue(mockResponse);
            (utils.base64toBlob as jest.Mock).mockReturnValue(new Blob());
            (utils.base64toBlobForExcel as jest.Mock).mockReturnValue(new Blob());

            const response = await orderQuoteServices.orderSave();

            waitFor(() => {
                expect(mockHttpService.post).toHaveBeenCalledWith(
                    `${END_POINT.ORDER_SAVE}`,
                    expect.any(Object),
                    {},
                    false,
                    process.env.REACT_APP_QUOTE_BASE_URL
                );
                expect(utils.base64toBlob).toHaveBeenCalledWith('base64pdf');
                expect(utils.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), 'ORDER123');
                expect(utils.base64toBlobForExcel).toHaveBeenCalledWith('base64excel');
                expect(utils.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), 'ORDER123');
                expect(response).toEqual(mockResponse);
            });
        });
    });

    describe('getPDFData', () => {
        it('should get PDF data and return file URL', async () => {
            const mockUrl = 'blob:http://localhost/pdf';
            jest.spyOn(window.URL, 'createObjectURL').mockReturnValue(mockUrl);
            const fileUrl = await orderQuoteServices.getPDFData('templateName');
            expect(mockHttpService.export).toHaveBeenCalledWith(
                `order/pdf/download?templateName=templateName`,
                expect.any(Object),
                {},
                false,
                process.env.REACT_APP_QUOTE_BASE_URL
            );
            expect(fileUrl).toBe(mockUrl);
        });

        it('should throw error if get PDF data fails', () => {
            (mockHttpService.export as jest.Mock).mockRejectedValue(
                new Error('PDF download failed')
            );

            waitFor(() => {
                expect(orderQuoteServices.getPDFData('templateName')).rejects.toThrow(
                    'PDF download failed'
                );
            });
        });
    });
});
