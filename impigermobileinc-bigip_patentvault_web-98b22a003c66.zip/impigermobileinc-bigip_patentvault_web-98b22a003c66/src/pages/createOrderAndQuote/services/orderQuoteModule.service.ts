import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import {
    BackupDataToCompare,
    QuoteOrderModuleStore,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import selectCountryService from 'pages/orders/selectCountry/services/selectCountry.service';
import {
    STEPPER_DATA_TYPE,
    STEPPER_INFO,
    STEPPER_STATE
} from 'pages/components/progressStepper/types/progressStepper.type';
import {
    CountryConfig,
    SelectCountryDataForEdit
} from 'pages/orders/selectCountry/types/country.type';
import {
    CountryList,
    CountsFieldsList,
    SummaryListingTableName,
    SummaryMetaData,
    SummaryResponse
} from '../components/summary/types/summary.type';
import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_DATA,
    STEPPER_TYPE_ID
} from 'constants/progressStepper.constant';
import { PATHS } from 'constants/routes.constant';
import { toggleLoadingIndicator } from 'core/utils/utils';
import progressStepperServices from 'pages/components/progressStepper/services/progressStepper.service';
import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { ROLE } from 'constants/app.constant';
import { ProjectManager } from '../components/serviceType/types/serviceType.type';
import { getSummaryInitData } from '../components/summary/summary';

interface ParamCheckAndUpdateCountry {
    country: CountryList;
    summaryListingTableName: SummaryListingTableName;
    validateTotalOnlyDirectly: boolean;
    isCustomCheck: boolean;
}

const httpService = new HttpService();
const pvBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

// helpers
const getGrandTotal = (
    summaryPage: SummaryMetaData | null,
    isEPFlow: boolean,
    isUP: boolean | null
): number => {
    let total = 0;

    if (isEPFlow) {
        total = isUP
            ? (summaryPage?.totals?.nationalValidationUP.grandTotalUP ?? 0)
            : (summaryPage?.totals?.nationalValidation.grandTotal ?? 0);
    } else {
        total =
            (summaryPage?.totals?.nationalValidation?.countryFeeTotal ?? 0) +
            (summaryPage?.totals?.customCountry ?? 0);
    }

    return total;
};

// users/roles
const getSalesRepList = async <T>(): Promise<T> => {
    const apiUrl = `${END_POINT.COMPANIES.BASE}/${END_POINT.COMPANIES.GET_SALES_REP_LIST}`;
    try {
        const response = await httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching Sales Rep listing data:', error);
        throw error;
    }
};
const getProjectManagersList = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.PROJECT_MANAGER_LIST}`;
    try {
        const response = await httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};
const setAdditionalInfoPM = async () => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const quoteOrderData = quoteOrderModuleStore.getData();
    const loggedInUserRoleId = userDetails?.userInfo?.roleId;
    const isPMUser =
        loggedInUserRoleId === ROLE.PROJECT_MANAGER.roleId ||
        loggedInUserRoleId === ROLE.VENDOR_PROJECT_MANAGER.roleId ||
        loggedInUserRoleId === ROLE.VENDOR_PROJECT_COORDINATOR.roleId;

    try {
        if (isPMUser && !quoteOrderData.formData?.additionalInfoPage?.projectManager) {
            /** if PM dropdown is empty in additional-info page, then set user-id only for PM users. */
            const projectManagers = await getProjectManagersList<ProjectManager[]>();
            const loggedInUser =
                projectManagers?.find(
                    (pm: ProjectManager) => pm.id === userDetails?.userInfo.userId
                ) ?? null;
            if (!loggedInUser) return;

            const updatedAdditionalInfoPage = {
                ...(quoteOrderData.formData.additionalInfoPage ?? {}),
                projectManager: [{ ...loggedInUser }]
            };
            const updatedQuoteOrderFormData = {
                ...quoteOrderData.formData,
                additionalInfoPage: updatedAdditionalInfoPage
            };
            quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        }
    } catch (error) {
        console.error('Error in getProjectManagersList(): ', error);
    }
};

// stepper
const addMoreStepInStepper = () => {
    // common method to add the summary page step in stepper
    // function to add the summary step in stepper
    try {
        const stepperData = stepperStore.getStepperData();

        const summaryStep: STEPPER_DATA_TYPE = STEPPER_DATA.SUMMARY;
        const isSummaryExists = stepperData?.stepperList?.some(
            (step) => step.stepperId === summaryStep.stepperId
        );

        if (!stepperData || !summaryStep) throw Error;

        if (summaryStep && stepperData?.stepperList && !isSummaryExists) {
            const updatedStepperList: STEPPER_DATA_TYPE[] = [
                ...stepperData.stepperList,
                summaryStep
            ];

            const updatedStepperData: STEPPER_STATE = {
                ...stepperData,
                stepperList: updatedStepperList
            };

            stepperStore?.updateStepper(updatedStepperData);
        }
    } catch (error) {
        console.error('Error in addMoreStepInStepper() : ', error);
    }
};
const removeStepInStepper = () => {
    // common method to remove the summary page step in stepper
    // function to add the summary step in stepper
    try {
        const stepperData = stepperStore.getStepperData();

        const summaryStep: STEPPER_DATA_TYPE = STEPPER_DATA.SUMMARY;
        const isSummaryExists = stepperData?.stepperList?.some(
            (step) => step.stepperId === summaryStep.stepperId
        );

        if (summaryStep && stepperData?.stepperList && isSummaryExists) {
            const updatedStepperList: STEPPER_DATA_TYPE[] = stepperData?.stepperList.filter(
                (step: STEPPER_DATA_TYPE) => step.stepperId !== summaryStep.stepperId
            );
            if (updatedStepperList) {
                const updatedStepperData: STEPPER_STATE = {
                    ...stepperData,
                    stepperList: updatedStepperList
                };

                /** reset the summary page on store, since we remove this summary step from stepper. */
                setInitDataToSummary();

                stepperStore?.updateStepper(updatedStepperData);
            }
        }
    } catch (error) {
        console.error(
            'Error while removing the summary step in existing stepper (removeStepInStepper()): ',
            error
        );
    }
};
export const stepperNavigation = () => {
    try {
        const stepperData: STEPPER_STATE = stepperStore.getStepperData();
        const updatedStepperInfo: STEPPER_INFO | undefined =
            progressStepperServices?.updateStepperStoreForNextPage(stepperData);

        if (!updatedStepperInfo) return null;

        if (updatedStepperInfo?.currStep) {
            stepperStore.updateStepper({ stepperInfo: updatedStepperInfo });
            return updatedStepperInfo;
        }
    } catch (error) {
        console.error('Error in stepperNavigation() : ', error);
    }
};
const setInitDataToSummary = () => {
    const summaryInitData: SummaryMetaData = getSummaryInitData();
    const updatedQuoteOrderFormData = {
        ...quoteOrderModuleStore.getData().formData,
        summaryPage: summaryInitData
    };

    quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
};

// backup some page data to compare
const getLanguages = (quoteOrderData: QuoteOrderModuleStore): { [key: string]: string | null } => {
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;
    const languagesToSave = ['english', 'german', 'french'];
    const selectedLanguages: { [key: string]: string | null } = {
        english: null,
        german: null,
        french: null
    };

    for (const language of languagesToSave) {
        selectedLanguages[language] = patentDetailsPage
            ? (patentDetailsPage[language] ?? null)
            : null;
    }
    return selectedLanguages;
};
const getCountFields = (quoteOrderData: QuoteOrderModuleStore) => {
    // get counts fields only from PatentDetailsPage to update on store
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;
    const countFields: { [key: string]: number | null } | null = {};

    if (patentDetailsPage) {
        CountsFieldsList.forEach((key: string) => {
            countFields[key] = Object.prototype.hasOwnProperty.call(patentDetailsPage, key)
                ? patentDetailsPage[key]
                : null;
        });
    }

    return countFields;
};
const getCountriesList = (
    quoteOrderData: QuoteOrderModuleStore,
    isBackupFromEditAPIResponse: boolean = false
): number[] => {
    const formData = quoteOrderData.formData;
    const selectedServiceId = quoteOrderData.info.selectedService?.serviceTypeId as number;
    const isEPFlow = selectedServiceId === SERVICE_TYPE_ID.european_patent;

    let countryIds: number[] = [];

    /** get country ids form list then return as number[]. */
    const getCountryIds = (countryList: CountryConfig[] | SelectCountryDataForEdit[]): number[] => {
        if (!countryList || countryList.length === 0) return [];

        const ids: number[] = countryList
            .map((country: CountryConfig | SelectCountryDataForEdit) => {
                if (isBackupFromEditAPIResponse) {
                    return (country as SelectCountryDataForEdit).countryId;
                } else {
                    return (country as CountryConfig).isSelected
                        ? (country as CountryConfig).data.id
                        : null;
                }
            })
            /** filter the result to get [], only as numbers. */
            .filter((id): id is number => id !== null)
            /** sort the result to avoid wrong results when countries are same with different order in []. */
            .sort((a, b) => a - b);

        return ids;
    };

    if (isBackupFromEditAPIResponse) {
        let originalSelectedCountries: SelectCountryDataForEdit[] = [];

        if (isEPFlow) {
            originalSelectedCountries = formData.selectCountryPageEdit?.epCountries ?? [];
            countryIds = getCountryIds(originalSelectedCountries);
        } else {
            const originalInstantCountries = formData.selectCountryPageEdit?.instantCountries ?? [];
            const originalCustomCountries = formData.selectCountryPageEdit?.customCountries ?? [];
            originalSelectedCountries = [...originalInstantCountries, ...originalCustomCountries];
            countryIds = getCountryIds(originalSelectedCountries);
        }
    } else {
        let selectedCountries: CountryConfig[] = [];

        if (isEPFlow) {
            selectedCountries = formData.selectCountryPageForEP?.countryList ?? [];
            countryIds = getCountryIds(selectedCountries);
        } else {
            const instantCountries = formData.selectCountryPage?.instantCountries ?? [];
            const customCountries = formData.selectCountryPage?.customCountries ?? [];
            selectedCountries = [...instantCountries, ...customCountries];
            countryIds = getCountryIds(selectedCountries);
        }
    }

    return countryIds;
};
const backupDataToStore = (quoteOrderData: QuoteOrderModuleStore) => {
    /** backup some wanted pages data to compare and save on store */
    const getPageDataToBackupToCompare: BackupDataToCompare = {
        companyName: quoteOrderData.formData.companyDetailsPage?.selectedCompany ?? null,
        selectedCurrency: quoteOrderData.formData.summaryPage?.selectedCurrency ?? null,
        languages: getLanguages(quoteOrderData),
        counts: getCountFields(quoteOrderData),
        countries: getCountriesList(quoteOrderData, true)
    };
    quoteOrderModuleStore.updatePage('backupDataToCompare', getPageDataToBackupToCompare);
};

/** data comparison b/w current pages and backup pages */
export const pagesComparisonWithBackupData = (quoteOrderData: QuoteOrderModuleStore): boolean => {
    // existing data to compare from store
    const backupDataToCompare = quoteOrderData?.backupDataToCompare;

    // get current data
    const companyName = quoteOrderData.formData.companyDetailsPage?.selectedCompany ?? null;
    const languages = getLanguages(quoteOrderData);
    const countsFields = getCountFields(quoteOrderData);
    const selectedCountries = getCountriesList(quoteOrderData);

    if (!backupDataToCompare || !companyName || !countsFields || !selectedCountries) return true;

    const compareValues = (data1: any, data2: any): boolean => {
        /** convert the params as string and compare the values then return as boolean. */
        return JSON.stringify(data1) === JSON.stringify(data2);
    };

    const isCompanyModified = !compareValues(companyName, backupDataToCompare?.companyName);
    const isLanguagesModified = !compareValues(languages, backupDataToCompare.languages);
    const isCountsModified = !compareValues(countsFields, backupDataToCompare?.counts);
    const isCountriesModified = !compareValues(selectedCountries, backupDataToCompare?.countries);
    const isCurrencyModified = !compareValues(
        quoteOrderData.formData.summaryPage?.selectedCurrency,
        backupDataToCompare.selectedCurrency
    );

    /** check and update the flags when values are different with Backup data. */
    const pagesMatchStatusWithBackupData = {
        isCompanyModified,
        isLanguagesModified,
        isCountsModified,
        isCountriesModified,
        isCurrencyModified
    };
    if (
        /** condition to avoid the store update when the data is same. */
        JSON.stringify(pagesMatchStatusWithBackupData) !==
        JSON.stringify(quoteOrderData.flags.pagesMatchStatusWithBackupData)
    ) {
        const updatedQuoteOrderFlags = {
            ...quoteOrderData?.flags,
            pagesMatchStatusWithBackupData
        };
        quoteOrderModuleStore.updatePage('flags', updatedQuoteOrderFlags); // update store - flags
    }

    return isCompanyModified || isLanguagesModified || isCountsModified || isCountriesModified;
};

// summary page - table validations
const checkSummaryTablesHasInvalidValues = (
    quoteOrderData: QuoteOrderModuleStore,
    checkIsCountryHasValuesAsZero: boolean = false
) => {
    /** check if tables have invalid values. via this function we shows validations against cells.
     *  we validating only the cells which we shows in the table (UI). */
    toggleLoadingIndicator(true);

    const summaryPage: SummaryMetaData | null = quoteOrderData.formData.summaryPage;
    const isEPFlow =
        quoteOrderData.info.selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent;
    const isUP: boolean | null = summaryPage?.flags?.IsUp ?? null;
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId as number;
    const PCT: { [key: string]: number } =
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty];
    const EP: { [key: string]: number } = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent];
    const PC: { [key: string]: number } = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty];

    interface ColumnsType {
        columnName: string;
        notApplicableFor: (SummaryListingTableName | number)[];
    }
    const columns: ColumnsType[] = [
        {
            columnName: 'agencyFee',
            notApplicableFor: [
                'upCountryList',
                'languageFeeList',
                PCT.translation_only,
                EP.translation_only,
                PC.translation_only
            ]
        },
        {
            columnName: 'officialFee',
            notApplicableFor: [
                'upCountryList',
                'languageFeeList',
                PCT.translation_only,
                EP.translation_only,
                PC.translation_only
            ]
        },
        {
            columnName: 'translationFee',
            notApplicableFor: [PCT.annuities, PCT.recordal, EP.recordal, EP.Renewals]
        },
        {
            columnName: 'total',
            notApplicableFor: []
        }
    ];

    const instantCountryList =
        quoteOrderData.formData.summaryPage?.responseData.summaryResponse?.instantCountryList;
    const customCountryList =
        quoteOrderData.formData.summaryPage?.responseData.summaryResponse?.customCountryList;
    const serviceBasedList =
        quoteOrderData.formData.summaryPage?.responseData.summaryResponse?.serviceBasedFee;
    const languageBasedList =
        quoteOrderData.formData.summaryPage?.responseData.summaryResponse?.languageBasedFee;

    let isCountryHasInvalidValues: boolean = false; // flag to check if any country has null/undefined.
    let isCountryHasValuesAsZero: boolean = false; // flag to check only if any country has '0' values.

    // functions
    const countryRowHasInvalidValues = (params: ParamCheckAndUpdateCountry): ColumnsType[] => {
        const { country, summaryListingTableName, validateTotalOnlyDirectly } = params;

        return columns.filter((column) => {
            /** we handle show and hide on the languages rows based on this flag in country listing.
             * if this false means we don't show those. so validation also not need. */
            if (country.isSelected === false) return false;

            const field = country[column.columnName as keyof CountryList];

            /** Flag: validateTotalOnlyDirectly -> here we validate the fields with selected columns by above filtered columns by 'columns' variable.
             * for languages fields, having value in any one of the column only. but we don't know that exact column name.
             * so, we just validate the 'total' field only for languages.
             * so, to avoid the columns for languages fields we used this flag. */
            if (
                column.notApplicableFor.includes(selectedCategoryId) ||
                column.notApplicableFor.includes(summaryListingTableName) ||
                validateTotalOnlyDirectly
            ) {
                return false;
            } else if (!checkIsCountryHasValuesAsZero) {
                /** check if any invalid values */
                return !(field !== undefined && field !== null && field !== '');
            } else if (checkIsCountryHasValuesAsZero && field && field !== '') {
                /** check is there any values as '0' on valid columns only.
                 *  note: we already validated the invalid columns above. */
                return +field === 0;
            }
        });
    };
    const checkAndUpdateCountry = (params: ParamCheckAndUpdateCountry): CountryList => {
        const { country, isCustomCheck } = params;

        let hasNullValue = false;

        const checkCountryRowHasInvalidValues = countryRowHasInvalidValues(params);

        if (checkCountryRowHasInvalidValues.length > 0) {
            hasNullValue = true;
        }

        if (isCustomCheck && country.isSelected) {
            hasNullValue = country.total === null;
        }

        if (hasNullValue) {
            country.hasNullValues = true;
            isCountryHasInvalidValues = true;
        } else {
            country.hasNullValues = false;
        }

        return country;
    };
    const iterateCountryList = () => {
        if (instantCountryList?.countryFeeList && instantCountryList?.countryFeeList.length > 0) {
            instantCountryList?.countryFeeList.forEach((country) => {
                /** Note: set this flag as true to validate only the 'total' column for the language items. */
                const validateTotalOnlyDirectly: boolean =
                    (!country.countryId || country.countryId === 0) && !country.countryName;

                const params: ParamCheckAndUpdateCountry = {
                    country,
                    summaryListingTableName: 'countryFeeList',
                    validateTotalOnlyDirectly,
                    isCustomCheck: false // default value
                };

                if (!checkIsCountryHasValuesAsZero) {
                    checkAndUpdateCountry(params);
                } else if (checkIsCountryHasValuesAsZero && !isCountryHasValuesAsZero) {
                    isCountryHasValuesAsZero = countryRowHasInvalidValues(params).length > 0;
                }
            });
        }
        if (customCountryList && customCountryList.length > 0) {
            customCountryList?.forEach((country) => {
                const params: ParamCheckAndUpdateCountry = {
                    country,
                    summaryListingTableName: 'customCountry',
                    validateTotalOnlyDirectly: false, // default value
                    isCustomCheck: false // default value
                };

                if (!checkIsCountryHasValuesAsZero) {
                    checkAndUpdateCountry(params);
                } else if (checkIsCountryHasValuesAsZero && !isCountryHasValuesAsZero) {
                    isCountryHasValuesAsZero = countryRowHasInvalidValues(params).length > 0;
                }
            });
        }

        if (EP.Renewals !== selectedCategoryId) {
            if (serviceBasedList?.upFee && serviceBasedList?.upFee.length > 0) {
                serviceBasedList?.upFee.forEach((country) => {
                    const params: ParamCheckAndUpdateCountry = {
                        country,
                        summaryListingTableName: 'upCountryList',
                        validateTotalOnlyDirectly: true,
                        isCustomCheck: true
                    };

                    if (!checkIsCountryHasValuesAsZero) {
                        checkAndUpdateCountry(params);
                    } else if (checkIsCountryHasValuesAsZero && !isCountryHasValuesAsZero) {
                        isCountryHasValuesAsZero =
                            countryRowHasInvalidValues({
                                ...params,
                                validateTotalOnlyDirectly: false
                            }).length > 0;
                    }
                });
            }

            if (serviceBasedList?.nonupFee && serviceBasedList?.nonupFee.length > 0) {
                serviceBasedList?.nonupFee.forEach((country) => {
                    const params: ParamCheckAndUpdateCountry = {
                        country,
                        summaryListingTableName: 'nonUPCountryList',
                        validateTotalOnlyDirectly: true,
                        isCustomCheck: false // default value
                    };

                    if (!checkIsCountryHasValuesAsZero) {
                        checkAndUpdateCountry(params);
                    } else if (checkIsCountryHasValuesAsZero && !isCountryHasValuesAsZero) {
                        isCountryHasValuesAsZero =
                            countryRowHasInvalidValues({
                                ...params,
                                validateTotalOnlyDirectly: false
                            }).length > 0;
                    }
                });
            }
            if (languageBasedList && languageBasedList.length > 0) {
                languageBasedList.forEach((country) => {
                    const params: ParamCheckAndUpdateCountry = {
                        country,
                        summaryListingTableName: 'languageFeeList',
                        validateTotalOnlyDirectly: true,
                        isCustomCheck: false // default value
                    };

                    if (!checkIsCountryHasValuesAsZero) {
                        checkAndUpdateCountry(params);
                    } else if (checkIsCountryHasValuesAsZero && !isCountryHasValuesAsZero) {
                        isCountryHasValuesAsZero =
                            countryRowHasInvalidValues({
                                ...params,
                                validateTotalOnlyDirectly: false
                            }).length > 0;
                    }
                });
            }
        }
    };
    const updateStore = async () => {
        const summaryPageData = quoteOrderData.formData.summaryPage;
        if (summaryPageData?.responseData?.summaryResponse) {
            const summaryResponse = summaryPageData.responseData.summaryResponse;

            const updatedSummaryResponse: SummaryResponse = {
                currencySymbol: summaryResponse.currencySymbol,
                customCountryList: customCountryList ?? [],
                customCountryMessage: summaryResponse.customCountryMessage,
                disclaimerList: summaryResponse.disclaimerList,
                grandTotal: getGrandTotal(summaryPage, isEPFlow, isUP),
                instantCountryList: {
                    countryFeeList: instantCountryList?.countryFeeList ?? []
                },
                languageBasedFee: languageBasedList ?? [],
                serviceBasedFee: {
                    upFee: serviceBasedList?.upFee ?? [],
                    nonupFee: serviceBasedList?.nonupFee ?? [],
                    agencyFeeTooltip: serviceBasedList?.agencyFeeTooltip ?? null,
                    translationFeeTooltip: serviceBasedList?.translationFeeTooltip ?? null
                }
            };

            const updatedData: SummaryMetaData = {
                ...summaryPageData,
                responseData: {
                    ...summaryPageData.responseData,
                    summaryResponse: updatedSummaryResponse
                }
            };

            // Update the page data to store
            const updatedQuoteOrderData = quoteOrderModuleStore.getData().formData;

            /** get all the tables data from the response and compare with the store data,
             *  to avoid unnecessary store update. */
            const summaryResponseData = { ...updatedData.responseData.summaryResponse }; // current updated data
            const updatedTablesData = {
                countryFeeList: summaryResponseData?.instantCountryList?.countryFeeList ?? [],
                upFee: summaryResponseData?.serviceBasedFee?.upFee ?? [],
                nonupFee: summaryResponseData?.serviceBasedFee?.nonupFee ?? [],
                languageFeeList: summaryResponseData?.languageBasedFee ?? [],
                customCountryFeeList: summaryResponseData?.customCountryList ?? []
            };
            const summaryResDataOnStore = {
                ...updatedQuoteOrderData.summaryPage?.responseData.summaryResponse
            }; // existing data on store
            const tablesDataOnStore = {
                countryFeeList: summaryResDataOnStore?.instantCountryList?.countryFeeList ?? [],
                upFee: summaryResDataOnStore?.serviceBasedFee?.upFee ?? [],
                nonupFee: summaryResDataOnStore?.serviceBasedFee?.nonupFee ?? [],
                languageFeeList: summaryResDataOnStore?.languageBasedFee ?? [],
                customCountryFeeList: summaryResDataOnStore?.customCountryList ?? []
            };

            if (JSON.stringify(updatedTablesData) !== JSON.stringify(tablesDataOnStore)) {
                quoteOrderModuleStore.updatePage('formData', {
                    ...updatedQuoteOrderData,
                    summaryPage: updatedData
                });

                await new Promise((r) => setTimeout(r, 100));
                // to trigger the summary page re-render
                quoteOrderModuleStore.updatePage('flags', {
                    ...quoteOrderModuleStore.getData().flags,
                    storeUpdateWithSummaryData: new Date().toISOString()
                });
            }
        }
    };

    /** iterate the countries to find if table cells has invalid/zero values.
     *  #1 -> if cell has invalid values, then update the store with flags to show the errors against each cells.
     *  #2 -> if cell has zero values, just return the flag only as 'true'.
     *      this will trigger confirmation popup to user proceed with 'zero' or can cancel. */
    iterateCountryList();

    // #1
    if (checkIsCountryHasValuesAsZero) {
        toggleLoadingIndicator(false);
        return isCountryHasValuesAsZero;
    }

    // #2
    updateStore();
    toggleLoadingIndicator(false);
    return isCountryHasInvalidValues;
};

// order draft API trigger
const saveDraft = async (viewSummary?: boolean): Promise<string | null> => {
    try {
        const response: { referenceNo: number; requestCurrencyId: number } =
            await selectCountryService.orderSaveDraft();

        if (response) {
            const primaryId = response.referenceNo;
            const requestCurrencyId = response.requestCurrencyId;
            const quoteOrderData: QuoteOrderModuleStore = quoteOrderModuleStore.getData();
            const isEditFlow = quoteOrderData?.info.isEditFlow === true;

            /** in Create-Flow, we pass primaryId as '0' and get the actual 'primaryId' & 'currencyId' in response.
             *  then use that ids for further steps.
             *  in Edit-Flow, we got primaryId and currencyId from the init Edit API response.
             *  then use that ids for further steps and omit the response when we get from the Draft API response. */
            const updatedPrimaryId = isEditFlow ? quoteOrderData?.info.primaryId : primaryId;
            const updatedRequestCurrencyId = isEditFlow
                ? quoteOrderData?.info.requestCurrencyId
                : requestCurrencyId;

            /** this will compare the current flow page data with backup data which is store
             *  and updates the flags for the same on store (flags.pagesMatchStatusWithBackupData). */
            pagesComparisonWithBackupData(quoteOrderData);

            // update store - info
            const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                ...quoteOrderData?.info,
                primaryId: updatedPrimaryId,
                requestCurrencyId: updatedRequestCurrencyId
            };
            quoteOrderModuleStore?.updatePage('info', updatedQuoteOrderInfo); // update store - info

            /** navigation - stepper */
            stepperNavigation();

            /** navigation - URL (page / component) */
            const isLastStep = stepperStore.getIsLastStepper(STEPPER_TYPE_ID.SELECT_COUNTRY);
            const stepperData = stepperStore.getStepperData();
            const currentFlow = isEditFlow ? PATHS.EDIT : PATHS.CREATE;
            const redirectTo: string | null = updatedPrimaryId
                ? `/${PATHS.ORDER_QUOTE}/${currentFlow}/${viewSummary ? PATHS.SUMMARY : stepperData?.stepperInfo?.currStep?.stepperPath}`
                : null;
            return isLastStep ? 'IS_FINAL_STEP' : redirectTo;
        } else return null;
    } catch (error) {
        // TODO: add toast message while API fails
        console.error('Error while saving draft:', error);
        return null;
    }
};

const orderQuoteModuleService = {
    // helpers
    getGrandTotal,

    // users/roles
    getSalesRepList,
    getProjectManagersList,
    setAdditionalInfoPM,

    // stepper
    addMoreStepInStepper,
    removeStepInStepper,
    stepperNavigation,

    // backup data and manipulate
    backupDataToStore,
    pagesComparisonWithBackupData,

    // table validation
    checkSummaryTablesHasInvalidValues,

    // save-draft
    saveDraft
};
export default orderQuoteModuleService;
