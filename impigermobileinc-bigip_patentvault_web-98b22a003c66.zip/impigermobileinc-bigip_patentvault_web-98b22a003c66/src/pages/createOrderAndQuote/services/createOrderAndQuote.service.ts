import { END_POINT } from 'constants/endPoint';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import HttpService from 'core/interceptor/api.handler';
import {
    CountryConfig,
    SelectCountryData,
    CountryDataForPostAPI,
    LanguageBasedFeeList
} from 'pages/orders/selectCountry/types/country.type';
import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_DATA
} from 'constants/progressStepper.constant';
import {
    CountryList,
    DisclaimerList,
    SummaryMetaData,
    SummaryResponse
} from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { LANGUAGE_ID, MODE, PATENT_SOURCE_LANGUAGE } from 'constants/app.constant';
import orderQuoteDetailsService from '../components/standard/orderQuoteDetails/services/orderQuoteDetails.service';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import summaryService from '../components/summary/services/summary.service';
import utils, { formatDateYYMMDD } from 'core/utils/utils';
import {
    OrderResponseMustHaveProps,
    OrderSave,
    OrderSaveResponse
} from 'pages/ordersAndQuotes/types/ordersAndQuotes.types';
import orderQuoteModuleService from './orderQuoteModule.service';
import AuthStore from 'core/store/authStore/authStore';
import { isContactUser } from 'core/utils/utils';

const _httpService = new HttpService();
const baseURL: string | null = process.env.REACT_APP_QUOTE_BASE_URL ?? null;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

// variables
let selectedCountriesList: CountryDataForPostAPI[] = [];

// helper function
const parseFee = (fee: string | null): number => (fee ? parseFloat(fee) : 0);
const getDisclaimerInfoList = (quoteOrderData: QuoteOrderModuleStore) => {
    try {
        const summaryPage: SummaryMetaData | null = quoteOrderData.formData.summaryPage;

        /** just append the 'custom-disclaimer' in 'disclaimerList' on payload.
         *  also, add the 'instruction' in 'customDisclaimer' object.
         *  if user not added 'custom-disclaimer' means, then construct 'custom-disclaimer' and append the 'instruction' into that. */
        const disclaimerList = [
            ...(summaryPage?.responseData.summaryResponse?.disclaimerList ?? [])
        ];
        const customDisclaimer = summaryPage?.customDisclaimer;

        const constructCustomDisclaimerWithInstruction: DisclaimerList = {
            sNo: disclaimerList?.length > 0 ? disclaimerList.length + 1 : 1,
            disclaimer: '',
            isCustomDisclaimer: true,
            customInstruction: summaryPage?.instruction ?? null
        };
        const updatedCustomDisclaimer: DisclaimerList = customDisclaimer
            ? { ...customDisclaimer, customInstruction: summaryPage?.instruction ?? null }
            : constructCustomDisclaimerWithInstruction;

        disclaimerList.push(updatedCustomDisclaimer);

        return disclaimerList;
    } catch (error) {
        console.error(`Error in getDisclaimerInfoList(): ${error}`);
    }
};
const getCountryListForNonEP = (quoteOrderData: QuoteOrderModuleStore) => {
    try {
        /** PCT - get the InstantCountryList (country-page), compare that with CountryFeeList (summary-page).
            just append these 'agencyFee'/'officialFee'/'translationFee'/'total' to the matched InstantCountry object. */

        const summaryResponse = quoteOrderData.formData.summaryPage?.responseData.summaryResponse;
        const selectCountryPage = quoteOrderData.formData.selectCountryPage;
        const countryFeeList: CountryList[] | null =
            summaryResponse?.instantCountryList.countryFeeList ?? null;
        const customCountryList: CountryList[] | null = summaryResponse?.customCountryList ?? null;

        // instant countries
        selectCountryPage?.instantCountries?.map((instantCountry: CountryConfig) => {
            if (!instantCountry.isSelected) return;

            const countryData: SelectCountryData = instantCountry.data;

            const countryFee: CountryList | null =
                countryFeeList?.find((country) => country.countryId === countryData.id) ?? null;

            if (!countryFee) return;

            const updatedInstantCountry: CountryDataForPostAPI = {
                countryId: countryData.id ?? 0,
                languageId: countryData.languageId ?? 0,
                entityType: instantCountry.selectedWipoEntityId ?? 0,
                agencyFee: countryFee?.agencyFee ? parseFloat(countryFee.agencyFee) : 0,
                officialFee: countryFee?.officialFee ? parseFloat(countryFee.officialFee) : 0,
                translationFee: countryFee?.translationFee
                    ? parseFloat(countryFee.translationFee)
                    : 0,
                total: countryFee?.total ? parseFloat(countryFee.total) : 0,
                isUserPreferredAiTranslation: countryFee.isUserPreferredAiTranslation
            };

            selectedCountriesList.push(updatedInstantCountry);
        });

        // adding english line item
        countryFeeList
            ?.filter((country) => country.countryId === null || country.countryId === 0)
            .map((countryData: CountryList) => {
                const updatedInstantCountry: CountryDataForPostAPI = {
                    countryId: countryData.countryId ?? 0,
                    languageId: countryData.languageId ?? 0,
                    agencyFee: countryData?.agencyFee ? parseFloat(countryData.agencyFee) : 0,
                    officialFee: countryData?.officialFee ? parseFloat(countryData.officialFee) : 0,
                    translationFee: countryData?.translationFee
                        ? parseFloat(countryData.translationFee)
                        : 0,
                    total: countryData?.total ? parseFloat(countryData.total) : 0,
                    isUserPreferredAiTranslation: countryData.isUserPreferredAiTranslation
                };

                selectedCountriesList.push(updatedInstantCountry);
            });

        // custom countries
        selectCountryPage?.customCountries?.map((customCountry: CountryConfig) => {
            if (!customCountry.isSelected) return;

            const countryData: SelectCountryData = customCountry.data;

            const customCountryFee: CountryList | null =
                customCountryList?.find((country) => country.countryId === countryData.id) ?? null;

            if (!customCountryFee) return;

            const updatedCustomCountry: CountryDataForPostAPI = {
                ...customCountry.data,
                countryId: countryData.id ?? 0,
                languageId: countryData.languageId ?? 0,
                entityType: customCountry.selectedWipoEntityId ?? 0,
                agencyFee: +(customCountryFee?.agencyFee ?? '0'),
                officialFee: +(customCountryFee?.officialFee ?? '0'),
                translationFee: +(customCountryFee?.translationFee ?? '0'),
                total: +(customCountryFee?.total ?? '0'),
                isCustomCountry: true,
                isUserPreferredAiTranslation: customCountryFee.isUserPreferredAiTranslation
            };

            selectedCountriesList.push(updatedCustomCountry);
        });
    } catch (error) {
        console.error(`Error in getCountryListForNonEp() : ${error}`);
    }
};
const getCountryListForEP = (params: any) => {
    try {
        const data = {
            countryId: 0,
            entityType: 0,
            EP: null,
            UP: null,
            agencyFee: 0,
            officialFee: 0,
            translationFee: 0,
            total: 0,
            isUserPreferredAiTranslation: null
        };
        const isUP: boolean | null =
            params?.quoteOrderData?.formData?.summaryPage?.flags?.IsUp ?? null;
        const patentDetailsPage = params?.quoteOrderData.formData.patentDetailsPage;
        const selectCountryPageForEP = params?.quoteOrderData.formData.selectCountryPageForEP;
        const summaryResponse: SummaryResponse | null =
            params?.quoteOrderData.formData.summaryPage?.responseData.summaryResponse ?? null;
        const countryFeeList: CountryList[] | null =
            summaryResponse?.instantCountryList.countryFeeList ?? null;
        const isEpTranslationAndValidation =
            params?.quoteOrderData.info.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];
        const isEpTranslationOnly =
            quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'];
        let upCountryFeeList: CountryList[] | null = [];
        const upFees = summaryResponse?.serviceBasedFee?.upFee;
        const nonUpFees = summaryResponse?.serviceBasedFee?.nonupFee;
        if (
            isUP &&
            params?.quoteOrderData.formData.summaryPage &&
            params?.quoteOrderData.formData.summaryPage.responseData.summaryResponse
        ) {
            upCountryFeeList =
                params?.quoteOrderData.formData.summaryPage.responseData.summaryResponse
                    .serviceBasedFee.nonupFee;
        }

        // TODO:
        // const nonEPFeeList: CountryList[] | null =
        //     summaryResponse?.serviceBasedFee.nonupFee ?? null;
        let languageBasedFee: CountryList[] | null = summaryResponse?.languageBasedFee ?? null;

        if (
            params?.isOrderCreationMode &&
            params?.is713Claims &&
            params?.summaryAPIResponse !== null
        ) {
            languageBasedFee = params?.summaryAPIResponse?.languageBasedFee;
        }
        const isSubmitOrder = params?.quoteOrderData.info.approveStatus === 2;

        selectCountryPageForEP?.countryList?.map((epCountry: CountryConfig) => {
            if (!epCountry?.isSelected) return;

            const countryData: SelectCountryData = epCountry.data;

            let epCountryFee: CountryList | null =
                countryFeeList?.find(
                    (country: CountryList) => country.countryId === countryData.id
                ) ?? null;

            if (isUP) {
                epCountryFee =
                    upCountryFeeList?.find(
                        (country: CountryList) => country.countryId === countryData.id
                    ) ?? epCountryFee;
            }

            selectedCountriesList.push({
                countryId: countryData.id,
                languageId: countryData.languageId,
                entityType: epCountry.selectedWipoEntityId ?? 0,
                EP: true,
                UP: countryData.up === null ? false : countryData.up,
                isClaim: false,
                agencyFee: epCountryFee?.agencyFee ? parseFloat(epCountryFee.agencyFee) : 0,
                officialFee: epCountryFee?.officialFee ? parseFloat(epCountryFee.officialFee) : 0,
                translationFee: epCountryFee?.translationFee
                    ? parseFloat(epCountryFee.translationFee)
                    : 0,
                total: epCountryFee?.total ? parseFloat(epCountryFee.total) : 0,
                isUserPreferredAiTranslation: epCountryFee?.isUserPreferredAiTranslation ?? null
            });
        });

        // adding english line item
        if (
            ((MODE.CREATE_QUOTE === params?.quoteOrderData.info.mode ||
                MODE.EDIT_QUOTE === params?.quoteOrderData.info.mode) &&
                !isSubmitOrder) ||
            !isUP
        ) {
            countryFeeList
                ?.filter(
                    (country) =>
                        (country.countryId === null || country.countryId === 0) &&
                        country.languageId === LANGUAGE_ID.ENGLISH
                )
                .map((countryData: CountryList) => {
                    const updatedInstantCountry: CountryDataForPostAPI = {
                        countryId: countryData.countryId ?? 0,
                        languageId: countryData.languageId ?? 0,
                        EP: true,
                        UP: false,
                        agencyFee: countryData.agencyFee ? parseFloat(countryData.agencyFee) : 0,
                        officialFee: countryData.officialFee
                            ? parseFloat(countryData.officialFee)
                            : 0,
                        translationFee: countryData.translationFee
                            ? parseFloat(countryData.translationFee)
                            : 0,
                        total: countryData.total ? parseFloat(countryData.total) : 0,
                        isUserPreferredAiTranslation:
                            countryData.isUserPreferredAiTranslation ?? null
                    };

                    selectedCountriesList.push(updatedInstantCountry);
                });
        }

        if (
            params?.quoteOrderData.info.selectedCategory?.patentCategoryId !==
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal
        ) {
            selectCountryPageForEP?.countryList?.map((epCountry: CountryConfig) => {
                const countryData: SelectCountryData = epCountry.data;

                if (!epCountry || !epCountry.isUpSelected || !countryData.up) return;

                const epCountryFee: CountryList | null =
                    countryFeeList?.find(
                        (country: CountryList) => country.countryId === countryData.id
                    ) ?? null;

                selectedCountriesList.push({
                    countryId: countryData.id,
                    languageId: countryData.languageId,
                    entityType: epCountry.selectedWipoEntityId ?? 0,
                    EP: false,
                    UP: countryData.up,
                    isClaim: false,
                    isUserPreferredAiTranslation:
                        epCountryFee?.isUserPreferredAiTranslation ?? null,
                    agencyFee: (() => {
                        const isAgencyFeeApplicable = isEpTranslationAndValidation
                            ? upFees?.some((fee) => fee.languageName === 'UP Agency Fee')
                            : true;
                        return epCountryFee?.agencyFee && isAgencyFeeApplicable
                            ? parseFloat(epCountryFee.agencyFee)
                            : 0;
                    })(),
                    officialFee: (() => {
                        if (epCountryFee?.officialFee) {
                            if (isEpTranslationAndValidation) {
                                return 0;
                            } else {
                                return parseFloat(epCountryFee.officialFee);
                            }
                        }
                        return 0;
                    })(),
                    translationFee: (() => {
                        if (epCountryFee?.translationFee) {
                            return isEpTranslationAndValidation
                                ? 0
                                : parseFloat(epCountryFee.translationFee);
                        }
                        return 0;
                    })(),
                    total: (() => {
                        if (epCountryFee?.total) {
                            if (isEpTranslationAndValidation) {
                                if (
                                    epCountryFee.agencyFee &&
                                    upFees?.some((fee) => fee.languageName === 'UP Agency Fee')
                                ) {
                                    return parseFloat(epCountryFee.agencyFee);
                                } else {
                                    return 0;
                                }
                            } else {
                                return parseFloat(epCountryFee.total);
                            }
                        }
                        return 0;
                    })()
                });
            });
        }

        // up table related data
        // Update total and translationFee only for countries that meet the condition

        const unitaryPatentFee = upFees?.find((fee) => fee.languageName === 'UP Agency Fee');
        const otherLanguageFees = upFees?.filter((fee) => fee.languageName !== 'UP Agency Fee');
        const EpOtherLanguageFees = upFees?.filter(
            (fee) =>
                fee.languageName !== 'UP Agency Fee' &&
                fee.languageId === params?.quoteOrderData?.formData?.summaryPage?.selectedLanguage
        );
        const EpNonUpLanguageFees = nonUpFees?.filter(
            (fee) => (fee.countryId === null || fee.countryId === 0) && fee.languageId
        );
        const EpNonUpDiscountFees = nonUpFees?.filter(
            (fee) => fee.countryId === null && fee.languageId === null
        );
        const isFrenchPatent =
            patentDetailsPage?.sourceLanguage.toUpperCase() === PATENT_SOURCE_LANGUAGE.FRENCH;
        const isEnglishPatent =
            patentDetailsPage?.sourceLanguage.toUpperCase() === PATENT_SOURCE_LANGUAGE.ENGLISH;
        const isGermanPatent =
            patentDetailsPage?.sourceLanguage.toUpperCase() === PATENT_SOURCE_LANGUAGE.GERMANY;

        if (isFrenchPatent || isGermanPatent) {
            EpNonUpLanguageFees?.forEach((fee) => {
                selectedCountriesList.push({
                    countryId: null, // Adjust as needed
                    languageId: fee?.languageId ?? 0,
                    entityType: 0, // Adjust as needed
                    EP: true,
                    UP: true,
                    isClaim: false,
                    agencyFee: parseFee(fee.agencyFee),
                    officialFee: parseFee(fee.officialFee),
                    translationFee: parseFee(fee.translationFee),
                    total: parseFee(fee.total)
                });
            });
        }

        if (
            isEnglishPatent &&
            params?.quoteOrderData?.formData?.summaryPage?.responseData?.languageList.some(
                (lang: LanguageBasedFeeList) => lang.targetLanguageId === LANGUAGE_ID.SPANISH
            ) &&
            params?.quoteOrderData?.formData?.summaryPage?.selectedLanguage === LANGUAGE_ID.SPANISH
        ) {
            EpNonUpDiscountFees?.forEach((fee) => {
                selectedCountriesList.push({
                    countryId: null, // Adjust as needed
                    languageId: null,
                    entityType: 0, // Adjust as needed
                    EP: true,
                    UP: true,
                    isClaim: false,
                    agencyFee: parseFee(fee.agencyFee),
                    officialFee: parseFee(fee.officialFee),
                    translationFee: parseFee(fee.translationFee),
                    total: parseFee(fee.total)
                });
            });
        } else if (!isEnglishPatent) {
            EpNonUpDiscountFees?.forEach((fee) => {
                selectedCountriesList.push({
                    countryId: null, // Adjust as needed
                    languageId: null,
                    entityType: 0, // Adjust as needed
                    EP: null,
                    UP: null,
                    isClaim: false,
                    agencyFee: parseFee(fee.agencyFee),
                    officialFee: parseFee(fee.officialFee),
                    translationFee: parseFee(fee.translationFee),
                    total: parseFee(fee.total)
                });
            });
        }

        if (unitaryPatentFee) {
            selectedCountriesList.forEach((country: CountryDataForPostAPI) => {
                const upCountry: CountryConfig | null =
                    selectCountryPageForEP?.countryList?.find(
                        (item: CountryConfig) => item.data.id === country.countryId
                    ) ?? null;

                const countryData = upCountry?.data as SelectCountryData;
                if (upCountry && upCountry.isUpSelected && countryData.up && !country.EP) {
                    country.officialFee = parseFee(unitaryPatentFee.officialFee);
                    country.agencyFee = parseFee(unitaryPatentFee.agencyFee);
                    country.total = parseFee(unitaryPatentFee.total);
                    country.translationFee = parseFee(unitaryPatentFee.translationFee);
                }
            });
        }

        if (isEpTranslationAndValidation || isEpTranslationOnly) {
            EpOtherLanguageFees?.forEach((fee) => {
                if (fee.isSelected) {
                    selectedCountriesList.push({
                        countryId: null, // Adjust as needed
                        languageId: fee?.languageId ?? 0,
                        entityType: 0, // Adjust as needed
                        EP: false,
                        UP: true,
                        isClaim: false,
                        agencyFee: parseFee(fee.agencyFee),
                        officialFee: parseFee(fee.officialFee),
                        translationFee: parseFee(fee.translationFee),
                        total: parseFee(fee.total)
                    });
                }
            });
        } else {
            otherLanguageFees?.forEach((fee) => {
                if (fee.isSelected) {
                    selectedCountriesList.push({
                        countryId: null, // Adjust as needed
                        languageId: fee?.languageId ?? 0,
                        entityType: 0, // Adjust as needed
                        EP: false,
                        UP: true,
                        isClaim: false,
                        agencyFee: parseFee(fee.agencyFee),
                        officialFee: parseFee(fee.officialFee),
                        translationFee: parseFee(fee.translationFee),
                        total: parseFee(fee.total)
                    });
                }
            });
        }

        // update language
        // 71 3 claims related data
        if (patentDetailsPage?.english) {
            const englishData = languageBasedFee?.find(
                (item) => item.languageId === LANGUAGE_ID.ENGLISH
            );
            selectedCountriesList.push({
                ...data,
                languageId: englishData?.languageId ?? 0,
                isClaim: true,
                translationFee:
                    (englishData &&
                        parseFloat(
                            englishData?.translationFee ? englishData?.translationFee : '0'
                        )) ??
                    0,
                total:
                    (englishData &&
                        parseFloat(
                            englishData?.translationFee ? englishData?.translationFee : '0'
                        )) ??
                    0,
                isUserPreferredAiTranslation: englishData?.isUserPreferredAiTranslation ?? null
            });
        }
        if (patentDetailsPage?.german) {
            const germanData = languageBasedFee?.find(
                (item) => item.languageId === LANGUAGE_ID.GERMAN
            );
            selectedCountriesList.push({
                ...data,
                languageId: germanData?.languageId ?? 0,
                isClaim: true,
                translationFee:
                    (germanData &&
                        parseFloat(
                            germanData?.translationFee ? germanData?.translationFee : '0'
                        )) ??
                    0,
                total:
                    (germanData &&
                        parseFloat(
                            germanData?.translationFee ? germanData?.translationFee : '0'
                        )) ??
                    0,
                isUserPreferredAiTranslation: germanData?.isUserPreferredAiTranslation ?? null
            });
        }
        if (patentDetailsPage?.french) {
            const frenchData = languageBasedFee?.find(
                (item) => item.languageId === LANGUAGE_ID.FRENCH
            );
            selectedCountriesList.push({
                ...data,
                languageId: frenchData?.languageId ?? 0,
                isClaim: true,
                translationFee:
                    (frenchData &&
                        parseFloat(
                            frenchData?.translationFee ? frenchData?.translationFee : '0'
                        )) ??
                    0,
                total:
                    (frenchData &&
                        parseFloat(
                            frenchData?.translationFee ? frenchData?.translationFee : '0'
                        )) ??
                    0,
                isUserPreferredAiTranslation: frenchData?.isUserPreferredAiTranslation ?? null
            });
        }
    } catch (error) {
        console.error(`Error in getCountryListForEP() : ${error}`);
    }
};
const getPatentCountrySummaryList = (
    quoteOrderData: QuoteOrderModuleStore,
    summaryAPIResponse: SummaryResponse | null,
    isOrderCreationMode: boolean,
    is713Claims: boolean
) => {
    const params = {
        quoteOrderData,
        summaryAPIResponse,
        isOrderCreationMode,
        is713Claims
    };
    try {
        selectedCountriesList = [];
        const isEPFlow =
            quoteOrderData.info.selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent;
        isEPFlow ? getCountryListForEP(params) : getCountryListForNonEP(quoteOrderData);

        return selectedCountriesList;
    } catch (error) {
        console.error(`Error in getPatentCountrySummaryList(): ${error}`);
    }
};
const getDateTime = (pageData: any, key: string) => {
    const date = pageData && pageData[key];
    if (date && date !== '') return formatDateYYMMDD(date as string);
    return null;
};
const getSumTotal = (summaryResponseData: SummaryResponse) => {
    if (!summaryResponseData || !summaryResponseData.languageBasedFee) {
        return null;
    }

    let total = 0;
    summaryResponseData.languageBasedFee.forEach((item: CountryList) => {
        return (total += parseFloat(item.total ?? '0'));
    });

    return total;
};
const isEPRenewals = (quoteOrderData: QuoteOrderModuleStore): boolean => {
    // function for to find selected service category is ep-renewals
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId as number;
    return selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].Renewals;
};
export const exportActions = <T extends OrderResponseMustHaveProps>(
    response: OrderSaveResponse<T>
) => {
    if (Array.isArray(response?.pdfFiles) && response?.pdfFiles.length > 0) {
        response?.pdfFiles.forEach((file) => {
            // Check if 'pdfFile' exists and is a non-empty string
            if ('pdfFile' in file && typeof file?.pdfFile === 'string' && file?.pdfFile) {
                // Convert base64 string to Blob
                const pdfFile: string = file?.pdfFile;
                const pdfBlob = utils.base64toBlob(pdfFile);
                // Use provided file name or default to 'download.pdf'
                const fileName: string =
                    'Quote - ' + response?.orderResponse?.orderRequestNumber || 'download.pdf';
                // Download the Blob
                utils.downloadBlob(pdfBlob, fileName);
            }
        });
    }

    // Check if 'excelFiles' exists and is an array
    if (Array.isArray(response?.excelFiles) && response?.excelFiles.length > 0) {
        response?.excelFiles.forEach((file) => {
            // Check if 'excelFile' exists and is a non-empty string
            if ('excelFile' in file && typeof file.excelFile === 'string' && file.excelFile) {
                // Convert base64 string to Blob
                const excelFile: string = file.excelFile;
                const excelBlob = utils.base64toBlobForExcel(excelFile);
                // Use provided file name or default to 'download.xlsx'
                const fileName: string =
                    'Quote - ' + response?.orderResponse?.orderRequestNumber || 'download.xlsx';
                // Download the Blob
                utils.downloadBlob(excelBlob, fileName);
            }
        });
    }
};

// construct data for POST api
const prepareData = async (quoteOrderData: QuoteOrderModuleStore) => {
    const userInfo = AuthStore.getUserInfo().userInfo;
    const userRoleId = userInfo?.roleId;
    const isThisContactUser = isContactUser(userRoleId);
    const mode = quoteOrderData?.info.mode;
    const isQuoteCreationMode = mode === MODE.CREATE_QUOTE;
    const isOrderCreationMode = mode === MODE.CREATE_ORDER;
    const selectedServiceId = quoteOrderData.info.selectedService?.serviceTypeId;
    const selectedCategoryId = quoteOrderData.info.selectedCategory?.patentCategoryId;
    const parentId = quoteOrderData.info.selectedCategory?.parentId;
    const stepperList = stepperStore.getStepperData().stepperList;

    const additionalInfo = quoteOrderData.formData.additionalInfoPage;
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;
    const selectCountryPageForEP = quoteOrderData.formData.selectCountryPageForEP;
    const summaryPage: SummaryMetaData | null = quoteOrderData.formData.summaryPage;
    let summaryAPIResponse: SummaryResponse | null = null;

    const primaryId = quoteOrderData.info.primaryId ?? null;
    const isEditFlow = quoteOrderData.info.isEditFlow === true;
    const isEPFlow = selectedServiceId === SERVICE_TYPE_ID.european_patent;
    const isUP: boolean | null = summaryPage?.flags?.IsUp ?? null;
    const isEP713Claims =
        selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['71_3_claims'];
    const isEPRecordals =
        selectedCategoryId === CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal;
    const isUPCountrySelected = selectCountryPageForEP?.countryList?.some(
        (country) => country.data.up === true && country.isUpSelected === true
    );
    // helpers
    const deliverTo = additionalInfo?.deliverTo as any[]; // deliverTO
    if (deliverTo && deliverTo.length > 0) {
        deliverTo.forEach((mail: { email: any }) => {
            return mail.email;
        });
    }
    const checkManualFeesUpdationNeeded = () => {
        return (
            (isThisContactUser &&
                (isQuoteCreationMode || isOrderCreationMode) &&
                parentId === SERVICE_TYPE_ID.paris_convention_treaty) ||
            !isSummaryExists // if summary page not exists then call API manually
        );
    };
    const getAssignPM = (projectManager: any) => {
        /** this function will gives the valid number[].
         *  i.e. [123, { id: 789 }, null, undefined, { id: null }] // output: [123, 789] */

        const filteredIds =
            projectManager
                ?.filter(
                    (pm: number | object) =>
                        typeof pm === 'number' ||
                        (typeof pm === 'object' &&
                            pm !== null &&
                            'id' in pm &&
                            typeof (pm as { id: unknown }).id === 'number')
                )
                .map((pm: number | object) =>
                    typeof pm === 'number' ? pm : (pm as { id: number }).id
                ) ?? null;

        return filteredIds;
    };

    /** in some scenario 'Summary-Page' not there, in this case we should call API manually and send to the Submission API. */
    let disclaimer = '';
    const isSummaryExists =
        stepperList?.some((step) => step.stepperId === STEPPER_DATA.SUMMARY.stepperId) ?? false;
    if (primaryId && !isSummaryExists) {
        disclaimer = await orderQuoteDetailsService.getDisclaimers(primaryId);
    }

    const isManualFeesUpdationNeeded = checkManualFeesUpdationNeeded();

    if ((isOrderCreationMode && isEP713Claims) || isManualFeesUpdationNeeded) {
        summaryAPIResponse = await summaryService.getSummaryPageData();
    }

    // construct data for POST api
    try {
        let preparedData: object = {
            referenceNo: primaryId,
            quoteStatus: quoteOrderData.info.approveStatus,
            requestCurrencyId:
                summaryPage?.selectedCurrency?.currencyId ?? quoteOrderData.info.requestCurrencyId,
            validationDeadline: patentDetailsPage?.validationDeadline ?? null,
            filingDeadLine: patentDetailsPage?.filingDeadLine ?? null,

            // totals
            grandTotal:
                isOrderCreationMode && isEP713Claims
                    ? getSumTotal(summaryAPIResponse as SummaryResponse)
                    : orderQuoteModuleService.getGrandTotal(summaryPage, isEPFlow, isUP),
            UpGrandTotal: summaryPage?.totals?.nationalValidationUP.up ?? 0, // up
            NonUpGrandTotal: summaryPage?.totals?.nationalValidationUP.nonUP ?? 0, // non-up
            ClaimGrandTotal: summaryPage?.totals?.nationalValidationUP.languageFeeTotal ?? 0, // languages
            EpGrandTotal: summaryPage?.totals?.nationalValidation.countryFeeTotal ?? 0,
            epLanguageTotal: summaryPage?.totals?.nationalValidation.languageFeeTotal ?? 0,

            totalBillAmountUP: summaryPage?.totals?.nationalValidationUP.up ?? 0,
            totalBillAmountNonUP: summaryPage?.totals?.nationalValidationUP.nonUP ?? 0,
            orderNumber: 0,
            totalWordCount: patentDetailsPage?.totalWordCount ?? 0,
            claimsPriority: true,
            specialInstructions: patentDetailsPage?.specialInstructions ?? '',
            isClaims71_3:
                isOrderCreationMode && isEP713Claims ? true : patentDetailsPage?.ifEpGrantedYesNo,
            IsUp:
                (isOrderCreationMode && isEP713Claims) || isEPRenewals(quoteOrderData)
                    ? false
                    : isEPRecordals
                      ? null
                      : isUP,
            orderDate: new Date(),
            completedDate: null,
            instructionByContactUser: '',
            instructionByPM: '',
            assignPM: getAssignPM(additionalInfo?.projectManager),
            additionalInfo: {
                referenceNumber: patentDetailsPage?.referenceNo ?? '',
                emailID: additionalInfo?.emailID ?? '',
                deliverTo: (deliverTo && deliverTo.length > 0 ? deliverTo.join() : '') ?? '',
                mailCC: additionalInfo?.cc ?? '',
                po: additionalInfo?.po ?? '',
                instructionByContactUser: additionalInfo?.instructionByContactUser ?? '',
                instructionByPM: additionalInfo?.instructionByProjectManager ?? '',
                requestedDeliveryDate: getDateTime(patentDetailsPage, 'requestedDeliveryDate'),
                quoteTargetDate: getDateTime(additionalInfo, 'quoteTargetDate')
            },
            disclaimerInfoList: isSummaryExists
                ? getDisclaimerInfoList(quoteOrderData)
                : disclaimer,
            patentCountrySummaryList: getPatentCountrySummaryList(
                quoteOrderData,
                summaryAPIResponse,
                isOrderCreationMode,
                isEP713Claims
            ),
            isAmendQuote: isEditFlow,
            isBothDecideLater:
                summaryPage?.flags?.isBothDecideLater && isUPCountrySelected ? true : null,
            epUpGrandTotal: {
                claimsTotal: summaryPage?.totals?.nationalValidationUP.languageFeeTotal ?? 0,
                epTotal: summaryPage?.totals?.nationalValidation.countryFeeTotal ?? 0,
                upTotal:
                    (summaryPage?.totals?.nationalValidationUP.up ?? 0) +
                    (summaryPage?.totals?.nationalValidationUP.nonUP ?? 0)
            }
        };

        if (isManualFeesUpdationNeeded) {
            preparedData = updatedPreparedDataWithFees(preparedData, summaryAPIResponse);
        }
        return preparedData;
    } catch (error) {
        console.error(`Error in prepareData(): ${error}`);
    }
};

const updatedPreparedDataWithFees = (preparedData: any, summaryResponse: any) => {
    try {
        const countryFeeList = [...(summaryResponse?.instantCountryList?.countryFeeList ?? [])];
        const customCountryFeeList = [...(summaryResponse?.customCountryList ?? [])];
        const preparedList = [...(preparedData?.patentCountrySummaryList ?? [])];

        /** compare the 'countryFeeList' with 'preparedCountryList', before construct the 'instantCountryList'. */
        const updatedCountryFeeList = countryFeeList.filter(
            (country: any) =>
                !preparedList.some((item: any) => item.countryId === country.countryId)
        );
        const instantCountryList = (updatedCountryFeeList || []).map((country: any) => {
            if (country)
                return {
                    agencyFee: parseFee(country.agencyFee as string),
                    countryId: country.countryId,
                    entityType: parseFee(country.entityType as string),
                    languageId: parseFee(country.languageId as string),
                    officialFee: parseFee(country.officialFee as string),
                    total: parseFee(country.total as string),
                    translationFee: parseFee(country.translationFee as string),
                    isUserPreferredAiTranslation: country.isUserPreferredAiTranslation ?? null
                };
            else return {};
        });

        const customCountryList = customCountryFeeList.map((country: any) => {
            if (country)
                return {
                    agencyFee: parseFee(country.agencyFee as string),
                    countryId: country.countryId,
                    entityType: parseFee(country.entityType as string),
                    languageId: parseFee(country.languageId as string),
                    officialFee: parseFee(country.officialFee as string),
                    total: parseFee(country.total as string),
                    translationFee: parseFee(country.translationFee as string),
                    isUserPreferredAiTranslation: country.isUserPreferredAiTranslation ?? null
                };
            else return {};
        });

        // Combine both lists
        preparedData.patentCountrySummaryList = [
            ...preparedData.patentCountrySummaryList,
            ...instantCountryList,
            ...customCountryList
        ];

        if (summaryResponse.grandTotal) {
            preparedData.EpGrandTotal = summaryResponse.grandTotal;
            preparedData.grandTotal = summaryResponse.grandTotal;
        }

        return preparedData;
    } catch (error) {
        console.error('Error in updatedPreparedDataWithFees:', error);
        return preparedData;
    }
};

// api
const orderSave = async <T extends OrderSaveResponse<OrderSave>>(
    exportType: number | null = null
): Promise<OrderSaveResponse<OrderSave>> => {
    try {
        /** We use this same service to trigger 'Save' \ 'Save with Excel' \ 'Save with PDF'. */
        const apiUrl = exportType
            ? `${END_POINT.ORDER_SAVE}?fileExportType=${exportType}`
            : `${END_POINT.ORDER_SAVE}`;

        const quoteOrderData = quoteOrderModuleStore.getData();
        const orderSaveData = await prepareData(quoteOrderData);

        const response = (await _httpService.post<T, OrderSaveResponse<OrderSave>>(
            apiUrl,
            orderSaveData as T,
            {},
            false,
            baseURL
        )) as OrderSaveResponse<OrderSave>;

        // Check if 'pdfFiles' exists and is an array
        exportActions(response);

        return response;
    } catch (error) {
        console.error(`Error in orderSave(): ${error}`);
        throw error;
    }
};
export const getPDFData = async <T>(templateName: string, isEpOrNonUpPreview?: 'EP' | 'Non-UP') => {
    try {
        const apiUrl = `order/pdf/download?templateName=${templateName}`;
        const quoteOrderData = quoteOrderModuleStore.getData();
        let orderSaveData = await prepareData(quoteOrderData);

        if (isEpOrNonUpPreview) {
            orderSaveData = {
                ...orderSaveData,
                IsUp: isEpOrNonUpPreview === 'EP'
            };
        }

        const response = await _httpService.export<T, T>(
            apiUrl,
            orderSaveData as T,
            {},
            false,
            baseURL
        );
        const fileUrl = window.URL?.createObjectURL(
            new Blob([response as Blob], {
                type: 'application/pdf' // Set the correct MIME type for PDF
            })
        );
        return fileUrl;
    } catch (error) {
        console.error(`Error in download PDF template(): ${error}`);
        throw error;
    }
};

export const createUpcOptOut = async <T>(): Promise<T> => {
    const userInfo = AuthStore.getUserInfo().userInfo;
    const userRoleId = userInfo?.roleId;
    const isThisCUserExcludedSalesRep = isContactUser(userRoleId, true);
    try {
        const quoteOrderModuleData = quoteOrderModuleStore.getData();
        const requestedDeliveryDate =
            quoteOrderModuleData.formData.upcOptOutPage?.requestedDeliveryDate;
        const upcOptOutData = {
            referenceNo: quoteOrderModuleData.info.primaryId ?? 0,
            companyId: quoteOrderModuleData.formData?.companyDetailsPage?.selectedCompany?.id ?? 0,
            contactUserId: isThisCUserExcludedSalesRep
                ? userInfo?.userId
                : (quoteOrderModuleData.formData?.companyDetailsPage?.selectedContact?.id ?? 0),
            requestedDeliveryDate: requestedDeliveryDate
                ? formatDateYYMMDD(requestedDeliveryDate.toDateString())
                : null,
            referenceNumber: quoteOrderModuleData.formData.upcOptOutPage?.referenceNumber || '',
            instructionByContactUser:
                quoteOrderModuleData.formData.upcOptOutPage?.instructionsAndCommentsContactUsers ??
                '',
            instructionByPm:
                quoteOrderModuleData.formData.upcOptOutPage?.instructionsAndCommentsAdminPMUsers ??
                '',
            requestTypeId: quoteOrderModuleData.info.mode ?? 0,
            requestCurrencyId: quoteOrderModuleData.info.requestCurrencyId ?? 0,
            assignPM:
                quoteOrderModuleData.formData?.companyDetailsPage?.selectedContact?.projectManagers?.map(
                    (pm: { id: number }) => pm.id
                ) || [],
            assignSalesRep: quoteOrderModuleData.formData?.companyDetailsPage?.selectedContact
                ?.salesRepId
                ? [quoteOrderModuleData.formData?.companyDetailsPage?.selectedContact?.salesRepId]
                : []
        };

        const apiUrl = `${END_POINT.ORDERS_AND_QUOTES_END_POINT.CREATE_UPC_OPT_OUT}`;
        const response = await _httpService.post<T, T>(
            apiUrl,
            upcOptOutData as T,
            {},
            false,
            baseURL
        );
        return response;
    } catch (error) {
        console.error(`Error in createUpcOptOut(): ${error}`);
        throw error;
    }
};

const orderQuoteServices = { orderSave, getPDFData, exportActions };
export default orderQuoteServices;
