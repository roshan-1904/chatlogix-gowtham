import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { useMemo } from 'react';
import CountryListingEP from './ep/countryListingEP';
import CountryListingNonEP from './pct/countryListingNonEP';
import EpCountryListing from './ep/epCountryListing';

const SelectCountry = () => {
    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const selectedService = quoteOrderData.info.selectedService;
    const selectedCategory = quoteOrderData.info.selectedCategory?.patentCategoryId;
    const isEPTranslationAndValidation =
        selectedCategory ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];

    return (
        <>
            {/* Country selection page is different only for EP\UP */}
            {selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent ? (
                isEPTranslationAndValidation ? (
                    <EpCountryListing />
                ) : (
                    <CountryListingEP />
                )
            ) : (
                <CountryListingNonEP />
            )}
        </>
    );
};

export default SelectCountry;
