import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CustomCountry from './countryEntity'; // Adjust the import path as necessary

describe('Country Component', () => {
    const mockCountry = {
        data: {
            id: 1,
            name: 'United States',
            code: 'US',
            iconName: 'us.png',
            concatCode: '',
            languageId: 1,
            wipoEntitySize: [],
            pcEntitySize: [],
            wipoIq: 1, // PCT
            epoState: 1, // EP
            pcIq: 1, // PC
            up: true
        },
        isSelected: false,
        isUpSelected: false
    };

    const mockSelectedInstantCountryChange = jest.fn();

    it('should display the country name and code', () => {
        render(
            <CustomCountry
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const countryNameElement = screen.getByText(/United States \(US\)/i);
        expect(countryNameElement).toBeInTheDocument();
    });

    it('should call selectedInstantCountryChange with correct id when the country is clicked', () => {
        render(
            <CustomCountry
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const countryDivElement = screen.getByText(/United States \(US\)/i);
        fireEvent.click(countryDivElement);
        waitFor(() => {
            expect(mockSelectedInstantCountryChange).toHaveBeenCalledWith(mockCountry.data.id);
        });
        // Update the expected argument to the correct id
    });

    it('should filter out the country based on filteredInstant', () => {
        render(
            <CustomCountry
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant="Canada"
            />
        );
        waitFor(() => {
            const countryNameElement = screen.queryByText(/United States \(US\)/i);
            expect(countryNameElement).not.toBeInTheDocument();
        });
    });

    it('should show the correct background color when selected', () => {
        const selectedCountry = {
            ...mockCountry,
            isSelected: true
        };

        render(
            <CustomCountry
                country={selectedCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );
        waitFor(() => {
            const countryDivElement = screen.getByText(/United States \(US\)/i).parentElement;
            expect(countryDivElement).toHaveClass('bg-sky-100');
        });
    });

    it('should check the checkbox when the country is selected', () => {
        const selectedCountry = {
            ...mockCountry,
            isSelected: true
        };

        render(
            <CustomCountry
                country={selectedCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );
        waitFor(() => {
            const checkbox = screen.getByTestId('CountryEntity');
            expect(checkbox).toBeChecked();
        });
    });

    it('should call selectedInstantCountryChange when checkbox is clicked', () => {
        render(
            <CustomCountry
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const checkbox = screen.getByTestId('CountryEntity');
        fireEvent.click(checkbox);
        waitFor(() => {
            expect(mockSelectedInstantCountryChange).toHaveBeenCalledWith(mockCountry.data.id);
        });
    });
});
