// import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Country from './country'; // Adjust the import path as necessary
import { CountryConfig } from '../../types/country.type';

describe('Country Component', () => {
    const mockCountry: CountryConfig = {
        data: {
            id: 1,
            name: 'United States',
            code: 'US',
            iconName: 'us.png',
            concatCode: '',
            languageId: 1,
            wipoEntitySize: [],
            pcEntitySize: [],
            wipoIq: 1, // PCT
            epoState: 1, // EP
            pcIq: 1, // PC
            up: true
        },
        isSelected: false,
        isUpSelected: false
    };

    const mockSelectedInstantCountryChange = jest.fn();

    test('should display the country name and code', () => {
        render(
            <Country
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const countryNameElement = screen.getByText(/United States \(US\)/i);
        expect(countryNameElement).toBeInTheDocument();
    });

    test('should call selectedInstantCountryChange with correct id when the country is clicked', () => {
        render(
            <Country
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const countryDivElement = screen.getByText(/United States \(US\)/i);
        fireEvent.click(countryDivElement);

        expect(mockSelectedInstantCountryChange).toHaveBeenCalledWith(1);
    });

    test('should filter out the country based on filteredInstant', () => {
        render(
            <Country
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant="Canada"
            />
        );

        const countryNameElement = screen.queryByText(/United States \(US\)/i);
        expect(countryNameElement).not.toBeInTheDocument();
    });

    test('should show the correct background color when selected', () => {
        const selectedCountry = {
            ...mockCountry,
            isSelected: true
        };

        render(
            <Country
                country={selectedCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );
    });

    test('should check the checkbox when the country is selected', () => {
        const selectedCountry = {
            ...mockCountry,
            isSelected: true
        };

        render(
            <Country
                country={selectedCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const checkbox = screen.getByTestId('instantSelectCountry');
        expect(checkbox).toBeChecked();
    });

    test('should call selectedInstantCountryChange when checkbox is clicked', () => {
        render(
            <Country
                country={mockCountry}
                selectedInstantCountryChange={mockSelectedInstantCountryChange}
                filteredInstant=""
            />
        );

        const checkbox = screen.getByTestId('instantSelectCountry');
        fireEvent.click(checkbox);

        expect(mockSelectedInstantCountryChange).toHaveBeenCalledWith(1);
    });
});
