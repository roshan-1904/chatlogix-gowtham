import { useId, useMemo, useState } from 'react';
import { CountryConfig } from '../../types/country.type';
import { COUNTRY_ENTITY } from '../../constants/country.constant';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';

interface CountryEntityProps {
    country: CountryConfig;
    selectedInstantCountryChange: (
        id: number,
        wipoEntityId: number | null,
        resetEntity?: boolean
    ) => void;
    filteredInstant: string;
}

const CustomCountry: React.FC<CountryEntityProps> = ({
    country = {} as CountryConfig,
    selectedInstantCountryChange,
    filteredInstant
}) => {
    const randomId = useId();
    const [isShowOptions, setIsShowOptions] = useState(false);

    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const selectedService = quoteOrderData?.info.selectedService;
    const isPC = selectedService?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;

    return (
        <>
            {country?.data?.name?.toLowerCase().includes(filteredInstant?.toLowerCase()) && (
                <div className="relative" data-testid="CountryEntity">
                    <div
                        className={`grid grid-cols-8 md:grid-cols-5 rounded-md border-2 px-2 py-1 ${
                            !isShowOptions && country.isSelected
                                ? 'bg-sky-100 border-blue-200'
                                : 'bg-slate-50 border-slate-200'
                        }`}>
                        <div
                            className="col-span-1 flex justify-center items-center"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="instantSelectCountry"
                            onClick={() => setIsShowOptions(!isShowOptions)}>
                            <div className="avatar">
                                <div className="h-6 rounded-full border">
                                    <div
                                        className={`h-full w-full bg-no-repeat bg-center`}
                                        style={{
                                            backgroundImage:
                                                'url(/images/country-flags/' +
                                                country.data.iconName +
                                                ')',
                                            backgroundSize: '150%'
                                        }}></div>
                                </div>
                            </div>
                        </div>
                        <div
                            className="col-span-6 md:col-span-3 flex justify-start items-center cursor-pointer"
                            onKeyDown={() => setIsShowOptions(!isShowOptions)}
                            onClick={() => setIsShowOptions(!isShowOptions)}>
                            <div className="flex gap-2">
                                <span
                                    className={`${
                                        !isShowOptions &&
                                        country.isSelected &&
                                        country.selectedWipoEntityId
                                            ? 'max-w-24'
                                            : 'max-w-32'
                                    } text-sm truncate leading-5 ${!isShowOptions && country.isSelected ? 'font-semibold' : ''}`}>
                                    {country?.data?.name && country?.data?.code
                                        ? `${country.data.name} (${country.data.code})`
                                        : ' -- '}
                                </span>
                                {!isShowOptions &&
                                    country.isSelected &&
                                    country.selectedWipoEntityId && (
                                        <div className="flex items-center justify-center font-semibold bg-white text-red-600 border border-red-600 rounded-full">
                                            <span className="py-[0.125rem] px-[0.275rem] leading-[0]">
                                                {country.selectedWipoEntityId === 1 ? 'S' : 'L'}
                                            </span>
                                        </div>
                                    )}
                            </div>
                        </div>
                        <div className="col-span-1 md:col-span-1 flex justify-center items-center">
                            {country?.isSelected ? (
                                <input
                                    type="checkbox"
                                    id={`country_${country.data.name}`}
                                    checked={country?.isSelected}
                                    onChange={() =>
                                        selectedInstantCountryChange(country.data.id, 0, true)
                                    }
                                    className={`checkbox checkbox-sm cursor-pointer rounded-md ${
                                        country?.isSelected
                                            ? 'border-none checked:bg-sky-500 [--chkbg:theme(colors.sky.500)]'
                                            : 'bg-white border-1 border-slate-400'
                                    }`}
                                    data-testid="instantSelectEntityCountry"
                                />
                            ) : (
                                <i
                                    className={`pi text-sm cursor-pointer ${isShowOptions ? 'pi-chevron-up' : 'pi-chevron-down'}`}
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => setIsShowOptions(!isShowOptions)}
                                    data-testid="entityToggle"></i>
                            )}
                        </div>
                        {/* Radio buttons and labels */}
                        {isShowOptions && (
                            <div className="z-10 w-full absolute top-full left-0 py-2 -mt-1 bg-slate-50 border-2 rounded-sm border-t-0 border-slate-200">
                                <div className="grid grid-cols-5">
                                    {(isPC
                                        ? country.data.pcEntitySize
                                        : country.data.wipoEntitySize
                                    ).map((entityId: number, index: number) => (
                                        <div
                                            key={`Option_${index}_${randomId}`}
                                            className="flex col-start-2 col-span-2 py-3">
                                            <input
                                                type="radio"
                                                id={`radio_${country.data.id}_${entityId}`}
                                                name={`entityRadioGroup_${country.data.id}`}
                                                value={COUNTRY_ENTITY[entityId]?.id}
                                                className="radio-sm cursor-pointer mr-3"
                                                checked={
                                                    COUNTRY_ENTITY[entityId]?.id ===
                                                    country.selectedWipoEntityId
                                                }
                                                onChange={() => {
                                                    selectedInstantCountryChange(
                                                        country.data.id,
                                                        COUNTRY_ENTITY[entityId].id
                                                    );
                                                    setIsShowOptions(!isShowOptions);
                                                }}
                                                data-testid="entityCountryDDRadioOptions"
                                            />
                                            <label
                                                htmlFor={`radio_${country.data.id}_${entityId}`}
                                                className="text-sm cursor-pointer"
                                                onClick={() => {
                                                    selectedInstantCountryChange(
                                                        country.data.id,
                                                        COUNTRY_ENTITY[entityId].id
                                                    );
                                                    setIsShowOptions(!isShowOptions);
                                                }}
                                                onKeyDown={(e) =>
                                                    e.key === 'Enter' && e.currentTarget.click()
                                                }
                                                data-testid="entityCountryDDRadioOptions">
                                                {COUNTRY_ENTITY[entityId]?.name}
                                            </label>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </>
    );
};

export default CustomCountry;
