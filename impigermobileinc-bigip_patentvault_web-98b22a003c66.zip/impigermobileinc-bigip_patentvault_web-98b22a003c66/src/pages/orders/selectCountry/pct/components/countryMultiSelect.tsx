import { useEffect, useRef, useState } from 'react';

import { useTranslation } from 'react-i18next';
import { CountryConfig } from '../../types/country.type';
interface CountryMultiSelectProps {
    customCountries: CountryConfig[];
    selectedCustomCountryCount: number;
    selectedCustomCountryChange: (id: number, isRemove?: boolean) => void;
    getSearchInputCommonStyle: string;
    filteredCustom: string;
    setFilteredCustom: React.Dispatch<React.SetStateAction<string>>;
}

const CountryMultiSelect: React.FC<CountryMultiSelectProps> = ({
    customCountries,
    selectedCustomCountryCount,
    selectedCustomCountryChange,
    getSearchInputCommonStyle,
    filteredCustom,
    setFilteredCustom
}) => {
    const { t } = useTranslation();

    const customMultiSelectDropdownElementRef = useRef<HTMLDivElement | null>(null);
    const [isShowOptions, setIsShowOptions] = useState(false);

    // handler
    const handlerCustomDropdown = (event: MouseEvent) => {
        /** Expected: If click on the 'Search-Input', 'Options' element should be show.
           if click outside of the "Dropdown(CustomMultiSelectDropdownElementRef)", then 'Options'(isShowOptions) should be hide.
           achieved this behavior with this below ref. */
        if (
            /** we have cancel button in the search text box.
             *  don't hide the 'Options'(isShowOptions) whenever clicks that button. */
            event.target instanceof Element &&
            event.target.className.includes('customCountrySearchBoxCancel')
        )
            return;

        if (
            customMultiSelectDropdownElementRef.current &&
            customMultiSelectDropdownElementRef.current.contains(event.target as Node)
        ) {
            !isShowOptions && setIsShowOptions(true);
        } else {
            isShowOptions && setIsShowOptions(false);
        }
    };
    const handlerSearchBoxCancel = () => {
        setFilteredCustom('');

        const inputField = document.getElementById('customCountrySearch') as HTMLInputElement;
        if (inputField) {
            inputField.focus();
            inputField.value = '';
        }
    };

    // effects
    useEffect(() => {
        document.addEventListener('click', handlerCustomDropdown);
        return () => document.removeEventListener('click', handlerCustomDropdown);
    }, [isShowOptions]);

    return (
        <div ref={customMultiSelectDropdownElementRef} className="custom-dropdown">
            {/* Selected Country Listing */}
            {selectedCustomCountryCount > 0 && (
                <div className="flex flex-row flex-wrap w-full gap-2 my-4">
                    {customCountries.map(
                        (country: CountryConfig, index: number) =>
                            country.isSelected && (
                                <div
                                    key={`Selected_InstantCountry_${country.data.id}-Index_${index}`}
                                    className="flex items-center px-2 py-1 bg-red-100 rounded-xl border border-red-200">
                                    {/* country logo */}
                                    <div
                                        className={`h-6 w-6 rounded-full border bg-no-repeat bg-center`}
                                        style={{
                                            backgroundImage:
                                                'url(/images/country-flags/' +
                                                country?.data?.iconName +
                                                ')',
                                            backgroundSize: '150%'
                                        }}></div>
                                    {/* country name */}
                                    <div className="text-xs font-normal leading-5 px-2">
                                        {country.data.name || ''}
                                    </div>
                                    {/* close button */}
                                    <i
                                        className="customCountrySearchBoxCancel pi pi-times text-base font-normal cursor-pointer text-gray-400 hover:text-gray-600"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        data-testid="customDropdownSelectedOptions"
                                        onClick={() => {
                                            selectedCustomCountryChange(country.data.id, true);
                                        }}
                                    />
                                </div>
                            )
                    )}
                </div>
            )}

            {/* Custom Dropdown With */}
            <div className="flex flex-col items-center relative">
                {customCountries.length > 0 && (
                    <div
                        className={`justify-start w-full gap-2 mb-2 bg-slate-100 border-gray-300 ${getSearchInputCommonStyle}`}>
                        <i className="pi pi-search text-sky-600"></i>
                        <input
                            type="text"
                            id="customCountrySearch"
                            className="w-full"
                            onChange={(e) => setFilteredCustom(e.target.value)}
                            placeholder={t('SELECT_COUNTRY.SEARCH_COUNTRY')}
                            autoComplete="off"
                            onFocus={() => setIsShowOptions(true)}
                            data-testid="searchCountry"
                        />
                        {filteredCustom && (
                            <i
                                className="customCountrySearchBoxCancel pi pi-times cursor-pointer text-neutral-700"
                                onClick={() => {
                                    handlerSearchBoxCancel();
                                }}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                data-testid="customCountrySearchBoxCancel"
                            />
                        )}
                    </div>
                )}
                {/* Options */}
                {isShowOptions && (
                    <div className="absolute shadow top-full bg-white z-40 w-full rounded max-h-80 overflow-y-auto">
                        {customCountries.map(
                            (country: CountryConfig, index: number) =>
                                country.data.name
                                    .toLowerCase()
                                    .includes(filteredCustom.toLowerCase()) && (
                                    <div
                                        key={`Option_InstantCountry_${country?.data?.id}-Index_${index}`}
                                        className={`cursor-pointer w-full border-gray-100 rounded-t border-b my-1 ${country?.isSelected ? 'bg-red-50' : 'hover:bg-red-50'}`}
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => {
                                            selectedCustomCountryChange(country.data.id);
                                            const inputField = document.getElementById(
                                                'customCountrySearch'
                                            ) as HTMLInputElement;
                                            if (inputField) inputField.focus();
                                        }}
                                        data-testid="customDropdownOptions">
                                        <div
                                            className={`flex items-center p-2 pl-2 border-transparent border-l-2 hover: ${country?.isSelected ? 'border-red-400' : 'hover:border-red-400'} `}>
                                            <div className="text-sm mx-2">
                                                {country?.data?.name}
                                            </div>
                                        </div>
                                    </div>
                                )
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default CountryMultiSelect;
