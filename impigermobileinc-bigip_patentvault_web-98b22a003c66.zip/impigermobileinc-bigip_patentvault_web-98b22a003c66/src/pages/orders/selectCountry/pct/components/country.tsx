import { CountryConfig } from '../../types/country.type';

interface CountryProps {
    country: CountryConfig;
    selectedInstantCountryChange: (id: number) => void;
    filteredInstant: string;
}

const Country: React.FC<CountryProps> = ({
    country,
    selectedInstantCountryChange,
    filteredInstant
}) => {
    return (
        <>
            {country.data.name.toLowerCase().includes(filteredInstant.toLowerCase()) && (
                <div
                    className={`grid grid-cols-8 md:grid-cols-5 rounded-md border-2 px-2 py-1 ${
                        country.isSelected
                            ? 'bg-sky-100 border-blue-200'
                            : 'bg-slate-50 border-slate-200'
                    }`}>
                    <div
                        onClick={() => selectedInstantCountryChange(country.data.id)}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        data-testid="instantSelectCountry"
                        className="col-span-1 flex justify-center items-center">
                        <div className="avatar">
                            <div className="h-6 rounded-full border">
                                <div
                                    className={`h-full w-full bg-no-repeat bg-center`}
                                    style={{
                                        backgroundImage:
                                            'url(/images/country-flags/' +
                                            country?.data?.iconName +
                                            ')',
                                        backgroundSize: '150%'
                                    }}></div>
                            </div>
                        </div>
                    </div>

                    <div className="col-span-6 md:col-span-3 flex justify-start items-center cursor-pointer">
                        <div
                            onClick={() => selectedInstantCountryChange(country.data.id)}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            data-testid="instantSelectCountry"
                            className={`text-base font-normal leading-5 w-[95%] min-w-[95%] max-w-[95%] truncate ${country?.isSelected ? 'font-semibold' : ''}`}>
                            {country?.data?.name && country?.data?.code
                                ? `${country.data.name} (${country.data.code})`
                                : ' -- '}
                        </div>
                    </div>
                    <div className="col-span-1 md:col-span-1 flex justify-center items-center">
                        <input
                            type="checkbox"
                            id={`country_${country.data.name}`}
                            checked={country?.isSelected}
                            onChange={() => selectedInstantCountryChange(country.data.id)}
                            className={`checkbox checkbox-sm cursor-pointer rounded-md ${
                                country?.isSelected
                                    ? 'border-none checked:bg-sky-500 [--chkbg:theme(colors.sky.500)]'
                                    : 'bg-white border-1 border-slate-400'
                            }`}
                            data-testid="instantSelectCountry"
                        />
                    </div>
                </div>
            )}
        </>
    );
};

export default Country;
