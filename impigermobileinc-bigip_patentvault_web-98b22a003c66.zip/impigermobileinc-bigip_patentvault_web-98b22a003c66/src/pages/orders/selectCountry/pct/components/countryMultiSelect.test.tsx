import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import CountryMultiSelect from './countryMultiSelect';
import { CountryConfig } from '../../types/country.type';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

describe('CountryMultiSelect Component', () => {
    const customCountries: CountryConfig[] = [
        {
            data: {
                id: 1,
                name: 'United States',
                code: 'US',
                iconName: 'us.png',
                concatCode: '',
                languageId: 1,
                wipoEntitySize: [],
                pcEntitySize: [],
                wipoIq: 1, // PCT
                epoState: 1, // EP
                pcIq: 1, // PC
                up: true
            },
            isSelected: false,
            isUpSelected: false
        }
    ];

    const mockSelectedCustomCountryChange = jest.fn();

    const renderComponent = (overrides = {}) => {
        return render(
            <CountryMultiSelect
                customCountries={customCountries}
                selectedCustomCountryCount={1}
                selectedCustomCountryChange={mockSelectedCustomCountryChange}
                getSearchInputCommonStyle=""
                filteredCustom=""
                setFilteredCustom={() => {}}
                {...overrides}
            />
        );
    };

    test('should filter countries based on search input', () => {
        const setFilteredCustom = jest.fn();
        renderComponent({
            setFilteredCustom
        });

        const searchInput = screen.getByPlaceholderText('SELECT_COUNTRY.SEARCH_COUNTRY');
        fireEvent.change(searchInput, { target: { value: 'Country B' } });

        expect(setFilteredCustom).toHaveBeenCalledWith('Country B');
    });

    test('should show options when input is focused', () => {
        renderComponent();

        const searchInput = screen.getByPlaceholderText('SELECT_COUNTRY.SEARCH_COUNTRY');
        fireEvent.focus(searchInput);
        waitFor(() => {
            const optionCountryB = screen.getByText('Country B');
            expect(optionCountryB).toBeInTheDocument();

            const optionCountryC = screen.getByText('Country C');
            expect(optionCountryC).toBeInTheDocument();
        });
    });

    test('should call selectedCustomCountryChange when a country is selected or removed', () => {
        renderComponent();

        const optionCountryB = screen.getByTestId('searchCountry');
        fireEvent.click(optionCountryB);
        waitFor(() => {
            expect(mockSelectedCustomCountryChange).toHaveBeenCalledWith(2);
        });
    });

    test('should close dropdown when clicking outside', () => {
        renderComponent();

        const searchInput = screen.getByPlaceholderText('SELECT_COUNTRY.SEARCH_COUNTRY');
        fireEvent.focus(searchInput);

        fireEvent.click(document);
        waitFor(() => {
            expect(screen.queryByText('Country B')).not.toBeVisible();
        });
    });
});
