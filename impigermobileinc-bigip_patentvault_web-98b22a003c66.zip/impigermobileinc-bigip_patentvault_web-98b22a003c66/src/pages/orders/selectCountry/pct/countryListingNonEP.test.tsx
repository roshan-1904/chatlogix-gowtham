import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CountryListingNonEP from './countryListingNonEP';
import selectCountryService from '../services/selectCountry.service';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('../services/selectCountry.service');
jest.mock('pages/createOrderAndQuote/services/orderQuoteModule.service');
jest.mock('core/store/orderQuoteStore/orderQuote.store');

const mockQuoteOrderData = {
    info: {
        selectedService: { serviceTypeId: 1, patentType: 1 },
        isEditFlow: false,
        selectedCategory: { patentCategoryId: 1, patentCategoryIsRequestEntity: true },
        mode: 'CREATE_ORDER',
        quoteStatus: 'PREPARING_QUOTE'
    },
    formData: {
        selectCountryPage: {
            instantCountries: [],
            customCountries: [],
            isCheckedSelectAllInstantCheckbox: false,
            isCheckedSelectAllCustomCheckbox: false
        },
        patentDetailsPage: { sourceLanguage: 'ENGLISH' }
    },
    flags: { isCountriesSyncedCompletedInEditMode: false },
    isFormValid: {}
};

(quoteOrderModuleStore.getData as jest.Mock).mockReturnValue(mockQuoteOrderData);

describe('CountryListingNonEP', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the component', () => {
        render(
            <Router>
                <CountryListingNonEP />
            </Router>
        );

        expect(screen.getByText('SELECT_COUNTRY.TITLE')).toBeInTheDocument();
    });

    test('fetches and constructs country data on mount', () => {
        const mockCountriesData = [
            { id: 1, concatCode: 'A', wipoIq: 1 },
            { id: 2, concatCode: 'B', wipoIq: 2 }
        ];
        (selectCountryService.getCountriesData as jest.Mock<any>).mockResolvedValue(
            mockCountriesData
        );

        render(
            <Router>
                <CountryListingNonEP />
            </Router>
        );

        waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalledWith(1);
        });
    });

    test('handles select all countries for instant section', () => {
        const mockCountriesData = [
            { id: 1, concatCode: 'A', wipoIq: 1 },
            { id: 2, concatCode: 'B', wipoIq: 1 }
        ];
        (selectCountryService.getCountriesData as jest.Mock).mockResolvedValue(mockCountriesData);

        render(
            <Router>
                <CountryListingNonEP />
            </Router>
        );

        waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalledWith(1);
        });

        waitFor(() => {
            const selectAllCheckbox = screen.getByTestId('instantSelectAllCheckBox');
            fireEvent.click(selectAllCheckbox);

            expect(selectAllCheckbox).toBeChecked();
        });
    });

    test('handles select all countries for custom section', () => {
        const mockCountriesData = [
            { id: 1, concatCode: 'A', wipoIq: 2 },
            { id: 2, concatCode: 'B', wipoIq: 2 }
        ];
        (selectCountryService.getCountriesData as jest.Mock).mockResolvedValue(mockCountriesData);

        render(
            <Router>
                <CountryListingNonEP />
            </Router>
        );

        waitFor(() => {
            expect(selectCountryService.getCountriesData).toHaveBeenCalledWith(1);
        });

        waitFor(() => {
            const selectAllCheckbox = screen.getByTestId('customSelectAllCheckBox');
            fireEvent.click(selectAllCheckbox);
            expect(selectAllCheckbox).toBeChecked();
        });
    });

    test('handles form submission', () => {
        (orderQuoteModuleService.saveDraft as jest.Mock).mockResolvedValue('/some-path');

        render(
            <Router>
                <CountryListingNonEP />
            </Router>
        );

        waitFor(() => {
            const submitButton = screen.getByRole('button', { name: /submit/i });
            fireEvent.click(submitButton);
            expect(orderQuoteModuleService.saveDraft).toHaveBeenCalled();
        });
    });
});
