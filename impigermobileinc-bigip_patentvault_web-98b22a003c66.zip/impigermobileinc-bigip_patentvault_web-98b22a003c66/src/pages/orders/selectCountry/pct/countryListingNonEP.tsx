/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

import Country from './components/country';
import CountryEntity from './components/countryEntity';
import CountryMultiSelect from './components/countryMultiSelect';
import selectCountryService from '../services/selectCountry.service';
import { SelectCountryData, CountryConfig, SelectCountryDataForEdit } from '../types/country.type';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_TYPE_ID
} from 'constants/progressStepper.constant';
import { ENTITY_SIZE_TYPE, WIPO_IQ_TYPE } from '../constants/country.constant';
import {
    QuoteOrderModuleStore,
    SelectCountryPageMetaData
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { MODE, PATENT_SOURCE_LANGUAGE, STATUS_MODE } from 'constants/app.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';
import { Language } from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import { isContactUser } from 'core/utils/utils';
import stepperStore from 'core/store/stepperStore/progressStepper.store';

const CountryListingNonEP = () => {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const instantSelectAllRef = useRef<HTMLInputElement>(null);
    const customSelectAllRef = useRef<HTMLInputElement>(null);

    const [instantCountries, setInstantCountries] = useState<CountryConfig[]>([]);
    const [customCountries, setCustomCountries] = useState<CountryConfig[]>([]);
    const [filteredInstant, setFilteredInstant] = useState('');
    const [filteredCustom, setFilteredCustom] = useState('');
    const [isCheckedSelectAllInstantCheckbox, setIsCheckedSelectAllInstantCheckbox] =
        useState(false);
    const [isCheckedSelectAllCustomCheckbox, setIsCheckedSelectAllCustomCheckbox] = useState(false);
    const [isMinOneCountrySelected, setIsMinOneCountrySelected] = useState<boolean | null>(null);
    const [isFormSubmitting, setIsFormSubmitting] = useState<boolean>(false);

    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const selectedService = quoteOrderData?.info.selectedService;
    const isEditFlow = quoteOrderData?.info.isEditFlow === true;
    const isPCT = selectedService?.serviceTypeId === SERVICE_TYPE_ID.patent_cooperation_treaty;
    const isPC = selectedService?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;
    const PC = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.paris_convention_treaty];
    const selectedCategoryId = quoteOrderData?.info.selectedCategory?.patentCategoryId;

    type CountrySectionType = 'instant' | 'custom';
    const SELECT_ALL_STATE = {
        NO_SELECTION: 0,
        PARTIALLY_SELECTED: 1,
        ALL_SELECTED: 2
    };

    // api
    const getCountriesList = async (): Promise<void> => {
        try {
            const patentType: number = quoteOrderData?.info.selectedService?.patentType ?? 0;
            const selectedLanguage = quoteOrderData.formData.patentDetailsPage.sourceLanguage;
            const languageList = await OrdersAndQuotesService.getLanguageList<Language[]>();

            let language: Language | undefined;
            if (selectedLanguage) {
                language = languageList.find(
                    (lang) => lang.abbreviation.toLowerCase() === selectedLanguage.toLowerCase()
                );
            }

            const countryListResponse: SelectCountryData[] =
                await selectCountryService?.getCountriesData(
                    // append 'servicePatentTypeId' in API to get country list
                    patentType,
                    language?.id ?? null
                );
            if (countryListResponse) {
                constructCountryData(countryListResponse);
            }
        } catch (error) {
            console.error('Error in getCountriesList:', error);
        }
    };
    const orderSaveApi = async () => {
        const redirectTo: string | null = await orderQuoteModuleService.saveDraft(true);
        if (redirectTo) navigate(redirectTo);
    };

    // constructions
    const constructCountryData = (countryList: SelectCountryData[]) => {
        const instantCountriesData: CountryConfig[] = [];
        const customCountriesData: CountryConfig[] = [];

        const dbParam = getDBParam('iq');

        try {
            const sortedCountryList = sortCountriesByConcatCode(countryList);

            for (const country of sortedCountryList) {
                if (dbParam && country[dbParam] !== null && country[dbParam] !== undefined) {
                    if (country[dbParam] === WIPO_IQ_TYPE?.INSTANT_COUNTRY) {
                        instantCountriesData.push({
                            isSelected: false,
                            isUpSelected: false,
                            selectedWipoEntityId: null,
                            data: { ...country }
                        });
                    } else if (country[dbParam] === WIPO_IQ_TYPE?.CUSTOM_COUNTRY) {
                        customCountriesData.push({
                            isSelected: false,
                            isUpSelected: false,
                            data: { ...country }
                        });
                    }
                } else {
                    throw new Error('wipoIq / pcIq is not available for countries.');
                }
            }

            const fetchFormData: SelectCountryPageMetaData | null =
                quoteOrderData?.formData?.selectCountryPage ?? null;

            if (fetchFormData) {
                instantCountriesData.forEach((instantCountry) => {
                    const selectedCountry = fetchFormData.instantCountries?.find(
                        (country) => country.data.id === instantCountry.data.id
                    );
                    if (selectedCountry) {
                        instantCountry.isSelected = selectedCountry.isSelected;
                        instantCountry.isUpSelected = selectedCountry.isUpSelected;
                        instantCountry.selectedWipoEntityId = selectedCountry.selectedWipoEntityId;
                    }
                });

                customCountriesData.forEach((customCountry) => {
                    const selectedCountry = fetchFormData.customCountries?.find(
                        (country) => country.data.id === customCountry.data.id
                    );
                    if (selectedCountry) {
                        customCountry.isSelected = selectedCountry.isSelected;
                        customCountry.isUpSelected = selectedCountry.isUpSelected;
                        customCountry.selectedWipoEntityId = selectedCountry.selectedWipoEntityId;
                    }
                });

                setInstantCountries(fetchFormData.instantCountries ?? []);
                setCustomCountries(fetchFormData.customCountries ?? []);
                setIsCheckedSelectAllInstantCheckbox(
                    Boolean(fetchFormData.isCheckedSelectAllInstantCheckbox)
                );
                setIsCheckedSelectAllCustomCheckbox(
                    Boolean(fetchFormData.isCheckedSelectAllCustomCheckbox)
                );
            }

            setInstantCountries(instantCountriesData);
            setCustomCountries(customCountriesData);
        } catch (error: any) {
            console.error('Error:', error.message);
        }
    };
    const isCountryEntity = (country: SelectCountryData) => {
        /** Allow entity type for 'translation_&_filing' category only which is available in PCT and PC services. */
        try {
            const PCT = CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty];
            const selectedCategory = quoteOrderData?.info.selectedCategory?.patentCategoryId;

            const dbParam = getDBParam('entity');
            if (!dbParam) throw new Error('Entity param is not available.');

            const dbParamValue = country[dbParam];
            const hasValidLength = Array.isArray(dbParamValue) && dbParamValue.length > 0;
            const isEntity =
                hasValidLength &&
                quoteOrderData?.info.selectedCategory?.patentCategoryIsRequestEntity;

            if (
                selectedCategory === PCT?.['translation_&_filing'] ||
                selectedCategory === PC?.['translation_&_filing']
            ) {
                return isEntity;
            } else {
                return false;
            }
        } catch (error) {
            console.error('Error in validateCountry function:', error);
            return false;
        }
    };
    const getDBParam = (paramType: 'iq' | 'entity'): keyof SelectCountryData | null => {
        let dbParam: keyof SelectCountryData | null = null;

        if (paramType === 'iq') {
            if (isPCT) {
                dbParam = 'wipoIq';
            } else if (isPC) {
                dbParam = 'pcIq';
            }
        } else if (paramType === 'entity') {
            if (isPCT) {
                dbParam = 'wipoEntitySize';
            } else if (isPC) {
                dbParam = 'pcEntitySize';
            }
        }

        return dbParam ?? null;
    };

    // onchange handlers
    const selectedInstantCountryChange = (
        selectedInstantCountryId: number,
        wipoEntityId?: number | null,
        resetEntity?: boolean
    ) => {
        const updatedInstantCountries: CountryConfig[] = instantCountries.map(
            (country: CountryConfig) => {
                if (country?.data?.id === selectedInstantCountryId) {
                    let updatedCountryData = { ...country };

                    /** there are two different country in InstantCountry
                        One is normal selection, another one is Entity type (Radio options - Large , Small)
                        differentiate those with 'WipoEntityId'. */
                    if (!wipoEntityId && wipoEntityId !== 0) {
                        // normal selection
                        updatedCountryData = { ...country, isSelected: !country?.isSelected };
                    } else if (wipoEntityId === 0 && resetEntity) {
                        // reset entity selection
                        updatedCountryData = {
                            ...country,
                            isSelected: false,
                            selectedWipoEntityId: null
                        };
                    } else if (wipoEntityId) {
                        // entity selection
                        updatedCountryData = {
                            ...country,
                            isSelected: true,
                            selectedWipoEntityId: wipoEntityId
                        };
                    }

                    return updatedCountryData;
                }
                return country;
            }
        );
        setInstantCountries(updatedInstantCountries);
    };
    const selectedCustomCountryChange = (selectedCustomCountryId: number, isRemove = false) => {
        const updatedCustomCountries: CountryConfig[] = customCountries?.map(
            (country: CountryConfig) => {
                if (country?.data?.id === selectedCustomCountryId) {
                    const updatedCountryData = { ...country, isSelected: !isRemove };
                    return updatedCountryData;
                }
                return country;
            }
        );
        setCustomCountries(updatedCustomCountries);
    };
    const selectAllCountries = (countrySectionType: CountrySectionType) => {
        const countries = getCountryStateWithParam(countrySectionType);

        const updatedCountries = countries?.map((country) => {
            country.isSelected =
                countrySectionType === 'instant'
                    ? !isCheckedSelectAllInstantCheckbox
                    : !isCheckedSelectAllCustomCheckbox;

            if (countrySectionType === 'instant' && isCountryEntity(country.data)) {
                if (!isCheckedSelectAllInstantCheckbox) {
                    if (country.selectedWipoEntityId) {
                        /** in SelectAll, if country is already selected with Entity type, then keep it as it is.
                            else select with default Entity type (Large) */
                        return country;
                    } else {
                        country.selectedWipoEntityId = ENTITY_SIZE_TYPE.LARGE;
                    }
                } else {
                    country.selectedWipoEntityId = null;
                }
            }

            return country;
        });

        if (countrySectionType === 'instant') {
            setInstantCountries(updatedCountries);
            setIsCheckedSelectAllInstantCheckbox(!isCheckedSelectAllInstantCheckbox);
        } else if (countrySectionType === 'custom') {
            setCustomCountries(updatedCountries);
            setIsCheckedSelectAllCustomCheckbox(!isCheckedSelectAllCustomCheckbox);
        }
    };

    // render helpers
    const selectAllCheckBoxState = (countrySectionType: CountrySectionType) => {
        let state = null;
        const selectedCountryCount = selectedCountriesCount(countrySectionType);

        // define the 'Select All' checkbox current state based on the selected countries count
        if (selectedCountryCount === 0) {
            state = SELECT_ALL_STATE.NO_SELECTION;
        } else if (selectedCountryCount === getCountryStateWithParam(countrySectionType).length) {
            state = SELECT_ALL_STATE.ALL_SELECTED;
        } else if (
            selectedCountryCount > 0 &&
            selectedCountryCount !== getCountryStateWithParam(countrySectionType).length
        ) {
            state = SELECT_ALL_STATE.PARTIALLY_SELECTED;
        }

        // have to update the style for the select-all checkbox using 'useRef', while partially countries selected.
        const checkbox =
            countrySectionType === 'instant'
                ? instantSelectAllRef.current
                : customSelectAllRef.current;
        if (checkbox) checkbox.indeterminate = state === SELECT_ALL_STATE.PARTIALLY_SELECTED;
        return state;
    };
    const selectedCountriesCount = (countrySectionType: CountrySectionType) => {
        let count = 0;
        const countries = getCountryStateWithParam(countrySectionType);

        if (countries) {
            count = countries?.filter((country) => country?.isSelected).length || 0;
        }
        return count;
    };
    const getCountryStateWithParam = (countrySectionType: CountrySectionType) => {
        if (countrySectionType === 'instant') {
            return instantCountries;
        } else if (countrySectionType === 'custom') {
            return customCountries;
        }

        return [];
    };
    const getSelectAllCheckboxStyle = (countrySectionType: CountrySectionType) => {
        const commonClass =
            'checkbox checkbox-xs cursor-pointer rounded-sm border-gray-300 checked:border-none';
        let conditionalStyle = commonClass;

        if (selectAllCheckBoxState(countrySectionType) === SELECT_ALL_STATE.ALL_SELECTED) {
            conditionalStyle += ' [--chkbg:theme(colors.sky.500)]';
        } else if (
            selectAllCheckBoxState(countrySectionType) === SELECT_ALL_STATE.PARTIALLY_SELECTED
        ) {
            conditionalStyle += ' border-red-500 [--chkfg:red] [--chkbg:theme(colors.white)]';
        }

        return conditionalStyle;
    };
    const getSearchInputCommonStyle = () => {
        return 'input input-sm input-bordered flex items-center focus:border-gray-500 focus-within:border-gray-500 focus:outline-none focus-visible:outline-none focus-within:outline-none';
    };
    const updateFormData = (updatedQuoteOrderData: QuoteOrderModuleStore) => {
        const updatedQuoteOrderFormData = {
            ...updatedQuoteOrderData?.formData, // keep other forms data
            selectCountryPage: {
                instantCountries,
                customCountries,
                isCheckedSelectAllInstantCheckbox,
                isCheckedSelectAllCustomCheckbox
            }
        };
        quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
    };
    const updateIsFormValid = (updatedQuoteOrderData: QuoteOrderModuleStore) => {
        // form valid status to update store
        if (
            !instantCountries ||
            !customCountries ||
            instantCountries.length === 0 ||
            customCountries.length === 0
        )
            return;

        const updatedQuoteOrderIsFormValid = {
            ...updatedQuoteOrderData.isFormValid,
            [PATHS.SELECT_COUNTRY]:
                instantCountries.some((country) => country.isSelected) ||
                customCountries.some((country) => country.isSelected)
        };

        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
    };
    const updatePageValidStatus = (): boolean => {
        // form valid status update for local
        const updatedIsMinOneCountrySelected: boolean =
            instantCountries.some((country) => country.isSelected) ||
            customCountries.some((country) => country.isSelected);
        setIsMinOneCountrySelected(updatedIsMinOneCountrySelected);

        return updatedIsMinOneCountrySelected;
    };
    const sortCountriesByConcatCode = (countryList: SelectCountryData[]) => {
        return countryList.sort((a, b) => {
            if (a.concatCode < b.concatCode) {
                return -1;
            }
            if (a.concatCode > b.concatCode) {
                return 1;
            }
            return 0;
        });
    };
    const onSubmit = () => {
        setIsFormSubmitting(true);
        const isPageValid = updatePageValidStatus();

        /** trigger temporary 'OrderSave' API only page is valid.
             note: page navigation and this API call will happen parallelly. */
        isPageValid &&
            !stepperStore.getIsLastStepper(STEPPER_TYPE_ID.SELECT_COUNTRY) &&
            orderSaveApi();
    };
    const updateSelectedCountries = async () => {
        try {
            await new Promise((r) => setTimeout(r, 500));

            const selectedInstantCountries: SelectCountryDataForEdit[] | null =
                quoteOrderData?.formData?.selectCountryPageEdit?.instantCountries ?? null;
            const selectedCustomCountries: SelectCountryDataForEdit[] | null =
                quoteOrderData?.formData?.selectCountryPageEdit?.customCountries ?? null;

            instantCountries.forEach((instantCountry) => {
                if (selectedInstantCountries) {
                    const selectedCountryInCreateFlow = selectedInstantCountries.find(
                        (selectedInstantCountry) =>
                            selectedInstantCountry.countryId === instantCountry.data.id
                    );
                    if (selectedCountryInCreateFlow) {
                        instantCountry.isSelected = true;
                        instantCountry.selectedWipoEntityId =
                            selectedCountryInCreateFlow.entityType ?? 0;
                    }
                }
            });
            customCountries.forEach((customCountry) => {
                if (selectedCustomCountries) {
                    const selectedCountryInCreateFlow = selectedCustomCountries.find(
                        (selectedCustomCountry) =>
                            selectedCustomCountry.countryId === customCountry.data.id
                    );
                    if (selectedCountryInCreateFlow) {
                        customCountry.isSelected = true;
                        customCountry.selectedWipoEntityId =
                            selectedCountryInCreateFlow.entityType ?? 0;
                    }
                }
            });

            setInstantCountries([...instantCountries]);
            setCustomCountries([...customCountries]);

            const updatedQUoteOrderDataFlags = {
                ...quoteOrderData?.flags,
                isCountriesSyncedCompletedInEditMode: true
            };
            quoteOrderModuleStore.updatePage('flags', updatedQUoteOrderDataFlags);
        } catch (error) {
            console.error('Error in updateSelectedCountries(): ', error);
        }
    };

    // summary page hide and show for PCT flow only while selecting custom country only
    const summaryPageHideAndShow = () => {
        const isPCTFlow =
            selectedService?.serviceTypeId === SERVICE_TYPE_ID.patent_cooperation_treaty;
        const isCreateOrderFlow = quoteOrderData?.info.mode === MODE.CREATE_ORDER;

        const sourceLanguage: string =
            quoteOrderData?.formData.patentDetailsPage?.sourceLanguage || '';

        if (!isThisContactUser) {
            return false;
        }

        // PC flow works only for English language and custom country selection also for CU and CM users
        const isPCFlow = selectedService?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;
        if (
            isPCFlow &&
            selectedCategoryId === PC['translation_only'] &&
            !isCreateOrderFlow &&
            sourceLanguage.toLowerCase() === PATENT_SOURCE_LANGUAGE.ENGLISH.toLowerCase() &&
            !isEditFlow
        ) {
            const isCustomCountrySelected = customCountries.some((country) => country.isSelected);
            if (isCustomCountrySelected) {
                orderQuoteModuleService.removeStepInStepper();
            } else {
                orderQuoteModuleService.addMoreStepInStepper();
            }
        }

        if (
            !isPCTFlow ||
            isCreateOrderFlow ||
            !Object.values(PATENT_SOURCE_LANGUAGE).includes(sourceLanguage)
        ) {
            return false;
        }
        // skipping recordal and annuities for PCT
        const isPCTRecordalIOrAnnuities =
            quoteOrderData?.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].recordal ||
            quoteOrderData?.info.selectedCategory?.patentCategoryId ===
                CATEGORY_TYPE_ID[SERVICE_TYPE_ID.patent_cooperation_treaty].annuities;
        if (isPCTRecordalIOrAnnuities) return;
        const isCustomCountrySelected = customCountries.some((country) => country.isSelected);
        const isInstantCountrySelected = instantCountries.some((country) => country.isSelected);
        if (isEditFlow) {
            if (
                quoteOrderData?.info.quoteStatus === STATUS_MODE.PREPARING_QUOTE &&
                isCustomCountrySelected &&
                !isInstantCountrySelected
            ) {
                orderQuoteModuleService.removeStepInStepper();
            } else {
                orderQuoteModuleService.addMoreStepInStepper();
            }
        } else if (isCustomCountrySelected && !isInstantCountrySelected) {
            orderQuoteModuleService.removeStepInStepper();
        } else {
            orderQuoteModuleService.addMoreStepInStepper();
        }
    };

    const handleFilteredInstant = () => {
        setFilteredInstant('');
        const inputField = document.getElementById('instantCountrySearch') as HTMLInputElement;
        if (inputField) {
            inputField.focus();
            inputField.value = '';
        }
    };

    // effects
    useEffect(() => {
        try {
            getCountriesList();
        } catch (error) {
            console.error('Error handling initial data on useEffect():', error);
        }
    }, [quoteOrderData]);

    // update store in onChange
    useEffect(() => {
        summaryPageHideAndShow(); // summary page hide and show based on conditions

        const updatedQuoteOrderData = quoteOrderModuleStore.getData();

        updateFormData(updatedQuoteOrderData);
        updateIsFormValid(updatedQuoteOrderData);

        if (
            !updatedQuoteOrderData?.flags.isCountriesSyncedCompletedInEditMode &&
            updatedQuoteOrderData?.info.isEditFlow === true &&
            instantCountries?.length > 0 &&
            customCountries?.length > 0
        ) {
            updateSelectedCountries();
        }

        if (isFormSubmitting) updatePageValidStatus();
    }, [instantCountries, customCountries]);

    useEffect(() => {
        const inputField = document.getElementById('instantCountrySearch') as HTMLInputElement;
        if (inputField) {
            inputField.focus();
        }
    }, [instantCountries]);

    return (
        <div className="p-5 pt-4">
            <h4 className="font-semibold mb-5">{t('SELECT_COUNTRY.TITLE')}</h4>

            {/* Section 1 - Instant Quote */}
            <div className="relative border-2 rounded-lg border-blue-300 p-3 md:p-4 lg:p-6 pt-6 md:pt-6 lg:pt-4 mb-7 h-[40vh] md:h-full">
                <label className="absolute text-base font-medium top-0 left-5 -mt-3.5 bg-white px-1 border-none">
                    {t('SELECT_COUNTRY.INSTANT_QUOTE')}
                </label>
                <div className="country-list-container">
                    <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-8 gap-2 md:gap-4 mb-4 lg:mb-5">
                        {/* Selected countries count */}
                        <div
                            className={`sm:col-span-1 md:col-span-2 lg:col-span-3 inline md:flex justify-start items-center gap-3`}>
                            <div className="flex justify-start items-center gap-2 mb-1.5 md:mb-0">
                                <input
                                    type="checkbox"
                                    id="instantSelectAllCheckBox"
                                    ref={instantSelectAllRef}
                                    checked={isCheckedSelectAllInstantCheckbox}
                                    className={getSelectAllCheckboxStyle('instant')}
                                    onChange={() => selectAllCountries('instant')}
                                    data-testid="instantSelectAllCheckBox"
                                />
                                <label
                                    htmlFor="instantSelectAllCheckBox"
                                    className="text-sm font-normal cursor-pointer">
                                    {/* Selected (0) */}
                                    {t('SELECT_COUNTRY.SELECTED')}
                                    {` (${instantCountries?.filter((country) => country?.isSelected)?.length})`}
                                </label>
                            </div>
                            <div className="flex sm:justify-start">
                                {isMinOneCountrySelected === false && (
                                    <ErrorLabel
                                        message={`${t('SELECT_COUNTRY.ERROR')}`}
                                        warningIcon={true}
                                    />
                                )}
                            </div>
                        </div>
                        {/* Search countries */}
                        <div className="sm:col-span-1 md:col-span-2 lg:col-span-3 lg:col-start-6">
                            <div
                                className={`border-gray-300 gap-2 focus:border-primary focus-within:border-primary ${getSearchInputCommonStyle()}`}>
                                <i className="pi pi-search text-sky-600"></i>
                                <input
                                    type="text"
                                    id="instantCountrySearch"
                                    className="w-full"
                                    onChange={(e) => setFilteredInstant(e.target.value)}
                                    placeholder={t('SELECT_COUNTRY.SEARCH_COUNTRY')}
                                    autoComplete="off"
                                />
                                {filteredInstant && (
                                    <i
                                        className="pi pi-times cursor-pointer text-neutral-700"
                                        onClick={handleFilteredInstant}
                                        data-testid="instantCountrySearchClear"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                    />
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Custom Dropdown for country size with radio */}
                    <div
                        className={`${isMinOneCountrySelected === false ? 'h-[25vh]' : 'h-[26vh]'} grid sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 md:h-full`}>
                        {instantCountries.length > 0 &&
                            instantCountries.map((country: CountryConfig, index: number) =>
                                /** 'patentCategoryIsRequestEntity' we can get this flag while select service (in first page).
                                 *    with this we should decide this 'Country' should be consider as Entity or not.
                                 *    Entity is "true" if 'patentCategoryIsRequestEntity' is true and 'wipoEntitySize' array has value
                                 */
                                isCountryEntity(country.data) === true ? (
                                    <CountryEntity
                                        key={index + 1}
                                        // state
                                        country={country}
                                        // handlers
                                        selectedInstantCountryChange={selectedInstantCountryChange}
                                        // search input - filter
                                        filteredInstant={filteredInstant}
                                    />
                                ) : (
                                    <Country
                                        key={index + 1}
                                        // state
                                        country={country}
                                        // handlers
                                        selectedInstantCountryChange={selectedInstantCountryChange}
                                        // search input - filter
                                        filteredInstant={filteredInstant}
                                    />
                                )
                            )}
                    </div>
                </div>
            </div>

            {/* Section 2 - Custom Quote */}
            <div className="relative border-2 rounded-lg border-red-200 p-3 md:p-4 lg:p-6 pt-6 md:pt-6 lg:pt-4">
                <label className="absolute text-base font-medium top-0 left-5 -mt-3.5 bg-white px-1 border-none">
                    {t('SELECT_COUNTRY.CUSTOM_QUOTE')}
                </label>
                <div className="country-list-container">
                    <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-8 gap-2 md:gap-4 mb-4 lg:mb-5">
                        {/* Selected countries count */}
                        <div className="sm:col-span-1 md:col-span-2 lg:col-span-3 inline md:flex justify-start items-center gap-3">
                            <div className="flex justify-start items-center gap-2 mb-1.5 md:mb-0">
                                <input
                                    type="checkbox"
                                    id="customSelectAllCheckBox"
                                    ref={customSelectAllRef}
                                    checked={isCheckedSelectAllCustomCheckbox}
                                    className={getSelectAllCheckboxStyle('custom')}
                                    onChange={() => selectAllCountries('custom')}
                                    data-testid="customSelectAllCheckBox"
                                />
                                {/* Selected countries count */}
                                <label
                                    htmlFor="customSelectAllCheckBox"
                                    className="text-sm font-normal cursor-pointer">
                                    {/* Selected (0) */}
                                    {t('SELECT_COUNTRY.SELECTED')}
                                    {` (${customCountries.filter((country) => country.isSelected).length})`}
                                </label>
                            </div>
                            <div className="flex sm:justify-start">
                                {isMinOneCountrySelected === false && (
                                    <ErrorLabel
                                        message={`${t('SELECT_COUNTRY.ERROR')}`}
                                        warningIcon={true}
                                    />
                                )}
                            </div>
                        </div>
                        <div className="sm:col-span-1 md:col-span-2 lg:col-span-4 col-start-1 md:col-start-1 lg:col-start-5 flex justify-start md:justify-end items-center">
                            {/* sm:col-span-1 md:col-span-2 lg:col-span-3 lg:col-start-6 */}
                            <div className="flex justify-center items-center gap-2 text-sm px-2 py-1 bg-orange-50 border-2 rounded-md border-orange-100">
                                <i className="pi pi-exclamation-circle"></i>
                                <span className="lg:whitespace-nowrap">
                                    {t('SELECT_COUNTRY.CUSTOM_QUOTE_WARNING')}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Custom dropdown to select custom countries */}
                <CountryMultiSelect
                    // country data
                    customCountries={customCountries || []}
                    selectedCustomCountryCount={selectedCountriesCount('custom')}
                    // handlers
                    selectedCustomCountryChange={selectedCustomCountryChange}
                    getSearchInputCommonStyle={getSearchInputCommonStyle()}
                    // search input - filter
                    filteredCustom={filteredCustom}
                    setFilteredCustom={setFilteredCustom}
                />
            </div>

            {/* submit */}
            <button
                type="button"
                id={`submit-${PATHS.SELECT_COUNTRY}`}
                onClick={onSubmit}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                data-testid={`submit-${PATHS.SELECT_COUNTRY}`}
            />
        </div>
    );
};

export default CountryListingNonEP;
