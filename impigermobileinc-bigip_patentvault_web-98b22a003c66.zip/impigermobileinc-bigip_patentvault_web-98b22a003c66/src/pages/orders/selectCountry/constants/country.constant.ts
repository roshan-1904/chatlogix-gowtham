import { primaryCurrencyFormat } from 'core/utils/utils';
import { CountryEntityType, EpCountryResponseList } from '../types/country.type';

export const COUNTRY_TYPE: { [key: string]: number } = {
    INSTANT: 1,
    CUSTOM: 2
};

export const ENTITY_SIZE_TYPE: { [key: string]: number } = {
    SMALL: 1,
    LARGE: 2
};

export const WIPO_IQ_TYPE: { [key: string]: number } = {
    INSTANT_COUNTRY: 1,
    CUSTOM_COUNTRY: 0
};

export const COUNTRY_ENTITY: CountryEntityType = {
    1: { id: 1, name: 'Small', code: 'S' },
    2: { id: 2, name: 'Large', code: 'L' }
};

export const EPO_STATE: { [key: string]: number } = {
    DESIGNATED_CONTRACTING_STATES: 1,
    VALIDATION_STATES: 2,
    EXTENSION_STATES: 3
};

export const selectedCurrency = (currencySymbol: string, value: number) => {
    return currencySymbol + ' ' + primaryCurrencyFormat(value);
};

export const serviceIncludedOptions: EpCountryResponseList['serviceIncluded'] = {
    allFees: { id: 1, label: 'All', value: 0, isSelected: true },
    agencyAndOfficialFee: {
        id: 2,
        label: 'Agency & Official Fees',
        value: 0,
        isSelected: false
    },
    agencyFee: {
        id: 3,
        label: 'Agency Fee',
        value: 0,
        isSelected: false
    },
    translationFee: {
        id: 4,
        label: 'Translation Fee',
        value: 0,
        isSelected: false
    },
    officialFee: {
        id: 5,
        label: 'Official Fee',
        value: 0,
        isSelected: false
    }
};

export const COUNTRY_ID = {
    SPAIN: 106
};
