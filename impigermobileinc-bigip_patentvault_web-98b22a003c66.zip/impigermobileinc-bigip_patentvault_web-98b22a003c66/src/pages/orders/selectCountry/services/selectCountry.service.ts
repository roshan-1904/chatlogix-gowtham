import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { CATEGORY_TYPE_ID, SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import AuthStore from 'core/store/authStore/authStore';
import { LANGUAGE_ID, YES_NO } from 'constants/app.constant';
import utils, { formatDateYYMMDD, isContactUser, toggleLoadingIndicator } from 'core/utils/utils';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { EpCountriesData } from '../types/country.type';
import { serviceIncludedOptions } from '../constants/country.constant';
import { VendorAssignmentCheckRequestBody } from 'shared/dataTable/types/dataTable.types';

const baseURL: string | undefined = process.env.REACT_APP_QUOTE_BASE_URL;

// Check if baseURL is defined before proceeding
if (!baseURL) {
    throw new Error('REACT_APP_API_BASE_URL is not defined in the environment variables.');
}

const httpService = new HttpService();

const getQuoteOrderStoreData = () => {
    let quoteOrderData = quoteOrderModuleStore.getData();
    quoteOrderData = removePatentFields(quoteOrderData);
    return quoteOrderData;
};
const removePatentFields = (storeData: QuoteOrderModuleStore) => {
    /** in UI when fields are hidden we removed the populated/entered values as well via formio. 
        in this case we disable that formio behavior for some reason. So we do that removal on here. */

    const patentDetailsPage = storeData.formData.patentDetailsPage ?? {};

    // If `ifEpGrantedYesNo` is true, remove specific fields from patentDetailsPage
    if (!patentDetailsPage.ifEpGrantedYesNo) {
        const keysToRemove = [
            'french',
            'german',
            'english',
            'requestedDeliveryDateForClaimsTranslation',
            'statutoryDeadlineDate'
        ];

        // Remove keys by deleting them from the object
        keysToRemove.forEach((key) => {
            delete patentDetailsPage[key];
        });
    }

    const updatedStoreData = {
        ...storeData,
        formData: {
            ...storeData.formData,
            patentDetailsPage
        }
    };
    return updatedStoreData;
};

const getCountriesData = async <T>(
    patentType: number,
    languageId: number | null = null
): Promise<T> => {
    let apiUrl = `${END_POINT.SELECT_COUNTRY.GET_COUNTRIES}/${patentType}`;
    if (languageId) {
        apiUrl += `?sourceLanguageId=${languageId}`;
    }
    try {
        const response = await httpService.get<T>(apiUrl, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error fetching service types:', error);
        throw error;
    }
};

const orderSaveDraft = async <T>(orderCountryEdit?: {
    isOrderEdit: boolean;
    orderId: number;
    draftId: number;
    isEpOrder: boolean;
    isUPOrder: boolean;
    isAddOrRemoveCountries?: boolean;
    hasOrderCostUpdated?: boolean;
    noEnglishTranslationRequired?: boolean;
}): Promise<T> => {
    const userDetails = AuthStore.getUserInfo();
    const quoteOrderData = getQuoteOrderStoreData();
    const apiUrl = orderCountryEdit?.isOrderEdit
        ? END_POINT.ORDER_COUNTRY_UPDATE
        : END_POINT.ORDER_SAVE_DRAFT;

    const loggedInUserInfo = userDetails.userInfo;
    const isThisCUserExcludedSalesRep = isContactUser(loggedInUserInfo.roleId, true);
    const info = quoteOrderData.info;

    const primaryId = info.primaryId ?? 0;
    const selectedService = info.selectedService;

    const companyDetailsPageFormData = quoteOrderData.formData.companyDetailsPage;
    const additionalInfoPage = quoteOrderData.formData.additionalInfoPage;
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;
    const selectCountryPage = quoteOrderData.formData.selectCountryPage;
    const selectCountryPageForEP = quoteOrderData.formData.selectCountryPageForEP;

    const isPCT = selectedService?.serviceTypeId === SERVICE_TYPE_ID.patent_cooperation_treaty;
    const isEP = selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent;
    const isPC = selectedService?.serviceTypeId === SERVICE_TYPE_ID.paris_convention_treaty;

    const isEpTranslationAndValidation =
        info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_&_validation'];

    let selectedCountriesList: {
        countryId: number | null;
        countryName?: string | null;
        languageId: number | null;
        entityType?: number | null;
        EP?: boolean | null;
        UP?: boolean | null;
        isClaim?: boolean | null;
        agencyFee?: number | null;
        officialFee?: number | null;
        translationFee?: number | null;
        translationRate?: number | null;
        agencyFeeFormula?: string | null;
        officialFeeFormula?: string | null;
        translationFeeFormula?: string | null;
        includeAgencyFee?: boolean | null;
        includeOfficialFee?: boolean | null;
        includeTranslationFee?: boolean | null;
        agencyOrOfficialFeeUpdated?: boolean | null;
        translationFeeUpdated?: boolean | null;
        isNewRecord?: boolean | null;
        isUserPreferredAiTranslation?: boolean | null;
    }[] = [];

    const getSalesRep = (): string | null => {
        const salesRepSet: Set<string> = new Set();

        /** concat these SalesRep and send as comma string */
        const salesRepOfCompanyPage: number | null =
            companyDetailsPageFormData?.patentDetails?.salesRepId ?? null;
        const salesRepOfPatentPage: number | null = patentDetailsPage.salesRepId ?? null;
        const salesRepOfAddInfoPage: number[] | null = additionalInfoPage?.salesRep ?? null;

        if (salesRepOfCompanyPage !== null) {
            salesRepSet.add(salesRepOfCompanyPage.toString());
        }
        if (salesRepOfPatentPage !== null) {
            salesRepSet.add(salesRepOfPatentPage.toString());
        }
        if (Array.isArray(salesRepOfAddInfoPage) && salesRepOfAddInfoPage.length > 0) {
            salesRepOfAddInfoPage.forEach((salesRepId) => salesRepSet.add(salesRepId.toString()));
        }
        const salesRepValues = Array.from(salesRepSet);

        // Join all sales rep values with commas
        return salesRepValues.length > 0 ? salesRepValues.join(',') : null;
    };

    const countriesId = () => {
        if (
            quoteOrderData.info.selectedService?.serviceTypeId ===
                SERVICE_TYPE_ID.european_patent ||
            orderCountryEdit?.isOrderEdit
        ) {
            selectedCountriesList = [];
            const isUPFeeID =
                selectCountryPageForEP?.epTranslationAndValidationData
                    ?.upAndNationalValidationsFeesID?.serviceIncludedId;
            const upAndNationalValidationsFees =
                selectCountryPageForEP?.epTranslationAndValidationData
                    ?.upAndNationalValidationsFeesID;
            const isEditFlow = quoteOrderModuleStore?.getData()?.info?.isEditFlow;

            // const handleGroupedCountriesTranslationFeeFlag = (groupId: number) => {
            //     // Check if any primary country in the group is already selected
            //     const primarySelected =
            //         selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList.some(
            //             (item) =>
            //                 item.groupId === groupId && item.isPrimaryDisplay && item.isSelected
            //         );
            //     if (primarySelected) {
            //         // If already selected, skip showing translation fee
            //         return false;
            //     }
            //     // Otherwise, show translation fee for the primary country in the group
            //     return selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList.find(
            //         (item) => item.groupId === groupId && item.isPrimaryDisplay
            //     )?.serviceIncluded.translationFee.isSelected;
            // };

            if (isEpTranslationAndValidation || orderCountryEdit?.isOrderEdit) {
                selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList.map(
                    (country) => {
                        if (orderCountryEdit?.isUPOrder) return;
                        const { agencyAndOfficialFee, allFees, agencyFee, translationFee } =
                            country.serviceIncluded;

                        const includeAgencyFee =
                            agencyAndOfficialFee.isSelected ||
                            allFees.isSelected ||
                            agencyFee.isSelected;

                        const includeOfficialFee =
                            agencyAndOfficialFee.isSelected || allFees.isSelected;

                        const includeTranslationFee =
                            translationFee.isSelected || allFees.isSelected;

                        country.isSelected &&
                            selectedCountriesList.push({
                                countryId: country.id,
                                countryName: country.countryName,
                                languageId: country.languageId,
                                entityType: 0,
                                EP: true,
                                UP: country.isUp == null ? false : country.isUp,
                                agencyFee: includeAgencyFee
                                    ? country.serviceIncluded.agencyFee.value
                                    : 0,
                                officialFee: includeOfficialFee
                                    ? country.serviceIncluded.officialFee.value
                                    : 0,
                                translationFee: includeTranslationFee
                                    ? country.serviceIncluded.translationFee.value
                                    : 0,
                                translationRate: country.translationRate,
                                isNewRecord: isEditFlow ? country.isNewRecord : undefined,
                                agencyFeeFormula: (() => {
                                    if (!country.isNewRecord && isEditFlow) {
                                        return country.agencyOrOfficialFeeUpdated
                                            ? country.agencyFeeFormula
                                            : country.selectedListAgencyFeeFormula;
                                    } else {
                                        return country.agencyFeeFormula;
                                    }
                                })(),
                                officialFeeFormula: (() => {
                                    if (!country.isNewRecord && isEditFlow) {
                                        if (country.agencyOrOfficialFeeUpdated) {
                                            return country.officialFeeFormula;
                                        } else {
                                            return country.selectedListOfficialFeeFormula;
                                        }
                                    } else {
                                        return country.officialFeeFormula;
                                    }
                                })(),
                                translationFeeFormula: (() => {
                                    if (!country.isNewRecord && isEditFlow) {
                                        return country.translationFeeUpdated
                                            ? country.agencyFeeFormula
                                            : country.selectedListTranslationFeeFormula;
                                    } else {
                                        return country.translationFeeFormula;
                                    }
                                })(),
                                includeAgencyFee,
                                includeOfficialFee,
                                includeTranslationFee,
                                agencyOrOfficialFeeUpdated: (() => {
                                    if (!isEditFlow) return undefined;
                                    if (country.isNewRecord) return false;
                                    return country.agencyOrOfficialFeeUpdated ?? false;
                                })(),
                                translationFeeUpdated: (() => {
                                    if (!isEditFlow) return undefined;
                                    if (country.isNewRecord) return false;
                                    return country.translationFeeUpdated ?? false;
                                })(),
                                isUserPreferredAiTranslation:
                                    country.isUserPreferredAiTranslationUpdated ?? null
                            });
                    }
                );

                if (
                    selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList.some(
                        (country) => country.isUp && country.isSelected
                    )
                ) {
                    if (orderCountryEdit?.isEpOrder) return;
                    selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList?.map(
                        (country) => {
                            country.isUp &&
                                selectedCountriesList.push({
                                    countryId: country.id,
                                    countryName: country.countryName,
                                    languageId: country.languageId,
                                    entityType: 0,
                                    EP: false,
                                    UP: country.isUp,
                                    agencyFee: (() => {
                                        if (
                                            isUPFeeID === serviceIncludedOptions.agencyFee.id ||
                                            isUPFeeID === serviceIncludedOptions.allFees.id
                                        ) {
                                            if (isEditFlow) {
                                                if (
                                                    upAndNationalValidationsFees?.agencyOrOfficialFeeUpdated
                                                ) {
                                                    return (
                                                        selectCountryPageForEP
                                                            ?.epTranslationAndValidationData
                                                            ?.upAgencyFee ?? 0
                                                    );
                                                } else {
                                                    return upAndNationalValidationsFees?.agencyFee;
                                                }
                                            } else {
                                                return (
                                                    selectCountryPageForEP
                                                        ?.epTranslationAndValidationData
                                                        ?.upAgencyFee ?? 0
                                                );
                                            }
                                        } else {
                                            return 0;
                                        }
                                    })(),
                                    translationRate: country.translationRate,
                                    officialFee: null,
                                    agencyFeeFormula: (() => {
                                        if (isEditFlow) {
                                            if (
                                                upAndNationalValidationsFees?.agencyOrOfficialFeeUpdated
                                            ) {
                                                return country.agencyFeeFormula;
                                            } else {
                                                return country.selectedListAgencyFeeFormula;
                                            }
                                        } else {
                                            return country.agencyFeeFormula;
                                        }
                                    })(),
                                    officialFeeFormula: null,
                                    translationFeeFormula: null,
                                    includeAgencyFee:
                                        isUPFeeID === serviceIncludedOptions.agencyFee.id ||
                                        isUPFeeID === serviceIncludedOptions.allFees.id,
                                    includeOfficialFee: null,
                                    includeTranslationFee: null,
                                    agencyOrOfficialFeeUpdated: isEditFlow
                                        ? (upAndNationalValidationsFees?.agencyOrOfficialFeeUpdated ??
                                          false)
                                        : undefined,
                                    translationFeeUpdated: isEditFlow ? false : undefined
                                });
                        }
                    );
                }
                if (
                    (isUPFeeID === serviceIncludedOptions.translationFee.id ||
                        isUPFeeID === serviceIncludedOptions.allFees.id) &&
                    selectCountryPageForEP?.epTranslationAndValidationData?.epCountryResponseList.some(
                        (country) => country.isUp && country.isSelected
                    )
                ) {
                    if (orderCountryEdit?.isEpOrder) return;
                    selectedCountriesList.push({
                        countryId: null,
                        languageId:
                            selectCountryPageForEP?.epTranslationAndValidationData?.upTargetLanguage
                                ?.targetLanguageId ?? null,
                        entityType: 0,
                        EP: false,
                        UP: true,
                        isClaim: false,
                        agencyFee: 0,
                        translationFee: (() => {
                            if (isEditFlow) {
                                if (upAndNationalValidationsFees?.translationFeeUpdated) {
                                    return (
                                        selectCountryPageForEP?.epTranslationAndValidationData
                                            ?.upTargetLanguage?.translationFee ?? 0
                                    );
                                } else {
                                    return upAndNationalValidationsFees?.translationFee ?? 0;
                                }
                            } else {
                                return (
                                    selectCountryPageForEP?.epTranslationAndValidationData
                                        ?.upTargetLanguage?.translationFee ?? 0
                                );
                            }
                        })(),
                        officialFee: 0,
                        includeAgencyFee: null,
                        includeOfficialFee: null,
                        includeTranslationFee: true,
                        translationFeeFormula: (() => {
                            let formula = null;
                            if (isEditFlow) {
                                if (upAndNationalValidationsFees?.translationFeeUpdated) {
                                    formula =
                                        selectCountryPageForEP?.epTranslationAndValidationData
                                            ?.upTargetLanguage?.translationFeeFormula ?? null;
                                } else {
                                    formula =
                                        selectCountryPageForEP?.epTranslationAndValidationData?.selectedCountryFullList?.find(
                                            (item) => item.countryId === null && item.languageId
                                        )?.translationFeeFormula ?? null;
                                }
                            } else {
                                formula =
                                    selectCountryPageForEP?.epTranslationAndValidationData
                                        ?.upTargetLanguage?.translationFeeFormula ?? null;
                            }
                            return formula;
                        })(),
                        agencyOrOfficialFeeUpdated: false,
                        translationFeeUpdated:
                            upAndNationalValidationsFees?.translationFeeUpdated ?? false
                    });
                }
            } else {
                selectCountryPageForEP?.countryList?.map((country) => {
                    country.isSelected &&
                        selectedCountriesList.push({
                            countryId: country.data.id,
                            languageId: country.data.languageId,
                            entityType: 0,
                            EP: true,
                            UP: country.data.up == null ? false : country.data.up
                        });
                });

                selectCountryPageForEP?.countryList?.map((country) => {
                    country.isUpSelected &&
                        country.data.up &&
                        selectedCountriesList.push({
                            countryId: country.data.id,
                            languageId: country.data.languageId,
                            entityType: 0,
                            EP: false,
                            UP: country.data.up
                        });
                });
            }
        } else {
            selectedCountriesList = [];
            selectCountryPage?.customCountries?.map((country) => {
                country.isSelected &&
                    selectedCountriesList.push({
                        countryId: country.data.id,
                        languageId: country.data.languageId,
                        entityType: 0,
                        EP: null,
                        UP: null
                    });
            });
            selectCountryPage?.instantCountries?.map((country) => {
                country.isSelected &&
                    selectedCountriesList.push({
                        countryId: country.data.id,
                        languageId: country.data.languageId,
                        entityType: country.selectedWipoEntityId ?? 0,
                        EP: null,
                        UP: null
                    });
            });
        }

        return selectedCountriesList;
    };
    countriesId();

    // helper
    const getCompanyId = () => {
        let companyId = null;

        if (companyDetailsPageFormData?.selectedCompany) {
            companyId = companyDetailsPageFormData.selectedCompany.id;
        } else if (patentDetailsPage.companyName) {
            companyId = patentDetailsPage.companyName;
        }

        return companyId;
    };
    const getContactUser = () => {
        let contactUserId = null;

        if (isThisCUserExcludedSalesRep) {
            // CM/CU does not have 'contact-user' dropdown. so we have to manually set on Payload
            contactUserId = loggedInUserInfo.userId;
        } else if (companyDetailsPageFormData) {
            contactUserId = companyDetailsPageFormData?.selectedContact?.id;
        } else {
            contactUserId = patentDetailsPage?.contactUser?.id;
        }

        return contactUserId;
    };
    const getPatentNumber = (type: 'publication' | 'application') => {
        const userTypesValue = companyDetailsPageFormData?.publicationNumber ?? null;
        let number = null;

        if (isPCT) {
            if (type === 'publication') {
                number = companyDetailsPageFormData?.patentDetails?.patentPublicationNumber;
            } else if (type === 'application') {
                number = companyDetailsPageFormData?.patentDetails?.pctReference;
            }
        }

        if (isEP) {
            if (type === 'publication') {
                number = companyDetailsPageFormData?.patentDetails?.patentPublicationNumber;
            } else if (type === 'application') {
                number = companyDetailsPageFormData?.patentDetails?.patentApplicationNumber;
            }
        }

        return number ?? userTypesValue;
    };
    const getDateTime = (pageData: any, key: string) => {
        const date = pageData?.[key];
        if (date && date !== '') return formatDateYYMMDD(date as string);
        return null;
    };
    const getSourceLanguageCode = () => {
        if (isPC) {
            return patentDetailsPage?.sourceLanguage || '';
        } else {
            return companyDetailsPageFormData?.patentDetails?.sourceLanguage;
        }
    };

    if (quoteOrderData.info.selectedService?.serviceTypeId === SERVICE_TYPE_ID.european_patent) {
        if (patentDetailsPage?.english) {
            selectedCountriesList.push({
                countryId: 0,
                languageId: LANGUAGE_ID.ENGLISH,
                entityType: 0,
                EP: null,
                UP: null,
                isClaim: true
            });
        }
        if (patentDetailsPage?.german) {
            selectedCountriesList.push({
                countryId: 0,
                languageId: LANGUAGE_ID.GERMAN,
                entityType: 0,
                EP: null,
                UP: null,
                isClaim: true
            });
        }
        if (patentDetailsPage?.french) {
            selectedCountriesList.push({
                countryId: 0,
                languageId: LANGUAGE_ID.FRENCH,
                entityType: 0,
                EP: null,
                UP: null,
                isClaim: true
            });
        }
    }
    let data;
    if (orderCountryEdit?.isOrderEdit) {
        data = {
            requestId: orderCountryEdit.orderId,
            referenceNo: orderCountryEdit.draftId,
            patentCountrySummaryList: selectedCountriesList,
            isAddOrRemoveCountries: orderCountryEdit.isAddOrRemoveCountries ?? false,
            hasOrderCostUpdated: orderCountryEdit.hasOrderCostUpdated ?? false,
            noEnglishTranslationRequired: orderCountryEdit.noEnglishTranslationRequired ?? false
        };
    } else {
        data = {
            referenceNo: primaryId,
            requestTypeId: info.mode,
            patentCategoryId: info.selectedCategory?.parentId,
            patentServiceTypeId: info.selectedCategory?.patentCategoryId,
            isClaims713: patentDetailsPage.ifEpGrantedYesNo ?? false,
            requestCurrencyId:
                selectCountryPageForEP?.epTranslationAndValidationData?.requestCurrencyId ||
                quoteOrderData?.info?.requestCurrencyId,
            companyAuthentication: {
                companyId: getCompanyId(),
                contactUserId: getContactUser(),
                patentPublicationNumber: getPatentNumber('publication'),
                patentDetails: {
                    patentTitle: companyDetailsPageFormData?.patentDetails?.title,
                    patentTitleFrench: companyDetailsPageFormData?.patentDetails?.titleFR ?? '',
                    patentTitleGerman: companyDetailsPageFormData?.patentDetails?.titleDE ?? '',
                    referenceNumber: patentDetailsPage?.referenceNo || '',
                    salesRepresentative: getSalesRep(),
                    patentApplicationNumber: getPatentNumber('application'),
                    patentPublicationNumber: getPatentNumber('publication'),
                    applicant: patentDetailsPage.applicantName ?? '',
                    sourceLanguageCode: getSourceLanguageCode(),
                    monthDeadline30:
                        companyDetailsPageFormData?.patentDetails?.textthirtyMonthsDeadline,
                    specialInstructions: patentDetailsPage.specialInstructions,
                    numberOfPriorityApplications:
                        companyDetailsPageFormData?.patentDetails?.numberOfPriorityClaims ?? 0,
                    numberOfClaims: companyDetailsPageFormData?.patentDetails?.numberOfClaims ?? 0,
                    numberOfIndependentClaims: patentDetailsPage.numberOfIndependentClaims ?? 0,
                    estimatedNumberOfTotalPages:
                        companyDetailsPageFormData?.patentDetails?.estTotalPages ?? 0,
                    descriptionPageCount:
                        companyDetailsPageFormData?.patentDetails?.descriptionPageCount ?? 0,
                    claimsPageCount:
                        companyDetailsPageFormData?.patentDetails?.claimsPageCount ?? 0,
                    drawingsPageCount:
                        companyDetailsPageFormData?.patentDetails?.drawingsPageCount ?? 0,
                    totalPageCount: companyDetailsPageFormData?.patentDetails?.totalPageCount ?? 0,
                    claimsWordCount:
                        companyDetailsPageFormData?.patentDetails?.claimsWordCount ?? 0,
                    numberOfApplicants:
                        utils.handleGetApplicantCount(String(patentDetailsPage?.applicantName)) ??
                        0,
                    descriptionWordCount:
                        companyDetailsPageFormData?.patentDetails?.descriptionWordCount ?? 0,
                    drawingsWordCount:
                        companyDetailsPageFormData?.patentDetails?.drawingsWordCount ?? 0,
                    abstractWordCount:
                        companyDetailsPageFormData?.patentDetails?.abstractWordCount ?? 0,
                    descriptionAndDrawingsWordCount:
                        companyDetailsPageFormData?.patentDetails
                            ?.descriptionandDrawingswordcount ?? 0,
                    numberOfPriorities:
                        companyDetailsPageFormData?.patentDetails?.numberofPriorities ?? 0,
                    specificationPageCount:
                        companyDetailsPageFormData?.patentDetails?.specificationPageCount ?? 0,

                    numberOfDrawings:
                        companyDetailsPageFormData?.patentDetails?.numberofDrawings ?? 0,
                    kind: patentDetailsPage.kind,
                    filingDeadLine: getDateTime(
                        // for PC we don't get filing date from the DB (no pub-num verification for PC)
                        isPC ? patentDetailsPage : companyDetailsPageFormData?.patentDetails,
                        isPC
                            ? 'filingDeadLine' /** lbl: Filing Deadline */
                            : 'filingDate' /** got while verify */
                    ),
                    requestedDeliveryDate: getDateTime(patentDetailsPage, 'requestedDeliveryDate'),
                    requestedDeliveryDateForClaimsTranslation: getDateTime(
                        patentDetailsPage,
                        'requestedDeliveryDateForClaimsTranslation'
                    ),
                    statutoryDeadlineDate: getDateTime(patentDetailsPage, 'statutoryDeadlineDate'),
                    requestedFilingDeadLine: isEP
                        ? getDateTime(patentDetailsPage, 'europeanFilingDate') // lbl: European Filing Date
                        : getDateTime(patentDetailsPage, 'requestedFilingDeadLine'), // lbl: Requested Filing Date
                    validationDeadline: getDateTime(
                        patentDetailsPage,
                        'validationDeadline'
                    ) /** got while verify */,
                    upDeadLine: getDateTime(
                        patentDetailsPage,
                        'validationDeadlineUP'
                    ) /** got while verify */,
                    po: patentDetailsPage.po ?? '',
                    patentTitleWordCount:
                        companyDetailsPageFormData?.patentDetails?.patentTitleWordCount ?? 0
                }
            },
            patentCountDetails: {
                referenceNumber: patentDetailsPage?.referenceNo || '',
                abstractWordCount: patentDetailsPage.abstractWordCount ?? 0,
                drawingsWordCount: patentDetailsPage.drawingsWordCount ?? 0,
                descriptionWordCount: patentDetailsPage.descriptionWordCount ?? 0,
                claimsWordCount: patentDetailsPage.claimsWordCount ?? 0,
                drawingsPageCount: patentDetailsPage.drawingsPageCount ?? 0,
                estimatedNumberOfTotalPages: patentDetailsPage.estTotalPages ?? 0,
                numberOfDrawings: patentDetailsPage.numberOfDrawings ?? 0,
                specificationWordCount: patentDetailsPage.specificationWordCount ?? 0,
                numberOfIndependentClaims: patentDetailsPage.numberOfIndependentClaims ?? 0,
                estimatedSequenceListing: patentDetailsPage.estimatedSequenceListing ?? 0,
                numberOfPriorityApplications: patentDetailsPage.numberOfPriorityClaims ?? 0,
                numberOfClaims: patentDetailsPage.numberOfClaims ?? 0,
                descriptionPageCount: patentDetailsPage.descriptionPageCount ?? 0,
                claimsPageCount: patentDetailsPage.claimsPageCount ?? 0,
                validationDeadline: getDateTime(patentDetailsPage, 'validationDeadline'),
                totalPageCount: patentDetailsPage.numberTotalPages ?? 0,
                claimsPriority:
                    patentDetailsPage.applicationClaimsPriority === YES_NO.YES ? true : false,
                patentTitleWordCount: patentDetailsPage?.patentTitleWordCount ?? 0
            },
            patentSelectCountries: selectedCountriesList,
            totalWordCount: patentDetailsPage.totalWords ?? 0,
            grandTotal: 0,
            epUpGrandTotal: {
                ClaimsTotal: selectCountryPageForEP?.epUpGrandTotal?.claimsTotal ?? 0,
                epTotal: selectCountryPageForEP?.epUpGrandTotal?.epTotal ?? 0,
                upTotal: selectCountryPageForEP?.epUpGrandTotal?.upTotal ?? 0
            }
        };
    }

    try {
        toggleLoadingIndicator(true);
        const response = await httpService.post<T, T>(
            apiUrl,
            data as T,
            {
                data: {
                    hideLoader: true
                }
            },
            false,
            baseURL
        );
        toggleLoadingIndicator(false);
        return response as T & { requestId: number };
    } catch (error) {
        toggleLoadingIndicator(false);
        console.error('Error saving draft:', error);
        throw error;
    }
};

const handleGetSourceLanguageId = (language: string) => {
    const id = LANGUAGE_ID[language.toUpperCase() as keyof typeof LANGUAGE_ID];
    return id;
};

const generateGetCountryListPayload = (currencyId: number) => {
    const quoteOrderData = getQuoteOrderStoreData();
    const info = quoteOrderData.info;
    const isEditFlow = info.isEditFlow;
    const selectedService = info.selectedService;
    const companyDetailsPageFormData = quoteOrderData.formData.companyDetailsPage;
    const additionalInfoPage = quoteOrderData.formData.additionalInfoPage;
    const patentDetailsPage = quoteOrderData.formData.patentDetailsPage;

    return {
        patentServiceId: selectedService?.serviceTypeId ?? 0,
        companyId: companyDetailsPageFormData?.selectedCompany?.id ?? 0,
        requestCurrencyId: currencyId,
        sourceLanguageId: handleGetSourceLanguageId(String(patentDetailsPage?.sourceLanguageName)),
        requestId: isEditFlow
            ? quoteOrderData?.editFlowResponseData?.info.primaryId
            : (info.primaryId ?? 0),
        patentDetails: {
            patentTitle: companyDetailsPageFormData?.patentDetails?.title ?? '',
            patentTitleFrench: companyDetailsPageFormData?.patentDetails?.titleFR ?? '',
            patentTitleGerman: companyDetailsPageFormData?.patentDetails?.titleDE ?? '',
            requestByUserId: additionalInfoPage?.requestedByUserId ?? 0,
            requestedBy: additionalInfoPage?.requestedBy ?? '',
            salesRepresentative: patentDetailsPage?.salesRepId?.toString() ?? '',
            patentApplicationNumber:
                companyDetailsPageFormData?.patentDetails?.patentApplicationNumber ?? '',
            patentPublicationNumber:
                companyDetailsPageFormData?.patentDetails?.patentPublicationNumber ?? '',
            applicantId: patentDetailsPage?.applicantId ?? 0,
            applicant: patentDetailsPage?.applicantName ?? '',
            sourceLanguageCode: companyDetailsPageFormData?.patentDetails?.sourceLanguage ?? '',
            sourceLanguageId: handleGetSourceLanguageId(
                String(patentDetailsPage?.sourceLanguageName)
            ),
            monthDeadline30:
                companyDetailsPageFormData?.patentDetails?.textthirtyMonthsDeadline ?? '',
            requestedDeliveryDate: patentDetailsPage?.requestedDeliveryDate || null,
            referenceNumber: patentDetailsPage?.referenceNo ?? '',
            fillingDeadLine: patentDetailsPage?.filingDeadLine || null,
            requestedFillingDeadLine: patentDetailsPage?.requestedFillingDeadLine || null,
            specialInstructions: patentDetailsPage?.specialInstructions ?? '',
            numberOfPriorityApplications: patentDetailsPage?.numberOfPriorityClaims ?? 0,
            numberOfClaims: patentDetailsPage?.numberOfClaims ?? 0,
            numberOfIndependentClaims: patentDetailsPage?.numberOfIndependentClaims ?? 0,
            estimatedNumberOfTotalPages: patentDetailsPage?.estTotalPages ?? 0,
            descriptionPageCount: patentDetailsPage?.descriptionPageCount ?? 0,
            claimsPageCount: patentDetailsPage?.claimsPageCount ?? 0,
            validationDeadline: patentDetailsPage?.validationDeadline || null,
            translationRate: patentDetailsPage?.translationRate ?? 0,
            drawingsPageCount: patentDetailsPage?.drawingsPageCount ?? 0,
            totalPageCount: patentDetailsPage?.totalPageCount ?? 0,
            exchangeRate: patentDetailsPage?.exchangeRate ?? 0,
            claimsWordCount: patentDetailsPage?.claimsWordCount ?? 0,
            numberOfApplicants:
                utils.handleGetApplicantCount(String(patentDetailsPage?.applicantName)) ?? 0,
            descriptionWordCount: patentDetailsPage?.descriptionWordCount ?? 0,
            drawingsWordCount: patentDetailsPage?.drawingsWordCount ?? 0,
            abstractWordCount: patentDetailsPage?.abstractWordCount ?? 0,
            descriptionAndDrawingsWordCount:
                patentDetailsPage?.descriptionandDrawingswordcount ?? 0,
            numberOfPriorities: patentDetailsPage?.numberofPriorities ?? 0,
            specificationPageCount: patentDetailsPage?.specificationPageCount ?? 0,
            numberOfDrawings: patentDetailsPage?.numberofDrawings ?? 0,
            specificationWordCount: patentDetailsPage?.specificationWordCount ?? 0,
            kind: patentDetailsPage?.kind ?? '',
            statutoryClaimDeadline: patentDetailsPage?.statutoryClaimDeadline || null,
            requestedDeliveryDateForClaimsTranslation:
                patentDetailsPage?.requestedDeliveryDateForClaimsTranslation || null,
            statutoryDeadlineDate: patentDetailsPage?.statutoryDeadlineDate || null,
            upDeadLine: patentDetailsPage?.upDeadLine || null,
            europeanFilingDate: patentDetailsPage?.europeanFilingDate || null,
            filingDeadLine: patentDetailsPage?.filingDeadLine || null,
            requestedFilingDeadLine: patentDetailsPage?.requestedFilingDeadLine || null
        }
    };
};

const getEpCountryListing = async <T = EpCountriesData>(currencyId: number): Promise<T> => {
    const apiUrl = END_POINT.SELECT_COUNTRY.GET_EP_COUNTRY_LISTING;
    try {
        const response = await httpService.post<T, T>(
            apiUrl,
            generateGetCountryListPayload(currencyId) as T,
            {},
            false,
            baseURL
        );
        return response;
    } catch (error) {
        console.error('Error fetching EP country listing:', error);
        throw error;
    }
};

const getEpOrderEditCountryListing = async <T = EpCountriesData>(orderId: number): Promise<T> => {
    const apiUrl = END_POINT.SELECT_COUNTRY.GET_ORDER_EP_COUNTRY_LISTING_EDIT;
    try {
        const response = await httpService.get<T>(`${apiUrl}/${orderId}`, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error('Error fetching EP country listing for order edit:', error);
        throw error;
    }
};

const getVendorAssignmentValidation = async <
    T = {
        orderId: number;
        isCountryRemovable: boolean;
        taskIds: string;
        taskNumbers: string;
        isIndirectTranslationAvailable: boolean;
    }
>(reqVendorAssignmentValidation: {
    orderId: number;
    countryId: number;
    isTranslationFeeSelected: boolean;
    isValidationAgencyOrOfficialFeeSelected: boolean;
    isIndirectTranslationAvailable: boolean;
}): Promise<T> => {
    const apiUrl = END_POINT.SELECT_COUNTRY.VALIDATE_VENDOR_ASSIGNMENT;
    try {
        const response = await httpService.post<T, T>(
            apiUrl,
            reqVendorAssignmentValidation as T,
            {},
            false,
            baseURL
        );
        return response;
    } catch (error) {
        console.error('Error validating vendor assignment:', error);
        throw error;
    }
};

// updateCountryFees function used to update the country table cell edit in order details screen.
export const getTranslationModeValidation = async (
    body: VendorAssignmentCheckRequestBody
): Promise<any> => {
    const apiUrl = END_POINT.SELECT_COUNTRY.VALIDATE_VENDOR_ASSIGNMENT;
    try {
        const response = await httpService.post(apiUrl, body, {}, false, baseURL);
        return response;
    } catch (error) {
        console.error(`Error validating vendor assignment :`, error);
        throw error;
    }
};

const selectCountryService = {
    getCountriesData,
    orderSaveDraft,
    getEpCountryListing,
    getVendorAssignmentValidation,
    getTranslationModeValidation,
    getEpOrderEditCountryListing
};

export default selectCountryService;
