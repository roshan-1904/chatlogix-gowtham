import selectCountryService from './selectCountry.service';
import HttpService from 'core/interceptor/api.handler';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';
import { YES_NO } from 'constants/app.constant';
import { waitFor } from '@testing-library/react';

jest.mock('core/interceptor/api.handler');
jest.mock('core/store/orderQuoteStore/orderQuote.store');
jest.mock('core/store/authStore/authStore');
jest.mock('core/utils/utils');

describe('selectCountryService', () => {
    const baseURL = 'http://example.com';
    process.env.REACT_APP_QUOTE_BASE_URL = baseURL;
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('getCountriesData', () => {
        const patentType = 1;
        it('should fetch getCountriesData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await selectCountryService.getCountriesData(patentType);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(selectCountryService.getCountriesData(patentType)).rejects.toThrow(
                mockError
            );
        });
    });
    // describe('getCountriesData', () => {
    //     it('should fetch countries data successfully', async () => {
    //         const mockResponse = { data: 'mockData' };
    //         HttpService.prototype.get = jest.fn().mockResolvedValue(mockResponse);

    //         const result = await selectCountryService.getCountriesData<number>(1);

    //         waitFor(() => {
    //             expect(HttpService.prototype.get).toHaveBeenCalledWith(
    //                 `${END_POINT.SELECT_COUNTRY.GET_COUNTRIES}/1`,
    //                 {},
    //                 false,
    //                 baseURL
    //             );
    //             expect(result).toEqual(mockResponse);
    //         });
    //     });

    //     // it('should throw an error if fetching countries data fails', () => {
    //     //     const mockError = new Error('Fetch error');
    //     //     HttpService.prototype.get = jest.fn().mockRejectedValue(mockError);

    //     //     waitFor(() => {
    //     //         expect(selectCountryService.getCountriesData<number>(1)).rejects.toThrow(
    //     //             'Fetch error'
    //     //         );
    //     //     });
    //     // });
    // });

    describe('orderSaveDraft', () => {
        it('should save order draft successfully', async () => {
            const mockResponse = { requestId: 123 };
            HttpService.prototype.post = jest.fn().mockResolvedValue(mockResponse);

            AuthStore.getUserInfo = jest.fn().mockReturnValue({
                userInfo: { roleId: 1, userId: 1 }
            });
            quoteOrderModuleStore.getData = jest.fn().mockReturnValue({
                info: {
                    primaryId: 1,
                    mode: 1,
                    selectedCategory: { parentId: 1, patentCategoryId: 1 },
                    selectedService: { serviceTypeId: SERVICE_TYPE_ID.european_patent }
                },
                formData: {
                    companyDetailsPage: {
                        selectedCompany: { id: 1 },
                        patentDetails: {
                            salesRepId: 1,
                            title: 'title',
                            referenceNo: 'refNo',
                            patentApplicationNumber: 'appNo',
                            patentPublicationNumber: 'pubNo',
                            sourceLanguage: 'EN',
                            textthirtyMonthsDeadline: '2023-01-01',
                            numberOfPriorityClaims: 1,
                            numberOfClaims: 1,
                            estTotalPages: 1,
                            descriptionPageCount: 1,
                            claimsPageCount: 1,
                            drawingsPageCount: 1,
                            totalPageCount: 1,
                            claimsWordCount: 1,
                            numberofapplicants: 1,
                            descriptionWordCount: 1,
                            drawingsWordCount: 1,
                            abstractWordCount: 1,
                            descriptionandDrawingswordcount: 1,
                            numberofPriorities: 1,
                            specificationPageCount: 1,
                            numberofDrawings: 1
                        },
                        publicationNumber: 'pubNo'
                    },
                    additionalInfoPage: {
                        salesRep: [1]
                    },
                    patentDetailsPage: {
                        applicantName: 'applicant',
                        ifEpGrantedYesNo: true,
                        specialInstructions: 'instructions',
                        // Remove one of the duplicate properties
                        kind: 'A',
                        filingDeadLine: '2023-01-01',
                        requestedDeliveryDate: '2023-01-01',
                        requestedDeliveryDateForClaimsTranslation: '2023-01-01',
                        statutoryDeadlineDate: '2023-01-01',
                        europeanFilingDate: '2023-01-01',
                        validationDeadline: '2023-01-01',
                        validationDeadlineUP: '2023-01-01',
                        po: 'po',
                        referenceNo: 'refNo',
                        abstractWordCount: 1,
                        drawingsWordCount: 1,
                        descriptionWordCount: 1,
                        claimsWordCount: 1,
                        drawingsPageCount: 1,
                        estTotalPages: 1,
                        numberOfDrawings: 1,
                        specificationWordCount: 1,
                        numberOfIndependentClaims: 1,
                        estimatedSequenceListing: 1,
                        numberOfPriorityClaims: 1,
                        numberOfClaims: 1,
                        descriptionPageCount: 1,
                        claimsPageCount: 1,
                        numberTotalPages: 1,
                        applicationClaimsPriority: YES_NO.YES,
                        totalWords: 1
                    },
                    selectCountryPage: {
                        customCountries: [
                            {
                                isSelected: true,
                                data: { id: 1, languageId: 1 }
                            }
                        ],
                        instantCountries: [
                            {
                                isSelected: true,
                                data: { id: 1, languageId: 1, selectedWipoEntityId: 1 }
                            }
                        ]
                    },
                    selectCountryPageForEP: {
                        countryList: [
                            {
                                isSelected: true,
                                data: { id: 1, languageId: 1, up: true },
                                isUpSelected: true
                            }
                        ]
                    }
                }
            });
            const result = await selectCountryService.orderSaveDraft();
            waitFor(() => {
                expect(HttpService.prototype.post).toHaveBeenCalledWith(
                    END_POINT.ORDER_SAVE_DRAFT,
                    expect.any(Object),
                    {},
                    false,
                    baseURL
                );
                expect(result).toEqual(mockResponse);
            });
        });
    });
});
