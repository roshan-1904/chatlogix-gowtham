import { render } from '@testing-library/react';
import SelectCountry from './selectCountry';
import CountryListingEP from './ep/countryListingEP';
import CountryListingNonEP from './pct/countryListingNonEP';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { SERVICE_TYPE_ID } from 'constants/progressStepper.constant';

jest.mock('./ep/countryListingEP');
jest.mock('./pct/countryListingNonEP');
jest.mock('core/store/orderQuoteStore/orderQuote.store');

describe('SelectCountry Component', () => {
    beforeEach(() => {
        (CountryListingEP as jest.Mock).mockImplementation(() => <div>EP Component</div>);
        (CountryListingNonEP as jest.Mock).mockImplementation(() => <div>Non-EP Component</div>);
    });

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should render CountryListingEP when selected service type is European Patent', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                selectedService: {
                    serviceTypeId: SERVICE_TYPE_ID.european_patent
                }
            }
        });

        const { getByText } = render(<SelectCountry />);

        expect(getByText('EP Component')).toBeInTheDocument();
        expect(CountryListingEP).toHaveBeenCalled();
    });

    it('should render CountryListingNonEP when selected service type is not European Patent', () => {
        (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue({
            info: {
                selectedService: {
                    serviceTypeId: 'some_other_service_type'
                }
            }
        });

        const { getByText } = render(<SelectCountry />);

        expect(getByText('Non-EP Component')).toBeInTheDocument();
        expect(CountryListingNonEP).toHaveBeenCalled();
    });
});
