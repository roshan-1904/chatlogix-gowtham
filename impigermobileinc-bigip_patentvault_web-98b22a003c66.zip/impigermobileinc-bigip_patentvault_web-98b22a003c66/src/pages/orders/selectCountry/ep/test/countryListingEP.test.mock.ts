export const storeMock = {
    serviceTypePage: {
        serviceType: [
            {
                name: 'patent_cooperation_treaty',
                displayText: 'Patent Cooperation Treaty',
                displayOrder: 1,
                serviceTypeId: 1,
                patentType: 1,
                requestType: 1,
                isRequestEntity: null,
                imageIcon: 'i-Note-icon',
                serviceUniqueName: null,
                requestCurrencyId: 2,
                patentCategories: [
                    {
                        parentId: 1,
                        patentCategoryName: 'translation_only',
                        patentCategoryId: 6,
                        patentCategoryDisplay: 'Translation',
                        patentCategoryDisplayOrder: 1,
                        patentCategoryIsRequestEntity: false,
                        serviceUniqueName: 'PCT_TranslationOnly'
                    },
                    {
                        parentId: 1,
                        patentCategoryName: 'translation_&_filing',
                        patentCategoryId: 7,
                        patentCategoryDisplay: 'Translation & Filing',
                        patentCategoryDisplayOrder: 2,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'PCT_Translation_Filing'
                    },
                    {
                        parentId: 1,
                        patentCategoryName: 'recordal',
                        patentCategoryId: 9,
                        patentCategoryDisplay: 'Recordals',
                        patentCategoryDisplayOrder: 4,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'PCT_Recordals'
                    },
                    {
                        parentId: 1,
                        patentCategoryName: 'annuities',
                        patentCategoryId: 10,
                        patentCategoryDisplay: 'Annuities',
                        patentCategoryDisplayOrder: 5,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'PCT_Annuities'
                    }
                ],
                id: 0,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            },
            {
                name: 'european_patent',
                displayText: 'European Grant and Validations',
                displayOrder: 2,
                serviceTypeId: 2,
                patentType: 2,
                requestType: 1,
                isRequestEntity: null,
                imageIcon: 'i-write-icon',
                serviceUniqueName: null,
                requestCurrencyId: 6,
                patentCategories: [
                    {
                        parentId: 2,
                        patentCategoryName: '71_3_claims',
                        patentCategoryId: 11,
                        patentCategoryDisplay: '71(3) Claims(EP,UP)',
                        patentCategoryDisplayOrder: 1,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'EP_713Claims_EP_UP'
                    },
                    {
                        parentId: 2,
                        patentCategoryName: 'translation_only',
                        patentCategoryId: 12,
                        patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)',
                        patentCategoryDisplayOrder: 2,
                        patentCategoryIsRequestEntity: false,
                        serviceUniqueName: 'EP_713Claims_TranslationOnly_EP_UP'
                    },
                    {
                        parentId: 2,
                        patentCategoryName: 'translation_&_validation',
                        patentCategoryId: 13,
                        patentCategoryDisplay:
                            '71(3) Claims and Translation & Validation/Filing(EP,UP)',
                        patentCategoryDisplayOrder: 3,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'EP_713Claims_Translation_Validation_Filing_EP_UP'
                    },
                    {
                        parentId: 2,
                        patentCategoryName: 'recordal',
                        patentCategoryId: 15,
                        patentCategoryDisplay: 'Recordals (EP)',
                        patentCategoryDisplayOrder: 5,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'EP_Recordals_EP'
                    },
                    {
                        parentId: 2,
                        patentCategoryName: 'Renewals',
                        patentCategoryId: 16,
                        patentCategoryDisplay: 'Renewals (EP,UP)',
                        patentCategoryDisplayOrder: 6,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'EP_Renewals_EP_UP'
                    }
                ],
                id: 0,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            },
            {
                name: 'paris_convention_treaty',
                displayText: 'Paris Convention Treaty',
                displayOrder: 3,
                serviceTypeId: 3,
                patentType: 3,
                requestType: 1,
                isRequestEntity: null,
                imageIcon: 'i-book-icon',
                serviceUniqueName: null,
                requestCurrencyId: 2,
                patentCategories: [
                    {
                        parentId: 3,
                        patentCategoryName: 'translation_only',
                        patentCategoryId: 17,
                        patentCategoryDisplay: 'Translation',
                        patentCategoryDisplayOrder: 1,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'PC_TranslationOnly'
                    },
                    {
                        parentId: 3,
                        patentCategoryName: 'translation_&_filing',
                        patentCategoryId: 18,
                        patentCategoryDisplay: 'Translation & Filing ',
                        patentCategoryDisplayOrder: 2,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: 'PC_Translation_FilingOnly'
                    }
                ],
                id: 0,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            },
            {
                name: 'other_translations',
                displayText: 'Other',
                displayOrder: 5,
                serviceTypeId: 5,
                patentType: 4,
                requestType: 0,
                isRequestEntity: null,
                imageIcon: 'i-other-icon',
                serviceUniqueName: null,
                requestCurrencyId: 2,
                patentCategories: [
                    {
                        parentId: 5,
                        patentCategoryName: 'patent_non_filing',
                        patentCategoryId: 24,
                        patentCategoryDisplay: 'Patent Non-Filing',
                        patentCategoryDisplayOrder: 1,
                        patentCategoryIsRequestEntity: true,
                        serviceUniqueName: null
                    }
                ],
                id: 0,
                createdBy: null,
                createdAt: '0001-01-01T00:00:00',
                updatedBy: null,
                updatedAt: null,
                isActive: false
            }
        ],
        selectedServiceDetails: {
            serviceTypeId: 2,
            patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)'
        }
    },
    companyDetailsPage: {
        companyList: [
            {
                id: 614,
                name: '16072024-255',
                companyType: 1,
                parentCompanyId: null,
                salesRep: 2,
                salesRepName: 'Ameen yasir Ameen',
                requestCurrencyId: 2,
                isPoRequired: false
            }
        ],
        selectedCompany: {
            id: 4,
            name: 'Test Company 4',
            companyType: 0,
            parentCompanyId: null,
            salesRep: null,
            salesRepName: null,
            requestCurrencyId: 4,
            isPoRequired: false
        },
        selectedContact: {
            id: 71,
            firstName: 'CUSER 2',
            lastName: '',
            middleName: '',
            fullName: 'CUSER 2  ',
            roleId: null,
            email: 'cuser2@gmail.com',
            salesRepName: 'fhkklkllllll  test name',
            salesRepId: 185,
            contactInformation: null
        },
        contactUserList: [
            {
                id: 71,
                firstName: 'CUSER 2',
                lastName: '',
                middleName: '',
                fullName: 'CUSER 2  ',
                roleId: null,
                email: 'cuser2@gmail.com',
                salesRepName: 'fhkklkllllll  test name',
                salesRepId: 185,
                contactInformation: null
            },
            {
                id: 609,
                firstName: 'Nivethitha',
                lastName: 'Dinakaran',
                middleName: '',
                fullName: 'Nivethitha  Dinakaran',
                roleId: null,
                email: 'nivebigipbigip@gmail.com',
                salesRepName: 'contact user profile finial-2 test user test name',
                salesRepId: 278,
                contactInformation: null
            },
            {
                id: 818,
                firstName: 'mohan',
                lastName: 'r',
                middleName: '',
                fullName: 'mohan  r',
                roleId: null,
                email: 'biglcontactuser2024+mohan@gmail.com',
                salesRepName: 'k, James',
                salesRepId: 642,
                contactInformation: null
            }
        ],
        publicationNumber: 'EP3419868 ',
        patentDetails: {
            salesRepId: 185,
            salesRepName: 'fhkklkllllll  test name',
            id: {
                timestamp: 1614717504,
                machine: 3070930,
                pid: -31154,
                increment: 8042318,
                creationTime: '2021-03-02T20:38:24Z'
            },
            createdAt: '2021-01-30T02:54:27Z',
            updatedAt: '2021-01-30T02:54:27Z',
            filePath:
                'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
            sourceLanguageName: 'English',
            sourceLanguage: 'EN',
            patentPublicationNumber: 'EP3419868',
            kind: 'A1',
            patentPublicationDate: '',
            fileName: 'EP16706187NWA1.xml',
            patentApplicationNumber: '16706187.8',
            descriptionWordCount: 3073,
            numberOfClaims: 8,
            claimWordCount: 865,
            claimsWordCount: 865,
            title: 'WINDSCREEN WIPER DEVICE',
            validationDeadline: '',
            communicationOfIntentionDate: '',
            statutoryDeadline: '',
            descriptionPageCount: 7,
            claimsPageCount: 3,
            drawingsPageCount: 10,
            applicantAddress: 'Avenue Champion , 6790 Aubange',
            applicantCountry: 'BE',
            applicantName: 'Federal-Mogul S.A.',
            agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
            agentCountry: 'NL',
            agentName: 'Hooiveld, Arjen Jan Winfried',
            applicantCount: 1,
            titleFR: '',
            titleDE: '',
            validationDeadlineUP: '',
            originalDescriptionWordCount: 3073,
            originalNumberOfClaims: 8,
            originalClaimsWordCount: 865,
            originalDrawingsPageCount: 10,
            originalClaimsPageCount: 3,
            originalApplicantCount: 1
        },
        isFormSubmitting: true,
        formData: {
            companyName: {
                isReadonly: false,
                isAutoPopulate: false,
                isMandatory: true,
                isError: false
            },
            contactUser: {
                isShow: true,
                isReadonly: false,
                isAutoPopulate: false,
                isMandatory: true,
                isError: false
            },
            publicationNumber: {
                isReadonly: false,
                isError: false
            },
            patentDetails: {
                companyName: {
                    isReadonly: false,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                contactUser: {
                    isShow: true,
                    isReadonly: false,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                publicationNumber: {
                    isReadonly: false
                },
                patentDetails: {
                    isShow: false,
                    dataNotFoundForPatent: false
                },
                isShow: true
            },
            isDuplicate: {
                isError: false
            }
        }
    },
    additionalInfoPage: {
        id: {
            timestamp: 1614717504,
            machine: 3070930,
            pid: -31154,
            increment: 8042318,
            creationTime: '2021-03-02T20:38:24Z'
        },
        createdAt: '2021-01-30T02:54:27Z',
        updatedAt: '2021-01-30T02:54:27Z',
        filePath:
            'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
        sourceLanguageName: 'English',
        sourceLanguage: 'EN',
        patentPublicationNumber: 'EP3419868',
        kind: 'A1',
        patentPublicationDate: '',
        fileName: 'EP16706187NWA1.xml',
        patentApplicationNumber: '16706187.8',
        descriptionWordCount: 3073,
        numberOfClaims: 8,
        claimWordCount: 865,
        claimsWordCount: 865,
        title: 'WINDSCREEN WIPER DEVICE',
        validationDeadline: '',
        communicationOfIntentionDate: '',
        statutoryDeadline: '',
        descriptionPageCount: 7,
        claimsPageCount: 3,
        drawingsPageCount: 10,
        applicantAddress: 'Avenue Champion , 6790 Aubange',
        applicantCountry: 'BE',
        applicantName: 'Federal-Mogul S.A.',
        agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
        agentCountry: 'NL',
        agentName: 'Hooiveld, Arjen Jan Winfried',
        applicantCount: 1,
        titleFR: '',
        titleDE: '',
        validationDeadlineUP: '',
        originalDescriptionWordCount: 3073,
        originalNumberOfClaims: 8,
        originalClaimsWordCount: 865,
        originalDrawingsPageCount: 10,
        originalClaimsPageCount: 3,
        originalApplicantCount: 1
    },
    patentDetailsPage: {
        referenceNo: '',
        applicationClaimsPriority: 2,
        ifEpGrantedYesNo: false,
        selectedCategoryId: 12,
        mode: 1,
        roleId: 1,
        sourceLanguageFlag: 'EN',
        submit: true,
        requestedBy: 'Gopikrishna Saravana',
        salesRepId: null,
        salesRepName: null,
        applicantName: 'Federal-Mogul S.A.',
        sourceLanguage: 'EN',
        originalAbstractWordCount: '',
        originalDrawingsWordCount: '',
        descriptionWordCount: 3073,
        originalDescriptionWordCount: 3073,
        originalNumberOfDrawings: '',
        claimsWordCount: 865,
        originalClaimsWordCount: 865,
        drawingsPageCount: 10,
        originalDrawingsPageCount: 10,
        originalSpecificationWordCount: '',
        originalNumberOfPriorityClaims: '',
        numberOfClaims: 8,
        originalNumberOfClaims: 8,
        descriptionPageCount: 7,
        originalDescriptionPageCount: '',
        claimsPageCount: 3,
        originalClaimsPageCount: 3,
        originalNumberOfIndependentClaims: '',
        originalEstTotalPages: '',
        statutoryDeadlineDate: '',
        id: {
            timestamp: 1614717504,
            machine: 3070930,
            pid: -31154,
            increment: 8042318,
            creationTime: '2021-03-02T20:38:24Z'
        },
        createdAt: '2021-01-30T02:54:27Z',
        updatedAt: '2021-01-30T02:54:27Z',
        filePath:
            'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
        sourceLanguageName: 'English',
        patentPublicationNumber: 'EP3419868',
        kind: 'A1',
        patentPublicationDate: '',
        fileName: 'EP16706187NWA1.xml',
        patentApplicationNumber: '16706187.8',
        claimWordCount: 865,
        title: 'WINDSCREEN WIPER DEVICE',
        validationDeadline: '',
        communicationOfIntentionDate: '',
        statutoryDeadline: '',
        applicantAddress: 'Avenue Champion , 6790 Aubange',
        applicantCountry: 'BE',
        agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
        agentCountry: 'NL',
        agentName: 'Hooiveld, Arjen Jan Winfried',
        applicantCount: 1,
        titleFR: '',
        titleDE: '',
        validationDeadlineUP: '',
        originalApplicantCount: 1,
        requestedDeliveryDateForClaimsTranslation: null,
        selectedCompanyPoRequired: false,
        estimatedSequenceListing: 2
    },
    selectCountryPage: null,
    selectCountryPageEdit: null,
    selectCountryPageForEP: {
        countryList: [
            {
                isSelected: false,
                isUpSelected: false,
                data: {
                    id: 131,
                    name: 'France',
                    code: 'FR',
                    iconName: '077-france.svg',
                    wipoIq: null,
                    up: true,
                    pcIq: null,
                    languageId: null,
                    wipoEntitySize: null,
                    pcEntitySize: null,
                    epoState: 1,
                    concatCode: 'France (FR)',
                    latitude: '46.227638',
                    longitude: '2.213749'
                }
            },
            {
                isSelected: false,
                isUpSelected: false,
                data: {
                    id: 86,
                    name: 'Montenegro',
                    code: 'ME',
                    iconName: '230-montenegro.svg',
                    wipoIq: null,
                    up: false,
                    pcIq: null,
                    languageId: 151,
                    wipoEntitySize: null,
                    pcEntitySize: null,
                    epoState: 3,
                    concatCode: 'Montenegro (ME)',
                    latitude: '42.708678',
                    longitude: '19.37439'
                }
            },
            {
                isSelected: false,
                isUpSelected: false,
                data: {
                    id: 184,
                    name: 'San Marino',
                    code: 'SM',
                    iconName: '214-san-marino.svg',
                    wipoIq: null,
                    up: false,
                    pcIq: null,
                    languageId: 71,
                    wipoEntitySize: null,
                    pcEntitySize: null,
                    epoState: 1,
                    concatCode: 'San Marino (SM)',
                    latitude: '43.94236',
                    longitude: '12.457777'
                }
            },
            {
                isSelected: false,
                isUpSelected: false,
                data: {
                    id: 125,
                    name: 'Tunisia',
                    code: 'TN',
                    iconName: '013-tunisia.svg',
                    wipoIq: null,
                    up: false,
                    pcIq: null,
                    languageId: 5,
                    wipoEntitySize: null,
                    pcEntitySize: null,
                    epoState: 2,
                    concatCode: 'Tunisia (TN)',
                    latitude: '33.886917',
                    longitude: '9.537499'
                }
            }
        ],
        selectAllChecked: null,
        selectUpCountryChecked: null
    },
    summaryPage: null,
    orderQuoteDetailsPage: null,
    languageSelectionPage: null,
    standardPageForEdit: null
};

export const initialStoreData = {
    info: {
        mode: 1,
        selectedService: {
            name: 'european_patent',
            displayText: 'European Grant and Validations',
            displayOrder: 2,
            serviceTypeId: 2,
            patentType: 2,
            requestType: 1,
            isRequestEntity: null,
            imageIcon: 'i-write-icon',
            serviceUniqueName: null,
            requestCurrencyId: 6,
            patentCategories: [
                {
                    parentId: 2,
                    patentCategoryName: '71_3_claims',
                    patentCategoryId: 11,
                    patentCategoryDisplay: '71(3) Claims(EP,UP)',
                    patentCategoryDisplayOrder: 1,
                    patentCategoryIsRequestEntity: true,
                    serviceUniqueName: 'EP_713Claims_EP_UP'
                },
                {
                    parentId: 2,
                    patentCategoryName: 'translation_only',
                    patentCategoryId: 12,
                    patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)',
                    patentCategoryDisplayOrder: 2,
                    patentCategoryIsRequestEntity: false,
                    serviceUniqueName: 'EP_713Claims_TranslationOnly_EP_UP'
                },
                {
                    parentId: 2,
                    patentCategoryName: 'translation_&_validation',
                    patentCategoryId: 13,
                    patentCategoryDisplay:
                        '71(3) Claims and Translation & Validation/Filing(EP,UP)',
                    patentCategoryDisplayOrder: 3,
                    patentCategoryIsRequestEntity: true,
                    serviceUniqueName: 'EP_713Claims_Translation_Validation_Filing_EP_UP'
                },
                {
                    parentId: 2,
                    patentCategoryName: 'recordal',
                    patentCategoryId: 15,
                    patentCategoryDisplay: 'Recordals (EP)',
                    patentCategoryDisplayOrder: 5,
                    patentCategoryIsRequestEntity: true,
                    serviceUniqueName: 'EP_Recordals_EP'
                },
                {
                    parentId: 2,
                    patentCategoryName: 'Renewals',
                    patentCategoryId: 16,
                    patentCategoryDisplay: 'Renewals (EP,UP)',
                    patentCategoryDisplayOrder: 6,
                    patentCategoryIsRequestEntity: true,
                    serviceUniqueName: 'EP_Renewals_EP_UP'
                }
            ],
            id: 0,
            createdBy: null,
            createdAt: '0001-01-01T00:00:00',
            updatedBy: null,
            updatedAt: null,
            isActive: false
        },
        selectedCategory: {
            parentId: 2,
            patentCategoryName: 'translation_only',
            patentCategoryId: 12,
            patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)',
            patentCategoryDisplayOrder: 2,
            patentCategoryIsRequestEntity: false,
            serviceUniqueName: 'EP_713Claims_TranslationOnly_EP_UP'
        },
        primaryId: null,
        requestCurrencyId: null,
        requestNumber: null,
        documentId: null,
        isEditFlow: false,
        isUP: null,
        approveStatus: 1,
        statusId: null
    },
    flags: {
        storeUpdateWithSummaryData: null,
        isCountriesSyncedCompletedInEditMode: false,
        isSummaryPageTablesInlineEditInProgress: false,
        pagesMatchStatusWithBackupData: {
            isCompanyModified: false,
            isLanguagesModified: false,
            isCountsModified: false,
            isCountriesModified: false
        }
    },
    isFormValid: {
        'service-type': true,
        'company-details': false,
        'additional-info': null,
        'patent-details': true,
        'select-country': null,
        'file-upload': true,
        summary: true,
        'order-quote-details': null,
        'language-selection': true
    },
    formData: {
        serviceTypePage: {
            serviceType: [
                {
                    name: 'patent_cooperation_treaty',
                    displayText: 'Patent Cooperation Treaty',
                    displayOrder: 1,
                    serviceTypeId: 1,
                    patentType: 1,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-Note-icon',
                    serviceUniqueName: null,
                    requestCurrencyId: 2,
                    patentCategories: [
                        {
                            parentId: 1,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 6,
                            patentCategoryDisplay: 'Translation',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: false,
                            serviceUniqueName: 'PCT_TranslationOnly'
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'translation_&_filing',
                            patentCategoryId: 7,
                            patentCategoryDisplay: 'Translation & Filing',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'PCT_Translation_Filing'
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'recordal',
                            patentCategoryId: 9,
                            patentCategoryDisplay: 'Recordals',
                            patentCategoryDisplayOrder: 4,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'PCT_Recordals'
                        },
                        {
                            parentId: 1,
                            patentCategoryName: 'annuities',
                            patentCategoryId: 10,
                            patentCategoryDisplay: 'Annuities',
                            patentCategoryDisplayOrder: 5,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'PCT_Annuities'
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'european_patent',
                    displayText: 'European Grant and Validations',
                    displayOrder: 2,
                    serviceTypeId: 2,
                    patentType: 2,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-write-icon',
                    serviceUniqueName: null,
                    requestCurrencyId: 6,
                    patentCategories: [
                        {
                            parentId: 2,
                            patentCategoryName: '71_3_claims',
                            patentCategoryId: 11,
                            patentCategoryDisplay: '71(3) Claims(EP,UP)',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'EP_713Claims_EP_UP'
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 12,
                            patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: false,
                            serviceUniqueName: 'EP_713Claims_TranslationOnly_EP_UP'
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'translation_&_validation',
                            patentCategoryId: 13,
                            patentCategoryDisplay:
                                '71(3) Claims and Translation & Validation/Filing(EP,UP)',
                            patentCategoryDisplayOrder: 3,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'EP_713Claims_Translation_Validation_Filing_EP_UP'
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'recordal',
                            patentCategoryId: 15,
                            patentCategoryDisplay: 'Recordals (EP)',
                            patentCategoryDisplayOrder: 5,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'EP_Recordals_EP'
                        },
                        {
                            parentId: 2,
                            patentCategoryName: 'Renewals',
                            patentCategoryId: 16,
                            patentCategoryDisplay: 'Renewals (EP,UP)',
                            patentCategoryDisplayOrder: 6,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'EP_Renewals_EP_UP'
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'paris_convention_treaty',
                    displayText: 'Paris Convention Treaty',
                    displayOrder: 3,
                    serviceTypeId: 3,
                    patentType: 3,
                    requestType: 1,
                    isRequestEntity: null,
                    imageIcon: 'i-book-icon',
                    serviceUniqueName: null,
                    requestCurrencyId: 2,
                    patentCategories: [
                        {
                            parentId: 3,
                            patentCategoryName: 'translation_only',
                            patentCategoryId: 17,
                            patentCategoryDisplay: 'Translation',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'PC_TranslationOnly'
                        },
                        {
                            parentId: 3,
                            patentCategoryName: 'translation_&_filing',
                            patentCategoryId: 18,
                            patentCategoryDisplay: 'Translation & Filing ',
                            patentCategoryDisplayOrder: 2,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: 'PC_Translation_FilingOnly'
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                },
                {
                    name: 'other_translations',
                    displayText: 'Other',
                    displayOrder: 5,
                    serviceTypeId: 5,
                    patentType: 4,
                    requestType: 0,
                    isRequestEntity: null,
                    imageIcon: 'i-other-icon',
                    serviceUniqueName: null,
                    requestCurrencyId: 2,
                    patentCategories: [
                        {
                            parentId: 5,
                            patentCategoryName: 'patent_non_filing',
                            patentCategoryId: 24,
                            patentCategoryDisplay: 'Patent Non-Filing',
                            patentCategoryDisplayOrder: 1,
                            patentCategoryIsRequestEntity: true,
                            serviceUniqueName: null
                        }
                    ],
                    id: 0,
                    createdBy: null,
                    createdAt: '0001-01-01T00:00:00',
                    updatedBy: null,
                    updatedAt: null,
                    isActive: false
                }
            ],
            selectedServiceDetails: {
                serviceTypeId: 2,
                patentCategoryDisplay: '71(3) Claims and Translation(EP,UP)'
            }
        },
        companyDetailsPage: {
            companyList: [],
            selectedCompany: {
                id: 4,
                name: 'Test Company 4',
                companyType: 0,
                parentCompanyId: null,
                salesRep: null,
                salesRepName: null,
                requestCurrencyId: 4,
                isPoRequired: false
            },
            selectedContact: {
                id: 71,
                firstName: 'CUSER 2',
                lastName: '',
                middleName: '',
                fullName: 'CUSER 2  ',
                roleId: null,
                email: 'cuser2@gmail.com',
                salesRepName: 'fhkklkllllll  test name',
                salesRepId: 185,
                contactInformation: null
            },
            contactUserList: [
                {
                    id: 71,
                    firstName: 'CUSER 2',
                    lastName: '',
                    middleName: '',
                    fullName: 'CUSER 2  ',
                    roleId: null,
                    email: 'cuser2@gmail.com',
                    salesRepName: 'fhkklkllllll  test name',
                    salesRepId: 185,
                    contactInformation: null
                },
                {
                    id: 609,
                    firstName: 'Nivethitha',
                    lastName: 'Dinakaran',
                    middleName: '',
                    fullName: 'Nivethitha  Dinakaran',
                    roleId: null,
                    email: 'nivebigipbigip@gmail.com',
                    salesRepName: 'contact user profile finial-2 test user test name',
                    salesRepId: 278,
                    contactInformation: null
                },
                {
                    id: 818,
                    firstName: 'mohan',
                    lastName: 'r',
                    middleName: '',
                    fullName: 'mohan  r',
                    roleId: null,
                    email: 'biglcontactuser2024+mohan@gmail.com',
                    salesRepName: 'k, James',
                    salesRepId: 642,
                    contactInformation: null
                }
            ],
            publicationNumber: 'EP3419868 ',
            patentDetails: {
                salesRepId: 185,
                salesRepName: 'fhkklkllllll  test name',
                id: {
                    timestamp: 1614717504,
                    machine: 3070930,
                    pid: -31154,
                    increment: 8042318,
                    creationTime: '2021-03-02T20:38:24Z'
                },
                createdAt: '2021-01-30T02:54:27Z',
                updatedAt: '2021-01-30T02:54:27Z',
                filePath:
                    'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
                sourceLanguageName: 'English',
                sourceLanguage: 'EN',
                patentPublicationNumber: 'EP3419868',
                kind: 'A1',
                patentPublicationDate: '',
                fileName: 'EP16706187NWA1.xml',
                patentApplicationNumber: '16706187.8',
                descriptionWordCount: 3073,
                numberOfClaims: 8,
                claimWordCount: 865,
                claimsWordCount: 865,
                title: 'WINDSCREEN WIPER DEVICE',
                validationDeadline: '',
                communicationOfIntentionDate: '',
                statutoryDeadline: '',
                descriptionPageCount: 7,
                claimsPageCount: 3,
                drawingsPageCount: 10,
                applicantAddress: 'Avenue Champion , 6790 Aubange',
                applicantCountry: 'BE',
                applicantName: 'Federal-Mogul S.A.',
                agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
                agentCountry: 'NL',
                agentName: 'Hooiveld, Arjen Jan Winfried',
                applicantCount: 1,
                titleFR: '',
                titleDE: '',
                validationDeadlineUP: '',
                originalDescriptionWordCount: 3073,
                originalNumberOfClaims: 8,
                originalClaimsWordCount: 865,
                originalDrawingsPageCount: 10,
                originalClaimsPageCount: 3,
                originalApplicantCount: 1
            },
            isFormSubmitting: true,
            formData: {
                companyName: {
                    isReadonly: false,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                contactUser: {
                    isShow: true,
                    isReadonly: false,
                    isAutoPopulate: false,
                    isMandatory: true,
                    isError: false
                },
                publicationNumber: {
                    isReadonly: false,
                    isError: false
                },
                patentDetails: {
                    companyName: {
                        isReadonly: false,
                        isAutoPopulate: false,
                        isMandatory: true,
                        isError: false
                    },
                    contactUser: {
                        isShow: true,
                        isReadonly: false,
                        isAutoPopulate: false,
                        isMandatory: true,
                        isError: false
                    },
                    publicationNumber: {
                        isReadonly: false
                    },
                    patentDetails: {
                        isShow: false,
                        dataNotFoundForPatent: false
                    },
                    isShow: true
                },
                isDuplicate: {
                    isError: false
                }
            }
        },
        additionalInfoPage: {
            id: {
                timestamp: 1614717504,
                machine: 3070930,
                pid: -31154,
                increment: 8042318,
                creationTime: '2021-03-02T20:38:24Z'
            },
            createdAt: '2021-01-30T02:54:27Z',
            updatedAt: '2021-01-30T02:54:27Z',
            filePath:
                'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
            sourceLanguageName: 'English',
            sourceLanguage: 'EN',
            patentPublicationNumber: 'EP3419868',
            kind: 'A1',
            patentPublicationDate: '',
            fileName: 'EP16706187NWA1.xml',
            patentApplicationNumber: '16706187.8',
            descriptionWordCount: 3073,
            numberOfClaims: 8,
            claimWordCount: 865,
            claimsWordCount: 865,
            title: 'WINDSCREEN WIPER DEVICE',
            validationDeadline: '',
            communicationOfIntentionDate: '',
            statutoryDeadline: '',
            descriptionPageCount: 7,
            claimsPageCount: 3,
            drawingsPageCount: 10,
            applicantAddress: 'Avenue Champion , 6790 Aubange',
            applicantCountry: 'BE',
            applicantName: 'Federal-Mogul S.A.',
            agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
            agentCountry: 'NL',
            agentName: 'Hooiveld, Arjen Jan Winfried',
            applicantCount: 1,
            titleFR: '',
            titleDE: '',
            validationDeadlineUP: '',
            originalDescriptionWordCount: 3073,
            originalNumberOfClaims: 8,
            originalClaimsWordCount: 865,
            originalDrawingsPageCount: 10,
            originalClaimsPageCount: 3,
            originalApplicantCount: 1
        },
        patentDetailsPage: {
            referenceNo: '',
            applicationClaimsPriority: 2,
            ifEpGrantedYesNo: false,
            selectedCategoryId: 12,
            mode: 1,
            roleId: 1,
            sourceLanguageFlag: 'EN',
            submit: true,
            requestedBy: 'Gopikrishna Saravana',
            salesRepId: null,
            salesRepName: null,
            applicantName: 'Federal-Mogul S.A.',
            sourceLanguage: 'EN',
            originalAbstractWordCount: '',
            originalDrawingsWordCount: '',
            descriptionWordCount: 3073,
            originalDescriptionWordCount: 3073,
            originalNumberOfDrawings: '',
            claimsWordCount: 865,
            originalClaimsWordCount: 865,
            drawingsPageCount: 10,
            originalDrawingsPageCount: 10,
            originalSpecificationWordCount: '',
            originalNumberOfPriorityClaims: '',
            numberOfClaims: 8,
            originalNumberOfClaims: 8,
            descriptionPageCount: 7,
            originalDescriptionPageCount: '',
            claimsPageCount: 3,
            originalClaimsPageCount: 3,
            originalNumberOfIndependentClaims: '',
            originalEstTotalPages: '',
            statutoryDeadlineDate: '',
            id: {
                timestamp: 1614717504,
                machine: 3070930,
                pid: -31154,
                increment: 8042318,
                creationTime: '2021-03-02T20:38:24Z'
            },
            createdAt: '2021-01-30T02:54:27Z',
            updatedAt: '2021-01-30T02:54:27Z',
            filePath:
                'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
            sourceLanguageName: 'English',
            patentPublicationNumber: 'EP3419868',
            kind: 'A1',
            patentPublicationDate: '',
            fileName: 'EP16706187NWA1.xml',
            patentApplicationNumber: '16706187.8',
            claimWordCount: 865,
            title: 'WINDSCREEN WIPER DEVICE',
            validationDeadline: '',
            communicationOfIntentionDate: '',
            statutoryDeadline: '',
            applicantAddress: 'Avenue Champion , 6790 Aubange',
            applicantCountry: 'BE',
            agentAddress: 'Arnold & Siedsma \nBezuidenhoutseweg 57 , 2594 AC The Hague',
            agentCountry: 'NL',
            agentName: 'Hooiveld, Arjen Jan Winfried',
            applicantCount: 1,
            titleFR: '',
            titleDE: '',
            validationDeadlineUP: '',
            originalApplicantCount: 1,
            requestedDeliveryDateForClaimsTranslation: null,
            selectedCompanyPoRequired: false,
            estimatedSequenceListing: 2
        },
        selectCountryPage: null,
        selectCountryPageEdit: null,
        selectCountryPageForEP: null,
        summaryPage: null,
        orderQuoteDetailsPage: null,
        languageSelectionPage: null,
        standardPageForEdit: null
    }
};

export const expectedMock = {
    formData: {
        additionalInfoPage: {
            agentAddress: 'Arnold & Siedsma· Bezuidenhoutseweg 57 , 2594 AC The Hague',
            agentCountry: 'NL',
            agentName: 'Hooiveld, Arjen Jan Winfried',
            applicantAddress: 'Avenue Champion , 6790 Aubange',
            applicantCount: 1,
            applicantCountry: 'BE',
            applicantName: 'Federal-Mogul S.A.',
            claimWordCount: 865,
            claimsPageCount: 3,
            claimsWordCount: 865,
            communicationOfIntentionDate: '',
            createdAt: '2021-01-30T02:54:27Z',
            descriptionPageCount: 7,
            descriptionWordCount: 3073,
            drawingsPageCount: 10,
            fileName: 'EP16706187NWA1.xml',
            filePath:
                'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
            id: 'someId',
            kind: 'A1',
            numberOfClaims: 8,
            originalApplicantCount: 1,
            originalClaimsPageCount: 3,
            originalClaimsWordCount: 865,
            originalDescriptionWordCount: 3073,
            originalDrawingsPageCount: 10,
            originalNumberOfClaims: 8,
            patentApplicationNumber: '16706187.8',
            patentPublicationDate: '',
            patentPublicationNumber: 'EP3419868',
            sourceLanguage: 'EN',
            sourceLanguageName: 'English',
            statutoryDeadline: '',
            title: 'WINDSCREEN WIPER DEVICE',
            titleDE: '',
            titleFR: '',
            updatedAt: '2021-01-30T02:54:27Z',
            validationDeadline: '',
            validationDeadlineUP: ''
        },
        companyDetailsPage: {
            companyList: [],
            contactUserList: [],
            formData: {},
            isFormSubmitting: true,
            patentDetails: {},
            publicationNumber: 'EP3419868',
            selectedCompany: {},
            selectedContact: {}
        },
        languageSelectionPage: null,
        orderQuoteDetailsPage: null,
        patentDetailsPage: {
            agentAddress: 'Arnold & Siedsma· Bezuidenhoutseweg 57 , 2594 AC The Hague',
            agentCountry: 'NL',
            agentName: 'Hooiveld, Arjen Jan Winfried',
            applicantAddress: 'Avenue Champion , 6790 Aubange',
            applicantCount: 1,
            applicantCountry: 'BE',
            applicantName: 'Federal-Mogul S.A.',
            applicationClaimsPriority: 2,
            claimWordCount: 865,
            claimsPageCount: 3,
            claimsWordCount: 865,
            communicationOfIntentionDate: '',
            createdAt: '2021-01-30T02:54:27Z',
            descriptionPageCount: 7,
            descriptionWordCount: 3073,
            drawingsPageCount: 10,
            estimatedSequenceListing: 2,
            fileName: 'EP16706187NWA1.xml',
            filePath:
                'E:\\EPfulltext_backfile\\2019\\EPRTBJV2019000001001001\\DOC\\EPNWA1\\EP16706187NWA1.zip',
            id: 'someId',
            ifEpGrantedYesNo: false,
            kind: 'A1',
            mode: 1,
            numberOfClaims: 8,
            originalAbstractWordCount: '',
            originalApplicantCount: 1,
            originalClaimsPageCount: 3,
            originalClaimsWordCount: 865,
            originalDescriptionPageCount: '',
            originalDescriptionWordCount: 3073,
            originalDrawingsPageCount: 10,
            originalDrawingsWordCount: '',
            originalEstTotalPages: '',
            originalNumberOfClaims: 8,
            originalNumberOfDrawings: '',
            originalNumberOfIndependentClaims: '',
            originalNumberOfPriorityClaims: '',
            originalSpecificationWordCount: '',
            patentApplicationNumber: '16706187.8',
            patentPublicationDate: '',
            patentPublicationNumber: 'EP3419868',
            referenceNo: '',
            requestedBy: 'Gopikrishna Saravana',
            requestedDeliveryDateForClaimsTranslation: null,
            roleId: 1,
            salesRepId: null,
            salesRepName: null,
            selectedCategoryId: 12,
            selectedCompanyPoRequired: false,
            sourceLanguage: 'EN',
            sourceLanguageFlag: 'EN',
            sourceLanguageName: 'English',
            statutoryDeadline: '',
            statutoryDeadlineDate: '',
            submit: true,
            title: 'WINDSCREEN WIPER DEVICE',
            titleDE: '',
            titleFR: '',
            updatedAt: '2021-01-30T02:54:27Z',
            validationDeadline: '',
            validationDeadlineUP: ''
        },
        selectCountryPage: null,
        selectCountryPageEdit: null,
        selectCountryPageForEP: {
            countryList: [],
            selectAllChecked: null,
            selectUpCountryChecked: null
        },
        serviceTypePage: {
            selectedServiceDetails: {},
            serviceType: []
        },
        standardPageForEdit: null,
        summaryPage: null
    }
};
