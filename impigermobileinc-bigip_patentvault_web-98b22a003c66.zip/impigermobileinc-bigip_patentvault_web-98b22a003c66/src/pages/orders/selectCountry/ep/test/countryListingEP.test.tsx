import { render, screen, waitFor } from '@testing-library/react';
import CountryListingEP from '../countryListingEP';
import { SelectCountryData } from '../../types/country.type';
import selectCountryService from '../../services/selectCountry.service';
// import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
// import { initialStoreData } from './countryListingEP.test.mock';
// import { PATHS } from 'constants/routes.constant';

// import { useNavigate } from 'react-router-dom';

// Mock dependencies
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useLocation: jest.fn(),
    useNavigate: jest.fn().mockReturnValue(jest.fn())
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

// mocking the service api
jest.mock('../../services/selectCountry.service', () => ({
    getCountriesData: jest.fn()
}));

// mocking store
// jest.mock('core/store/orderQuoteStore/orderQuote.store', () => ({
//     updatePage: jest.fn(),
//     getData: jest.fn()
// }));

const mockCountryList: SelectCountryData[] = [
    {
        id: 86,
        name: 'Montenegro',
        code: 'ME',
        iconName: '230-montenegro.svg',
        wipoIq: 0,
        up: false,
        pcIq: 0,
        languageId: 151,
        wipoEntitySize: [],
        pcEntitySize: [],
        epoState: 2,
        concatCode: 'Montenegro (ME)'
    },
    {
        id: 125,
        name: 'Tunisia',
        code: 'TN',
        iconName: '013-tunisia.svg',
        up: false,
        pcIq: 0,
        wipoIq: 0,
        languageId: null,
        wipoEntitySize: [],
        pcEntitySize: [],
        epoState: 3,
        concatCode: 'Tunisia (TN)'
    },
    {
        id: 131,
        name: 'France',
        code: 'FR',
        iconName: '077-france.svg',
        wipoIq: 0,
        up: true,
        pcIq: 0,
        languageId: null,
        wipoEntitySize: [],
        pcEntitySize: [],
        epoState: 1,
        concatCode: 'France (FR)'
    },
    {
        id: 184,
        name: 'San Marino',
        code: 'SM',
        iconName: '214-san-marino.svg',
        wipoIq: 0,
        up: false,
        pcIq: 0,
        languageId: 71,
        wipoEntitySize: [],
        pcEntitySize: [],
        epoState: 1,
        concatCode: 'San Marino (SM)'
    }
];

describe('CountryListingEP', () => {
    // beforeEach(() => {
    //     // Reset mock implementations before each test
    //     quoteOrderModuleStore.updatePage = jest.fn();
    //     quoteOrderModuleStore.getData = jest.fn(() => ({
    //         info: {
    //             mode: null,
    //             selectedService: null,
    //             selectedCategory: null,
    //             primaryId: null,
    //             requestCurrencyId: null,
    //             requestNumber: null,
    //             documentId: null,
    //             isEditFlow: null,
    //             isUP: null,
    //             approveStatus: 0,
    //             statusId: null
    //         },
    //         flags: {
    //             storeUpdateWithSummaryData: null,
    //             isCountriesSyncedCompletedInEditMode: false,
    //             isSummaryPageTablesInlineEditInProgress: false,
    //             pagesMatchStatusWithBackupData: {
    //                 /** this flags will ensure the current pages data matches with backup data(backupDataToCompare) or not.  */
    //                 isCompanyModified: false,
    //                 isLanguagesModified: false,
    //                 isCountsModified: false,
    //                 isCountriesModified: false
    //             }
    //         },
    //         isFormValid: {
    //             [PATHS.SERVICE_TYPE]: null,
    //             [PATHS.COMPANY_DETAILS]: null,
    //             [PATHS.ADDITIONAL_INFO]: null,
    //             [PATHS.PATENT_DETAILS]: null,
    //             [PATHS.SELECT_COUNTRY]: null,
    //             [PATHS.FILE_UPLOAD]: true,
    //             [PATHS.SUMMARY]: true,
    //             [PATHS.ORDER_QUOTE_DETAILS]: null,
    //             [PATHS.QO_FILE_UPLOAD]: true,
    //             [PATHS.LANGUAGE_SELECTION]: true
    //         },
    //         formData: {
    //             // keep all page as 'null' to validate while page navigation
    //             serviceTypePage: null,
    //             companyDetailsPage: null,
    //             additionalInfoPage: null,
    //             patentDetailsPage: null,
    //             selectCountryPage: null,
    //             selectCountryPageEdit: null,
    //             selectCountryPageForEP: null,
    //             summaryPage: null,
    //             orderQuoteDetailsPage: null,
    //             languageSelectionPage: null,
    //             standardPageForEdit: null
    //         }
    //     }));
    // });
    test('renders the component', () => {
        (selectCountryService.getCountriesData as jest.Mock).mockResolvedValue(mockCountryList);
        render(<CountryListingEP />);

        // Assert that the component renders without throwing an error
        expect(screen.getByTestId('CountryListingEP')).toBeInTheDocument();
    });

    test('renders the country list', async () => {
        (selectCountryService.getCountriesData as jest.Mock).mockResolvedValue(mockCountryList);
        // (quoteOrderModuleStore.getData as jest.Mock).mockReturnValue(initialStoreData);
        render(<CountryListingEP />);
        // await waitFor(() => {
        //     expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith(
        //         'formData',
        //         initialStoreData
        //     );
        //     expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith('isFormValid', []);
        //     expect(quoteOrderModuleStore.updatePage).toHaveBeenCalledWith('flags', []);
        // });

        // Remove the line of code that tries to access the 'updateFormData' property
        await waitFor(() => {
            const designatedCountries = screen.getByText(
                'SELECT_EP_COUNTRY.DESIGNATED_CONTRACTING_STATES'
            );
            const validationCountries = screen.getByText('Montenegro');
            const extensionCountries = screen.getByText('SELECT_EP_COUNTRY.EXTENSION_STATES');
            expect(designatedCountries).toBeInTheDocument();
            expect(validationCountries).toBeInTheDocument();
            expect(extensionCountries).toBeInTheDocument();
        });
    });
});
