import { Checkbox, CheckboxChangeEvent } from 'primereact/checkbox';
import { Column } from 'primereact/column';
import { DataTable, DataTableStateEvent } from 'primereact/datatable';
import { useEffect, useMemo, useState } from 'react';
import { CountryConfig, SelectCountryData, SelectCountryDataForEdit } from '../types/country.type';
import selectCountryService from '../services/selectCountry.service';
import { COUNTRY_ID, EPO_STATE } from '../constants/country.constant';
import { useTranslation } from 'react-i18next';
import { TriStateCheckbox } from 'primereact/tristatecheckbox';
import { PATHS } from 'constants/routes.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { QuoteOrderModuleStore } from 'core/store/orderQuoteStore/orderQuote.type.store';
import { useNavigate } from 'react-router-dom';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import { checkBoxStyle, tooltipStyle } from 'constants/styles.constant';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import {
    CATEGORY_TYPE_ID,
    SERVICE_TYPE_ID,
    STEPPER_TYPE_ID
} from 'constants/progressStepper.constant';
import { PATENT_SOURCE_LANGUAGE } from 'constants/app.constant';
import { Tooltip } from 'primereact/tooltip';
import stepperStore from 'core/store/stepperStore/progressStepper.store';

// For the new EP country Enhance, this file is currently not used.
// It is kept for future reference and to avoid confusion.

const CountryListingEP = () => {
    const quoteOrderData = useMemo(() => quoteOrderModuleStore.getData(), []);
    const [countryList, setCountryList] = useState<CountryConfig[]>();
    const { t } = useTranslation();
    const [selectAllChecked, setSelectAllChecked] = useState<boolean | null>(null);
    const [selectUpCountryChecked, setSelectUpCountryChecked] = useState<boolean | null>(null);
    const [isFormSubmitting, setIsFormSubmitting] = useState<boolean>(false);
    const navigate = useNavigate();
    const [isMinOneCountrySelected, setIsMinOneCountrySelected] = useState<boolean | null>(null);
    const [sortTableOrder, setSortTableOrder] = useState<1 | 0 | -1 | undefined | null>(null);
    const isEPRecordalIOrRenewals =
        quoteOrderData?.info.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].recordal ||
        quoteOrderData?.info.selectedCategory?.patentCategoryId ===
            CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent].Renewals;
    const isEnglishSourceLanguage =
        quoteOrderModuleStore.getData()?.formData?.companyDetailsPage?.patentDetails
            ?.sourceLanguage === PATENT_SOURCE_LANGUAGE.ENGLISH;
    const isEpTranslationOnly =
        quoteOrderModuleStore.getData().info.selectedCategory?.patentCategoryId ===
        CATEGORY_TYPE_ID[SERVICE_TYPE_ID.european_patent]['translation_only'];
    // api
    const getCountriesList = async (): Promise<void> => {
        try {
            const patentType: number = quoteOrderData?.info.selectedService?.patentType ?? 0;
            const countryListResponse: SelectCountryData[] =
                await selectCountryService?.getCountriesData(
                    // append 'servicePatentTypeId' in API to get country list
                    patentType
                );

            if (countryListResponse) {
                countryListResponse.forEach((country) => {
                    if (country.epoState === 3) {
                        country.epoState = 5;
                    }
                    if (country.epoState === 2) {
                        country.epoState = 3;
                    }
                    if (country.epoState === 5) {
                        country.epoState = 2;
                    }
                    return country;
                });

                countryListResponse.sort((a, b) => a.name.localeCompare(b.name));
                constructCountryData(countryListResponse);
            }
        } catch (error) {
            console.error('Error in getCountriesList:', error);
        }
    };

    // effects
    useEffect(() => {
        try {
            const fetchFormData = quoteOrderData?.formData?.selectCountryPageForEP;
            if (fetchFormData) {
                setCountryList((fetchFormData.countryList as CountryConfig[]) ?? []);
                setSelectAllChecked(fetchFormData?.selectAllChecked as boolean);
                setSelectUpCountryChecked(fetchFormData?.selectUpCountryChecked as boolean);
            } else {
                getCountriesList();
            }
        } catch (error) {
            console.error('Error handling initial data on useEffect():', error);
        }
    }, [quoteOrderData]);

    const updateAllCountrySelection = () => {
        if (countryList) {
            const countryIsSelected: CountryConfig[] = countryList.filter((country) => {
                if (country.isSelected) {
                    return country;
                }
            });
            if (countryIsSelected.length === 0) {
                setSelectAllChecked(null);
                setSelectUpCountryChecked(null);
            } else if (!(countryIsSelected.length === countryList.length)) {
                setSelectAllChecked(false);
            } else {
                setSelectAllChecked(true);
            }
        }
    };

    const updateAllUpCountrySelection = () => {
        if (countryList) {
            const totalUpCountry: CountryConfig[] = countryList.filter((country) => {
                if (country.data.up) {
                    return country;
                }
            });
            const upCountryIsSelected: CountryConfig[] = countryList.filter((country) => {
                if (country.isUpSelected && country.data.up) {
                    return country;
                }
            });

            if (isEPRecordalIOrRenewals || upCountryIsSelected.length === 0) {
                setSelectUpCountryChecked(null);
            } else if (!(upCountryIsSelected.length === totalUpCountry.length)) {
                setSelectUpCountryChecked(false);
            } else {
                setSelectUpCountryChecked(true);
            }
        }
    };

    const updateSelectedCountries = async () => {
        try {
            if (!countryList) throw new Error('Country list is empty.');

            await new Promise((r) => setTimeout(r, 500));

            const selectedEPCountries: SelectCountryDataForEdit[] | null =
                quoteOrderData?.formData?.selectCountryPageEdit?.epCountries ?? null;
            countryList.forEach((epCountry) => {
                if (selectedEPCountries) {
                    const selectedCountryInCreateFlow = selectedEPCountries.find(
                        (selectedEPCountry) => selectedEPCountry.countryId === epCountry.data.id
                    );
                    if (selectedCountryInCreateFlow?.ep) {
                        epCountry.isSelected = true;
                        epCountry.isUpSelected = !isEPRecordalIOrRenewals;
                    } else if (selectedCountryInCreateFlow?.up) {
                        epCountry.isSelected = selectedCountryInCreateFlow.ep ?? false;
                        epCountry.isUpSelected = isEPRecordalIOrRenewals
                            ? false
                            : (selectedCountryInCreateFlow.up ?? false);
                    }
                }
            });

            setCountryList([...countryList]);

            const updatedQUoteOrderDataFlags = {
                ...quoteOrderData.flags,
                isCountriesSyncedCompletedInEditMode: true
            };
            quoteOrderModuleStore.updatePage('flags', updatedQUoteOrderDataFlags);
        } catch (error) {
            console.error('Error in updateSelectedCountries(): ', error);
        }
    };

    // update store in onChange
    useEffect(() => {
        updateAllCountrySelection();
        updateAllUpCountrySelection();
        const updatedQuoteOrderData = quoteOrderModuleStore.getData();

        if (
            !updatedQuoteOrderData?.flags.isCountriesSyncedCompletedInEditMode &&
            updatedQuoteOrderData?.info.isEditFlow === true &&
            countryList &&
            countryList.length > 0
        ) {
            updateSelectedCountries();
        }

        updateFormData(updatedQuoteOrderData);
        updateIsFormValid(updatedQuoteOrderData);

        if (isFormSubmitting) updatePageValidStatus();
    }, [countryList]);

    // constructions
    const constructCountryData = (countriesList: SelectCountryData[]) => {
        const countriesData: CountryConfig[] = [];

        try {
            for (const country of countriesList) {
                if (country) {
                    countriesData.push({
                        isSelected: false,
                        isUpSelected: false,
                        data: { ...country }
                    });
                } else {
                    throw new Error('wipoIq is null or undefined for countries.');
                }
            }

            setCountryList(countriesData);
        } catch (error: any) {
            console.error('Error:', error.message);
        }
    };

    const updateIsFormValid = (updatedQuoteOrderData: QuoteOrderModuleStore) => {
        // form valid status to update store
        if (countryList?.length === 0) return;

        const updatedQuoteOrderIsFormValid = {
            ...updatedQuoteOrderData.isFormValid,
            [PATHS.SELECT_COUNTRY]: countryList?.some((country) => country.isSelected)
        };

        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);
    };

    const updateFormData = (updatedQuoteOrderData: QuoteOrderModuleStore) => {
        const updatedQuoteOrderFormData = {
            ...updatedQuoteOrderData?.formData, // keep other forms data
            selectCountryPageForEP: {
                countryList,
                selectAllChecked,
                selectUpCountryChecked
            }
        };

        quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
    };

    const countryOptionTemplate = (rowData: CountryConfig) => {
        return (
            <div className="flex items-center justify-between px-5">
                <div className="flex items-center">
                    <div className="avatar">
                        <div className="h-6 rounded-full border">
                            <div
                                className={`h-full w-full bg-no-repeat bg-center`}
                                style={{
                                    backgroundImage:
                                        'url(/images/country-flags/' +
                                        rowData?.data?.iconName +
                                        ')',
                                    backgroundSize: '150%'
                                }}></div>
                        </div>
                    </div>
                    &nbsp;&nbsp;
                    <div className={`country-name-${rowData?.data?.name} flex items-center`}>
                        {rowData.data.name}
                        {rowData?.data?.id === COUNTRY_ID.SPAIN &&
                            isEnglishSourceLanguage &&
                            isEpTranslationOnly && (
                                <span>
                                    <Tooltip
                                        target={`.country-name-Spain`}
                                        content={t('SELECT_COUNTRY.SPAIN_INFO_TOOLTIP')}
                                        pt={tooltipStyle}
                                    />
                                    <i className={`pi pi-info-circle ml-2 pt-px text-primary`} />
                                </span>
                            )}
                    </div>
                </div>
                {rowData?.data.up ? (
                    <div className="text-primary bg-primary-100/50 rounded-md px-[5px] py-[2px] text-sm font-normal">
                        {t('SELECT_EP_COUNTRY.UP')}
                    </div>
                ) : (
                    <></>
                )}
            </div>
        );
    };

    const checkBoxTemplate = (rowData: CountryConfig) => {
        return (
            <div className="flex justify-center align-middle">
                <Checkbox
                    key={rowData?.data.id}
                    onChange={() => handleCheckBoxChange(rowData.data.id)}
                    checked={rowData.isSelected}
                    pt={checkBoxStyle}></Checkbox>
            </div>
        );
    };

    const checkBoxDisableTemplate = (rowData: CountryConfig) => {
        return (
            <div className="flex justify-center align-middle">
                <Checkbox
                    key={rowData?.data.id + 'up'}
                    checked={rowData.isUpSelected}
                    pt={checkBoxStyle}
                    disabled></Checkbox>
            </div>
        );
    };

    const headerTemplate = (rowData: CountryConfig) => {
        return (
            <div className="flex align-items-center gap-2 bg-primary-light">
                <div className="text-primary px-5 py-[8px] text-base font-normal">
                    {rowData.data.epoState &&
                    rowData.data.epoState === EPO_STATE.DESIGNATED_CONTRACTING_STATES
                        ? t('SELECT_EP_COUNTRY.DESIGNATED_CONTRACTING_STATES')
                        : rowData?.data.epoState === EPO_STATE.VALIDATION_STATES
                          ? t('SELECT_EP_COUNTRY.VALIDATION_STATES')
                          : t('SELECT_EP_COUNTRY.EXTENSION_STATES')}
                </div>
            </div>
        );
    };

    const columnSchema: any[] = [
        {
            field: 'name',
            header: 'Country',
            body: countryOptionTemplate,
            columnNumber: 0,
            visibility: true,
            sortable: true
        },
        {
            field: 'national_validations_only',
            header: 'National Validations Only',
            body: checkBoxTemplate,
            columnNumber: 1,
            visibility: true,
            sortable: false
        },
        {
            field: 'up_national_validation',
            header: 'UP + National Validations',
            body: checkBoxDisableTemplate,
            columnNumber: 2,
            visibility: true,
            sortable: false
        }
    ];

    const handleCheckBoxChange = (value: number) => {
        const updatedInstantCountries: CountryConfig[] | undefined = countryList?.map(
            (country: CountryConfig) => {
                if (country?.data?.id === value) {
                    /** there are two different country in InstantCountry
                         One is normal selection, another one is Entity type (Radio options - Large , Small)
                         differentiate those with 'WipoEntityId' */
                    const updatedCountryData = {
                        ...country,
                        isSelected: !country?.isSelected,
                        isUpSelected: isEPRecordalIOrRenewals ? false : !country?.isUpSelected
                    };

                    return updatedCountryData;
                }
                return country;
            }
        );

        setCountryList(updatedInstantCountries);
        const selectedUPCountry =
            updatedInstantCountries?.filter(
                (c: CountryConfig) =>
                    c.data.up === true && c.isSelected === true && c.isUpSelected === true
            ) ?? [];
        if (selectedUPCountry?.length > 0) {
            handleSelectUpCountry(updatedInstantCountries, true, true);
        } else {
            handleSelectUpCountry(updatedInstantCountries, false, true);
        }
    };

    const handleSelectAll = (e: CheckboxChangeEvent) => {
        const isChecked = e.value;
        if (!isChecked) {
            setSelectAllChecked(null);
            setSelectUpCountryChecked(null);
        } else {
            setSelectAllChecked(isChecked as boolean);
            if (!isEPRecordalIOrRenewals) {
                setSelectUpCountryChecked(true);
            }
        }

        const updatedInstantCountries: CountryConfig[] | undefined = countryList?.map(
            (country: CountryConfig) => {
                return {
                    ...country,
                    isSelected: isChecked,
                    isUpSelected: isEPRecordalIOrRenewals ? false : isChecked
                };
            }
        );
        setCountryList(updatedInstantCountries);

        handleSelectUpCountry(updatedInstantCountries, isChecked as boolean);
    };

    const handleSelectUpCountry = (
        updatedList = countryList,
        e: boolean,
        updateEPCountry = false
    ) => {
        const isChecked = e;
        const updatedInstantCountries: CountryConfig[] | undefined = updatedList?.map(
            (country: CountryConfig) => {
                if (country?.data?.up) {
                    const updatedCountryData = {
                        ...country,
                        isUpSelected: isEPRecordalIOrRenewals ? false : isChecked,
                        isSelected: updateEPCountry ? country.isSelected : isChecked
                    };
                    return updatedCountryData;
                }
                return country;
            }
        );
        setCountryList(updatedInstantCountries);
    };

    const updatePageValidStatus = (): boolean => {
        // form valid status update for local
        if (countryList) {
            const updatedIsMinOneCountrySelected: boolean = countryList.some(
                (country) => country.isSelected
            );
            setIsMinOneCountrySelected(updatedIsMinOneCountrySelected);

            return updatedIsMinOneCountrySelected;
        } else {
            return false;
        }
    };

    const onSubmit = () => {
        setIsFormSubmitting(true);
        const isPageValid = updatePageValidStatus();

        /** trigger temporary 'OrderSave' API only page is valid.
             note: page navigation and this API call will happen parallelly. */
        isPageValid &&
            !stepperStore.getIsLastStepper(STEPPER_TYPE_ID.SELECT_COUNTRY) &&
            orderSaveApi();
    };

    // save api
    const orderSaveApi = async () => {
        const redirectTo: string | null = await orderQuoteModuleService.saveDraft(true);
        if (redirectTo) navigate(redirectTo);
    };

    const getSelectedUPCountriesCount = () => {
        return countryList?.filter((country) => country.isUpSelected && country.data.up).length;
    };

    const getSelectedCountriesCount = () => {
        return countryList?.filter((country) => country.isSelected).length;
    };

    const header = (
        <div className="flex bg-white">
            <div className="hidden md:flex w-[35%]">
                <span className="text-xl text-900 font-semibold pt-2">
                    {t('SELECT_COUNTRY.TITLE')}
                </span>
                <div className="pl-3 flex sm:justify-start">
                    {isMinOneCountrySelected === false && (
                        <ErrorLabel message={`${t('SELECT_COUNTRY.ERROR')}`} warningIcon={true} />
                    )}
                </div>
            </div>

            <div className="flex w-full lg:w-[33.3%]">
                <div className="flex items-center justify-between p-3 w-full bg-neutral-800 rounded-t-md rounded-b-none border border-neutral-900">
                    <div className="flex w-1/2 items-center justify-center">
                        <TriStateCheckbox
                            id="selectAll"
                            pt={checkBoxStyle}
                            onChange={handleSelectAll}
                            value={selectAllChecked}
                            uncheckIcon={
                                <img src="/images/svgs/checkbox.svg" className="h-[20px] w-5" />
                            }
                        />
                        <label
                            htmlFor="selectAll"
                            className="text-primary px-3 py-px text-base font-medium md:whitespace-nowrap">
                            {t('SELECT_EP_COUNTRY.SELECT_ALL_COUNTRIES')} (
                            {getSelectedCountriesCount()})
                        </label>
                    </div>
                    <div className="border border-neutral-100 h-6"></div>
                    <div className="flex w-1/2 items-center justify-center">
                        <TriStateCheckbox
                            id="selectUpCountry"
                            pt={checkBoxStyle}
                            value={selectUpCountryChecked}
                            onChange={(e: CheckboxChangeEvent) =>
                                handleSelectUpCountry(countryList, e.value as boolean)
                            }
                            disabled={isEPRecordalIOrRenewals}
                            uncheckIcon={
                                <img
                                    alt="Image"
                                    src="/images/svgs/checkbox.svg"
                                    className="h-[20px] w-4"
                                />
                            }
                        />
                        <label
                            htmlFor="selectUpCountry"
                            className="text-primary px-3 py-px text-base font-medium">
                            {t('SELECT_EP_COUNTRY.SELECT_UP_ONLY')} ({getSelectedUPCountriesCount()}
                            )
                        </label>
                    </div>
                </div>
            </div>
        </div>
    );

    const handleSort = (e: DataTableStateEvent) => {
        const { sortField } = e;
        setSortTableOrder(sortTableOrder === 1 ? -1 : 1);

        // Ensure countryList is defined and use an empty array if it's not
        const sortedData = [...(countryList ?? [])];

        const newData = sortedData.sort((a, b) => {
            // Use type assertion to ensure TypeScript knows the type of sortField
            const valueA = a.data[sortField as keyof SelectCountryData] as
                | string
                | number
                | null
                | undefined;
            const valueB = b.data[sortField as keyof SelectCountryData] as
                | string
                | number
                | null
                | undefined;

            if (sortTableOrder && sortTableOrder != null) {
                // Handle null values
                if (valueA == null && valueB == null) return 0;
                if (valueA == null) return sortTableOrder;
                if (valueB == null) return -sortTableOrder;

                // If both values are strings, use localeCompare for string comparison
                if (typeof valueA === 'string' && typeof valueB === 'string') {
                    return sortTableOrder * valueA.localeCompare(valueB);
                }

                // If both values are numbers, perform numeric comparison
                if (typeof valueA === 'number' && typeof valueB === 'number') {
                    return sortTableOrder * (valueA - valueB);
                }
            }

            // If values are of different types or not comparable, return a default value (0)
            return 0;
        });
        setCountryList(newData);
    };

    return (
        <div className="tableComponent customTable select-country-table-style p-4 px-6 bg-white rounded-lg">
            <DataTable
                value={countryList}
                data-testid="CountryListingEP"
                tableStyle={{ minWidth: '50rem' }}
                header={header}
                rowGroupMode="subheader"
                groupRowsBy="data.epoState"
                rowGroupHeaderTemplate={headerTemplate}
                sortField="data.epoState"
                sortMode="single"
                sortOrder={sortTableOrder}
                onSort={(e) => handleSort(e)}
                scrollable
                scrollHeight="70px"
                className="p-0"
                pt={{
                    rowGroupHeader: {
                        bodyCell: {
                            className: 'p-0'
                        }
                    },
                    header: {
                        className: 'p-0 text-title-header border-none '
                    },
                    column: {
                        bodyCell: {
                            className: 'text-center p-0'
                        }
                    },
                    thead: {
                        className: 'bg-white'
                    },
                    headerRow: {
                        className: 'bg-inherit p-0'
                    },
                    table: {
                        className: 'whitespace-nowrap mb-1'
                    },
                    bodyRow: {
                        className: 'even:bg-neutral hover:bg-neutral-50 p-0'
                    },
                    wrapper: {
                        className:
                            'border-[3px] border-x-0 border-t-primary border-solid tableCustomHeight'
                    }
                }}>
                {columnSchema.map((col, index) => (
                    <Column
                        key={index + 1}
                        field={col.field}
                        header={col.header}
                        sortable={col.sortable}
                        body={col.body}
                        pt={{
                            bodyCell: {
                                className: 'text-center p-2'
                            },
                            headerContent: {
                                className: 'justify-center p-0'
                            },
                            headerTitle: {
                                className: 'font-medium text-lg'
                            }
                        }}></Column>
                ))}
            </DataTable>

            {/* submit */}
            <button
                type="button"
                id={`submit-${PATHS.SELECT_COUNTRY}`}
                onClick={onSubmit}
                data-testid={`submit-${PATHS.SELECT_COUNTRY}`}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
            />
        </div>
    );
};

export default CountryListingEP;
