import { t } from 'i18next';
import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import EpCountryDataTable from './epCountryDataTable';
import selectCountryService from '../services/selectCountry.service';
import {
    EpCountriesData,
    EpCountryResponseList,
    LanguageBasedFeeList
} from '../types/country.type';
import { Checkbox } from 'primereact/checkbox';
import { Dropdown } from 'primereact/dropdown';
import {
    dropDownStyle,
    hoverDropdownStyle,
    tooltipStyle,
    translationFeeInputSwitchPT
} from 'constants/styles.constant';
import { showToastMessage, toggleLoadingIndicator } from 'core/utils/utils';
import summaryService from 'pages/createOrderAndQuote/components/summary/services/summary.service';
import { CurrencyResponse } from 'pages/createOrderAndQuote/components/summary/types/summary.type';
import {
    COUNTRY_ID,
    selectedCurrency,
    serviceIncludedOptions
} from '../constants/country.constant';
import { PATHS } from 'constants/routes.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import orderQuoteModuleService from 'pages/createOrderAndQuote/services/orderQuoteModule.service';
import { useNavigate } from 'react-router-dom';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { Tooltip } from 'primereact/tooltip';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { LANGUAGE_ID, SOURCE_LANGUAGES } from 'constants/app.constant';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import { STEPPER_TYPE_ID } from 'constants/progressStepper.constant';
import { InputSwitch } from 'primereact/inputswitch';

interface Props {
    orderEditMode?: {
        isOrderEdit: boolean;
        orderId: number;
        draftId: number;
        isUpOrder: boolean;
        isNoEnglishTranslation: boolean;
        isEPOrder: boolean;
        sourceLanguage: string | null;
        hasOrderCostUpdated: boolean | null;
    };
}

const EpCountryListing = forwardRef((props: Props, ref) => {
    const navigate = useNavigate();
    const [confirmationPopup, setConfirmationPopup] = useState({
        visible: false,
        header: t('SELECT_EP_COUNTRY.TASK_ALREADY_ASSIGNED'),
        description: t('SELECT_EP_COUNTRY.TASK_ALREADY_ASSIGNED_MSG'),
        taskIDs: '' as string
    });
    const [quoteOrderData, setQuoteOrderData] = useState(quoteOrderModuleStore.getData());
    quoteOrderModuleStore.subscribe(setQuoteOrderData);
    const storeData =
        quoteOrderData?.formData?.selectCountryPageForEP?.epTranslationAndValidationData;
    const isEditMode =
        props.orderEditMode?.isOrderEdit || quoteOrderData?.info?.isEditFlow || false;
    const [epCountriesData, setEpCountriesData] = useState<EpCountriesData | null>(null);
    const [epCountriesList, setEpCountriesList] = useState<EpCountryResponseList[]>([]);
    const [languageBasedFeeList, setLanguageBasedFeeList] = useState<LanguageBasedFeeList[]>([]);
    const [upAndNationalValidationsFees, setUpAndNationalValidationsFees] = useState<number>(
        storeData?.upAndNationalValidationsFeesID?.serviceIncludedId ||
            serviceIncludedOptions.allFees.id
    );
    const [selectedTargetLanguageId, setSelectedTargetLanguageId] = useState<number | null>(
        storeData?.upTargetLanguage?.targetLanguageId || null
    );
    const [currencyList, setCurrencyList] = useState<CurrencyResponse[]>([]);
    const [selectedCurrencyId, setSelectedCurrencyId] = useState<number>(
        Number(
            isEditMode
                ? quoteOrderData?.editFlowResponseData?.info?.requestCurrencyId
                : quoteOrderData?.info?.requestCurrencyId
        )
    );
    const currencySymbol = epCountriesData?.currencySymbol || '';
    const isSelectedAnyCountry = epCountriesList.some((country) => country.isSelected);
    const isSelectedAnyUPCountry =
        props?.orderEditMode?.isOrderEdit && props?.orderEditMode?.isEPOrder
            ? false
            : epCountriesList.some((country) => country.isUp && country.isSelected);
    const [noEnglishTranslationRequired, setNoEnglishTranslationRequired] =
        useState<boolean>(false);
    const [upAgencyAndTranslationFees, setUpAgencyAndTranslationFees] = useState<{
        agencyFee: number;
        translationFee: number;
        agencyOrOfficialFeeUpdated?: boolean;
        translationFeeUpdated?: boolean;
    }>({
        agencyFee: storeData?.upAndNationalValidationsFeesID?.agencyFee || 0,
        translationFee: storeData?.upAndNationalValidationsFeesID?.translationFee || 0,
        agencyOrOfficialFeeUpdated:
            storeData?.upAndNationalValidationsFeesID?.agencyOrOfficialFeeUpdated ?? false,
        translationFeeUpdated:
            storeData?.upAndNationalValidationsFeesID?.translationFeeUpdated ?? false
    });
    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });

    const hasSelectedEpUp = epCountriesList?.some(
        (country) => country.isEp && country.isUp && country.isSelected
    );
    const hasSelectedEpNonUp = epCountriesList?.some(
        (country) => country.isEp && !country.isUp && country.isSelected
    );
    const isEnglishSourceLanguage = props.orderEditMode?.isOrderEdit
        ? props.orderEditMode?.sourceLanguage?.toUpperCase() === SOURCE_LANGUAGES.ENGLISH
        : quoteOrderModuleStore
              .getData()
              ?.formData?.companyDetailsPage?.patentDetails?.sourceLanguageName?.toUpperCase() ===
          SOURCE_LANGUAGES.ENGLISH;
    const selectedCountryIdTranslationFee = epCountriesList?.some(
        (item) =>
            item.isSelected &&
            languageBasedFeeList.find((fee) => fee.targetLanguageId === selectedTargetLanguageId)
                ?.countryId === item.countryId &&
            (item.serviceIncluded.translationFee.isSelected ||
                item.serviceIncluded.allFees.isSelected)
    );
    const isNonUpCountryRecordsModified = epCountriesList?.some(
        (item) =>
            item.isSelected &&
            (item.isNewRecord || item.agencyOrOfficialFeeUpdated || item.translationFeeUpdated)
    );

    const isUpLanguageAndFeesModified =
        upAgencyAndTranslationFees.agencyOrOfficialFeeUpdated ||
        upAgencyAndTranslationFees.translationFeeUpdated;

    const isPrimaryCountrySelected = (countryList: EpCountryResponseList[], groupId: number) => {
        if (!groupId && countryList) return false;
        return countryList.some(
            (item) => item.groupId === groupId && item.isPrimaryDisplay && item.isSelected
        );
    };

    const isPrimaryCountryIsTranslationSelected = (
        countryList: EpCountryResponseList[],
        groupId: number
    ) => {
        if (!groupId && countryList) return false;
        return countryList.some(
            (item) =>
                item.groupId === groupId &&
                item.isPrimaryDisplay &&
                (item.serviceIncluded.translationFee.isSelected ||
                    item.serviceIncluded.allFees.isSelected)
        );
    };

    const totalOfSelectedCountries = () => {
        if (props?.orderEditMode?.isOrderEdit && props?.orderEditMode?.isUpOrder) return 0;
        return epCountriesList
            .filter((country) => country.isSelected)
            .reduce((sum, country) => {
                const selectedFee = Object.values(country.serviceIncluded).find(
                    (item) => item.isSelected
                );
                return sum + (selectedFee?.value ?? 0);
            }, 0);
    };

    // Check Spain-related condition only once
    const shouldSubtractSpanishFee =
        epCountriesList?.some(
            (item) =>
                item.countryId === COUNTRY_ID.SPAIN &&
                item.isEp &&
                item.isSelected &&
                (item.serviceIncluded.translationFee.isSelected ||
                    item.serviceIncluded.allFees.isSelected) &&
                item.translationFee >
                    Number(
                        languageBasedFeeList?.find(
                            (lang) => lang.targetLanguageId === selectedTargetLanguageId
                        )?.translationFee
                    )
        ) &&
        isEnglishSourceLanguage &&
        selectedTargetLanguageId === LANGUAGE_ID.SPANISH &&
        (upAndNationalValidationsFees === serviceIncludedOptions.translationFee.id ||
            upAndNationalValidationsFees === serviceIncludedOptions.allFees.id);

    // Calculate total of Non-UP countries
    const totalOfNonUP =
        epCountriesList
            .filter((country) => !country.isUp && country.isSelected)
            .reduce((sum, country) => {
                const selectedFee = Object.values(country.serviceIncluded).find(
                    (item) => item.isSelected
                );
                return sum + (selectedFee?.value ?? 0);
            }, 0) -
        (shouldSubtractSpanishFee
            ? Number(
                  languageBasedFeeList?.find(
                      (item) => item.targetLanguageId === selectedTargetLanguageId
                  )?.translationFee
              )
            : 0);

    const translationFee = selectedCountryIdTranslationFee
        ? 0
        : Number(
              languageBasedFeeList.find((fee) => fee.targetLanguageId === selectedTargetLanguageId)
                  ?.translationFee
          ) || 0;

    const totalOfUPTargetLanguageAndFees = () => {
        if (!isSelectedAnyUPCountry) return 0;
        if (upAndNationalValidationsFees === serviceIncludedOptions.allFees.id) {
            let translationFeeValue: number;
            if (isEditMode) {
                translationFeeValue = upAgencyAndTranslationFees.translationFeeUpdated
                    ? translationFee
                    : epCountriesList?.some(
                            (item) =>
                                item.isSelected &&
                                (languageBasedFeeList.find(
                                    (fee) => fee.targetLanguageId === selectedTargetLanguageId
                                )?.countryId === item.countryId ||
                                    LANGUAGE_ID.SPANISH === selectedTargetLanguageId ||
                                    LANGUAGE_ID.GERMAN === selectedTargetLanguageId ||
                                    LANGUAGE_ID.ENGLISH === selectedTargetLanguageId) &&
                                !item.isNewRecord &&
                                !item.serviceIncluded.translationFee.translationFeeUpdated
                        )
                      ? upAgencyAndTranslationFees.translationFee
                      : translationFee;
            } else {
                translationFeeValue = translationFee;
            }

            let agencyFeeValue: number;
            if (isEditMode) {
                agencyFeeValue = upAgencyAndTranslationFees.agencyOrOfficialFeeUpdated
                    ? epCountriesData?.upAgencyFee || 0
                    : upAgencyAndTranslationFees.agencyFee;
            } else {
                agencyFeeValue = epCountriesData?.upAgencyFee || 0;
            }

            return translationFeeValue + agencyFeeValue;
        } else if (upAndNationalValidationsFees === serviceIncludedOptions.agencyFee.id) {
            let agencyFeeValue: number;
            if (isEditMode) {
                agencyFeeValue = upAgencyAndTranslationFees.agencyOrOfficialFeeUpdated
                    ? epCountriesData?.upAgencyFee || 0
                    : upAgencyAndTranslationFees.agencyFee;
            } else {
                agencyFeeValue = epCountriesData?.upAgencyFee || 0;
            }
            return agencyFeeValue;
        } else if (upAndNationalValidationsFees === serviceIncludedOptions.translationFee.id) {
            let translationFeeValue: number;
            if (isEditMode) {
                translationFeeValue = upAgencyAndTranslationFees.translationFeeUpdated
                    ? translationFee
                    : epCountriesList?.some(
                            (item) =>
                                item.isSelected &&
                                (languageBasedFeeList.find(
                                    (fee) => fee.targetLanguageId === selectedTargetLanguageId
                                )?.countryId === item.countryId ||
                                    LANGUAGE_ID.SPANISH === selectedTargetLanguageId ||
                                    LANGUAGE_ID.GERMAN === selectedTargetLanguageId ||
                                    LANGUAGE_ID.ENGLISH === selectedTargetLanguageId) &&
                                !item.isNewRecord &&
                                !item.serviceIncluded.translationFee.translationFeeUpdated
                        )
                      ? upAgencyAndTranslationFees.translationFee
                      : translationFee;
            } else {
                translationFeeValue = translationFee || 0;
            }
            return translationFeeValue;
        }
        return 0;
    };

    const isCountryIncludedApiSelectedList = (countryId: number) => {
        if (!countryId || countryId === 0) return false;
        return storeData?.selectedCountryFullList?.some((item) => item.countryId === countryId);
    };

    const validateCountryRemoval = async (
        country: EpCountryResponseList | undefined,
        orderId: number,
        isTranslationFeeSelected: boolean,
        isValidationAgencyOrOfficialFeeSelected: boolean,
        isIndirectTranslationAvailable: boolean
    ): Promise<boolean> => {
        if (!isCountryIncludedApiSelectedList(country?.countryId ?? 0)) return true;
        if (!country && props.orderEditMode) return false;

        const res = await selectCountryService.getVendorAssignmentValidation({
            orderId: orderId ?? 0,
            countryId: country?.countryId ?? 0,
            isTranslationFeeSelected,
            isValidationAgencyOrOfficialFeeSelected,
            isIndirectTranslationAvailable
        });

        if (!res.isCountryRemovable) {
            setConfirmationPopup({
                ...confirmationPopup,
                visible: true,
                taskIDs: res.taskNumbers
            });
            return false; // not removable
        }

        return true; // removable
    };

    const validateToggleChange = async (
        country: EpCountryResponseList | undefined,
        orderId: number,
        isAiTranslationEnabled: boolean
    ): Promise<boolean> => {
        const res = await selectCountryService.getTranslationModeValidation({
            orderId: orderId ?? 0,
            countryId: country?.countryId ?? 0,
            isAiTranslationEnabled
        });

        if (!res.isCountryRemovable) {
            setConfirmationPopup({
                ...confirmationPopup,
                visible: true,
                taskIDs: res.taskNumbers
            });
            return false; // not removable
        }

        return true; // removable
    };

    const handleIndirectTranslationAvailability = (country: EpCountryResponseList) => {
        if (
            country.serviceIncluded.translationFee.isSelected ||
            country.serviceIncluded.allFees.isSelected
        ) {
            const selectedCountryInSelectedList = epCountriesList.filter(
                (item) =>
                    item.isSelected &&
                    item.isEnglishTranslationRequired &&
                    (item.serviceIncluded.translationFee.isSelected ||
                        item.serviceIncluded.allFees.isSelected)
            );

            return selectedCountryInSelectedList.length === 1;
        } else {
            return false;
        }
    };

    const handleIncludedFees = async (id: number, selectedFeesId: number) => {
        const updatedEpCountriesList = await Promise.all(
            epCountriesList.map(async (country) => {
                if (country.id !== id) return country;
                let updatedServiceIncluded;
                const isCheckSelectedList = epCountriesData?.selectedCountryList?.some(
                    (item) => item.countryId === country.countryId
                );

                const agencyFeeChanged = {
                    ...country.serviceIncluded,
                    allFees: {
                        ...country.serviceIncluded.allFees,
                        value:
                            country.serviceIncluded.agencyFee.value +
                            country.serviceIncluded.officialFee.value +
                            country.translationFee,
                        isSelected: selectedFeesId === serviceIncludedOptions.allFees.id
                    },
                    agencyAndOfficialFee: {
                        ...country.serviceIncluded.agencyAndOfficialFee,
                        value:
                            country.serviceIncluded.agencyFee.value +
                            country.serviceIncluded.officialFee.value,
                        isSelected:
                            selectedFeesId === serviceIncludedOptions.agencyAndOfficialFee.id
                    },
                    translationFee: {
                        ...country.serviceIncluded.translationFee,
                        value: country.translationFee,
                        isSelected: selectedFeesId === serviceIncludedOptions.translationFee.id,
                        translationFeeUpdated: true
                    },
                    agencyFee: {
                        ...country.serviceIncluded.agencyFee,
                        value: country.serviceIncluded.agencyFee.value,
                        isSelected: selectedFeesId === serviceIncludedOptions.agencyFee.id
                    },
                    officialFee: {
                        ...country.serviceIncluded.officialFee,
                        value: country.serviceIncluded.officialFee.value,
                        isSelected: selectedFeesId === serviceIncludedOptions.officialFee.id
                    }
                };

                const translationFeeChanged = {
                    ...country.serviceIncluded,
                    allFees: {
                        ...country.serviceIncluded.allFees,
                        value:
                            country.agencyFee +
                            country.officialFee +
                            country.serviceIncluded.translationFee.value,
                        isSelected: selectedFeesId === serviceIncludedOptions.allFees.id
                    },
                    agencyAndOfficialFee: {
                        ...country.serviceIncluded.agencyAndOfficialFee,
                        value: country.agencyFee + country.officialFee,
                        isSelected:
                            selectedFeesId === serviceIncludedOptions.agencyAndOfficialFee.id,
                        agencyOrOfficialFeeUpdated: true
                    },
                    translationFee: {
                        ...country.serviceIncluded.translationFee,
                        value: country.serviceIncluded.translationFee.value,
                        isSelected: selectedFeesId === serviceIncludedOptions.translationFee.id
                    },
                    agencyFee: {
                        ...country.serviceIncluded.agencyFee,
                        value: country.agencyFee,
                        isSelected: selectedFeesId === serviceIncludedOptions.agencyFee.id
                    },
                    officialFee: {
                        ...country.serviceIncluded.officialFee,
                        value: country.officialFee,
                        isSelected: selectedFeesId === serviceIncludedOptions.officialFee.id
                    }
                };

                if (isEditMode && isCheckSelectedList) {
                    if (selectedFeesId === serviceIncludedOptions.agencyAndOfficialFee.id) {
                        if (props.orderEditMode?.isOrderEdit) {
                            const validateVendorAssignment = await validateCountryRemoval(
                                country,
                                props.orderEditMode?.orderId ?? 0,
                                false,
                                true,
                                handleIndirectTranslationAvailability(country)
                            );
                            if (validateVendorAssignment) {
                                updatedServiceIncluded = agencyFeeChanged;
                            } else {
                                updatedServiceIncluded = { ...country.serviceIncluded };
                            }
                        } else {
                            updatedServiceIncluded = agencyFeeChanged;
                        }
                    } else if (selectedFeesId === serviceIncludedOptions.translationFee.id) {
                        if (props.orderEditMode?.isOrderEdit) {
                            const validateVendorAssignment = await validateCountryRemoval(
                                country,
                                props.orderEditMode?.orderId ?? 0,
                                true,
                                false,
                                handleIndirectTranslationAvailability(country)
                            );
                            if (validateVendorAssignment) {
                                updatedServiceIncluded = translationFeeChanged;
                            } else {
                                updatedServiceIncluded = { ...country.serviceIncluded };
                            }
                        } else {
                            updatedServiceIncluded = translationFeeChanged;
                        }
                    } else {
                        updatedServiceIncluded = {
                            ...country.serviceIncluded,
                            allFees: {
                                ...country.serviceIncluded.allFees,
                                value:
                                    country.serviceIncluded.agencyFee.value +
                                    country.serviceIncluded.officialFee.value +
                                    country.serviceIncluded.translationFee.value,
                                isSelected: selectedFeesId === serviceIncludedOptions.allFees.id
                            },
                            agencyAndOfficialFee: {
                                ...country.serviceIncluded.agencyAndOfficialFee,
                                value:
                                    country.serviceIncluded.agencyFee.value +
                                    country.serviceIncluded.officialFee.value,
                                isSelected:
                                    selectedFeesId ===
                                    serviceIncludedOptions.agencyAndOfficialFee.id
                            },
                            translationFee: {
                                ...country.serviceIncluded.translationFee,
                                value: country.serviceIncluded.translationFee.value,
                                isSelected:
                                    selectedFeesId === serviceIncludedOptions.translationFee.id
                            }
                        };
                    }
                } else {
                    updatedServiceIncluded = {
                        ...country.serviceIncluded,
                        allFees: {
                            ...country.serviceIncluded.allFees,
                            isSelected: selectedFeesId === serviceIncludedOptions.allFees.id
                        },
                        agencyAndOfficialFee: {
                            ...country.serviceIncluded.agencyAndOfficialFee,
                            isSelected:
                                selectedFeesId === serviceIncludedOptions.agencyAndOfficialFee.id
                        },
                        translationFee: {
                            ...country.serviceIncluded.translationFee,
                            isSelected: selectedFeesId === serviceIncludedOptions.translationFee.id
                        }
                    };
                }
                return {
                    ...country,
                    agencyOrOfficialFeeUpdated:
                        updatedServiceIncluded.agencyAndOfficialFee.agencyOrOfficialFeeUpdated,
                    translationFeeUpdated:
                        updatedServiceIncluded.translationFee.translationFeeUpdated,
                    serviceIncluded: updatedServiceIncluded
                };
            })
        );
        setEpCountriesList(updatedEpCountriesList);
        handleGroupedCountriesTranslationFee(updatedEpCountriesList);
    };

    const labelTemplate = (option: any) => {
        return (
            <div className="flex items-center gap-2">
                {(() => {
                    let colorClass = 'text-primary';
                    if (option?.id === serviceIncludedOptions.allFees.id) {
                        colorClass = 'text-success-green';
                    } else if (
                        option?.id === serviceIncludedOptions.agencyFee?.id ||
                        option?.id === serviceIncludedOptions.agencyAndOfficialFee.id
                    ) {
                        colorClass = 'text-soft-yellow';
                    }
                    return (
                        <i className={`pi pi-circle-fill text-[0.75rem] pt-0.5 ${colorClass}`}></i>
                    );
                })()}
                <span className="font-medium leading-loose">{option?.label}</span>
            </div>
        );
    };

    const includedFeesTemplate = (
        id: number,
        serviceIncluded: EpCountryResponseList['serviceIncluded']
    ) => {
        return (
            <div className="w-fit">
                <Dropdown
                    data-testid={`service-dropdown-${id}`}
                    key={id}
                    pt={hoverDropdownStyle}
                    value={
                        Object.values(serviceIncluded).find((item) => item.isSelected)?.id ||
                        serviceIncludedOptions.allFees.id
                    }
                    valueTemplate={labelTemplate}
                    defaultValue={'allFees'}
                    optionLabel="label"
                    optionValue="id"
                    options={Object.values(serviceIncludedOptions).filter(
                        (option) =>
                            option.id !== serviceIncludedOptions.agencyFee?.id &&
                            option.id !== serviceIncludedOptions.officialFee?.id
                    )}
                    onChange={(e) => {
                        if (e.value === null) return;
                        handleIncludedFees(id, Number(e.value));
                    }}
                    onKeyUp={(e) => {
                        if (e.key === 'Enter') {
                            const li = e.target as HTMLElement;
                            const selectedValue =
                                li.getAttribute('data-pc-section') === 'item'
                                    ? li.getAttribute('aria-label')
                                    : null;

                            if (selectedValue) {
                                const matchedOption = Object.values(serviceIncludedOptions).find(
                                    (opt) => opt.label.includes(selectedValue)
                                );
                                if (matchedOption) {
                                    handleIncludedFees(id, matchedOption.id);
                                }
                            }
                        }
                    }}
                    itemTemplate={labelTemplate}
                />
            </div>
        );
    };

    const handleGroupedCountriesTranslationFee = (
        updatedList: EpCountryResponseList[],
        isDirectToggleSwitch?: boolean
    ) => {
        const updatedCountryList = updatedList.map((country) => {
            if (country.groupId) {
                let translationFeeValue: number;
                if (
                    country.isPrimaryDisplay ||
                    !isPrimaryCountrySelected(updatedList, country.groupId)
                ) {
                    if (isEditMode && !country.isNewRecord) {
                        translationFeeValue = country.translationFeeUpdated
                            ? country.groupedCountryTranslationFee
                            : isPrimaryCountrySelected(updatedList, country.groupId)
                              ? country.serviceIncluded.translationFee.value
                              : country.groupedCountryTranslationFee;
                    } else {
                        translationFeeValue = country.groupedCountryTranslationFee;
                    }
                } else {
                    if (isPrimaryCountryIsTranslationSelected(updatedList, country.groupId)) {
                        translationFeeValue = 0;
                    } else {
                        if (isEditMode && !country.isNewRecord) {
                            translationFeeValue = country.translationFeeUpdated
                                ? country.groupedCountryTranslationFee
                                : country.groupedCountrySelectedListTranslationFee?.hasSelectedList
                                  ? isPrimaryCountryIsTranslationSelected(
                                        updatedList,
                                        country.groupId
                                    )
                                      ? country.groupedCountrySelectedListTranslationFee
                                            ?.translationFee || 0
                                      : country.groupedCountryTranslationFee
                                  : country.serviceIncluded.translationFee.value;
                        } else {
                            translationFeeValue = country.groupedCountryTranslationFee;
                        }
                    }
                }

                return {
                    ...country,
                    translationFee: translationFeeValue,
                    isUserPreferredAiTranslationUpdated:
                        !isDirectToggleSwitch &&
                        epCountriesList?.some(
                            (item) =>
                                item.groupId === country.groupId &&
                                item.countryId !== country.countryId &&
                                item.isSelected
                        )
                            ? epCountriesList?.find(
                                  (item) =>
                                      item.groupId === country.groupId &&
                                      item.countryId !== country.countryId &&
                                      item.isSelected
                              )?.isUserPreferredAiTranslationUpdated || false
                            : country.isUserPreferredAiTranslationUpdated,
                    serviceIncluded: {
                        ...country.serviceIncluded,
                        translationFee: {
                            ...country.serviceIncluded.translationFee,
                            value: translationFeeValue
                        },
                        allFees: {
                            ...country.serviceIncluded.allFees,
                            value:
                                country.serviceIncluded.agencyAndOfficialFee.value +
                                translationFeeValue
                        }
                    }
                };
            }
            return country;
        });
        setEpCountriesList(updatedCountryList);
    };

    const handleCountrySelection = async (
        selectedCountries: EpCountryResponseList[],
        checked?: boolean
    ) => {
        const updatedList = await Promise.all(
            epCountriesList.map(async (country) => {
                const selected = selectedCountries.find(
                    (item) => item.countryId === country.countryId
                );

                const resetServiceIncluded = {
                    ...country,
                    isSelected: false,
                    isNewRecord: isEditMode ? true : undefined,
                    isUserPreferredAiTranslationUpdated: country.isUserPreferredAiTranslation,
                    translationFee: country.isUserPreferredAiTranslation
                        ? country.aiTranslationFee
                        : country.translationFormulaFee,
                    serviceIncluded: {
                        ...country.serviceIncluded,
                        allFees: {
                            ...country.serviceIncluded.allFees,
                            value:
                                country.agencyFee +
                                country.officialFee +
                                (country.isUserPreferredAiTranslation
                                    ? country.aiTranslationFee
                                    : country.translationFormulaFee),
                            isSelected: true
                        },
                        agencyAndOfficialFee: {
                            ...country.serviceIncluded.agencyAndOfficialFee,
                            value: country.agencyFee + country.officialFee,
                            isSelected: false
                        },
                        translationFee: {
                            ...country.serviceIncluded.translationFee,
                            value: country.isUserPreferredAiTranslation
                                ? country.aiTranslationFee
                                : country.translationFormulaFee,
                            isSelected: false
                        },
                        officialFee: {
                            ...country.serviceIncluded.officialFee,
                            value: country.officialFee,
                            isSelected: false
                        }
                    }
                };

                if (selected) {
                    if (country.isSelected) return country;
                    return {
                        ...country,
                        isSelected: true,
                        isNewRecord: isEditMode ? true : undefined,
                        serviceIncluded: resetServiceIncluded.serviceIncluded,
                        isUserPreferredAiTranslationUpdated: country.isUserPreferredAiTranslation
                    };
                } else {
                    if (props.orderEditMode?.isOrderEdit && !checked && country.isSelected) {
                        const uncheckedCountry = epCountriesList.find(
                            (item) => item.countryId === country.countryId && item.isSelected
                        );

                        const isRemovable = await validateCountryRemoval(
                            uncheckedCountry,
                            props.orderEditMode?.orderId ?? 0,
                            false,
                            false,
                            handleIndirectTranslationAvailability(uncheckedCountry!)
                        );

                        if (!isRemovable) {
                            return {
                                ...country,
                                isSelected: country.isSelected,
                                isNewRecord: country.isNewRecord,
                                serviceIncluded: {
                                    ...country.serviceIncluded
                                },
                                isUserPreferredAiTranslationUpdated:
                                    country.isUserPreferredAiTranslationUpdated
                            };
                        } else {
                            return resetServiceIncluded;
                        }
                    } else {
                        return resetServiceIncluded;
                    }
                }
            })
        );
        setEpCountriesList(updatedList);
        handleGroupedCountriesTranslationFee(updatedList);
    };

    const handleSelectAll = (checked: boolean) => {
        const updatedList = epCountriesList.map((country) => {
            let isSelected: boolean;
            if (props.orderEditMode?.isOrderEdit && !props.orderEditMode?.isEPOrder) {
                if (props.orderEditMode?.isUpOrder) {
                    if (country.isUp) {
                        isSelected = checked;
                    } else {
                        isSelected = country.isSelected;
                    }
                } else {
                    if (country.isUp) {
                        isSelected = country.isSelected;
                    } else {
                        isSelected = checked;
                    }
                }
            } else {
                isSelected = checked;
            }

            return {
                ...country,
                isSelected,
                isNewRecord: (() => {
                    if (checked) return country.isNewRecord;
                    if (isEditMode) return true;
                    return undefined;
                })(),
                isUserPreferredAiTranslationUpdated: country.isSelected
                    ? country.isUserPreferredAiTranslationUpdated
                    : country.isUserPreferredAiTranslation,
                translationFee: country.isSelected
                    ? country.translationFee
                    : country.isUserPreferredAiTranslation
                      ? country.aiTranslationFee
                      : country.translationFormulaFee,
                serviceIncluded: {
                    ...country.serviceIncluded,
                    allFees: {
                        ...country.serviceIncluded.allFees,
                        isSelected: country.isSelected
                            ? country.serviceIncluded.allFees.isSelected
                            : true,
                        value: checked
                            ? country.serviceIncluded.allFees.value
                            : country.agencyFee +
                              country.officialFee +
                              (country.isUserPreferredAiTranslation
                                  ? country.aiTranslationFee
                                  : country.translationFormulaFee)
                    },
                    agencyAndOfficialFee: {
                        ...country.serviceIncluded.agencyAndOfficialFee,
                        isSelected: country.isSelected
                            ? country.serviceIncluded.agencyAndOfficialFee.isSelected
                            : false,
                        value: checked
                            ? country.serviceIncluded.agencyAndOfficialFee.value
                            : country.agencyFee + country.officialFee
                    },
                    translationFee: {
                        ...country.serviceIncluded.translationFee,
                        isSelected: country.isSelected
                            ? country.serviceIncluded.translationFee.isSelected
                            : false,
                        value: checked
                            ? country.serviceIncluded.translationFee.value
                            : country.isUserPreferredAiTranslation
                              ? country.aiTranslationFee
                              : country.translationFormulaFee
                    }
                }
            };
        });
        setEpCountriesList(updatedList);
        handleGroupedCountriesTranslationFee(updatedList);
    };

    const handleIsUPOnly = (checked: boolean) => {
        const updatedList = epCountriesList.map((country) => {
            if (country.isUp) {
                return {
                    ...country,
                    isSelected: checked ?? false,
                    isNewRecord: checked ? country.isNewRecord : isEditMode ? true : undefined,
                    isUserPreferredAiTranslationUpdated: country.isSelected
                        ? country.isUserPreferredAiTranslationUpdated
                        : country.isUserPreferredAiTranslation,
                    translationFee: country.isSelected
                        ? country.translationFee
                        : country.isUserPreferredAiTranslation
                          ? country.aiTranslationFee
                          : country.translationFormulaFee,
                    serviceIncluded: {
                        ...country.serviceIncluded,
                        allFees: {
                            ...country.serviceIncluded.allFees,
                            isSelected: country.isSelected
                                ? country.serviceIncluded.allFees.isSelected
                                : true,
                            value: checked
                                ? country.serviceIncluded.allFees.value
                                : country.agencyFee +
                                  country.officialFee +
                                  (country.isUserPreferredAiTranslation
                                      ? country.aiTranslationFee
                                      : country.translationFormulaFee)
                        },
                        agencyAndOfficialFee: {
                            ...country.serviceIncluded.agencyAndOfficialFee,
                            isSelected: country.isSelected
                                ? country.serviceIncluded.agencyAndOfficialFee.isSelected
                                : false,
                            value: checked
                                ? country.serviceIncluded.agencyAndOfficialFee.value
                                : country.agencyFee + country.officialFee
                        },
                        translationFee: {
                            ...country.serviceIncluded.translationFee,
                            isSelected: country.isSelected
                                ? country.serviceIncluded.translationFee.isSelected
                                : false,
                            value: checked
                                ? country.serviceIncluded.translationFee.value
                                : country.isUserPreferredAiTranslation
                                  ? country.aiTranslationFee
                                  : country.translationFormulaFee
                        }
                    }
                };
            }
            return country;
        });
        setEpCountriesList(updatedList);
        handleGroupedCountriesTranslationFee(updatedList);
    };

    const countryNameTemplate = (rowData: EpCountryResponseList) => {
        return (
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <div className="avatar">
                        <div className="h-5 rounded-full border">
                            <div
                                className={`h-full w-full bg-no-repeat bg-center`}
                                style={{
                                    backgroundImage:
                                        'url(/images/country-flags/' + rowData?.iconName + ')',
                                    backgroundSize: '150%'
                                }}></div>
                        </div>
                    </div>
                    <div className={`country-name-${rowData.countryName} flex items-center`}>
                        {rowData.countryName}
                        {rowData.countryId === COUNTRY_ID.SPAIN && isEnglishSourceLanguage && (
                            <span>
                                <Tooltip
                                    target={`.country-name-Spain`}
                                    content={t('SELECT_COUNTRY.SPAIN_INFO_TOOLTIP')}
                                    pt={tooltipStyle}
                                />
                                <i className={`pi pi-info-circle ml-2 pt-px text-primary`} />
                            </span>
                        )}
                    </div>
                </div>

                {rowData?.isUp && (
                    <p className="text-primary bg-primary/10 p-1 rounded-md">{t('COMMON.UP')}</p>
                )}
            </div>
        );
    };

    const ValidationAndSaveCountryToggleChange = async (
        rowData: EpCountryResponseList,
        isChecked: boolean
    ) => {
        const res = await selectCountryService.getTranslationModeValidation({
            countryId: rowData.countryId,
            isAiTranslationEnabled: isChecked,
            orderId: props.orderEditMode?.orderId
        });
        if (res.isCountryRemovable === true) {
            handleAiTranslationToggle(rowData, isChecked);
        } else {
            await validateToggleChange(rowData, props.orderEditMode?.orderId ?? 0, isChecked);
            return <></>;
        }
    };

    const handleAiTranslationToggle = (rowData: EpCountryResponseList, isChecked: boolean) => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });

        const updatedList = epCountriesList.map((country) => {
            if (
                country.countryId === rowData.countryId ||
                (country.groupId === rowData.groupId && rowData.groupId && country.groupId)
            ) {
                return {
                    ...country,
                    aiHtTranslationToggleUpdated: isEditMode ? true : undefined,
                    isUserPreferredAiTranslationUpdated: isChecked,
                    translationFee: isChecked
                        ? country.aiTranslationFee
                        : country.translationFormulaFee,
                    groupedCountryTranslationFee: isChecked
                        ? country.aiTranslationFee
                        : country.translationFormulaFee,
                    serviceIncluded: {
                        ...country.serviceIncluded,
                        allFees: {
                            ...country.serviceIncluded.allFees,
                            value:
                                country.agencyFee +
                                country.officialFee +
                                (isChecked
                                    ? country.aiTranslationFee
                                    : country.translationFormulaFee)
                        },
                        translationFee: {
                            ...country.serviceIncluded.translationFee,
                            value: isChecked
                                ? country.aiTranslationFee
                                : country.translationFormulaFee
                        }
                    }
                };
            }
            return country;
        });
        setEpCountriesList(updatedList);
        handleGroupedCountriesTranslationFee(updatedList, true);
    };

    const translationFeeTemplate = (rowData: EpCountryResponseList) => {
        let feeValue = 0;
        if (
            rowData.serviceIncluded.translationFee.isSelected ||
            rowData.serviceIncluded.allFees.isSelected
        ) {
            feeValue =
                isEditMode && !rowData.isNewRecord
                    ? rowData.serviceIncluded.translationFee.value
                    : rowData.translationFee;
        }
        return (
            <div className="w-full flex justify-between items-center translation-fee-cell">
                {rowData.isAiTranslationConfiguration ||
                rowData.isUserPreferredAiTranslation ||
                rowData.selectedListIsAiTranslationConfiguration ? (
                    <InputSwitch
                        checked={rowData.isUserPreferredAiTranslationUpdated}
                        disabled={
                            (!rowData.isUserPreferredAiTranslationUpdated &&
                                !rowData.isAiTranslationConfiguration) ||
                            (!rowData.serviceIncluded.translationFee.isSelected &&
                                !rowData.serviceIncluded.allFees.isSelected)
                        }
                        onChange={(e) =>
                            isEditMode
                                ? void ValidationAndSaveCountryToggleChange(rowData, e.value)
                                : void handleAiTranslationToggle(rowData, e.value)
                        }
                        pt={translationFeeInputSwitchPT}
                    />
                ) : (
                    <div></div>
                )}
                <span className="w-24">{selectedCurrency(currencySymbol, feeValue)}</span>
            </div>
        );
    };

    const generateTableData = (data: EpCountryResponseList[]) => {
        return data
            .slice()
            .sort((a, b) => a.countryName.localeCompare(b.countryName))
            .map((country) => ({
                ...country,
                id: country.id,
                countryNameTemplate: countryNameTemplate(country),
                isSelected: country.isSelected,
                includedFeesTemplate: includedFeesTemplate(country.id, country.serviceIncluded),
                translationFeeTemplate: translationFeeTemplate(country),
                totalIncludedFees: Object.values(country.serviceIncluded).find(
                    (item) => item.isSelected
                )?.value,
                serviceIncluded: country.serviceIncluded
            }));
    };

    // region API Country list
    const fetchEpCountriesData = async (currencyId: number, isCurrencyChanged?: boolean) => {
        let data: EpCountriesData;
        data = await (props.orderEditMode?.isOrderEdit
            ? selectCountryService.getEpOrderEditCountryListing(props.orderEditMode?.orderId ?? 0)
            : selectCountryService.getEpCountryListing(currencyId));

        data = {
            ...data,
            epCountryResponseList: data.epCountryResponseList.map((country) => {
                const selectedCountry = data?.selectedCountryList?.find(
                    (item) => item.countryId === country.countryId
                );

                const storedCountry = storeData?.epCountryResponseList?.find(
                    (item) => item.countryId === country.countryId
                );

                const storedIsSelectedCountry = storeData?.epCountryResponseList?.find(
                    (item) => item.countryId === country.countryId && item.isSelected
                );

                const groupSelectedCountry = data?.selectedCountryList?.find(
                    (item) => item.groupId === country.groupId && item.includeTranslationFee
                );

                return {
                    ...country,
                    includeInSelectedCountry: data?.selectedCountryList?.some(
                        (item) => item.countryId === country.countryId
                    ),
                    selectedListAgencyFeeFormula: selectedCountry?.agencyFeeFormula,
                    selectedListOfficialFeeFormula: selectedCountry?.officialFeeFormula,
                    selectedListTranslationFeeFormula: selectedCountry?.translationFeeFormula,
                    agencyOrOfficialFeeUpdated: (() => {
                        if (isEditMode) {
                            if (isCurrencyChanged) {
                                return true;
                            } else {
                                return storedCountry?.agencyOrOfficialFeeUpdated;
                            }
                        }
                        return undefined;
                    })(),

                    translationFeeUpdated: (() => {
                        if (isEditMode) {
                            if (isCurrencyChanged) {
                                return true;
                            } else {
                                return storedCountry?.translationFeeUpdated;
                            }
                        }
                        return undefined;
                    })(),

                    aiHtTranslationToggleUpdated: (() => {
                        if (isEditMode) {
                            if (isCurrencyChanged) {
                                return undefined;
                            } else {
                                return storedCountry?.aiHtTranslationToggleUpdated;
                            }
                        }
                        return undefined;
                    })(),

                    isUserPreferredAiTranslationUpdated: (() => {
                        if (isEditMode) {
                            if (isCurrencyChanged) {
                                return country.isUserPreferredAiTranslation;
                            } else if (storedIsSelectedCountry?.aiHtTranslationToggleUpdated) {
                                return (
                                    storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated ??
                                    false
                                );
                            } else if (selectedCountry?.includeTranslationFee) {
                                return selectedCountry?.isUserPreferredAiTranslation ?? false;
                            } else if (selectedCountry?.groupId) {
                                return groupSelectedCountry?.isUserPreferredAiTranslation ?? false;
                            } else {
                                return country.isUserPreferredAiTranslation;
                            }
                        } else if (isCurrencyChanged) {
                            return country.isUserPreferredAiTranslation;
                        } else {
                            return (
                                storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated ??
                                false
                            );
                        }
                    })(),

                    selectedListIsAiTranslationConfiguration: isEditMode
                        ? (selectedCountry?.isAiTranslationConfiguration ?? false)
                        : undefined,

                    translationFee: (() => {
                        if (isCurrencyChanged) {
                            return country.translationFee;
                        }
                        if (
                            country.isAiTranslationConfiguration ||
                            country.isUserPreferredAiTranslation
                        ) {
                            if (selectedCountry && isEditMode) {
                                if (storedIsSelectedCountry?.aiHtTranslationToggleUpdated) {
                                    return (storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated ??
                                        false)
                                        ? country.aiTranslationFee
                                        : country.translationFormulaFee;
                                } else if (
                                    groupSelectedCountry?.isUserPreferredAiTranslation ??
                                    false
                                ) {
                                    return country.aiTranslationFee;
                                } else {
                                    return country.translationFormulaFee;
                                }
                            } else if (
                                storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated
                            ) {
                                return country.translationFormulaFee;
                            } else {
                                return country.aiTranslationFee;
                            }
                        }
                        return country.translationFee;
                    })(),

                    groupedCountryTranslationFee: (() => {
                        if (isCurrencyChanged) {
                            return country.translationFee;
                        }
                        if (
                            country.isAiTranslationConfiguration ||
                            country.isUserPreferredAiTranslation
                        ) {
                            if (
                                storedIsSelectedCountry?.aiHtTranslationToggleUpdated &&
                                isEditMode
                            ) {
                                return (storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated ??
                                    false)
                                    ? country.aiTranslationFee
                                    : country.translationFormulaFee;
                            }
                            if (selectedCountry?.groupId && isEditMode) {
                                const isGroupAi =
                                    groupSelectedCountry?.isUserPreferredAiTranslation ?? false;
                                return isGroupAi
                                    ? country.aiTranslationFee
                                    : country.translationFormulaFee;
                            } else {
                                return storedIsSelectedCountry?.isUserPreferredAiTranslationUpdated
                                    ? country.aiTranslationFee
                                    : country.translationFee;
                            }
                        }
                        return country.translationFee;
                    })(),

                    groupedCountrySelectedListTranslationFee: {
                        hasSelectedList: data?.selectedCountryList?.some(
                            (item) => item.countryId === country.countryId && item.ep
                        ),
                        translationFee: data?.selectedCountryList?.find(
                            (item) => item.countryId === country.countryId && item.ep
                        )?.translationFee
                    }
                };
            }),
            selectedLanguageId: isEditMode
                ? data?.selectedCountryList?.find(
                      (item) => item.countryId === null && item.languageId && item.up && !item.ep
                  )?.languageId
                : undefined,
            selectedCountryFullList: data?.selectedCountryList,
            // Ep countries only - customize
            selectedCountryList: data?.selectedCountryList
                ?.filter((country) => country.countryId && country.ep)
                .map((country) => ({
                    ...country,
                    isNewRecord: isEditMode ? false : undefined,
                    isUserPreferredAiTranslationUpdated:
                        data?.selectedCountryList?.find(
                            (item) => item.countryId === country.countryId
                        )?.isUserPreferredAiTranslation ?? false,
                    serviceIncluded: {
                        allFees: {
                            ...serviceIncludedOptions.allFees,
                            value: country.agencyFee + country.officialFee + country.translationFee,
                            isSelected:
                                country.includeAgencyFee &&
                                country.includeOfficialFee &&
                                country.includeTranslationFee
                        },
                        agencyAndOfficialFee: {
                            ...serviceIncludedOptions.agencyAndOfficialFee,
                            value: country.agencyFee + country.officialFee,
                            isSelected:
                                country.includeAgencyFee &&
                                country.includeOfficialFee &&
                                !country.includeTranslationFee
                        },
                        agencyFee: {
                            ...serviceIncludedOptions.agencyFee,
                            value: country.agencyFee,
                            isSelected:
                                (country.includeAgencyFee || country.includeOfficialFee) &&
                                !country.includeTranslationFee
                        },
                        officialFee: {
                            ...serviceIncludedOptions.officialFee,
                            value: country.officialFee,
                            isSelected:
                                (country.includeAgencyFee || country.includeOfficialFee) &&
                                !country.includeTranslationFee
                        },
                        translationFee: {
                            ...serviceIncludedOptions.translationFee,
                            value: country.translationFee,
                            isSelected:
                                !country.includeAgencyFee &&
                                !country.includeOfficialFee &&
                                country.includeTranslationFee
                        }
                    }
                }))
        };

        const selectedCountries = data?.selectedCountryList || [];

        const updatedList = data.epCountryResponseList.map((country) => {
            const storedData = storeData?.epCountryResponseList.find(
                (item) => item.countryId === country.countryId
            );
            const storedDataServiceIncluded = storedData?.serviceIncluded;

            const isNewRecord = storeData?.epCountryResponseList?.find(
                (item) => item.countryId === country.countryId
            )?.isNewRecord;

            const isEditNotNewRecord = isEditMode && !isNewRecord;

            const findCountry = selectedCountries.find(
                (item) => item.countryId === country.countryId
            );

            let agencyFeeAmount = country.agencyFee;
            let officialFeeAmount = country.officialFee;
            let translationFeeAmount = country.translationFee;

            if (isEditNotNewRecord && country.includeInSelectedCountry && !isCurrencyChanged) {
                agencyFeeAmount = (() => {
                    const isAgencyOrAllSelected =
                        findCountry?.serviceIncluded?.agencyFee.isSelected ||
                        findCountry?.serviceIncluded.allFees.isSelected;
                    if (isAgencyOrAllSelected) {
                        if (storedData?.agencyOrOfficialFeeUpdated) {
                            return country.agencyFee;
                        } else {
                            return (
                                selectedCountries.find(
                                    (item) => item.countryId === country.countryId
                                )?.agencyFee ?? 0
                            );
                        }
                    } else {
                        return country.agencyFee;
                    }
                })();

                officialFeeAmount = (() => {
                    const isOfficialOrAllSelected =
                        findCountry?.serviceIncluded?.officialFee.isSelected ||
                        findCountry?.serviceIncluded.allFees.isSelected;
                    if (isOfficialOrAllSelected) {
                        if (storedData?.agencyOrOfficialFeeUpdated) {
                            return country.officialFee;
                        } else {
                            return (
                                selectedCountries.find(
                                    (item) => item.countryId === country.countryId
                                )?.officialFee ?? 0
                            );
                        }
                    } else {
                        return country.officialFee;
                    }
                })();

                translationFeeAmount = (() => {
                    const isTranslationOrAllSelected =
                        findCountry?.serviceIncluded?.translationFee.isSelected ||
                        findCountry?.serviceIncluded.allFees.isSelected;
                    if (isTranslationOrAllSelected) {
                        if (
                            storedData?.translationFeeUpdated ||
                            (isEditMode ? storedData?.aiHtTranslationToggleUpdated : true)
                        ) {
                            return country.translationFee;
                        } else {
                            return (
                                selectedCountries.find(
                                    (item) => item.countryId === country.countryId
                                )?.translationFee ?? 0
                            );
                        }
                    } else {
                        return country.translationFee;
                    }
                })();
            }

            const allFeesValue =
                isEditNotNewRecord && country.includeInSelectedCountry && !isCurrencyChanged
                    ? agencyFeeAmount + officialFeeAmount + translationFeeAmount
                    : country.agencyFee + country.officialFee + country.translationFee;

            const agencyAndOfficialFeeValue =
                isEditNotNewRecord && country.includeInSelectedCountry && !isCurrencyChanged
                    ? agencyFeeAmount + officialFeeAmount
                    : country.agencyFee + country.officialFee;

            const agencyFeeValue = agencyFeeAmount;
            const translationFeeValue = translationFeeAmount;
            const officialFeeValue = officialFeeAmount;

            const isCheckAllFees =
                isEditNotNewRecord &&
                !storedData?.agencyOrOfficialFeeUpdated &&
                !storedData?.translationFeeUpdated
                    ? findCountry?.serviceIncluded?.agencyAndOfficialFee.isSelected ||
                      findCountry?.serviceIncluded?.translationFee.isSelected
                    : storedDataServiceIncluded?.agencyAndOfficialFee.isSelected ||
                      storedDataServiceIncluded?.translationFee.isSelected;

            const isCheckAgencyAndOfficialFee =
                isEditNotNewRecord &&
                !storedData?.agencyOrOfficialFeeUpdated &&
                !storedData?.translationFeeUpdated
                    ? storedDataServiceIncluded?.agencyAndOfficialFee.isSelected ||
                      findCountry?.serviceIncluded?.agencyAndOfficialFee.isSelected ||
                      false
                    : (storedDataServiceIncluded?.agencyAndOfficialFee.isSelected ?? false);

            const isCheckAgencyFee =
                isEditNotNewRecord &&
                !storedData?.agencyOrOfficialFeeUpdated &&
                !storedData?.translationFeeUpdated
                    ? storedDataServiceIncluded?.agencyFee.isSelected ||
                      findCountry?.serviceIncluded?.agencyFee.isSelected ||
                      false
                    : (storedDataServiceIncluded?.agencyFee.isSelected ?? false);

            const isCheckOfficialFee =
                isEditNotNewRecord &&
                !storedData?.agencyOrOfficialFeeUpdated &&
                !storedData?.translationFeeUpdated
                    ? storedDataServiceIncluded?.officialFee.isSelected ||
                      findCountry?.serviceIncluded?.officialFee.isSelected ||
                      false
                    : (storedDataServiceIncluded?.officialFee.isSelected ?? false);

            const isCheckTranslationFee =
                isEditNotNewRecord &&
                !storedData?.agencyOrOfficialFeeUpdated &&
                !storedData?.translationFeeUpdated
                    ? storedDataServiceIncluded?.translationFee.isSelected ||
                      findCountry?.serviceIncluded?.translationFee.isSelected ||
                      false
                    : (storedDataServiceIncluded?.translationFee.isSelected ?? false);

            return {
                ...country,
                id: country.countryId,
                isSelected: (() => {
                    if (isEditNotNewRecord) {
                        if (props?.orderEditMode?.isOrderEdit && props?.orderEditMode?.isUpOrder) {
                            return country.isUp || false;
                        } else {
                            return (
                                selectedCountries.some(
                                    (item) => item.countryId === country.countryId
                                ) ||
                                storedData?.isSelected ||
                                false
                            );
                        }
                    } else {
                        return storedData?.isSelected || false;
                    }
                })(),
                serviceIncluded: {
                    allFees: {
                        ...serviceIncludedOptions.allFees,
                        value: allFeesValue,
                        isSelected: !isCheckAllFees
                    },
                    agencyAndOfficialFee: {
                        ...serviceIncludedOptions.agencyAndOfficialFee,
                        value: agencyAndOfficialFeeValue,
                        isSelected: isCheckAgencyAndOfficialFee,
                        agencyOrOfficialFeeUpdated:
                            isEditMode && storedData?.agencyOrOfficialFeeUpdated
                    },
                    agencyFee: {
                        ...serviceIncludedOptions.agencyFee,
                        value: agencyFeeValue,
                        isSelected: isCheckAgencyFee
                    },
                    translationFee: {
                        ...serviceIncludedOptions.translationFee,
                        value: translationFeeValue,
                        isSelected: isCheckTranslationFee,
                        translationFeeUpdated: isEditMode && storedData?.translationFeeUpdated
                    },
                    officialFee: {
                        ...serviceIncludedOptions.officialFee,
                        value: officialFeeValue,
                        isSelected: isCheckOfficialFee
                    }
                }
            };
        });

        setEpCountriesData(data);
        setEpCountriesList(updatedList);
        setLanguageBasedFeeList(data.languageBasedFeeList);
        setNoEnglishTranslationRequired(data.noEnglishTranslationRequired || false);
        handleGroupedCountriesTranslationFee(updatedList);
        const upCountry = data?.selectedCountryFullList?.find((item) => !item.ep && item.up);

        const translationIncluded = data?.selectedCountryFullList?.find(
            (item) => item.countryId === null && item.languageId && item.up && !item.ep
        )?.includeTranslationFee;

        if (isEditMode && isCurrencyChanged) {
            setUpAgencyAndTranslationFees({
                ...upAgencyAndTranslationFees,
                agencyFee: upCountry?.agencyFee || 0,
                translationFee:
                    data?.epCountryResponseList.find(
                        (item) =>
                            item.countryId === null && item.languageId && item.isUp && !item.isEp
                    )?.translationFee || 0,
                agencyOrOfficialFeeUpdated: true,
                translationFeeUpdated: true
            });
        }

        if (
            isEditMode &&
            !storeData?.upAndNationalValidationsFeesID?.agencyOrOfficialFeeUpdated &&
            !storeData?.upAndNationalValidationsFeesID?.translationFeeUpdated &&
            !isCurrencyChanged
        ) {
            const upCountryData = data?.selectedCountryFullList?.find(
                (item) => !item.ep && item.up
            );
            const translationCountryData = data?.selectedCountryFullList?.find(
                (item) => item.countryId === null && item.languageId && item.up && !item.ep
            );
            const targetLanguageId =
                translationCountryData?.languageId ||
                data?.languageBasedFeeList?.find((item) => item.isDefault)?.targetLanguageId;
            const languageFee = data?.languageBasedFeeList.find(
                (fee) => fee.targetLanguageId === targetLanguageId
            )?.translationFee;

            if (upCountry?.includeAgencyFee && translationIncluded) {
                setUpAndNationalValidationsFees(serviceIncludedOptions.allFees.id);
                setUpAgencyAndTranslationFees({
                    ...upAgencyAndTranslationFees,
                    agencyFee: upCountryData?.agencyFee || 0,
                    translationFee: translationCountryData?.translationFee || 0
                });
            } else if (upCountry?.includeAgencyFee && !translationIncluded) {
                setUpAndNationalValidationsFees(serviceIncludedOptions.agencyFee.id);
                setUpAgencyAndTranslationFees({
                    ...upAgencyAndTranslationFees,
                    agencyFee: upCountryData?.agencyFee || 0,
                    translationFee: Number(languageFee) || 0
                });
            } else if (!upCountry?.includeAgencyFee && translationIncluded) {
                setUpAndNationalValidationsFees(serviceIncludedOptions.translationFee.id);
                setUpAgencyAndTranslationFees({
                    ...upAgencyAndTranslationFees,
                    agencyFee: data?.upAgencyFee || 0,
                    translationFee: translationCountryData?.translationFee || 0
                });
            }
        }
    };

    const fetchCurrencyList = async () => {
        const data = await summaryService.getCurrencyList();
        setCurrencyList(Array.isArray(data) ? (data as CurrencyResponse[]) : []);
    };

    const handleAddOrRemoveCountries = (): boolean => {
        const selectedCountries = epCountriesList
            .filter((country) => country.isSelected)
            .map((country) => country.countryId);

        const previouslySelectedCountries = epCountriesData?.selectedCountryFullList
            ?.filter((country) => country.countryId)
            .map((country) => country.countryId);

        if (selectedCountries.length !== previouslySelectedCountries?.length) {
            return true;
        }

        const allCountriesMatch = selectedCountries.every((countryId) =>
            previouslySelectedCountries?.includes(countryId)
        );

        return !allCountriesMatch;
    };

    const arrayOfObjectComparison = (a: EpCountryResponseList[], b: EpCountryResponseList[]) => {
        if (a.length !== b.length) return true;

        // Compare only agencyFee, officialFee, translationFee for each country by countryId
        for (const objA of a) {
            const objB = b.find((item) => item.countryId === objA.countryId);
            if (!objB) return true;
            const agencyFeeA =
                objA.serviceIncluded.agencyFee.isSelected || objA.serviceIncluded.allFees.isSelected
                    ? objA.serviceIncluded.agencyFee.value
                    : 0;
            const officialFeeA =
                objA.serviceIncluded.officialFee.isSelected ||
                objA.serviceIncluded.allFees.isSelected
                    ? objA.serviceIncluded.officialFee.value
                    : 0;
            const translationFeeA =
                objA.serviceIncluded.translationFee.isSelected ||
                objA.serviceIncluded.allFees.isSelected
                    ? objA.serviceIncluded.translationFee.value
                    : 0;

            if (
                agencyFeeA !== objB.agencyFee ||
                officialFeeA !== objB.officialFee ||
                translationFeeA !== objB.translationFee
            ) {
                return true; // There is a change
            }
        }
        return false; // No changes
    };

    const onSubmit = async (): Promise<boolean> => {
        if (isSelectedAnyCountry) {
            if (props.orderEditMode?.isOrderEdit) {
                const res = await selectCountryService.orderSaveDraft({
                    isOrderEdit: props.orderEditMode.isOrderEdit,
                    orderId: props.orderEditMode.orderId,
                    draftId: props.orderEditMode.draftId,
                    isEpOrder: props.orderEditMode.isEPOrder,
                    isUPOrder: props.orderEditMode.isUpOrder,
                    isAddOrRemoveCountries: handleAddOrRemoveCountries(),
                    hasOrderCostUpdated: arrayOfObjectComparison(
                        epCountriesList.filter((country) => country.isSelected),
                        epCountriesData?.selectedCountryFullList?.filter(
                            (country) => country.countryId
                        ) ?? []
                    ),
                    noEnglishTranslationRequired
                });

                return !!res;
            } else if (stepperStore.getIsLastStepper(STEPPER_TYPE_ID.SELECT_COUNTRY)) {
                return false;
            } else {
                const redirectTo: string | null = await orderQuoteModuleService.saveDraft(true);
                if (redirectTo) {
                    navigate(redirectTo);
                    return true;
                }
                return false;
            }
        } else {
            showToastMessage({
                type: ToastType.ERROR,
                message: t('SELECT_COUNTRY.ERROR')
            });
            return false;
        }
    };

    useImperativeHandle(ref, () => ({
        onSubmit
    }));

    useEffect(() => {
        toggleLoadingIndicator(true);
        props.orderEditMode
            ? fetchEpCountriesData(selectedCurrencyId)
            : fetchCurrencyList().then(() => {
                  fetchEpCountriesData(selectedCurrencyId);
              });
    }, []);

    useEffect(() => {
        if (
            languageBasedFeeList?.length > 0 &&
            (!selectedTargetLanguageId ||
                !languageBasedFeeList.some(
                    (item) => item.targetLanguageId === selectedTargetLanguageId
                ))
        ) {
            setSelectedTargetLanguageId(
                (storeData?.upTargetLanguage?.targetLanguageId &&
                languageBasedFeeList.some(
                    (item) =>
                        item.targetLanguageId === storeData?.upTargetLanguage?.targetLanguageId
                ) &&
                !isEditMode
                    ? storeData?.upTargetLanguage?.targetLanguageId
                    : 0) ||
                    (isEditMode &&
                        (storeData?.upTargetLanguage?.targetLanguageId ||
                            epCountriesData?.selectedLanguageId)) ||
                    languageBasedFeeList.find((item) => item.isDefault)?.targetLanguageId ||
                    0
            );
        }
    }, [languageBasedFeeList, selectedTargetLanguageId]);

    useEffect(() => {
        const upAndNationalValidationsTranslationFee = () => {
            let translationFeeValue: number;
            if (isEditMode) {
                translationFeeValue = upAgencyAndTranslationFees.translationFeeUpdated
                    ? translationFee
                    : epCountriesList?.some(
                            (item) =>
                                item.isSelected &&
                                (languageBasedFeeList.find(
                                    (fee) => fee.targetLanguageId === selectedTargetLanguageId
                                )?.countryId === item.countryId ||
                                    LANGUAGE_ID.SPANISH === selectedTargetLanguageId ||
                                    LANGUAGE_ID.GERMAN === selectedTargetLanguageId ||
                                    LANGUAGE_ID.ENGLISH === selectedTargetLanguageId) &&
                                !item.isNewRecord &&
                                !item.serviceIncluded.translationFee.translationFeeUpdated
                        )
                      ? upAgencyAndTranslationFees.translationFee
                      : translationFee;
            } else {
                translationFeeValue = translationFee;
            }
            return translationFeeValue;
        };

        const updatedQuoteOrderFormData = {
            ...quoteOrderData?.formData, // keep other forms data
            selectCountryPageForEP: {
                countryList: epCountriesList.map((country) => ({
                    isSelected: country.isSelected,
                    isUpSelected: epCountriesList.some((items) => items.isUp && items.isSelected),
                    data: { ...country, up: country.isUp }
                })),
                selectAllChecked: epCountriesList.every((country) => country.isSelected),
                selectUpCountryChecked: epCountriesList
                    .filter((country) => country.isUp)
                    .every((country) => country.isSelected),
                epTranslationAndValidationData: {
                    ...epCountriesData,
                    epCountryResponseList: epCountriesList,
                    upAndNationalValidationsFeesID: {
                        serviceIncludedId: upAndNationalValidationsFees,
                        agencyFee: upAgencyAndTranslationFees.agencyFee,
                        translationFee: upAndNationalValidationsTranslationFee(),
                        agencyOrOfficialFeeUpdated: isEditMode
                            ? upAgencyAndTranslationFees.agencyOrOfficialFeeUpdated
                            : undefined,
                        translationFeeUpdated: isEditMode
                            ? upAgencyAndTranslationFees.translationFeeUpdated
                            : undefined
                    },
                    upTargetLanguage: {
                        targetLanguageId: selectedTargetLanguageId,
                        translationFee: upAndNationalValidationsTranslationFee(),
                        translationFeeFormula:
                            languageBasedFeeList?.find(
                                (item) => item.targetLanguageId === selectedTargetLanguageId
                            )?.translationFeeFormula ?? null
                    },
                    requestCurrencyId: selectedCurrencyId
                },
                epUpGrandTotal: {
                    epTotal: totalOfSelectedCountries(),
                    upTotal: totalOfUPTargetLanguageAndFees() + totalOfNonUP
                }
            }
        };

        quoteOrderModuleStore.updatePage('formData', updatedQuoteOrderFormData);
        const updatedQuoteOrderData = quoteOrderData;
        const updatedQuoteOrderIsFormValid = {
            ...updatedQuoteOrderData.isFormValid,
            [PATHS.SELECT_COUNTRY]: isSelectedAnyCountry
        };
        quoteOrderModuleStore.updatePage('isFormValid', updatedQuoteOrderIsFormValid);

        if (!hasSelectedEpUp || !hasSelectedEpNonUp) {
            quoteOrderModuleStore.updatePage('flags', {
                ...quoteOrderModuleStore.getData()?.flags,
                isBothDecideLaterDisableApprove: null
            });
        } else {
            quoteOrderModuleStore.updatePage('flags', {
                ...quoteOrderData?.flags,
                isBothDecideLaterDisableApprove:
                    quoteOrderModuleStore.getData()?.formData?.summaryPage?.flags?.isBothDecideLater
            });
        }
    }, [
        epCountriesList,
        isSelectedAnyCountry,
        selectedTargetLanguageId,
        upAndNationalValidationsFees,
        upAgencyAndTranslationFees
    ]);

    useEffect(() => {
        const infoUpdate = {
            ...quoteOrderData?.info,
            requestCurrencyId: selectedCurrencyId
        };
        quoteOrderModuleStore.updatePage('info', infoUpdate);
    }, [selectedCurrencyId]);

    // #region render
    return (
        <div
            className={`p-4 h-full ep-country-data-table ${props.orderEditMode ? 'pt-1 pb-0' : 'py-3 '}`}
            data-testid="EpCountryListing">
            {confirmationPopup.visible && (
                <ConfirmationPopup
                    popupID={'EpCountryListingConfirmationPopup'}
                    onCancel={() =>
                        setConfirmationPopup({
                            ...confirmationPopup,
                            visible: false,
                            taskIDs: ''
                        })
                    }
                    visible={confirmationPopup.visible}
                    headerText={confirmationPopup.header}
                    description={
                        <div className="flex flex-col gap-2">
                            <div>{confirmationPopup.description} </div>
                            <div>{confirmationPopup.taskIDs}</div>
                        </div>
                    }
                    rejectLabel={t('COMMON.CLOSE')}
                    isShowAcceptButton={false}
                />
            )}
            {!props.orderEditMode?.isOrderEdit && (
                <div className="flex items-center">
                    <h4 className="font-semibold">{t('SELECT_EP_COUNTRY.SELECT_COUNTRY')}</h4>
                </div>
            )}
            <div className="flex justify-between h-11">
                <div className="flex items-center gap-1">
                    <div className="text-base font-medium flex items-center gap-2 w-40">
                        <Checkbox
                            disabled={
                                props.orderEditMode?.isOrderEdit && props.orderEditMode?.isUpOrder
                            }
                            data-testid={`checkbox-all-countries`}
                            checked={
                                epCountriesList.length > 0 &&
                                (props.orderEditMode?.isOrderEdit && !props.orderEditMode?.isEPOrder
                                    ? epCountriesList
                                          .filter((country) => !country.isUp)
                                          .every((country) => country.isSelected)
                                    : epCountriesList.every((country) => country.isSelected))
                            }
                            onChange={(e) => handleSelectAll(e.checked ?? false)}
                        />
                        {t('SELECT_EP_COUNTRY.ALL_COUNTRIES')}
                        {isSelectedAnyCountry && (
                            <span
                                className="font-semibold text-primary"
                                data-testid={`selected-all-countries-count`}>
                                ({epCountriesList.filter((country) => country.isSelected).length})
                            </span>
                        )}
                    </div>
                    <div className="text-base font-medium flex items-center gap-2 w-[8.5rem]">
                        <Checkbox
                            data-testid={`checkbox-up-countries`}
                            disabled={
                                props.orderEditMode?.isOrderEdit && !props.orderEditMode?.isEPOrder
                                    ? true
                                    : undefined
                            }
                            checked={
                                epCountriesList.length > 0 &&
                                epCountriesList
                                    .filter((country) => country.isUp)
                                    .every((country) => country.isSelected)
                            }
                            onChange={(e) => {
                                handleIsUPOnly(e.checked ?? false);
                            }}
                        />
                        {t('SELECT_EP_COUNTRY.IS_UP_ONLY')}
                        {isSelectedAnyUPCountry && (
                            <span
                                className="font-semibold text-primary"
                                data-testid={`selected-up-countries-count`}>
                                (
                                {
                                    epCountriesList.filter(
                                        (country) => country.isUp && country.isSelected
                                    ).length
                                }
                                )
                            </span>
                        )}
                    </div>
                    {props?.orderEditMode?.isNoEnglishTranslation && (
                        <div className="text-base font-medium flex items-center gap-2 border-l-2 pl-3">
                            <Checkbox
                                key={'englishFeeCheckbox'}
                                checked={noEnglishTranslationRequired}
                                onChange={(e) =>
                                    setNoEnglishTranslationRequired(e.checked ?? false)
                                }
                            />
                            {t('SUMMARY.ENGLISH_TRANSLATION_REQUIRED')}
                        </div>
                    )}
                </div>
                {props.orderEditMode?.isOrderEdit &&
                    props.orderEditMode?.isEPOrder === false &&
                    props.orderEditMode?.isUpOrder &&
                    (props.orderEditMode?.hasOrderCostUpdated === true ||
                        isUpLanguageAndFeesModified) && (
                        <div data-testid="upPatentWarningLabel" className="mt-2">
                            <span
                                className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1
                                  bg-orange-50 border-2 rounded-md border-orange-100">
                                <i className="pi pi-info-circle text-yellow-500 mt-px"></i>
                                <span className="md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                                    {t(
                                        'SELECT_EP_COUNTRY.CHECK_ASSOCIATED_NON_UP_CASE_FOR_UPDATES'
                                    )}
                                </span>
                            </span>
                        </div>
                    )}
                {props.orderEditMode?.isOrderEdit &&
                    props.orderEditMode?.isEPOrder === false &&
                    !props.orderEditMode?.isUpOrder &&
                    (props.orderEditMode?.hasOrderCostUpdated === true ||
                        isNonUpCountryRecordsModified) && (
                        <div data-testid="nonUpPatentWarningLabel" className="mt-2">
                            <span
                                className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1
                                  bg-orange-50 border-2 rounded-md border-orange-100">
                                <i className="pi pi-info-circle text-yellow-500 mt-px"></i>
                                <span className="md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                                    {t('SELECT_EP_COUNTRY.CHECK_ASSOCIATED_UP_CASE_FOR_UPDATES')}
                                </span>
                            </span>
                        </div>
                    )}

                {!props.orderEditMode?.isOrderEdit && (
                    <div>
                        <Dropdown
                            data-testid={`dropdown-currency`}
                            value={selectedCurrencyId}
                            pt={{
                                ...dropDownStyle,
                                root: {
                                    className: dropDownStyle.root.className + ' md:w-24 h-8'
                                },
                                input: {
                                    className: dropDownStyle.input.className + ' font-semibold'
                                }
                            }}
                            optionValue="currencyId"
                            optionLabel="currencyCode"
                            options={currencyList}
                            onChange={(e) => {
                                setSelectedCurrencyId(Number(e.value));
                                fetchEpCountriesData(Number(e.value), true);
                            }}
                        />
                    </div>
                )}
            </div>
            <div>
                <EpCountryDataTable
                    tableData={generateTableData(epCountriesList)}
                    handleCountrySelection={(...args) => {
                        void handleCountrySelection(...args);
                    }}
                    handleSelectAll={handleSelectAll}
                    currencySymbol={epCountriesData?.currencySymbol || ''}
                    orderCountryEdit={{
                        isOrderEdit: props.orderEditMode?.isOrderEdit ?? false,
                        isUPOrder: props.orderEditMode?.isUpOrder ?? false,
                        isEPOrder: props.orderEditMode?.isEPOrder ?? false,
                        sourceLanguage: props.orderEditMode?.sourceLanguage || ''
                    }}
                    isAITranslationAvailable={
                        epCountriesData?.isAITranslationAvailable
                            ? epCountriesList.some(
                                  (country) =>
                                      country.isAiTranslationConfiguration && country.isSelected
                              )
                            : false
                    }
                />
            </div>
            <div
                className="my-3 h-[5.5rem] rounded w-full flex"
                data-testid={`up-national-validations`}>
                <div className="4xl:w-[79%] w-full bg-primary/5 border-2 border-r-0 border-primary/20 rounded-l py-2 pl-3 pr-0 h-full">
                    <div className="border-r-2 border-neutral-100 h-full">
                        <h5 className="font-medium flex items-center max-2xl:text-[1.05rem]">
                            {t('SELECT_EP_COUNTRY.UP_NATIONAL_VALIDATIONS')}
                            <Tooltip
                                target=".upNationalValidationInfo"
                                position="top"
                                pt={tooltipStyle}
                            />
                            <i
                                className="pi pi-info-circle text-sm text-black/60 ml-1 pt-0.5 upNationalValidationInfo"
                                data-pr-tooltip={t('SELECT_EP_COUNTRY.UP_NATIONAL_VALIDATION_INFO')}
                            />
                        </h5>
                        <div className="flex justify-between items-start mt-1.5 mr-4">
                            <div className="flex items-center justify-between gap-3">
                                <h6 className="bg-soft-blue/50 w-fit px-1 rounded text-primary font-medium">
                                    {t('COMMON.UP')}
                                </h6>
                                <div className="flex items-center gap-2">
                                    <p>{t('SELECT_EP_COUNTRY.UP_TARGET_LANGUAGE')}</p>
                                    <Dropdown
                                        data-testid={`dropdown-target-language`}
                                        disabled={!isSelectedAnyUPCountry}
                                        value={
                                            isSelectedAnyUPCountry
                                                ? selectedTargetLanguageId
                                                : undefined
                                        }
                                        placeholder={t('COMMON.SELECT')}
                                        filter
                                        filterPlaceholder={t('COMMON.SEARCH')}
                                        pt={{
                                            ...dropDownStyle,
                                            root: {
                                                className:
                                                    dropDownStyle.root.className +
                                                    ' md:w-[11.3rem] h-7 pl-3' +
                                                    (isSelectedAnyUPCountry
                                                        ? ''
                                                        : ' hover:border-neutral-100')
                                            }
                                        }}
                                        optionLabel="targetLanguageName"
                                        optionValue="targetLanguageId"
                                        options={languageBasedFeeList}
                                        onChange={(e) => {
                                            if (e.value === null) return;
                                            setUpAgencyAndTranslationFees({
                                                ...upAgencyAndTranslationFees,
                                                translationFeeUpdated: true
                                            });
                                            setSelectedTargetLanguageId(Number(e.value));
                                        }}
                                        onKeyUp={(e) => {
                                            if (e.key === 'Enter') {
                                                const li = e.target as HTMLElement;
                                                const selectedValue =
                                                    li.getAttribute('data-pc-section') === 'item'
                                                        ? li.getAttribute('aria-label')
                                                        : null;

                                                if (selectedValue) {
                                                    const matchedOption = Object.values(
                                                        languageBasedFeeList
                                                    ).find((opt) =>
                                                        opt.targetLanguageName.includes(
                                                            selectedValue
                                                        )
                                                    );
                                                    if (matchedOption) {
                                                        setUpAgencyAndTranslationFees({
                                                            ...upAgencyAndTranslationFees,
                                                            translationFeeUpdated: true
                                                        });
                                                        setSelectedTargetLanguageId(
                                                            matchedOption.targetLanguageId
                                                        );
                                                    }
                                                }
                                            }
                                        }}
                                    />
                                    <Tooltip
                                        target=".targetLanguageInfo"
                                        position="bottom"
                                        pt={tooltipStyle}
                                    />
                                    <i
                                        className="pi pi-info-circle text-sm text-black/60  targetLanguageInfo"
                                        data-pr-tooltip={t(
                                            'SELECT_EP_COUNTRY.TARGET_COUNTRY_TOOLTIP'
                                        )}
                                    />
                                </div>
                                <div className="flex items-center gap-2">
                                    <p>{t('COMMON.FEES')}</p>
                                    {
                                        <Dropdown
                                            data-testid={`dropdown-fees`}
                                            disabled={!isSelectedAnyUPCountry}
                                            appendTo={'self'}
                                            pt={{
                                                ...dropDownStyle,
                                                root: {
                                                    className:
                                                        dropDownStyle.root.className +
                                                        ' md:w-44 h-7 pl-3' +
                                                        (isSelectedAnyUPCountry
                                                            ? ''
                                                            : ' hover:border-neutral-100')
                                                },
                                                wrapper: {
                                                    className: '!w-44'
                                                },
                                                item: {
                                                    className:
                                                        dropDownStyle.item.className + ' py-1'
                                                }
                                            }}
                                            value={upAndNationalValidationsFees}
                                            valueTemplate={
                                                isSelectedAnyUPCountry
                                                    ? labelTemplate
                                                    : t('COMMON.SELECT')
                                            }
                                            defaultValue={'allFees'}
                                            optionLabel="label"
                                            optionValue="id"
                                            options={Object.values(serviceIncludedOptions).filter(
                                                (option) =>
                                                    option.id !==
                                                        serviceIncludedOptions.agencyAndOfficialFee
                                                            ?.id &&
                                                    option.id !==
                                                        serviceIncludedOptions.officialFee?.id
                                            )}
                                            onChange={(e) => {
                                                if (e.value === null) return;
                                                setUpAndNationalValidationsFees(Number(e.value));
                                                if (
                                                    e.value === serviceIncludedOptions.agencyFee.id
                                                ) {
                                                    setUpAgencyAndTranslationFees({
                                                        ...upAgencyAndTranslationFees,
                                                        translationFeeUpdated: true
                                                    });
                                                } else if (
                                                    e.value ===
                                                    serviceIncludedOptions.translationFee.id
                                                ) {
                                                    setUpAgencyAndTranslationFees({
                                                        ...upAgencyAndTranslationFees,
                                                        agencyOrOfficialFeeUpdated: true
                                                    });
                                                }
                                            }}
                                            onKeyUp={(e) => {
                                                if (e.key === 'Enter') {
                                                    const li = e.target as HTMLElement;
                                                    const selectedValue =
                                                        li.getAttribute('data-pc-section') ===
                                                        'item'
                                                            ? li.getAttribute('aria-label')
                                                            : null;

                                                    if (selectedValue) {
                                                        const matchedOption = Object.values(
                                                            serviceIncludedOptions
                                                        ).find((opt) =>
                                                            opt.label.includes(selectedValue)
                                                        );
                                                        if (matchedOption) {
                                                            setUpAndNationalValidationsFees(
                                                                matchedOption.id
                                                            );
                                                            if (
                                                                matchedOption.id ===
                                                                serviceIncludedOptions.agencyFee.id
                                                            ) {
                                                                setUpAgencyAndTranslationFees({
                                                                    ...upAgencyAndTranslationFees,
                                                                    translationFeeUpdated: true
                                                                });
                                                            } else if (
                                                                matchedOption.id ===
                                                                serviceIncludedOptions
                                                                    .translationFee.id
                                                            ) {
                                                                setUpAgencyAndTranslationFees({
                                                                    ...upAgencyAndTranslationFees,
                                                                    agencyOrOfficialFeeUpdated: true
                                                                });
                                                            }
                                                        }
                                                    }
                                                }
                                            }}
                                            itemTemplate={labelTemplate}
                                        />
                                    }
                                </div>
                                <p
                                    data-testid={`up-national-validations-fees`}
                                    key={selectedTargetLanguageId}>
                                    {selectedCurrency(
                                        currencySymbol,
                                        isSelectedAnyUPCountry
                                            ? totalOfUPTargetLanguageAndFees()
                                            : 0
                                    )}
                                </p>
                            </div>

                            <div className="flex items-center gap-1.5">
                                <h6 className="bg-warning-50 text-warning-800 border border-warning-200/30 w-fit px-1 rounded font-medium">
                                    {t('COMMON.NON_UP')}
                                </h6>
                                <p
                                    className="w-20 text-right whitespace-nowrap min-w-fit"
                                    data-testid={`non-up-total`}>
                                    {selectedCurrency(
                                        currencySymbol,
                                        isSelectedAnyUPCountry ? totalOfNonUP : 0
                                    )}
                                </p>
                            </div>
                            <div className="flex items-center gap-1.5 ">
                                <h4 className="leading-6">{t('COMMON.TOTAL')}</h4>
                                <h5
                                    className="font-semibold leading-none w-24 text-right whitespace-nowrap min-w-fit"
                                    data-testid={`up-national-validations-total`}>
                                    {selectedCurrency(
                                        currencySymbol,
                                        isSelectedAnyUPCountry
                                            ? totalOfUPTargetLanguageAndFees() + totalOfNonUP
                                            : 0
                                    )}
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="w-[21%] bg-cream-yellow/50 border-2 border-l-0 border-warning-800/30 rounded-r p-2">
                    <div className="mr-5">
                        <h5 className="font-medium max-2xl:text-[1.05rem]">
                            {t('SELECT_EP_COUNTRY.NATIONAL_VALIDATIONS')}
                        </h5>
                        <div className="flex gap-3 items-center justify-end mt-1.5">
                            <h4 className="leading-6">{t('COMMON.TOTAL')}</h4>
                            <h5
                                className="font-semibold leading-none"
                                data-testid={`ep-country-total`}>
                                {selectedCurrency(currencySymbol, totalOfSelectedCountries())}
                            </h5>
                        </div>
                    </div>
                </div>
            </div>

            {/* submit */}
            <button
                className="hidden"
                type="button"
                id={`submit-${PATHS.SELECT_COUNTRY}`}
                onClick={() => {
                    onSubmit();
                }}
                data-testid={`submit-${PATHS.SELECT_COUNTRY}`}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
            />
        </div>
    );
});
export default EpCountryListing;
