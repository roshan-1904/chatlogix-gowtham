import { customTableStyle } from 'constants/styles.constant';
import { t } from 'i18next';
import { Column } from 'primereact/column';
import {
    DataTable,
    DataTableDataSelectableEvent,
    DataTableSelectionMultipleChangeEvent
} from 'primereact/datatable';
import { EpCountryListingColumnSchema, EpCountryResponseList } from '../types/country.type';
import { EPO_STATE, selectedCurrency } from '../constants/country.constant';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { Tooltip } from 'primereact/tooltip';
import { SOURCE_LANGUAGES } from 'constants/app.constant';
import TranslationFeeInfoTooltipOverlayPanel from 'pages/createOrderAndQuote/components/summary/components/TranslationFeeInfoTooltipOverlayPanel';

interface EpCountryDataTableProps {
    tableData: EpCountryResponseList[];
    handleCountrySelection: (selectedCountries: EpCountryResponseList[], checked: boolean) => void;
    handleSelectAll: (selectAll: boolean) => void;
    currencySymbol: string;
    orderCountryEdit?: {
        isOrderEdit: boolean;
        isUPOrder: boolean;
        isEPOrder: boolean;
        sourceLanguage?: string;
    };
    isAITranslationAvailable?: boolean;
}

const EpCountryDataTable = ({
    tableData,
    handleCountrySelection,
    handleSelectAll,
    currencySymbol,
    orderCountryEdit,
    isAITranslationAvailable
}: EpCountryDataTableProps) => {
    const isHide = 'opacity-0 pointer-events-none';
    const isEditMode = quoteOrderModuleStore.getData()?.info?.isEditFlow || false;
    const isEnglishSourceLanguage = orderCountryEdit?.isOrderEdit
        ? orderCountryEdit?.sourceLanguage?.toUpperCase() === SOURCE_LANGUAGES.ENGLISH
        : quoteOrderModuleStore
              .getData()
              ?.formData?.companyDetailsPage?.patentDetails?.sourceLanguageName?.toUpperCase() ===
          SOURCE_LANGUAGES.ENGLISH;
    let columnNumber = 1;
    const columnSchema: EpCountryListingColumnSchema[] = [
        {
            field: 'countryNameTemplate',
            header: t('SELECT_EP_COUNTRY.COUNTRY'),
            columnNumber: columnNumber++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left',
            cellStyle: 'text-left'
        },
        {
            field: 'agencyFee',
            header: t('SELECT_EP_COUNTRY.AGENCY_FEE'),
            columnNumber: columnNumber++,
            visibility: true,
            body(rowData: {
                agencyFee: number;
                isSelected: boolean;
                serviceIncluded: EpCountryResponseList['serviceIncluded'];
                isNewRecord?: boolean;
            }) {
                let feeValue = 0;
                if (
                    rowData.serviceIncluded.agencyAndOfficialFee.isSelected ||
                    rowData.serviceIncluded.allFees.isSelected
                ) {
                    feeValue =
                        isEditMode && !rowData.isNewRecord
                            ? rowData.serviceIncluded.agencyFee.value
                            : rowData.agencyFee;
                }
                return (
                    <span
                        className={
                            rowData.isSelected && !orderCountryEdit?.isUPOrder ? '' : isHide
                        }>
                        {selectedCurrency(currencySymbol, feeValue)}
                    </span>
                );
            }
        },
        {
            field: 'officialFee',
            header: t('SELECT_EP_COUNTRY.OFFICIAL_FEE'),
            columnNumber: columnNumber++,
            visibility: true,
            body(rowData: {
                officialFee: number;
                isSelected: boolean;
                serviceIncluded: EpCountryResponseList['serviceIncluded'];
                isNewRecord?: boolean;
            }) {
                let feeValue = 0;
                if (
                    rowData.serviceIncluded.agencyAndOfficialFee.isSelected ||
                    rowData.serviceIncluded.allFees.isSelected
                ) {
                    feeValue =
                        isEditMode && !rowData.isNewRecord
                            ? rowData.serviceIncluded.officialFee.value
                            : rowData.officialFee;
                }
                return (
                    <span
                        className={
                            rowData.isSelected && !orderCountryEdit?.isUPOrder ? '' : isHide
                        }>
                        {selectedCurrency(currencySymbol, feeValue)}
                    </span>
                );
            }
        },
        {
            field: 'translationFee',
            header: (
                <div className="flex items-center gap-2">
                    {t('SELECT_EP_COUNTRY.TRANSLATION_FEE')}{' '}
                    <div className="w-4">
                        <TranslationFeeInfoTooltipOverlayPanel
                            isHideTitle
                            iconCustomStyle={'pt-0.5'}
                            isAITranslationAvailable={
                                isAITranslationAvailable && !orderCountryEdit?.isUPOrder
                            }
                        />
                    </div>
                </div>
            ),
            columnNumber: columnNumber++,
            visibility: true,
            body: (rowData: { translationFeeTemplate: JSX.Element; isSelected: boolean }) => (
                <span
                    className={
                        'w-fit ' +
                        (rowData.isSelected && !orderCountryEdit?.isUPOrder ? '' : isHide)
                    }>
                    {rowData.translationFeeTemplate}
                </span>
            )
        },
        {
            field: 'totalIncludedFees',
            header: t('SELECT_EP_COUNTRY.TOTAL_NATIONAL_VALIDATION_ONLY'),
            columnNumber: columnNumber++,
            visibility: true,
            cellStyle: '!w-32',
            body: (rowData: { totalIncludedFees: number; isSelected: boolean }) => (
                <span
                    className={
                        'font-medium ' +
                        (rowData.isSelected && !orderCountryEdit?.isUPOrder ? '' : isHide)
                    }>
                    {selectedCurrency(currencySymbol, rowData.totalIncludedFees)}
                </span>
            )
        },
        {
            field: 'includedFeesTemplate',
            header: t('SELECT_EP_COUNTRY.SERVICES_INCLUDED'),
            columnNumber: columnNumber++,
            visibility: true,
            cellStyle: '!w-60',
            body: (rowData: { includedFeesTemplate: string; isSelected: boolean }) => (
                <span
                    className={
                        'w-fit ' +
                        (rowData.isSelected && !orderCountryEdit?.isUPOrder ? '' : isHide)
                    }>
                    {rowData.includedFeesTemplate}
                </span>
            )
        }
    ];

    const headerTemplate = (rowData: EpCountryResponseList) => {
        let translatedText = '';

        switch (rowData?.epoState) {
            case EPO_STATE.DESIGNATED_CONTRACTING_STATES:
                translatedText = t('SELECT_EP_COUNTRY.DESIGNATED_CONTRACTING_STATES');
                break;
            case EPO_STATE.VALIDATION_STATES:
                translatedText = t('SELECT_EP_COUNTRY.VALIDATION_STATES');
                break;
            case EPO_STATE.EXTENSION_STATES:
                translatedText = t('SELECT_EP_COUNTRY.EXTENSION_STATES');
                break;
            default:
                translatedText = t('COMMON.NOT_FOUND');
                break;
        }

        return (
            <div className="flex align-items-center bg-neutral-100/50 p-3 pl-16 font-medium text-[1.06rem]">
                {translatedText}
                {rowData?.epoState === EPO_STATE.DESIGNATED_CONTRACTING_STATES &&
                    !isEnglishSourceLanguage && (
                        <>
                            <div id="epTranslationDiscountTooltipMessage" className="ml-2 mt-0.5">
                                <span className="pi pi-info-circle text-primary font-semibold"></span>
                            </div>
                            <Tooltip
                                position="right"
                                target={'#epTranslationDiscountTooltipMessage'}
                                content={t(
                                    'SELECT_EP_COUNTRY.UP_TRANSLATION_DISCOUNT_SCENARIO_TOOLTIP'
                                )}></Tooltip>
                        </>
                    )}
            </div>
        );
    };
    const isRowSelectable = (event: DataTableDataSelectableEvent): boolean | null => {
        if (!event.data) {
            return null;
        }
        let result: boolean | null;
        if (orderCountryEdit?.isUPOrder) {
            result = false;
        } else {
            result = event.data.isUp === null || event.data.isUp === false;
        }
        return result;
    };

    return (
        <div className="tableComponent">
            <DataTable
                selectionMode={'checkbox'}
                selection={tableData.filter((country) => country.isSelected)}
                onSelectionChange={(
                    e: DataTableSelectionMultipleChangeEvent<EpCountryResponseList[]>
                ) => {
                    const checked = e.originalEvent?.target
                        ? (e.originalEvent.target as HTMLInputElement).checked
                        : false;
                    handleCountrySelection(e.value, checked);
                }}
                onSelectAllChange={(e) => handleSelectAll(e.checked)}
                selectAll={tableData.every((country) => country.isSelected) ?? false}
                value={tableData}
                data-testid="CountryListingEP"
                rowGroupMode="subheader"
                groupRowsBy="epoState"
                rowGroupHeaderTemplate={headerTemplate}
                sortField="epoState"
                sortMode="single"
                sortOrder={1}
                onSort={(e) => e}
                scrollable
                scrollHeight="70px"
                className="p-0"
                isDataSelectable={
                    orderCountryEdit?.isOrderEdit && !orderCountryEdit?.isEPOrder
                        ? isRowSelectable
                        : undefined
                }
                pt={customTableStyle(true)}>
                <Column selectionMode="multiple" headerStyle={{ width: '2rem' }}></Column>
                {columnSchema.map((col, index) => (
                    <Column
                        data-testid={`ep-country-data-table-column-${index + 1}`}
                        key={index + 1}
                        field={col.field}
                        header={col.header}
                        sortable={col.sortable}
                        body={col.body}
                        pt={{
                            bodyCell: {
                                className:
                                    'text-black text-right' +
                                    (col.cellStyle ? ` ${col.cellStyle}` : '')
                            },
                            headerContent: {
                                className: 'justify-center'
                            },
                            headerTitle: {
                                className: 'font-medium text-black/70 text-lg'
                            }
                        }}></Column>
                ))}
            </DataTable>
        </div>
    );
};
export default EpCountryDataTable;
