export type SelectCountryData = {
    id: number;
    name: string;
    code: string;
    concatCode: string;
    iconName: string;
    languageId: number | null;
    wipoEntitySize: number[] | [];
    pcEntitySize: number[] | [];
    otherEntitySize?: null;
    wipoIq: number; // PCT
    epoState: number | null; // EP
    pcIq: number | null; // PC
    otherIq?: null; // Others
    up: boolean | null; // flag for UP in EP-Flow
};

export type CountryConfig = {
    isSelected: boolean;
    isUpSelected: boolean;
    selectedWipoEntityId?: number | null;
    data: SelectCountryData;
    epTranslationAndValidationData?: EpCountryResponseList;
};

export type CountryEntityType = {
    [key: number]: { id: number; name: string; code: string };
};

export type CountryDataForPostAPI = {
    countryId: number | null;
    languageId: number | null;
    entityType?: number | null;
    EP?: boolean | null;
    UP?: boolean | null;
    isClaim?: boolean;
    agencyFee: number | null;
    officialFee: number | null;
    translationFee: number | null;
    total: number | null;
    isCustomCountry?: boolean;
    isUserPreferredAiTranslation?: boolean | null;
};

export type SelectCountryDatasetForEdit = {
    instantCountries: SelectCountryDataForEdit[];
    customCountries: SelectCountryDataForEdit[];
    epCountries: SelectCountryDataForEdit[];
    // selectCountryPageForEP: SelectCountryDataForEdit[];
};

export type SelectCountryDataForEdit = {
    countryId: number;
    isInstantQuote?: boolean | null;
    languageId?: number | null;
    countryName?: string | null;
    languageName?: string | null;
    entityType?: number | null;
    total?: number;
    ep?: boolean | null;
    up?: boolean | null;
    isprimary?: boolean | null;
    isCustomCountry?: boolean | null;
    isClaim?: boolean | null;
    agencyFee?: number | null;
    officialFee?: number | null;
    translationFee?: number | null;
};

export interface EpCountriesData {
    epCountryResponseList: EpCountryResponseList[];
    languageBasedFeeList: LanguageBasedFeeList[];
    currencySymbol: string;
    selectedCountryList: EpCountryResponseList[];
    selectedLanguageId?: number;
    selectedCountryFullList?: EpCountryResponseList[];
    upAgencyFee: number;
    noEnglishTranslationRequired: boolean;
    epUpGrandTotal?: {
        claimsTotal: number;
        epTotal: number;
        upTotal: number;
    };
    upAndNationalValidationsFeesID?: {
        serviceIncludedId: number;
        agencyFee: number;
        translationFee: number;
        agencyOrOfficialFeeUpdated?: boolean;
        translationFeeUpdated?: boolean;
        selectedListTranslationFeeFormula?: string;
    };
    upTargetLanguage?: {
        targetLanguageId: number;
        translationFee: number;
        translationFeeFormula: string;
    };
    requestCurrencyId?: number;
    isAITranslationAvailable: boolean;
}

export interface EpCountryResponseList {
    id: number;
    countryId: number;
    languageId: number;
    requestCurrencyId: number;
    countryName: string;
    countryNameTemplate: JSX.Element;
    concatCode: string;
    countryCode: string;
    iconName: string;
    latitude: string;
    longitude: string;
    groupId?: number;
    epoState: number;
    wipoEntitySize: any[];
    agencyFee: number;
    officialFee: number;
    translationFee: number;
    groupedCountryTranslationFee: number;
    groupedCountrySelectedListTranslationFee: {
        hasSelectedList: boolean;
        translationFee?: number;
    };
    translationRate: number;
    agencyFeeFormula: string;
    officialFeeFormula: string;
    translationFeeFormula: string;
    selectedListAgencyFeeFormula?: string;
    selectedListOfficialFeeFormula?: string;
    selectedListTranslationFeeFormula?: string;
    isUp?: boolean;
    isEp?: boolean;
    up?: boolean;
    ep?: boolean;
    isUpCompatible?: boolean;
    totalIncludedFees?: number;
    serviceIncluded: {
        allFees: ServiceFeesProps;
        agencyAndOfficialFee: ServiceFeesProps;
        translationFee: ServiceFeesProps;
        agencyFee: ServiceFeesProps;
        officialFee: ServiceFeesProps;
    };
    includedFeesTemplate: JSX.Element;
    translationFeeTemplate: JSX.Element;
    isSelected: boolean;
    isPrimaryDisplay: boolean | null;
    isNewRecord?: boolean;
    agencyOrOfficialFeeUpdated?: boolean;
    translationFeeUpdated?: boolean;
    aiHtTranslationToggleUpdated?: boolean;
    includeAgencyFee: boolean;
    includeOfficialFee: boolean;
    includeTranslationFee: boolean;
    includeInSelectedCountry?: boolean;
    isAiTranslationConfiguration: boolean;
    selectedListIsAiTranslationConfiguration?: boolean;
    isUserPreferredAiTranslation: boolean;
    aiTranslationFee: number;
    translationFormulaFee: number;
    isUserPreferredAiTranslationUpdated: boolean;
    isEnglishTranslationRequired: boolean;
}
export interface EpCountryListingColumnSchema {
    field: string;
    header: string | React.ReactNode;
    columnNumber: number;
    visibility: boolean;
    frozen?: boolean;
    body?: ((data: any, options: any) => React.ReactNode) | React.FC<unknown>;
    alignFrozen?: 'left' | 'right' | undefined;
    cellStyle?: string;
    sortable?: boolean;
}

export interface ServiceFeesProps {
    id: number;
    label: string;
    value: number;
    isSelected: boolean;
    isDisabled?: boolean;
    agencyOrOfficialFeeUpdated?: boolean;
    translationFeeUpdated?: boolean;
}

export interface LanguageBasedFeeList {
    countryId?: number;
    sourceLanguageId: number;
    targetLanguageId: number;
    targetLanguageName: string;
    languageFee: any;
    translationFee?: string;
    translationRate?: number;
    translationFeeFormula?: string;
    total?: string;
    isClaim: boolean;
    isDefault: boolean;
}
