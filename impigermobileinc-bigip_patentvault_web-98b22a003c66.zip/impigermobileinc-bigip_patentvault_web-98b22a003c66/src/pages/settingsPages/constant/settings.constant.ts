export enum PAGE_TYPE {
    BILLING_TERMS = '/BillingTerms',
    TASKS = '/Abilities',
    REQUEST_CURRENCIES = '/RequestCurrencies',
    VENDOR_CURRENCIES = '/VendorCurrencies',
    LANGUAGES = '/Languages',
    PAYMENT_METHODS = '/PaymentMethods',
    IP_INSTRUCTION_DEADLINES = '/IPInstructionDeadlines',
    UNITS = '/Units',
    TAX_FORMS = '/TaxForms',
    CURRENCY_EXCHANGES = '/CurrencyExchanges',
    BREAKDOWNS = '/Breakdowns',
    RATE_LABELS = '/RateLabels'
}
