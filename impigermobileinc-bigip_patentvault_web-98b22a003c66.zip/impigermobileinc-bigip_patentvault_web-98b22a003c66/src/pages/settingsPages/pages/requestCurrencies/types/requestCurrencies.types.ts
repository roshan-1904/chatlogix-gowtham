export interface RequestCurrencySchema {
    id: number;
    formName: string;
    schema: string;
}

export interface RequestCurrencyDataItem {
    name: string;
    isoCode: string;
    currencySymbol: string;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
    currencyId: number;
    concatNameCode: string;
}

export interface GetRequestCurrencyResponse {
    data: RequestCurrencyDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
export interface CreateRequestCurrencyData {
    currencyId: number;
    id?: number;
}
