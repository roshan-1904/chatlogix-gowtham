import { render, fireEvent } from '@testing-library/react';
import CreateRequestCurrencyPopup from '../requestCurrencyPopup';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('CreateRequestCurrencyPopup', () => {
    test('renders with default props', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateRequestCurrencyPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Assert that the title reflects the default value of isFromEdit
        expect(getByText('COMMON.CREATE_REQUEST_CURRENCY')).toBeInTheDocument();
    });

    test('renders with isFromEdit set to true', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateRequestCurrencyPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={true}
            />
        );

        expect(
            getByText('SETTING_PAGES.REQUEST_CURRENCIES.UPDATE_REQUEST_CURRENCIES')
        ).toBeInTheDocument();
        expect(getByText('COMMON.UPDATE')).toBeInTheDocument();
        expect(getByText('COMMON.CANCEL')).toBeInTheDocument();
    });

    test('renders with isFromEdit set to false', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateRequestCurrencyPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={false}
            />
        );

        expect(getByText('COMMON.CREATE_REQUEST_CURRENCY')).toBeInTheDocument();
        expect(getByText('COMMON.CREATE')).toBeInTheDocument();
        expect(getByText('COMMON.RESET')).toBeInTheDocument();
    });

    test('calls onChangeCreateAnother function when user chooses to create another item', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateRequestCurrencyPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        fireEvent.click(getByText('COMMON.CREATE_ANOTHER'));

        expect(onChangeCreateAnother).toHaveBeenCalled();
    });

    // Add more test cases as needed
});
