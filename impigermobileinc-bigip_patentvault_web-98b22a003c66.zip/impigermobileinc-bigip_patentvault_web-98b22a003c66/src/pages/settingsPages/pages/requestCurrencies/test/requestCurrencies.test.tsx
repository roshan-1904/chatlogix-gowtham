import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import RequestCurrenciesPage from '../requestCurrencies';
import SettingsService from '../../../service/settings.service';

// Mock SettingsService functions
jest.mock('../../../service/settings.service');

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('RequestCurrenciesPage Component', () => {
    beforeEach(() => {
        // Reset mock implementation before each test
        jest.clearAllMocks();
    });

    test('renders correctly with initial data', () => {
        render(<RequestCurrenciesPage />);
        // Add assertions to ensure that the component renders without crashing
    });

    test('fetches table schema on mount', async () => {
        const mockTableSchema = [
            {
                field: 'id',
                header: 'ID',
                sortable: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 0,
                visibility: true
            },
            {
                field: 'name',
                header: 'Name',
                sortable: true,
                filter: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 1,
                visibility: true
            }
        ];

        // Mock the resolved value for SettingsService function
        const mockedSettingsService = SettingsService as jest.Mocked<typeof SettingsService>;
        mockedSettingsService.getTableColumnDefinition.mockResolvedValue({
            schema: JSON.stringify(mockTableSchema)
        });

        render(<RequestCurrenciesPage />);

        // Wait for API call to resolve
        await waitFor(() => {
            // Add assertions to verify that the function is called and data is fetched
            expect(mockedSettingsService.getTableColumnDefinition).toHaveBeenCalledTimes(1);
        });
    });

    test('Check the export button click', () => {
        render(<RequestCurrenciesPage />);
        const exportButton = screen.getByTestId('export-list-button');
        expect(exportButton).toBeDefined();
        fireEvent.click(exportButton);
    });

    // test('clicking on create button opens modal', async () => {
    //     const { getByText } = render(<RequestCurrenciesPage />);
    //     const createButton = getByText('Create Request Currency');
    //     fireEvent.click(createButton);
    //     await waitFor(() => {
    //         // Add assertions for expected behavior
    //     });
    // });

    // Add more tests to cover other functionalities such as event handlers, API calls, and rendering logic
});
