import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { TABLE_POP_IDS, DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';

import { useEffect, useState } from 'react';
import { PAGE_TYPE } from '../../constant/settings.constant';
import SettingsService from '../../service/settings.service';
import {
    RequestCurrencyDataItem,
    RequestCurrencySchema,
    GetRequestCurrencyResponse,
    CreateRequestCurrencyData
} from './types/requestCurrencies.types';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import CreateRequestCurrencyPopup from './requestCurrencyPopup';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import tableSchema from './data/requestCurrenciesTableSchema.json';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { Permissions } from 'constants/permissions';
function RequestCurrenciesPage() {
    const { t } = useTranslation();

    const [columnSchema] = useState<ColumnDefinition[]>(tableSchema as ColumnDefinition[]);
    const [toggleRowData, setToggleRowData] = useState<RequestCurrencyDataItem>();
    const [isEditMode, setIsEditMode] = useState(false);
    const [tableData, setTableData] = useState<RequestCurrencyDataItem[]>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.REQUEST_CURRENCIES_ORDERS;
    const [showModal, setShowModal] = useState(false);

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [createAnother, setCreateAnother] = useState(false);
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        create: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.CREATE_MESSAGE.SUCCESS_MESSAGE')
        },
        update: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.UPDATE_MESSAGE.SUCCESS_MESSAGE')
        },
        markActive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.MARK_ACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.MARK_ACTIVE.ERROR_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.MARK_INACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.REQUEST_CURRENCIES.MARK_INACTIVE.ERROR_MESSAGE')
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const emptyMessage = t('SETTING_PAGES.REQUEST_CURRENCIES.EMPTY_MESSAGE');
    const getRequestCurrenciesTableSchema = async () => {
        try {
            await SettingsService.getTableColumnDefinition<RequestCurrencySchema>(
                PAGE_TYPE.REQUEST_CURRENCIES
            );
        } catch (error) {
            console.error('Error in Request Currencies info fetch:', error);
        }
    };

    const getAllRequestCurrenciesList = async (body: RequestBody) => {
        try {
            const response: GetRequestCurrencyResponse =
                await SettingsService.getTableData<GetRequestCurrencyResponse>(
                    PAGE_TYPE.REQUEST_CURRENCIES,
                    body
                );
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response.data.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            setEmptyMessage(emptyMessage);
            console.error('Error in Request Currencies  info fetch:', error);
        }
    };
    const postChangeStatus = async (id: number, isActive: boolean) => {
        try {
            const response: boolean = await SettingsService.updateChangeStatus<boolean>(
                PAGE_TYPE.REQUEST_CURRENCIES,
                id,
                isActive
            );
            if (response) {
                getAllRequestCurrenciesList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
            // Handle response data as needed
        } catch (error) {
            console.error('Error updating status:', error);
            if (isActive === false) {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markInactive.ERROR_MESSAGE
                });
            } else {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markActive.ERROR_MESSAGE
                });
            }
            // Handle error
        }
    };
    const getCreateRequestCurrencyData = async (body: CreateRequestCurrencyData) => {
        try {
            const response: RequestCurrencyDataItem = await SettingsService.getCreateTableData<
                RequestCurrencyDataItem,
                CreateRequestCurrencyData
            >(PAGE_TYPE.REQUEST_CURRENCIES, body);
            if (response) {
                getAllRequestCurrenciesList(requestBody);
                if (body.id === undefined) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.create.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.update.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error in Request Currency info fetch:', error);
        }
    };
    useEffect(() => {
        getRequestCurrenciesTableSchema();
    }, []);
    useEffect(() => {
        getAllRequestCurrenciesList(requestBody);
    }, [requestBody]);

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.REQUEST_CURRENCY_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.REQUEST_CURRENCY_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const onSubmit = (data: any) => {
        if (data.id === '') {
            delete data.id;
        }
        const createRequest: CreateRequestCurrencyData = {
            currencyId: data?.currencyId,
            id: data?.id
        };
        getCreateRequestCurrencyData(createRequest).then(() => {
            formStatusStore.clearFormData();
            if (!createAnother) {
                closeModal();
            }
        });
    };
    const buttonChildren = () => {
        return (
            <button
                data-testid="create-request-currency-button"
                onClick={() => {
                    setIsEditMode(false);
                    clearFormStatusStore();
                    openModal();
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn  btn-sm text-white font-medium bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE_REQUEST_CURRENCY')}
            </button>
        );
    };
    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {
                        setIsEditMode(true);
                        generateFormData();
                        setCreateAnother(false);
                        openModal();
                    }
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header:
                                    toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                        ? t('COMMON.MARK_AS_INACTIVE')
                                        : t('COMMON.MARK_AS_ACTIVE'),
                                subHeader: toggleRowData.name,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status:
                                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.INACTIVE')
                                            : t('COMMON.ACTIVE'),
                                    table_name: tableDefinition.title.toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];
    const generateFormData = () => {
        const data = {
            currencyId: toggleRowData?.currencyId,
            id: toggleRowData?.id
        };
        formStatusStore.updateFormData(data, false, false);
    };

    const clearFormStatusStore = () => {
        const data = null;
        formStatusStore.updateFormData(data, false, false);
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.REQUEST_CURRENCIES'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        buttonChildren:
            AuthStore.hasPermission(Permissions.CREATE_REQUEST_CURRENCIES) && buttonChildren(),
        items: menuItems,
        columns: AuthStore.hasPermission(Permissions.EDIT_REQUEST_CURRENCIES)
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    function exportData() {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.REQUEST_CURRENCIES}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Request Currencies Data.xlsx');
    }

    return (
        <div data-testid="RequestCurrencyTableComponent" className="p-4 pb-3">
            {showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}
            {showModal && (
                <CreateRequestCurrencyPopup
                    closeModal={closeModal}
                    onSubmit={onSubmit}
                    popId={TABLE_POP_IDS.CREATE_POPUP.REQUEST_CURRENCY_POPUP}
                    isFromEdit={isEditMode}
                    onChangeCreateAnother={setCreateAnother}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as RequestCurrencyDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
}
export default RequestCurrenciesPage;
