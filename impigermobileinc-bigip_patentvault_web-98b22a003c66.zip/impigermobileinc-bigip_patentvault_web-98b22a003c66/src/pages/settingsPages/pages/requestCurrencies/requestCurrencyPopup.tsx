import PopupModal from 'components/popupModal/popupModal';
import React, { Dispatch, SetStateAction, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import formData from './data/requestCurrencies.mock.json';
import HttpService from 'core/interceptor/api.handler';

const CreateRequestCurrencyPopup: React.FC<{
    closeModal: () => void;
    onSubmit: (data: any) => void;
    popId: string;
    isFromEdit?: boolean;
    onChangeCreateAnother: Dispatch<SetStateAction<boolean>>;
}> = ({ closeModal, onSubmit, popId, isFromEdit = false, onChangeCreateAnother }) => {
    const { t } = useTranslation();
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());

    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(formData);

    formStatusStore.subscribe(setFormState);

    const onFormChange = (e: any) => {
        if (e.changed && e.changed.component.key !== 'id') {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    const handleSubmit = () => {
        onSubmit(formState?.data);
    };

    return (
        <PopupModal
            id={popId}
            title={
                isFromEdit
                    ? t('SETTING_PAGES.REQUEST_CURRENCIES.UPDATE_REQUEST_CURRENCIES')
                    : t('COMMON.CREATE_REQUEST_CURRENCY')
            }
            onClose={closeModal}
            onSubmit={handleSubmit}
            createButtonText={isFromEdit ? t('COMMON.UPDATE') : t('COMMON.CREATE')}
            resetButtonText={isFromEdit ? t('COMMON.CANCEL') : t('COMMON.RESET')}
            isEdit={isFromEdit}
            showButtonValidation={true}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            onChangeCreateAnother={onChangeCreateAnother}>
            <div className="p-4 pb-1 bg-neutral-300">
                <Form
                    form={formBuilderData}
                    onChange={onFormChange}
                    submission={{ data: formState.data }}
                />
            </div>
        </PopupModal>
    );
};

export default CreateRequestCurrencyPopup;
