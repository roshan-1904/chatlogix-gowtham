import DataTableComponent from 'shared/dataTable/dataTable';
import { Tooltip } from 'primereact/tooltip';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { TABLE_POP_IDS, DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { useEffect, useMemo, useState } from 'react';
import { PAGE_TYPE } from '../../constant/settings.constant';
import SettingsService from '../../service/settings.service';
import {
    TasksDataItem,
    TaskTableSchema,
    GetTasksListApiResponse,
    CreateTaskData
} from './types/tasks.types';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import CreateTasksPopup from './createTasksPopup';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { Permissions } from 'constants/permissions';
import { ToggleSwitch } from 'pages/accounting/components/toggleSwitch/toggleSwitch';
import { isFinanceUser } from 'core/utils/utils';

function TasksPage() {
    const { t } = useTranslation();

    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const [toggleRowData, setToggleRowData] = useState<TasksDataItem>();
    const [isEditMode, setIsEditMode] = useState(false);
    const [tableData, setTableData] = useState<TasksDataItem[]>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.TASKS_COLUMN_ORDERS;

    const [showModal, setShowModal] = useState(false);

    const hasPermissionForActions = AuthStore.hasPermission(Permissions.SETTING_EDIT_TASK);
    const isThisFinanceUser = isFinanceUser(loggedInUserRoleId);
    const isTasksGridReadOnlyMode = isThisFinanceUser;

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [createAnother, setCreateAnother] = useState(false);

    const handleConfirm = () => {};
    const [showPopup, setShowPopup] = useState({
        visible: false,
        handleConfirm,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        create: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.TASKS.CREATE_MESSAGE.SUCCESS_MESSAGE')
        },
        update: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.TASKS.UPDATE_MESSAGE.SUCCESS_MESSAGE')
        },
        markActive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.TASKS.MARK_ACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.TASKS.MARK_ACTIVE.ERROR_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.TASKS.MARK_INACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.TASKS.MARK_INACTIVE.ERROR_MESSAGE')
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const emptyMessage = t('SETTING_PAGES.TASKS.EMPTY_MESSAGE');

    const getTasksTableSchema = async () => {
        try {
            await SettingsService.getTableColumnDefinition<TaskTableSchema>(PAGE_TYPE.TASKS);
        } catch (error) {
            console.error('Error in Task info fetch:', error);
        }
    };

    const getAllTaskList = async (body: RequestBody) => {
        try {
            const response: GetTasksListApiResponse =
                await SettingsService.getTableData<GetTasksListApiResponse>(PAGE_TYPE.TASKS, body);
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response.data.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            setEmptyMessage(emptyMessage);
            console.error('Error in Tasks info fetch:', error);
        }
    };
    const postChangeStatus = async (id: number, isActive: boolean) => {
        try {
            const response: boolean = await SettingsService.updateChangeStatus<boolean>(
                PAGE_TYPE.TASKS,
                id,
                isActive
            );
            if (response) {
                getAllTaskList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
            // Handle response data as needed
        } catch (error) {
            console.error('Error updating status:', error);
            if (isActive === false) {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markInactive.ERROR_MESSAGE
                });
            } else {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markActive.ERROR_MESSAGE
                });
            }
            // Handle error
        }
    };
    const getCreateTasksData = async (body: CreateTaskData) => {
        try {
            const response: TasksDataItem = await SettingsService.getCreateTableData<
                TasksDataItem,
                CreateTaskData
            >(PAGE_TYPE.TASKS, body);
            if (response) {
                getAllTaskList(requestBody);
                if (body.id === undefined) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.create.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.update.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error in Tasks info fetch:', error);
        }
    };
    useEffect(() => {
        getTasksTableSchema();
    }, []);
    useEffect(() => {
        getAllTaskList(requestBody);
    }, [requestBody]);

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.TASK_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.TASK_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const onSubmit = (data: any) => {
        if (data.id === '') {
            delete data.id;
        }
        getCreateTasksData(data as CreateTaskData).then(() => {
            formStatusStore.clearFormData();
            if (!createAnother) {
                closeModal();
            }
        });
    };
    const buttonChildren = () => {
        return (
            <button
                data-testid="create-task-button"
                onClick={() => {
                    setIsEditMode(false);
                    clearFormStatusStore();
                    openModal();
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE_TASK')}
            </button>
        );
    };

    const handleStatusUpdate = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };

    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <img src="/images/svgs/i-edit-blue-icon.svg" className="h-4 w-4" />,
                    command() {
                        setIsEditMode(true);
                        generateFormData();
                        setCreateAnother(false);
                        openModal();
                    }
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                handleConfirm: () => handleStatusUpdate(),
                                header: t('COMMON.CONFIRMATION'),
                                subHeader: '',
                                description: t('COMMON.CONFIRMATION_MESSAGE', {
                                    status:
                                        toggleRowData.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.DISABLE')
                                            : t('COMMON.ENABLE'),
                                    label: tableDefinition.title.toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];
    const generateFormData = () => {
        const data = {
            name: toggleRowData?.name,
            description: toggleRowData?.description,
            revenueGLAccountNumber: parseInt(toggleRowData?.revenueGLAccountNumber ?? '', 10),
            id: toggleRowData?.id
        };
        formStatusStore.updateFormData(data, false, false);
    };
    const clearFormStatusStore = () => {
        const data = null;
        formStatusStore.updateFormData(data, false, false);
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };

    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    const updateStatusToAPI = (rowData: TasksDataItem): void => {
        const updatedRowData = { ...rowData, grossMarginEligible: !rowData.grossMarginEligible };
        getCreateTasksData(updatedRowData as CreateTaskData).then(() => {
            setShowPopup({ ...showPopup, visible: false });
        });
    };

    const updateMarginEligibleStatus = (rowData: TasksDataItem) => {
        setShowPopup({
            visible: true,
            handleConfirm: () => updateStatusToAPI(rowData),
            header: t('COMMON.CONFIRMATION'),
            subHeader: '',
            description: t('COMMON.CONFIRMATION_MESSAGE', {
                status:
                    (rowData.grossMarginEligible
                        ? t('COMMON.DISABLE')
                        : t('COMMON.ENABLE')
                    ).toLocaleLowerCase() +
                    ' ' +
                    t('TASKS.GROSS_MARGIN_ELIGIBLE'),
                label: rowData.name
            })
        });
    };

    const grossMarginTemplate = (rowData: TasksDataItem) => {
        return (
            <>
                <div className="flex">
                    <ToggleSwitch
                        onChange={() => updateMarginEligibleStatus(rowData)}
                        title=""
                        checked={rowData.grossMarginEligible ?? false}
                        isToggleDisabled={isTasksGridReadOnlyMode}
                        valueText={rowData.grossMarginEligible ? t('COMMON.YES') : t('COMMON.NO')}
                    />
                    <div className="flex ml-4 items-center">
                        <Tooltip
                            id={`summary-gross-margin-tooltip-${rowData?.id}`}
                            target={`.custom-target-gross-margin-icon-${rowData?.id}`}
                            content={
                                (rowData.grossMarginEligible ?? false)
                                    ? 'Non-Pass-Through'
                                    : 'Pass-Through'
                            }
                            position="bottom"
                            mouseTrack={false}
                            autoHide={false}
                            pt={{ root: { className: 'shadow-none ml-2' } }}
                        />
                        <i
                            className={`custom-target-gross-margin-icon-${rowData?.id} pi pi-info-circle text-primary cursor-pointer text-[1rem]`}
                        />
                    </div>
                </div>
            </>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'id',
            header: 'ID',
            sortable: true,
            filter: false,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'name',
            header: 'Name',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'description',
            header: 'Description',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'revenueGLAccountNumber',
            header: 'Revenue GL Account Number',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'costAccountNumber',
            header: 'Cost Account Number',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'grossMarginEligible',
            header: 'Gross Margin Eligible',
            sortable: true,
            filter: true,
            filterType: 'Dropdown',
            valueType: 'YesOrNo',
            columnNumber: 3,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Yes',
                    value: 'true'
                },
                {
                    label: 'No',
                    value: 'false'
                }
            ],
            body: grossMarginTemplate
        },
        {
            field: 'active',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: 'Dropdown',
            valueType: 'StatusDots',
            columnNumber: 4,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Active',
                    value: 'active'
                },
                {
                    label: 'Inactive',
                    value: 'inactive'
                }
            ]
        },
        {
            field: 'createdAt',
            header: 'Created At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 5,
            visibility: false
        },
        {
            field: 'createdBy',
            header: 'Created By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 6,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 7,
            visibility: false
        },
        {
            field: 'updatedBy',
            header: 'Updated By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 8,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: 'Deleted At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 9,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 10,
            visibility: false
        },
        {
            field: 'restoredAt',
            header: 'Restored At',
            sortable: true,
            filter: true,
            filterType: 'Calendar',
            valueType: 'Date',
            columnNumber: 11,
            visibility: false
        },
        {
            field: 'restoredBy',
            header: 'Restored By',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: 12,
            visibility: false
        },
        {
            field: 'action',
            header: 'Action',
            frozen: true,
            filterType: 'Text',
            valueType: 'Action',
            columnNumber: 13,
            visibility: true,
            className: 'w-40'
        }
    ];

    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.TASKS'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        buttonChildren:
            AuthStore.hasPermission(Permissions.SETTING_CREATE_TASK) && buttonChildren(),
        items: menuItems,
        columns: hasPermissionForActions
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    function exportData() {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.TASKS}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Tasks Data.xlsx');
    }

    return (
        <div data-testid="TasksComponent" className="p-4 pb-3">
            {showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={showPopup.handleConfirm}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}
            {showModal && (
                <CreateTasksPopup
                    closeModal={closeModal}
                    onSubmit={onSubmit}
                    popId={TABLE_POP_IDS.CREATE_POPUP.TASK_POPUP}
                    isFromEdit={isEditMode}
                    onChangeCreateAnother={setCreateAnother}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as TasksDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
}
export default TasksPage;
