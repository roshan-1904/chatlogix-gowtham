import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import TasksPage from '../tasks';
import SettingsService from '../../../service/settings.service';
import DataTableComponent from 'shared/dataTable/dataTable';
import { TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';
import { DataTableDefinition } from 'shared/dataTable/types/dataTable.types';

// Mock SettingsService functions
jest.mock('../../../service/settings.service');

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('TasksPage Component', () => {
    beforeEach(() => {
        // Reset mock implementation before each test
        jest.clearAllMocks();
    });

    test('renders correctly with initial data', () => {
        render(<TasksPage />);
        // Add assertions to ensure that the component renders without crashing
    });

    test('fetches table schema on mount', async () => {
        const mockTableSchema = [
            {
                field: 'id',
                header: 'ID',
                sortable: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 0,
                visibility: true
            },
            {
                field: 'name',
                header: 'Name',
                sortable: true,
                filter: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 1,
                visibility: true
            }
        ];

        // Mock the resolved value for SettingsService function
        const mockedSettingsService = SettingsService as jest.Mocked<typeof SettingsService>;
        mockedSettingsService.getTableColumnDefinition.mockResolvedValue({
            schema: JSON.stringify(mockTableSchema)
        });

        render(<TasksPage />);

        // Wait for API call to resolve
        await waitFor(() => {
            // Add assertions to verify that the function is called and data is fetched
            expect(mockedSettingsService.getTableColumnDefinition).toHaveBeenCalledTimes(1);
        });
    });

    test('Check the export button click', () => {
        render(<TasksPage />);
        const exportButton = screen.getByTestId('export-list-button');
        expect(exportButton).toBeDefined();
        fireEvent.click(exportButton);
    });

    // test('clicking on create button opens modal', async () => {
    //     const { getByText } = render(<TasksPage />);
    //     const createButton = getByText('Create Task');
    //     fireEvent.click(createButton);
    //     await waitFor(() => {
    //         // Add assertions for expected behavior
    //     });
    // });

    // Add more tests to cover other functionalities such as event handlers, API calls, and rendering logic
});

describe('Render table data component', () => {
    test('should render DataTableComponent with provided props', () => {
        const tableData = [
            { id: 1, name: 'Task 1' },
            { id: 2, name: 'Task 2' }
        ];
        const tableDefinition: DataTableDefinition = {
            title: 'Sample Table',
            tableType: TableTypes.SETTINGS_TABLES,
            emptyMessage: 'No data available',
            filters: {},
            reOrderableColumns: true,
            localStorageKey: 'tasks_column_orders',
            showFilter: true,
            renderChildrenAlone: true,
            hideColumnSelector: false,
            buttonChildren: <button>Click Me</button>,
            tableCustomStyle: 'custom-style',
            items: [
                {
                    label: 'Edit',
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {}
                }
            ],
            columns: [
                {
                    field: 'ID',
                    header: 'ID',
                    filterType: 'text',
                    valueType: 'string',
                    columnNumber: 1,
                    visibility: true
                },
                {
                    field: 'Name',
                    header: 'Name',
                    filterType: 'text',
                    valueType: 'string',
                    columnNumber: 2,
                    visibility: true
                }
            ]
        };

        const requestBody = {
            searchModels: [],
            sorting: { propertyName: '', value: '' },
            pageNo: 1,
            pageCount: 10
        };
        const handleFilter = jest.fn();
        const sortHandler = jest.fn();
        const setToggleRowData = jest.fn();
        const paginationInfo = {
            pageNo: 1,
            totalPages: 10,
            totalRecords: 100,
            currentPage: 1
        };
        const handlePageChange = jest.fn();
        const exportData = jest.fn();

        render(
            <DataTableComponent
                tableData={tableData}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={setToggleRowData}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        );
    });
});
