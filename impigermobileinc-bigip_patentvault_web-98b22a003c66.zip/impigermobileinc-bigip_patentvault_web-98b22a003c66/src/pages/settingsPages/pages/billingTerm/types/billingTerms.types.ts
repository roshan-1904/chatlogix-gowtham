export const BILLING_TABLE = {
    POPUP_IDS: {
        BILLING_POPUP: 'create_and_edit_popup_modal'
    }
};
export interface BillingTermTableSchema {
    id: number;
    formName: string;
    schema: string;
}
export interface BillingDataItem {
    name: string;
    days: number;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
}
export interface GetBillingTermListApiResponse {
    data: BillingDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}

export interface CreateBillingTermsData {
    name: string;
    days: number;
    id?: number;
}
