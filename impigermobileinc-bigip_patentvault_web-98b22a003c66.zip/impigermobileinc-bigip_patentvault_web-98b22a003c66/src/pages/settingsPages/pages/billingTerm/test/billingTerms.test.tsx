import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import BillingTermsPage from '../billingTerms';
import SettingsService from '../../../service/settings.service';

// Mock SettingsService functions
jest.mock('../../../service/settings.service');

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('BillingTermsPage Component', () => {
    beforeEach(() => {
        // Reset mock implementation before each test
        jest.clearAllMocks();
    });

    test('renders correctly with initial data', () => {
        render(<BillingTermsPage />);
        // Add assertions to ensure that the component renders without crashing
    });

    test('fetches table schema and data on mount', async () => {
        const mockTableSchema = [
            {
                field: 'id',
                header: 'ID',
                sortable: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 0,
                visibility: true
            },
            {
                field: 'name',
                header: 'Name',
                sortable: true,
                filter: true,
                filterType: 'Text',
                valueType: 'Text',
                columnNumber: 1,
                visibility: true
            }
        ];
        const mockTableData = [{ id: 1, name: 'Billing Term 1' }];

        // Cast SettingsService as jest.Mocked<typeof SettingsService> to use mockImplementation
        const mockedSettingsService = SettingsService as jest.Mocked<typeof SettingsService>;

        mockedSettingsService.getTableColumnDefinition.mockResolvedValue({
            schema: JSON.stringify(mockTableSchema)
        });
        mockedSettingsService.getTableData.mockResolvedValue({ data: mockTableData });

        render(<BillingTermsPage />);

        // Wait for API calls to resolve
        await waitFor(() => {
            // Add assertions to verify that the functions are called and data is fetched
            expect(mockedSettingsService.getTableColumnDefinition).toHaveBeenCalledTimes(1);
            expect(mockedSettingsService.getTableData).toHaveBeenCalledTimes(1);
        });
    });

    test('Check the export button click', () => {
        render(<BillingTermsPage />);
        const exportButton = screen.getByTestId('export-list-button');
        expect(exportButton).toBeDefined();
        fireEvent.click(exportButton);
    });

    // test('clicking on create button opens modal', async () => {
    //     const { getByText } = render(<BillingTermsPage />);
    //     const createButton = getByText('Create Billing Term');
    //     fireEvent.click(createButton);
    //     await waitFor(() => {
    //         expect(openModal).toHaveBeenCalledTimes(1);
    //     });
    // });

    // test('clicking on edit button sets isEditMode to true and opens modal', async () => {
    //     const { getByText } = render(<BillingTermsPage />);
    //     const editButton = getByText('Edit');
    //     fireEvent.click(editButton);
    //     await waitFor(() => {
    //         expect(setIsEditMode).toHaveBeenCalledWith(true);
    //         expect(generateFormData).toHaveBeenCalledTimes(1);
    //         expect(openModal).toHaveBeenCalledTimes(1);
    //     });
    // });
    // test('clicking on edit button calls generateFormData', async () => {
    //     // Mock the generateFormData function
    //     const generateFormDataMock = jest.fn();
    //     BillingTermsPage.generateFormData = generateFormDataMock;

    //     const { getByText } = render(<BillingTermsPage />);
    //     const editButton = getByText('Edit');
    //     fireEvent.click(editButton);

    //     await waitFor(() => {
    //         // Expect generateFormData to be called
    //         expect(generateFormDataMock).toHaveBeenCalledTimes(1);
    //     });
    // });
    // Add more tests to cover other functionalities such as event handlers, API calls, and rendering logic
});
