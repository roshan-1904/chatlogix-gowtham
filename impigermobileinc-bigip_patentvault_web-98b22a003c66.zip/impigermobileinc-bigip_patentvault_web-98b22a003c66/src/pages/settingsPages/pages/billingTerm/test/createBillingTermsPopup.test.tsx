import { fireEvent, render } from '@testing-library/react';
import CreateBillingTermsPopup from '../createBillingTermsPopup';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('CreateBillingTermsPopup', () => {
    it('renders with default props', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateBillingTermsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Assert that the title reflects the default value of isFromEdit
        expect(getByText('COMMON.CREATE_BILLING_TERM')).toBeInTheDocument();
        expect(getByText('COMMON.CREATE')).toBeInTheDocument();
    });
    it('renders with isFromEdit set to true', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateBillingTermsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={true}
            />
        );

        // Assert that the title reflects the setting for isFromEdit
        expect(getByText('SETTING_PAGES.BILLING_TERMS.UPDATE_BILLING_TERM')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to false', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateBillingTermsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={false}
            />
        );

        // Assert that the title reflects the setting for isFromEdit
        expect(getByText('COMMON.CREATE_BILLING_TERM')).toBeInTheDocument();
    });

    it('calls onChangeCreateAnother function when user chooses to create another item', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateBillingTermsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Simulate the user clicking on the "Create Another" button
        fireEvent.click(getByText('COMMON.CREATE_ANOTHER'));

        // Check if onChangeCreateAnother function was called
        expect(onChangeCreateAnother).toHaveBeenCalled();
    });
    // Add more test cases as needed
});
