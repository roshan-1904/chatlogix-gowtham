import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS, TABLE_POP_IDS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import CreateBillingTermsPopup from './createBillingTermsPopup';
import { MenuItem } from 'primereact/menuitem';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';

import { useEffect, useState } from 'react';
import { PAGE_TYPE } from '../../constant/settings.constant';
import SettingsService from '../../service/settings.service';
import {
    BillingDataItem,
    BillingTermTableSchema,
    CreateBillingTermsData,
    GetBillingTermListApiResponse
} from './types/billingTerms.types';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import tableSchema from './data/billingTermTableSchema.json';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { Permissions } from 'constants/permissions';

function BillingTermsPage() {
    const { t } = useTranslation();
    const [columnSchema] = useState<ColumnDefinition[]>(tableSchema as ColumnDefinition[]);
    const [toggleRowData, setToggleRowData] = useState<BillingDataItem>();
    const [isEditMode, setIsEditMode] = useState(false);
    const [tableData, setTableData] = useState<BillingDataItem[]>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.BILLING_COLUMN_ORDERS;

    const [showModal, setShowModal] = useState(false);

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [createAnother, setCreateAnother] = useState(false);
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        create: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.CREATE_MESSAGE.SUCCESS_MESSAGE')
        },
        update: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.UPDATE_MESSAGE.SUCCESS_MESSAGE')
        },
        markActive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.MARK_ACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.MARK_ACTIVE.ERROR_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.MARK_INACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.BILLING_TERMS.MARK_INACTIVE.ERROR_MESSAGE')
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const emptyMessage = t('SETTING_PAGES.BILLING_TERMS.EMPTY_MESSAGE');

    const getBillingTermTableSchema = async () => {
        try {
            await SettingsService.getTableColumnDefinition<BillingTermTableSchema>(
                PAGE_TYPE.BILLING_TERMS
            );
        } catch (error) {
            console.error('Error in Billing terms info fetch:', error);
        }
    };

    const getAllBillingTermList = async (body: RequestBody) => {
        try {
            const response: GetBillingTermListApiResponse =
                await SettingsService.getTableData<GetBillingTermListApiResponse>(
                    PAGE_TYPE.BILLING_TERMS,
                    body
                );
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response.data.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            console.error('Error in Billing terms info fetch:', error);
            setEmptyMessage(emptyMessage);
        }
    };
    const postChangeStatus = async (id: number, isActive: boolean) => {
        try {
            const response: boolean = await SettingsService.updateChangeStatus<boolean>(
                PAGE_TYPE.BILLING_TERMS,
                id,
                isActive
            );
            if (response) {
                getAllBillingTermList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
            // Handle response data as needed
        } catch (error) {
            console.error('Error updating status:', error);
            if (isActive === false) {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markInactive.ERROR_MESSAGE
                });
            } else {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markActive.ERROR_MESSAGE
                });
            }
            // Handle error
        }
    };

    const getCreateBillingTermsData = async (body: CreateBillingTermsData) => {
        try {
            const response: BillingDataItem = await SettingsService.getCreateTableData<
                BillingDataItem,
                CreateBillingTermsData
            >(PAGE_TYPE.BILLING_TERMS, body);
            if (response) {
                getAllBillingTermList(requestBody);
                if (body.id === undefined) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.create.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.update.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error in Tasks info fetch:', error);
        }
    };

    useEffect(() => {
        getBillingTermTableSchema();
        getAllBillingTermList(requestBody);
    }, [requestBody]);

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.CREATING_BILLING_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.CREATING_BILLING_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const onSubmit = (data: any) => {
        if (data.id === '') {
            delete data.id;
        }
        getCreateBillingTermsData(data as CreateBillingTermsData).then(() => {
            formStatusStore.clearFormData();
            if (!createAnother) {
                closeModal();
            }
        });
    };
    const buttonChildren = () => {
        return (
            <button
                data-testid="create-billing-term-button"
                onClick={() => {
                    setIsEditMode(false);
                    clearFormStatusStore();
                    openModal();
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE_BILLING_TERM')}
            </button>
        );
    };
    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {
                        setIsEditMode(true);
                        generateFormData();
                        setCreateAnother(false);
                        openModal();
                    }
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header:
                                    toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                        ? t('COMMON.MARK_AS_INACTIVE')
                                        : t('COMMON.MARK_AS_ACTIVE'),
                                subHeader: toggleRowData.name,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status:
                                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.INACTIVE')
                                            : t('COMMON.ACTIVE'),
                                    table_name: tableDefinition.title.toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];
    const generateFormData = () => {
        const data = {
            name: toggleRowData?.name,
            days: toggleRowData?.days,
            id: toggleRowData?.id
        };
        formStatusStore.updateFormData(data, false, false);
    };

    const clearFormStatusStore = () => {
        const data = null;
        formStatusStore.updateFormData(data, false, true);
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.BILLING_TERMS'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        buttonChildren:
            AuthStore.hasPermission(Permissions.CREATE_BILLING_TERMS) && buttonChildren(),
        items: menuItems,
        columns: AuthStore.hasPermission(Permissions.EDIT_BILLING_TERMS)
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    function exportData() {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.BILLING_TERMS}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Billing Terms Data.xlsx');
    }

    return (
        <div data-testid="BillingTableComponent" className="p-4 pb-3">
            {showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}
            {showModal && (
                <CreateBillingTermsPopup
                    closeModal={closeModal}
                    onSubmit={onSubmit}
                    popId={TABLE_POP_IDS.CREATE_POPUP.CREATING_BILLING_POPUP}
                    isFromEdit={isEditMode}
                    onChangeCreateAnother={setCreateAnother}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as BillingDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
}
export default BillingTermsPage;
