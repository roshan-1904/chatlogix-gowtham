import PopupModal from 'components/popupModal/popupModal';
import React, { Dispatch, SetStateAction, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';
// import SettingsService from '../../service/settings.service';
// import { PAGE_TYPE } from '../../constant/settings.constant';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import createBillingMock from './data/createBillingMock.json';
const CreateBillingTermsPopup: React.FC<{
    closeModal: () => void;
    onSubmit: (data: any) => void;
    popId: string;
    isFromEdit?: boolean;
    onChangeCreateAnother: Dispatch<SetStateAction<boolean>>;
}> = ({ closeModal, onSubmit, popId, isFromEdit = false, onChangeCreateAnother }) => {
    const { t } = useTranslation();
    const [parsedFormObject] = useState<any>(createBillingMock);
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());

    // useEffect(() => {
    //     const fetchDynamicForm = async () => {
    //         try {
    //             const data = await SettingsService.getDynamicFormInfo(PAGE_TYPE.BILLING_TERMS);
    //             // setParsedFormObject(JSON.parse(data.formDesign));
    //         } catch (error) {
    //             console.error('Error fetching dynamic form info:', error);
    //         }
    //     };

    //     fetchDynamicForm();
    // }, []);

    formStatusStore.subscribe(setFormState);

    const onFormChange = (e: any) => {
        if (e.changed && e.changed.component.key !== 'id') {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    const handleSubmit = () => {
        onSubmit(formState?.data);
    };

    return (
        <PopupModal
            id={popId}
            title={
                isFromEdit
                    ? t('SETTING_PAGES.BILLING_TERMS.UPDATE_BILLING_TERM')
                    : t('COMMON.CREATE_BILLING_TERM')
            }
            onClose={closeModal}
            onSubmit={handleSubmit}
            createButtonText={isFromEdit ? t('COMMON.UPDATE') : t('COMMON.CREATE')}
            resetButtonText={isFromEdit ? t('COMMON.CANCEL') : t('COMMON.RESET')}
            isEdit={isFromEdit}
            showButtonValidation={true}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            onChangeCreateAnother={onChangeCreateAnother}>
            <div className="p-4 pb-1 bg-neutral-300">
                <Form
                    form={parsedFormObject}
                    onChange={onFormChange}
                    submission={{ data: formState.data }}
                />
            </div>
        </PopupModal>
    );
};

export default CreateBillingTermsPopup;
