import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import BreakDownPage from './breakDown';
import SettingsService from '../../service/settings.service';

// Mocking the services and stores
jest.mock('../../service/settings.service');
jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

describe('BreakDownPage Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the component successfully', () => {
        render(<BreakDownPage />);
        expect(screen.getByTestId('BreakDownComponent')).toBeInTheDocument();
    });

    test('calls getBreakDownTableSchema on component mount', async () => {
        render(<BreakDownPage />);
        await waitFor(() =>
            expect(SettingsService.getTableColumnDefinition).toHaveBeenCalledTimes(1)
        );
    });

    test('fetches and displays table data', async () => {
        const mockResponse = {
            data: [{ id: 1, breakdownName: 'Test Breakdown', active: '1' }],
            pageNo: 1,
            totalPages: 1,
            totalRecords: 1
        };

        (SettingsService.getTableData as jest.Mock).mockResolvedValueOnce(mockResponse);

        render(<BreakDownPage />);

        await waitFor(() => {
            expect(screen.getByText('Test Breakdown')).toBeInTheDocument();
        });
    });

    test('handles empty table data correctly', () => {
        const mockResponse = {
            data: [],
            pageNo: 1,
            totalPages: 1,
            totalRecords: 0
        };

        (SettingsService.getTableData as jest.Mock).mockResolvedValueOnce(mockResponse);

        render(<BreakDownPage />);

        waitFor(() => {
            expect(screen.getByText('No data available')).toBeInTheDocument();
        });
        // Adjust the text according to your emptyMessage
    });

    test('displays a confirmation popup when changing status', async () => {
        const mockResponse = {
            data: [{ id: 1, breakdownName: 'Test Breakdown', active: '1' }],
            pageNo: 1,
            totalPages: 1,
            totalRecords: 1
        };

        (SettingsService.getTableData as jest.Mock).mockResolvedValueOnce(mockResponse);

        render(<BreakDownPage />);

        await waitFor(() => expect(screen.getByText('Test Breakdown')).toBeInTheDocument());

        const menuButton = screen.getByText('Test Breakdown'); // Adjust selector based on your implementation
        fireEvent.click(menuButton);
    });

    test('updates status on confirmation', async () => {
        const mockResponse = {
            data: [{ id: 1, breakdownName: 'Test Breakdown', active: '1' }],
            pageNo: 1,
            totalPages: 1,
            totalRecords: 1
        };

        (SettingsService.getTableData as jest.Mock).mockResolvedValueOnce(mockResponse);
        (SettingsService.updateChangeStatus as jest.Mock).mockResolvedValueOnce(true);

        render(<BreakDownPage />);

        await waitFor(() => expect(screen.getByText('Test Breakdown')).toBeInTheDocument());

        fireEvent.click(screen.getByText('Test Breakdown')); // Simulate row selection
    });
});
