import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { useEffect, useState } from 'react';
import { PAGE_TYPE } from '../../constant/settings.constant';
import SettingsService from '../../service/settings.service';
import {
    BreakdownDataItem,
    BreakDownTableSchema,
    GetBreakdownListApiResponse
} from './types/breakdown.types';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';

import tableSchema from './data/breakDownTableSchema.json';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { Permissions } from 'constants/permissions';

function BreakDownPage() {
    const { t } = useTranslation();

    const [columnSchema] = useState<ColumnDefinition[]>(tableSchema as ColumnDefinition[]);
    const [toggleRowData, setToggleRowData] = useState<BreakdownDataItem>();

    const [tableData, setTableData] = useState<BreakdownDataItem[]>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.BREAKDOWNS_COLUMN_ORDERS;

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        create: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.CREATE_MESSAGE.SUCCESS_MESSAGE')
        },
        update: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.UPDATE_MESSAGE.SUCCESS_MESSAGE')
        },
        markActive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.MARK_ACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.MARK_ACTIVE.ERROR_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.MARK_INACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.BREAKDOWNS.MARK_INACTIVE.ERROR_MESSAGE')
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const emptyMessage = t('SETTING_PAGES.BREAKDOWNS.EMPTY_MESSAGE');

    const getBreakDownTableSchema = async () => {
        try {
            await SettingsService.getTableColumnDefinition<BreakDownTableSchema>(
                PAGE_TYPE.BREAKDOWNS
            );
        } catch (error) {
            console.error('Error in Task info fetch:', error);
        }
    };

    const getAllTaskList = async (body: RequestBody) => {
        try {
            const response: GetBreakdownListApiResponse =
                await SettingsService.getTableData<GetBreakdownListApiResponse>(
                    PAGE_TYPE.BREAKDOWNS,
                    body
                );
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response.data.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            setEmptyMessage(emptyMessage);
            console.error('Error in BreakDown info fetch:', error);
        }
    };
    const postChangeStatus = async (id: number, isActive: boolean) => {
        try {
            const response: boolean = await SettingsService.updateChangeStatus<boolean>(
                PAGE_TYPE.BREAKDOWNS,
                id,
                isActive
            );
            if (response) {
                getAllTaskList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error updating status:', error);
            if (isActive === false) {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markInactive.ERROR_MESSAGE
                });
            } else {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markActive.ERROR_MESSAGE
                });
            }
        }
    };

    useEffect(() => {
        getBreakDownTableSchema();
    }, []);
    useEffect(() => {
        getAllTaskList(requestBody);
    }, [requestBody]);

    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <img src="/images/svgs/i-edit-blue-icon.svg" className="h-4 w-4" />,
                    command() {}
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header:
                                    toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                        ? t('COMMON.MARK_AS_INACTIVE')
                                        : t('COMMON.MARK_AS_ACTIVE'),
                                subHeader: toggleRowData.breakdownName,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status:
                                        toggleRowData.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.INACTIVE')
                                            : t('COMMON.ACTIVE'),
                                    table_name: tableDefinition.title.toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };

    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.BREAKDOWNS'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        items: menuItems,
        columns: AuthStore.hasPermission(Permissions.EDIT_BREAKDOWN)
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    function exportData() {
        const exportURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.BREAKDOWNS}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportURL, 'BreakDown Data.xlsx');
    }

    return (
        <div data-testid="BreakDownComponent" className="p-4 pb-3">
            {showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as BreakdownDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
}
export default BreakDownPage;
