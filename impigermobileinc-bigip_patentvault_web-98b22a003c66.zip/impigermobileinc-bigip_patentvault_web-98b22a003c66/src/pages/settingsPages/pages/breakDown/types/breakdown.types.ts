export const BREAKDOWN_TABLE = {
    POPUP_IDS: {
        BREAKDOWN_POPUP: 'create_and_edit_breakdown_popup_modal'
    }
};
export interface BreakDownTableSchema {
    id: number;
    formName: string;
    schema: string;
}
export interface BreakdownDataItem {
    breakdownName: string;
    vendorPercentage: number;
    companyPercentage: number;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string | null;
    deletedAt: string | null;
    restoredBy: string | null;
    restoredAt: string | null;
}

export interface GetBreakdownListApiResponse {
    data: BreakdownDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}

export interface CreateBreakdownData {
    breakdownName: string;
    vendorPercentage: number;
    companyPercentage: number;
    id?: number;
}
