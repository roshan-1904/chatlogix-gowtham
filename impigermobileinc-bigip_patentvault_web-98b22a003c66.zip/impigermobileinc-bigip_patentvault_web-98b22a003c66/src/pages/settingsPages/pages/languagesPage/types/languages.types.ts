export interface LanguagesTableSchema {
    id: number;
    formName: string;
    schema: string;
}

export interface LanguagesDataItem {
    name: string;
    isoCode: string;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
}

export interface GetLanguagesListApiResponse {
    data: LanguagesDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
export interface CreateLanguagesData {
    name: string;
    isoCode: string;
    id?: number;
}
