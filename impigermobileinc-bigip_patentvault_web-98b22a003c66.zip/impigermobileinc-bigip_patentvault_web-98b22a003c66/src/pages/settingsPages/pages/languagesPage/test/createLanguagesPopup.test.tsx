import { render, fireEvent } from '@testing-library/react';
import CreateLanguagesPopup from '../createLanguagesPopup';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('CreateLanguagesPopup', () => {
    it('renders with default props', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateLanguagesPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Assert that the title reflects the default value of isFromEdit
        expect(getByText('COMMON.CREATE_LANGUAGE')).toBeInTheDocument();
    });
    it('renders with isFromEdit set to true', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateLanguagesPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={true}
            />
        );

        expect(getByText('SETTING_PAGES.LANGUAGES.UPDATE_LANGUAGES')).toBeInTheDocument();
        expect(getByText('COMMON.UPDATE')).toBeInTheDocument();
        expect(getByText('COMMON.CANCEL')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to false', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateLanguagesPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={false}
            />
        );

        expect(getByText('COMMON.CREATE_LANGUAGE')).toBeInTheDocument();
        expect(getByText('COMMON.CREATE')).toBeInTheDocument();
        expect(getByText('COMMON.RESET')).toBeInTheDocument();
    });

    it('calls onChangeCreateAnother function when user chooses to create another item', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateLanguagesPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        fireEvent.click(getByText('COMMON.CREATE_ANOTHER'));

        expect(onChangeCreateAnother).toHaveBeenCalled();
    });

    // Add more test cases as needed
});
