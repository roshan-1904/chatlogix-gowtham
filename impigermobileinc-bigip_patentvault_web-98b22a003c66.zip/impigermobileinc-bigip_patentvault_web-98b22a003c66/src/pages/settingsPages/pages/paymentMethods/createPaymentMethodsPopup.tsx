import PopupModal from 'components/popupModal/popupModal';
import React, { Dispatch, SetStateAction, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';
// import SettingsService from '../../service/settings.service';
// import { PAGE_TYPE } from '../../constant/settings.constant';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import paymentInfoMock from './data/createPaymentMethods.mock.json';
const CreatePaymentMethodsPopup: React.FC<{
    closeModal: () => void;
    onSubmit: (data: any) => void;
    popId: string;
    isFromEdit?: boolean;
    onChangeCreateAnother: Dispatch<SetStateAction<boolean>>;
}> = ({ closeModal, onSubmit, popId, isFromEdit = false, onChangeCreateAnother }) => {
    const { t } = useTranslation();
    const [parsedFormObject] = useState<any>(paymentInfoMock);
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());

    // useEffect(() => {
    //     const fetchDynamicForm = async () => {
    //         try {
    //             await SettingsService.getDynamicFormInfo(PAGE_TYPE.PAYMENT_METHODS);
    //             // setParsedFormObject(JSON.parse(data.formDesign));
    //         } catch (error) {
    //             console.error('Error fetching dynamic form info:', error);
    //         }
    //     };

    //     fetchDynamicForm();
    // }, []);

    formStatusStore.subscribe(setFormState);

    const onFormChange = (e: any) => {
        if (e.changed && e.changed.component.key !== 'id') {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    const handleSubmit = () => {
        onSubmit(formState?.data);
    };

    return (
        <PopupModal
            id={popId}
            title={
                isFromEdit
                    ? t('SETTING_PAGES.PAYMENT_METHODS.UPDATE_PAYMENT_METHODS')
                    : t('COMMON.CREATE_PAYMENT_METHOD')
            }
            onClose={closeModal}
            onSubmit={handleSubmit}
            createButtonText={isFromEdit ? t('COMMON.UPDATE') : t('COMMON.CREATE')}
            resetButtonText={isFromEdit ? t('COMMON.CANCEL') : t('COMMON.RESET')}
            isEdit={isFromEdit}
            showButtonValidation={true}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            onChangeCreateAnother={onChangeCreateAnother}>
            <div className="p-4 pb-1 bg-neutral-300">
                <Form
                    form={parsedFormObject}
                    onChange={onFormChange}
                    submission={{ data: formState.data }}
                />
            </div>
        </PopupModal>
    );
};

export default CreatePaymentMethodsPopup;
