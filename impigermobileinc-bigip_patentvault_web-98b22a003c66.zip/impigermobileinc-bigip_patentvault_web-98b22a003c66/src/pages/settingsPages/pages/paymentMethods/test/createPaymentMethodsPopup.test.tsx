import { render, fireEvent } from '@testing-library/react';
import CreatePaymentMethodsPopup from '../createPaymentMethodsPopup';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('CreatePaymentMethodsPopup', () => {
    it('renders with default props', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreatePaymentMethodsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        expect(getByText('COMMON.CREATE_PAYMENT_METHOD')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to true', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreatePaymentMethodsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={true}
            />
        );

        expect(
            getByText('SETTING_PAGES.PAYMENT_METHODS.UPDATE_PAYMENT_METHODS')
        ).toBeInTheDocument();
        expect(getByText('COMMON.UPDATE')).toBeInTheDocument();
        expect(getByText('COMMON.CANCEL')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to false', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText: getByTextCreate } = render(
            <CreatePaymentMethodsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={false}
            />
        );

        fireEvent.click(getByTextCreate('COMMON.CREATE'));

        // expect(onSubmit).toHaveBeenCalledWith({
        //     paymentMethodName: 'Credit Card',
        //     paymentMethodType: 'Visa'
        // });

        expect(getByTextCreate('COMMON.RESET')).toBeInTheDocument();
    });

    it('calls onChangeCreateAnother function when user chooses to create another item', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText: getByTextAnother } = render(
            <CreatePaymentMethodsPopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        fireEvent.click(getByTextAnother('COMMON.CREATE_ANOTHER'));

        // expect(onChangeCreateAnother).toHaveBeenCalled();
    });
});
