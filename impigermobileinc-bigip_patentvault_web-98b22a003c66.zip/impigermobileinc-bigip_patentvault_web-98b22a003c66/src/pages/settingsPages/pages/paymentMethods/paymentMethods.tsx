import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { TABLE_POP_IDS, DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { MenuItem } from 'primereact/menuitem';
import { ReactComponent as EditIcon } from 'assets/images/editBlue.svg';

import { useEffect, useState } from 'react';
import { PAGE_TYPE } from '../../constant/settings.constant';
import SettingsService from '../../service/settings.service';
import {
    PaymentMethodsDataItem,
    PaymentMethodTableSchema,
    GetPaymentMethodsListApiResponse,
    CreatePaymentMethodData
} from './types/paymentMethods.types';
import {
    ActiveStatusEnum,
    COLUMN_FIELD_CONST,
    TableTypes
} from 'shared/dataTable/constant/dataTable.constant';
import CreatePaymentMethodsPopup from './createPaymentMethodsPopup';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import tableSchema from './data/paymentTableSchema.json';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import AuthStore from 'core/store/authStore/authStore';
import { END_POINT } from 'constants/endPoint';
import { Permissions } from 'constants/permissions';

function PaymentMethodsPage() {
    const { t } = useTranslation();

    const [columnSchema] = useState<ColumnDefinition[]>(tableSchema as ColumnDefinition[]);
    const [toggleRowData, setToggleRowData] = useState<PaymentMethodsDataItem>();
    const [isEditMode, setIsEditMode] = useState(false);
    const [tableData, setTableData] = useState<PaymentMethodsDataItem[]>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.PAYMENT_METHODS_COLUMN_ORDERS;
    const [showModal, setShowModal] = useState(false);

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [createAnother, setCreateAnother] = useState(false);
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        subHeader: '',
        description: ''
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const toastMessages = {
        create: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.CREATE_MESSAGE.SUCCESS_MESSAGE')
        },
        update: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.UPDATE_MESSAGE.SUCCESS_MESSAGE')
        },
        markActive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.MARK_ACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.MARK_ACTIVE.ERROR_MESSAGE')
        },
        markInactive: {
            SUCCESS_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.MARK_INACTIVE.SUCCESS_MESSAGE'),
            ERROR_MESSAGE: t('SETTING_PAGES.PAYMENT_METHODS.MARK_INACTIVE.ERROR_MESSAGE')
        }
    };
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const emptyMessage = t('SETTING_PAGES.PAYMENT_METHODS.EMPTY_MESSAGE');
    const getPaymentMethodsTableSchema = async () => {
        try {
            await SettingsService.getTableColumnDefinition<PaymentMethodTableSchema>(
                PAGE_TYPE.PAYMENT_METHODS
            );
        } catch (error) {
            console.error('Error in Payment Method info fetch:', error);
        }
    };

    const getAllPaymentList = async (body: RequestBody) => {
        try {
            const response: GetPaymentMethodsListApiResponse =
                await SettingsService.getTableData<GetPaymentMethodsListApiResponse>(
                    PAGE_TYPE.PAYMENT_METHODS,
                    body
                );
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
            if (response.data.length) setEmptyMessage(emptyMessage);
        } catch (error) {
            setEmptyMessage(emptyMessage);
            console.error('Error in Payment Methods info fetch:', error);
        }
    };
    const postChangeStatus = async (id: number, isActive: boolean) => {
        try {
            const response: boolean = await SettingsService.updateChangeStatus<boolean>(
                PAGE_TYPE.PAYMENT_METHODS,
                id,
                isActive
            );
            if (response) {
                getAllPaymentList(requestBody);
                if (isActive === false) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markInactive.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.markActive.SUCCESS_MESSAGE
                    });
                }
            }
            // Handle response data as needed
        } catch (error) {
            console.error('Error updating status:', error);
            if (isActive === false) {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markInactive.ERROR_MESSAGE
                });
            } else {
                showToastMessage({
                    type: ToastType.ERROR,
                    message: toastMessages.markActive.ERROR_MESSAGE
                });
            }
            // Handle error
        }
    };
    const getCreatePaymentMethodsData = async (body: CreatePaymentMethodData) => {
        try {
            const response: PaymentMethodsDataItem = await SettingsService.getCreateTableData<
                PaymentMethodsDataItem,
                CreatePaymentMethodData
            >(PAGE_TYPE.PAYMENT_METHODS, body);
            if (response) {
                getAllPaymentList(requestBody);
                if (body.id === undefined) {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.create.SUCCESS_MESSAGE
                    });
                } else {
                    showToastMessage({
                        type: ToastType.SUCCESS,
                        message: toastMessages.update.SUCCESS_MESSAGE
                    });
                }
            }
        } catch (error) {
            console.error('Error in Payment Methods info fetch:', error);
        }
    };
    useEffect(() => {
        getPaymentMethodsTableSchema();
    }, []);
    useEffect(() => {
        getAllPaymentList(requestBody);
    }, [requestBody]);

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.PAYMENT_METHODS_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.PAYMENT_METHODS_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const onSubmit = (data: any) => {
        if (data.id === '') {
            delete data.id;
        }
        getCreatePaymentMethodsData(data as CreatePaymentMethodData).then(() => {
            formStatusStore.clearFormData();
            if (!createAnother) {
                closeModal();
            }
        });
    };
    const buttonChildren = () => {
        return (
            <button
                data-testid="create-payment-method-button"
                onClick={() => {
                    setIsEditMode(false);
                    clearFormStatusStore();
                    openModal();
                }}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                className="btn btn-sm text-white bg-primary hover:bg-primary-200">
                <i className="pi pi-plus-circle"></i>
                {t('COMMON.CREATE_PAYMENT_METHOD')}
            </button>
        );
    };
    const menuItems: MenuItem[] = [
        {
            items: [
                {
                    label: t('COMMON.EDIT'),
                    icon: () => <EditIcon className="h-4 w-4" />,
                    command() {
                        setIsEditMode(true);
                        generateFormData();
                        setCreateAnother(false);
                        openModal();
                    }
                },
                {
                    label:
                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                            ? t('COMMON.MARK_AS_INACTIVE')
                            : t('COMMON.MARK_AS_ACTIVE'),
                    icon: () => <i className="pi pi-check-circle text-primary" />,
                    command() {
                        if (toggleRowData) {
                            setShowPopup({
                                visible: true,
                                header:
                                    toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                        ? t('COMMON.MARK_AS_INACTIVE')
                                        : t('COMMON.MARK_AS_ACTIVE'),
                                subHeader: toggleRowData.name,
                                description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                                    status:
                                        toggleRowData?.active === ActiveStatusEnum.ACTIVE.toString()
                                            ? t('COMMON.INACTIVE')
                                            : t('COMMON.ACTIVE'),
                                    table_name: tableDefinition.title.toLowerCase()
                                })
                            });
                        }
                    }
                }
            ]
        }
    ];
    const generateFormData = () => {
        const data = {
            name: toggleRowData?.name,
            id: toggleRowData?.id
        };
        formStatusStore.updateFormData(data, false, false);
    };

    const clearFormStatusStore = () => {
        const data = null;
        formStatusStore.updateFormData(data, false, false);
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };
    const handleConfirm = () => {
        if (toggleRowData) {
            postChangeStatus(
                toggleRowData?.id,
                toggleRowData?.active !== ActiveStatusEnum.ACTIVE.toString()
            );
        }
        setShowPopup({ ...showPopup, visible: false });
    };
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.PAYMENT_METHODS'),
        emptyMessage: eMessage,
        localStorageKey: storageKey,
        buttonChildren: AuthStore.hasPermission(Permissions.CREATE_PAYMENT) && buttonChildren(),
        items: menuItems,
        columns: AuthStore.hasPermission(Permissions.EDIT_PAYMENT)
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    function exportData() {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.PAYMENT_METHODS}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Payment Methods Data.xlsx');
    }

    return (
        <div data-testid="PaymentMethodsComponent" className="p-4 pb-3">
            {showPopup.visible && (
                <ConfirmationPopup
                    onConfirm={() => handleConfirm()}
                    onCancel={() => handleCancel()}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    subHeaderText={showPopup.subHeader}
                    description={showPopup.description}
                />
            )}
            {showModal && (
                <CreatePaymentMethodsPopup
                    closeModal={closeModal}
                    onSubmit={onSubmit}
                    popId={TABLE_POP_IDS.CREATE_POPUP.PAYMENT_METHODS_POPUP}
                    isFromEdit={isEditMode}
                    onChangeCreateAnother={setCreateAnother}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={(rowData) => {
                    setToggleRowData(rowData as PaymentMethodsDataItem);
                }}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
}
export default PaymentMethodsPage;
