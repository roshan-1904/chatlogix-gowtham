export interface PaymentMethodTableSchema {
    id: number;
    formName: string;
    schema: string;
}

export interface PaymentMethodsDataItem {
    name: string;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
}

export interface GetPaymentMethodsListApiResponse {
    data: PaymentMethodsDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
export interface CreatePaymentMethodData {
    name: string;
    id?: number;
}
