import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { GetRateLabelListApiResponse, RateLabelsModel } from './types/rateLabel.types';
import { useEffect, useState } from 'react';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import {
    COLUMN_FIELD_CONST,
    FilterType,
    TableTypes,
    ValueType
} from 'shared/dataTable/constant/dataTable.constant';
import { t } from 'i18next';
import AuthStore from 'core/store/authStore/authStore';
import DataTableComponent from 'shared/dataTable/dataTable';
import { Permissions } from 'constants/permissions';
import { END_POINT } from 'constants/endPoint';
import { PAGE_TYPE } from 'pages/settingsPages/constant/settings.constant';
import SettingsService from 'pages/settingsPages/service/settings.service';

// constants
const requestBodyInit = {
    searchModels: [],
    sorting: {
        propertyName: '',
        value: ''
    },
    pageNo: 1,
    pageCount: 10
};

const RateLabels = () => {
    const [tableData, setTableData] = useState<RateLabelsModel[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>(requestBodyInit);
    const storageKey = DATA_STORAGE_KEYS.DATA_TABLE.RATE_LABELS_COLUMN_ORDER;
    const hasPermissionForActions = AuthStore.hasPermission(Permissions.VIEW_RATE_LABELS);

    // api
    const getRateLabelList = async (body: RequestBody) => {
        try {
            const response: GetRateLabelListApiResponse =
                await SettingsService.getTableData<GetRateLabelListApiResponse>(
                    PAGE_TYPE.RATE_LABELS,
                    body
                );
            setTableData(response.data);
            const pagination: paginationData = {
                pageNo: response.pageNo,
                totalPages: response.totalPages,
                totalRecords: response.totalRecords
            };
            setPaginationInfo(pagination);
        } catch (error) {
            console.error('Error in Tasks info fetch:', error);
        }
    };

    let column = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'id',
            header: 'ID',
            sortable: true,
            filter: false,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: column++,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'name',
            header: 'Name',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: column++,
            visibility: true
        },
        {
            field: 'labelCode',
            header: 'Code',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: column++,
            visibility: true
        },
        {
            field: 'description',
            header: 'Description',
            sortable: true,
            filter: true,
            filterType: 'Text',
            valueType: 'Text',
            columnNumber: column++,
            visibility: true
        },
        {
            field: 'isSystemOnly',
            header: 'System Only',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: [
                {
                    label: t('COMMON.YES'),
                    value: 'yes'
                },
                {
                    label: t('COMMON.NO'),
                    value: 'no'
                }
            ],
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: true
        },
        {
            field: 'active',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.StatusDots,
            columnNumber: column++,
            visibility: true
        },
        {
            field: 'createdBy',
            header: 'Created By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'createdAt',
            header: 'Created At',
            frozen: false,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'updatedBy',
            header: 'Updated At',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'updatedAt',
            header: 'Updated At',
            frozen: false,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'deletedBy',
            header: 'Deleted By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'deletedAt',
            header: 'Deleted At',
            frozen: false,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'restoredBy',
            header: 'Restored By',
            frozen: false,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: column++,
            visibility: false
        },
        {
            field: 'restoredAt',
            header: 'Restored At',
            frozen: false,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: column++,
            visibility: false
        }
    ];
    const tableDefinition: DataTableDefinition = {
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.SETTINGS_TABLES,
        title: t('MENU.RATE_LABELS'),
        emptyMessage: t('SETTING_PAGES.RATE_LABELS.EMPTY_MESSAGE'),
        localStorageKey: storageKey,
        items: [],
        columns: hasPermissionForActions
            ? columnSchema
            : columnSchema?.filter((item) => item.field !== COLUMN_FIELD_CONST.ACTION.toString())
    };

    // functions
    const exportData = () => {
        const exportTaskURL = `${END_POINT.SETTINGS.SETTING_END_POINT}${PAGE_TYPE.RATE_LABELS}${END_POINT.SETTINGS.EXPORT}`;
        SettingsService.exportData(requestBody, exportTaskURL, 'Rate Labels.xlsx');
    };
    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // side effects
    useEffect(() => {
        getRateLabelList(requestBody);
    }, [requestBody]);

    return (
        <div data-testid="RateLabelComponent" className="p-4 pb-3">
            <DataTableComponent
                tableData={tableData ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                handleSort={sortHandler}
                toggleRowData={() => {}}
                tablePaginationData={paginationInfo}
                handlePagination={handlePageChange}
                exportData={exportData}
            />
        </div>
    );
};

export default RateLabels;
