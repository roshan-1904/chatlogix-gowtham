export interface RateLabelsModel {
    id: number;
    name: string;
    code: string;
    description: string;
}

export interface GetRateLabelListApiResponse {
    data: RateLabelsModel[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}

export interface EpoListModel {
    id: string;
    sourceLanguage: string;
    sourceLanguageName: string;
    patentPublicationNumber: string;
    patentApplicationNumber: string;
    kind?: string;
    applicantName?: string;
    applicantCount?: number;
    title?: string;
    titleFR?: string;
    titleDE?: string;
    patentPublicationDate?: Date;
    statutoryDeadline?: Date;
    validationDeadline?: Date;
    validationDeadlineUP?: Date;
    descriptionWordCount?: number;
    numberOfClaims?: number;
    claimWordCount?: number;
    descriptionPageCount?: number;
    claimsPageCount?: number;
    drawingsPageCount?: number;
    recordSource?: string;
}

export interface EpoListApiResponse {
    data: EpoListModel[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
