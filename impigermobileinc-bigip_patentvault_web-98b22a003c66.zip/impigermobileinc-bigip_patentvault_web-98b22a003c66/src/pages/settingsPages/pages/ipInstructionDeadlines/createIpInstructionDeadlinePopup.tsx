import PopupModal from 'components/popupModal/popupModal';
import React, { Dispatch, SetStateAction, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Form } from '@formio/react';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import ipMock from './data/createIpInstruction.mock.json';
const CreateIpInstructionDeadlinePopup: React.FC<{
    closeModal: () => void;
    onSubmit: (data: any) => void;
    popId: string;
    isFromEdit?: boolean;
    onChangeCreateAnother: Dispatch<SetStateAction<boolean>>;
}> = ({ closeModal, onSubmit, popId, isFromEdit = false, onChangeCreateAnother }) => {
    const { t } = useTranslation();

    const [parsedFormObject] = useState<any>(ipMock);
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());
    formStatusStore.subscribe(setFormState);

    const onFormChange = (e: any) => {
        if (e.changed && e.changed.component.key !== 'id') {
            const { data, isValid } = e;
            const formattedData: any = data;
            delete formattedData.submit;
            formStatusStore.updateFormData(formattedData, !!isValid, true);
        }
    };

    const handleSubmit = () => {
        onSubmit(formState?.data);
    };

    return (
        <PopupModal
            id={popId}
            title={
                isFromEdit
                    ? t('SETTING_PAGES.IP_INSTRUCTION_DEADLINES.UPDATE_IP_INSTRUCTION_DEADLINES')
                    : t('COMMON.CREATE_IP_INSTRUCTION_DEADLINE')
            }
            onClose={closeModal}
            onSubmit={handleSubmit}
            createButtonText={isFromEdit ? t('COMMON.UPDATE') : t('COMMON.CREATE')}
            resetButtonText={isFromEdit ? t('COMMON.CANCEL') : t('COMMON.RESET')}
            isEdit={isFromEdit}
            showButtonValidation={true}
            createAnotherText={t('COMMON.CREATE_ANOTHER')}
            onChangeCreateAnother={onChangeCreateAnother}>
            <div className="p-4 pb-1 bg-neutral-300">
                <Form
                    form={parsedFormObject}
                    onChange={onFormChange}
                    submission={{ data: formState.data }}
                />
            </div>
        </PopupModal>
    );
};

export default CreateIpInstructionDeadlinePopup;
