import { fireEvent, render } from '@testing-library/react';
import CreateIpInstructionDeadlinePopup from '../createIpInstructionDeadlinePopup';

// Mock dependencies
jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

describe('CreateIpInstructionDeadlinePopup', () => {
    it('renders with default props', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateIpInstructionDeadlinePopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Assert that the title reflects the default value of isFromEdit
        expect(getByText('COMMON.CREATE_IP_INSTRUCTION_DEADLINE')).toBeInTheDocument();
        expect(getByText('COMMON.CREATE')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to true', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateIpInstructionDeadlinePopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={true}
            />
        );

        // Assert that the title reflects the setting for isFromEdit
        expect(
            getByText('SETTING_PAGES.IP_INSTRUCTION_DEADLINES.UPDATE_IP_INSTRUCTION_DEADLINES')
        ).toBeInTheDocument();
        expect(getByText('COMMON.UPDATE')).toBeInTheDocument();
    });

    it('renders with isFromEdit set to false', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateIpInstructionDeadlinePopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
                isFromEdit={false}
            />
        );

        // Assert that the title reflects the setting for isFromEdit
        expect(getByText('COMMON.CREATE_IP_INSTRUCTION_DEADLINE')).toBeInTheDocument();
        expect(getByText('COMMON.CREATE')).toBeInTheDocument();
    });
    it('calls onChangeCreateAnother function when user chooses to create another item', () => {
        const closeModal = jest.fn();
        const onSubmit = jest.fn();
        const onChangeCreateAnother = jest.fn();

        const { getByText } = render(
            <CreateIpInstructionDeadlinePopup
                closeModal={closeModal}
                onSubmit={onSubmit}
                popId="test-popup"
                onChangeCreateAnother={onChangeCreateAnother}
            />
        );

        // Simulate the user clicking on the "Create Another" button
        fireEvent.click(getByText('COMMON.CREATE_ANOTHER'));

        // Check if onChangeCreateAnother function was called
        expect(onChangeCreateAnother).toHaveBeenCalled();
    });
    // Add more test cases as needed
});
