export interface IpInstructionDeadlineTableSchema {
    id: number;
    formName: string;
    schema: string;
}

export interface IpInstructionDeadlinesDataItem {
    totalOrClaimWordCount: string;
    from: number;
    to: number;
    noticePeriod: string;
    id: number;
    createdBy: string;
    createdAt: string;
    updatedBy: string;
    updatedAt: string;
    active: string;
    deletedBy: string;
    deletedAt: string;
    restoredBy: string;
    restoredAt: string;
}

export interface GetIpInstructionDeadlinesListApiResponse {
    data: IpInstructionDeadlinesDataItem[];
    pageNo: number;
    totalPages: number;
    totalRecords: number;
}
export interface CreateIpInstructionDeadlineData {
    totalOrClaimWordCount: string;
    noticePeriod: string;
    id?: number;
}
