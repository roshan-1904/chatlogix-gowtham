export const IsShowUPDeadLines = (upInfo: DateAndDeadLinesViewModel) => {
    return (
        upInfo.isEP &&
        upInfo.isEPTranslationAndValidation &&
        (!upInfo.is713Claims ||
            (upInfo.is713Claims && upInfo.isEPTranslationAndValidation && upInfo.isQuote)) &&
        !upInfo.isNonIp &&
        upInfo.isUP
    );
};

export const IsShowValidationDeadLines = (upInfo: DateAndDeadLinesViewModel) => {
    return (
        upInfo.isEP &&
        (!upInfo.is713Claims ||
            (upInfo.is713Claims && upInfo.isEPTranslationAndValidation && upInfo.isQuote)) &&
        upInfo.isEPTranslationAndValidation &&
        (upInfo.isQuote || (!upInfo.isQuote && !upInfo.isUP)) &&
        !upInfo.isNonIp
    );
};

export interface DateAndDeadLinesViewModel {
    isEP: boolean;
    isUP: boolean;
    is713Claims: boolean;
    isEPTranslationAndValidation: boolean;
    isNonIp: boolean;
    isQuote: boolean;
}
