import RequestDetailsPage from './components/requestDetails/requestDetails';
import { t } from 'i18next';
import AdditionalInfoPage from './components/additionalInfo/additionalInfo';
import DateAndDeadlinesPage from './components/dateAndDeadlines/dateAndDeadlines';
import PatentCountsPage from './components/patentCounts/patentCounts';
import { ViewOrderAndQuoteHeader, ViewOrderAndQuoteHeaderRef } from './components/header/header';
import CountryDetailsPage from './components/countryDetails/countryDetails';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
    getCountryDetails,
    getEpUpCountryDetails,
    getOrderDetails,
    getPDFData,
    getRequestStatusList,
    updateAdditionalInfo,
    updateDateAndDeadline,
    updateInstruction,
    updateInternalDeadline,
    updatePatentCounts,
    updatePatentTitle
} from './service/viewOrderQuoteService';
import {
    AccordianType,
    AdditionalInfoInputs,
    DateAndDeadLinesEditInputs,
    InstructionType,
    PatentCountEditInputs,
    RequestDetailsInputs,
    ResponseCountryList,
    StatusType,
    ViewOrderType
} from './types/viewDetailsTypes';
import {
    additionalInfoEditErrorMessages,
    additionalInfoEditValidations,
    additionalInfoUpdateBody,
    dateAndDeadlineUpdateBody,
    handleAPIUpdate,
    instructionUpdateBody,
    patentCountsValidation,
    patentCountUpdateBody,
    requestDetailsUpdateBody,
    showToastMessage,
    updateStateOnCancel
} from './shared/viewOrderAndQuoteHelper';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import InstructionsAndComments from './components/instructions/instructions';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import {
    CATEGORY_TYPE,
    IP_NONIP,
    MODE,
    PATENT_SOURCE_LANGUAGE,
    SERVICE_TYPES,
    STATUS_MODE
} from 'constants/app.constant';
import UploadedDocuments from './components/uploadedDocuments/uploadedDocuments';
import BillsAndInvoices from './components/billsAndInvoices/billsAndInvoices';
import utils, {
    getWindowSize,
    isAdminUser,
    isContactUser,
    isProjectManagerUser,
    isSalesRep,
    isStaffUser,
    isVendorUser
} from 'core/utils/utils';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import {
    QuoteOrderModuleStore,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import { Dialog } from 'primereact/dialog';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import { PATHS } from 'constants/routes.constant';
import { Permissions } from 'constants/permissions';
import { previewDialogPopup } from 'constants/styles.constant';
import stepperStore from 'core/store/stepperStore/progressStepper.store';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';
import EpUpCountryDetailsPage, {
    CountryAndLanguageDetailModel,
    CountryAndLanguageDetails,
    CountryAndLanguageDetailsResponse
} from './components/countryDetails/epUpCountryDetails';
import EpCountryOrderEdit from './components/countryDetails/epCountryOrderEdit';
import Actions from './components/actions/actions';

const ViewOrderAndQuotePage = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { requestId } = useParams();
    const isUpcOptOut = window.location?.href?.includes(PATHS.UPC_OPT_OUT) ?? false;
    const separatorLine = () => <span className=" font-medium text-primary mx-2">|</span>;
    const [viewData, setViewData] = useState<ViewOrderType | null>(null);
    const [countryData, setCountryData] = useState<ResponseCountryList | null>({
        orderViewCountryModel: [],
        total: 0
    });
    const defaultCountryAndLanguageDetails: CountryAndLanguageDetails = {
        upList: [],
        nonUpList: [],
        epList: [],
        claimsTranslationList: [],
        currencySymbol: null,
        viewData: null,
        countryEditResponse: false,
        setCountryEditResponse: undefined
    };
    const [epUpCountryList, setupEpUpCountryList] = useState<CountryAndLanguageDetails>(
        defaultCountryAndLanguageDetails
    );
    const [statusList, setStatusList] = useState<StatusType[]>([]);
    const [dropDownValue, setDropDownValue] = useState(
        state?.statusName || viewData?.headers?.statusName
    );
    const [orderOrQuoteId, setOrderOrQuoteId] = useState(state?.requestId);
    const [primaryIdForAzureStorage, setPrimaryIdForAzureStorage] = useState(state?.primaryId);
    const [category, setCategory] = useState('');
    const [service, setService] = useState('');
    const requestType = viewData?.requestType;
    const isNonIp = requestType === IP_NONIP.nonIp;

    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisStaffExcludedFinance = isStaffUser(loggedInUserRoleId, true);
    const isThisVendorExcludedFinance = isVendorUser(loggedInUserRoleId, {
        excludeFinance: true
    });
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isThisPMOrAdminUser =
        isProjectManagerUser(loggedInUserRoleId) || isAdminUser(loggedInUserRoleId);

    const [patentCountEdit, setPatentCountEdit] = useState<boolean>(false);
    const [isPatentCountError, setIsPatentCountError] = useState<boolean>(false);
    const isUP = !!viewData?.headers?.isUP;
    const [companyId, setCompanyId] = useState<number | undefined>();
    const [isRebuildOrderStatusList, setIsRebuildOrderStatusList] = useState<number>(0);
    const [triggerGetInvoiceList, setTriggerGetInvoiceList] = useState<() => void>(() => () => {});
    const isRecordal = service === SERVICE_TYPES.recordal;
    const isQuoteCreation = viewData?.requestTypeId === MODE.CREATE_QUOTE;
    const isOrder = viewData?.requestTypeId === MODE.CREATE_ORDER;
    const isQuoteToOrder = viewData?.headers?.isQuote === true;
    // Check for user permissions
    const hasBillTaskPermission = AuthStore.hasPermission(Permissions.VIEW_BILL_TASK);
    const hasInvoiceTaskPermission = AuthStore.hasPermission(Permissions.VIEW_INVOICE_TASK);
    const isBothDecideLater = viewData?.headers?.isBothDecideLater;
    const isEPRenewals =
        category === CATEGORY_TYPE.european_patent && service === SERVICE_TYPES.renewals;
    const isPreparingQuote = dropDownValue === RequestStatusEnum.PREPARING_QUOTE;
    const isCanceledQuote = dropDownValue === RequestStatusEnum.CANCELED;
    const isToBeProcessed = dropDownValue === RequestStatusEnum.TO_BE_PROCESSED;
    const isWFA = dropDownValue === RequestStatusEnum.WAITING_FOR_APPROVAL;
    const isCompleted = dropDownValue === RequestStatusEnum.COMPLETED;
    const isInvoiced = dropDownValue === RequestStatusEnum.INVOICED;
    const isShowServicesAccordion =
        isThisStaffUser || isThisVendorUser || (isThisContactUser && !isQuoteCreation);
    const isEPTranslationValidationFiling =
        viewData?.headers?.serviceType === 'EP' &&
        (viewData?.requestDetails?.services === SERVICE_TYPES.translation_only ||
            viewData?.requestDetails?.services === SERVICE_TYPES.translation_and_validation);

    // Request body for country details API for filters and short
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 100
    });

    const [requestDetailsInput, setRequestDetailsInput] = useState({
        patentTitle: {
            isEdit: false,
            isError: false,
            value: viewData?.requestDetails?.patentTitle,
            newValue: viewData?.requestDetails?.patentTitle
        }
    });

    const [additionalInfoInput, setAdditionalInfoInput] = useState({
        contactEmail: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.contactEmail,
            newValue: viewData?.additionalInfo?.contactEmail
        },
        alsoDeliverTo: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.alsoDeliverTo
                ? viewData?.additionalInfo?.alsoDeliverTo?.split(',')
                : [],
            newValue: viewData?.additionalInfo?.alsoDeliverTo
                ? viewData?.additionalInfo?.alsoDeliverTo?.split(',')
                : []
        },
        cc: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.cc ? viewData?.additionalInfo?.cc?.split(',') : [],
            newValue: viewData?.additionalInfo?.cc ? viewData?.additionalInfo?.cc?.split(',') : []
        },
        poNumber: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.poNumber,
            newValue: viewData?.additionalInfo?.poNumber,
            required: viewData?.additionalInfo?.requiredFields?.isPoNumber
        },
        referenceNo: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.referenceNumber,
            newValue: viewData?.additionalInfo?.referenceNumber,
            errorMessage: ''
        },
        projectManagers: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.projectManagers,
            newValue: viewData?.additionalInfo?.projectManagers?.map((item) => item?.id)
        },
        requestCurrency: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.requestCurrency,
            newValue: viewData?.additionalInfo?.requestCurrency
        },
        salesRepresentative: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.salesRepresentative,
            newValue: viewData?.additionalInfo?.salesRepresentative
        },
        invoiceStatus: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.invoiceStatus,
            newValue: viewData?.additionalInfo?.invoiceStatus
        }
    });
    const [dateAndDeadEditInput, setDateAndDeadEditInput] = useState({
        completedAt: { isEdit: false, value: viewData?.dateAndDeadLines?.completedAt },
        createdAt: { isEdit: false, value: viewData?.dateAndDeadLines?.createdAt },
        quoteRequired: { isEdit: false, value: viewData?.dateAndDeadLines?.quoteRequired },
        monthDeadline: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.thirtyMonthDeadLine,
            newValue: viewData?.dateAndDeadLines?.thirtyMonthDeadLine
        },
        fillingDeadLine: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.filingDeadLine,
            newValue: viewData?.dateAndDeadLines?.filingDeadLine
        },
        upDeadLine: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.upDeadLine,
            newValue: viewData?.dateAndDeadLines?.upDeadLine
        },
        europeanFilingDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.europeanFilingDate,
            newValue: viewData?.dateAndDeadLines?.europeanFilingDate
        },
        requestedFillingDeadLine: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.requestedFilingDeadLine,
            newValue: viewData?.dateAndDeadLines?.requestedFilingDeadLine
        },
        statutoryDeadlineDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.statutoryDeadlineDate,
            newValue: viewData?.dateAndDeadLines?.statutoryDeadlineDate
        },
        requestedDeliveryDateForClaimsTranslation: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.requestedDeliveryDateForClaimsTranslation,
            newValue: viewData?.dateAndDeadLines?.requestedDeliveryDateForClaimsTranslation
        },
        validationDeadline: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.validationDeadline,
            newValue: viewData?.dateAndDeadLines?.validationDeadline
        },
        quoteTargetDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.quoteTargetDate,
            newValue: viewData?.dateAndDeadLines?.quoteTargetDate
        },
        requestDeliveryDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.requestedDeliveryDate,
            newValue: viewData?.dateAndDeadLines?.requestedDeliveryDate
        },
        internalDeliveryDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.internalDeliveryDate,
            newValue: viewData?.dateAndDeadLines?.internalDeliveryDate
        }
    });
    const [patentEditInput, setPatentEditInput] = useState({
        abstractWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.abstractWordCount,
            newValue: viewData?.patentCounts?.abstractWordCount
        },
        claimsWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.claimsWordCount,
            newValue: viewData?.patentCounts?.claimsWordCount
        },
        descriptionWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.descriptionWordCount,
            newValue: viewData?.patentCounts?.descriptionWordCount
        },
        patentTitleWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.patentTitleWordCount,
            newValue: viewData?.patentCounts?.patentTitleWordCount
        },
        drawingsPageCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.drawingsPageCount,
            newValue: viewData?.patentCounts?.drawingsPageCount
        },
        drawingsWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.drawingsWordCount,
            newValue: viewData?.patentCounts?.drawingsWordCount
        },
        numberofDrawings: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.numberofDrawings,
            newValue: viewData?.patentCounts?.numberofDrawings
        },
        claimsPageCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.claimsPageCount,
            newValue: viewData?.patentCounts?.claimsPageCount
        },
        descriptionPageCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.descriptionPageCount,
            newValue: viewData?.patentCounts?.descriptionPageCount
        },
        estimatedNumberofTotalPages: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.estimatedNumberofTotalPages,
            newValue: viewData?.patentCounts?.estimatedNumberofTotalPages
        },
        estimatedSequenceListing: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.estimatedSequenceListing === 1 ? 'Yes' : 'No',
            newValue: viewData?.patentCounts?.estimatedSequenceListing === 1 ? 'Yes' : 'No'
        },
        numberofClaims: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.numberofClaims,
            newValue: viewData?.patentCounts?.numberofClaims
        },
        numberofIndependentClaims: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.numberofIndependentClaims,
            newValue: viewData?.patentCounts?.numberofIndependentClaims
        },
        numberofPriorityApplications: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.numberofPriorityApplications,
            newValue: viewData?.patentCounts?.numberofPriorityApplications
        },
        specificationWordCount: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.specificationWordCount,
            newValue: viewData?.patentCounts?.specificationWordCount
        },
        claimsPriority: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.claimsPriority === true ? 'Yes' : 'No',
            newValue: viewData?.patentCounts?.claimsPriority === true ? 'Yes' : 'No'
        },
        specialInstructions: {
            isEdit: false,
            isError: false,
            value: viewData?.patentCounts?.specialInstructions,
            newValue: viewData?.patentCounts?.specialInstructions
        }
    });
    const [instructions, setInstructions] = useState<InstructionType>({
        pmInstruction: {
            isEdit: false,
            isError: false,
            value: viewData?.instructionByProjectManager?.instruction ?? '',
            newValue: viewData?.instructionByProjectManager?.instruction ?? ''
        },
        pmCreatedAt: {
            isEdit: false,
            value: viewData?.instructionByProjectManager?.createdAt ?? ''
        },
        cuInstruction: {
            isEdit: false,
            isError: false,
            value: viewData?.instructionByContactUser?.instruction ?? '',
            newValue: viewData?.instructionByContactUser?.instruction ?? ''
        },
        cuCreatedAt: { isEdit: false, value: viewData?.instructionByContactUser?.createdAt ?? '' }
    });

    const [addInfoResponse, setAddInfoResponse] = useState<any>();
    const [dateDeadlineResponse, setDateDeadlineResponse] = useState<any>();
    const [instructionResponse, setInstructionResponse] = useState<any>();
    const [patentCountResponse, setPatentCountResponse] = useState<any>();
    const [statusResponse, setStatusResponse] = useState<number>(0);
    const [countryEditResponse, setCountryEditResponse] = useState<any>(false);
    const [accordionActive, setAccordianActive] = useState<AccordianType>({
        requestDetails: true,
        additionalInfo: false,
        dateAndDeadline: false,
        patentCount: false,
        countryDetails: false,
        uploadedDocuments: false,
        instructions: false,
        billsInvoice: false,
        languageDetails: false
    });
    const handleAccordion = (fieldName: keyof AccordianType) => {
        setAccordianActive((prevState) => ({
            ...prevState,
            [fieldName]: !prevState[fieldName]
        }));
    };
    const redirectAccordion = (fieldName: any) => {
        setAccordianActive((prevState) => ({
            ...prevState,
            [fieldName]: true
        }));
    };

    const handleEditRequestDetails = (fieldName: string) => {
        setRequestDetailsInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof RequestDetailsInputs],
                isEdit: true
            }
        }));
    };

    const handleChangeRequestDetails = (
        fieldName: string,
        newValue: string | number | string[]
    ) => {
        setRequestDetailsInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof RequestDetailsInputs],
                newValue,
                isError: !newValue
            }
        }));
    };

    // Additional info's onchange and edit functions
    const handleImageClickAdditionalInfo = (fieldName: string) => {
        setAdditionalInfoInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof AdditionalInfoInputs],
                isEdit: true,
                errorMessage: '',
                isError: false
            }
        }));
    };

    const handleChangeAdditionalInfo = (
        fieldName: string,
        newValue: string | number | string[]
    ) => {
        setAdditionalInfoInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof AdditionalInfoInputs],
                newValue,
                isError: additionalInfoEditValidations(fieldName, newValue),
                errorMessage: additionalInfoEditErrorMessages(fieldName, newValue)
            }
        }));
    };

    // Date and Deadlines sections onblur, onchange and edit click handling functions
    const handleImageClickDateAndDeadline = (fieldName: keyof DateAndDeadLinesEditInputs) => {
        setDateAndDeadEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                isEdit: true
            }
        }));
    };
    const handleOnChangeDateAndDeadline = (
        fieldName: keyof DateAndDeadLinesEditInputs,
        value: string
    ) => {
        setDateAndDeadEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue: value || ''
            }
        }));
    };

    // Patent counts sections onblur, onchange and edit click handling functions
    const handlePatentImageClick = (fieldName: keyof PatentCountEditInputs) => {
        setPatentEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                isEdit: true
            }
        }));
    };
    const handleChangePatent = (fieldName: keyof PatentCountEditInputs, newValue: string) => {
        setPatentEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue,
                isError: patentCountsValidation(newValue)
            }
        }));
    };

    // Instructions edit handle
    const instructionEditImageClick = (fieldName: keyof InstructionType) => {
        setInstructions((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                isEdit: true
            }
        }));
    };
    const handleChangeInstruction = (fieldName: keyof InstructionType, value: string) => {
        setInstructions((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue: value || '',
                isError: value ? false : true
            }
        }));
    };

    // handle save/cancel
    const handleSaveWrapper = (value1: string, value2: string) => {
        const result = handleSave(value1, value2);

        if (result instanceof Promise) {
            result.catch((err) => {
                console.error(err);
            });
        }
    };
    const handleSave = async (fieldName: string, section: string) => {
        let body: any;
        let updateFunction: any;
        let setResponse: any;
        let setState: any;
        let stateValues: any;

        switch (section) {
            case 'RequestDetails':
                body = requestDetailsUpdateBody(fieldName, requestDetailsInput);
                updateFunction = updatePatentTitle;
                setResponse = setStatusResponse;
                setState = setRequestDetailsInput;
                stateValues = requestDetailsInput;
                break;
            case 'AdditionalInfo':
                body = additionalInfoUpdateBody(fieldName, additionalInfoInput);
                updateFunction = updateAdditionalInfo;
                setResponse = setAddInfoResponse;
                setState = setAdditionalInfoInput;
                stateValues = additionalInfoInput;
                break;
            case 'DateAndDeadlines':
                body = dateAndDeadlineUpdateBody(fieldName, dateAndDeadEditInput, requestId);
                updateFunction =
                    fieldName !== 'internalDeliveryDate'
                        ? updateDateAndDeadline
                        : updateInternalDeadline;
                setResponse = setDateDeadlineResponse;
                setState = setDateAndDeadEditInput;
                stateValues = dateAndDeadEditInput;
                break;
            case 'Instruction':
                body = instructionUpdateBody(
                    fieldName,
                    instructions,
                    isThisStaffUser || isThisVendorUser
                );
                updateFunction = updateInstruction;
                setResponse = setInstructionResponse;
                setState = setInstructions;
                stateValues = instructions;
                break;
            case 'PatentCounts':
                body = patentCountUpdateBody('edit', patentEditInput);
                updateFunction = updatePatentCounts;
                setResponse = setPatentCountResponse;
                setState = setPatentEditInput;
                stateValues = patentEditInput;
                break;
            default:
                return;
        }

        if (requestId) {
            await handleAPIUpdate(
                updateFunction,
                body,
                requestId,
                setResponse,
                setState,
                stateValues,
                fieldName,
                !isQuoteCreation
            );
        }
    };
    const handleCancel = (fieldName: any, section: string) => {
        switch (section) {
            case 'RequestDetails':
                updateStateOnCancel(setRequestDetailsInput, requestDetailsInput, fieldName);
                break;
            case 'AdditionalInfo':
                updateStateOnCancel(setAdditionalInfoInput, additionalInfoInput, fieldName);
                break;
            case 'DateAndDeadlines':
                updateStateOnCancel(setDateAndDeadEditInput, dateAndDeadEditInput, fieldName);
                break;
            case 'Instruction':
                updateStateOnCancel(setInstructions, instructions, fieldName);
                break;
            case 'PatentCounts':
                updateStateOnCancel(setPatentEditInput, patentEditInput, fieldName);
                break;
            default:
                break;
        }
    };

    // API call for getting order details based on selected order Id
    const getOrderDetailsAPI = async () => {
        if (requestId) {
            try {
                const response = await getOrderDetails<ViewOrderType>(requestId, isUpcOptOut);
                setViewData(response);
                setCompanyId(response?.headers?.companyId);
                setCategory(response?.requestDetails?.category);
                setService(response?.requestDetails?.services);
                setRequestDetailsInput((prevState) => ({
                    ...prevState,
                    patentTitle: {
                        isEdit: false,
                        isError: false,
                        value: response?.requestDetails?.patentTitle,
                        newValue: response?.requestDetails?.patentTitle
                    }
                }));
                setAdditionalInfoInput((prevState) => ({
                    ...prevState,
                    contactEmail: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.contactEmail,
                        newValue: response?.additionalInfo?.contactEmail
                    },
                    alsoDeliverTo: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.alsoDeliverTo
                            ? response?.additionalInfo?.alsoDeliverTo?.split(',')
                            : [],
                        newValue: response?.additionalInfo?.alsoDeliverTo
                            ? response?.additionalInfo?.alsoDeliverTo?.split(',')
                            : []
                    },
                    cc: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.cc
                            ? response?.additionalInfo?.cc?.split(',')
                            : [],
                        newValue: response?.additionalInfo?.cc
                            ? response?.additionalInfo?.cc?.split(',')
                            : []
                    },
                    poNumber: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.poNumber,
                        newValue: response?.additionalInfo?.poNumber,
                        required: response?.additionalInfo?.requiredFields?.isPoNumber
                    },
                    referenceNo: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.referenceNumber,
                        newValue: response?.additionalInfo?.referenceNumber,
                        errorMessage: ''
                    },
                    projectManagers: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.projectManagers,
                        newValue: response?.additionalInfo?.projectManagers?.map((item) => item?.id)
                    },
                    requestCurrency: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.requestCurrency,
                        newValue: response?.additionalInfo?.requestCurrency
                    },
                    salesRepresentative: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.salesRepresentative,
                        newValue: response?.additionalInfo?.salesRepresentative
                    },
                    invoiceStatus: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.invoiceStatus,
                        newValue: response?.additionalInfo?.invoiceStatus
                    }
                }));
                setDateAndDeadEditInput((prevState) => ({
                    ...prevState,
                    completedAt: { isEdit: false, value: response?.dateAndDeadLines?.completedAt },
                    createdAt: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.createdAt,
                        newValue: response?.dateAndDeadLines?.createdAt
                    },
                    fillingDeadLine: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.filingDeadLine,
                        newValue: response?.dateAndDeadLines?.filingDeadLine
                    },
                    requestedFillingDeadLine: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.requestedFilingDeadLine,
                        newValue: response?.dateAndDeadLines?.requestedFilingDeadLine
                    },
                    statutoryDeadlineDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.statutoryDeadlineDate,
                        newValue: response?.dateAndDeadLines?.statutoryDeadlineDate
                    },
                    requestedDeliveryDateForClaimsTranslation: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines
                            ?.requestedDeliveryDateForClaimsTranslation,
                        newValue:
                            response?.dateAndDeadLines?.requestedDeliveryDateForClaimsTranslation
                    },
                    validationDeadline: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.validationDeadline,
                        newValue: response?.dateAndDeadLines?.validationDeadline
                    },
                    monthDeadline: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.thirtyMonthDeadLine,
                        newValue: response?.dateAndDeadLines?.thirtyMonthDeadLine
                    },
                    internalDeliveryDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.internalDeliveryDate,
                        newValue: response?.dateAndDeadLines?.internalDeliveryDate
                    },
                    quoteRequired: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.quoteRequired,
                        newValue: response?.dateAndDeadLines?.quoteRequired
                    },
                    upDeadLine: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.upDeadLine,
                        newValue: response?.dateAndDeadLines?.upDeadLine
                    },
                    europeanFilingDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.europeanFilingDate,
                        newValue: response?.dateAndDeadLines?.europeanFilingDate
                    },
                    quoteTargetDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.quoteTargetDate,
                        newValue: response?.dateAndDeadLines?.quoteTargetDate
                    },
                    requestDeliveryDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.requestedDeliveryDate,
                        newValue: response?.dateAndDeadLines?.requestedDeliveryDate
                    }
                }));
                setPatentEditInput((prevState) => ({
                    ...prevState,
                    abstractWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.abstractWordCount,
                        newValue: response?.patentCounts?.abstractWordCount
                    },
                    claimsWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.claimsWordCount,
                        newValue: response?.patentCounts?.claimsWordCount
                    },
                    descriptionWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.descriptionWordCount,
                        newValue: response?.patentCounts?.descriptionWordCount
                    },
                    drawingsPageCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.drawingsPageCount,
                        newValue: response?.patentCounts?.drawingsPageCount
                    },
                    drawingsWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.drawingsWordCount,
                        newValue: response?.patentCounts?.drawingsWordCount
                    },
                    patentTitleWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.patentTitleWordCount,
                        newValue: response?.patentCounts?.patentTitleWordCount
                    },
                    numberofDrawings: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.numberofDrawings,
                        newValue: response?.patentCounts?.numberofDrawings
                    },
                    claimsPageCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.claimsPageCount,
                        newValue: response?.patentCounts?.claimsPageCount
                    },
                    descriptionPageCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.descriptionPageCount,
                        newValue: response?.patentCounts?.descriptionPageCount
                    },
                    estimatedNumberofTotalPages: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.estimatedNumberofTotalPages,
                        newValue: response?.patentCounts?.estimatedNumberofTotalPages
                    },
                    estimatedSequenceListing: {
                        isEdit: false,
                        isError: false,
                        value:
                            response?.patentCounts?.estimatedSequenceListing === 1 ? 'Yes' : 'No',
                        newValue:
                            response?.patentCounts?.estimatedSequenceListing === 1 ? 'Yes' : 'No'
                    },
                    numberofClaims: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.numberofClaims,
                        newValue: response?.patentCounts?.numberofClaims
                    },
                    numberofIndependentClaims: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.numberofIndependentClaims,
                        newValue: response?.patentCounts?.numberofIndependentClaims
                    },
                    numberofPriorityApplications: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.numberofPriorityApplications,
                        newValue: response?.patentCounts?.numberofPriorityApplications
                    },
                    specificationWordCount: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.specificationWordCount,
                        newValue: response?.patentCounts?.specificationWordCount
                    },
                    claimsPriority: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.claimsPriority === true ? 'Yes' : 'No',
                        newValue: response?.patentCounts?.claimsPriority === true ? 'Yes' : 'No'
                    },
                    specialInstructions: {
                        isEdit: false,
                        isError: false,
                        value: response?.patentCounts?.specialInstructions,
                        newValue: response?.patentCounts?.specialInstructions
                    }
                }));
                setInstructions((prevState) => ({
                    ...prevState,
                    pmInstruction: {
                        isEdit: false,
                        isError: false,
                        value: response?.instructionByProjectManager?.instruction ?? '',
                        newValue: response?.instructionByProjectManager?.instruction ?? ''
                    },
                    pmCreatedAt: {
                        isEdit: false,
                        value: response?.instructionByProjectManager?.createdAt ?? ''
                    },
                    cuInstruction: {
                        isEdit: false,
                        isError: false,
                        value: response?.instructionByContactUser?.instruction ?? '',
                        newValue: response?.instructionByContactUser?.instruction ?? ''
                    },
                    cuCreatedAt: {
                        isEdit: false,
                        value: response?.instructionByContactUser?.createdAt ?? ''
                    },
                    customDisclaimer: {
                        isEdit: false,
                        isError: false,
                        value: response?.customDisclaimer || '',
                        newValue: response?.customDisclaimer || ''
                    }
                }));
                setDropDownValue(response?.headers?.statusName);
                setOrderOrQuoteId(response?.headers?.requestId);
                setPrimaryIdForAzureStorage(response?.headers?.referenceFolderId);
            } catch (error) {
                console.error(error);
                showToastMessage(
                    t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_QUOTE_AND_ORDER_DETAILS'),
                    ToastType.ERROR
                );
            }
        }
    };

    const getCountryDetailsAPI = async () => {
        if (requestId && !isUpcOptOut) {
            if (isEPTranslationValidationFiling && isQuoteCreation && (isWFA || isPreparingQuote)) {
                return getEpUpCountryDetailsAPI();
            } else if (isBothDecideLater !== true) {
                try {
                    const response: ResponseCountryList =
                        await getCountryDetails<ResponseCountryList>(requestId, requestBody);

                    if (
                        Array.isArray(response.orderViewCountryModel) &&
                        response?.orderViewCountryModel?.length > 0
                    ) {
                        if (
                            viewData?.headers.isUP === true &&
                            viewData?.headers.isClaims71_3 === false
                        ) {
                            const transformResponse = prepareUpTableDate(
                                response.orderViewCountryModel
                            );
                            response.orderViewCountryModel = transformResponse;
                        }
                        setCountryData(response);
                    } else {
                        setCountryData({
                            orderViewCountryModel: [],
                            total: 0
                        });
                    }
                } catch (error) {
                    console.error(error);
                    showToastMessage(
                        t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_COUNTRY_LIST'),
                        ToastType.ERROR
                    );
                }
            }
        }
    };
    const prepareUpTableDate = (rows: CountryAndLanguageDetailModel[] | null) => {
        const response = rows?.reduce(
            (
                acc: {
                    agencyFee: CountryAndLanguageDetailModel[];
                    translationFee: CountryAndLanguageDetailModel[];
                },
                item: CountryAndLanguageDetailModel
            ) => {
                // countryId 0 means translation fee row and country id is null or zero for that row
                // and countryId > 0 means agency fee row and country name available for those rows
                if ((item.countryId ?? 0) === 0) {
                    acc.translationFee.push(item);
                } else {
                    acc.agencyFee.push(item);
                }
                return acc;
            },
            { agencyFee: [], translationFee: [] }
        );
        const countryNames = (response?.agencyFee as CountryAndLanguageDetailModel[])
            .map((s) => s.countryName)
            .join(',');
        const upValue: CountryAndLanguageDetailModel = {
            sourceLanguageId: response?.agencyFee[0]?.sourceLanguageId ?? null,
            sourceLanguageName: response?.agencyFee[0]?.sourceLanguageName ?? null,
            languageId: response?.translationFee[0]?.languageId ?? null,
            countryId: response?.agencyFee[0]?.countryId ?? null,
            countryName: countryNames,
            officialLanguage: response?.translationFee[0]?.officialLanguage ?? null,
            agencyFee: response?.agencyFee[0]?.agencyFee ?? 0,
            officialFee: response?.agencyFee[0]?.officialFee ?? 0,
            translationFee: response?.translationFee[0]?.translationFee ?? 0,
            total:
                (response?.agencyFee[0]?.agencyFee ?? 0) +
                (response?.translationFee[0]?.translationFee ?? 0),
            instantQuote: null,
            iconName: null,
            up: true,
            ep: null,
            isClaim: null,
            includeAgencyFee: null,
            includeOfficialFee: null,
            includeTranslationFee: null
        };
        return [upValue];
    };

    const getEpUpCountryDetailsAPI = async () => {
        if (requestId) {
            try {
                const response: CountryAndLanguageDetailsResponse =
                    await getEpUpCountryDetails<CountryAndLanguageDetailsResponse>(requestId);
                const context: CountryAndLanguageDetails = {
                    claimsTranslationList: response.claimsTranslationList,
                    upList: response.upList,
                    epList: response.epList,
                    nonUpList: response.nonUpList,
                    currencySymbol: viewData?.additionalInfo?.requestCurrency ?? null,
                    viewData: viewData ?? null,
                    setCountryEditResponse: null,
                    countryEditResponse: false
                };
                setupEpUpCountryList(context);
            } catch (error) {
                console.error(error);
                showToastMessage(
                    t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_COUNTRY_LIST'),
                    ToastType.ERROR
                );
            }
        }
    };
    const getStatusList = async () => {
        try {
            const response = await getRequestStatusList<StatusType[]>();
            setStatusList(response);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_REQUEST_STATUS_LIST'),
                ToastType.ERROR
            );
        }
    };

    // helpers
    function statusRerender() {
        setStatusResponse(statusResponse + 1);
    }
    function rebuildOrderStatusList() {
        setIsRebuildOrderStatusList(isRebuildOrderStatusList + 1);
    }

    // side effects
    useEffect(() => {
        if (requestId) {
            getOrderDetailsAPI();
            getCountryDetailsAPI();
            getStatusList();
        } else {
            navigate('/orders-quotes');
        }
    }, [
        dateDeadlineResponse,
        addInfoResponse,
        instructionResponse,
        statusResponse,
        countryEditResponse
    ]);
    useEffect(() => {
        if (requestId) {
            if (patentCountResponse) {
                getOrderDetailsAPI();
                getCountryDetailsAPI();
                getStatusList();
            }
        } else {
            navigate('/orders-quotes');
        }
    }, [patentCountResponse, countryEditResponse]);
    useEffect(() => {
        if (requestId) {
            getCountryDetailsAPI();
        } else {
            navigate('/orders-quotes');
        }
    }, [requestBody]);
    useEffect(() => {
        // store updated for stepper edit flow
        const quoteOrderData: QuoteOrderModuleStore = quoteOrderModuleStore.getData();
        const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
            ...quoteOrderData.info,
            primaryId: viewData?.headers?.requestId as number, // store this id as 'PrimaryId' to access the edit-API.
            mode: viewData?.requestTypeId as number,
            isEditFlow: true,
            statusId: viewData?.headers?.statusId as number
        };
        if (JSON.stringify(quoteOrderData.info) !== JSON.stringify(updatedQuoteOrderInfo)) {
            quoteOrderModuleStore.updatePage('info', updatedQuoteOrderInfo);
        }
    }, [viewData, countryData]);
    useEffect(() => {
        // reset the store, when user land on this page.
        stepperStore.resetStepperStore();
        quoteOrderModuleStore.resetQuoteOrderStore();
    }, []);
    useEffect(() => {
        setIsPatentCountError(checkPatentCountsError);
    }, [patentEditInput]);

    useEffect(() => {
        getCountryDetailsAPI();
    }, [isBothDecideLater]);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const checkPatentCountsError = () => {
        const keys = Object.keys(patentEditInput) as (keyof PatentCountEditInputs)[];
        for (const key of keys) {
            if (patentEditInput[key]?.isError) {
                return true;
            }
        }
        return false;
    };
    const allowEdits = () => {
        return (
            (isThisStaffExcludedFinance || isThisVendorExcludedFinance) &&
            (viewData?.headers.statusId === STATUS_MODE.PREPARING_QUOTE ||
                viewData?.headers.statusId === STATUS_MODE.WAITING_FOR_APPROVAL ||
                viewData?.headers.statusId === STATUS_MODE.TO_BE_PROCESSED)
        );
    };

    const [visible, setVisible] = useState<boolean>(false);
    const [pdfUrl, setPdfUrl] = useState<string>('');
    const templateName: string = viewData?.requestDetails?.serviceUniqueName || '';
    const requestIdData = viewData?.headers?.requestId;
    const requestTypeIP = viewData?.requestType;
    const isIP = requestTypeIP === IP_NONIP.ip;

    const headerRef = useRef<ViewOrderAndQuoteHeaderRef>(null);
    const isShowApproveQuoteButton = () => {
        const isShow: boolean =
            isQuoteToOrder &&
            (isThisStaffUser || isThisVendorUser || isThisContactUser) &&
            isWFA &&
            // (isPreparingQuote || isWFA) &&
            // !isToBeProcessed &&

            /** check permission */
            (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                AuthStore.hasPermission(Permissions.EDIT_ORDER));

        return isShow;
    };
    const isShowCancelButton = () => {
        const isShow: boolean =
            isQuoteToOrder &&
            (isSalesRep(loggedInUserRoleId) || isContactUser(loggedInUserRoleId)) &&
            isWFA &&
            /** check permission */
            (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                AuthStore.hasPermission(Permissions.EDIT_ORDER));

        return isShow;
    };

    const downloadPDF = async () => {
        try {
            const response = await getPDFData(
                templateName,
                requestIdData as number,
                undefined,
                undefined,
                undefined,
                isUpcOptOut
            );
            setPdfUrl(response);
            if (response) {
                setVisible(true);
            }
        } catch (error) {
            showToastMessage(t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'), ToastType.ERROR);
        }
    };

    const CheckAndBindEPOrUpCategoryTab = (serviceType: string) => {
        switch (serviceType) {
            case 'EP':
                return (
                    (viewData?.headers?.serviceType === 'EP' &&
                        isBothDecideLater !== true &&
                        isUP === false) ||
                    isBothDecideLater === true
                );
            case 'UP':
                return (
                    (viewData?.headers?.serviceType === 'EP' &&
                        isBothDecideLater !== true &&
                        isUP === true) ||
                    isBothDecideLater === true
                );
            default:
                return false;
        }
    };
    const downloadPDFData = async (
        pdfPreviewTemplateName: string,
        isUPTemplate: boolean,
        isDownload?: boolean
    ) => {
        try {
            if (isDownload === null) {
                isDownload = false;
            }
            const response = await getPDFData(
                pdfPreviewTemplateName,
                requestIdData as number,
                isUPTemplate,
                viewData?.headers.requestId,
                true
            );
            if (isDownload === false) {
                setPdfUrl(response);

                if (response) {
                    setVisible(true);
                }
            } else {
                const link = document.createElement('a');
                link.href = response;

                link.download =
                    viewData?.requestDetails?.serviceUniqueName +
                    '' +
                    (viewData?.headers.requestId + '') +
                    (isUPTemplate ? '-UP' : '-EP') +
                    '.pdf';
                link.click();
            }
        } catch (error) {
            showToastMessage(t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'), ToastType.ERROR);
        }
    };

    // Function to get the title based on role and permissions
    const getPanelTitle = (): string => {
        // Determine the title based on role and permissions
        if (!isThisContactUser) {
            if (hasBillTaskPermission && hasInvoiceTaskPermission) {
                return t('QUOTE_AND_ORDER.BILLS_AND_INVOICE');
            }
            if (hasInvoiceTaskPermission) {
                return t('MENU.INVOICES');
            }
            return t('MENU.BILLS');
        }

        return t('COMMON.SERVICES');
    };
    const showToastMessages = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };

    const exportToExcel = async (
        templateKey: string,
        referenceNo: number,
        fileName: string,
        isBothDecideLaterProp?: boolean
    ) => {
        try {
            await OrdersAndQuotesService.exportExcel(
                templateKey,
                referenceNo,
                fileName,
                isBothDecideLaterProp,
                isUpcOptOut
            );
        } catch (error) {
            showToastMessages({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_EXPORT_EXCEL'),
                type: ToastType.ERROR
            });
        }
    };

    return (
        <>
            <Dialog
                pt={previewDialogPopup}
                header={
                    <div className="w-full flex justify-between items-center">
                        {(isQuoteCreation ? t('COMMON.QUOTE') + ' - ' : t('COMMON.ORDER') + ' - ') +
                            (viewData?.headers?.requestNumber ?? 'Preview')}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(
                                    pdfUrl,
                                    (isQuoteCreation
                                        ? t('COMMON.QUOTE') + ' - '
                                        : t('COMMON.ORDER') + ' - ') +
                                        (viewData?.headers?.requestNumber ?? 'Preview')
                                )
                            }
                        />
                    </div>
                }
                visible={visible}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>

            <TopNavigationStep
                backNavigationPath="/orders-quotes"
                steps={[
                    {
                        label: t('COMMON.ORDERS_QUOTES'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: '/orders-quotes'
                    },
                    {
                        label: viewData?.headers?.requestNumber ?? '',
                        isCurrent: true,
                        isPrevious: false,
                        labelName: isOrder ? t('COMMON.ORDER') : t('COMMON.QUOTE'),
                        module: 'ORDER_QUOTE',
                        isCopyable: true
                    }
                ]}
            />

            <div data-testid="view-order-Page" className="px-3">
                <div className="sticky top-0 z-[9] bg-neutral-bg-50">
                    <div className="md:py-1 mt-3" data-testid="view-order-header">
                        <ViewOrderAndQuoteHeader
                            ref={headerRef}
                            orderInsights={
                                viewData?.headers ?? {
                                    grossProfitPercentage: 0 /* other required fields with default values */
                                }
                            }
                            statusList={statusList}
                            state={state}
                            requestNumber={requestId ?? ''}
                            setDropDownValue={setDropDownValue}
                            dropDownValue={dropDownValue}
                            currencySymbol={viewData?.additionalInfo?.requestCurrency ?? ''}
                            requestType={viewData?.requestType ?? ''}
                            setStatusResponse={statusRerender}
                            viewData={viewData}
                            isQuoteCreation={isQuoteCreation}
                            isRebuildOrderStatusList={isRebuildOrderStatusList}
                        />
                    </div>
                    <div className="hidden md:block py-2.5">
                        <div className="flex items-center px-3 py-2 w-full bg-white border-neutral-50 border-2 rounded-lg">
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#request-detail-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() =>
                                    redirectAccordion('requestDetails')
                                }>{`${t('COMMON.REQUEST_DETAILS')}`}</a>
                            {separatorLine()}
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#additional-info-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => redirectAccordion('additionalInfo')}>
                                {t('ADDITIONAL_INFO.TITLE')}
                            </a>
                            {separatorLine()}
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#date-deadlines-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => redirectAccordion('dateAndDeadline')}>
                                {t('DATE_AND_DEADLINES.TITLE')}
                            </a>
                            {separatorLine()}
                            {!isNonIp &&
                                (isThisStaffUser || isThisVendorUser) &&
                                !isRecordal &&
                                !isEPRenewals &&
                                !isUpcOptOut && (
                                    <>
                                        <a
                                            className=" text-[1.083rem] font-medium text-primary mx-2"
                                            href="#patent-count-container"
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            onClick={() => redirectAccordion('patentCount')}>
                                            {t('PATENT_DETAILS.PATENT_COUNTS')}
                                        </a>
                                        {separatorLine()}
                                    </>
                                )}
                            {!isNonIp && (isThisStaffUser || isThisVendorUser) && !isUpcOptOut && (
                                <>
                                    <a
                                        className=" text-[1.083rem] font-medium text-primary mx-2"
                                        href="#country-details-container"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => redirectAccordion('countryDetails')}>
                                        {t('QUOTE_AND_ORDER.COUNTRY_DETAILS')}
                                    </a>
                                    {separatorLine()}
                                </>
                            )}
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#uploaded-documents-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => redirectAccordion('uploadedDocuments')}>
                                {t('QUOTE_AND_ORDER.UPLOAD_DOCUMENTS')}
                            </a>
                            {separatorLine()}
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#instruction-comments-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => redirectAccordion('instructions')}>
                                {t('COMMON.INSTRUCTIONS_AND_COMMENTS')}
                            </a>
                            {isShowServicesAccordion &&
                                (hasBillTaskPermission || hasInvoiceTaskPermission) && (
                                    <>
                                        {separatorLine()}

                                        <a
                                            className=" text-[1.083rem] font-medium text-primary mx-2"
                                            href="#bills-invoices-container"
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            onClick={() => redirectAccordion('billsInvoice')}>
                                            {getPanelTitle()}
                                        </a>
                                    </>
                                )}
                            <div className="flex items-center gap-3 ml-auto">
                                {isShowCancelButton() && (
                                    <div className="hidden lg:inline ml-auto">
                                        {
                                            <button
                                                className="btn border-secondary text-secondary hover:bg-secondary/5 hover:border-secondary h-9 min-h-9"
                                                onClick={() =>
                                                    headerRef.current?.approveOrCancelButtonClick(
                                                        false
                                                    )
                                                }>
                                                {t('QUOTE_AND_ORDER.CANCEL_QUOTE')}
                                            </button>
                                        }
                                    </div>
                                )}

                                {isShowApproveQuoteButton() && (
                                    <div className="hidden lg:inline ml-auto">
                                        {
                                            <button
                                                className="btn button-primary h-9 min-h-9"
                                                onClick={() =>
                                                    headerRef.current?.approveOrCancelButtonClick(
                                                        true
                                                    )
                                                }>
                                                {t('QUOTE_AND_ORDER.APPROVE_QUOTE')}
                                            </button>
                                        }
                                    </div>
                                )}

                                <Actions
                                    isApproveButtonVisible={isShowApproveQuoteButton()}
                                    editButton={{
                                        isVisible:
                                            !(isPreparingQuote && isThisContactUser) &&
                                            isQuoteCreation &&
                                            !isToBeProcessed &&
                                            isBothDecideLater !== true &&
                                            !isCanceledQuote &&
                                            !isUpcOptOut &&
                                            (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                                                AuthStore.hasPermission(Permissions.EDIT_ORDER)),
                                        onClick: () =>
                                            navigate(
                                                `/${PATHS.ORDER_QUOTE}/${PATHS.EDIT}/${PATHS.SERVICE_TYPE}`
                                            )
                                    }}
                                    previewButton={{
                                        isVisible:
                                            isBothDecideLater !== true &&
                                            isQuoteToOrder &&
                                            isIP &&
                                            !isPreparingQuote,
                                        onClick: () => void downloadPDF()
                                    }}
                                    epEditButton={{
                                        isVisible:
                                            isShowApproveQuoteButton() &&
                                            isBothDecideLater === true &&
                                            isQuoteCreation &&
                                            !isCanceledQuote,
                                        onClick: () =>
                                            navigate(
                                                `/${PATHS.ORDER_QUOTE}/${PATHS.EDIT}/${PATHS.SERVICE_TYPE}`
                                            )
                                    }}
                                    epBothDecidePreviewButton={{
                                        isVisible: isBothDecideLater === true && isQuoteCreation,
                                        uponClick: () =>
                                            void downloadPDFData(
                                                'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                                true,
                                                false
                                            ),
                                        nationalValidationClick: () =>
                                            void downloadPDFData(
                                                'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                                false,
                                                false
                                            )
                                    }}
                                    epBothDecideExportButton={{
                                        isVisible: isBothDecideLater === true && isQuoteCreation,
                                        pdfClick() {
                                            void downloadPDFData(
                                                'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                                true,
                                                true
                                            );
                                            void downloadPDFData(
                                                'EP_713Claims_Translation_Validation_Filing_EP_UP',
                                                false,
                                                true
                                            );
                                        },
                                        excelClick: () =>
                                            void exportToExcel(
                                                viewData?.requestDetails?.serviceUniqueName + '',
                                                viewData?.headers.requestId || 0,
                                                (viewData?.requestTypeId === MODE.CREATE_QUOTE
                                                    ? t('COMMON.QUOTE') + ' - '
                                                    : t('COMMON.ORDER') + ' - ') +
                                                    viewData?.headers.requestNumber ||
                                                    ('' as string),
                                                true
                                            )
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="w-full overflow-x-hidden overflow-scroll xl:max-h-[calc(100vh-230px)] 2xl:max-h-[calc(100vh-261px)] 4xl:max-h-[calc(100vh-305px)] pb-4">
                    <div>
                        <div className="grid gap-y-1 md:grid md:gap-y-2">
                            <div
                                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg overflow-visible`}
                                id="request-detail-container">
                                <input
                                    type="checkbox"
                                    className="py-1 min-h-0"
                                    name="my-accordion-2"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => handleAccordion('requestDetails')}
                                    checked={accordionActive?.requestDetails}
                                />
                                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                                    <span className=" text-xl font-medium text-primary">
                                        {t('COMMON.REQUEST_DETAILS')}
                                    </span>
                                </div>
                                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                    <RequestDetailsPage
                                        requestDetails={viewData?.requestDetails} // whole response
                                        category={category}
                                        service={service}
                                        viewData={viewData}
                                        editInput={requestDetailsInput}
                                        handleEdit={handleEditRequestDetails}
                                        handleChange={handleChangeRequestDetails}
                                        handleSave={handleSaveWrapper}
                                        handleCancel={handleCancel}
                                    />
                                </div>
                            </div>
                            <div
                                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                                id="additional-info-container">
                                <input
                                    type="checkbox"
                                    className="py-1 min-h-0"
                                    name="my-accordion-2"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => handleAccordion('additionalInfo')}
                                    checked={accordionActive?.additionalInfo}
                                />
                                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                    <span className=" text-xl font-medium text-primary">
                                        {t('ADDITIONAL_INFO.TITLE')}
                                    </span>
                                </div>
                                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                    <AdditionalInfoPage
                                        editInput={additionalInfoInput}
                                        handleImageClick={handleImageClickAdditionalInfo}
                                        handleChange={handleChangeAdditionalInfo}
                                        handleSave={handleSaveWrapper}
                                        handleCancel={handleCancel}
                                        companyId={companyId ?? 0}
                                        statuses={{
                                            isCompleted,
                                            isInvoiced,
                                            isPreparingQuote,
                                            isToBeProcessed,
                                            isWFA
                                        }}
                                    />
                                </div>
                            </div>

                            <div
                                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                                id="date-deadlines-container">
                                <input
                                    type="checkbox"
                                    className="py-1 min-h-0"
                                    name="my-accordion-2"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => handleAccordion('dateAndDeadline')}
                                    checked={accordionActive?.dateAndDeadline}
                                />
                                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                    <span className=" text-xl font-medium text-primary">
                                        {t('DATE_AND_DEADLINES.TITLE')}
                                    </span>
                                </div>
                                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                    <DateAndDeadlinesPage
                                        editInput={dateAndDeadEditInput}
                                        handleImageClick={handleImageClickDateAndDeadline}
                                        handleChange={handleOnChangeDateAndDeadline}
                                        handleSaveAI={handleSave}
                                        handleCancelAI={handleCancel}
                                        category={category}
                                        service={service}
                                        viewData={viewData}
                                        contactUser={isThisContactUser}
                                    />
                                </div>
                            </div>

                            {(isThisStaffUser || isThisVendorUser) &&
                                !isRecordal &&
                                !isEPRenewals &&
                                !isUpcOptOut && (
                                    <div
                                        className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                                        id="patent-count-container">
                                        <input
                                            type="checkbox"
                                            className="py-1 min-h-0"
                                            name="my-accordion-2"
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            onClick={() => handleAccordion('patentCount')}
                                            checked={accordionActive?.patentCount}
                                        />

                                        <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                            <span className=" text-xl font-medium text-primary">
                                                {t('PATENT_DETAILS.PATENT_COUNTS')}
                                            </span>
                                        </div>
                                        <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                            {!patentCountEdit && allowEdits() && (
                                                <div className="flex justify-end mt-3">
                                                    <button
                                                        data-testid="editPatentCounts"
                                                        className="btn button-primary-outline min-h-[2rem] h-[2rem] !font-medium w-18"
                                                        onKeyDown={(e) =>
                                                            e.key === 'Enter' &&
                                                            e.currentTarget.click()
                                                        }
                                                        onClick={() => setPatentCountEdit(true)}>
                                                        <i className="pi pi-pencil h-3 w-3"></i>
                                                        <span>{t('COMMON.EDIT')}</span>
                                                    </button>
                                                </div>
                                            )}
                                            {patentCountEdit && (
                                                <div className={`flex justify-end mt-3`}>
                                                    <button
                                                        className={`btn button-neutral min-h-[2rem] h-[2rem] !font-medium w-18 ml-3`}
                                                        onKeyDown={(e) =>
                                                            e.key === 'Enter' &&
                                                            e.currentTarget.click()
                                                        }
                                                        onClick={() => {
                                                            setPatentEditInput((prevState) => ({
                                                                ...prevState,
                                                                abstractWordCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.abstractWordCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.abstractWordCount
                                                                },
                                                                claimsWordCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.claimsWordCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.claimsWordCount
                                                                },
                                                                descriptionWordCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.descriptionWordCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.descriptionWordCount
                                                                },
                                                                drawingsPageCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.drawingsPageCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.drawingsPageCount
                                                                },
                                                                drawingsWordCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.drawingsWordCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.drawingsWordCount
                                                                },
                                                                numberofDrawings: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.numberofDrawings,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.numberofDrawings
                                                                },
                                                                claimsPageCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.claimsPageCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.claimsPageCount
                                                                },
                                                                descriptionPageCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.descriptionPageCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.descriptionPageCount
                                                                },
                                                                estimatedNumberofTotalPages: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.estimatedNumberofTotalPages,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.estimatedNumberofTotalPages
                                                                },
                                                                estimatedSequenceListing: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value:
                                                                        viewData?.patentCounts
                                                                            ?.estimatedSequenceListing ===
                                                                        1
                                                                            ? 'Yes'
                                                                            : 'No',
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.estimatedSequenceListing ===
                                                                        1
                                                                            ? 'Yes'
                                                                            : 'No'
                                                                },
                                                                numberofClaims: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.numberofClaims,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.numberofClaims
                                                                },
                                                                numberofIndependentClaims: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.numberofIndependentClaims,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.numberofIndependentClaims
                                                                },
                                                                numberofPriorityApplications: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.numberofPriorityApplications,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.numberofPriorityApplications
                                                                },
                                                                specificationWordCount: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.specificationWordCount,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.specificationWordCount
                                                                },
                                                                claimsPriority: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value:
                                                                        viewData?.patentCounts
                                                                            ?.claimsPriority ===
                                                                        true
                                                                            ? 'Yes'
                                                                            : 'No',
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.claimsPriority ===
                                                                        true
                                                                            ? 'Yes'
                                                                            : 'No'
                                                                },
                                                                specialInstructions: {
                                                                    isEdit: false,
                                                                    isError: false,
                                                                    value: viewData?.patentCounts
                                                                        ?.specialInstructions,
                                                                    newValue:
                                                                        viewData?.patentCounts
                                                                            ?.specialInstructions
                                                                }
                                                            }));
                                                            setPatentCountEdit(false);
                                                        }}>
                                                        <span>{t('COMMON.CANCEL')}</span>
                                                    </button>
                                                    <button
                                                        disabled={isPatentCountError ? true : false}
                                                        onKeyDown={(e) =>
                                                            e.key === 'Enter' &&
                                                            e.currentTarget.click()
                                                        }
                                                        className={`btn bg-primary-200 text-white min-h-[2rem] h-[2rem] hover:bg-primary-200 hover:text-white !font-medium w-18 ml-4`}
                                                        onClick={() => {
                                                            handleSave('', 'PatentCounts').then(
                                                                () => setPatentCountEdit(false)
                                                            );
                                                        }}>
                                                        <span>{t('COMMON.RECALCULATE')}</span>
                                                    </button>
                                                </div>
                                            )}
                                            <PatentCountsPage
                                                editInput={patentEditInput}
                                                handleImageClick={handlePatentImageClick}
                                                // handleBlur={handleBlurPatent}
                                                handleChange={handleChangePatent}
                                                // handleSaveAI={handleSaveAI}
                                                // handleCancelAI={handleCancelAI}
                                                viewData={viewData}
                                                requestDetails={viewData?.requestDetails}
                                                patentCountEdit={patentCountEdit}
                                                disablePatentFields={{
                                                    /** 'estimatedSequenceListing' is should be disable on 'WaitingForApproval' status. */
                                                    estimatedSequenceListing: isWFA,
                                                    patentTitleWordCount: !isThisPMOrAdminUser
                                                }}
                                                loggedInUserId={loggedInUserRoleId}
                                            />
                                        </div>
                                    </div>
                                )}

                            {!isNonIp && (isThisStaffUser || isThisVendorUser) && !isUpcOptOut && (
                                <div
                                    className={`collapse collapse-arrow relative bg-white border-neutral-50 border-2 rounded-lg`}
                                    id="country-details-container">
                                    <input
                                        type="checkbox"
                                        className="py-1 min-h-0"
                                        name="my-accordion-2"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => handleAccordion('countryDetails')}
                                        checked={accordionActive?.countryDetails}
                                    />
                                    <div
                                        className="flex collapse-title text-lg py-2.5 min-h-0 after:h-[11px] 
                                        after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 items-center gap-2">
                                        <div className=" text-xl font-medium text-primary">
                                            {t('QUOTE_AND_ORDER.COUNTRY_DETAILS')}
                                        </div>
                                        {isOrder &&
                                            !viewData?.headers?.isClaims71_3 &&
                                            isUP === false &&
                                            viewData?.requestDetails?.services ===
                                                SERVICE_TYPES.translation_and_validation &&
                                            !viewData?.headers?.requestNumber.includes('EP') &&
                                            viewData.hasOrderCostUpdated && (
                                                <div
                                                    data-testid="nonUpPatentWarningLabel"
                                                    className="mt-2">
                                                    <span
                                                        className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1
                                  bg-orange-50 border-2 rounded-md border-orange-100">
                                                        <i className="pi pi-info-circle text-yellow-500 mt-px"></i>
                                                        <span className="md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                                                            {t(
                                                                'SELECT_EP_COUNTRY.CHECK_ASSOCIATED_UP_CASE_FOR_UPDATES'
                                                            )}
                                                        </span>
                                                    </span>
                                                </div>
                                            )}
                                        {isOrder &&
                                            !viewData?.headers?.isClaims71_3 &&
                                            viewData.headers.isUP === true &&
                                            viewData?.requestDetails?.services ===
                                                SERVICE_TYPES.translation_and_validation &&
                                            viewData.hasOrderCostUpdated && (
                                                <div
                                                    data-testid="upPatentWarningLabel"
                                                    className="mt-2">
                                                    <span
                                                        className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1
                                  bg-orange-50 border-2 rounded-md border-orange-100">
                                                        <i className="pi pi-info-circle text-yellow-500 mt-px"></i>
                                                        <span className="md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                                                            {t(
                                                                'SELECT_EP_COUNTRY.CHECK_ASSOCIATED_NON_UP_CASE_FOR_UPDATES'
                                                            )}
                                                        </span>
                                                    </span>
                                                </div>
                                            )}
                                    </div>
                                    <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                        <div className="absolute top-2 right-16 z-20">
                                            <p>
                                                {'isEPOrder' + !isUP &&
                                                    !viewData?.headers?.isClaims71_3 &&
                                                    viewData?.headers?.requestNumber.includes('EP')}
                                            </p>
                                            {isOrder &&
                                                !viewData?.headers?.isClaims71_3 &&
                                                viewData?.headers?.serviceType === 'EP' && (
                                                    <EpCountryOrderEdit
                                                        viewData={viewData}
                                                        data-testId="ep-country-order-edit"
                                                        orderId={orderOrQuoteId}
                                                        draftId={primaryIdForAzureStorage}
                                                        isUpOrder={isUP}
                                                        isEPOrder={
                                                            !isUP &&
                                                            !viewData?.headers?.isClaims71_3 &&
                                                            viewData?.headers?.requestNumber.includes(
                                                                'EP'
                                                            )
                                                        }
                                                        setCountryEditResponse={
                                                            setCountryEditResponse
                                                        }
                                                        countryEditResponse={countryEditResponse}
                                                        isNoEnglishTranslation={
                                                            viewData?.existingPatentCounts
                                                                ?.sourceLanguageCode !==
                                                            PATENT_SOURCE_LANGUAGE.ENGLISH
                                                        }
                                                    />
                                                )}
                                        </div>
                                        {isEPTranslationValidationFiling &&
                                        isQuoteCreation &&
                                        accordionActive?.countryDetails ? (
                                            <EpUpCountryDetailsPage
                                                data-testId="ep-up-country-details-page"
                                                currencySymbol={epUpCountryList.currencySymbol}
                                                viewData={viewData}
                                                upList={
                                                    CheckAndBindEPOrUpCategoryTab('UP')
                                                        ? epUpCountryList.upList
                                                        : null
                                                }
                                                nonUpList={
                                                    CheckAndBindEPOrUpCategoryTab('UP')
                                                        ? epUpCountryList.nonUpList
                                                        : null
                                                }
                                                epList={
                                                    CheckAndBindEPOrUpCategoryTab('EP')
                                                        ? epUpCountryList.epList
                                                        : []
                                                }
                                                claimsTranslationList={
                                                    epUpCountryList.claimsTranslationList
                                                }
                                                setCountryEditResponse={setCountryEditResponse}
                                                countryEditResponse={
                                                    countryEditResponse
                                                }></EpUpCountryDetailsPage>
                                        ) : (
                                            <CountryDetailsPage
                                                countryDetails={countryData}
                                                handleFilter={handleFilter}
                                                sortHandler={sortHandler}
                                                requestBody={requestBody}
                                                currencySymbol={
                                                    viewData?.additionalInfo?.currencySymbol || ''
                                                }
                                                category={category}
                                                service={service}
                                                viewData={viewData}
                                                setCountryEditResponse={setCountryEditResponse}
                                                countryEditResponse={countryEditResponse}
                                            />
                                        )}
                                    </div>
                                </div>
                            )}

                            <div
                                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg overflow-visible`}
                                id="uploaded-documents-container">
                                <input
                                    type="checkbox"
                                    className="py-1 min-h-0"
                                    name="my-accordion-2"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => handleAccordion('uploadedDocuments')}
                                    checked={accordionActive?.uploadedDocuments}
                                />
                                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                    <span className=" text-xl font-medium text-primary">
                                        Uploaded Documents
                                    </span>
                                </div>
                                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5 max-w-full overflow-auto">
                                    <UploadedDocuments
                                        orderOrQuoteId={orderOrQuoteId}
                                        primaryIdForAzureStorage={primaryIdForAzureStorage}
                                        viewData={viewData}
                                        flags={{ isCompleted, isInvoiced }}
                                        triggerGetOrderDetails={() => {
                                            void getOrderDetailsAPI();
                                        }}
                                        triggerGetInvoiceList={() => {
                                            setTriggerGetInvoiceList(() => () => {});
                                        }}
                                    />
                                </div>
                            </div>

                            <div
                                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                                id="instruction-comments-container">
                                <input
                                    type="checkbox"
                                    className="py-1 min-h-0"
                                    name="my-accordion-2"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => handleAccordion('instructions')}
                                    checked={accordionActive?.instructions}
                                />
                                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                    <span className=" text-xl font-medium text-primary">
                                        {t('COMMON.INSTRUCTIONS_AND_COMMENTS')}
                                    </span>
                                </div>
                                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                    <InstructionsAndComments
                                        instructionData={instructions}
                                        instructionEditImageClick={instructionEditImageClick}
                                        handleSaveAI={handleSaveWrapper}
                                        handleCancelAI={handleCancel}
                                        handleChange={handleChangeInstruction}
                                        viewData={viewData}
                                        isEditable={!isCompleted && !isInvoiced}
                                    />
                                </div>
                            </div>
                            {isShowServicesAccordion &&
                                (hasBillTaskPermission || hasInvoiceTaskPermission) && (
                                    <div
                                        className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                                        id="bills-invoices-container">
                                        <input
                                            type="checkbox"
                                            className="py-1 min-h-0"
                                            name="my-accordion-2"
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            onClick={() => handleAccordion('billsInvoice')}
                                            checked={accordionActive?.billsInvoice}
                                        />
                                        <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                                            <span className=" text-xl font-medium text-primary">
                                                {getPanelTitle()}
                                            </span>
                                        </div>
                                        <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                                            <BillsAndInvoices
                                                {...{
                                                    viewData,
                                                    getOrderDetailsAPI,
                                                    patentCountResponse,
                                                    countryEditResponse,
                                                    rebuildOrderStatusList,
                                                    triggerGetInvoiceList
                                                }}
                                            />
                                        </div>
                                    </div>
                                )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ViewOrderAndQuotePage;
