import {
    Company,
    ContactUser
} from 'pages/createOrderAndQuote/components/companyDetails/types/companyDetails.type';
import { ServiceAndCategoryType } from 'pages/createOrderAndQuote/components/serviceType/types/serviceType.type';
import { SelectCountryData } from 'pages/orders/selectCountry/types/country.type';
import { CountryAndLanguageDetailModel } from '../components/countryDetails/epUpCountryDetails';

export interface RequestDetailsType {
    patentTitle: string;
    category: string;
    services: string;
    patentApplicationNumber: string | null;
    patentPublicationNumber: string;
    sourceLanguage: string;
    applicant: string;
    referenceNumber: string | null;
    salesRepresentative: string | null;
    monthDeadline30: string | null;
    filingDeadLine: string | null;
    isUp?: boolean | null;
    serviceUniqueName?: string;
}

interface RequiredFields {
    isPoNumber: boolean;
}
export interface AdditionalInfo {
    contactEmail: string;
    alsoDeliverTo: string;
    cc: string;
    poNumber: string;
    referenceNumber: string | null;
    requestCurrency: string;
    requestCurrencyId: number;
    invoiceStatus: string | null;
    salesRepresentative: string | null;
    projectManagers: { id: number; name: string }[];
    currencySymbol?: string;
    requiredFields: RequiredFields;
}

export interface DateAndDeadLines {
    requestedDeliveryDate: string | null;
    quoteRequired: boolean | null;
    quoteTargetDate: string | null;
    createdAt: string;
    completedAt: string | null;
    thirtyMonthDeadLine: string | null;
    europeanFilingDate: string | null;
    upDeadLine: string | null;
    filingDeadLine: string | null;
    requestedFilingDeadLine: string | null;
    statutoryDeadlineDate: string | null;
    validationDeadline: string | null;
    requestedDeliveryDateForClaimsTranslation: string | null;
    internalDeliveryDate: string | null;
}

export interface PatentCounts {
    claimsPageCount: any;
    descriptionPageCount: any;
    estimatedNumberofTotalPages: any;
    estimatedSequenceListing?: number | null;
    numberofClaims: any;
    numberofIndependentClaims: any;
    numberofPriorityApplications: any;
    specificationWordCount: any;
    abstractWordCount: number;
    descriptionWordCount: number;
    claimsWordCount: number;
    numberofDrawings: number;
    drawingsPageCount: number;
    drawingsWordCount: number;
    claimsPriority: boolean | null;
    specialInstructions: string | null;
    requestedBy: string | null;
    salesRepresentative: string | null;
    sourceLanguageCode: string | null;
    patentTitleWordCount: number | null;
}

interface CountryDetail {
    country: string | null;
    sourceLanguage: string;
    instantQuote: number | null;
    officialLanguage: string;
    agencyFee: number;
    officialFee: number;
    translationFee: number;
    total: number;
}

export interface InstructionTypes {
    instruction?: string;
    createdAt?: string;
    summaryComments?: string;
}
export interface HeaderType {
    requestId: number;
    requestType: string;
    requestNumber: string;
    statusName: string;
    statusId: number;
    companyId: number;
    companyName: string;
    userId: number;
    userName: string;
    totalAmout?: string;
    referenceFolderId: number;
    isQuote?: boolean;
    isUP?: boolean | null;
    isClaims71_3?: boolean | null;
    grossProfitPercentage: number;
    stdPreviewType: string;
    isBothDecideLater?: boolean;
    epUpGrandTotalModel: EpUpGrandTotalModel;
    serviceType?: string;
}

export interface ViewOrderType {
    additionalInfo: AdditionalInfo;
    countryDetails?: CountryDetail;
    patentCounts: PatentCounts;
    existingPatentCounts: PatentCounts;
    dateAndDeadLines: DateAndDeadLines;
    requestDetails: RequestDetailsType;
    instructionByContactUser: InstructionTypes;
    instructionByProjectManager: InstructionTypes;
    headers: HeaderType;
    requestType?: string;
    requestTypeId: number | null;
    patentCategory: number | null;
    customDisclaimerSTD: string | null;
    customDisclaimer: string | null;
    stdPreviewType?: string;
    hasOrderCostUpdated: boolean | null;
    upcOptOutPatentNumbers: {
        patentNumber: string;
        isValid: boolean;
    }[];
}

export interface EditInput {
    isEdit: boolean;
    value: string;
}

// interface CCInput {
//     isEdit: boolean;
//     value: { id: number; name: string }[];
// }

interface CCInputs {
    isEdit: boolean;
    isError: boolean;
    value: { id: number; name: string }[];
    newValue: { id: number; name: string }[];
}

export interface EditInputs {
    isEdit: boolean;
    isError: boolean;
    value: string;
    newValue: string;
}

export interface RequestDetailsInputs {
    patentTitle: EditInputs;
}
export interface AdditionalInfoInputs {
    contactEmail: EditInputs;
    alsoDeliverTo: EditInputs;
    cc: CCInputs;
    poNumber: EditInputs;
    referenceNo: EditInputs;
    requestCurrency: EditInputs;
    invoiceStatus: EditInputs;
    salesRepresentative: EditInputs;
    projectManagers: CCInputs;
}
export interface PatentCountEditInputs {
    abstractWordCount: EditInputs;
    claimsWordCount: EditInputs;
    descriptionWordCount: EditInputs;
    drawingsPageCount: EditInputs;
    drawingsWordCount: EditInputs;
    numberofDrawings: EditInputs;
    claimsPageCount: EditInputs;
    descriptionPageCount: EditInputs;
    estimatedNumberofTotalPages: EditInputs;
    estimatedSequenceListing: EditInputs;
    numberofClaims: EditInputs;
    numberofIndependentClaims: EditInputs;
    numberofPriorityApplications: EditInputs;
    specificationWordCount: EditInputs;
}

export interface DateAndDeadLinesEditInputs {
    completedAt: EditInput;
    createdAt: EditInput;
    monthDeadline: EditInput;
    quoteRequired: EditInput;
    quoteTargetDate: EditInputs;
    requestDeliveryDate: EditInputs;
    internalDeliveryDate: EditInputs;
}

export interface ResponseCountryList {
    orderViewCountryModel: CountryAndLanguageDetailModel[];
    total: number | null;
}
export interface CountryDataType {
    sourceLanguageId: number;
    sourceLanguageName: string;
    countryName: string | null;
    officialLanguage: string;
    instantQuote: string;
    countryId: number | null;
    languageId: number;
    agencyFee: number | null;
    officialFee: number | null;
    translationFee: number | null;
    total: number | null;
}

export interface InstructionType {
    pmInstruction: EditInputs;
    pmCreatedAt: EditInput;
    cuInstruction: EditInputs;
    cuCreatedAt: EditInput;
    customDisclaimer?: EditInputs;
}

export type StatusType = {
    id: number;
    name: string;
    statusType: number;
};

export interface UploadedDocumentType {
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    viewData: any;
    flags?: { [key: string]: boolean };
    triggerGetOrderDetails?: () => void;
    triggerGetInvoiceList?: () => void;
}

export interface SourceDocumentData {
    id: number;
    documentId: number;
    fileName: string;
    fileType: string;
    uploadedOn: string;
    documentType: string;
    fileId: number;
    fileSize: string;
    uploadedBy: string;
    wordCount: number | null;
    reCall?: boolean;
}

export interface SourceDocumentsResponse {
    orderSourceDocumentsModel?: SourceDocumentData[];
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    total?: number;
    blobUri?: string;
    flags?: { [key: string]: boolean };
    viewData?: any;
    triggerGetOrderDetails?: () => void;
    triggerGetInvoiceList?: () => void;
}

export interface OfficialReceiptsDocumentsResponse {
    orderOfficialReceiptDocumentsModel?: SourceDocumentData[];
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    total?: number;
    blobUri?: string;
    flags?: { [key: string]: boolean };
    viewData?: any;
    triggerGetOrderDetails?: () => void;
}

export interface VendorInvoiceDocumentsData {
    id: number;
    documentId: number;
    fileName: string;
    uploadedOn: string;
    documentType: string;
    fileId: number;
    fileSize: string;
    fileType: string;
    uploadedBy: string;
}

export interface VendorInvoiceDocumentsResponse {
    vendorDocumentsModel?: VendorInvoiceDocumentsData[];
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    total?: number;
    blobUri?: string;
}

export interface DocumentUploadPopupType {
    closeModal: (data: any) => void;
    onSubmit: (data: any) => void;
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    isNonIp?: boolean;
    upcOptOutUploadedFile?: (file: File) => void;
}

export interface FiledDocumentsType {
    orderFiledDocumentsModel?: FiledDocumentsTypeResponse[];
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    total?: number;
    blobUri?: string;
    viewData: any;
    isNonIp?: boolean;
    isEditable?: boolean;
    flags?: { [key: string]: boolean };
}

export interface FiledDocumentsTypeResponse {
    id: number;
    documentId: number;
    fileName: string;
    taskId: string;
    targetCountry: string;
    targetLanguage: string;
    targetLanguageId: any;
    taskName: any;
    taskrefId: number;
    statusId: any;
    targetLanguageName: any;
    blobFileName: string;
    targetCountryId: any;
    targetCountryName: any;
    documentType: number;
    documentTypes: string;
    documentStatus: number;
    documentStatusName: string;
    document: any;
    uploadedOn: string;
    expectedDeliveryDate: string;
    vendorName: any;
    fileId: number;
    fileSize: string;
    uploadedBy: string;
    reCall: boolean;
    reCallDate: Date | null;
}
export interface FiledDocumentTaskIdDropDownType {
    id: number;
    message?: string;
    taskId: string;
}

export interface FiledDocumentCountryDropDownType {
    countryId: number;
    countryName: string;
}

export interface TaskDocumentStatusType {
    id: number;
    name: string;
    color?: string;
    backgroundColor?: string;
}

export interface FormalDocumentsType {
    orderFormalDocumentsModel?: FormalDocumentsResponse[];
    orderOrQuoteId: number;
    primaryIdForAzureStorage: number;
    total?: number;
    blobUri?: string;
    onSubmit?: (data: any) => void;
    flags?: { [key: string]: boolean };
}

export interface FormalDocumentsResponse {
    id: number;
    documentId: number;
    fileName: string;
    uploadedOn: string;
    documentType: number;
    uplaoded: number;
    fileSize: string;
    blobFileName: string;
    disPatchAddress?: any;
    fileType: string;
    uploadedBy: string;
    targetCountry?: string;
    fileId: number;
    taskrefId: number;
    targetCountryId?: number;
    poAStatusId: number;
    hardCopy?: boolean;
    hardCopyStatusId: number;
    expectedDeliveryDate?: string;
    documentTypes: string;
    status?: any;
    hardCopyStatus?: string;
    airwayNo?: string;
    hardCopyValues?: string;
    iconName: string;
}

export interface FormalDocumentCountryListType {
    id: number;
    countryName: string;
    countryId: number;
}

export interface FormalDocumentStatusType {
    id: number;
    name: string;
    color?: string;
    backgroundColor?: string;
}

export interface DocumentType {
    id: number;
    name: string;
    moduleType: number;
    labelName: string;
    displayOrder: number;
}

export interface FormalDocumentHardCopyStatusType {
    id: number;
    name: string;
    color?: string;
    backgroundColor?: string;
}

export interface FormalDocumentUploadFieldsType {
    dateTime: string;
    ifHardCopyYesOrNo: string;
    dispatchAddress: string;
}

export interface AccordianType {
    requestDetails: boolean;
    additionalInfo: boolean;
    dateAndDeadline: boolean;
    patentCount: boolean;
    countryDetails: boolean;
    uploadedDocuments: boolean;
    instructions: boolean;
    billsInvoice: boolean;
    languageDetails: boolean;
}

export interface OrderQuoteEditDataType {
    moduleData: ViewOrderType;
    countryData: any;
    serviceAndCategory: ServiceAndCategoryType[];
    companyList: Company[];
    contactUserList: ContactUser[];
    countryList: SelectCountryData[];
}

export interface ListForEditFlow {
    serviceAndCategory: ServiceAndCategoryType[];
    companyList: Company[];
    contactUserList: ContactUser[];
    countryList: SelectCountryData[];
}

export interface LanguageDetails {
    FileName: string;
    SourceLanguage: string;
    TargetLanguages: string;
    DeliveryDate: string;
}

export interface InvoiceTaskStatusModal {
    id: number;
    taskRefId: number;
    taskId: string;
    taskName: string;
    taskDescription: string | null;
    taskStatus: string;
    sourceLanguage: string;
    targetLanguage: string;
    targetCountry: string;
    grandTotal: number;
    baseCurrencyAmount: number;
    showInInvoice: boolean;
    requestCurrencyAmount: number;
    requestCurrencySymbol: string;
    baseCurrencySymbol: string;
    requestCurrencyName: string;
    invoiceId: number;
}

export interface OtherTasksResponseModal {
    [key: string]: string;
}

export interface OtherTasksModal {
    categoryKey: string;
    categoryName: string;
    taskIds: string;
}

export interface TasksStatusListModal {
    invoiceTasks: InvoiceTaskStatusModal[];
    otherTasks: OtherTasksResponseModal;
    otherTasksList: OtherTasksModal[];
}

export interface EpUpGrandTotalModel {
    epTotal: number | null;
    upTotal: number | null;
}
export interface EPSaveAmountModel {
    amount: number;
    percentage: number;
}
