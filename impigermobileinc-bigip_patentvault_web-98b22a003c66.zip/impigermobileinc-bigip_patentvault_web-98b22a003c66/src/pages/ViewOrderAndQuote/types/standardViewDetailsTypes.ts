import { AllLanguageResponseType } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import {
    HeaderType,
    AdditionalInfo,
    EditInput,
    EditInputs,
    InstructionTypes
} from './viewDetailsTypes';

export interface StandardRequestDetailsType {
    patentTitle: string;
    requestedDeliveryDate: string | null;
    quoteDatetime: string | null;
    referenceNumber: string | null;
    category: string;
    categoryDisplayText: string;
    service: string;
}

export interface DateAndDeadLines {
    requestedDeliveryDate: string; // ISO date string
    quoteDatetime: string; // ISO date string
    isQuote: boolean;
    createdAt: string; // ISO date string
    completedAt: string | null; // ISO date string or null
    turnAroundTime: string | null;
    internalDeliveryDate: string | null; // ISO date string or null
}

export interface StandardViewOrderType {
    requestDetails: StandardRequestDetailsType;
    additionalInfo: AdditionalInfo;
    headers: HeaderType;
    requestType: string;
    requestTypeId: number | null;
    dateAndDeadLines: DateAndDeadLines;
    instructionByContactUser: InstructionTypes;
    instructionByProjectManager: InstructionTypes;
    customDisclaimerSTD: string | null;
    stdPreviewType: string;
}

export const InitDefaultStandardViewOrderType: StandardViewOrderType = {
    requestDetails: {
        patentTitle: '',
        requestedDeliveryDate: null,
        quoteDatetime: null,
        referenceNumber: null,
        category: '',
        categoryDisplayText: '',
        service: ''
    },
    additionalInfo: {} as AdditionalInfo,
    headers: {} as HeaderType,
    requestType: '',
    requestTypeId: null,
    dateAndDeadLines: {
        requestedDeliveryDate: '',
        quoteDatetime: '',
        isQuote: false,
        createdAt: '',
        completedAt: null,
        turnAroundTime: null,
        internalDeliveryDate: null
    },
    stdPreviewType: '',
    instructionByContactUser: {
        instruction: '',
        instructionType: '',
        instructionBy: '',
        instructionDate: null,
        instructionTime: null,
        instructionByContactUser: ''
    } as InstructionTypes,
    instructionByProjectManager: {
        instruction: '',
        instructionType: '',
        instructionBy: '',
        instructionDate: null,
        instructionTime: null,
        instructionByContactUser: ''
    } as InstructionTypes,
    customDisclaimerSTD: ''
};

export interface StandardDateAndDeadLinesEditInputs {
    completedAt: EditInput;
    createdAt: EditInput;
    quoteTargetDate: EditInputs;
    requestDeliveryDate: EditInputs;
}

export interface StandardAccordionType {
    requestDetails: boolean;
    additionalInfo: boolean;
    uploadedDocuments: boolean;
    billsInvoice: boolean;
    dateAndDeadlines: boolean;
    instructions: boolean;
}

export interface StandardViewDocumentType {
    Id: number;
}

export interface Task {
    taskId: string;
    taskNumber: number;
    shownInvendor: boolean;
    documentMappingId: number;
}

export interface DocumentDetail {
    documentNumber: string;
    orderId: number;
    documentId: number;
    fileName: string;
    blobFileName: string;
    fileType: string;
    fileSize: string;
    blobUrl: string;
    sectionId: number;
    documentType: number;
    documentTypeName: string;
    uploadAction: string | null;
    shownInVendor: boolean | null;
    notes: string;
    sourceLanguageId: number | null;
    targetLanguageId: number | null;
    sourceLanguageName: string;
    targetLanguageName: string;
    task: Task[];
    taskIds: string[] | null | JSX.Element[];
}

export interface DocumentSectionDetails {
    sectionId: number;
    sourceLanguageIds: number[];
    targetLanguageIds: number[];
    sourceLanguages: string;
    targetLanguages: string;
}
export interface ValidateTargetLanguageInputModel {
    targetLanguageIds: number[];
    orderId: number;
    documentId: number;
}

export interface ManageLanguageSaveModel {
    sourceLanguageIds: number[];
    targetLanguageId: number[];
    orderId: number;
    documentId: number;
}

export interface ManageDocumentProps {
    orderId: number;
    documentId: number;
    documentSectionDetails: DocumentSectionDetails;
    languageList: AllLanguageResponseType[];
    modifiedList: number[];
}
export interface DocumentGroup extends DocumentSectionDetails {
    documentDetails: DocumentDetail[];
}
export interface DocumentDetailsResponse {
    orderId: number;
    requestType: string;
    primaryIdForAzureStorage: number;
    documentDetails: DocumentGroup[];
    blobUri: string;
    documentRowValueChangeEvent(): void;
    functions: {
        getStandardDetailsAPI: () => void;
        getDocumentAndLanguagesList: () => void;
    };
    flags: { [key: string]: boolean };
}

export interface TaskListToReorderModel {
    taskId: number;
    taskName: string;
    taskDescription: string;
    quantity: number;
    rate: number;
    amount: number;
    sequenceNumber: number;
}
export interface SaveTaskListToReorderModel {
    orderId: number;
    reOrderViewModel: TaskListToReorderModel[];
}
