import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { RequestStatusEnum, statusIndicators } from 'shared/dataTable/constant/dataTable.constant';
import { StatusType } from '../types/viewDetailsTypes';
import tick from 'assets/svgs/tick.svg';
import close from 'assets/svgs/close-icon.svg';
import { t } from 'i18next';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';
import { STATUS_MODE } from 'constants/app.constant';

export function renderLabel(label: string, className = 'font-medium text-neutral-700 leading-6') {
    return (
        <label data-testId={label} className={className}>
            {label}
        </label>
    );
}

export const showToastMessage = (toastMsg: string, errorType: ToastType) => {
    const message: notificationModel = {
        message: toastMsg,
        type: errorType
    };
    NotificationStore.showAlert(message);
};

// Function used to filter status drop down options
// export const getStatusOptions = (dropDownValue: string, statusList: StatusType[]) => {
//     let options: any = [];

//     const preparingQuoteIds = [1, 2, 3, 4, 5, 6, 7];
//     const waitingForApproval = [2, 3, 4, 5, 6, 7];
//     const toBeProcessedIds = [3, 4, 5, 6, 7];
//     const inProgressIds = [4, 5, 6, 7];
//     const cancelOnHoldIds = [5, 6, 7];
//     const completedIds = [7, 8];
//     const invoiced = [8];

//     switch (dropDownValue) {
//         case RequestStatusEnum.PREPARING_QUOTE:
//             options = statusList?.filter((item) => preparingQuoteIds.includes(item.id));
//             break;
//         case RequestStatusEnum.WAITING_FOR_APPROVAL:
//             options = statusList?.filter((item) => waitingForApproval.includes(item.id));
//             break;
//         case RequestStatusEnum.TO_BE_PROCESSED:
//             options = statusList?.filter((item) => toBeProcessedIds.includes(item.id));
//             break;
//         case RequestStatusEnum.IN_PROGRESS:
//             options = statusList?.filter((item) => inProgressIds.includes(item.id));
//             break;
//         case RequestStatusEnum.CANCELED:
//             options = statusList?.filter((item) => cancelOnHoldIds.includes(item.id));
//             break;
//         case RequestStatusEnum.ON_HOLD:
//             options = statusList?.filter((item) => cancelOnHoldIds.includes(item.id));
//             break;
//         case RequestStatusEnum.COMPLETED:
//             options = statusList?.filter((item) => completedIds.includes(item.id));
//             break;
//         case RequestStatusEnum.INVOICED:
//             options = statusList?.filter((item) => invoiced.includes(item.id));
//             break;
//         default:
//             break;
//     }
//     return options;
// };

// Function used to filter status drop down options
type getStatusDisabledOptionsType = {
    dropDownValue: string;
    statusList: StatusType[];
    orderRequestId: number;
    currentStatusId: number | null;
    isStatusChangedFromOnHoldInQuoteMode?: boolean;
    isAnyTaskAssignedToVendor: boolean;
};
export const getStatusDisabledOptions = ({
    dropDownValue,
    statusList,
    isStatusChangedFromOnHoldInQuoteMode = false,
    isAnyTaskAssignedToVendor = false
}: getStatusDisabledOptionsType) => {
    let options: any = [];

    // 1. Preparing Quote	2. Waiting For Approval
    // 3. To Be Processed	4. In Progress
    // 5. Canceled			6. On Hold
    // 7. Completed			8. Invoiced

    const preparingQuoteIds = [
        STATUS_MODE.WAITING_FOR_APPROVAL,
        STATUS_MODE.CANCELED,
        STATUS_MODE.ON_HOLD
    ];
    const waitingForApproval = [
        STATUS_MODE.TO_BE_PROCESSED,
        STATUS_MODE.CANCELED,
        STATUS_MODE.ON_HOLD
    ];
    const toBeProcessedIds = [
        STATUS_MODE.IN_PROGRESS,
        STATUS_MODE.CANCELED,
        STATUS_MODE.ON_HOLD,
        STATUS_MODE.COMPLETED,
        STATUS_MODE.INVOICED
    ];
    const inProgressIds = [
        STATUS_MODE.CANCELED,
        STATUS_MODE.ON_HOLD,
        STATUS_MODE.COMPLETED,
        STATUS_MODE.INVOICED
    ];
    const completedIds = [STATUS_MODE.COMPLETED, STATUS_MODE.INVOICED];
    const invoiced = [STATUS_MODE.CANCELED];
    const cancelIds = [STATUS_MODE.ON_HOLD];
    // on hold
    const conditionalOnHoldIds = isStatusChangedFromOnHoldInQuoteMode
        ? []
        : [isAnyTaskAssignedToVendor ? STATUS_MODE.IN_PROGRESS : STATUS_MODE.TO_BE_PROCESSED];
    const onHoldIds = [...conditionalOnHoldIds, STATUS_MODE.CANCELED];

    switch (dropDownValue) {
        case RequestStatusEnum.PREPARING_QUOTE:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: preparingQuoteIds.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.WAITING_FOR_APPROVAL:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: checkOptionStatusForWaitingForApproval(item.id, waitingForApproval),
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.TO_BE_PROCESSED:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: toBeProcessedIds.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.IN_PROGRESS:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: inProgressIds.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.CANCELED:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: checkOptionStatusForOnCancel(item.id, cancelIds),
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.ON_HOLD:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: onHoldIds.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.COMPLETED:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: completedIds.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        case RequestStatusEnum.INVOICED:
            options = statusList?.map((item) => ({
                label: item?.name,
                value: item?.name,
                disabled: invoiced.includes(item.id) ? false : true,
                ...statusIndicators(item?.name)
            }));
            break;
        default:
            break;
    }
    return options;
};

function checkOptionStatusForWaitingForApproval(id: number, waitingForApprovalIds: number[]) {
    return waitingForApprovalIds.includes(id) && AuthStore.hasPermission(Permissions.APPROVE_QUOTE)
        ? false
        : true;
}
function checkOptionStatusForOnCancel(id: number, onCancelIds: number[]) {
    return onCancelIds.includes(id) ? false : true;
}

export const editActionsIcons = (
    handleSaveAI: (value1: string, value2: string) => Promise<void> | void,
    handleCancelAI: (value1: string, value2: string) => void,
    fieldName: string,
    section: string,
    isError: boolean = false
) => {
    return (
        <div className="flex items-center justify-center">
            <div
                className="h-7 w-7 ml-3 shadow-md shadow-gray-200 rounded-lg flex items-center justify-center"
                onClick={() => {
                    if (!isError) {
                        handleSaveAI(fieldName, section);
                    }
                }}
                onKeyDown={(e) => {
                    if (!isError && (e.key === 'Enter' || e.key === ' ')) {
                        handleSaveAI(fieldName, section);
                    }
                }}
                tabIndex={0}>
                <img className="cursor-pointer h-3" src={tick} />
            </div>
            <div
                className="h-7 w-7 ml-3  shadow-md shadow-gray-200 rounded-lg flex items-center justify-center"
                onClick={() => {
                    handleCancelAI(fieldName, section);
                }}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        handleCancelAI(fieldName, section);
                    }
                }}
                tabIndex={0}>
                <img className="cursor-pointer h-3 " src={close} />
            </div>
        </div>
    );
};

export const requestDetailsUpdateBody = (fieldName: string, requestDetailsInput: any) => {
    return {
        patentTitle:
            fieldName === 'patentTitle'
                ? requestDetailsInput?.patentTitle?.newValue
                : requestDetailsInput?.patentTitle?.value
    };
};

export const additionalInfoUpdateBody = (fieldName: string, additionalInfoInput: any) => {
    const projectManagersData =
        fieldName === 'projectManagers'
            ? additionalInfoInput?.projectManagers?.newValue
                  ?.map((item: any) => `${item}`)
                  .join(',')
            : additionalInfoInput?.projectManagers?.value
                  ?.map((item: any) => `${item?.id}`)
                  .join(',');
    const alsoDeliverToData =
        fieldName === 'alsoDeliverTo'
            ? additionalInfoInput?.alsoDeliverTo?.newValue?.map((item: any) => `${item}`).join(',')
            : additionalInfoInput?.alsoDeliverTo?.value?.map((item: any) => `${item}`).join(',');
    const ccEditData = additionalInfoInput?.cc?.newValue?.map((item: any) => `${item}`).join(',');
    return {
        contactEmail:
            fieldName === 'contactEmail'
                ? additionalInfoInput?.contactEmail?.newValue
                : additionalInfoInput?.contactEmail?.value,
        alsoDeliverTo: alsoDeliverToData,
        cc:
            fieldName === 'cc'
                ? ccEditData
                : additionalInfoInput?.cc?.value?.map((item: any) => `${item}`).join(','),
        poNumber:
            fieldName === 'poNumber'
                ? additionalInfoInput?.poNumber?.newValue
                : additionalInfoInput?.poNumber?.value,
        referenceNumber:
            fieldName === 'referenceNo'
                ? additionalInfoInput?.referenceNo?.newValue
                : additionalInfoInput?.referenceNo?.value,
        requestCurrencyId: 1,
        statusId: 1,
        salesRepresentative: additionalInfoInput?.salesRepresentative?.value,
        projectManagers: projectManagersData
    };
};

function toISOFormat(date: any) {
    const year = date?.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}T00:00:00`;
}

export const dateAndDeadlineUpdateBody = (
    fieldName: string,
    dateAndDeadlineInput: any,
    orderId?: any
) => {
    const result: any = {};
    result.orderId = orderId;
    switch (fieldName) {
        case 'statutoryDeadlineDate':
            result.statutoryDeadlineDate =
                toISOFormat(dateAndDeadlineInput?.statutoryDeadlineDate?.newValue) ||
                dateAndDeadlineInput?.statutoryDeadlineDate?.value;
            break;
        case 'requestedDeliveryDateForClaimsTranslation':
            result.requestedDeliveryDateForClaimsTranslation =
                toISOFormat(
                    dateAndDeadlineInput?.requestedDeliveryDateForClaimsTranslation?.newValue
                ) || dateAndDeadlineInput?.requestedDeliveryDateForClaimsTranslation?.value;
            break;
        case 'requestDeliveryDate':
            result.requestedDeliveryDate =
                toISOFormat(dateAndDeadlineInput?.requestDeliveryDate?.newValue) ||
                dateAndDeadlineInput?.requestDeliveryDate?.value;
            break;
        case 'quoteRequired':
            result.quoteRequired = dateAndDeadlineInput?.quoteRequired?.value;
            break;
        case 'quoteTargetDate':
            result.quoteTargetDate =
                toISOFormat(dateAndDeadlineInput?.quoteTargetDate?.newValue) ||
                dateAndDeadlineInput?.quoteTargetDate?.value;
            break;
        case 'validationDeadline':
            result.validationDeadline =
                toISOFormat(dateAndDeadlineInput?.validationDeadline?.newValue) ||
                dateAndDeadlineInput?.validationDeadline?.value;
            break;
        case 'upDeadLine':
            result.upDeadLine =
                toISOFormat(dateAndDeadlineInput?.upDeadLine?.newValue) ||
                dateAndDeadlineInput?.upDeadLine?.value;
            break;
        case 'monthDeadline':
            result.thirtyMonthyDeadLine =
                toISOFormat(dateAndDeadlineInput?.monthDeadline?.newValue) ||
                dateAndDeadlineInput?.monthDeadline?.value;
            break;
        case 'europeanFilingDate':
            result.europeanFilingDate =
                toISOFormat(dateAndDeadlineInput?.europeanFilingDate?.newValue) ||
                dateAndDeadlineInput?.europeanFilingDate?.value;
            break;
        case 'fillingDeadLine':
            result.filingDate =
                toISOFormat(dateAndDeadlineInput?.fillingDeadLine?.newValue) ||
                dateAndDeadlineInput?.fillingDeadLine?.value;
            break;
        case 'createdAt':
            result.createdAt = dateAndDeadlineInput?.createdAt?.value;
            break;
        case 'completedAt':
            result.completedAt = dateAndDeadlineInput?.completedAt?.value;
            break;
        case 'turnAroundTime':
            result.turnAroundTime = dateAndDeadlineInput?.turnAroundTime?.newValue;
            break;
        case 'internalDeliveryDate':
            // result.orderId=dateAndDeadlineInput?.orderId?.value;
            result.internalDeliveryDate =
                toISOFormat(dateAndDeadlineInput?.internalDeliveryDate?.newValue) ||
                dateAndDeadlineInput?.internalDeliveryDate?.value;
            break;
        default:
            break;
    }

    return result;
};

export const instructionUpdateBody = (
    fieldName: string,
    instruction: any,
    hasPermission: boolean
) => {
    let instructionBody;

    switch (fieldName) {
        case 'pmInstruction':
            instructionBody = {
                instruction: instruction?.pmInstruction?.newValue,
                isStaffUser: hasPermission,
                createdAt:
                    instruction?.pmCreatedAt?.value === '' ? null : instruction?.pmCreatedAt?.value,
                updatedAt: new Date()
            };
            break;
        case 'cuInstruction':
            instructionBody = {
                instruction: instruction?.cuInstruction?.newValue,
                isStaffUser: hasPermission,
                createdAt:
                    instruction?.cuCreatedAt?.value === '' ? null : instruction?.cuCreatedAt?.value,
                updatedAt: new Date()
            };
            break;
        case 'customDisclaimer':
            instructionBody = {
                instruction: instruction?.customDisclaimer?.newValue,
                isStaffUser: hasPermission,
                isCustomDisclaimer: true
            };
            break;
        default:
            instructionBody = {};
    }

    return instructionBody;
};

export const patentCountUpdateBody = (fieldName: string, patentEditInput: any) => {
    return {
        abstractWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.abstractWordCount?.newValue as string)
                : parseFloat(patentEditInput?.abstractWordCount?.value as string),
        descriptionWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.descriptionWordCount?.newValue as string)
                : parseFloat(patentEditInput?.descriptionWordCount?.value as string),
        claimsWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.claimsWordCount?.newValue as string)
                : parseFloat(patentEditInput?.claimsWordCount?.value as string),
        patentTitleWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.patentTitleWordCount?.newValue as string)
                : parseFloat(patentEditInput?.patentTitleWordCount?.value as string),
        numberofDrawings:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.numberofDrawings?.newValue as string)
                : parseFloat(patentEditInput?.numberofDrawings?.value as string),
        drawingsPageCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.drawingsPageCount?.newValue as string)
                : parseFloat(patentEditInput?.drawingsPageCount?.value as string),
        drawingsWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.drawingsWordCount?.newValue as string)
                : parseFloat(patentEditInput?.drawingsWordCount?.value as string),
        claimsPageCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.claimsPageCount?.newValue as string)
                : parseFloat(patentEditInput?.claimsPageCount?.value as string),
        descriptionPageCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.descriptionPageCount?.newValue as string)
                : parseFloat(patentEditInput?.descriptionPageCount?.value as string),
        estimatedNumberofTotalPages:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.estimatedNumberofTotalPages?.newValue as string)
                : parseFloat(patentEditInput?.estimatedNumberofTotalPages?.value as string),
        estimatedSequenceListing:
            fieldName === 'edit'
                ? patentEditInput?.estimatedSequenceListing?.newValue === 'Yes'
                    ? 1
                    : 2
                : patentEditInput?.estimatedSequenceListing?.value === 'Yes'
                  ? 1
                  : 2,
        claimsPriority:
            fieldName === 'edit'
                ? patentEditInput?.claimsPriority?.newValue === 'Yes'
                    ? true
                    : false
                : patentEditInput?.claimsPriority?.value === 'Yes'
                  ? true
                  : false,
        numberofClaims:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.numberofClaims?.newValue as string)
                : parseFloat(patentEditInput?.numberofClaims?.value as string),
        numberofIndependentClaims:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.numberofIndependentClaims?.newValue as string)
                : parseFloat(patentEditInput?.numberofIndependentClaims?.value as string),
        numberofPriorityApplications:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.numberofPriorityApplications?.newValue as string)
                : parseFloat(patentEditInput?.numberofPriorityApplications?.value as string),
        specificationWordCount:
            fieldName === 'edit'
                ? parseFloat(patentEditInput?.specificationWordCount?.newValue as string)
                : parseFloat(patentEditInput?.specificationWordCount?.value as string),
        specialInstructions:
            fieldName === 'edit'
                ? patentEditInput?.specialInstructions?.newValue
                : patentEditInput?.specialInstructions?.value
    };
};

const validateEmail = (email: string) => {
    if (email === '') {
        return true;
    } else {
        const re = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return !re.test(String(email).toLowerCase());
    }
};
const validateMultipleEmails = (emails: string[]) => {
    return emails.some((email: string) => validateEmail(email));
};

const validateReferenceNumber = (referenceNumber: string) => {
    return referenceNumber.length > 50;
};

export const additionalInfoEditValidations = (fieldName: string, value: any) => {
    switch (fieldName) {
        case 'contactEmail':
            return validateEmail((value as string) || '');
        case 'cc':
            return validateMultipleEmails((value as []) || []);
        case 'referenceNo':
            return validateReferenceNumber(value as string);
        default:
            break;
    }
};

export const additionalInfoEditErrorMessages = (fieldName: string, value: any) => {
    switch (fieldName) {
        case 'referenceNo':
            return validateReferenceNumber(value as string)
                ? t('QUOTE_AND_ORDER.REFERENCE_NUMBER_MAX_LENGTH')
                : '';
        default:
            break;
    }
};

export const patentCountsValidation = (value: string): boolean => {
    return !value;
};

export const updateStateOnCancel = (setState: any, state: any, fieldName: any) => {
    setState((prevState: { [x: string]: any }) => ({
        ...prevState,
        [fieldName]: {
            ...prevState[fieldName],
            newValue:
                fieldName !== 'projectManagers'
                    ? state?.[fieldName]?.value
                    : (state?.[fieldName]?.value as []).map((item: any) => item.id),
            isEdit: false
        }
    }));
};

export const handleAPIUpdate = async (
    updateFunction: any,
    body: any,
    orderId: string,
    setResponse: any,
    setState: any,
    state: any,
    fieldName: any,
    isOrder: boolean
) => {
    try {
        const response = await updateFunction(body, orderId);
        if (response) {
            setResponse(response);
            showToastMessage(
                isOrder
                    ? t('QUOTE_AND_ORDER.ORDER_UPDATED_SUCCESSFULLY')
                    : t('QUOTE_AND_ORDER.QUOTE_UPDATED_SUCCESSFULLY'),
                ToastType.SUCCESS
            );
        } else {
            setState((prevState: { [x: string]: any }) => ({
                ...prevState,
                [fieldName]: {
                    ...prevState[fieldName],
                    newValue: state?.[fieldName]?.value,
                    isEdit: false
                }
            }));
        }
    } catch (error) {
        setState((prevState: { [x: string]: any }) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue: state?.[fieldName]?.value,
                isEdit: false
            }
        }));
        console.error(error);
        showToastMessage('Failed to update the field', ToastType.ERROR);
    }
};

export interface basedOnUserHardCopyStatus {
    // PROJECT_MANAGER: [22,24],
    dispatcheIDs: [22, 24];
}
