import { ChangeEvent, useState, KeyboardEvent, useMemo } from 'react';
// import refreshIcon from 'assets/svgs/refresh-icon.svg';
import editBlueIcon from 'assets/images/editBlue.svg';
import { formatCurrency, isStaffUser, isVendorUser } from 'core/utils/utils';
import { STATUS_MODE } from 'constants/app.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';

export const EditFieldInline = ({
    fieldValue,
    onSave,
    onCancel,
    currency,
    statusId
}: {
    fieldValue: number;
    onSave: (fieldValue: number) => any;
    currency?: string | null;
    onCancel: any;
    statusId: number;
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [value, setValue] = useState<number>(fieldValue);
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisStaffExcludedFinance = isStaffUser(loggedInUserId, true);
    const isThisVendorExcludedFinance = isVendorUser(loggedInUserId, {
        excludeFinance: true
    });

    const handleEditClick = () => setIsEditing(true);
    const handleSaveClick = () => {
        setIsEditing(false);
        onSave(value);
    };
    const handleCancelClick = () => {
        setIsEditing(false);
        setValue(fieldValue);
        onCancel();
    };
    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        const newValue = parseFloat(e.target.value);
        setValue(newValue);
    };
    // Define a common function to handle keyboard events
    const handleKeyboardEvent = (e: KeyboardEvent<HTMLElement>, action = () => {}) => {
        if (e.key === 'Enter' || e.key === ' ') {
            action();
        }
    };

    const allowEdits = () => {
        return (
            (isThisStaffExcludedFinance || isThisVendorExcludedFinance) &&
            (statusId === STATUS_MODE.PREPARING_QUOTE ||
                statusId === STATUS_MODE.WAITING_FOR_APPROVAL ||
                statusId === STATUS_MODE.TO_BE_PROCESSED)
        );
    };

    return (
        <div className="relative group w-full pt-1 min-w-44">
            {!isEditing ? (
                <div className="flex items-center justify-end ">
                    <span>{`${currency ?? ''} ${formatCurrency(fieldValue)}`}</span>
                    {allowEdits() && (
                        <div className="flex items-center ml-2 group">
                            <button
                                onClick={handleEditClick}
                                onKeyDown={(e) => handleKeyboardEvent(e, handleEditClick)}>
                                <img
                                    src={editBlueIcon}
                                    className="h-4 w-4 cursor-pointer mx-2 hidden group-hover:block"
                                    alt="edit-blue-icon"
                                />
                            </button>
                        </div>
                    )}
                </div>
            ) : (
                <div className="flex items-center justify-end">
                    <label className="input rounded input-bordered h-8 border-[0.02rem] focus-within:outline-none border-neutral-100 focus:border-primary focus-within:border-primary flex items-center gap-2 w-32">
                        <span>{currency}</span>{' '}
                        <input
                            type="number"
                            value={value}
                            onChange={handleChange}
                            className="grow font-medium text-sm text-black no-arrows w-full"
                        />
                    </label>
                    <span
                        role="button"
                        tabIndex={0}
                        className="pi pi-times text-error cursor-pointer mx-1"
                        onClick={handleCancelClick}
                        onKeyDown={(e) => handleKeyboardEvent(e, handleCancelClick)}
                    />
                    <span
                        role="button"
                        tabIndex={0}
                        className="pi pi-check text-primary cursor-pointer mx-1"
                        onClick={handleSaveClick}
                        onKeyDown={(e) => handleKeyboardEvent(e, handleSaveClick)}
                    />
                </div>
            )}
        </div>
    );
};
