import { RequestStatusEnum, statusIndicators } from 'shared/dataTable/constant/dataTable.constant';

describe('statusIndicators', () => {
    it('should return correct colors for ACCEPTED status', () => {
        const result = statusIndicators(RequestStatusEnum.ACCEPTED);
        expect(result).toEqual({ color: '#1D7486', backgroundColor: '#E8F1F3' });
    });

    it('should return correct colors for APPROVED status', () => {
        const result = statusIndicators(RequestStatusEnum.APPROVED);
        expect(result).toEqual({ color: '#77C976', backgroundColor: '#F1FAF1' });
    });

    it('should return correct colors for CANCELED status', () => {
        const result = statusIndicators(RequestStatusEnum.CANCELED);
        expect(result).toEqual({ color: '#EE2F27', backgroundColor: '#FEE9E9' });
    });

    it('should return correct colors for COMPLETED status', () => {
        const result = statusIndicators(RequestStatusEnum.COMPLETED);
        expect(result).toEqual({ color: '#4AB648', backgroundColor: '#ECF8EC' });
    });

    it('should return correct colors for IN_PROGRESS status', () => {
        const result = statusIndicators(RequestStatusEnum.IN_PROGRESS);
        expect(result).toEqual({ color: '#2D76BB', backgroundColor: '#E9F1F8' });
    });

    it('should return correct colors for INVOICED status', () => {
        const result = statusIndicators(RequestStatusEnum.INVOICED);
        expect(result).toEqual({ color: '#6D429B', backgroundColor: '#F0EBF5' });
    });

    it('should return correct colors for unknown status', () => {
        const result = statusIndicators('UNKNOWN_STATUS');
        expect(result).toEqual({ color: '#2D76BB', backgroundColor: '#E9F1F8' });
    });
});
