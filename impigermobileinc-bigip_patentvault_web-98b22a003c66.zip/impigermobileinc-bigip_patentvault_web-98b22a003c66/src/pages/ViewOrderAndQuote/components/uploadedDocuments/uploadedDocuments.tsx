import { UploadedDocumentType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { TabView, TabPanel } from 'primereact/tabview';
import { useMemo, useState } from 'react';
import SourceDocument from './sourceDocuments/sourceDocuments';
import FiledDocuments from './filedDocuments/filedDocuments';
import FormalDocuments from './formalDocuments/formalDocuments';
import { tabPanelPT } from 'constants/styles.constant';
import { IP_NONIP, MODE, SERVICE_TYPES } from 'constants/app.constant';
import { t } from 'i18next';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import ExecutedFormalDocuments from './executedFormalDocuments/executedFormalDocuments';
import { isContactUser } from 'core/utils/utils';
import OfficialFilingReceiptDocument from './officialFilingReceiptDocument/officialFilingReceiptDocument';

const UploadedDocuments: React.FC<UploadedDocumentType> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    viewData,
    flags,
    triggerGetOrderDetails,
    triggerGetInvoiceList
}) => {
    const [activeIndex, setActiveIndex] = useState(0);
    const requestType = viewData?.requestType;
    const isNonIp = requestType === IP_NONIP.nonIp;
    const isOrderMode = viewData?.requestTypeId === MODE.CREATE_ORDER;
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isUPCOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;

    const tabViewStyle = {
        nav: { className: 'gap-4 border-0' },
        panelcontainer: { className: 'border border-neutral-100/50' }
    };

    const getFiledDocuments = (tabIndex: number) => {
        const getFiledDocumentsHeader = () => {
            if (isThisContactUser) return t('File_UPLOAD.FINAL_DOCUMENT');
            else if (isNonIp) return t('File_UPLOAD.TRANSLATED_DOCUMENT');
            else return t('File_UPLOAD.TRANSLATED_FILED_DOCUMENT');
        };

        return (
            isOrderMode && (
                <TabPanel
                    header={getFiledDocumentsHeader()}
                    pt={tabPanelPT(activeIndex === tabIndex)}>
                    <div className="p-3">
                        <FiledDocuments
                            orderOrQuoteId={orderOrQuoteId}
                            primaryIdForAzureStorage={primaryIdForAzureStorage}
                            viewData={viewData}
                            isNonIp={isNonIp}
                        />
                    </div>
                </TabPanel>
            )
        );
    };

    const getFormalDocuments = (tabIndex: number) => {
        return (
            isOrderMode && (
                <TabPanel header="Formal Documents" pt={tabPanelPT(activeIndex === tabIndex)}>
                    <div className="p-3">
                        <FormalDocuments
                            orderOrQuoteId={orderOrQuoteId}
                            primaryIdForAzureStorage={primaryIdForAzureStorage}
                            flags={flags}
                        />
                    </div>
                </TabPanel>
            )
        );
    };

    const getExecutedFormalDocuments = (tabIndex: number) =>
        isOrderMode && (
            <TabPanel
                header={'Executed Formal Documents'}
                pt={tabPanelPT(activeIndex === tabIndex)}>
                <div className="p-3">
                    <ExecutedFormalDocuments
                        orderOrQuoteId={orderOrQuoteId}
                        primaryIdForAzureStorage={primaryIdForAzureStorage}
                        viewData={viewData}
                        flags={flags}
                    />
                </div>
            </TabPanel>
        );

    const getOfficialFilingReceiptDocument = (tabIndex: number) => (
        <TabPanel header={'Official Filing Receipt(s)'} pt={tabPanelPT(activeIndex === tabIndex)}>
            <div className="p-3">
                <OfficialFilingReceiptDocument
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    viewData={viewData}
                    flags={flags}
                    triggerGetOrderDetails={triggerGetOrderDetails}
                />
            </div>
        </TabPanel>
    );

    const renderTabs = () => {
        if (isThisContactUser && !isUPCOptOut) {
            return [getFormalDocuments(1), getFiledDocuments(2)];
        } else if (isUPCOptOut) {
            return [getFiledDocuments(1), getOfficialFilingReceiptDocument(2)]; // For UPC Opt-out, only show Filed Documents tab
        }
        return [getFiledDocuments(1), getFormalDocuments(2), getExecutedFormalDocuments(3)];
    };

    return (
        <div className="pt-5">
            <div className="card">
                <TabView
                    pt={tabViewStyle}
                    activeIndex={activeIndex}
                    onTabChange={(e) => setActiveIndex(e.index)}>
                    <TabPanel header="Source Documents" pt={tabPanelPT(activeIndex === 0)}>
                        <div className="p-3">
                            <SourceDocument
                                orderOrQuoteId={orderOrQuoteId}
                                primaryIdForAzureStorage={primaryIdForAzureStorage}
                                flags={flags}
                                viewData={viewData}
                                triggerGetOrderDetails={triggerGetOrderDetails}
                                triggerGetInvoiceList={triggerGetInvoiceList}
                            />
                        </div>
                    </TabPanel>
                    {renderTabs()}
                </TabView>
            </div>
        </div>
    );
};

export default UploadedDocuments;
