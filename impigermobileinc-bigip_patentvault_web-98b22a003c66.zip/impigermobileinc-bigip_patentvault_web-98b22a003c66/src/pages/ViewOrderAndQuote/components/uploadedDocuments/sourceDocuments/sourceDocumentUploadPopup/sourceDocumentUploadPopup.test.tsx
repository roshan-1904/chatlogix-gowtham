import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import SourceDocumentUploadPopup from './sourceDocumentUploadPopup';
import { DocumentUploadPopupType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

const mockCloseModal = jest.fn();
const mockOnSubmit = jest.fn();

const defaultProps: DocumentUploadPopupType = {
    closeModal: mockCloseModal,
    onSubmit: mockOnSubmit,
    orderOrQuoteId: 12,
    primaryIdForAzureStorage: 45
};

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});
describe('sourceDocumentUploadPopup', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders the PopupModal with correct title', () => {
        render(<SourceDocumentUploadPopup {...defaultProps} />);
        expect(screen.getByText('Upload document')).toBeInTheDocument();
    });

    test('calls closeModal when the close button is clicked', () => {
        render(<SourceDocumentUploadPopup {...defaultProps} />);
        fireEvent.click(screen.getByText('Close'));
        expect(mockCloseModal).toHaveBeenCalled();
    });

    test('calls onSubmit when the upload button is clicked', () => {
        render(<SourceDocumentUploadPopup {...defaultProps} />);
        waitFor(() => {
            fireEvent.click(screen.getByText('Upload'));
            expect(mockOnSubmit).toHaveBeenCalled();
        });
    });

    test('renders FileUpload component with correct props', () => {
        render(<SourceDocumentUploadPopup {...defaultProps} />);
        waitFor(() => {
            const fileUploadComponent = screen.getByTestId('file-upload-component');
            expect(fileUploadComponent).toBeInTheDocument();
            expect(fileUploadComponent).toHaveClass('orderdetail-upload-sourcedocument');
        });
    });
});
