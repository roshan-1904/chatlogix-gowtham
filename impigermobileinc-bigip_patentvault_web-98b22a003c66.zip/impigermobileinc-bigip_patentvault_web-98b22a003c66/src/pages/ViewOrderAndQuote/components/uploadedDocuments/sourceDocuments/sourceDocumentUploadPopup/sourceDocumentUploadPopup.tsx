import FileUpload from 'components/fileUpload/fileUpload';
import PopupModal from 'components/popupModal/popupModal';
import { MODULE_TYPE } from 'constants/app.constant';
import {
    QUOTE_ORDER_USER_MODULE,
    VIEW_QUOTE_ORDER_MODULE
} from 'constants/fileUploadApiUrl.constant';
import { DocumentUploadPopupType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

const sourceDocumentUploadPopup: React.FC<DocumentUploadPopupType> = ({
    closeModal,
    onSubmit,
    orderOrQuoteId,
    primaryIdForAzureStorage
}) => {
    const handleSubmit = () => {
        if (onSubmit) {
            onSubmit({});
        }
    };
    const close = () => {
        if (closeModal) {
            closeModal({});
        }
    };

    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

    const moduleId = MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId;
    const azureFolderName = MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName;
    const uploadFileApiUrl = `${quoteBaseURL}${VIEW_QUOTE_ORDER_MODULE.UPLOAD_FILE}${orderOrQuoteId}&moduleType=${moduleId}`; // Upload file API URL
    const deleteFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`; // Delete file API URL
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`; // Get document type API URL
    const updateDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPDATE_DOCUMENT_TYPE}`; // Update document type API URL

    return (
        <PopupModal
            id={'upload-filedocument'}
            title={'Upload document'}
            onClose={() => close()}
            createButtonText={'Upload'}
            resetButtonText={'Close'}
            isEdit={true}
            onSubmit={handleSubmit}
            isSubmitHide={false}>
            <div className="bg-neutral-300 pb-0">
                <FileUpload
                    uploadFileApiUrl={uploadFileApiUrl}
                    deleteFileApiUrl={deleteFileApiUrl}
                    getDocumentTypeApiUrl={getDocumentTypeApiUrl}
                    updateDocumentTypeApiUrl={updateDocumentTypeApiUrl}
                    moduleType={{ moduleId, azureFolderName }}
                    primaryId={primaryIdForAzureStorage}
                    documentUploadTitle={false}
                    documentUploadOptionalText={false}
                    uploadedDocumentListTable={false}
                    isNotClassified={false}
                    className="orderdetail-upload-sourcedocument"
                    moduleName={`sourceDocument-${orderOrQuoteId}`}
                />
            </div>
        </PopupModal>
    );
};

export default sourceDocumentUploadPopup;
