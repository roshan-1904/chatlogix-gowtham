import {
    SourceDocumentData,
    SourceDocumentsResponse
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import DocumentUploadPopup from './sourceDocumentUploadPopup/sourceDocumentUploadPopup';
import { getSourceDocuments } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import {
    QUOTE_ORDER_USER_MODULE,
    VIEW_QUOTE_ORDER_MODULE
} from 'constants/fileUploadApiUrl.constant';
import { DOCUMENT_TYPE, MODULE_TYPE, SERVICE_TYPES } from 'constants/app.constant';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { Dialog } from 'primereact/dialog';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import utils, { getWindowSize } from 'core/utils/utils';
import { customTableStyle, previewDialogPopup } from 'constants/styles.constant';
import PrimeButton from 'components/buttons/primeButton';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';
import { FileUploadResponse } from 'pages/createOrderAndQuote/components/epUpcOptOut/epUpcOptOut.types';
import { getUploadedFilePatentNumbers } from 'pages/createOrderAndQuote/components/epUpcOptOut/epUpcOptOut.service';
import AuthStore from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';

const SourceDocument: React.FC<SourceDocumentsResponse> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    flags,
    viewData,
    triggerGetOrderDetails,
    triggerGetInvoiceList
}) => {
    const { t } = useTranslation();
    const { requestId } = useParams();
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const moduleId = MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`;
    const [showModal, setShowModal] = useState(false);
    const [orderSourceDocumentsModelList, setOrderSourceDocumentsModelList] = useState<
        SourceDocumentData[]
    >([]);
    const [fileTypes, setFileTypes] = useState<any>([]);
    const [toggleRowData, setToggleRowData] = useState<any>();
    const [showFileDeletePopup, setShowFileDeletePopup] = useState({
        visible: false,
        header: '',
        description: ''
    });
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const emptyMessage = t('COMMON.NO_DATA_FOUND');
    const [errMessage, setErrMessage] = useState<undefined | string>(undefined);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const isUpcOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription.unsubscribe();
        };
    }, []);

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 2000) {
                    handleGetSourceDocuments(requestBody);
                    triggerGetInvoiceList?.();
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    // Handling deletion confirmation
    const handleDeleteRecord = (data: any) => {
        setToggleRowData(data);
        setShowFileDeletePopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t('File_UPLOAD.DELETE_CONFIRMATION')
        });
    };

    // Confirming file deletion
    const handleConfirm = () => {
        if (toggleRowData) {
            handleFileDelete(toggleRowData);
            setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
        }
    };

    // Canceling file deletion
    const handleCancel = () => {
        setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
    };

    // Fetching SAS URL on component mount
    useEffect(() => {
        getSasUrlApi();
        fetchDocumentTypes();
    }, []);

    // Fetching document types and source documents on component mount
    useEffect(() => {
        handleGetSourceDocuments(requestBody);
    }, [requestBody]);

    // Fetching document types
    const fetchDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        const filteredResponse = response.filter(
            (item: { id: number }) => item.id === 1 || item.id === 2
        );
        setFileTypes(filteredResponse);
    };

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const handleFileUploadAndGetData = async (e: React.ChangeEvent<HTMLInputElement>) => {
        setUploadedFile(null);
        const file = e.target.files?.[0];
        if (file) {
            const resetFileInput = document.getElementById(
                'upload-completed-Template'
            ) as HTMLInputElement;
            resetFileInput.value = '';
            const payload = {
                file,
                orderId: Number(requestId)
            };
            try {
                const response: FileUploadResponse = await getUploadedFilePatentNumbers(
                    payload,
                    false
                );
                if (response) {
                    setUploadedFile(file);
                    if (triggerGetOrderDetails) {
                        triggerGetOrderDetails();
                    }
                }
            } catch {
                console.error('Error fetching uploaded file patent numbers');
            }
        }
    };

    const DocumentPreviewTemplate = (rowData: any) => {
        return (
            <div className="flex justify-between items-center gap-3">
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileId + ' flex items-center gap-1'}>
                    {fileTypeIcon(rowData.fileType as string)}
                    <p
                        className="text-base text-primary font-medium underline underline-offset-1 max-w-64 truncate cursor-pointer"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handlePreviewDocument(rowData);
                            }
                        }}
                        tabIndex={0}>
                        {rowData.fileName}
                    </p>
                </div>
                {isUpcOptOut &&
                    (AuthStore.hasPermission(Permissions.CREATE_QUOTE) ||
                        AuthStore.hasPermission(Permissions.CREATE_ORDER)) && (
                        <div className="w-5">
                            <label className="cursor-pointer">
                                <div className="h-5 w-5">
                                    <Tooltip
                                        position="bottom"
                                        target={'.fileTooltip'}
                                        content={'Replace the existing file'}></Tooltip>
                                    <img
                                        src={uploadIcon}
                                        className="fileTooltip w-full h-full"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => {
                                            setToggleRowData(rowData);
                                        }}
                                    />
                                </div>
                                <input
                                    type="file"
                                    id="upload-completed-Template"
                                    hidden
                                    accept=".xlsx, .xls"
                                    onChange={(e) => {
                                        handleFileUploadAndGetData(e);
                                    }}
                                />
                            </label>
                        </div>
                    )}
            </div>
        );
    };

    const DocumentTypeTemplate = (rowData: SourceDocumentData) => {
        return (
            <div>
                {fileTypes.map((type: { id: number; name: string }) => {
                    if (type.id === Number(rowData.documentType)) {
                        return (
                            <p key={rowData.documentId} className="text-base">
                                {type.name}
                            </p>
                        );
                    }
                })}
            </div>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: !isUpcOptOut,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'fileName',
            header: 'Document Name',
            sortable: !isUpcOptOut,
            filter: true,
            filterType: FilterType.Text,
            body: DocumentPreviewTemplate,
            columnNumber: 1,
            visibility: true,
            cellStyle: 'max-w-56'
        },
        {
            field: 'documentType',
            header: 'Document Type',
            sortable: !isUpcOptOut,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            filterDropDownOptions: fileTypes.map((type: { name: any; id: any }) => ({
                label: type.name,
                value: `${type.id}`
            })),
            columnNumber: 2,
            visibility: true,
            body: DocumentTypeTemplate
        },
        {
            field: 'fileSize',
            header: 'Size',
            sortable: !isUpcOptOut,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded by',
            sortable: !isUpcOptOut,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: !isUpcOptOut,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'action',
            header: 'Action',
            filter: false,
            frozen: true,
            filterType: FilterType.Text,
            valueType: ValueType.DeleteIcon,
            columnNumber: 6,
            className: 'w-[6%]',
            visibility: true
        }
    ];

    const handleClick = () => {
        openModal().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const uploadDocumentButton = () => {
        return (
            <a href="#file-upload">
                <PrimeButton
                    testid="upload-documents-ip-source"
                    label={'Upload Document'}
                    type="primary"
                    className=""
                    disabled={flags?.isCompleted || flags?.isInvoiced}
                    icon="pi pi-cloud-upload"
                    size="medium"
                    onClick={handleClick}
                />
            </a>
        );
    };

    const tableDefinition: DataTableDefinition = {
        title: 'Source Documents',
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.ORDER_QUOTE_SOURCE_DOCUMENTS,
        emptyMessage: errMessage,
        tableCustomStyle: 'p-0',
        columns: isUpcOptOut
            ? columnSchema.filter((column) => column.field !== 'action')
            : columnSchema,
        buttonChildren: !isUpcOptOut && uploadDocumentButton(),
        customTablePT: {
            ...customTableStyle(false),
            thead: {
                className: `${customTableStyle(false).thead.className} ${isUpcOptOut ? '[&>tr:nth-child(2)]:hidden' : ''}`
            }
        },
        customTableHeight: false,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.SOURCE_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: false
    };

    const handleFileDelete = (data: any) => {
        handleDeleteFileApi(data.documentId as number, data.fileId as number);
    };

    const handleDeleteFileApi = async (documentId: number, fileId: number) => {
        const deleteUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`;
        try {
            const deletionSuccess = await fileUploadService.deleteTheDocument(
                deleteUrl,
                documentId,
                fileId
            );
            if (deletionSuccess) {
                handleGetSourceDocuments(requestBody);
            } else {
                console.error('Error deleting file:', deletionSuccess);
            }
        } catch (error) {
            console.error('Error deleting file:', error);
            // Handle error, if necessary
        }
    };

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }

        // Update the URL fragment without reloading the page
        window.location.hash = 'uploaded-documents-container';
    };

    // Fetch and process source documents
    const handleGetSourceDocuments = async (body: RequestBody) => {
        try {
            const response: SourceDocumentsResponse =
                await getSourceDocuments<SourceDocumentsResponse>(String(requestId), body);

            setOrderSourceDocumentsModelList(
                response.orderSourceDocumentsModel as SourceDocumentData[]
            );

            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil((response.total ?? 0) / body.pageCount),
                totalRecords: response.total as number
            };
            setBlobURL(response.blobUri);
            setPaginationInfo(pagination);

            if (response.orderSourceDocumentsModel?.length === 0) setErrMessage(emptyMessage);
        } catch (error) {
            console.error('Error fetching source documents:', error);
            setErrMessage(emptyMessage);
        }
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    return (
        <div>
            {isUpcOptOut && (
                <FileUpload
                    className="hidden"
                    uploadFileApiUrl={`${quoteBaseURL}${VIEW_QUOTE_ORDER_MODULE.UPLOAD_FILE}${orderOrQuoteId}&moduleType=${MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId}`}
                    moduleType={{
                        moduleId: MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId,
                        azureFolderName: MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName
                    }}
                    primaryId={primaryIdForAzureStorage}
                    documentTypeId={DOCUMENT_TYPE.SOURCE.id}
                    deleteFileApiUrl={null}
                    getDocumentTypeApiUrl={null}
                    updateDocumentTypeApiUrl={null}
                    multipleFiles={false}
                    moduleName={`upcOptOut-${orderOrQuoteId}`}
                    acceptedFileTypes={['.xlsx', '.xls']}
                    triggerHandleFiles={
                        uploadedFile
                            ? (handleFiles: (files: File[]) => void) => {
                                  handleFiles([uploadedFile]);
                                  setUploadedFile(null);
                              }
                            : undefined
                    }
                    isEpUPCOptOut={true}
                    replaceFileId={toggleRowData ? (toggleRowData.fileId as number) : undefined}
                />
            )}
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            {showFileDeletePopup.visible ? (
                <ConfirmationPopup
                    key={'deleteSouceDocumentPopup'}
                    onConfirm={handleConfirm}
                    onCancel={handleCancel}
                    visible={showFileDeletePopup.visible}
                    headerText={showFileDeletePopup.header}
                    description={showFileDeletePopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    popupID={'deleteSouceDocumentPopup'}
                />
            ) : null}
            {showModal && (
                <DocumentUploadPopup
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    closeModal={closeModal}
                    onSubmit={() => {}}
                />
            )}
            <DataTableComponent
                tableData={orderSourceDocumentsModelList ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                toggleRowData={() => {}}
                deleteRecord={handleDeleteRecord}
                previewDocument={handlePreviewDocument}
                handlePagination={handlePageChange}
                tablePaginationData={paginationInfo}
                showPagination={!isUpcOptOut}
                handleSort={sortHandler}
            />
        </div>
    );
};

export default SourceDocument;
