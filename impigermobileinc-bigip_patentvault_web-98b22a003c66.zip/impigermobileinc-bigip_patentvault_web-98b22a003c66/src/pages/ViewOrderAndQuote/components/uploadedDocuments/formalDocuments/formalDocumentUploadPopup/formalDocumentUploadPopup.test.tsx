import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import FormalDocumentUploadPopup from './formalDocumentUploadPopup';
import { DocumentUploadPopupType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import AuthStore from 'core/store/authStore/authStore';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import { getFormalDocumentCountryList } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';

jest.mock('core/store/formIoStore/formIoStore');
jest.mock('core/store/authStore/authStore');
jest.mock('components/fileUpload/services/fileUpload.service');
jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService');

const mockProps: DocumentUploadPopupType = {
    closeModal: jest.fn(),
    onSubmit: jest.fn(),
    orderOrQuoteId: 1,
    primaryIdForAzureStorage: 1
};
jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('FormalDocumentUploadPopup', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        jest.spyOn(formStatusStore, 'getFormData').mockReturnValue({ data: {} });
        jest.spyOn(AuthStore, 'getUserInfo').mockReturnValue({
            userInfo: {
                roleId: 1,
                permissions: [],
                userId: 0,
                userFullName: '',
                role: ''
            },
            authToken: '',
            expiresOn: 0,
            isAuthenticated: false
        });
        jest.spyOn(fileUploadService, 'getDocumentTypes').mockResolvedValue([]);
        (getFormalDocumentCountryList as jest.Mock).mockResolvedValue([]);
    });

    test('renders FormalDocumentUploadPopup component', () => {
        render(<FormalDocumentUploadPopup {...mockProps} />);

        expect(screen.getByText('Upload Document')).toBeInTheDocument();
        expect(screen.getByText('Upload')).toBeInTheDocument();
        expect(screen.getByText('Close')).toBeInTheDocument();
    });

    test('calls closeModal when Close button is clicked', async () => {
        render(<FormalDocumentUploadPopup {...mockProps} />);

        fireEvent.click(screen.getByText('Close'));

        await waitFor(() => {
            expect(mockProps.closeModal).toHaveBeenCalled();
        });
    });

    test('calls onSubmit when Upload button is clicked', () => {
        render(<FormalDocumentUploadPopup {...mockProps} />);

        fireEvent.click(screen.getByText('Upload'));

        waitFor(() => {
            expect(mockProps.onSubmit).toHaveBeenCalled();
        });
    });

    test('fetches document types and country list on mount', async () => {
        render(<FormalDocumentUploadPopup {...mockProps} />);

        await waitFor(() => {
            expect(fileUploadService.getDocumentTypes).toHaveBeenCalled();
            expect(getFormalDocumentCountryList).toHaveBeenCalledWith(mockProps.orderOrQuoteId);
        });
    });

    test('updates form data on form change', () => {
        render(<FormalDocumentUploadPopup {...mockProps} />);

        const formChangeEvent = {
            data: { targetCountry: { countryId: 1 }, documentType: 1, dateTime: '2023-01-01' },
            isValid: true,
            changed: true
        };
        waitFor(() => {
            fireEvent.change(screen.getByTestId('selected-file-type'), {
                target: { value: formChangeEvent.data.targetCountry }
            });
            expect(formStatusStore.updateFormData).toHaveBeenCalledWith(formChangeEvent.data, true);
        });
    });
});
