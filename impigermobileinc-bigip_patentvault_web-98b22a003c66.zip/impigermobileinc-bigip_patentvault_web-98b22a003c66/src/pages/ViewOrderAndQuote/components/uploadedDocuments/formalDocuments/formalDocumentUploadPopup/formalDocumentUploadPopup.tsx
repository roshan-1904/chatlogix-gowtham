import FileUpload from 'components/fileUpload/fileUpload';
import PopupModal from 'components/popupModal/popupModal';
import { DOCUMENT_TYPE, MODULE_TYPE } from 'constants/app.constant';
import {
    FORMAL_DOCUMENT_MODULE,
    QUOTE_ORDER_USER_MODULE
} from 'constants/fileUploadApiUrl.constant';
import {
    DocumentUploadPopupType,
    FormalDocumentCountryListType,
    DocumentType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dropdown } from 'primereact/dropdown';
import { dropDownStyle } from 'constants/styles.constant';
import { getFormalDocumentCountryList } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { useEffect, useMemo, useState } from 'react';
import { END_POINT } from 'constants/endPoint';
import FormalDocumentUploadField from './formalDocumentUploadField.json';
import { Form } from '@formio/react';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import HttpService from 'core/interceptor/api.handler';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { formatDateYYMMDD, isContactUser } from 'core/utils/utils';

const FormalDocumentUploadPopup: React.FC<DocumentUploadPopupType> = ({
    closeModal,
    onSubmit,
    orderOrQuoteId,
    primaryIdForAzureStorage
}) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const [selectedFormalDocumentCountry, setSelectedFormalDocumentCountry] =
        useState<FormalDocumentCountryListType>({ id: 0, countryId: 0, countryName: '' });
    const [formalDocumentCountryList, setFormalDocumentCountryList] = useState<
        FormalDocumentCountryListType[]
    >([]);
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(FormalDocumentUploadField);
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());
    formStatusStore.subscribe(setFormState);

    const [fileTypes, setFileTypes] = useState<DocumentType[]>([]);

    const handleSubmit = () => {
        if (onSubmit) {
            onSubmit({});
        }
    };
    const close = () => {
        if (closeModal) {
            closeModal({});
        }
    };

    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

    const getUserModuleType = () => {
        if (isThisContactUser) {
            return MODULE_TYPE.FORMAL_DOCUMENT_MODULE_CM_CU;
        } else {
            return MODULE_TYPE.FORMAL_DOCUMENT_MODULE;
        }
    };

    const { moduleId, azureFolderName } = getUserModuleType();

    const uploadFileApiUrl = `${quoteBaseURL}${END_POINT.ORDER}${FORMAL_DOCUMENT_MODULE.UPLOAD_FILE}?primaryId=${orderOrQuoteId}&moduleType=${1}`; // Upload file API URL
    const deleteFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`; // Delete file API URL
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`; // Get document type API URL
    const updateDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPDATE_DOCUMENT_TYPE}`; // Update document type API URL

    const countryListDropDown = () => {
        return (
            <label className="flex flex-col">
                <p className="text-base font-medium text-neutral-200 flex gap-x-px">
                    Target Country
                    <span className="text-secondary font-semibold text-xl">*</span>
                </p>
                <Dropdown
                    required={true}
                    data-testid="selected-file-type"
                    value={selectedFormalDocumentCountry}
                    filter={true}
                    onChange={(e) =>
                        setSelectedFormalDocumentCountry(e.value as FormalDocumentCountryListType)
                    }
                    options={formalDocumentCountryList}
                    optionLabel="countryName"
                    placeholder={'Select Target Country'}
                    pt={{
                        ...dropDownStyle,
                        root: {
                            className:
                                'hover:border-primary font-medium border-2 border-neutral-100 md:w-80'
                        },
                        item: { className: 'hover:bg-primary-50' },
                        input: {
                            className: 'p-2'
                        }
                    }}
                />
            </label>
        );
    };

    const [fillRequiredFieldsFlag, setFillRequiredFieldsFlag] = useState<boolean>(false);

    const onFormChange = (e: any) => {
        const { data, isValid } = e;
        const updatedFormData = data;
        if (e.changed) {
            formStatusStore.updateFormData(updatedFormData, !!isValid);

            // Check the required fields based on the value of `ifHardCopyYesOrNo`
            const isAllRequiredFieldsFilled =
                updatedFormData?.ifHardCopyYesOrNo === 'yes'
                    ? updatedFormData?.targetCountry &&
                      updatedFormData?.documentType &&
                      updatedFormData?.dateTime &&
                      updatedFormData?.dispatchAddress &&
                      updatedFormData?.vendorName &&
                      updatedFormData?.vendorEmail
                    : updatedFormData?.targetCountry &&
                      updatedFormData?.documentType &&
                      updatedFormData?.dateTime;

            // Set the flag based on the condition
            setFillRequiredFieldsFlag(!!isAllRequiredFieldsFilled);
        }
    };

    useEffect(() => {
        fetchDocumentTypes();
        fetchFormalCountryList();
    }, []);

    const fetchDocumentTypes = async () => {
        const response: DocumentType[] =
            await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        response &&
            setFileTypes(
                response.filter(
                    (item: { id: number }) => item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id
                )
            );
    };

    const fetchFormalCountryList = async () => {
        const response: FormalDocumentCountryListType[] =
            await getFormalDocumentCountryList(orderOrQuoteId);
        response && setFormalDocumentCountryList(response);
    };

    const generateFormData = (options: any, countryOption: any) => {
        const data = {
            documentTypeOption: options,
            documentType: options[0]?.id,
            targetCountryOption: countryOption,
            targetCountry: countryOption[0],
            ifHardCopyYesOrNo: 'no'
        };
        formStatusStore.updateFormData(data, false);
    };

    useEffect(() => {
        generateFormData(fileTypes, formalDocumentCountryList);
    }, [fileTypes, formalDocumentCountryList]);

    const extraFieldHtml = () => {
        return (
            <div className="formalDocumentUpload h-44 overflow-x-hidden overflow-y-auto">
                {
                    <Form
                        key={'file-upload-formalDocument'}
                        form={formBuilderData}
                        submission={formState}
                        onChange={(e: any) => onFormChange(e)}
                    />
                }
            </div>
        );
    };

    return (
        <PopupModal
            id={'upload-formalDocument'}
            title={'Upload Document'}
            onClose={() => close()}
            createButtonText={'Upload'}
            resetButtonText={'Close'}
            isEdit={true}
            onSubmit={handleSubmit}
            isSubmitHide={false}>
            <div className="bg-neutral-300 pb-0">
                <FileUpload
                    uploadFileApiUrl={uploadFileApiUrl}
                    deleteFileApiUrl={deleteFileApiUrl}
                    getDocumentTypeApiUrl={getDocumentTypeApiUrl}
                    updateDocumentTypeApiUrl={updateDocumentTypeApiUrl}
                    moduleType={{ moduleId, azureFolderName }}
                    primaryId={primaryIdForAzureStorage}
                    documentUploadTitle={false}
                    documentUploadOptionalText={false}
                    uploadedDocumentListTable={false}
                    isNotClassified={false}
                    className="orderdetail-upload-formaldocument"
                    childDropDown={countryListDropDown()}
                    extraFields={extraFieldHtml()}
                    ifFormalDocumentUpload={{ isFormalDoc: true }}
                    moduleName={`formalDocument-${orderOrQuoteId}`}
                    formalDocumentFields={{
                        targetCountryId:
                            formStatusStore.getFormData().data?.targetCountry?.countryId ?? 0,
                        hardCopy: formStatusStore.getFormData().data?.ifHardCopyYesOrNo === 'yes',
                        expectedDeliveryDate:
                            formStatusStore.getFormData().data?.dateTime === '' ||
                            formStatusStore.getFormData().data?.dateTime === null ||
                            formStatusStore.getFormData().data?.dateTime === undefined
                                ? undefined
                                : formatDateYYMMDD(
                                      formStatusStore.getFormData().data?.dateTime as string
                                  ),
                        disPatchAddress: formStatusStore.getFormData().data?.dispatchAddress ?? '',
                        documentType: formStatusStore.getFormData().data?.documentType ?? 0,
                        vendorName: formStatusStore.getFormData().data?.vendorName ?? '',
                        vendorPhoneNumber:
                            formStatusStore.getFormData().data?.vendorPhoneNumber ?? '',
                        vendorEmail: formStatusStore.getFormData().data?.vendorEmail ?? ''
                    }}
                    multipleFiles={false}
                    documentTypeFlag={false}
                    singleFileUploadIndication={(status: boolean) => {
                        if (status) {
                            setTimeout(() => {
                                close();
                            }, 2000);
                        }
                    }}
                    isValidateRequiredFields={true}
                    fillRequiredFieldsAreValid={fillRequiredFieldsFlag}
                />
            </div>
        </PopupModal>
    );
};

export default FormalDocumentUploadPopup;
