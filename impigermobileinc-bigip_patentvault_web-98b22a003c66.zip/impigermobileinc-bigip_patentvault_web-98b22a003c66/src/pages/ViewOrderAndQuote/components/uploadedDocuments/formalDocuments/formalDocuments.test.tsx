import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import FormalDocuments from './formalDocuments';
import { BrowserRouter as Router } from 'react-router-dom';
import {
    getFormalDocumentHardCopyStatus,
    getFormalDocumentStatus,
    getFormalDocuments
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import { getSasUrl } from 'components/fileUpload/services/azureStorage.service';
import AuthStore from 'core/store/authStore/authStore';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService');
jest.mock('components/fileUpload/services/fileUpload.service');
jest.mock('components/fileUpload/services/azureStorage.service');
jest.mock('core/store/authStore/authStore');
jest.mock('core/store/uploadedFile.store/uploadedFile.store');
jest.mock('core/store/notificationStore/notificationStore');
jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});
describe('FormalDocuments Component', () => {
    const mockUserInfo = {
        userInfo: {
            roleId: 1
        }
    };

    beforeEach(() => {
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue(mockUserInfo);
        (UploadedFileStore.subscribe as jest.Mock).mockReturnValue({ unsubscribe: jest.fn() });
        (getFormalDocuments as jest.Mock).mockResolvedValue({
            orderFormalDocumentsModel: [],
            total: 0,
            blobUri: ''
        });
        (getFormalDocumentStatus as jest.Mock).mockResolvedValue([]);
        (getFormalDocumentHardCopyStatus as jest.Mock).mockResolvedValue([]);
        (getSasUrl as jest.Mock).mockResolvedValue('sasUrl');
        (fileUploadService.getDocumentTypes as jest.Mock).mockResolvedValue([]);
    });

    test('renders FormalDocuments component', async () => {
        render(
            <Router>
                <FormalDocuments orderOrQuoteId={1} primaryIdForAzureStorage={1} />
            </Router>
        );

        expect(screen.getByText('Formal Documents')).toBeInTheDocument();
        await waitFor(() => expect(getFormalDocuments).toHaveBeenCalled());
    });

    test('opens and closes the upload modal', () => {
        render(
            <Router>
                <FormalDocuments orderOrQuoteId={1} primaryIdForAzureStorage={1} />
            </Router>
        );

        const uploadButton = screen.getByText('Upload Document');
        fireEvent.click(uploadButton);
        waitFor(() => {
            expect(screen.queryByText('Upload Document')).not.toBeInTheDocument();
        });
    });

    test('handles file delete confirmation', () => {
        render(
            <Router>
                <FormalDocuments orderOrQuoteId={1} primaryIdForAzureStorage={1} />
            </Router>
        );

        waitFor(() => {
            const deleteButton = screen.getByText('Actions');
            fireEvent.click(deleteButton);
            expect(screen.getByText('COMMON.CONFIRMATION')).toBeInTheDocument();
            const confirmButton = screen.getByText('COMMON.YES');
            fireEvent.click(confirmButton);
            expect(screen.queryByText('COMMON.CONFIRMATION')).not.toBeInTheDocument();
        });
    });

    test('handles status change popup', () => {
        render(
            <Router>
                <FormalDocuments orderOrQuoteId={1} primaryIdForAzureStorage={1} />
            </Router>
        );

        waitFor(() => {
            const statusDropdown = screen.getByTestId('status-dropdown');
            fireEvent.change(statusDropdown, { target: { value: 2 } });
            expect(screen.getByText('PoA Status')).toBeInTheDocument();
            const updateButton = screen.getByText('Update');
            fireEvent.click(updateButton);

            expect(screen.queryByText('PoA Status')).not.toBeInTheDocument();
        });
    });

    test('fetches formal document types', async () => {
        render(
            <Router>
                <FormalDocuments orderOrQuoteId={1} primaryIdForAzureStorage={1} />
            </Router>
        );

        await waitFor(() => expect(fileUploadService.getDocumentTypes).toHaveBeenCalled());
    });
});
