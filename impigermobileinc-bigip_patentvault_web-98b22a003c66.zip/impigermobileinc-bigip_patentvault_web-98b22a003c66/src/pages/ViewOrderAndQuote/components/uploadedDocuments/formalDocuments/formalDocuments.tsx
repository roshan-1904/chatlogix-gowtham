import {
    getFormalDocumentHardCopyStatus,
    getFormalDocumentStatus,
    getFormalDocuments,
    poaDocumentReminderSend,
    updateFormalDocumentHardCopyStatus,
    updateFormalDocumentStatus
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import {
    FormalDocumentHardCopyStatusType,
    FormalDocumentStatusType,
    FormalDocumentsResponse,
    FormalDocumentsType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
    FilterType,
    TableTypes,
    ValueType,
    statusIndicators
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import FormalDocumentUploadPopup from './formalDocumentUploadPopup/formalDocumentUploadPopup';
import { useTranslation } from 'react-i18next';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { ORDER_QUOTE_MODULE, QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { Dialog } from 'primereact/dialog';
import { Dropdown } from 'primereact/dropdown';
import PopupModal from 'components/popupModal/popupModal';
import { Form } from '@formio/react';
import formStatusStore, { FormStatus } from 'core/store/formIoStore/formIoStore';
import HttpService from 'core/interceptor/api.handler';
import FormalDocumentAirwayNo from './formalDocumentAirwayNo.json';
import FormalDocumentRejectStatus from './formalDocumentRejectStatus.json';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { DOCUMENT_TYPE, STATUS_TYPE_ID, MODULE_TYPE } from 'constants/app.constant';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import NotificationStore, {
    ToastType,
    notificationModel
} from 'core/store/notificationStore/notificationStore';
import utils, { getWindowSize, isContactUser, isStaffUser, isVendorUser } from 'core/utils/utils';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';
import { previewDialogPopup } from 'constants/styles.constant';
import PrimeButton from 'components/buttons/primeButton';

const FormalDocuments: React.FC<FormalDocumentsType> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    flags
}) => {
    const { t } = useTranslation();
    const { requestId } = useParams();
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const [formalDocumentsList, setFormalDocumentsList] = useState<FormalDocumentsResponse[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [eMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const emptyMessage = t('COMMON.NO_DATA_FOUND');
    const [showModal, setShowModal] = useState(false);
    const [statusChangePopup, setStatusChangePopup] = useState(false);
    const [toggleRowData, setToggleRowData] = useState<any>();
    const [showFileDeletePopup, setShowFileDeletePopup] = useState({
        visible: false,
        header: '',
        description: ''
    });
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [formalDocumentStatus, setFormalDocumentStatus] = useState<FormalDocumentStatusType[]>();
    const [formalDocumentHardCopyStatus, setFormalDocumentHardCopyStatus] =
        useState<FormalDocumentHardCopyStatusType[]>();
    const [selectedRowData, setSelectedRowData] = useState<FormalDocumentsResponse>();
    const [selectedFormBuilderData, setSelectedFormBuilderData] = useState<object>({});
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(selectedFormBuilderData);
    const [formState, setFormState] = useState<FormStatus>(formStatusStore.getFormData());
    const [selectedStatusTypeId, setSelectedStatusTypeId] = useState<FormalDocumentStatusType>();
    const [selectedHardCopyStatusTypeId, setSelectedHardCopyStatusTypeId] =
        useState<FormalDocumentHardCopyStatusType>();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${MODULE_TYPE.FORMAL_DOCUMENT_MODULE.moduleId}`; // Get document type API URL
    const [formalDocumentTypes, setFormalDocumentTypes] = useState<any[]>([]);
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisContactUser = isContactUser(loggedInUserRoleId);

    formStatusStore.subscribe(setFormState);

    // Showing toast message
    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    useEffect(() => {
        // API call to get the data
        fetchFormalDocuments(requestBody);
    }, [requestBody]);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    const fileInputTriggerRef = useRef<(() => void) | null>(null);
    const uploadFileApiUrl = `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_EXISTING_FILE}?primaryId=${toggleRowData?.id}&FileId=${toggleRowData?.fileId}`; // Replace existing file API URL

    // Fetch Uploaded File Store
    const [uploadFileStore, SetUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(SetUploadFileStore);
        return () => {
            subscription.unsubscribe();
        };
    }, []);

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 3000) {
                    fetchFormalDocuments(requestBody);
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    useEffect(() => {
        getSasUrlApi();
        fetchFormalDocumentStatus();
        fetchFormalDocumentHardCopyStatus();
    }, []);

    useEffect(() => {
        fetchForamlDocumentTypes();
    }, []);

    const fetchForamlDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        response &&
            setFormalDocumentTypes(
                response.filter(
                    (item: { id: number }) => item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id
                )
            );
    };

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const fetchFormalDocumentStatus = async () => {
        const response: FormalDocumentStatusType[] = await getFormalDocumentStatus();
        const documentWithColor = response.map((item) => {
            return {
                ...item,
                color: statusIndicators(item.name).color,
                backgroundColor: statusIndicators(item.name).backgroundColor
            };
        });
        setFormalDocumentStatus(
            documentWithColor.filter((item: { id: number }) => item.id !== STATUS_TYPE_ID.PENDING)
        );
    };

    const fetchFormalDocuments = async (body: RequestBody) => {
        // API call to get the data
        const response: FormalDocumentsType = await getFormalDocuments<FormalDocumentsType>(
            String(requestId),
            body
        );

        setFormalDocumentsList(response.orderFormalDocumentsModel as FormalDocumentsResponse[]);
        const pagination: paginationData = {
            pageNo: body.pageNo,
            totalPages: Math.ceil(response.total ?? 0 / body.pageCount),
            totalRecords: response.total ?? 0
        };
        setPaginationInfo(pagination);
        setBlobURL(response.blobUri);
        if (response.orderFormalDocumentsModel?.length === 0) {
            setEmptyMessage(emptyMessage);
        }
    };

    const fetchFormalDocumentHardCopyStatus = async () => {
        const response: FormalDocumentHardCopyStatusType[] =
            await getFormalDocumentHardCopyStatus();
        const documentWithColor = response.map((item) => {
            return {
                ...item,
                color: statusIndicators(item.name).color,
                backgroundColor: statusIndicators(item.name).backgroundColor
            };
        });

        setFormalDocumentHardCopyStatus(documentWithColor);
    };

    const uploadDocumentButton = () => {
        return (
            <a href="#file-upload">
                <PrimeButton
                    testid="upload-documents-ip-formal"
                    label={'Upload Document'}
                    type="primary"
                    className=""
                    disabled={flags?.isCompleted || flags?.isInvoiced}
                    icon="pi pi-cloud-upload"
                    size="medium"
                    onClick={handleClick}
                />
            </a>
        );
    };

    const handleClick = () => {
        openModal().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-formalDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-formalDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }

        // Update the URL fragment without reloading the page
        window.location.hash = 'uploaded-documents-container';
    };

    const handleStatusChangePopup = () => {
        openStatusChangePopup().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const openStatusChangePopup = async () => {
        setStatusChangePopup(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'status-change-popup'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeStatusChangePopup = () => {
        setStatusChangePopup(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'status-change-popup'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const handleFileDelete = (data: any) => {
        handleDeleteFileApi(data.documentId as number, data.fileId as number);
    };

    const onFormChange = (e: any) => {
        const { data, isValid } = e;
        const updatedFormDate = JSON.parse(JSON.stringify(data));
        formStatusStore.updateFormData(updatedFormDate, !!isValid);
    };

    const handleDeleteFileApi = async (documentId: number, fileId: number) => {
        const deleteUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`;
        try {
            const deletionSuccess = await fileUploadService.deleteTheDocument(
                deleteUrl,
                documentId,
                fileId
            );
            if (deletionSuccess) {
                fetchFormalDocuments(requestBody);
            } else {
                console.error('Error deleting file:', deletionSuccess);
            }
        } catch (error) {
            console.error('Error deleting file:', error);
            // Handle error, if necessary
        }
    };

    // Handling deletion confirmation
    const handleDeleteRecord = (data: any) => {
        setToggleRowData(data);
        setShowFileDeletePopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: t('File_UPLOAD.DELETE_CONFIRMATION')
        });
    };

    // Confirming file deletion
    const handleConfirm = () => {
        if (toggleRowData) {
            handleFileDelete(toggleRowData);
            setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
        }
    };

    // Canceling file deletion
    const handleCancel = () => {
        setShowFileDeletePopup({ ...showFileDeletePopup, visible: false });
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    const documentNameWithSizeTemplate = (rowData: any) => {
        return (
            <div className="flex items-center justify-between gap-3">
                <div>
                    <Tooltip
                        position="bottom"
                        target={'.fileNameTooltip' + rowData.fileId}
                        content={rowData.fileName}></Tooltip>
                    <div
                        className={'fileNameTooltip' + rowData.fileId + ' flex items-center gap-2'}>
                        {fileTypeIcon(rowData.fileType as string)}
                        <p
                            className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56 cursor-pointer"
                            onClick={() => handlePreviewDocument(rowData)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                    handlePreviewDocument(rowData);
                                }
                            }}
                            tabIndex={0}>
                            {rowData.fileName}
                        </p>
                        <p className="text-base text-neutral-200">{rowData.fileSize}</p>
                    </div>
                </div>
                <div className="w-5">
                    <label className="cursor-pointer">
                        <div className="h-5 w-5">
                            <Tooltip
                                position="bottom"
                                target={'.fileTooltip'}
                                content={'Replace the existing file'}></Tooltip>
                            <img
                                src={uploadIcon}
                                className="fileTooltip w-full h-full"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    setToggleRowData(rowData);
                                    handleTriggerFileInputClick();
                                }}
                            />
                        </div>
                    </label>
                </div>
            </div>
        );
    };

    const handleFormalDocumentDropdownChange = (e: number, fileId: number) => {
        const updateFormalDocumentList: FormalDocumentsResponse[] = formalDocumentsList.map(
            (item: FormalDocumentsResponse) => {
                if (item.fileId === fileId) {
                    return { ...item, poAStatusId: e };
                }
                return item;
            }
        );

        setFormalDocumentsList(updateFormalDocumentList);
    };

    const handleFormalDocumentStatusChange = async (
        e: number,
        rowData: FormalDocumentsResponse,
        selectedStatus: FormalDocumentStatusType
    ) => {
        let res;
        if (e === STATUS_TYPE_ID.REMINDER_SENT || e === STATUS_TYPE_ID.SENT_FOR_SIGNATURE) {
            res = await poaDocumentReminderSend(rowData.documentId, rowData.fileId);
            if (res) showToastMessage(t('File_UPLOAD.REMINDER_SENT'), ToastType.SUCCESS);
        } else {
            res = await updateFormalDocumentStatus(rowData.documentId, rowData.fileId, e, '', '');
        }

        if (res) {
            handleFormalDocumentDropdownChange(e, rowData.fileId);
            setSelectedStatusTypeId(selectedStatus);
        }
    };

    const handleStatusSubmit = async () => {
        if (selectedFormBuilderData === FormalDocumentAirwayNo) {
            if (selectedRowData?.documentId) {
                closeStatusChangePopup();
                const response = await updateFormalDocumentHardCopyStatus(
                    selectedRowData.documentId,
                    selectedRowData.fileId,
                    selectedHardCopyStatusTypeId?.id as number,
                    formState.data.airwayNo as string
                );
                if (response) {
                    fetchFormalDocuments(requestBody);
                }
            }
        } else {
            if (selectedRowData?.documentId) {
                closeStatusChangePopup();
                const response = await updateFormalDocumentStatus(
                    selectedRowData.documentId,
                    selectedRowData.fileId,
                    selectedStatusTypeId?.id as number,
                    formState.data.reason as string,
                    formState.data.expectedDeliveryDate as string
                );
                if (response) {
                    fetchFormalDocuments(requestBody);
                }
            }
        }
    };

    const optionTemplate = (option: FormalDocumentStatusType) => {
        return (
            <div
                style={{ color: option.color, backgroundColor: option.backgroundColor }}
                className="px-3 p-1 mx-2 w-fit">
                <span className="font-semibold">{option.name}</span>
            </div>
        );
    };

    const optionHardCopyTemplate = (option: FormalDocumentHardCopyStatusType) => {
        return (
            <div
                style={{ color: option.color, backgroundColor: option.backgroundColor }}
                className="px-3 p-1 mx-2 w-fit">
                <span className="font-semibold">{option.name}</span>
            </div>
        );
    };

    const valueTemplate = (option: FormalDocumentStatusType) => {
        return (
            <div
                style={{ color: option?.color, backgroundColor: option?.backgroundColor }}
                className="h-10 w-56 flex items-center justify-between px-3 rounded-sm">
                <span className="font-semibold">{option?.name}</span>
                <i className="pi pi-chevron-down"></i>
            </div>
        );
    };

    const valueHardCopyTemplate = (option: FormalDocumentHardCopyStatusType) => {
        return (
            <div
                style={{ color: option?.color, backgroundColor: option?.backgroundColor }}
                className="h-10 w-56 flex items-center justify-between px-3 rounded-sm">
                <span className="font-semibold">{option?.name}</span>
                <i className="pi pi-chevron-down"></i>
            </div>
        );
    };

    const FormalDocumentStatusTemplate = (rowData: FormalDocumentsResponse) => {
        const getOptionDisabled = (e: { id: number }) => {
            switch (rowData.poAStatusId) {
                case STATUS_TYPE_ID.APPROVED:
                    return (
                        e.id === STATUS_TYPE_ID.WAITING_FOR_APPROVAL ||
                        e.id === STATUS_TYPE_ID.REJECTED
                    );
                case STATUS_TYPE_ID.REJECTED:
                    return (
                        e.id === STATUS_TYPE_ID.WAITING_FOR_APPROVAL ||
                        e.id === STATUS_TYPE_ID.APPROVED
                    );
                case STATUS_TYPE_ID.WAITING_FOR_APPROVAL:
                    return (
                        e.id === STATUS_TYPE_ID.COMPLETED ||
                        e.id === STATUS_TYPE_ID.SENT_FOR_SIGNATURE ||
                        e.id === STATUS_TYPE_ID.REMINDER_SENT
                    );
                case STATUS_TYPE_ID.SENT_FOR_SIGNATURE:
                    return (
                        e.id === STATUS_TYPE_ID.REJECTED ||
                        e.id === STATUS_TYPE_ID.WAITING_FOR_APPROVAL ||
                        e.id === STATUS_TYPE_ID.APPROVED ||
                        e.id === STATUS_TYPE_ID.REMINDER_SENT
                    );
                case STATUS_TYPE_ID.REMINDER_SENT:
                    return (
                        e.id === STATUS_TYPE_ID.REJECTED ||
                        e.id === STATUS_TYPE_ID.WAITING_FOR_APPROVAL ||
                        e.id === STATUS_TYPE_ID.APPROVED ||
                        e.id === STATUS_TYPE_ID.SENT_FOR_SIGNATURE ||
                        e.id === STATUS_TYPE_ID.REMINDER_SENT
                    );
                default:
                    return false;
            }
        };

        return (
            <div>
                {rowData.poAStatusId > 0 ? (
                    <>
                        {(isThisStaffUser || isThisVendorUser) &&
                        rowData.poAStatusId !== STATUS_TYPE_ID.COMPLETED &&
                        rowData.poAStatusId !== STATUS_TYPE_ID.APPROVED &&
                        rowData.poAStatusId !== STATUS_TYPE_ID.REJECTED ? (
                            <div className="flex items-center gap-2">
                                <Dropdown
                                    data-testid={`status-dropdown`}
                                    value={rowData.poAStatusId}
                                    onChange={(e) => {
                                        const selectedStatus = formalDocumentStatus?.find(
                                            (item) => item.id === e.value
                                        );
                                        if (e.value === STATUS_TYPE_ID.REJECTED) {
                                            setSelectedFormBuilderData(FormalDocumentRejectStatus);
                                            setSelectedRowData(rowData);
                                            setSelectedStatusTypeId(selectedStatus);
                                            handleStatusChangePopup();
                                        } else {
                                            setSelectedRowData(rowData);
                                            handleFormalDocumentStatusChange(
                                                e.value as number,
                                                rowData,
                                                selectedStatus as FormalDocumentStatusType
                                            );
                                        }
                                    }}
                                    options={formalDocumentStatus}
                                    optionValue={'id'}
                                    optionLabel="name"
                                    valueTemplate={valueTemplate}
                                    itemTemplate={optionTemplate}
                                    optionDisabled={getOptionDisabled}
                                    style={{ border: 'none' }}
                                    pt={{
                                        root: {
                                            className: 'bg-inherit'
                                        },
                                        trigger: {
                                            className: 'hidden'
                                        },
                                        input: {
                                            className: 'p-0'
                                        },
                                        item: {
                                            className: 'formalDocumentDropdownItemsHidden'
                                        }
                                    }}
                                />
                                {(rowData.poAStatusId === STATUS_TYPE_ID.REMINDER_SENT ||
                                    rowData.poAStatusId === STATUS_TYPE_ID.SENT_FOR_SIGNATURE) && (
                                    <div className="mt-1">
                                        <Tooltip
                                            position="bottom"
                                            target={'.reminderSendTooltip'}
                                            content={'Sent Reminder'}></Tooltip>
                                        <i
                                            className={`pi pi-send reminderSendTooltip text-base mt-[0.20rem] ${rowData.poAStatusId === STATUS_TYPE_ID.SENT_FOR_SIGNATURE ? 'text-[#6D429B]' : 'text-primary'}`}
                                            onClick={() => {
                                                handleFormalDocumentStatusChange(
                                                    STATUS_TYPE_ID.REMINDER_SENT,
                                                    rowData,
                                                    formalDocumentStatus?.find(
                                                        (item) =>
                                                            item.id === STATUS_TYPE_ID.REMINDER_SENT
                                                    ) as FormalDocumentStatusType
                                                );
                                            }}
                                            onKeyDown={(e) => {
                                                if (e?.key === 'Enter' || e.key === ' ') {
                                                    handleFormalDocumentStatusChange(
                                                        STATUS_TYPE_ID.REMINDER_SENT,
                                                        rowData,
                                                        formalDocumentStatus?.find(
                                                            (item) =>
                                                                item.id ===
                                                                STATUS_TYPE_ID.REMINDER_SENT
                                                        ) as FormalDocumentStatusType
                                                    );
                                                }
                                            }}
                                        />
                                    </div>
                                )}{' '}
                            </div>
                        ) : (
                            <div
                                style={{
                                    color: formalDocumentStatus?.find(
                                        (item) => item.id === rowData.poAStatusId
                                    )?.color,
                                    backgroundColor: formalDocumentStatus?.find(
                                        (item) => item.id === rowData.poAStatusId
                                    )?.backgroundColor
                                }}
                                className="h-10 w-56 flex items-center justify-between px-3 rounded-md">
                                <span className="font-semibold">
                                    {
                                        formalDocumentStatus?.find(
                                            (item) => item.id === rowData.poAStatusId
                                        )?.name
                                    }
                                </span>
                            </div>
                        )}
                    </>
                ) : (
                    <>-</>
                )}
            </div>
        );
    };

    const handleFormalDocumentHardCopyStatusChange = (e: number, fileId: number) => {
        handleFormalDocumentHardCopyDropdownChange(e, fileId);
    };

    const handleFormalDocumentHardCopyDropdownChange = (e: number, fileId: number) => {
        const updateFormalDocumentList: FormalDocumentsResponse[] = formalDocumentsList.map(
            (item: FormalDocumentsResponse) => {
                if (item.fileId === fileId) {
                    return { ...item, hardCopyStatusId: e };
                }
                return item;
            }
        );

        setFormalDocumentsList(updateFormalDocumentList);
    };

    const FormalDocumentHardCopyStatusTemplate = (rowData: FormalDocumentsResponse) => {
        const getOptionDisabled = (e: { id: number }) => {
            if (isThisStaffUser || isThisVendorUser) {
                switch (rowData.hardCopyStatusId) {
                    case STATUS_TYPE_ID.NOT_YET_RECEIVED:
                        return (
                            e.id === STATUS_TYPE_ID.DISPATCHED || e.id === STATUS_TYPE_ID.RECEIVED
                        );
                    case STATUS_TYPE_ID.DISPATCHED:
                        return e.id === STATUS_TYPE_ID.NOT_YET_RECEIVED;
                    case STATUS_TYPE_ID.RECEIVED:
                        return (
                            e.id === STATUS_TYPE_ID.NOT_YET_RECEIVED ||
                            e.id === STATUS_TYPE_ID.DISPATCHED
                        );
                    default:
                        return false;
                }
            } else if (isThisContactUser) {
                switch (rowData.hardCopyStatusId) {
                    case STATUS_TYPE_ID.NOT_YET_RECEIVED:
                        return e.id === STATUS_TYPE_ID.RECEIVED;
                    case STATUS_TYPE_ID.DISPATCHED:
                        return (
                            e.id === STATUS_TYPE_ID.NOT_YET_RECEIVED ||
                            e.id === STATUS_TYPE_ID.RECEIVED
                        );
                    case STATUS_TYPE_ID.RECEIVED:
                        return (
                            e.id === STATUS_TYPE_ID.NOT_YET_RECEIVED ||
                            e.id === STATUS_TYPE_ID.DISPATCHED
                        );
                    default:
                        return false;
                }
            }
            return false;
        };

        return (
            <div>
                {rowData.hardCopyStatusId > 0 ? (
                    (isThisContactUser &&
                        rowData.hardCopyStatusId === STATUS_TYPE_ID.NOT_YET_RECEIVED) ||
                    ((isThisStaffUser || isThisVendorUser) &&
                        rowData.hardCopyStatusId === STATUS_TYPE_ID.DISPATCHED) ? (
                        <Dropdown
                            data-testid={'header-status-dropdown'}
                            value={rowData.hardCopyStatusId}
                            onChange={(e) => {
                                const selectedStatus = formalDocumentHardCopyStatus?.find(
                                    (item) => item.id === e.value
                                );
                                if (e.value === STATUS_TYPE_ID.DISPATCHED) {
                                    setSelectedFormBuilderData(FormalDocumentAirwayNo);
                                    setSelectedHardCopyStatusTypeId(selectedStatus);
                                    setSelectedRowData(rowData);
                                    handleStatusChangePopup();
                                } else {
                                    updateFormalDocumentHardCopyStatus(
                                        rowData.documentId,
                                        rowData.fileId,
                                        e.value as number,
                                        ''
                                    );
                                    handleFormalDocumentHardCopyStatusChange(
                                        e.value as number,
                                        rowData.fileId
                                    );
                                }
                            }}
                            options={formalDocumentHardCopyStatus}
                            optionValue={'id'}
                            optionLabel="name"
                            valueTemplate={valueHardCopyTemplate}
                            itemTemplate={optionHardCopyTemplate}
                            optionDisabled={getOptionDisabled}
                            style={{ border: 'none' }}
                            pt={{
                                root: {
                                    className: 'bg-inherit'
                                },
                                trigger: {
                                    className: 'hidden'
                                },
                                input: {
                                    className: 'p-0'
                                },
                                item: {
                                    className: 'formalDocumentDropdownItemsHidden'
                                }
                            }}
                        />
                    ) : (
                        <div
                            style={{
                                color: formalDocumentHardCopyStatus?.find(
                                    (item) => item.id === rowData.hardCopyStatusId
                                )?.color,
                                backgroundColor: formalDocumentHardCopyStatus?.find(
                                    (item) => item.id === rowData.hardCopyStatusId
                                )?.backgroundColor
                            }}
                            className="h-10 w-56 flex items-center justify-between px-3 rounded-md">
                            <span className="font-semibold">
                                {
                                    formalDocumentHardCopyStatus?.find(
                                        (item) => item.id === rowData.hardCopyStatusId
                                    )?.name
                                }
                            </span>
                        </div>
                    )
                ) : (
                    <div>-</div>
                )}
            </div>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            flagIconKey: 'iconName',
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'fileName',
            header: 'Formal Document',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            columnNumber: 2,
            visibility: true,
            body: documentNameWithSizeTemplate
        },
        {
            field: 'documentTypes',
            header: 'Document Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            columnNumber: 3,
            visibility: true,
            filterDropDownOptions: formalDocumentTypes.map((type) => ({
                label: type.name,
                value: `${type.id}`
            }))
        },
        {
            field: 'poAStatusId',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: formalDocumentStatus?.map((status) => ({
                label: status.name,
                value: `${status.id}`
            })),
            columnNumber: 4,
            visibility: true,
            body: FormalDocumentStatusTemplate
        },
        {
            field: 'expectedDeliveryDate',
            header: 'Expected Delivery Date',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'disPatchAddress',
            header: 'Dispatch Address',
            sortable: true,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 6,
            visibility: true
        },
        {
            field: 'hardCopyValues',
            header: 'Hard Copy Required',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 7,
            visibility: true
        },
        {
            field: 'hardCopyStatusId',
            header: 'Hard Copy Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: formalDocumentHardCopyStatus?.map((status) => ({
                label: status.name,
                value: `${status.id}`
            })),
            columnNumber: 8,
            visibility: true,
            body: FormalDocumentHardCopyStatusTemplate
        },
        {
            field: 'airwayNo',
            header: 'Airways No',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 9,
            visibility: true
        },
        {
            field: 'vendorName',
            header: 'Vendor Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 10,
            visibility: true
        },
        {
            field: 'vendorPhoneNumber',
            header: 'Vendor Phone Number',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 11,
            visibility: true
        },
        {
            field: 'vendorEmail',
            header: 'Vendor Email',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 12,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded By',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 13,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 14,
            visibility: true
        },
        {
            field: 'reCallDate',
            header: 'Published On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 15,
            visibility: true
        },
        {
            field: 'actions',
            header: 'Actions',
            sortable: false,
            valueType: ValueType.DeleteIcon,
            filter: false,
            columnNumber: 15,
            visibility: true,
            frozen: true
        }
    ];

    const vendorColumnHide = [
        'vendorName',
        'vendorPhoneNumber',
        'vendorEmail',
        'documentStatus',
        'uploadedBy',
        'uploadedOn',
        'reCallDate'
    ];

    const tableDefinition: DataTableDefinition = {
        title: 'Formal Documents',
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.ORDER_QUOTE_FORMAL_DOCUMENTS,
        emptyMessage: eMessage,
        tableCustomStyle: 'p-0',
        columns: isThisContactUser
            ? columnSchema?.filter((item) => !vendorColumnHide?.includes(item?.field))
            : columnSchema?.filter((item) => item?.field !== 'reCallDate '),
        buttonChildren: uploadDocumentButton(),
        customTableHeight: false,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.FORMAL_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: false
    };

    const handleTriggerFileInputClick = () => {
        if (fileInputTriggerRef.current) {
            fileInputTriggerRef.current(); // Trigger the file input click
        }
    };

    return (
        <div>
            {statusChangePopup && (
                <PopupModal
                    id={'status-change-popup'}
                    title={
                        selectedFormBuilderData === FormalDocumentRejectStatus
                            ? 'PoA Status'
                            : 'Airway No'
                    }
                    onClose={() => closeStatusChangePopup()}
                    createButtonText={'Update'}
                    resetButtonText={'Close'}
                    isEdit={true}
                    onSubmit={() => {
                        handleStatusSubmit();
                    }}>
                    <div className="formalDocumentUpload">
                        <Form
                            form={formBuilderData}
                            onChange={(e: any) => {
                                onFormChange(e);
                            }}
                        />
                    </div>
                </PopupModal>
            )}
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <FileUpload
                className="hidden"
                triggerFileInputClick={(triggerFileInput: () => void) => {
                    fileInputTriggerRef.current = triggerFileInput;
                }}
                uploadFileApiUrl={uploadFileApiUrl}
                moduleType={{
                    moduleId: MODULE_TYPE.FORMAL_DOCUMENT_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.FORMAL_DOCUMENT_MODULE.azureFolderName
                }}
                primaryId={toggleRowData?.id}
                deleteFileApiUrl={''}
                getDocumentTypeApiUrl={''}
                updateDocumentTypeApiUrl={''}
                ifFormalDocumentUpload={{ isFormalDoc: true, isExistingDocReplace: true }}
                formalDocumentFields={{
                    documentType: toggleRowData?.documentType,
                    hardCopy: toggleRowData?.hardCopy
                }}
                multipleFiles={false}
                moduleName={`formalDocument-${toggleRowData?.id}`}
            />
            {showModal && (
                <FormalDocumentUploadPopup
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    closeModal={closeModal}
                    onSubmit={() => {}}
                />
            )}
            {showFileDeletePopup.visible ? (
                <ConfirmationPopup
                    onConfirm={handleConfirm}
                    onCancel={handleCancel}
                    visible={showFileDeletePopup.visible}
                    headerText={showFileDeletePopup.header}
                    description={showFileDeletePopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    popupID={'deleteFormalDocumentPopup'}
                />
            ) : null}
            <div className="formalDocumentTable">
                <DataTableComponent
                    tableData={formalDocumentsList}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    toggleRowData={() => {}}
                    showPagination={true}
                    handleFilter={handleFilter}
                    deleteRecord={handleDeleteRecord}
                    handleSort={sortHandler}
                    handlePagination={handlePageChange}
                    tablePaginationData={paginationInfo}
                />
            </div>
        </div>
    );
};

export default FormalDocuments;
