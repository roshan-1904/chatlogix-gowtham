import {
    OfficialReceiptsDocumentsResponse,
    SourceDocumentData
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import {
    getOfficialFilingReceiptDocuments,
    updateStatusPublishToCustomer
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import {
    QUOTE_ORDER_USER_MODULE,
    VIEW_QUOTE_ORDER_MODULE
} from 'constants/fileUploadApiUrl.constant';
import { DOCUMENT_TYPE, MODULE_TYPE } from 'constants/app.constant';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { Dialog } from 'primereact/dialog';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import utils, { getWindowSize, isContactUser, isPMorAdminUser } from 'core/utils/utils';
import { previewDialogPopup } from 'constants/styles.constant';
import PrimeButton from 'components/buttons/primeButton';
import OfficialFilingReceiptDocumentUpload from './officialFilingReceiptDocumentUploadUploadPopup/officialFilingReceiptDocumentUpload';
import { Dropdown } from 'primereact/dropdown';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';

const OfficialFilingReceiptDocument: React.FC<OfficialReceiptsDocumentsResponse> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    flags
}) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isTheContactUser = isContactUser(loggedInUserRoleId);
    const isTheAdminOrPmUser = isPMorAdminUser(loggedInUserRoleId);
    const { t } = useTranslation();
    const { requestId } = useParams();
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${MODULE_TYPE.UPC_DOCUMENT_MODULE.moduleId}`; // Get document type API URL
    const [showModal, setShowModal] = useState(false);
    const [orderFilingReceiptDocumentsModelList, setOrderFilingReceiptDocumentsModelList] =
        useState<SourceDocumentData[]>([]);
    const [fileTypes, setFileTypes] = useState<any>([]);
    const actionType = {
        delete: 'delete',
        publishToCustomer: 'publishToCustomer'
    };
    const [toggleRowData, setToggleRowData] = useState<SourceDocumentData | null>(null);
    const [showPopup, setShowPopup] = useState({
        actionType: '',
        visible: false,
        header: '',
        description: ''
    });
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const emptyMessage = t('COMMON.NO_DATA_FOUND');
    const [errMessage, setErrMessage] = useState<undefined | string>(undefined);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription.unsubscribe();
        };
    }, []);

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 2000) {
                    handleGetFilingReceiptDocuments(requestBody);
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    const handlePublishToCustomer = async (rowData: SourceDocumentData) => {
        try {
            await updateStatusPublishToCustomer(
                rowData.documentId,
                rowData.fileId,
                !rowData.reCall
            );
            handleGetFilingReceiptDocuments(requestBody);
        } catch (error) {
            console.error('Error publishing document to customer:', error);
        }
    };

    // Confirming file deletion
    const handleConfirm = () => {
        if (toggleRowData) {
            if (showPopup.actionType === actionType.publishToCustomer) {
                handlePublishToCustomer(toggleRowData);
            }
            setShowPopup({ ...showPopup, visible: false });
        }
    };

    // Canceling file deletion
    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    // Fetching SAS URL on component mount
    useEffect(() => {
        getSasUrlApi();
        fetchDocumentTypes();
    }, []);

    // Fetching document types and official filing receipts documents on component mount
    useEffect(() => {
        handleGetFilingReceiptDocuments(requestBody);
    }, [requestBody]);

    // Fetching document types
    const fetchDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        const filteredResponse = response.filter(
            (item: { id: number }) => item.id === DOCUMENT_TYPE.OFFICIAL_RECEIPT.id
        );
        setFileTypes(filteredResponse);
    };

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const DocumentPreviewTemplate = (rowData: SourceDocumentData) => {
        return (
            <div className="flex justify-between items-center gap-3">
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'fileNameTooltip' + rowData.fileId + ' flex items-center gap-1'}>
                    {fileTypeIcon(rowData.fileType)}
                    <p
                        className="text-base text-primary font-medium underline underline-offset-1 max-w-64 truncate cursor-pointer"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handlePreviewDocument(rowData);
                            }
                        }}
                        tabIndex={0}>
                        {rowData.fileName}
                    </p>
                </div>

                {isTheAdminOrPmUser && (
                    <div className="w-5">
                        <label className="cursor-pointer">
                            <div className="h-5 w-5">
                                <Tooltip
                                    position="bottom"
                                    target={'.fileTooltip'}
                                    content={'Replace the existing file'}></Tooltip>
                                <img
                                    src={uploadIcon}
                                    className="fileTooltip w-full h-full"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => {
                                        setToggleRowData(rowData);
                                    }}
                                />
                            </div>
                            <input
                                type="file"
                                id="upload-completed-Template"
                                hidden
                                accept=".xlsx, .xls"
                                onChange={(e) => {
                                    setUploadedFile(null);
                                    const file = e.target.files?.[0];
                                    if (file) {
                                        setUploadedFile(file);
                                    }
                                }}
                            />
                        </label>
                    </div>
                )}
            </div>
        );
    };

    const DocumentTypeTemplate = (rowData: SourceDocumentData) => {
        return (
            <div>
                {fileTypes.map((type: { id: number; name: string }) => {
                    if (type.id === Number(rowData.documentType)) {
                        return (
                            <p key={rowData.documentId} className="text-base">
                                {type.name}
                            </p>
                        );
                    }
                })}
            </div>
        );
    };

    const publishToCustomerTemplate = (rowData: SourceDocumentData) => {
        const isOfficialFilingReceipt =
            Number(rowData.documentType) === DOCUMENT_TYPE.OFFICIAL_RECEIPT.id;
        return (
            <div>
                {isOfficialFilingReceipt ? (
                    isTheContactUser ? (
                        <>{rowData?.reCall ? 'Yes' : 'No'}</>
                    ) : (
                        <Dropdown
                            value={rowData?.reCall ?? false}
                            options={[
                                { label: 'Yes', value: true },
                                { label: 'No', value: false }
                            ]}
                            onChange={(e) => {
                                setToggleRowData(rowData);
                                setShowPopup({
                                    actionType: actionType.publishToCustomer,
                                    visible: true,
                                    header: t('COMMON.CONFIRMATION'),
                                    description: e.value
                                        ? t(
                                              'File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_CONFIRMATION_YES'
                                          )
                                        : t(
                                              'File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_CONFIRMATION_NO'
                                          )
                                });
                            }}
                            optionLabel="label"
                            optionValue="value"
                            pt={{
                                root: {
                                    className:
                                        'hover:border-primary font-medium border-transparent hover:border bg-inherit h-8 flex items-center w-fit md:w-fit'
                                },
                                item: {
                                    className: 'hover:bg-primary-50'
                                },
                                input: {
                                    className: '!block p-2 text-base'
                                }
                            }}
                        />
                    )
                ) : (
                    <>-</>
                )}
            </div>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'fileName',
            header: 'Document Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: DocumentPreviewTemplate,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'documentType',
            header: 'Document Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            valueType: ValueType.Text,
            filterDropDownOptions: fileTypes.map((type: { name: any; id: any }) => ({
                label: type.name,
                value: `${type.id}`
            })),
            columnNumber: 2,
            visibility: true,
            body: DocumentTypeTemplate
        },
        {
            field: 'reCall',
            header: 'Publish to Customer',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            body: publishToCustomerTemplate,
            filterDropDownOptions: [
                { label: 'Yes', value: 'true' },
                { label: 'No', value: 'false' }
            ],
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded by',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 6,
            visibility: true
        }
    ];

    const handleClick = () => {
        openModal().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const uploadDocumentButton = () => {
        return (
            // As per client feedback, hiding the button temporarily
            <a href="#file-upload" className="hidden">
                <PrimeButton
                    testid="upload-documents-ip-official filing receipts documents"
                    label={'Upload Document'}
                    type="primary"
                    className=""
                    disabled={flags?.isCompleted || flags?.isInvoiced}
                    icon="pi pi-cloud-upload"
                    size="medium"
                    onClick={handleClick}
                />
            </a>
        );
    };

    const tableDefinition: DataTableDefinition = {
        title: 'Official Filing Receipt(s)',
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.ORDER_QUOTE_OFFICIAL_FILING_RECEIPTS_DOCUMENTS,
        emptyMessage: errMessage,
        tableCustomStyle: 'p-0',
        columns: isTheContactUser
            ? columnSchema.filter((col) => col.field !== 'reCall')
            : columnSchema,
        buttonChildren: isTheContactUser ? null : uploadDocumentButton(),
        customTableHeight: false,
        localStorageKey:
            DATA_STORAGE_KEYS.DATA_TABLE.OFFICIAL_FILING_RECEIPTS_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: false
    };

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }

        // Update the URL fragment without reloading the page
        window.location.hash = 'uploaded-documents-container';
    };

    // Fetch and process official filing receipts documents
    const handleGetFilingReceiptDocuments = async (body: RequestBody) => {
        try {
            const response: OfficialReceiptsDocumentsResponse =
                await getOfficialFilingReceiptDocuments<OfficialReceiptsDocumentsResponse>(
                    String(requestId),
                    body
                );

            setOrderFilingReceiptDocumentsModelList(
                response.orderOfficialReceiptDocumentsModel as SourceDocumentData[]
            );

            const pagination: paginationData = {
                pageNo: body.pageNo,
                totalPages: Math.ceil((response.total ?? 0) / body.pageCount),
                totalRecords: response.total as number
            };
            setBlobURL(response.blobUri);
            setPaginationInfo(pagination);

            if (response.orderOfficialReceiptDocumentsModel?.length === 0)
                setErrMessage(emptyMessage);
        } catch (error) {
            console.error('Error fetching official filing receipts documents:', error);
            setErrMessage(emptyMessage);
        }
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    return (
        <div>
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <FileUpload
                className="hidden"
                uploadFileApiUrl={`${quoteBaseURL}${VIEW_QUOTE_ORDER_MODULE.UPLOAD_FILE}${orderOrQuoteId}&moduleType=${MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId}`}
                moduleType={{
                    moduleId: MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName
                }}
                primaryId={primaryIdForAzureStorage}
                documentTypeId={Number(toggleRowData?.documentType)}
                deleteFileApiUrl={null}
                getDocumentTypeApiUrl={null}
                updateDocumentTypeApiUrl={null}
                multipleFiles={false}
                moduleName={`upcOptOut-${orderOrQuoteId}`}
                triggerHandleFiles={
                    uploadedFile
                        ? (handleFiles: (files: File[]) => void) => {
                              handleFiles([uploadedFile]);
                              setUploadedFile(null);
                          }
                        : undefined
                }
                replaceFileId={toggleRowData?.fileId}
            />
            {showPopup.visible ? (
                <ConfirmationPopup
                    key={'OfficialDocumentPopup'}
                    onConfirm={handleConfirm}
                    onCancel={handleCancel}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={t('COMMON.YES')}
                    rejectLabel={t('COMMON.NO')}
                    popupID={'OfficialDocumentPopup'}
                />
            ) : null}
            {showModal && (
                <OfficialFilingReceiptDocumentUpload
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    closeModal={closeModal}
                    onSubmit={() => {}}
                />
            )}
            <DataTableComponent
                tableData={orderFilingReceiptDocumentsModelList ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={handleFilter}
                toggleRowData={() => {}}
                previewDocument={handlePreviewDocument}
                handlePagination={handlePageChange}
                tablePaginationData={paginationInfo}
                showPagination={true}
                handleSort={sortHandler}
            />
        </div>
    );
};

export default OfficialFilingReceiptDocument;
