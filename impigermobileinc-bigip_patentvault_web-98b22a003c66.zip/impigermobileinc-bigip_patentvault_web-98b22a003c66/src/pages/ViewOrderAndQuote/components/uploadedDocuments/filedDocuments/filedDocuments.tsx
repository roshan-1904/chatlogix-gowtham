import {
    getFiledDocuments,
    getFinalDocuments,
    getStandardTranslatedDocuments,
    getTaskDocumentStatus,
    updateStatusPublishToCustomer,
    updateSTDStatusPublishToCustomer,
    updateTaskDocumentStatus
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import {
    FiledDocumentsType,
    FiledDocumentsTypeResponse,
    TaskDocumentStatusType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dialog } from 'primereact/dialog';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
    FilterType,
    TableTypes,
    ValueType,
    statusIndicators
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import DocumentUploadPopup from './filedDocumentUploadPopup/filedDocumentUploadPopup';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { Task } from 'pages/taskManagement/types/tasks.types';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { TaskNameTemplate } from 'pages/taskManagement/shared/taskManagementHelper';
import { DOCUMENT_TYPE, IP_NONIP, MODULE_TYPE, STATUS_TYPE_ID } from 'constants/app.constant';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import PopupModal from 'components/popupModal/popupModal';
import HttpService from 'core/interceptor/api.handler';
import filedDocumentRejectionForm from './filedDocumentRejectReason.json';
import { Form } from '@formio/react';
import formStatusStore from 'core/store/formIoStore/formIoStore';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import utils, { getWindowSize, isContactUser } from 'core/utils/utils';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import { ORDER_QUOTE_MODULE, QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { previewDialogPopup } from 'constants/styles.constant';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';
import PrimeButton from 'components/buttons/primeButton';

const FiledDocuments: React.FC<FiledDocumentsType> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    viewData,
    isEditable,
    flags
}) => {
    const { t } = useTranslation();
    const { requestId } = useParams();
    const [orderFiledDocumentsModelList, setOrderFiledDocumentsModelList] = useState<
        FiledDocumentsTypeResponse[]
    >([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const NO_DATA_FOUND = t('COMMON.NO_DATA_FOUND');
    const [emptyMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [showModal, setShowModal] = useState(false);
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const [taskDocumentStatus, setTaskDocumentStatus] = useState<TaskDocumentStatusType[]>([]);
    const [statusChangePopup, setStatusChangePopup] = useState(false);
    const httpService = new HttpService();
    const formBuilderData = httpService.updateJsonDataWithDynamicValues(filedDocumentRejectionForm);
    const [selectedRowData, setSelectedRowData] = useState<FiledDocumentsTypeResponse>();
    const [selectedExistingDocument, setSelectedExistingDocument] = useState<any>();
    const [selectedStatusId, setSelectedStatusId] = useState<number>();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const [fileTypes, setFileTypes] = useState<any>([]);
    const [publishToCustomerFlag, setPublishToCustomerFlag] = useState<boolean>(false);
    const [isPublishToCustomerDropdown, setIsPublishToCustomerDropdown] = useState<boolean>(false);
    const fileInputTriggerRef = useRef<(() => void) | null>(null);

    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

    const showToastMessage = (toastMsg: string, errorType: ToastType) => {
        const message: notificationModel = {
            message: toastMsg,
            type: errorType
        };
        NotificationStore.showAlert(message);
    };

    const onFormChange = (e: any) => {
        const { data, isValid } = e;
        const updatedFormDate = JSON.parse(JSON.stringify(data));
        formStatusStore.updateFormData(updatedFormDate, !!isValid);
    };

    useEffect(() => {
        fetchDocumentTypes();
        handleGetFiledDocuments(requestBody);
    }, [requestBody]);

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    // Fetching document types
    const fetchDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        const filteredResponse = response.filter(
            (item: { id: number }) =>
                item.id !== DOCUMENT_TYPE.SOURCE.id &&
                item.id !== DOCUMENT_TYPE.REFERENCE.id &&
                item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id
        );
        setFileTypes(filteredResponse);
    };

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 2000) {
                    handleGetFiledDocuments(requestBody);
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    useEffect(() => {
        getSasUrlApi();
        handleGetTaskDocumentStatus();
    }, []);

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const handleGetFiledDocuments = async (body: RequestBody) => {
        let response: FiledDocumentsType;

        if (!isNonIp) {
            if (isThisContactUser) {
                response = await getFinalDocuments<FiledDocumentsType>(String(requestId), body);
            } else {
                response = await getFiledDocuments<FiledDocumentsType>(String(requestId), body);
            }
        } else {
            response = await getStandardTranslatedDocuments<FiledDocumentsType>(
                String(requestId),
                body
            );
        }

        setOrderFiledDocumentsModelList(
            response?.orderFiledDocumentsModel as FiledDocumentsTypeResponse[]
        );
        setBlobURL(response.blobUri);
        const pagination: paginationData = {
            pageNo: body.pageNo,
            totalPages: Math.ceil(response.total ?? 0 / body.pageCount),
            totalRecords: response.total ?? 0
        };

        setPaginationInfo(pagination);
        if (response.orderFiledDocumentsModel?.length === 0) {
            setEmptyMessage(NO_DATA_FOUND);
        }
    };

    const handleGetTaskDocumentStatus = async () => {
        const response: TaskDocumentStatusType[] = await getTaskDocumentStatus();
        if (response) {
            const documentWithColor = response.map((statusData: { id: number; name: string }) => ({
                id: statusData?.id,
                name: statusData?.name,
                ...statusIndicators(statusData.name)
            }));

            setTaskDocumentStatus(documentWithColor);
        }
    };

    const handleClick = () => {
        openModal().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }

        // Update the URL fragment without reloading the page
        window.location.hash = 'uploaded-documents-container';
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    const uploadDocumentButton = () => {
        return (
            <PrimeButton
                testid="upload-documents-ip-filed"
                label={'Upload Document'}
                type="primary"
                className=""
                disabled={flags?.isCompleted || flags?.isInvoiced}
                icon="pi pi-cloud-upload"
                size="medium"
                onClick={handleClick}
            />
        );
    };

    const taskTitleTemplate = (task: Task) => {
        const userIconTemplate = TaskNameTemplate(task?.taskName);

        return (
            <div className="flex items-center">
                <img className="h-[16px]" src={userIconTemplate} alt="" />
                <span className="pl-3">{task.taskName}</span>
            </div>
        );
    };

    const optionTemplate = (option: TaskDocumentStatusType) => {
        return (
            <div
                style={{ color: option.color, backgroundColor: option.backgroundColor }}
                className="px-3 p-1 mx-2 w-fit">
                <span className="font-semibold">{option.name}</span>
            </div>
        );
    };

    const handleDropdownChange = async (
        statusValue: number,
        rowData: FiledDocumentsTypeResponse,
        rejectionReason: string | null
    ) => {
        const updatedTaskDocumentStatus = !isNonIp
            ? await await updateTaskDocumentStatus(
                  rowData.documentId,
                  rowData.taskrefId,
                  rowData.fileId,
                  statusValue,
                  rejectionReason
              )
            : await updateSTDStatusPublishToCustomer({
                  documentId: selectedRowData?.documentId,
                  taskId: selectedRowData?.taskrefId,
                  changestatus: null,
                  statusId: selectedStatusId,
                  rejectionReason
              });

        if (updatedTaskDocumentStatus) {
            handleGetFiledDocuments(requestBody);
        }
    };

    const handleChange = (e: DropdownChangeEvent, rowData: FiledDocumentsTypeResponse) => {
        if (e.value === STATUS_TYPE_ID.DOCUMENT_REJECTED) {
            handleStatusChangePopup();
        } else if (e.value === STATUS_TYPE_ID.DOCUMENT_APPROVED) {
            setShowPopup({
                visible: true,
                header: t('COMMON.CONFIRMATION'),
                description: t('File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_CONFIRMATION_DESCRIPTION'),
                onConfirmLabel: t('COMMON.APPROVE_PUBLISH'),
                onCancelLabel: t('COMMON.APPROVE_ONLY')
            });
        } else {
            handleDropdownChange(e.value as number, rowData, null).catch((error) => {
                console.error('Error updating task document status:', error);
            });
        }
    };

    const handleStatusSubmit = () => {
        closeStatusChangePopup();
        handleDropdownChange(
            selectedStatusId as number,
            selectedRowData as FiledDocumentsTypeResponse,
            formStatusStore.getFormData().data.rejectionReason as string
        ).catch((error) => {
            console.error('Error updating task document status:', error);
        });
    };

    const handleStatusChangePopup = () => {
        openStatusChangePopup().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const openStatusChangePopup = async () => {
        setStatusChangePopup(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'filed-status-change-popup'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeStatusChangePopup = () => {
        setStatusChangePopup(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'filed-status-change-popup'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const valueTemplate = (option: TaskDocumentStatusType) => {
        return (
            <div
                style={{ color: option?.color, backgroundColor: option?.backgroundColor }}
                className="h-10 w-56 flex items-center justify-between px-3 rounded-sm">
                <span className="font-semibold">{option?.name}</span>
                <i className="pi pi-chevron-down"></i>
            </div>
        );
    };

    const taskDocumentStatusTemplate = (rowData: FiledDocumentsTypeResponse) => {
        const getOptionDisabled = (e: { id: number }) => {
            switch (rowData.documentStatus) {
                case STATUS_TYPE_ID.DOCUMENT_APPROVED:
                    return e.id === STATUS_TYPE_ID.DOCUMENT_IN_REVIEW;
                case STATUS_TYPE_ID.DOCUMENT_REJECTED:
                    return (
                        e.id === STATUS_TYPE_ID.DOCUMENT_IN_REVIEW ||
                        e.id === STATUS_TYPE_ID.DOCUMENT_APPROVED
                    );
                default:
                    return false;
            }
        };

        return (
            <div>
                {rowData.documentType === DOCUMENT_TYPE.TRANSLATED.id ? (
                    rowData.documentStatus === STATUS_TYPE_ID.DOCUMENT_IN_REVIEW ? (
                        <Dropdown
                            data-testid={'header-status-dropdown'}
                            value={rowData.documentStatus}
                            onChange={(e) => {
                                handleChange(e, rowData);
                                setSelectedRowData(rowData);
                                setSelectedStatusId(e.value as number);
                            }}
                            options={taskDocumentStatus}
                            optionValue="id"
                            optionLabel="name"
                            itemTemplate={optionTemplate}
                            valueTemplate={valueTemplate}
                            optionDisabled={getOptionDisabled}
                            style={{ border: 'none' }}
                            pt={{
                                root: {
                                    className: 'bg-inherit'
                                },
                                trigger: {
                                    className: 'hidden'
                                },
                                input: {
                                    className: 'p-0'
                                },
                                item: {
                                    className: 'filedDocumentDropdownItemsHidden'
                                }
                            }}
                        />
                    ) : (
                        <div
                            style={{
                                color: taskDocumentStatus?.find(
                                    (item) => item.id === rowData.documentStatus
                                )?.color,
                                backgroundColor: taskDocumentStatus?.find(
                                    (item) => item.id === rowData.documentStatus
                                )?.backgroundColor
                            }}
                            className="h-10 w-56 flex items-center justify-between px-3 rounded-md">
                            <span className="font-semibold">
                                {
                                    taskDocumentStatus?.find(
                                        (item) => item.id === rowData.documentStatus
                                    )?.name
                                }
                            </span>
                        </div>
                    )
                ) : (
                    <>-</>
                )}
            </div>
        );
    };

    const handleTriggerFileInputClick = () => {
        if (fileInputTriggerRef.current) {
            fileInputTriggerRef.current(); // Trigger the file input click
        }
    };

    const documentNameWithSizeTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.translatedDoctName' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'flex items-center justify-between gap-3'}>
                    <div
                        className={
                            'translatedDoctName' + rowData.fileId + ' flex items-center gap-2'
                        }>
                        {fileTypeIcon(rowData.fileType as string)}
                        <p
                            className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56 cursor-pointer"
                            onClick={() => handlePreviewDocument(rowData)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                    handlePreviewDocument(rowData);
                                }
                            }}
                            tabIndex={0}>
                            {rowData.fileName}
                        </p>
                        <p className="text-base text-neutral-200">{rowData.fileSize}</p>
                    </div>
                    {rowData.documentStatus !== STATUS_TYPE_ID.DOCUMENT_APPROVED &&
                        !isThisContactUser && (
                            <div className="w-5">
                                <label className="cursor-pointer">
                                    <div className="h-5 w-5">
                                        <Tooltip
                                            position="bottom"
                                            target={'.fileTooltip'}
                                            content={'Replace the existing file'}></Tooltip>
                                        <img
                                            src={uploadIcon}
                                            className="fileTooltip w-full h-full"
                                            onKeyDown={(e) =>
                                                e.key === 'Enter' && e.currentTarget.click()
                                            }
                                            onClick={() => {
                                                setSelectedExistingDocument(rowData);
                                                handleTriggerFileInputClick();
                                            }}
                                        />
                                    </div>
                                </label>
                            </div>
                        )}
                </div>
            </div>
        );
    };

    const handleDocApprove = (value: boolean) => {
        setShowPopup({
            visible: true,
            header: t('COMMON.CONFIRMATION'),
            description: value
                ? t('File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_CONFIRMATION_YES')
                : t('File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_CONFIRMATION_NO'),
            onConfirmLabel: t('COMMON.YES'),
            onCancelLabel: t('COMMON.NO')
        });
    };

    const updatePublishToCustomerFlag = async (publishToCM: boolean) => {
        if (!selectedRowData) return;
        // if (selectedRowData.taskName == 'Other Translations') {
        //     const translatedDocPublishToCustomer = await updateSTDStatusPublishToCustomer(
        //         selectedRowData?.documentId,
        //         selectedRowData?.fileId,
        //         publishToCM
        //     );
        // } else {
        const translatedDocPublishToCustomer = !isNonIp
            ? await updateStatusPublishToCustomer(
                  selectedRowData?.documentId,
                  selectedRowData?.fileId,
                  publishToCM
              )
            : await updateSTDStatusPublishToCustomer({
                  documentId: selectedRowData?.documentId,
                  taskId: selectedRowData?.taskrefId,
                  changestatus: publishToCM,
                  statusId: selectedStatusId
              });
        // }
        if (
            !isNonIp &&
            selectedStatusId &&
            selectedRowData.documentStatus !== STATUS_TYPE_ID.DOCUMENT_APPROVED &&
            selectedRowData.documentType !== DOCUMENT_TYPE.TRANSLATOR_COMMENTS.id
        ) {
            handleDropdownChange(selectedStatusId, selectedRowData, null);
        }

        if (translatedDocPublishToCustomer) {
            handleGetFiledDocuments(requestBody);
            if (!isPublishToCustomerDropdown) {
                if (publishToCM) {
                    showToastMessage(
                        t('File_UPLOAD.TRANSLATED_DOCUMENT_APPROVE_PUBLISH'),
                        ToastType.SUCCESS
                    );
                } else {
                    showToastMessage(
                        t('File_UPLOAD.TRANSLATED_DOCUMENT__APPROVE'),
                        ToastType.SUCCESS
                    );
                }
            } else {
                if (!publishToCM) {
                    showToastMessage(
                        t('File_UPLOAD.TRANSLATED_DOCUMENT_RECALL'),
                        ToastType.SUCCESS
                    );
                } else {
                    showToastMessage(
                        t('File_UPLOAD.TRANSLATED_DOCUMENT_PUBLISH'),
                        ToastType.SUCCESS
                    );
                }
            }
        }
    };

    const publishToCustomerTemplate = (rowData: FiledDocumentsTypeResponse) => {
        const isOfficialFillingRecepit =
            rowData.documentType === DOCUMENT_TYPE.OFFICIAL_FILING_RECEIPT.id;

        const isForTranslatorDocument =
            rowData.documentStatus === STATUS_TYPE_ID.DOCUMENT_APPROVED ||
            rowData.documentType === DOCUMENT_TYPE.TRANSLATOR_COMMENTS.id;

        return (
            <div>
                {isOfficialFillingRecepit || isForTranslatorDocument ? (
                    <Dropdown
                        value={rowData.reCall}
                        options={[
                            { label: 'Yes', value: true },
                            { label: 'No', value: false }
                        ]}
                        onChange={(e) => {
                            handleDocApprove(e.value as boolean);
                            setSelectedRowData(rowData);
                            setPublishToCustomerFlag(e.value as boolean);
                            setIsPublishToCustomerDropdown(true);
                        }}
                        optionLabel="label"
                        optionValue="value"
                        pt={{
                            root: {
                                className:
                                    'hover:border-primary font-medium border-transparent hover:border bg-inherit h-8 flex items-center w-fit md:w-fit'
                            },
                            item: {
                                className: 'hover:bg-primary-50'
                            },
                            input: {
                                className: '!block p-2 text-base'
                            }
                        }}
                    />
                ) : (
                    <>-</>
                )}
            </div>
        );
    };

    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: '',
        description: (<></>) as any,
        onConfirmLabel: '',
        onCancelLabel: ''
    });

    const handleConfirm = () => {
        if (isPublishToCustomerDropdown) {
            updatePublishToCustomerFlag(publishToCustomerFlag);
        } else {
            updatePublishToCustomerFlag(true);
        }
        setIsPublishToCustomerDropdown(false);
        setShowPopup({
            visible: false,
            header: '',
            description: '',
            onConfirmLabel: '',
            onCancelLabel: ''
        });
    };

    const handleCancel = () => {
        if (!isPublishToCustomerDropdown) {
            updatePublishToCustomerFlag(false);
        }
        setIsPublishToCustomerDropdown(false);
        setShowPopup({
            visible: false,
            header: '',
            description: '',
            onConfirmLabel: '',
            onCancelLabel: ''
        });
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskId',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'taskName',
            header: 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: taskTitleTemplate,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            flagIconKey: 'iconName',
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'documentTypes',
            header: 'Document Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: fileTypes.map((status: { name: any; id: any }) => ({
                label: status.name,
                value: `${status.id}`
            })),
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'fileName',
            header: 'Document',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            columnNumber: 6,
            visibility: true,
            body: documentNameWithSizeTemplate
        },
        {
            field: 'documentStatus',
            header: 'Document Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: taskDocumentStatus.map((status) => ({
                label: status.name,
                value: `${status.id}`
            })),
            body: taskDocumentStatusTemplate,
            columnNumber: 7,
            visibility: true
        },
        {
            field: 'reCall',
            header: 'Publish to Customer',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            columnNumber: 8,
            visibility: true,
            body: publishToCustomerTemplate,
            filterDropDownOptions: [
                { label: 'Yes', value: 'true' },
                { label: 'No', value: 'false' }
            ]
        },
        {
            field: 'expectedDeliveryDate',
            header: 'Expected Delivery Date',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 9,
            visibility: true
        },
        {
            field: 'vendor',
            header: 'Vendor Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 10,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded By',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 11,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 12,
            visibility: true
        },
        {
            field: 'reCallDate',
            header: 'Published On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 13,
            visibility: true
        }
    ];
    const requestType = viewData?.requestType;
    const isNonIp = requestType === IP_NONIP.nonIp;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${MODULE_TYPE.FILED_DOCUMENT_MODULE.moduleId}`;
    const uploadFileApiUrl = isNonIp
        ? `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_STD_SOURCE_DOCUMENT}/${selectedExistingDocument?.documentId}`
        : `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_FILED_EXISTING_FILE}/${selectedExistingDocument?.taskrefId}/${selectedExistingDocument?.documentId}/${selectedExistingDocument?.fileId}`; // Replace existing file API URL

    // const nonIpColumns = ['fileName', 'targetLanguage', 'sourceLanguage'];
    const removeColumnForCM = [
        'taskId',
        'taskName',
        'vendor',
        'reCall',
        'documentStatus',
        'uploadedBy',
        'uploadedOn'
    ];
    // const removeColumnForVendor = ['reCall'];

    const getColumns = () => {
        let filteredColumnSchema = columnSchema.filter((item) => item.visibility);
        if (isThisContactUser) {
            filteredColumnSchema = columnSchema?.filter(
                (item) => !removeColumnForCM?.includes(item?.field)
            );
        }

        // else if (isVendorUser(loggedInUserRoleId)) {
        //     filteredColumnSchema = columnSchema?.filter(
        //         (item) => !removeColumnForVendor?.includes(item?.field)
        //     );
        // }
        if (isNonIp) {
            filteredColumnSchema = filteredColumnSchema.filter(
                (item) => item.field !== 'targetCountry'
            );
        }
        if (!isThisContactUser) {
            filteredColumnSchema = columnSchema?.filter((item) => item?.field !== 'reCallDate');
        }
        return filteredColumnSchema;
    };

    const tableDefinition: DataTableDefinition = {
        title: isNonIp
            ? t('File_UPLOAD.TRANSLATED_DOCUMENT')
            : t('File_UPLOAD.TRANSLATED_FILED_DOCUMENT'),
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.ORDER_QUOTE_FILED_DOCUMENTS,
        emptyMessage,
        tableCustomStyle: 'p-0',
        columns: getColumns(),
        ...(!isThisContactUser && isEditable && { buttonChildren: uploadDocumentButton() }),
        customTableHeight: false,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.FILED_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: false
    };

    return (
        <div>
            {showPopup.visible ? (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleConfirm();
                    }}
                    onCancel={() => {
                        handleCancel();
                    }}
                    visible={showPopup.visible}
                    headerText={showPopup.header}
                    description={showPopup.description}
                    acceptLabel={showPopup.onConfirmLabel}
                    rejectLabel={showPopup.onCancelLabel}
                    popupID={'deleteFileConfirmationPopup'}
                    closeIcon={{
                        isTopCloseIcon: true,
                        isOnClickClose: () => setShowPopup({ ...showPopup, visible: false })
                    }}
                />
            ) : null}
            {statusChangePopup && (
                <PopupModal
                    id={'filed-status-change-popup'}
                    title={'Document Status'}
                    onClose={() => closeStatusChangePopup()}
                    createButtonText={'Confirm'}
                    resetButtonText={'Close'}
                    isEdit={true}
                    onSubmit={() => {
                        handleStatusSubmit();
                    }}>
                    <div className="filedDocumentStatusPopup">
                        <Form
                            form={formBuilderData}
                            onChange={(e: any) => {
                                onFormChange(e);
                            }}
                        />
                    </div>
                </PopupModal>
            )}

            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <FileUpload
                className="hidden"
                triggerFileInputClick={(triggerFileInput: () => void) => {
                    fileInputTriggerRef.current = triggerFileInput;
                }}
                uploadFileApiUrl={uploadFileApiUrl}
                moduleType={{
                    moduleId: MODULE_TYPE.FILED_DOCUMENT_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.FILED_DOCUMENT_MODULE.azureFolderName
                }}
                primaryId={selectedExistingDocument?.id as number}
                deleteFileApiUrl={''}
                getDocumentTypeApiUrl={''}
                updateDocumentTypeApiUrl={''}
                ifFiledDocumentUpload={{ isFiledDoc: true, isExistingDocReplace: true }}
                filedDocumentFields={{
                    documentType: selectedExistingDocument?.documentType
                }}
                multipleFiles={false}
                moduleName={`filedDocument-${selectedExistingDocument?.id}`}
            />
            {showModal && (
                <DocumentUploadPopup
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    closeModal={closeModal}
                    onSubmit={() => {}}
                    isNonIp={isNonIp}
                />
            )}
            <DataTableComponent
                tableData={orderFiledDocumentsModelList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                previewDocument={handlePreviewDocument}
                showPagination={true}
                handlePagination={handlePageChange}
                tablePaginationData={paginationInfo}
                handleSort={sortHandler}
                handleFilter={handleFilter}
            />
        </div>
    );
};
export default FiledDocuments;
