import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import FiledDocuments from './filedDocuments';
import { BrowserRouter as Router } from 'react-router-dom';

import {
    getFiledDocuments,
    getFinalDocuments,
    getTaskDocumentStatus,
    updateTaskDocumentStatus
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import AuthStore from 'core/store/authStore/authStore';

jest.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key })
}));

jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService', () => ({
    getFiledDocuments: jest.fn(),
    getFinalDocuments: jest.fn(),
    getTaskDocumentStatus: jest.fn(),
    updateStatusPublishToCustomer: jest.fn(),
    updateTaskDocumentStatus: jest.fn()
}));

jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn()
}));

jest.mock('core/store/uploadedFile.store/uploadedFile.store', () => ({
    initialState: { files: [] },
    subscribe: jest.fn()
}));

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('FiledDocuments Component', () => {
    const mockUserInfo = {
        userInfo: {
            roleId: 1
        }
    };

    beforeEach(() => {
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue(mockUserInfo);
        (getFiledDocuments as jest.Mock).mockResolvedValue({
            orderFiledDocumentsModel: [],
            blobUri: '',
            total: 0
        });
        (getFinalDocuments as jest.Mock).mockResolvedValue({
            orderFiledDocumentsModel: [],
            blobUri: '',
            total: 0
        });
        (getTaskDocumentStatus as jest.Mock).mockResolvedValue([]);
    });

    test.skip('renders FiledDocuments component', () => {
        render(
            <Router>
                <FiledDocuments
                    orderOrQuoteId={1}
                    primaryIdForAzureStorage={1}
                    viewData={{ requestType: 'IP' }}
                />
            </Router>
        );

        expect(screen.getByText('File_UPLOAD.TRANSLATED_FILED_DOCUMENT')).toBeInTheDocument();
    });

    test.skip('handles document status change', () => {
        (getTaskDocumentStatus as jest.Mock).mockResolvedValue([
            { id: 1, name: 'In Review', color: 'blue', backgroundColor: 'lightblue' },
            { id: 2, name: 'Approved', color: 'green', backgroundColor: 'lightgreen' }
        ]);

        render(
            <Router>
                <FiledDocuments
                    orderOrQuoteId={1}
                    primaryIdForAzureStorage={1}
                    viewData={{ requestType: 'IP' }}
                />
            </Router>
        );

        waitFor(() => {
            expect(screen.getByText('In Review')).toBeInTheDocument();
        });

        waitFor(() => {
            fireEvent.change(screen.getByTestId('header-status-dropdown'), {
                target: { value: 2 }
            });
            expect(updateTaskDocumentStatus).toHaveBeenCalled();
        });
    });

    test.skip('handles document preview', () => {
        render(
            <Router>
                <FiledDocuments
                    orderOrQuoteId={1}
                    primaryIdForAzureStorage={1}
                    viewData={{ requestType: 'IP' }}
                />
            </Router>
        );

        const documentName = 'test-document.pdf';

        waitFor(() => {
            fireEvent.click(screen.getByText(documentName));
            expect(screen.getByText(documentName)).toBeInTheDocument();
        });
    });
});
