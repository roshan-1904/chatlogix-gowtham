import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import FiledDocumentUploadPopup from './filedDocumentUploadPopup';
import { getTaskId } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { DocumentUploadPopupType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService');
jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

const mockGetTaskId = getTaskId as jest.MockedFunction<typeof getTaskId>;

const mockProps: DocumentUploadPopupType = {
    closeModal: jest.fn(),
    onSubmit: jest.fn(),
    orderOrQuoteId: 12,
    primaryIdForAzureStorage: 4
};

describe('FiledDocumentUploadPopup', () => {
    beforeEach(() => {
        mockGetTaskId.mockResolvedValue([
            { id: 1, taskId: 'Task 1' },
            { id: 2, taskId: 'Task 2' }
        ]);
    });

    it('renders without crashing', () => {
        render(<FiledDocumentUploadPopup {...mockProps} />);
        waitFor(() => expect(mockGetTaskId).toHaveBeenCalledWith('123'));
    });

    it('displays task IDs in the dropdown', () => {
        render(<FiledDocumentUploadPopup {...mockProps} />);
        waitFor(() => {
            const dropdown = screen.getByTestId('selected-file-type');
            expect(dropdown).toBeInTheDocument();
            fireEvent.click(dropdown);
            expect(screen.getByText('Task 1')).toBeInTheDocument();
            expect(screen.getByText('Task 2')).toBeInTheDocument();
        });
    });

    it('calls onSubmit when the upload button is clicked', () => {
        render(<FiledDocumentUploadPopup {...mockProps} />);
        waitFor(() => {
            expect(mockGetTaskId).toHaveBeenCalledWith('123');
            const uploadButton = screen.getByText('Upload');
            fireEvent.click(uploadButton);
            expect(mockProps.onSubmit).toHaveBeenCalled();
        });
    });

    it('calls closeModal when the close button is clicked', () => {
        render(<FiledDocumentUploadPopup {...mockProps} />);
        waitFor(() => expect(mockGetTaskId).toHaveBeenCalledWith('123'));
        const closeButton = screen.getByText('Close');
        fireEvent.click(closeButton);
        expect(mockProps.closeModal).toHaveBeenCalled();
    });

    it('sets the first task ID as the selected value by default', () => {
        render(<FiledDocumentUploadPopup {...mockProps} />);
        waitFor(() => {
            const dropdown = screen.getByTestId('selected-file-type');
            expect(dropdown).toHaveValue('Task 1');
        });
    });
});
