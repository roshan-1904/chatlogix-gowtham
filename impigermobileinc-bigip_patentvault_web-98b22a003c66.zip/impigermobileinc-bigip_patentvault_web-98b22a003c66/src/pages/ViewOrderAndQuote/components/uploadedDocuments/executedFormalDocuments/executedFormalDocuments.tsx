import {
    getExecutedDocumentStatus,
    getExecutedFormalDocuments,
    updateExecutedPOADocumentStatus
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import {
    FiledDocumentsType,
    FiledDocumentsTypeResponse,
    TaskDocumentStatusType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dialog } from 'primereact/dialog';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
    FilterType,
    TableTypes,
    ValueType,
    statusIndicators
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import DocumentUploadPopup from './executedFormalDocumentsUploadPopup/executedFormalDocumentsUploadPopup';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { Task } from 'pages/taskManagement/types/tasks.types';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { TaskNameTemplate } from 'pages/taskManagement/shared/taskManagementHelper';
import { DOCUMENT_TYPE, MODULE_TYPE, STATUS_TYPE_ID } from 'constants/app.constant';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { useTranslation } from 'react-i18next';
import { Tooltip } from 'primereact/tooltip';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import utils, { getWindowSize, isContactUser } from 'core/utils/utils';
import UploadedFileStore from 'core/store/uploadedFile.store/uploadedFile.store';
import { ORDER_QUOTE_MODULE, QUOTE_ORDER_USER_MODULE } from 'constants/fileUploadApiUrl.constant';
import fileUploadService from 'components/fileUpload/services/fileUpload.service';
import { previewDialogPopup } from 'constants/styles.constant';
import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';
import PrimeButton from 'components/buttons/primeButton';

const ExecutedFormalDocuments: React.FC<FiledDocumentsType> = ({
    orderOrQuoteId,
    primaryIdForAzureStorage,
    flags
}) => {
    const { t } = useTranslation();
    const { requestId } = useParams();
    const [executedFormalDocumentsList, setExecutedFormalDocumentsList] = useState<
        FiledDocumentsTypeResponse[]
    >([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const NO_DATA_FOUND = t('COMMON.NO_DATA_FOUND');
    const [emptyMessage, setEmptyMessage] = useState<undefined | string>(undefined);
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [showModal, setShowModal] = useState(false);
    const [visible, setVisible] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');
    const [sasURL, setSasURL] = useState<string>('');
    const [blobURL, setBlobURL] = useState<any>('');
    const [executedDocumentStatus, setExecutedDocumentStatus] = useState<TaskDocumentStatusType[]>(
        []
    );
    const [selectedExistingDocument, setSelectedExistingDocument] = useState<any>();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const { roleId } = userDetails.userInfo;
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${MODULE_TYPE.EXECUTED_FORMAL_DOCUMENT_MODULE.moduleId}`;
    const [fileTypes, setFileTypes] = useState<any>([]);
    const fileInputTriggerRef = useRef<(() => void) | null>(null);
    const uploadFileApiUrl = `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_FILED_EXISTING_FILE}/${selectedExistingDocument?.taskrefId}/${selectedExistingDocument?.documentId}/${selectedExistingDocument?.fileId}`; // Replace existing file API URL
    useEffect(() => {
        fetchDocumentTypes();
        getExecutedFormalDocumentsList(requestBody);
    }, [requestBody]);

    // Fetch Uploaded File Store
    const [uploadFileStore, setUploadFileStore] = useState<any>(
        UploadedFileStore.initialState.files
    );

    useLayoutEffect(() => {
        const subscription = UploadedFileStore.subscribe(setUploadFileStore);
        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    // Fetching document types
    const fetchDocumentTypes = async () => {
        const response = await fileUploadService.getDocumentTypes(getDocumentTypeApiUrl);
        const filteredResponse = response.filter(
            (item: { id: number }) =>
                item.id !== DOCUMENT_TYPE.SOURCE.id &&
                item.id !== DOCUMENT_TYPE.REFERENCE.id &&
                item.id !== DOCUMENT_TYPE.NOT_CLASSIFIED.id
        );
        setFileTypes(filteredResponse);
    };

    // Calculate the number of completed files
    const fileCompletedLength =
        uploadFileStore.length > 0 &&
        uploadFileStore.filter((file: { progress: number }) => file.progress >= 100.0);

    const lastCalledTimeRef = useRef<number | null>(null);

    useEffect(() => {
        const handleFileUploadListStore = async () => {
            if (
                uploadFileStore.length > 0 &&
                uploadFileStore.length === fileCompletedLength.length
            ) {
                await new Promise((r) => setTimeout(r, 2000));

                const currentTime = Date.now();
                if (!lastCalledTimeRef.current || currentTime - lastCalledTimeRef.current > 2000) {
                    getExecutedFormalDocumentsList(requestBody);
                    lastCalledTimeRef.current = currentTime;
                }
            }
        };

        if (fileCompletedLength) {
            handleFileUploadListStore();
        }
    }, [fileCompletedLength]);

    const handleFilter = (updatedFilter: RequestBody) => {
        setRequestBody(updatedFilter);
    };
    const sortHandler = (updatedSort: RequestBody) => {
        setRequestBody(updatedSort);
    };
    const handlePageChange = (updatedPage: RequestBody) => {
        setRequestBody(updatedPage);
    };

    useEffect(() => {
        getSasUrlApi();
        handleGetTaskDocumentStatus();
    }, []);

    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };

    const getExecutedFormalDocumentsList = async (body: RequestBody) => {
        const response: FiledDocumentsType = await getExecutedFormalDocuments<FiledDocumentsType>(
            String(requestId),
            body
        );

        setExecutedFormalDocumentsList(
            response?.orderFiledDocumentsModel as FiledDocumentsTypeResponse[]
        );
        setBlobURL(response.blobUri);
        const pagination: paginationData = {
            pageNo: body.pageNo,
            totalPages: Math.ceil(response.total ?? 0 / body.pageCount),
            totalRecords: response.total ?? 0
        };

        setPaginationInfo(pagination);
        if (response.orderFiledDocumentsModel?.length === 0) {
            setEmptyMessage(NO_DATA_FOUND);
        }
    };

    const handleGetTaskDocumentStatus = async () => {
        const response: TaskDocumentStatusType[] = await getExecutedDocumentStatus();
        if (response) {
            const documentWithColor = response.map((statusData: { id: number; name: string }) => ({
                id: statusData?.id,
                name: statusData?.name,
                ...statusIndicators(statusData.name)
            }));

            setExecutedDocumentStatus(documentWithColor);
        }
    };

    const handleClick = () => {
        openModal().catch((error) => {
            console.error('Error opening modal:', error);
        });
    };

    const openModal = async () => {
        setShowModal(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };

    const closeModal = () => {
        setShowModal(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            'upload-filedDocument'
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }

        // Update the URL fragment without reloading the page
        window.location.hash = 'uploaded-documents-container';
    };

    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;
        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${blobURL}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    const uploadDocumentButton = () => {
        return (
            <a href="#file-upload">
                <PrimeButton
                    testid="upload-documents-ip-executed"
                    label={'Upload Document'}
                    type="primary"
                    className=""
                    disabled={flags?.isCompleted || flags?.isInvoiced}
                    icon="pi pi-cloud-upload text-lg"
                    size="medium"
                    onClick={handleClick}
                />
            </a>
        );
    };

    const taskTitleTemplate = (task: Task) => {
        const userIconTemplate = TaskNameTemplate(task.taskName);

        return (
            <div className="flex items-center">
                <img className="h-[16px]" src={userIconTemplate} alt="" />
                <span className="pl-3">{task.taskName}</span>
            </div>
        );
    };

    const optionTemplate = (option: TaskDocumentStatusType) => {
        return (
            <div
                style={{ color: option.color, backgroundColor: option.backgroundColor }}
                className="px-3 p-1 mx-2 w-fit">
                <span className="font-semibold">{option.name}</span>
            </div>
        );
    };

    const handleDropdownChange = async (
        statusValue: number,
        rowData: FiledDocumentsTypeResponse
    ) => {
        const updatedTaskDocumentStatus = await updateExecutedPOADocumentStatus(
            rowData.documentId,
            rowData.fileId,
            statusValue
        );

        if (updatedTaskDocumentStatus) {
            getExecutedFormalDocumentsList(requestBody);
        }
    };

    const handleChange = (e: DropdownChangeEvent, rowData: FiledDocumentsTypeResponse) => {
        handleDropdownChange(e.value as number, rowData).catch((error) => {
            console.error('Error updating task document status:', error);
        });
    };

    const valueTemplate = (option: TaskDocumentStatusType) => {
        return (
            <div
                style={{ color: option?.color, backgroundColor: option?.backgroundColor }}
                className="h-10 max-w-max flex items-center justify-between px-3 rounded-sm">
                <span className="font-semibold pr-2">{option?.name}</span>
                <i className="pi pi-chevron-down"></i>
            </div>
        );
    };

    const taskDocumentStatusTemplate = (rowData: FiledDocumentsTypeResponse) => {
        const isShowDocumentStatusDropdown = () => {
            const isExecutedPOADocument =
                (rowData.documentType === DOCUMENT_TYPE.EXECUTED_POA_DOCUMENT.id ||
                    rowData.documentType === DOCUMENT_TYPE.EXECUTED_ASSIGNMENT_DOCUMENT.id) &&
                rowData.documentStatus === STATUS_TYPE_ID.PENDING_RECEIPT_CONFIRMATION;

            return isExecutedPOADocument;
        };

        return (
            <div>
                {isShowDocumentStatusDropdown() ? (
                    <Dropdown
                        data-testid={'header-status-dropdown'}
                        value={rowData.documentStatus}
                        onChange={(e) => {
                            handleChange(e, rowData);
                        }}
                        options={executedDocumentStatus}
                        optionValue="id"
                        optionLabel="name"
                        itemTemplate={optionTemplate}
                        valueTemplate={valueTemplate}
                        style={{ border: 'none' }}
                        pt={{
                            root: {
                                className: 'bg-inherit !w-full !max-w-max'
                            },
                            trigger: {
                                className: 'hidden'
                            },
                            input: {
                                className: 'p-0'
                            },
                            item: {
                                className: 'filedDocumentDropdownItemsHidden'
                            }
                        }}
                    />
                ) : (
                    <div
                        style={{
                            color: executedDocumentStatus?.find(
                                (item) => item.id === rowData.documentStatus
                            )?.color,
                            backgroundColor: executedDocumentStatus?.find(
                                (item) => item.id === rowData.documentStatus
                            )?.backgroundColor
                        }}
                        className="h-10 max-w-max flex items-center justify-between px-3 rounded-md">
                        <span className="font-semibold">{rowData.documentStatusName}</span>
                    </div>
                )}
            </div>
        );
    };

    const handleTriggerFileInputClick = () => {
        if (fileInputTriggerRef.current) {
            fileInputTriggerRef.current(); // Trigger the file input click
        }
    };

    const documentNameWithSizeTemplate = (rowData: any) => {
        return (
            <div>
                <Tooltip
                    position="bottom"
                    target={'.fileNameTooltip' + rowData.fileId}
                    content={rowData.fileName}></Tooltip>
                <div className={'flex items-center justify-between gap-3'}>
                    <div
                        className={'fileNameTooltip' + rowData.fileId + ' flex items-center gap-2'}>
                        {fileTypeIcon(rowData.fileType as string)}
                        <p
                            className="text-base text-primary truncate font-medium underline underline-offset-1 max-w-56 cursor-pointer"
                            onClick={() => handlePreviewDocument(rowData)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                    handlePreviewDocument(rowData);
                                }
                            }}
                            tabIndex={0}>
                            {rowData.fileName}
                        </p>
                        <p className="text-base text-neutral-200">{rowData.fileSize}</p>
                    </div>
                    {rowData.documentStatus !== STATUS_TYPE_ID.RECEIPT_CONFIRMED && (
                        <div className="w-5">
                            <label className="cursor-pointer">
                                <div className="h-5 w-5">
                                    <Tooltip
                                        position="bottom"
                                        target={'.fileTooltip'}
                                        content={'Replace the existing file'}></Tooltip>
                                    <img
                                        src={uploadIcon}
                                        className="fileTooltip w-full h-full"
                                        onKeyDown={(e) =>
                                            e.key === 'Enter' && e.currentTarget.click()
                                        }
                                        onClick={() => {
                                            setSelectedExistingDocument(rowData);
                                            handleTriggerFileInputClick();
                                        }}
                                    />
                                </div>
                            </label>
                        </div>
                    )}
                </div>
            </div>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskId',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'taskName',
            header: 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: taskTitleTemplate,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            flagIconKey: 'iconName',
            columnNumber: 3,
            visibility: true
        },
        {
            field: 'documentTypes',
            header: 'Document Type',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: fileTypes.map((status: { name: any; id: any }) => ({
                label: status.name,
                value: `${status.id}`
            })),
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        },
        {
            field: 'documentNumber',
            header: 'Document ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 5,
            visibility: true
        },
        {
            field: 'fileName',
            header: 'Document',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            columnNumber: 6,
            visibility: true,
            body: documentNameWithSizeTemplate
        },
        {
            field: 'documentStatus',
            header: 'Document Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Dropdown,
            filterDropDownOptions: executedDocumentStatus.map((status) => ({
                label: status.name,
                value: `${status.id}`
            })),
            body: taskDocumentStatusTemplate,
            columnNumber: 7,
            visibility: true
        },
        {
            field: 'uploadedBy',
            header: 'Uploaded By',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 11,
            visibility: true
        },
        {
            field: 'uploadedOn',
            header: 'Uploaded On',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: 12,
            visibility: true
        }
    ];

    const tableDefinition: DataTableDefinition = {
        title: t('File_UPLOAD.EXECUTED_FORMAL_DOCUMENTS'),
        filters: {},
        reOrderableColumns: true,
        tableType: TableTypes.ORDER_QUOTE_FILED_DOCUMENTS,
        emptyMessage,
        tableCustomStyle: 'p-0',
        columns: columnSchema,
        ...(!isContactUser(roleId) && { buttonChildren: uploadDocumentButton() }),
        customTableHeight: false,
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.FILED_DOCUMENT_COLUMN_ORDERS,
        hideTableExport: false
    };

    return (
        <div>
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {previewImageName}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(previewImage, previewImageName)
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <FileUpload
                className="hidden"
                triggerFileInputClick={(triggerFileInput: () => void) => {
                    fileInputTriggerRef.current = triggerFileInput;
                }}
                uploadFileApiUrl={uploadFileApiUrl}
                moduleType={{
                    moduleId: MODULE_TYPE.FILED_DOCUMENT_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.FILED_DOCUMENT_MODULE.azureFolderName
                }}
                primaryId={selectedExistingDocument?.id as number}
                deleteFileApiUrl={''}
                getDocumentTypeApiUrl={''}
                updateDocumentTypeApiUrl={''}
                ifFiledDocumentUpload={{ isFiledDoc: true, isExistingDocReplace: true }}
                filedDocumentFields={{
                    documentType: selectedExistingDocument?.documentType
                }}
                multipleFiles={false}
                moduleName={`filedDocument-${selectedExistingDocument?.id}`}
            />
            {showModal && (
                <DocumentUploadPopup
                    orderOrQuoteId={orderOrQuoteId}
                    primaryIdForAzureStorage={primaryIdForAzureStorage}
                    closeModal={closeModal}
                    onSubmit={() => {}}
                />
            )}
            <DataTableComponent
                tableData={executedFormalDocumentsList}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                toggleRowData={() => {}}
                previewDocument={handlePreviewDocument}
                showPagination={true}
                handlePagination={handlePageChange}
                tablePaginationData={paginationInfo}
                handleSort={sortHandler}
                handleFilter={handleFilter}
            />
        </div>
    );
};
export default ExecutedFormalDocuments;
