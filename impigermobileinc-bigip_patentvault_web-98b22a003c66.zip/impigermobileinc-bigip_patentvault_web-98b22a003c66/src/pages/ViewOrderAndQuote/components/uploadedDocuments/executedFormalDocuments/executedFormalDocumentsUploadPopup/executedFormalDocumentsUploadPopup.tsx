import { useEffect, useState } from 'react';
import FileUpload from 'components/fileUpload/fileUpload';
import PopupModal from 'components/popupModal/popupModal';
import { MODULE_TYPE } from 'constants/app.constant';
import { QUOTE_ORDER_USER_MODULE, TASK_MODULE } from 'constants/fileUploadApiUrl.constant';
import {
    DocumentUploadPopupType,
    FiledDocumentCountryDropDownType,
    FiledDocumentTaskIdDropDownType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dropdown } from 'primereact/dropdown';
import { dropDownStyle } from 'constants/styles.constant';
import {
    getCountryBasedTasks,
    getOrderCountries
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { showToastMessage } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';

const ExecutedFormalDocumentsUploadPopup: React.FC<DocumentUploadPopupType> = ({
    closeModal,
    onSubmit,
    orderOrQuoteId,
    primaryIdForAzureStorage
}) => {
    const [taskIdList, setTaskIdList] = useState<FiledDocumentTaskIdDropDownType[]>([]);
    const [countriesList, setCountriesList] = useState<FiledDocumentCountryDropDownType[]>([]);
    const [selectedTaskId, setSelectedTaskId] = useState<FiledDocumentTaskIdDropDownType>({
        id: 0,
        message: '',
        taskId: ''
    });
    const [selectedCountryId, setSelectedCountryId] = useState<FiledDocumentCountryDropDownType>({
        countryId: 0,
        countryName: ''
    });
    const handleSubmit = () => {
        if (onSubmit) {
            onSubmit({});
        }
    };
    const close = () => {
        if (closeModal) {
            closeModal({});
        }
    };

    useEffect(() => {
        if (selectedCountryId.countryId !== 0) {
            fetchTaskId();
        }
    }, [selectedCountryId]);

    useEffect(() => {
        fetchOrderCountries();
    }, []);

    const fetchTaskId = async () => {
        const response: FiledDocumentTaskIdDropDownType[] = await getCountryBasedTasks(
            orderOrQuoteId,
            selectedCountryId.countryId
        );
        if (response) {
            if (response.length === 1 && response[0].id === null) {
                showToastMessage({
                    type: ToastType.WARNING,
                    message: response[0]?.message ?? 'No task ID found for the selected country'
                });
                setSelectedTaskId({ id: 0, message: '', taskId: '' });
            } else {
                setTaskIdList(response);
                if (response.length > 0) {
                    setSelectedTaskId(response[0]); // Set the first task ID as the selected value
                }
            }
        }
    };

    const fetchOrderCountries = async () => {
        const response: FiledDocumentCountryDropDownType[] =
            await getOrderCountries(orderOrQuoteId);
        if (response) {
            setCountriesList(response);
            if (response.length > 0) {
                setSelectedCountryId(response[0]); // Set the first task ID as the selected value
            }
        }
    };

    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

    const moduleId = MODULE_TYPE.EXECUTED_FORMAL_DOCUMENT_MODULE.moduleId;
    const azureFolderName = MODULE_TYPE.EXECUTED_FORMAL_DOCUMENT_MODULE.azureFolderName;
    const uploadFileApiUrl = `${quoteBaseURL}${TASK_MODULE.UPLOAD_FILE}${orderOrQuoteId}/${selectedTaskId.id}`; // Upload file API URL
    const deleteFileApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.DELETE_FILE}`; // Delete file API URL
    const getDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.GET_DOCUMENT_TYPE}${moduleId}`; // Get document type API URL
    const updateDocumentTypeApiUrl = `${quoteBaseURL}${QUOTE_ORDER_USER_MODULE.UPDATE_DOCUMENT_TYPE}`; // Update document type API URL
    const [fillRequiredFieldsFlag, setFillRequiredFieldsFlag] = useState<boolean>(false);

    useEffect(() => {
        if (selectedCountryId.countryId !== 0 && selectedTaskId.id !== 0) {
            setFillRequiredFieldsFlag(true);
        } else {
            setFillRequiredFieldsFlag(false);
        }
    }, [selectedCountryId, selectedTaskId]);

    const taskListDropDown = () => {
        return (
            <>
                <label className="text-base font-medium text-neutral-200 flex flex-col gap-1">
                    <span className="field-required">Country</span>
                    <Dropdown
                        data-testid="selected-file-type"
                        value={selectedCountryId}
                        filter={true}
                        onChange={(e) =>
                            setSelectedCountryId(e.value as FiledDocumentCountryDropDownType)
                        }
                        options={countriesList}
                        optionLabel="countryName"
                        placeholder={'Select Country'}
                        pt={{
                            ...dropDownStyle,
                            root: {
                                className:
                                    'hover:border-primary font-medium border border-neutral-100 md:w-60 lg:w-72 4xl:w-96'
                            },
                            item: { className: 'hover:bg-primary-50' },
                            input: {
                                className: 'p-2'
                            }
                        }}
                    />
                </label>

                <label className="text-base font-medium text-neutral-200 flex flex-col gap-1">
                    <span className="field-required">Task ID</span>
                    <Dropdown
                        data-testid="selected-file-type"
                        value={selectedTaskId}
                        filter={true}
                        onChange={(e) =>
                            setSelectedTaskId(e.value as FiledDocumentTaskIdDropDownType)
                        }
                        options={taskIdList}
                        optionLabel="taskId"
                        placeholder={'Select Task'}
                        pt={{
                            ...dropDownStyle,
                            root: {
                                className:
                                    'hover:border-primary font-medium border border-neutral-100 md:w-60 lg:w-72 4xl:w-96'
                            },
                            item: { className: 'hover:bg-primary-50' },
                            input: {
                                className: 'p-2'
                            }
                        }}
                    />
                </label>
            </>
        );
    };

    return (
        <PopupModal
            id={'upload-filedDocument'}
            title={'Upload Document'}
            onClose={() => close()}
            createButtonText={'Upload'}
            resetButtonText={'Close'}
            isEdit={true}
            onSubmit={handleSubmit}
            isSubmitHide={false}>
            <div className="bg-neutral-300 pb-0">
                <FileUpload
                    uploadFileApiUrl={uploadFileApiUrl}
                    deleteFileApiUrl={deleteFileApiUrl}
                    getDocumentTypeApiUrl={getDocumentTypeApiUrl}
                    updateDocumentTypeApiUrl={updateDocumentTypeApiUrl}
                    moduleType={{ moduleId, azureFolderName }}
                    primaryId={primaryIdForAzureStorage}
                    documentUploadTitle={false}
                    documentUploadOptionalText={false}
                    uploadedDocumentListTable={false}
                    isNotClassified={false}
                    className="orderdetail-upload-executed-formal-documents orderdetail-upload-fileddocument"
                    childDropDown={taskListDropDown()}
                    sourceReferenceDocumentType={false}
                    moduleName={`executed-formal-documents-${orderOrQuoteId}`}
                    ifExecuteFormalDocumentUpload={{ isExecutingDoc: true }}
                    executeFormalDocumentFields={selectedCountryId.countryId}
                    isValidateRequiredFields={true}
                    fillRequiredFieldsAreValid={fillRequiredFieldsFlag}
                />
            </div>
        </PopupModal>
    );
};

export default ExecutedFormalDocumentsUploadPopup;
