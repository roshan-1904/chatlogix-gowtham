import { useEffect, useMemo, useRef, useState } from 'react';
import { t } from 'i18next';
import { TabPanel, TabView } from 'primereact/tabview';

import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';
import { previewDialogPopup, tabPanelPT } from 'constants/styles.constant';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { TABLE_POP_IDS, InitDefaultTableBody } from 'constants/dataTable.constant';

import PopupModal from 'components/popupModal/popupModal';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

import {
    manageLanguages,
    standardDeleteDocument,
    standardDeleteSection,
    validateDeleteTargetLanguage
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import {
    DocumentDetail,
    DocumentDetailsResponse,
    DocumentGroup
} from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import ManageTasks from './ManageTasks';
import { Tooltip } from 'primereact/tooltip';

import uploadIcon from 'assets/svgs/upload-cloud-icon.svg';
import FileUpload from 'components/fileUpload/fileUpload';
import { ORDER_QUOTE_MODULE } from 'constants/fileUploadApiUrl.constant';
import { MODULE_TYPE } from 'constants/app.constant';
import UploadSTDDetailsPage from 'pages/createOrderAndQuote/components/standard/uploadAndLanguageSelection/components/uploadSTDDetailsPage';
import {
    AllLanguageResponse,
    AllLanguageResponseType
} from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import PVSettingsService from 'pages/pvsettings/subaccordions/service/pvsettings.service';
import { InputFieldTemplate } from 'components/reuseComponents/constructField';
import { fileTypeIcon } from 'components/fileUpload/constant/fileTypeIcon';
import { getSasUrl, isSasUrlExpired } from 'components/fileUpload/services/azureStorage.service';
import { Dialog } from 'primereact/dialog';
import utils, { getWindowSize, isContactUser, isStaffUser, isVendorUser } from 'core/utils/utils';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { showToastMessage } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import PrimeButton from 'components/buttons/primeButton';
import CustomTableCellInlineFields from 'components/reuseComponents/customTableCellInlineFields';
import uploadSTDDetailsPageService from 'pages/createOrderAndQuote/components/standard/uploadAndLanguageSelection/services/uploadSTDDetailsPage.service';
import FiledDocuments from '../uploadedDocuments/filedDocuments/filedDocuments';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { STDUpdateDocumentWordCountModel } from 'pages/createOrderAndQuote/components/standard/uploadAndLanguageSelection/types/uploadAndLanguageSelection.type';

const StandardDocumentTabSection = (ViewData: DocumentDetailsResponse) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserId);
    const isThisVendorUser = isVendorUser(loggedInUserId);
    const isThisContactUser = isContactUser(loggedInUserId);

    const [requestBody, setRequestBody] = useState<RequestBody>(InitDefaultTableBody);
    const [activeIndex, setActiveIndex] = useState(0);
    const [showManageTaskPopup, setShowManageTaskPopup] = useState(false);
    const [showManageLanguagePopup, setShowManageLanguagePopup] = useState(false);
    const [manageTaskValues, setManageTaskValues] = useState<DocumentDetail>();
    const [manageLanguageSectionValues, setManageLanguageSectionValues] = useState<DocumentGroup>(
        {} as DocumentGroup
    );
    const [languageList, setLanguageList] = useState<AllLanguageResponseType[]>([]);
    const [modifiedList, setModifiedList] = useState<number[]>([]);
    const [isRenderUploadDialog, setIsRenderUploadDialog] = useState(false);
    const isCompletedORInvoiced = ViewData.flags.isCompleted || ViewData.flags.isInvoiced;

    const tabViewStyle = {
        nav: { className: 'gap-4 border-0' },
        panelcontainer: { className: 'border border-neutral-100/50' }
    };

    // API
    const getTableData = (docDetails: DocumentDetail[]) => {
        return docDetails.map((doc) => {
            doc.taskIds = doc.task.map((task: any) => {
                return task.taskId;
            });
            return doc;
        });
    };
    const getLanguageList = async () => {
        try {
            const requestBodySorting = { propertyName: 'id', value: 'asc' };
            const response: AllLanguageResponse =
                await PVSettingsService.getAllLanguages(requestBodySorting);

            if (response?.data) {
                const languageListData: AllLanguageResponseType[] = response.data;
                setLanguageList(languageListData);
            }
        } catch (error) {
            console.error(`Error in 'getSourceLanguages()':`, error);
            return null;
        }
    };

    // templates
    const requestNumberTemplate = (rowData: any) => {
        return (
            <div>
                <span className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer">
                    {rowData.documentNumber}
                </span>
            </div>
        );
    };
    const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
    const fileInputTriggerRef = useRef<(() => void) | null>(null);
    const [selectedExistingDocument, setSelectedExistingDocument] = useState<DocumentDetail>();
    const uploadFileApiUrl = `${quoteBaseURL}${ORDER_QUOTE_MODULE.REPLACE_STD_SOURCE_DOCUMENT}/${selectedExistingDocument?.documentId}`; // Replace existing file API URL
    const [selectedSectionId, setSelectedSectionId] = useState<number>(0);

    const handleTriggerFileInputClick = () => {
        if (fileInputTriggerRef.current) {
            fileInputTriggerRef.current(); // Trigger the file input click
        }
    };
    const ActionTemplate = (rowData: DocumentDetail) => {
        const isEditable = !isCompletedORInvoiced;
        const isSourceDocument = rowData.documentType === 1;

        // to find the section has minimum one source document to restrict the delete option against the row
        const sectionForSelectedRowData =
            ViewData.documentDetails.find((document) => document.sectionId === rowData.sectionId) ??
            null;
        const isShowDeleteButton =
            !isSourceDocument ||
            (isSourceDocument &&
                (sectionForSelectedRowData?.documentDetails.filter(
                    (document) => document.documentType === 1
                ).length ?? 0) > 1);

        return (
            <div className="flex justify-center">
                <span className="h-5 w-5 mr-2">
                    <Tooltip
                        position="bottom"
                        target={'.fileTooltip' + rowData.documentId}
                        content={'Replace the existing file'}></Tooltip>
                    <img
                        src={uploadIcon}
                        data-testid={'uploadIcon'}
                        className={'fileTooltip' + rowData.documentId + 'w-full h-full'}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        onClick={() => {
                            if (!isEditable) return;
                            setSelectedExistingDocument(rowData);
                            handleTriggerFileInputClick();
                        }}
                    />
                </span>
                {isShowDeleteButton && (
                    <span
                        className="p-menu-item-icon pi pi-trash ng-star-inserted co text-primary"
                        onClick={() => {
                            if (!isEditable) return;
                            handleDeleteClick(rowData);
                        }}></span>
                )}
            </div>
        );
    };
    // template for request Number column
    const manageTaskTemplate = (rowData: any) => {
        return (
            <a
                href="#"
                onClick={() => {
                    if (isCompletedORInvoiced) return;
                    setManageTaskValues(rowData as DocumentDetail);
                    openModal();
                }}
                className={`text-primary underline ${isCompletedORInvoiced ? 'text-primary-100 cursor-not-allowed' : 'cursor-pointer'}`}>
                Manage Document
            </a>
        );
    };
    const [sasURL, setSasURL] = useState<string>('');
    // Fetching SAS URL
    const getSasUrlApi = async () => {
        try {
            const response = await getSasUrl();
            if (!response) return;
            const sasToken = response.split('?')[1];
            setSasURL(sasToken);
        } catch (error) {
            console.error('Error fetching SAS URL:', error);
        }
    };
    const [previewImage, setPreviewImage] = useState<string>('');
    const [previewImageName, setPreviewImageName] = useState<string>('');

    const [visible, setVisible] = useState<boolean>(false);
    // Previewing document
    const handlePreviewDocument = (data: any) => {
        const { blobFileName, fileType, fileName } = data;

        isSasUrlExpired(sasURL).then((newSasUrl) => {
            newSasUrl = newSasUrl && newSasUrl.includes('?') ? newSasUrl.split('?')[1] : newSasUrl;
            // Construct the preview URL
            const previewURL = `${ViewData.blobUri}/${blobFileName}?${newSasUrl}`;

            // Extract the file extension from the file type
            const fileExtension = (fileType || '').toLowerCase().split('/')[1];

            // Define an array of allowed file extensions for preview
            const ALLOWED_EXTENSIONS = ['png', 'svg', 'pdf', 'svg+xml'];

            // Check if the file extension is in the ALLOWED_EXTENSIONS array and is an image or PDF
            const isImageOrPdf: boolean = ALLOWED_EXTENSIONS.includes(fileExtension as string);

            if (isImageOrPdf) {
                // Extract file name without extension
                const fileNameWithoutExtension = fileName.split('.')[0];

                // Set preview image name
                setPreviewImageName(fileNameWithoutExtension as string);

                // Set preview image URL
                setPreviewImage(previewURL);

                // Show preview dialog
                setVisible(true);
            } else {
                // Redirect to the file URL for non-previewable files
                window.open(previewURL, '_self');
            }
        });
    };

    const DocumentPreviewTemplate = (rowData: any) => {
        return (
            <div>
                <Dialog
                    header={
                        <div className="w-full flex justify-between items-center">
                            {previewImageName}
                            <i
                                className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() =>
                                    utils.handleDownloadPngSvg(previewImage, previewImageName)
                                }
                            />
                        </div>
                    }
                    visible={visible}
                    pt={previewDialogPopup}
                    style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                    onHide={() => setVisible(false)}>
                    <iframe
                        src={`${previewImage}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                        style={{ width: '100%', minHeight: '80vh' }}
                    />
                </Dialog>
                <Tooltip
                    position="bottom"
                    target={'.uploadedDoctName' + rowData.documentId}
                    content={rowData.fileName}></Tooltip>
                <div
                    className={
                        'uploadedDoctName' + rowData.documentId + ' flex items-center gap-1'
                    }>
                    {fileTypeIcon(rowData.fileType as string)}
                    <p
                        className="text-base text-primary font-medium underline underline-offset-1 max-w-56 truncate cursor-pointer"
                        onClick={() => handlePreviewDocument(rowData)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                handlePreviewDocument(rowData);
                            }
                        }}
                        tabIndex={0}>
                        {rowData.fileName}
                    </p>
                </div>
            </div>
        );
    };
    // handle events
    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        acceptLabel: '',
        rejectLabel: '',
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });
    const handleConfirmationCancel = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };
    const handleDeleteClick = (rowData: DocumentDetail) => {
        setShowConfirmationPopup({
            acceptLabel: t('COMMON.CONFIRM'),
            rejectLabel: t('COMMON.CANCEL'),
            visible: true,
            handlePopConfirmConfirm() {
                handleDeleteConfirm(rowData);
            },
            header: 'Delete Confirmation',
            subHeader: '',
            description: t('QUOTE_AND_ORDER.STD_DELETE_DOCUMENT_CONFIRMATION')
        });
    };
    const handleDeleteConfirm = (rowData: DocumentDetail) => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
        const executeUpdate = async () => {
            const res = await standardDeleteDocument<boolean>(rowData.documentId);
            if (res === true) {
                console.error('success');
                ViewData.documentRowValueChangeEvent();
                quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
            } else {
                console.error('error');
            }
        };
        return executeUpdate();
    };
    const UpdateWordCountWrapper = (payload: STDUpdateDocumentWordCountModel) => {
        UpdateWordCount(payload).catch((error) => {
            console.error('Error in UpdateWordCountWrapper:', error);
        });
    };
    const UpdateWordCount = async (payload: STDUpdateDocumentWordCountModel) => {
        const response = await uploadSTDDetailsPageService.updateDocumentWordCount(payload);
        if (response) {
            ViewData.documentRowValueChangeEvent();
            quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
            quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
        }
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };

    const handleCellInlineEditValueChangeWrapper = (
        documentId: number,
        fieldName: string,
        updatedValue: string | number | boolean
    ) => {
        handleCellInlineEditValueChange(documentId, fieldName, updatedValue);
    };
    const handleCellInlineEditValueChange = async (
        documentId: number,
        fieldName: string,
        updatedValue: string | number | boolean
    ) => {
        if (fieldName === 'notes') {
            const payload = {
                documentId,
                orderId: ViewData.orderId,
                notes: updatedValue as string
            };
            const response = await uploadSTDDetailsPageService.updateNotes(payload);

            if (response) {
                ViewData.documentRowValueChangeEvent();
                quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
            }
        } else if (fieldName === 'wordCount') {
            const payload: STDUpdateDocumentWordCountModel = {
                documentId,
                orderId: ViewData.orderId,
                wordCount: updatedValue as number
            };
            const response = await uploadSTDDetailsPageService.validateUpdateWordCount(payload);
            if (response) {
                setShowConfirmationPopup({
                    acceptLabel: t('COMMON.CONFIRM'),
                    rejectLabel: t('COMMON.CANCEL'),
                    visible: true,
                    handlePopConfirmConfirm: () => UpdateWordCountWrapper(payload),
                    header: 'Confirmation',
                    subHeader: '',
                    description: t('QUOTE_AND_ORDER.STD_WORD_COUNT_CHANGE_CONFIRMATION')
                });
            } else {
                showToastMessage(
                    t('QUOTE_AND_ORDER.STD_VALIDATE_WORD_COUNT_CHANGE_ERROR'),
                    ToastType.ERROR
                );
            }
        }
    };
    // Table Definition
    let contactColumnNumber = 0;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'documentNumber',
            header: 'Document No.',
            frozen: true,
            alignFrozen: 'left',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            body: requestNumberTemplate,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'fileName',
            header: 'Document Name.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            body: DocumentPreviewTemplate,
            visibility: true
        },
        {
            field: 'documentTypeName',
            header: 'Document Type.',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'sourceLanguageName',
            header: 'Source Languages',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'targetLanguageName',
            header: 'Target Languages',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'taskIds',
            header: 'Task ID',
            sortable: false,
            filter: false,
            filterType: FilterType.MultiSelect,
            valueType: ValueType.MultiSelect,
            columnNumber: contactColumnNumber++,
            visibility: isThisStaffUser || isThisVendorUser
        },
        {
            field: 'task',
            header: 'Manage Documents',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            body: manageTaskTemplate,
            visibility: isThisStaffUser || isThisVendorUser
        },
        {
            field: 'fileSize',
            header: 'Size',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'wordCount',
            header: 'Word Count',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true,
            body(rowData: any) {
                return (
                    <CustomTableCellInlineFields
                        moduleName="std-details"
                        fieldType="text"
                        fieldName="wordCount"
                        rowData={rowData}
                        quoteStatuses={ViewData.flags}
                        handleCellInlineEditValueChange={handleCellInlineEditValueChangeWrapper}
                    />
                );
            }
        },
        {
            field: 'notes',
            header: 'Notes',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true,
            body(rowData: any) {
                return (
                    <CustomTableCellInlineFields
                        moduleName="std-details"
                        fieldType="text"
                        fieldLabelName="Notes"
                        fieldName="notes"
                        rowData={rowData}
                        quoteStatuses={ViewData.flags}
                        handleCellInlineEditValueChange={handleCellInlineEditValueChangeWrapper}
                        getInputFromPopup={true}
                    />
                );
            }
        },
        {
            field: '',
            header: 'Action',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: contactColumnNumber++,
            body: ActionTemplate,
            visibility:
                !isThisContactUser || (isThisContactUser && ViewData.flags.isQuoteState === true),
            frozen: true,
            alignFrozen: 'right'
        }
    ];
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.STD_LANGUAGE_DOCUMENT_TABLE,
        filters: {},
        reOrderableColumns: false,
        title: '',
        emptyMessage: 'No Data Found',
        localStorageKey: '',
        columns: columnSchema,
        hideColumnSelector: true,
        hideTableExport: false,
        customTableHeight: false
    };
    const openModal = async () => {
        setShowManageTaskPopup(true);
        await new Promise((r) => setTimeout(r, 100));
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.MANAGE_TASKS_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };
    const closeModal = () => {
        setShowManageTaskPopup(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.MANAGE_TASKS_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    const openManageLanguagePopupModal = async () => {
        setShowManageLanguagePopup(true);
        await new Promise((r) => setTimeout(r, 100));
        const element = TABLE_POP_IDS.CREATE_POPUP.MANAGE_STANDARD_LANGUAGE_POPUP;
        const modal: HTMLDialogElement | null = document.getElementById(
            element
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.show();
        }
    };
    const closeManageLanguagePopupModal = () => {
        setShowManageLanguagePopup(false);
        const modal: HTMLDialogElement | null = document.getElementById(
            TABLE_POP_IDS.CREATE_POPUP.MANAGE_STANDARD_LANGUAGE_POPUP
        ) as HTMLDialogElement | null;
        if (modal) {
            modal.close();
        }
    };

    // side effects
    useEffect(() => {
        getLanguageList();
        getSasUrlApi();
    }, []);

    function handleDeleteSection(documentGroup: DocumentGroup) {
        setShowConfirmationPopup({
            acceptLabel: t('COMMON.CONFIRM'),
            rejectLabel: t('COMMON.CANCEL'),
            visible: true,
            handlePopConfirmConfirm() {
                handleDeleteSectionConfirm(documentGroup);
            },
            header: 'Delete Confirmation',
            subHeader: '',
            description: t('QUOTE_AND_ORDER.STD_DELETE_SECTION_CONFIRMATION')
        });
    }
    function handleDeleteSectionConfirm(documentGroup: DocumentGroup) {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
        const executeUpdate = async () => {
            try {
                const res = await standardDeleteSection<boolean>(
                    ViewData.orderId,
                    documentGroup.sectionId
                );
                if (res === true) {
                    console.error('success');
                    ViewData.documentRowValueChangeEvent();
                    quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                    quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
                } else {
                    console.error('error');
                }
            } catch (error) {
                console.error('error', error);
            }
        };
        return executeUpdate();
    }
    function handleManageLanguage(documentGroup: DocumentGroup) {
        setManageLanguageSectionValues(documentGroup);
        setShowManageLanguagePopup(true);
        setModifiedList(JSON.parse(JSON.stringify(documentGroup.targetLanguageIds)) as number[]);
        openManageLanguagePopupModal();
    }
    const handleTargetLanguageChange = async (value: number[]) => {
        try {
            const srcLanguageLength = manageLanguageSectionValues.sourceLanguageIds.length;
            if (srcLanguageLength > 1 && value.length >= 1) {
                showToastMessage(
                    t('QUOTE_AND_ORDER.STD_MAXIMUM_ONE_TARGET_LANGUAGE'),
                    ToastType.WARNING
                );
            }
            const deletedItems = manageLanguageSectionValues.targetLanguageIds.filter(
                (item) => !value.includes(item)
            );
            if (deletedItems.length > 0) {
                const res = await validateDeleteTargetLanguage<boolean>({
                    targetLanguageIds: deletedItems,
                    orderId: ViewData.orderId,
                    documentId: manageLanguageSectionValues.documentDetails[0].documentId
                });
                if (res === true) {
                    setModifiedList(value);
                } else {
                    showToastMessage(
                        t('QUOTE_AND_ORDER.STD_TARGET_LANGUAGE_ALREADY_ASSOCIATED_TO_VENDOR'),
                        ToastType.ERROR
                    );
                }
            } else {
                setModifiedList(value);
            }
        } catch (error) {
            console.error('error', error);
        }
    };
    function ManageLanguage() {
        return (
            <div className="flex flex-col gap-3 mb-5">
                <InputFieldTemplate
                    data-testid="input-field-template"
                    data={{
                        fieldType: 'dropdown',
                        inputType: { type: 'multiselect' },
                        fieldLabelName: 'Source Language',
                        fieldValue: manageLanguageSectionValues.sourceLanguageIds ?? [],
                        value: manageLanguageSectionValues.sourceLanguageIds ?? [],
                        required: true,
                        disabled: true,
                        moreInputInfo: {
                            select: {
                                options: languageList,
                                optionValue: 'id',
                                optionLabel: 'name',
                                isFilterEnabled: true
                            }
                        },
                        placeholder: 'Select',
                        onChange(value: number[]) {
                            console.error('value', value);
                        }
                    }}
                />
                <InputFieldTemplate
                    data={{
                        fieldType: 'dropdown',
                        inputType: { type: 'multiselect' },
                        fieldLabelName: 'Target Language',
                        fieldValue: modifiedList ?? [],
                        value: modifiedList ?? [],
                        required: true,
                        disabled: false,
                        moreInputInfo: {
                            select: {
                                options: languageList,
                                optionValue: 'id',
                                optionLabel: 'name',
                                isFilterEnabled: true
                            }
                        },
                        placeholder: 'Select',
                        onChange(value: number[]) {
                            handleTargetLanguageChange(value);
                        }
                    }}
                />
            </div>
        );
    }

    const handleManageLanguagePopupModalSubmit = () => {
        // manageLanguageAPI();
        const deletedItems = manageLanguageSectionValues.targetLanguageIds.filter(
            (item) => !modifiedList.includes(item)
        );
        if (manageLanguageSectionValues.sourceLanguageIds.length > 1 && modifiedList.length > 1) {
            showToastMessage(
                t('QUOTE_AND_ORDER.STD_MAXIMUM_ONE_TARGET_LANGUAGE'),
                ToastType.WARNING
            );
            return;
        }
        if (modifiedList.length === 0) {
            showToastMessage(
                t('QUOTE_AND_ORDER.STD_MINIMUM_ONE_TARGET_LANGUAGE'),
                ToastType.WARNING
            );
            return;
        }
        if (deletedItems.length > 0) {
            setShowConfirmationPopup({
                acceptLabel: t('COMMON.CONFIRM'),
                rejectLabel: t('COMMON.CANCEL'),
                visible: true,
                handlePopConfirmConfirm() {
                    manageLanguageAPI();
                    setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
                },
                header: 'Delete Confirmation',
                subHeader: '',
                description: t('QUOTE_AND_ORDER.STD_DELETE_TARGET_LANGUAGE_CONFIRMATION')
            });
        } else {
            manageLanguageAPI();
        }
    };
    const manageLanguageAPI = async () => {
        try {
            setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
            const res = await manageLanguages<boolean>({
                sourceLanguageIds: manageLanguageSectionValues.sourceLanguageIds,
                targetLanguageId: modifiedList,
                orderId: ViewData.orderId,
                documentId: manageLanguageSectionValues.documentDetails[0].documentId
            });
            if (res === true) {
                console.error('success');
                ViewData.documentRowValueChangeEvent();
                quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
            }

            closeManageLanguagePopupModal();
        } catch (error) {
            console.error('error', error);
        }
    };
    const translatedDocumentTabSection = () => {
        return (
            <TabPanel header="Translated Documents" pt={tabPanelPT(activeIndex === 1)}>
                <div className="p-3">
                    <div id="translatedDocumentsSection">
                        <FiledDocuments
                            orderOrQuoteId={ViewData.orderId}
                            primaryIdForAzureStorage={ViewData.primaryIdForAzureStorage}
                            viewData={ViewData}
                            isEditable={!isCompletedORInvoiced}
                        />
                    </div>
                </div>
            </TabPanel>
        );
    };

    return (
        <>
            <FileUpload
                className="hidden"
                triggerFileInputClick={(triggerFileInput: () => void) => {
                    fileInputTriggerRef.current = triggerFileInput;
                }}
                uploadFileApiUrl={uploadFileApiUrl}
                moduleType={{
                    moduleId: MODULE_TYPE.QUOTE_ORDER_MODULE.moduleId,
                    azureFolderName: MODULE_TYPE.QUOTE_ORDER_MODULE.azureFolderName
                }}
                primaryId={selectedExistingDocument?.documentId as number}
                deleteFileApiUrl={''}
                getDocumentTypeApiUrl={''}
                updateDocumentTypeApiUrl={''}
                ifFiledDocumentUpload={{ isFiledDoc: true, isExistingDocReplace: true }}
                filedDocumentFields={{
                    documentType: selectedExistingDocument?.documentType
                }}
                multipleFiles={false}
                moduleName={`OrderOrQuote-${selectedExistingDocument?.documentId}`}
            />
            <div className="m-w-full overflow-auto">
                {showConfirmationPopup.visible && (
                    <ConfirmationPopup
                        acceptLabel={showConfirmationPopup.acceptLabel}
                        rejectLabel={showConfirmationPopup.rejectLabel}
                        onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                        onCancel={() => handleConfirmationCancel()}
                        visible={showConfirmationPopup.visible}
                        headerText={showConfirmationPopup.header}
                        subHeaderText={showConfirmationPopup.subHeader}
                        description={showConfirmationPopup.description}
                    />
                )}
                {showManageTaskPopup && (
                    <PopupModal
                        id={TABLE_POP_IDS.CREATE_POPUP.MANAGE_TASKS_POPUP}
                        title={
                            <div className="flex items-center gap-3">
                                <div>{'Manage Document'}</div>
                                <span className="font-medium text-neutral-700">
                                    {`[${manageTaskValues?.fileName}]`}
                                </span>
                            </div>
                        }
                        onClose={() => closeModal()}
                        resetButtonText={t('COMMON.CLOSE')}
                        isEdit={true}>
                        <div className="p-4 bg-neutral-300 pb-0">
                            <ManageTasks tasks={manageTaskValues?.task ?? []}></ManageTasks>
                        </div>
                    </PopupModal>
                )}
                {showManageLanguagePopup && (
                    <PopupModal
                        id={TABLE_POP_IDS.CREATE_POPUP.MANAGE_STANDARD_LANGUAGE_POPUP}
                        title={'Manage Language(s)'}
                        createButtonText={t('COMMON.SAVE')}
                        skipValidation={true}
                        onSubmit={handleManageLanguagePopupModalSubmit}
                        onClose={() => closeManageLanguagePopupModal()}
                        resetButtonText={t('COMMON.CLOSE')}
                        isEdit={true}>
                        <div className="p-4 bg-neutral-300 pb-0">
                            {ManageLanguage()}
                            {/* <ManageLanguages
                                documentSectionDetails={manageLanguageSectionValues}
                                languageList={languageList}
                                modifiedList={modifiedList}
                                orderId={ViewData.orderId}
                                documentId={
                                    manageLanguageSectionValues.documentDetails[0].documentId
                                }></ManageLanguages> */}
                        </div>
                    </PopupModal>
                )}
            </div>

            {isRenderUploadDialog && (
                <UploadSTDDetailsPage
                    orderId={ViewData.orderId}
                    sectionId={selectedSectionId}
                    responseData={{ languageList, documentList: ViewData?.documentDetails }}
                    setIsRenderUploadDialog={setIsRenderUploadDialog}
                    toRefreshPage={{
                        stdDetails: ViewData.functions.getStandardDetailsAPI,
                        documentAndLanguageList: ViewData.functions.getDocumentAndLanguagesList
                    }}
                />
            )}

            <div className="pt-5">
                {activeIndex === 0 && (
                    <div className="absolute top-[4.5rem] right-[1.2rem] z-[1]">
                        <PrimeButton
                            testid="std-details-section-add-button"
                            label={'Add Document & Language'}
                            type="primary"
                            outlined={false}
                            className=""
                            disabled={isCompletedORInvoiced}
                            icon="pi pi-plus-circle"
                            size="medium"
                            onClick={() => {
                                setIsRenderUploadDialog(true);
                                setSelectedSectionId(0);
                            }}
                        />
                    </div>
                )}
                <div className="card">
                    <TabView
                        pt={tabViewStyle}
                        activeIndex={activeIndex}
                        onTabChange={(e) => setActiveIndex(e.index)}>
                        <TabPanel header="Uploaded Documents" pt={tabPanelPT(activeIndex === 0)}>
                            <div id="languageGroupSection">
                                <div
                                    data-testid="StandardDocumentTabSection"
                                    className="tableComponent taskTables grid gap-y-1 md:grid md:gap-y-2">
                                    {ViewData?.documentDetails?.map((document: DocumentGroup) => {
                                        return (
                                            // eslint-disable-next-line react/jsx-key
                                            <div
                                                key={document.sectionId}
                                                className="collapse !cursor-auto collapse-arrow bg-primary-50
                                                 border-neutral-600 border rounded-lg">
                                                <input
                                                    type="checkbox"
                                                    className="py-1 min-h-0 w-[44px] px-3"
                                                    name="taskAccordion"></input>
                                                <div
                                                    className="collapse-title !cursor-auto  border-neutral-600
                                                            text-lg py-2 min-h-0 after:h-[8px] after:w-[8px] after:top-3
                                                            after:left-[13px] px-3 pl-[35px]">
                                                    <div className="grid text-base max-w-[70%]">
                                                        <span className="text-base font-medium text-primary">
                                                            {document.sourceLanguages} →{' '}
                                                            {document.targetLanguages}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="collapse-content pb-0 px-5 m-w-full overflow-auto">
                                                    <div className=" bg-white pb-2 pt-3 mt-5 tableComponent rounded-lg">
                                                        <div className="flex justify-end position-relative">
                                                            <div className="absolute top-2 flex gap-2">
                                                                {ViewData.flags
                                                                    ?.isShowDeleteSectionButton && (
                                                                    <PrimeButton
                                                                        testid="std-details-add-language-button"
                                                                        label={'Delete Section'}
                                                                        type="primary"
                                                                        disabled={
                                                                            isCompletedORInvoiced
                                                                        }
                                                                        outlined={true}
                                                                        size="medium"
                                                                        onClick={() => {
                                                                            handleDeleteSection(
                                                                                document
                                                                            );
                                                                        }}
                                                                    />
                                                                )}
                                                                {ViewData.flags
                                                                    ?.isShowManageLanguageButton && (
                                                                    <PrimeButton
                                                                        testid="std-details-add-language-button"
                                                                        label={'Manage Language(s)'}
                                                                        type="primary"
                                                                        disabled={
                                                                            isCompletedORInvoiced
                                                                        }
                                                                        outlined={true}
                                                                        size="medium"
                                                                        onClick={() => {
                                                                            handleManageLanguage(
                                                                                document
                                                                            );
                                                                        }}
                                                                    />
                                                                )}
                                                                <PrimeButton
                                                                    testid="std-details-add-document-button"
                                                                    label={'Add Document(s)'}
                                                                    type="primary"
                                                                    disabled={isCompletedORInvoiced}
                                                                    outlined={true}
                                                                    size="medium"
                                                                    onClick={() => {
                                                                        setIsRenderUploadDialog(
                                                                            true
                                                                        );
                                                                        setSelectedSectionId(
                                                                            document.sectionId
                                                                        );
                                                                    }}
                                                                />
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <DataTableComponent
                                                                tableData={
                                                                    getTableData(
                                                                        document.documentDetails
                                                                    ) ?? []
                                                                }
                                                                tableRequestBodyData={requestBody}
                                                                tableDefinition={tableDefinition}
                                                                toggleRowData={() => {}}
                                                                handleFilter={setRequestBody}
                                                                handleSort={setRequestBody}
                                                                handlePagination={setRequestBody}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </TabPanel>
                        {translatedDocumentTabSection()}
                    </TabView>
                </div>
            </div>
        </>
    );
};
export default StandardDocumentTabSection;
