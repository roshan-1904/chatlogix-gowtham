import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { t } from 'i18next';
import { updateShowToVendor } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { Task } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';

import { useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    paginationData,
    RequestBody
} from 'shared/dataTable/types/dataTable.types';

interface ManageTaskProps {
    tasks: Task[] | [];
    // confirmationPopupProps: ConfirmationPopupProps;
}

// eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
const ManageTasks: React.FC<ManageTaskProps> = ({ tasks }) => {
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 25
    });
    const [paginationInfo] = useState<paginationData>();
    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        acceptLabel: '',
        rejectLabel: '',
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });

    let contactColumnNumber = 0;
    const publishDocumentTemplate = (rowData: Task) => {
        const getToggleText = (): string => {
            if (rowData.shownInvendor) {
                return t('COMMON.YES');
            } else {
                return t('COMMON.NO');
            }
        };
        return (
            <div
                key={rowData.taskId}
                data-testid="summaryGrossMarginEligible"
                className="flex items-center justify-start w-6/12 py-3 toggle_disable_State">
                <input
                    type="checkbox"
                    className="toggle toggle-sm border-2"
                    style={{
                        borderColor: rowData.shownInvendor ? '#1175C2' : '#A4A5A6',
                        backgroundColor: rowData.shownInvendor ? '#1175C2' : '#A4A5A6'
                    }}
                    checked={rowData.shownInvendor}
                    data-testid="toggle-text"
                    onChange={() => handlePublishToVendorToggleChange(rowData)}
                />
                <div data-testid="summaryGrossMarginEligible-text" className="ml-2">
                    {getToggleText()}
                </div>
            </div>
        );
    };
    const handlePublishToVendorToggleChange = (rowData: Task) => {
        setShowConfirmationPopup({
            acceptLabel: t('COMMON.CONFIRM'),
            rejectLabel: t('COMMON.CANCEL'),
            visible: true,
            handlePopConfirmConfirm: () => handlePublishToVendor(rowData),
            header: 'Confirmation',
            subHeader: '',
            description: t('COMMON.CONFIRMATION_STATUS')
        });
    };

    const handlePublishToVendor = (rowData: Task) => {
        const errMsg = 'Error while updating the task';
        const executeUpdate = async () => {
            try {
                const response = await updateShowToVendor<boolean>(rowData);
                if (response) {
                    {
                        rowData.shownInvendor = !rowData.shownInvendor;
                    }
                } else {
                    alert(errMsg);
                }
                setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
            } catch (error) {
                setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
                alert(errMsg);
            }
        };

        executeUpdate();
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskId',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: contactColumnNumber++,
            visibility: true
        },
        {
            field: 'shownInvendor',
            header: 'Show to Vendor',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.YesOrNo,
            columnNumber: contactColumnNumber++,
            body: publishDocumentTemplate,
            visibility: true
        }
    ];
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.STD_MANGE_DOCUMENT_TABLE,
        filters: {},
        reOrderableColumns: false,
        title: '',
        emptyMessage: 'No Data Found',
        localStorageKey: '',
        columns: columnSchema,
        hideColumnSelector: true,
        hideTableExport: false,
        customTableHeight: false
    };

    return (
        <>
            {showConfirmationPopup.visible && (
                <ConfirmationPopup
                    acceptLabel={showConfirmationPopup.acceptLabel}
                    rejectLabel={showConfirmationPopup.rejectLabel}
                    onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                    visible={showConfirmationPopup.visible}
                    headerText={showConfirmationPopup.header}
                    subHeaderText={showConfirmationPopup.subHeader}
                    description={showConfirmationPopup.description}
                />
            )}
            <DataTableComponent
                tableData={tasks ?? []}
                tableRequestBodyData={requestBody}
                tableDefinition={tableDefinition}
                toggleRowData={() => {}}
                handleFilter={setRequestBody}
                handleSort={setRequestBody}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
            />
        </>
    );
};

export default ManageTasks;
