import { fireEvent, render, screen } from '@testing-library/react';
import StandardDocumentTabSection from './StandardDocumentTabSection';
import { DocumentDetailsResponse } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import { BrowserRouter } from 'react-router-dom'; // Import BrowserRouter
import { IP_NONIP } from 'constants/app.constant';

// Mocks
jest.mock('shared/dataTable/dataTable', () => ({
    __esModule: true,
    default: () => <div data-testid="mocked-data-table">Mocked DataTable</div>
}));
jest.mock('components/popupModal/popupModal', () => ({
    __esModule: true,
    default: ({ children }: { children: React.ReactNode }) => (
        <div data-testid="mocked-popup-modal">{children}</div>
    )
}));
jest.mock('components/confirmationPopup/confirmationPopup', () => ({
    __esModule: true,
    default: ({ children }: { children: React.ReactNode }) => (
        <div data-testid="mocked-confirmation-popup">{children}</div>
    )
}));
jest.mock('pages/ViewOrderAndQuote/service/viewOrderQuoteService', () => ({
    __esModule: true,
    manageLanguages: jest.fn(),
    standardDeleteDocument: jest.fn(),
    validateDeleteTargetLanguage: jest.fn()
}));
jest.mock('pages/pvsettings/subaccordions/service/pvsettings.service', () => ({
    __esModule: true,
    getAllLanguages: jest.fn()
}));
jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn()
}));

test('renders component with tabs', () => {
    const mockDocumentDetails: DocumentDetailsResponse = {
        orderId: 1,
        primaryIdForAzureStorage: 100,
        requestType: IP_NONIP.nonIp,
        documentDetails: [
            {
                sectionId: 1,
                sourceLanguages: 'English',
                targetLanguages: 'French,German',
                documentDetails: [
                    {
                        documentId: 101,
                        documentNumber: 'DOC-001',
                        fileName: 'test.pdf',
                        documentTypeName: 'Contract',
                        sourceLanguageName: 'English',
                        targetLanguageName: 'French,German',
                        task: [
                            {
                                taskId: '201',
                                taskNumber: 0,
                                documentMappingId: 0,
                                shownInvendor: false
                            },
                            {
                                taskId: '202',
                                taskNumber: 0,
                                documentMappingId: 0,
                                shownInvendor: false
                            }
                        ],
                        orderId: 0,
                        blobFileName: '',
                        fileType: '',
                        fileSize: '',
                        blobUrl: '',
                        sectionId: 0,
                        documentType: 0,
                        uploadAction: null,
                        shownInVendor: null,
                        notes: '',
                        sourceLanguageId: null,
                        targetLanguageId: null,
                        taskIds: null
                    }
                ],
                sourceLanguageIds: [],
                targetLanguageIds: []
            }
        ],
        blobUri: 'http://example.com/blob',
        documentRowValueChangeEvent: jest.fn(),
        functions: {
            getStandardDetailsAPI: jest.fn(),
            getDocumentAndLanguagesList: jest.fn()
        },
        flags: { someData: true }
    };
    render(
        <BrowserRouter>
            <StandardDocumentTabSection {...mockDocumentDetails} />
        </BrowserRouter>
    );
    expect(screen.getByTestId('StandardDocumentTabSection')).toBeInTheDocument();
    expect(screen.getByText('English → French,German')).toBeInTheDocument();

    const addButton = screen.getAllByTestId('std-details-section-add-button')[0];
    expect(addButton).toBeInTheDocument();
    fireEvent.click(addButton);
});
