import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import PrimeSelect from 'components/inputs/primeSelect.input';
import { validateDeleteTargetLanguage } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { ManageDocumentProps } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import { useState } from 'react';

// eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
const ManageLanguages: React.FC<ManageDocumentProps> = (ctx: ManageDocumentProps) => {
    const handlePopConfirmConfirm = () => {};
    const [targetLanguageIds] = useState<number[]>(
        ctx.documentSectionDetails.targetLanguageIds ?? []
    );
    const [showConfirmationPopup] = useState({
        acceptLabel: '',
        rejectLabel: '',
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });
    const handleTargetLanguageChangeWrapper = (value: number[]) => {
        handleTargetLanguageChange(value).catch((error) =>
            console.error('Error handling target language change:', error)
        );
    };
    const handleTargetLanguageChange = async (value: number[]) => {
        const deletedItems = targetLanguageIds.filter((item) => !value.includes(item));
        if (deletedItems.length > 0) {
            const res = await validateDeleteTargetLanguage<boolean>({
                targetLanguageIds: deletedItems,
                orderId: ctx.orderId,
                documentId: ctx.documentId
            });
            if (res === true) {
                ctx.modifiedList = value;
            }
        }
    };

    return (
        <>
            {showConfirmationPopup.visible && (
                <ConfirmationPopup
                    acceptLabel={showConfirmationPopup.acceptLabel}
                    rejectLabel={showConfirmationPopup.rejectLabel}
                    onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                    visible={showConfirmationPopup.visible}
                    headerText={showConfirmationPopup.header}
                    subHeaderText={showConfirmationPopup.subHeader}
                    description={showConfirmationPopup.description}
                />
            )}
            {/* languages (multi-select) */}
            <div className="flex gap-3 mb-5" data-testid="input-field-template">
                <PrimeSelect
                    testId={'primeSelect'}
                    fieldLabelName={'Source Language'}
                    value={ctx.documentSectionDetails.sourceLanguageIds ?? []}
                    options={ctx.languageList}
                    optionLabel="name"
                    optionValue="id"
                    placeholder="Select"
                    invalid={false}
                    required={true}
                    disabled={true}
                    showInputLabelName={true}
                    isMultiSelect={true}
                    isFilterEnabled={true}
                    isClearEnabled={true}
                    isRenderAsChip={false}
                    errorMsg="Source Language is required"
                    customClass={{}}
                    onChange={() => {}}
                />
                <PrimeSelect
                    testId={'primeSelect'}
                    fieldLabelName={'Target Language'}
                    value={ctx.modifiedList ?? []}
                    options={ctx.languageList}
                    optionLabel="name"
                    optionValue="id"
                    placeholder="Select"
                    invalid={false}
                    required={true}
                    disabled={false}
                    showInputLabelName={true}
                    isMultiSelect={true}
                    isFilterEnabled={true}
                    isClearEnabled={true}
                    isRenderAsChip={false}
                    errorMsg="Source Language is required"
                    customClass={{ wrapper: 'max-w-[80%]' }}
                    onChange={(selectedValue) =>
                        handleTargetLanguageChangeWrapper(selectedValue as number[])
                    }
                />
            </div>
        </>
    );
};

export default ManageLanguages;
