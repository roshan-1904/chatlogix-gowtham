import { fireEvent, render, screen } from '@testing-library/react';
import ManageTasks from './ManageTasks';
import { ManageDocumentProps, Task } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import ManageLanguages from './ManageLanguages';

test('renders ManageTasks component', () => {
    const mockTasks: Task[] = [
        { taskId: '1', shownInvendor: true, documentMappingId: 1, taskNumber: 1 },
        { taskId: '2', shownInvendor: false, documentMappingId: 1, taskNumber: 2 }
    ];
    render(<ManageTasks tasks={mockTasks} />);
    // const dataTable = screen.getByTestId('data-table');
    // expect(dataTable).toBeInTheDocument();
});

test('renders ManageTasks component', () => {
    const mockTasks: ManageDocumentProps = {
        documentSectionDetails: {
            sectionId: 1,
            sourceLanguages: 'English',
            targetLanguageIds: [2, 3],
            targetLanguages: 'French, German',
            sourceLanguageIds: []
        },
        orderId: 123,
        documentId: 456,
        modifiedList: [],
        languageList: []
    };
    render(<ManageLanguages {...mockTasks} />);
    const inputField = screen.getByTestId('input-field-template');
    expect(inputField).toBeInTheDocument();
});

test('handlePublishToVendorToggleChange shows confirmation popup', () => {
    const mockTasks: Task[] = [
        { taskId: '1', shownInvendor: true, documentMappingId: 1, taskNumber: 1 },
        { taskId: '2', shownInvendor: false, documentMappingId: 1, taskNumber: 2 }
    ];
    render(<ManageTasks tasks={mockTasks} />);

    const checkbox = screen.getAllByTestId('toggle-text')[0];
    expect(checkbox).toBeInTheDocument();
    fireEvent.click(checkbox);
    const confirmButton = screen.getAllByTestId('accept-label')[0];
    fireEvent.click(confirmButton);
});
