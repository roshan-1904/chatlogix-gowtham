import { FC, useMemo } from 'react';
import ConstructField from 'components/reuseComponents/constructField';
import { CATEGORY_TYPE, IP_NONIP, SERVICE_TYPES } from 'constants/app.constant';
import { t } from 'i18next';
import { renderLabel } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { isStaffUser, isVendorUser } from 'core/utils/utils';
import FieldValue from 'components/inputs/fieldValue.label';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import OverflowTagList from 'shared/dataTable/components/overflowTagsList/overflowTagsList';

interface RequestDetailsPageModel {
    requestDetails: any;
    editInput?: any;
    handleEdit?: (value: string) => void;
    handleChange?: (value1: string, value2: string | number | string[]) => void;
    handleSave?: (value1: string, value2: string) => Promise<void> | void;
    handleCancel?: (value1: string, value2: string) => void;
    category: string;
    service: string;
    viewData: any;
}

const RequestDetailsPage: FC<RequestDetailsPageModel> = ({
    requestDetails,
    editInput,
    handleEdit,
    handleChange,
    handleSave,
    handleCancel,
    category,
    service,
    viewData
}) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserId);
    const isThisVendorUser = isVendorUser(loggedInUserId);
    const requestType = viewData?.requestType;
    const isNonIp = requestType === IP_NONIP.nonIp;
    const isPC = category === CATEGORY_TYPE.paris_convention_treaty;
    const isRecordals = service === SERVICE_TYPES.recordal;
    const isRenewals = service === SERVICE_TYPES.renewals;
    const isEp = category === CATEGORY_TYPE.european_patent;
    const isSTD = category === CATEGORY_TYPE.other_translations;
    const isUpcOptOut = service === SERVICE_TYPES.upc_opt_out;
    const isCompetedOrInvoiced =
        viewData?.headers?.statusName === RequestStatusEnum.COMPLETED ||
        viewData?.headers?.statusName === RequestStatusEnum.INVOICED;
    const isKindCodeShow =
        isEp &&
        (service === '71_3_claims' ||
            service === 'translation_only' ||
            service === 'translation_&_validation');
    const generalServiceToEnable = [
        'translation_only', // pct
        'annuities', // pct
        'translation_&_filing', // pct & ep
        '71_3_claims', // ep
        'translation_&_validation' // ep
    ];
    const isPatentApplicationShow =
        !isPC &&
        !isNonIp &&
        !isRecordals &&
        !isRenewals &&
        !isUpcOptOut &&
        generalServiceToEnable.includes(service);
    const isPatentPublicationShow =
        !isPC &&
        !isNonIp &&
        !isUpcOptOut &&
        (isRecordals || isRenewals || generalServiceToEnable.includes(service));

    const handleSaveWrapper = (value1: string, value2: string) => {
        const result = handleSave?.(value1, value2);

        if (result instanceof Promise) {
            result.catch((err) => {
                console.error(err);
            });
        }
    };

    return (
        <div className="py-3 pb-3" data-testid="AddressInformation-Accordian">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-7 mt-2">
                {!isRecordals && !isPC && (
                    <ConstructField
                        data={{
                            isFieldHasEditability:
                                (isThisStaffUser || isThisVendorUser) &&
                                (isSTD || isUpcOptOut) &&
                                !isCompetedOrInvoiced,
                            isFieldInEditMode: editInput?.patentTitle?.isEdit,
                            tooltip: {
                                content:
                                    isSTD || isUpcOptOut
                                        ? editInput?.patentTitle?.value
                                        : requestDetails?.patentTitle
                            },
                            fieldType: 'input',
                            inputType: { type: 'text' },
                            fieldValue:
                                isSTD || isUpcOptOut
                                    ? editInput?.patentTitle?.value
                                    : requestDetails?.patentTitle,
                            state: requestDetails?.patentTitle
                                ? editInput?.patentTitle?.newValue
                                : requestDetails?.patentTitle,
                            fieldLabelName: t('COMPANY_DETAILS.PATENT_TITLE'),
                            placeholder: t('COMPANY_DETAILS.PATENT_TITLE'),
                            actions: {
                                edit: () => handleEdit?.('patentTitle'),
                                update: () => handleSaveWrapper?.('patentTitle', 'RequestDetails'),
                                cancel: () => handleCancel?.('patentTitle', 'RequestDetails'),
                                onChange: (value: any) =>
                                    handleChange?.('patentTitle', (value ?? null) as string)
                            },
                            customClass: { fieldValueLabel: 'font-medium' },
                            testId: {
                                label: 'test-label-patent-title',
                                field: 'test-field-patent-title'
                            }
                        }}
                    />
                )}
                <div>
                    {renderLabel(t('COMPANY_DETAILS.CATEGORY'))}
                    <FieldValue
                        value={requestDetails?.categoryDisplayText}
                        fieldLabelName={t('COMPANY_DETAILS.CATEGORY')}
                        renderAs="string"
                        tooltipContent={requestDetails?.categoryDisplayText}
                        customClass={{ field: 'font-medium' }}
                        testId={'field-' + t('COMPANY_DETAILS.CATEGORY')}
                    />
                </div>
                <div>
                    {renderLabel(t('COMPANY_DETAILS.SERVICE'))}
                    <FieldValue
                        value={isNonIp ? service : requestDetails?.servicesDisplayText}
                        fieldLabelName={t('COMPANY_DETAILS.SERVICE')}
                        renderAs="string"
                        tooltipContent={isNonIp ? service : requestDetails?.servicesDisplayText}
                        customClass={{ field: 'font-medium' }}
                        testId={'field-' + t('COMPANY_DETAILS.SERVICE')}
                    />
                </div>

                {isUpcOptOut && (
                    <div>
                        <div className="flex items-center gap-3">
                            {renderLabel(t('COMPANY_DETAILS.PATENT_NUMBER'))}
                            <div
                                className="pt-0.5 flex items-center gap-2 [&>span]:text-[0.75rem] [&>span]:font-medium [&>span]:text-black/60 [&>span]:flex [&>span]:items-center [&>span]:gap-1
                            [&>span>div]:w-4 [&>span>div]:h-2.5 [&>span>div]:border [&>span>div]:rounded">
                                <span>
                                    <div className=" bg-success-green/10 border-success-green/80"></div>
                                    {t('COMMON.VALID')}
                                </span>
                                <div className="border h-3"></div>
                                <span>
                                    <div className=" bg-secondary-dark-red/5 border-secondary-dark-red/50"></div>
                                    {t('COMMON.INVALID')}
                                </span>
                            </div>
                        </div>
                        <div className="mt-1">
                            <OverflowTagList
                                key={`labels`}
                                tags={
                                    viewData?.upcOptOutPatentNumbers?.length
                                        ? viewData?.upcOptOutPatentNumbers.map(
                                              (item: {
                                                  patentNumber: string;
                                                  isValid: boolean;
                                              }) => ({
                                                  tag: item.patentNumber,
                                                  customStyle: item.isValid
                                                      ? 'bg-success-green/10 border-success-green/80 '
                                                      : 'bg-secondary-dark-red/5 border-secondary-dark-red/50 '
                                              })
                                          )
                                        : []
                                }
                            />
                        </div>
                    </div>
                )}

                {isPatentApplicationShow && (
                    <div>
                        {renderLabel(t('COMPANY_DETAILS.PATENT_APP_NUMBER'))}
                        <FieldValue
                            value={requestDetails?.patentApplicationNumber}
                            fieldLabelName={t('COMPANY_DETAILS.PATENT_APP_NUMBER')}
                            renderAs="string"
                            tooltipContent={requestDetails?.patentApplicationNumber}
                            customClass={{ field: 'font-medium' }}
                            testId={'field-' + t('COMPANY_DETAILS.PATENT_APP_NUMBER')}
                        />
                    </div>
                )}
                {isPatentPublicationShow && (
                    <div>
                        {renderLabel(t('COMPANY_DETAILS.PATENT_PUBLICATION_NUMBER'))}
                        <FieldValue
                            value={requestDetails?.patentPublicationNumber}
                            fieldLabelName={t('COMPANY_DETAILS.PATENT_PUBLICATION_NUMBER')}
                            renderAs="string"
                            tooltipContent={requestDetails?.patentPublicationNumber}
                            customClass={{ field: 'font-medium' }}
                            testId={'field-' + t('COMPANY_DETAILS.PATENT_PUBLICATION_NUMBER')}
                        />
                    </div>
                )}
                {!isNonIp && !isRecordals && !isUpcOptOut && (
                    <div>
                        {renderLabel(t('COMPANY_DETAILS.SOURCE_LANGUAGE'))}
                        <FieldValue
                            value={requestDetails?.sourceLanguage}
                            fieldLabelName={t('COMPANY_DETAILS.SOURCE_LANGUAGE')}
                            renderAs="string"
                            tooltipContent={requestDetails?.sourceLanguage}
                            customClass={{ field: 'font-medium' }}
                            testId={'field-' + t('COMPANY_DETAILS.SOURCE_LANGUAGE')}
                        />
                    </div>
                )}
                {!isNonIp && !isRecordals && !isUpcOptOut && (
                    <div>
                        {renderLabel(t('COMPANY_DETAILS.APPLICANT_NAME'))}
                        <FieldValue
                            value={requestDetails?.applicant?.split('=')?.join(', ')}
                            fieldLabelName={t('COMPANY_DETAILS.APPLICANT_NAME')}
                            renderAs="string"
                            tooltipContent={requestDetails?.applicant?.split('=')?.join(', ')}
                            customClass={{ field: 'font-medium' }}
                            testId={'field-' + t('COMPANY_DETAILS.APPLICANT_NAME')}
                        />
                    </div>
                )}
                {viewData?.existingPatentCounts?.kind &&
                    isKindCodeShow &&
                    !isNonIp &&
                    !isUpcOptOut && (
                        <div>
                            {renderLabel(t('COMPANY_DETAILS.KIND'))}
                            <FieldValue
                                value={viewData?.existingPatentCounts.kind}
                                fieldLabelName={t('COMPANY_DETAILS.KIND')}
                                renderAs="string"
                                tooltipContent={viewData?.existingPatentCounts.kind}
                                customClass={{ field: 'font-medium' }}
                                testId={'field-' + t('COMPANY_DETAILS.KIND')}
                            />
                        </div>
                    )}
            </div>
        </div>
    );
};

export default RequestDetailsPage;
