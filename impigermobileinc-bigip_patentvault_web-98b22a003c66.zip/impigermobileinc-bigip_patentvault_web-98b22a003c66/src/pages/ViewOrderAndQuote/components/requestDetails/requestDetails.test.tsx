import '@testing-library/jest-dom/extend-expect';
import { render, screen } from '@testing-library/react';
import viewOrderAndQuoteData from '../../Mock/viewOrderAndQuote.mock.json';
import RequestDetailsPage from './requestDetails';

const { requestDetailsData } = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('Request details section', () => {
    test('Check render of request details section in the view Order/Quote screen', () => {
        render(
            <RequestDetailsPage
                requestDetails={requestDetailsData}
                category={''}
                service={''}
                viewData={{}}
            />
        );
    });

    test('Check the presence of request details section fields screen', () => {
        render(
            <RequestDetailsPage
                requestDetails={requestDetailsData}
                category={''}
                service={''}
                viewData={{}}
            />
        );
        expect(screen.getByTestId('patent-title')).toBeDefined();
        expect(screen.getByTestId('category')).toBeDefined();
        expect(screen.getByTestId('service')).toBeDefined();
        expect(screen.getByTestId('patent-application-number')).toBeDefined();
        expect(screen.getByTestId('patent-publication-number')).toBeDefined();
        expect(screen.getByTestId('source-language')).toBeDefined();
        expect(screen.getByTestId('applicant-name')).toBeDefined();
    });
});
