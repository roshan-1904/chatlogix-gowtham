import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { LanguageDetails } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';

type LanguageDetailsProps = {
    languageDetails: LanguageDetails[];
    handleFilter: any;
    sortHandler: any;
    requestBody: any;
};

const LanguageDetailsPage = ({
    languageDetails,
    handleFilter,
    sortHandler,
    requestBody
}: LanguageDetailsProps) => {
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'fileName',
            header: 'File Name',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            alignFrozen: 'left'
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true
        },
        {
            field: 'targetLanguages',
            header: 'Target Languages',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.MultiSelect,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'quantity',
            header: 'Quantity',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 4,
            visibility: true
        }
        // {
        //     field: 'deliveryDate',
        //     header: 'Delivery Date',
        //     sortable: true,
        //     filter: true,
        //     filterType: FilterType.Calendar,
        //     valueType: ValueType.Date,
        //     columnNumber: 0,
        //     visibility: true
        // }
    ];

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.QUOTE_AND_ORDER,
        filters: {},
        reOrderableColumns: true,
        title: 'Table Header',
        emptyMessage: '',
        customTableHeight: false,
        editTable: {
            editType: '',
            rowEditComplete() {},
            isRowEdit: true
        },
        localStorageKey: '',
        columns: columnSchema
        // buttonChildren: createOrderQuoteDropDown()
    };
    return (
        <div className="py-2 pb-3" data-testid="AddressInformation-Accordian">
            <div className=" grid grid-cols-1 md:grid-cols-1 gap-4 mt-3">
                <div className="m-w-full overflow-auto mb-5">
                    <DataTableComponent
                        showPagination={false}
                        showHeader={false}
                        tableData={languageDetails ?? []}
                        tableDefinition={tableDefinition}
                        tableRequestBodyData={requestBody}
                        toggleRowData={() => {}}
                        selectedItems={[]}
                        dataKey="launguageDetails"
                        handleSelectedItems={() => {}}
                        handleFilter={handleFilter}
                        handleSort={sortHandler}
                    />
                </div>
            </div>
        </div>
    );
};

export default LanguageDetailsPage;
