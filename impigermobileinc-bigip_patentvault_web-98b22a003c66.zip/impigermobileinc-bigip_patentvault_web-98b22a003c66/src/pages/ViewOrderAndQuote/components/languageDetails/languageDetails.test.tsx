import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import LanguageDetailsPage from './languageDetails';

describe('LanguageDetailsPage Component', () => {
    const mockLanguageDetails = [
        {
            FileName: 'File1',
            SourceLanguage: 'English',
            TargetLanguages: '',
            DeliveryDate: '2023-10-01'
        },
        {
            FileName: 'File2',
            SourceLanguage: 'Spanish',
            TargetLanguages: '',
            Quantity: 5,
            DeliveryDate: '2023-10-02'
        }
    ];

    const mockHandleFilter = jest.fn();
    const mockSortHandler = jest.fn();
    const mockRequestBody = {};

    it('should render the component with table data', () => {
        render(
            <LanguageDetailsPage
                languageDetails={mockLanguageDetails}
                handleFilter={mockHandleFilter}
                sortHandler={mockSortHandler}
                requestBody={mockRequestBody}
            />
        );

        expect(screen.getByText('File Name')).toBeInTheDocument();
        expect(screen.getByText('Source Language')).toBeInTheDocument();
        expect(screen.getByText('Target Languages')).toBeInTheDocument();
        expect(screen.getByText('Quantity')).toBeInTheDocument();

        expect(screen.getByText('File1')).toBeInTheDocument();
        expect(screen.getByText('English')).toBeInTheDocument();
        expect(screen.getByText('French, German')).toBeInTheDocument();
        expect(screen.getByText('10')).toBeInTheDocument();
    });

    it('should call sortHandler when sorting is triggered', () => {
        render(
            <LanguageDetailsPage
                languageDetails={mockLanguageDetails}
                handleFilter={mockHandleFilter}
                sortHandler={mockSortHandler}
                requestBody={mockRequestBody}
            />
        );

        // Simulate a sort action (assuming a button or column header triggers sorting)
        const sortableHeader = screen.getByText('File Name');
        userEvent.click(sortableHeader);

        expect(mockSortHandler).toHaveBeenCalled();
    });

    it('should call handleFilter when filtering is triggered', () => {
        render(
            <LanguageDetailsPage
                languageDetails={mockLanguageDetails}
                handleFilter={mockHandleFilter}
                sortHandler={mockSortHandler}
                requestBody={mockRequestBody}
            />
        );

        // Simulate a filter action (assuming an input field is used for filtering)
        const filterInput = screen.getByPlaceholderText('Filter by File Name'); // Adjust placeholder text as per implementation
        userEvent.type(filterInput, 'File1');

        expect(mockHandleFilter).toHaveBeenCalled();
    });
});
