import { useRef } from 'react';
import { TieredMenu } from 'primereact/tieredmenu';
import { MenuItem } from 'primereact/menuitem';
import { t } from 'i18next';
import xls from 'assets/svgs/xls-file.svg';
import pdf from 'assets/svgs/pdf-file.svg';

const Actions = (props: {
    isApproveButtonVisible?: boolean;
    editButton?: { isVisible: boolean; onClick: () => void };
    previewButton?: { isVisible: boolean; onClick: () => void };
    epEditButton?: { isVisible: boolean; onClick: () => void };
    epBothDecidePreviewButton?: {
        isVisible: boolean;
        uponClick: () => void;
        nationalValidationClick: () => void;
    };
    epBothDecideExportButton?: {
        isVisible: boolean;
        pdfClick: () => void;
        excelClick: () => void;
    };
}) => {
    const menuRef = useRef<TieredMenu>(null);
    const adjustSubmenuAlignment = () => {
        setTimeout(() => {
            const submenus = document.getElementsByClassName('p-submenu-list-flipped');
            if (!submenus.length) return;

            Array.from(submenus).forEach((submenu) => {
                const submenuEl = submenu as HTMLElement;
                const parentMenu = submenuEl.closest('li');
                if (!parentMenu) return;

                const parentWidthRem = parentMenu.offsetWidth / 16;
                submenuEl.style.right = `${parentWidthRem + 0.06}rem`;
                submenuEl.style.opacity = '1';
            });
        }, 10);
    };

    const actionItem = {
        EDIT: 'EDIT',
        PREVIEW: 'PREVIEW',
        EP_EDIT: 'EP_EDIT',
        EP_BOTH_DECIDE_PREVIEW: 'EP_BOTH_DECIDE_PREVIEW',
        EP_BOTH_DECIDE_EXPORT: 'EP_BOTH_DECIDE_EXPORT'
    };

    const items: MenuItem[] = [
        {
            id: actionItem.EDIT,
            label: t('QUOTE_AND_ORDER.EDIT_QUOTE'),
            icon: () => (
                <img alt="edit" src="/images/svgs/i-edit-blue-icon.svg" className="h-4 mr-2" />
            ),
            visible: props.editButton?.isVisible,
            command: () => props.editButton?.onClick()
        },
        {
            id: actionItem.EP_EDIT,
            label: t('QUOTE_AND_ORDER.EDIT_QUOTE'),
            icon: () => (
                <img alt="edit" src="/images/svgs/i-edit-blue-icon.svg" className="h-4 mr-2" />
            ),
            visible: props.epEditButton?.isVisible,
            command: () => props.epEditButton?.onClick()
        },
        {
            id: actionItem.PREVIEW,
            label: t('COMMON.PREVIEW'),
            icon: 'pi pi-eye text-primary',
            visible: props.previewButton?.isVisible,
            command: () => props.previewButton?.onClick()
        },
        {
            id: actionItem.EP_BOTH_DECIDE_PREVIEW,
            label: t('COMMON.PREVIEW'),
            icon: 'pi pi-eye text-primary',
            visible: props.epBothDecidePreviewButton?.isVisible,
            items: [
                {
                    label: t('SELECT_EP_COUNTRY.UP_NATIONAL_VALIDATIONS'),
                    icon: 'pi pi-file-pdf text-primary',
                    command: () => props.epBothDecidePreviewButton?.uponClick()
                },
                {
                    label: t('SELECT_EP_COUNTRY.NATIONAL_VALIDATIONS'),
                    icon: 'pi pi-file-pdf text-warning-200',
                    command: () => props.epBothDecidePreviewButton?.nationalValidationClick()
                }
            ]
        },
        {
            id: actionItem.EP_BOTH_DECIDE_EXPORT,
            label: t('COMMON.EXPORT'),
            icon: 'pi pi-file-export text-primary',
            visible: props.epBothDecideExportButton?.isVisible,
            items: [
                {
                    label: t('COMMON.PDF'),
                    icon: <img alt="pdf" src={pdf} className="h-4 mr-2" />,
                    command: () => props.epBothDecideExportButton?.pdfClick()
                },
                {
                    label: t('COMMON.EXCEL'),
                    icon: <img alt="excel" src={xls} className="h-4 mr-2" />,
                    command: () => props.epBothDecideExportButton?.excelClick()
                }
            ]
        }
    ];

    const visibleItems = items.filter((item) => item.visible);
    const visibleCount = visibleItems.length;

    const isSingleVisible = visibleCount === 1;
    const isMultipleVisible = visibleCount > 1;

    const singleItem = isSingleVisible ? visibleItems[0] : null;

    const isApproveHideOnlyTwoItemsVisible =
        !props.isApproveButtonVisible &&
        visibleCount === 2 &&
        visibleItems.some(
            (item) => item.id === actionItem.EDIT || item.id === actionItem.EP_EDIT
        ) &&
        visibleItems.some((item) => item.id === actionItem.PREVIEW);

    return (
        <div className="card flex justify-content-center mr-2">
            {isApproveHideOnlyTwoItemsVisible && (
                <div className="flex items-center gap-3">
                    <button
                        className={`btn min-h-9 h-9 border border-primary text-primary rounded-md px-3 font-medium flex items-center gap-2 hover:bg-primary/10`}
                        onClick={() => {
                            props.previewButton?.onClick();
                        }}>
                        {t('COMMON.PREVIEW')}
                    </button>
                    <button
                        className={`btn min-h-9 h-9 border border-primary text-primary rounded-md px-3 font-medium flex items-center gap-2 hover:bg-primary/10`}
                        onClick={() => {
                            props.editButton?.onClick();
                        }}>
                        <img alt="edit" src="/images/svgs/i-edit-blue-icon.svg" className="h-4" />
                        {t('QUOTE_AND_ORDER.EDIT_QUOTE')}
                    </button>
                </div>
            )}

            {isSingleVisible && (
                <button
                    className={`btn min-h-9 h-9 border border-primary text-primary rounded-md px-3 font-medium flex items-center gap-2 hover:bg-primary/10`}
                    onClick={() => {
                        if (singleItem?.id === actionItem.EDIT) props.editButton?.onClick();
                        if (singleItem?.id === actionItem.PREVIEW) props.previewButton?.onClick();
                        if (singleItem?.id === actionItem.EP_EDIT) props.epEditButton?.onClick();
                    }}>
                    {(singleItem?.id === actionItem.EDIT ||
                        singleItem?.id === actionItem.EP_EDIT) && (
                        <img alt="edit" src="/images/svgs/i-edit-blue-icon.svg" className="h-4" />
                    )}
                    <span className="font-semibold">{singleItem?.label}</span>
                </button>
            )}

            {isMultipleVisible && !isApproveHideOnlyTwoItemsVisible && (
                <div>
                    <TieredMenu
                        model={items}
                        popup
                        ref={menuRef}
                        appendTo="self"
                        pt={{
                            submenu: {
                                className:
                                    'left-auto p-submenu-list-flipped opacity-0 border border-black/15 rounded-md'
                            },
                            menu: { className: 'p-menu-list' },
                            root: { className: '!left-auto right-0 border-black/15' },
                            action: { onClick: () => adjustSubmenuAlignment() },
                            label: { className: 'whitespace-nowrap text-black/80 font-medium pr-3' }
                        }}
                    />
                    <i
                        className="pi pi-ellipsis-v h-9 p-2 border border-primary text-primary rounded-md cursor-pointer"
                        title="More Options"
                        data-testid="more-options-icon"
                        onClick={(e) => menuRef.current?.toggle(e)}
                    />
                </div>
            )}
        </div>
    );
};

export default Actions;
