import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import viewOrderAndQuoteData from '../../Mock/viewOrderAndQuote.mock.json';
import DateAndDeadlinesPage from './dateAndDeadlines';

const { dateAndDeadlinesData } = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('Header of view order/quote', () => {
    test('Check render of date and deadlines section in the view Order/Quote screen', () => {
        render(
            <DateAndDeadlinesPage
                editInput={dateAndDeadlinesData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSaveAI={() => {}}
                handleCancelAI={() => {}}
                category={''}
                service={''}
                viewData={''}
                contactUser={false}
            />
        );
    });
});
