import edit from 'assets/images/editGrey.svg';
import validCount from 'assets/images/validCount.png';
import invalidCount from 'assets/images/invalidCount.png';
import { Calendar } from 'primereact/calendar';
import { calendarStyles } from 'shared/dataTable/constant/dataTable.styles';
import { t } from 'i18next';
import {
    editActionsIcons,
    renderLabel
} from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import {
    formatDate,
    formatDateWithTime,
    isAdminUser,
    isContactUser,
    isProjectManagerUser,
    isStaffUser,
    isVendorUser
} from 'core/utils/utils';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import { CATEGORY_TYPE, IP_NONIP, MODE, SERVICE_TYPES, STATUS_MODE } from 'constants/app.constant';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { InputSwitch } from 'primereact/inputswitch';
import { inputSwitchPT } from 'constants/styles.constant';
import {
    IsShowUPDeadLines,
    IsShowValidationDeadLines
} from 'pages/ViewOrderAndQuote/utils/dateAndDeadLinesUtils';
import ConstructField from 'components/reuseComponents/constructField';

type PropType = {
    editInput: any;
    handleImageClick: any;
    handleChange: any;
    handleSaveAI: (value1: string, value2: string) => Promise<void> | void;
    handleCancelAI: (value1: string, value2: string) => void;
    category: string;
    service: string;
    viewData: any;
    contactUser?: boolean;
};

const DateAndDeadlinesPage = ({
    editInput,
    handleImageClick,
    handleChange,
    handleSaveAI,
    handleCancelAI,
    category,
    service,
    viewData
}: PropType) => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisAdminUser = isAdminUser(loggedInUserRoleId);
    const isThisProjectManagerUser = isProjectManagerUser(loggedInUserRoleId);
    const isThisContactUser = isContactUser(loggedInUserRoleId, true);
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisStaffExcludedFinance = isStaffUser(loggedInUserRoleId, true);
    const isThisVendorExcludedFinance = isVendorUser(loggedInUserRoleId, {
        excludeFinance: true
    });
    const isUpcOptOut = service === SERVICE_TYPES.upc_opt_out;

    function statusIcon(value: boolean) {
        return value ? (
            <img src={validCount} className="h-5 p-0 mx-3 my-1" />
        ) : (
            <img src={invalidCount} className="h-5 p-0 mx-3 my-1" />
        );
    }
    const getDateValue = (dateString: string | Date): Date | null => {
        return typeof dateString === 'string' ? new Date(dateString) : dateString;
    };

    const is30MonthDeadlineShow =
        category === CATEGORY_TYPE.patent_cooperation_treaty && service !== SERVICE_TYPES.annuities;

    const isQuote = viewData?.requestTypeId === MODE.CREATE_QUOTE;
    const isEP = category === CATEGORY_TYPE.european_patent;
    const isEPTranslationAndValidation =
        category === CATEGORY_TYPE.european_patent &&
        (service === SERVICE_TYPES.translation_only ||
            service === SERVICE_TYPES.translation_and_validation);
    const isEpRenewals =
        category === CATEGORY_TYPE.european_patent && service === SERVICE_TYPES.renewals;
    const PCTranslationAndFiling =
        category === CATEGORY_TYPE.paris_convention_treaty &&
        (service === SERVICE_TYPES.translation_only ||
            service === SERVICE_TYPES.translation_and_filing);
    const isPCFiling =
        category === CATEGORY_TYPE.paris_convention_treaty &&
        service === SERVICE_TYPES.translation_and_filing;
    const is713ClaimsCategory = service === SERVICE_TYPES.claims;

    const isRecordals = service === SERVICE_TYPES.recordal;
    const requestType = viewData?.requestType;
    const isNonIp = requestType === IP_NONIP.nonIp;
    const is713Claims = viewData?.headers?.isClaims71_3;
    const toBeProcessedStatus = viewData?.headers?.statusId === STATUS_MODE.TO_BE_PROCESSED;
    const isUP = viewData?.headers?.isUP;
    const status_completed = viewData?.headers?.statusId === STATUS_MODE.COMPLETED;
    const status_invoiced = viewData?.headers?.statusId === STATUS_MODE.INVOICED;
    // const kind: string | null = viewData?.existingPatentCounts?.kind || null;

    // helpers
    const isShowStatutoryDeadline =
        (isQuote &&
            isEP &&
            service !== SERVICE_TYPES.recordal &&
            service !== SERVICE_TYPES.renewals &&
            is713Claims) ||
        (!isQuote && is713Claims && !isUpcOptOut);
    const isUPDeadlineShow = IsShowUPDeadLines({
        isEP,
        isUP,
        is713Claims,
        isEPTranslationAndValidation,
        isNonIp,
        isQuote
    });
    const isShowValidationDeadLine = IsShowValidationDeadLines({
        isEP,
        is713Claims,
        isEPTranslationAndValidation,
        isQuote,
        isNonIp,
        isUP
    });
    const isFieldEditable = (field: string) => {
        let isEditable = false;

        switch (field) {
            case 'requestDeliveryDate':
            case 'quoteTargetDate':
            case 'monthDeadline':
            case 'requestedDeliveryDateForClaimsTranslation':
            case 'statutoryDeadlineDate':
            case 'validationDeadline':
            case 'upDeadLine':
            case 'fillingDeadLine':
            case 'internalDeliveryDate':
            case 'europeanFilingDate': {
                isEditable =
                    (isThisStaffExcludedFinance || isThisVendorExcludedFinance) &&
                    !status_completed &&
                    !status_invoiced;
                break;
            }
            default:
                break;
        }
        return isEditable;
    };
    const handleSaveWrapper = (fieldName: string) => {
        handleSaveAI(fieldName, 'DateAndDeadlines')?.catch((error) => console.error(error));
    };

    return (
        <div className="py-3 pb-3" data-testid="AddressInformation-Accordian">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-7 mt-2">
                {/* FIELD - Requested Deliver Date */}
                {((isQuote && !is713ClaimsCategory) || (!isQuote && !is713Claims)) && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.REQUESTED_DELIVERY_DATE'))}
                            {isFieldEditable('requestDeliveryDate') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('requestDeliveryDate')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('requestDeliveryDate');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.requestDeliveryDate?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
            input-bordered h-8 border-[0.02rem] focus-within:outline-none 
            border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.requestDeliveryDate?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('requestDeliveryDate', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'requestDeliveryDate',
                                        'DateAndDeadlines',
                                        editInput?.requestDeliveryDate?.isError as boolean
                                    )}
                                </div>
                                {editInput?.requestDeliveryDate?.isError && (
                                    <ErrorLabel
                                        message={t(
                                            'DATE_AND_DEADLINES.ERROR_REQUESTED_DELIVERY_DATE'
                                        )}
                                    />
                                )}
                            </div>
                        ) : (
                            <div className="break-words font-medium">
                                {formatDate(
                                    editInput?.requestDeliveryDate?.value
                                        ? (editInput?.requestDeliveryDate?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Quote Required */}
                <div className="flex flex-col gap-1">
                    {renderLabel(t('DATE_AND_DEADLINES.QUOTE_REQUIRED'))}
                    <div className="flex">
                        <div className="flex items-center inputSwitchStyle">
                            <InputSwitch
                                checked={editInput?.quoteRequired?.value ?? false}
                                disabled={true}
                                pt={inputSwitchPT}
                            />
                        </div>

                        {editInput?.quoteRequired?.value
                            ? statusIcon(editInput?.quoteRequired?.value as boolean)
                            : null}
                    </div>
                </div>
                {/* {/* FIELD - Quote Target Date */}
                {(isThisStaffUser || isThisVendorUser) && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.QUOTE_TARGET_DATE'))}
                            {isFieldEditable('quoteTargetDate') && (
                                <img
                                    src={edit}
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('quoteTargetDate')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('quoteTargetDate');
                                        }
                                    }}
                                    tabIndex={0}
                                    className="h-3 p-0 mx-3 my-1 color-neutral-700 cursor-pointer"
                                />
                            )}
                        </div>
                        {editInput?.quoteTargetDate?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        className={`calender-input input px-2 rounded
                                            input-bordered h-8 border-[0.02rem] focus-within:outline-none
                                            border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.quoteTargetDate?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('quoteTargetDate', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: ''
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none font-medium text-black'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'quoteTargetDate',
                                        'DateAndDeadlines',
                                        editInput?.quoteTargetDate?.value?.isError as boolean
                                    )}
                                </div>
                                {editInput?.quoteTargetDate?.isError && (
                                    <ErrorLabel
                                        message={t('DATE_AND_DEADLINES.ERROR_QUOTE_TARGET_DATE')}
                                    />
                                )}
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.quoteTargetDate?.value
                                        ? (editInput?.quoteTargetDate?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Created At */}
                <div>
                    {renderLabel(t('DATE_AND_DEADLINES.CREATED_AT'))}
                    <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                        {formatDate(
                            editInput?.createdAt?.value
                                ? (editInput?.createdAt?.value as string)
                                : ''
                        )}
                    </div>
                </div>
                {/* FIELD - Completed At */}
                <div>
                    {renderLabel(t('DATE_AND_DEADLINES.COMPLETED_AT'))}
                    <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                        {editInput?.completedAt?.value
                            ? formatDateWithTime(
                                  editInput?.completedAt?.value
                                      ? (editInput?.completedAt?.value as string)
                                      : ''
                              ) + ' (UTC)'
                            : '-'}
                    </div>
                </div>
                {/* FIELD - 30-Month Deadline */}
                {is30MonthDeadlineShow && !isNonIp && !isRecordals && !isUpcOptOut && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.MONTH_DEADLINE'))}
                            {isFieldEditable('monthDeadline') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('monthDeadline')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('monthDeadline');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.monthDeadline?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
        input-bordered h-8 border-[0.02rem] focus-within:outline-none 
        border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.monthDeadline?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) => handleChange('monthDeadline', e.value)}
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'monthDeadline',
                                        'DateAndDeadlines',
                                        editInput?.monthDeadline?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.monthDeadline?.value
                                        ? (editInput?.monthDeadline?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Requested delivery date for claims translation */}
                {isEP &&
                    !(service === SERVICE_TYPES.recordal || service === SERVICE_TYPES.renewals) &&
                    is713Claims &&
                    !isUpcOptOut && (
                        <div>
                            <div className="flex">
                                {renderLabel(
                                    t('DATE_AND_DEADLINES.REQUESTED_DELIVERY_DATE_FOR_CLAIMS')
                                )}
                                {isFieldEditable('requestedDeliveryDateForClaimsTranslation') && (
                                    <img
                                        src={edit}
                                        alt="edit-grey-icon"
                                        onClick={() =>
                                            handleImageClick(
                                                'requestedDeliveryDateForClaimsTranslation'
                                            )
                                        }
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' || e.key === ' ') {
                                                handleImageClick(
                                                    'requestedDeliveryDateForClaimsTranslation'
                                                );
                                            }
                                        }}
                                        tabIndex={0}
                                        className="h-3 p-0 mx-3 my-1 color-neutral-700 cursor-pointer"
                                    />
                                )}
                            </div>
                            {editInput?.requestedDeliveryDateForClaimsTranslation?.isEdit ? (
                                <div className="flex flex-col items-start">
                                    <div className="flex">
                                        <label
                                            className={`calender-input input px-2 rounded 
                                            input-bordered h-8 border-[0.02rem] focus-within:outline-none 
                                            border-neutral-100  flex items-center gap-2 w-48`}>
                                            <i className="pi pi-calendar text-xs"></i>
                                            <Calendar
                                                value={getDateValue(
                                                    editInput
                                                        ?.requestedDeliveryDateForClaimsTranslation
                                                        ?.newValue as Date
                                                )} // Ensure value is a Date object
                                                onSelect={(e) =>
                                                    handleChange(
                                                        'requestedDeliveryDateForClaimsTranslation',
                                                        e.value
                                                    )
                                                }
                                                dateFormat="M dd, yy"
                                                placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                                showButtonBar={false}
                                                style={{ fontSize: '1rem' }}
                                                pt={{
                                                    ...calendarStyles,
                                                    root: {
                                                        className: ''
                                                    },
                                                    input: {
                                                        root: {
                                                            className:
                                                                'p-0 border-0 focus:border-0 focus:shadow-none font-medium text-black'
                                                        }
                                                    }
                                                }}
                                            />
                                        </label>
                                        {editActionsIcons(
                                            handleSaveAI,
                                            handleCancelAI,
                                            'requestedDeliveryDateForClaimsTranslation',
                                            'DateAndDeadlines',
                                            editInput?.requestedDeliveryDateForClaimsTranslation
                                                ?.value?.isError as boolean
                                        )}
                                    </div>
                                    {editInput?.requestedDeliveryDateForClaimsTranslation
                                        ?.isError && (
                                        <ErrorLabel
                                            message={t(
                                                'DATE_AND_DEADLINES.ERROR_REQUESTED_DELIVERY_DATE_FOR_CLAIMS'
                                            )}
                                        />
                                    )}
                                </div>
                            ) : (
                                <div
                                    className="break-words font-medium"
                                    style={{ fontSize: '1rem' }}>
                                    {formatDate(
                                        editInput?.requestedDeliveryDateForClaimsTranslation?.value
                                            ? (editInput?.requestedDeliveryDateForClaimsTranslation
                                                  ?.value as string)
                                            : ''
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                {/* FIELD - Statutory Deadline for claims translation */}
                {isShowStatutoryDeadline && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.STATUTORY_DEADLINE_FOR_CLAIMS'))}
                            {isFieldEditable('statutoryDeadlineDate') && (
                                <img
                                    src={edit}
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('statutoryDeadlineDate')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('statutoryDeadlineDate');
                                        }
                                    }}
                                    tabIndex={0}
                                    className="h-3 p-0 mx-3 my-1 color-neutral-700 cursor-pointer"
                                />
                            )}
                        </div>
                        {editInput?.statutoryDeadlineDate?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        className={`calender-input input px-2 rounded 
                                            input-bordered h-8 border-[0.02rem] focus-within:outline-none 
                                            border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.statutoryDeadlineDate?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('statutoryDeadlineDate', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: ''
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none font-medium text-black'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'statutoryDeadlineDate',
                                        'DateAndDeadlines',
                                        editInput?.statutoryDeadlineDate?.value?.isError as boolean
                                    )}
                                </div>
                                {editInput?.statutoryDeadlineDate?.isError && (
                                    <ErrorLabel
                                        message={t(
                                            'DATE_AND_DEADLINES.ERROR_STATUTORY_DEADLINE_FOR_CLAIMS'
                                        )}
                                    />
                                )}
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.statutoryDeadlineDate?.value
                                        ? (editInput?.statutoryDeadlineDate?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD-LABEL - Validation Deadline & UP Deadline */}
                {isEP &&
                    !isEPTranslationAndValidation &&
                    !is713Claims &&
                    !toBeProcessedStatus &&
                    !isNonIp &&
                    !isEpRenewals &&
                    !isRecordals &&
                    !isUpcOptOut && (
                        <>
                            <div>
                                {renderLabel(t('DATE_AND_DEADLINES.VALIDATION_DEADLINE'))}
                                <div
                                    className="break-words font-medium"
                                    style={{ fontSize: '1rem' }}>
                                    {formatDate(
                                        editInput?.validationDeadline?.value
                                            ? (editInput?.validationDeadline?.value as string)
                                            : ''
                                    )}
                                </div>
                            </div>
                            <div>
                                {renderLabel(t('DATE_AND_DEADLINES.UP_DEADLINE'))}
                                <div
                                    className="break-words font-medium"
                                    style={{ fontSize: '1rem' }}>
                                    {formatDate(
                                        editInput?.upDeadLine?.value
                                            ? (editInput?.upDeadLine?.value as string)
                                            : ''
                                    )}
                                </div>
                            </div>
                        </>
                    )}
                {/* FIELD - UP Deadline */}
                {isUPDeadlineShow && !isUpcOptOut && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.UP_DEADLINE'))}
                            {isFieldEditable('upDeadLine') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('upDeadLine')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('upDeadLine');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.upDeadLine?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
        input-bordered h-8 border-[0.02rem] focus-within:outline-none 
        border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.upDeadLine?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) => handleChange('upDeadLine', e.value)}
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'upDeadLine',
                                        'DateAndDeadlines',
                                        editInput?.upDeadLine?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.upDeadLine?.value
                                        ? (editInput?.upDeadLine?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Validation Deadline */}
                {isShowValidationDeadLine && !isUpcOptOut && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.VALIDATION_DEADLINE'))}
                            {isFieldEditable('validationDeadline') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('validationDeadline')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('validationDeadline');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.validationDeadline?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
            input-bordered h-8 border-[0.02rem] focus-within:outline-none 
            border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.validationDeadline?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('validationDeadline', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'validationDeadline',
                                        'DateAndDeadlines',
                                        editInput?.validationDeadline?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.validationDeadline?.value
                                        ? (editInput?.validationDeadline?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - European Filing Deadline */}
                {isEpRenewals && !isNonIp && !isUpcOptOut && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.EUROPEAN_FILING_DEADLINE'))}
                            {isFieldEditable('europeanFilingDate') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('europeanFilingDate')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('europeanFilingDate');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.europeanFilingDate?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
        input-bordered h-8 border-[0.02rem] focus-within:outline-none 
        border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.europeanFilingDate?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('europeanFilingDate', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'europeanFilingDate',
                                        'DateAndDeadlines',
                                        editInput?.europeanFilingDate?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.europeanFilingDate?.value
                                        ? (editInput?.europeanFilingDate?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Filing Deadline */}
                {PCTranslationAndFiling && !isNonIp && !isUpcOptOut && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.FILING_DEADLINE'))}
                            {isFieldEditable('fillingDeadLine') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('fillingDeadLine')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('fillingDeadLine');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.fillingDeadLine?.isEdit ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
        input-bordered h-8 border-[0.02rem] focus-within:outline-none 
        border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.fillingDeadLine?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('fillingDeadLine', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'fillingDeadLine',
                                        'DateAndDeadlines',
                                        editInput?.fillingDeadLine?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.fillingDeadLine?.value
                                        ? (editInput?.fillingDeadLine?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
                {/* FIELD - Requested Filing Deadline */}
                {isPCFiling && !isUpcOptOut && (
                    <div>
                        {renderLabel(t('DATE_AND_DEADLINES.REQUESTED_FILING_DEADLINE'))}
                        <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                            {formatDate(
                                editInput?.requestedFillingDeadLine?.value
                                    ? (editInput?.requestedFillingDeadLine?.value as string)
                                    : ''
                            )}
                        </div>
                    </div>
                )}
                {/* FIELD - Turnaround Time */}
                {isNonIp && !isUpcOptOut && (
                    <ConstructField
                        data={{
                            isFieldHasEditability:
                                (isThisStaffUser || isThisVendorUser) &&
                                !status_invoiced &&
                                !status_completed,
                            isFieldInEditMode: editInput?.turnAroundTime?.isEdit,
                            fieldType: 'input',
                            inputType: { type: 'text' },
                            fieldValue: editInput?.turnAroundTime?.value,
                            state: editInput?.turnAroundTime?.newValue,
                            fieldLabelName: t('ADDITIONAL_INFO.TURNAROUND_TIME'),
                            placeholder: 'Turnaround Time',
                            actions: {
                                edit: () => handleImageClick('turnAroundTime'),
                                update: () => handleSaveWrapper('turnAroundTime'),
                                cancel: () => handleCancelAI('turnAroundTime', 'DateAndDeadlines'),
                                onChange: (value: any) =>
                                    handleChange('turnAroundTime', (value ?? null) as string)
                            },
                            customClass: { fieldValueLabel: 'font-medium' }
                        }}
                    />
                )}

                {/* FIELD - Internal Delivery Date */}
                {!isThisContactUser && (
                    <div>
                        <div className="flex">
                            {renderLabel(t('DATE_AND_DEADLINES.INTERNAL_DELIVERY_DATE'))}
                            {isFieldEditable('internalDeliveryDate') && (
                                <img
                                    src={edit}
                                    className="h-3 p-0 mx-3 my-1 cursor-pointer"
                                    alt="edit-grey-icon"
                                    onClick={() => handleImageClick('internalDeliveryDate')}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            handleImageClick('internalDeliveryDate');
                                        }
                                    }}
                                    tabIndex={0}
                                />
                            )}
                        </div>
                        {editInput?.internalDeliveryDate?.isEdit &&
                        (isThisAdminUser || isThisProjectManagerUser) ? (
                            <div className="flex flex-col items-start">
                                <div className="flex">
                                    <label
                                        style={{ fontSize: 10 }}
                                        className={`calender-input input px-2 rounded 
        input-bordered h-8 border-[0.02rem] focus-within:outline-none 
        border-neutral-100  flex items-center gap-2 w-48`}>
                                        <i className="pi pi-calendar text-xs"></i>
                                        <Calendar
                                            value={getDateValue(
                                                editInput?.internalDeliveryDate?.newValue as Date
                                            )} // Ensure value is a Date object
                                            onSelect={(e) =>
                                                handleChange('internalDeliveryDate', e.value)
                                            }
                                            dateFormat="M dd, yy"
                                            placeholder={t('COMMON.SELECT_DATE_PLACEHOLDER')}
                                            showButtonBar={false}
                                            style={{ fontSize: '1rem' }}
                                            pt={{
                                                ...calendarStyles,
                                                root: {
                                                    className: 'w-[75px]'
                                                },
                                                input: {
                                                    root: {
                                                        className:
                                                            'p-0 border-0 focus:border-0 focus:shadow-none'
                                                    }
                                                }
                                            }}
                                        />
                                    </label>
                                    {editActionsIcons(
                                        handleSaveAI,
                                        handleCancelAI,
                                        'internalDeliveryDate',
                                        'DateAndDeadlines',
                                        editInput?.internalDeliveryDate?.isError as boolean
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="break-words font-medium" style={{ fontSize: '1rem' }}>
                                {formatDate(
                                    editInput?.internalDeliveryDate?.value
                                        ? (editInput?.internalDeliveryDate?.value as string)
                                        : ''
                                )}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default DateAndDeadlinesPage;
