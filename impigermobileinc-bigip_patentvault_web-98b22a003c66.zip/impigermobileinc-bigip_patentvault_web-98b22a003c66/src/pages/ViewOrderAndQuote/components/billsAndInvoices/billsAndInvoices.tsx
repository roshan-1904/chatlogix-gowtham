import { TabView, TabPanel } from 'primereact/tabview';
import { useEffect, useState } from 'react';
import { previewDialogPopup, tabPanelPT } from 'constants/styles.constant';
import BillsTasks from './billsTasks/billsTasks';
import InvoiceTasks from './invoiceTasks/invoiceTasks';
import Summary from './summary/summary';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { renderCreateTask } from 'pages/taskManagement/tasksList/components/taskFilters/taskFilters';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
    IP_NONIP,
    MODE,
    SERVICE_TYPES,
    STATUS_MODE,
    STD_PREVIEW_TEMPLATE
} from 'constants/app.constant';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import { Dialog } from 'primereact/dialog';
import utils, {
    getWindowSize,
    isContactUser,
    isFinanceUser,
    isStaffUser,
    isVendorUser
} from 'core/utils/utils';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import { Permissions } from 'constants/permissions';
import taskStepperStore from 'core/store/stepperStore/createTaskStore/createTask.store';
import viewOrderQuoteServices, {
    getPDFData
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import CustomPreviewTemplate from './customPreviewTemplate';
import { BillTask } from './billsTasks/types/billsTasks.type';
import InstructionPopup from 'pages/createOrderAndQuote/components/summary/components/instructionPopup';
import PrimeButton from 'components/buttons/primeButton';
import { PrimeDialogBox, PrimeDialogModal } from 'components/dialog/primeDialogBox';
import { TaskListToReorderModel } from 'pages/ViewOrderAndQuote/types/standardViewDetailsTypes';
import { Divider } from 'primereact/divider';
import PrimeReorder from 'components/reorderList/primeReorder';

export const dropdownOptionStyles = `cursor-pointer font-normal overflow-hidden
relative whitespace-nowrap m-0 p-3 border-0 transition-shadow duration-200 
rounded-none text-gray-700 hover:text-gray-700  hover:bg-primary-50 py-3 w-fit
flex items-center hover:bg-transparent`;

const BILLS_INVOICE_TABS = {
    INVOICE: 0,
    BILLS: 1,
    SUMMARY: 2
};
export interface AddInstructionData {
    orderId: number | null;
    taskId: number[];
    instructions: string | null;
}
interface TaskSelectionModel {
    selectedTasks: BillTask[];
    restrictedRowsToSelect: BillTask[];
    isAllTasksSelected: boolean;
}
interface PopupConfig {
    header: JSX.Element | string;
    title: string;
    primaryButtonLabel: string;
    secondaryButtonLabel: string;
}

const BillsAndInvoices = ({
    viewData,
    getOrderDetailsAPI,
    rebuildOrderStatusList,
    patentCountResponse,
    countryEditResponse,
    previewTypeModified,
    isSTDFlow = false,
    triggerGetInvoiceList
}: {
    viewData: any;
    getOrderDetailsAPI: () => Promise<void>;
    rebuildOrderStatusList?: () => void;
    patentCountResponse: any;
    countryEditResponse: any;
    previewTypeModified?: any;
    isSTDFlow?: boolean;
    triggerGetInvoiceList?: () => void;
}) => {
    const navigate = useNavigate();
    const { requestId = '' } = useParams();
    const { t } = useTranslation();

    const popupConfigInit: PopupConfig = {
        header: '',
        title: '',
        primaryButtonLabel: 'Add',
        secondaryButtonLabel: 'Close'
    };
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);
    const [taskListToReorder, setTaskListToReorder] = useState<{
        updatedList: TaskListToReorderModel[];
        responseList: TaskListToReorderModel[];
    }>({ updatedList: [], responseList: [] });

    // Check for user permissions
    const hasBillTaskPermission = AuthStore.hasPermission(Permissions.VIEW_BILL_TASK);
    const hasInvoiceTaskPermission = AuthStore.hasPermission(Permissions.VIEW_INVOICE_TASK);
    const [activeIndex, setActiveIndex] = useState(hasInvoiceTaskPermission ? 0 : 1);
    const [showDropdown, setShowDropdown] = useState(false);
    const [instruction, setInstruction] = useState<{ content: string; isError: boolean }>({
        content: '',
        isError: false
    });
    const [taskSelection, setTaskSelection] = useState<TaskSelectionModel>({
        selectedTasks: [],
        restrictedRowsToSelect: [],
        isAllTasksSelected: false
    });
    const isUPCOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;

    const tabViewStyle = {
        nav: {
            className: 'gap-4 border-0'
        }
    };
    const [visible, setVisible] = useState<boolean>(false);
    const [pdfUrl, setPdfUrl] = useState<string>('');
    const showToastMessage = (message: notificationModel) => {
        NotificationStore.showAlert(message);
    };
    const [documentType, setDocumentType] = useState(viewData?.stdPreviewType);
    const requestType = viewData?.requestType;
    const isNonIP = requestType === IP_NONIP.nonIp;

    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisStaffUserExcludedFinance = isStaffUser(loggedInUserRoleId, true);
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isThisFinanceUser = isFinanceUser(loggedInUserRoleId);
    const orderId: number | null = viewData?.headers?.requestId || null;
    const requestNumber: string | null = viewData?.headers?.requestNumber || null;
    const statusId = viewData?.headers?.statusId;
    const statusName = viewData?.headers?.statusName;
    const isWaitingForApproval = statusId === STATUS_MODE.WAITING_FOR_APPROVAL;
    const isPreparingQuote = statusId === STATUS_MODE.PREPARING_QUOTE;
    const isQuote = viewData?.requestTypeId === MODE.CREATE_QUOTE;
    const isDirectOrder = viewData?.headers?.isQuote === false;

    // api
    const getTaskDetailsToReorder = async (): Promise<boolean> => {
        try {
            const res = await viewOrderQuoteServices.getTaskDetailsToReorder<
                TaskListToReorderModel[]
            >(orderId as number);
            if (res) {
                const updatedListWithSeqNumber = res.map((item, index) => ({
                    ...item,
                    sequenceNumber: index + 1
                }));
                setTaskListToReorder({
                    updatedList: updatedListWithSeqNumber,
                    responseList: updatedListWithSeqNumber
                });
                return true;
            } else return false;
        } catch (error) {
            console.error('Error in getTaskDetailsToReorder(): ', error);
            return false;
        }
    };
    const saveTaskDetailsToReorder = () => {
        try {
            const payload = {
                orderId: orderId ?? 0,
                reOrderViewModel: taskListToReorder.updatedList
            };

            viewOrderQuoteServices.saveTaskDetailsToReorder(payload).then((result) => {
                if (result) {
                    showToastMessage({
                        message: 'Task order updated successfully.',
                        type: ToastType.SUCCESS
                    });
                    setPrimeDialog({ ...primeDialog, isShowDialog: false });
                }
            });
        } catch (error) {
            console.error('Error in saveTaskDetailsToReorder(): ', error);
        }
    };

    // functions
    const downloadPDF = async (templateName: string, requestNo: number) => {
        try {
            const response = await getPDFData(templateName, requestNo);
            setPdfUrl(response);
            if (response) {
                setVisible(true);
            }
        } catch (error) {
            showToastMessage({
                message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
                type: ToastType.ERROR
            });
            console.error('Error in DownloadPDF(): ', error);
            return null;
        }
    };
    const getTabPanelPT = (index: number) => {
        return tabPanelPT(activeIndex === index, () => setActiveIndex(index));
    };
    const isShowCreateTaskButton = (): boolean => {
        const isShow =
            ((!isWaitingForApproval && !isPreparingQuote && !isUPCOptOut) || isSTDFlow) &&
            AuthStore.hasPermission(Permissions.CREATE_BILL_TASK) &&
            AuthStore.hasPermission(Permissions.CREATE_INVOICE_TASK);

        return isShow;
    };
    const pdfType = async () => {
        const res = await viewOrderQuoteServices.standardPreview(
            orderId as number,
            documentType === STD_PREVIEW_TEMPLATE.BIGIP_Quote.name
                ? STD_PREVIEW_TEMPLATE.BIGIP_Quote.id
                : STD_PREVIEW_TEMPLATE.BIGIP_Quote_SalesOrder_NoRate_Qty.id
        );
        if (res) {
            previewTypeModified(res);
            setShowDropdown(false);
            showToastMessage({
                message: t('QUOTE_AND_ORDER.PREVIEW_TYPE_UPDATED'),
                type: ToastType.SUCCESS
            });
        }
    };
    const previewTemplateData = {
        orderId,
        documentList: [
            {
                previewTypeId: 'BIGIP_Quote',
                previewTypeName: t('PDF_TYPES_INVOICE.QUOTE')
            },
            {
                previewTypeId: 'BIGIP_Quote_SalesOrder_NoRate_Qty',
                previewTypeName: t('PDF_TYPES_INVOICE.NO_RATE_QUANTITY')
            }
        ],
        currentDocumentType: documentType,
        updateCurrentDocumentType: setDocumentType,
        download: downloadPDF,
        saveSelection: pdfType,
        visibility: { isShowPreviewIcon: true, isShowSaveButton: true }
    };

    // task selection handlers
    const handlerCreateTaskOnClick = () => {
        /** if we initiated the 'Create-Task' from the 'Bills & Invoice' page,
         *  then we should navigate to the same page once after task is created.
         *  to identify that, we have this 'isTaskCreationFromBillsInvoicePage' flag in store. */
        const updatedUserFormData = {
            ...taskStepperStore.getData().formData,
            isTaskCreationFromBillsInvoicePage: true
        };
        if (Object.keys(updatedUserFormData).length) {
            taskStepperStore.updatePage('formData', updatedUserFormData);
        }

        return renderCreateTask(
            navigate,
            t,
            requestId,
            statusName === RequestStatusEnum?.COMPLETED,
            orderId,
            requestNumber,
            isSTDFlow
        );
    };
    const handleSelectedTasks = (selectedList: BillTask[], taskList: BillTask[]) => {
        const selectableTaskList = taskList?.filter(
            (task) =>
                !taskSelection?.restrictedRowsToSelect?.some(
                    (restrictedTask) => restrictedTask.taskId === task.taskId
                )
        );

        // to keep update Select-All checkbox
        const isAllTasksSelected: boolean = selectedList.length === selectableTaskList.length;

        const updatedTaskSelection = {
            ...taskSelection,
            isAllTasksSelected,
            selectedTasks: selectedList
        };

        setTaskSelection(updatedTaskSelection);
    };
    const handleSelectAllTasks = (isSelected: boolean, taskList: BillTask[]) => {
        const updatedTaskSelection = { ...taskSelection, isAllTasksSelected: isSelected };
        const selectableTaskList = taskList?.filter(
            (task) =>
                !taskSelection?.restrictedRowsToSelect?.some(
                    (restrictedTask) => restrictedTask.taskId === task.taskId
                )
        );
        updatedTaskSelection.selectedTasks = isSelected ? [...selectableTaskList] : [];

        setTaskSelection(updatedTaskSelection);
    };
    const updateInstruction = (value: string) => {
        const updatedInstruction = {
            ...instruction,
            content: value,
            isError: instruction.content.trim() === ''
        };
        setInstruction(updatedInstruction);
    };
    const triggerAddInstructionPopup = () => {
        setPopupConfig({
            header: 'Add Instructions..',
            title: 'Add Instructions',
            primaryButtonLabel: t('COMMON.ADD'),
            secondaryButtonLabel: t('COMMON.CLOSE')
        });
        popupOpenClose('BillsInvoiceInstructionPopup', true);
    };
    const updateRestrictedRowsToSelect = (list: BillTask[]) => {
        setTaskSelection({ ...taskSelection, restrictedRowsToSelect: [...(list ?? [])] });
    };
    const handlerInstructionSubmitWrapper = () => {
        handlerInstructionSubmit();
    };
    const handlerInstructionSubmit = async () => {
        try {
            const selectedTaskIds: number[] = taskSelection.selectedTasks.map(
                (task) => task.taskId
            );

            const payload: AddInstructionData = {
                orderId,
                taskId: selectedTaskIds,
                instructions: instruction.content
            };
            const result = await viewOrderQuoteServices.updateVendorInstructions(payload);
            if (result) {
                setTaskSelection({
                    ...taskSelection,
                    selectedTasks: [],
                    isAllTasksSelected: false
                });
                popupOpenClose('BillsInvoiceInstructionPopup', false);
                showToastMessage({
                    message: t('TASKS.SUCCESS_MSG.INSTRUCTION_ASSIGNED_SUCCESS'),
                    type: ToastType.SUCCESS
                });
            }
        } catch (error: any) {
            popupOpenClose('BillsInvoiceInstructionPopup', false);
            console.error('Error in handlerInstructionSubmit(): ', error);
            showToastMessage({
                message: error?.message ?? t('TASKS.ERROR_MSG.INSTRUCTION_ASSIGNED_ERROR'),
                type: ToastType.ERROR
            });
        }
    };
    const popupOpenClose = (popupId: string, isShow: boolean = false) => {
        const modal = document.getElementById(popupId) as HTMLDialogElement | null;
        if (modal) {
            if (isShow) {
                setInstruction({ ...instruction, isError: false });
                modal.showModal();
            } else {
                // clear local state to avoid keep old data
                setInstruction({ content: '', isError: false });
                setPopupConfig({ ...popupConfigInit });
                modal.close();
            }
        }
    };

    // reorder
    const [isHovered, setIsHovered] = useState<string | null>(null);
    const handleReorderTask = () => {
        getTaskDetailsToReorder().then(
            (result: boolean) => result && setPrimeDialog({ ...primeDialog, isShowDialog: true })
        );
    };
    const reorderItemTemplate = (item: TaskListToReorderModel) => {
        return (
            <span
                onMouseEnter={() => setIsHovered(item.taskName)}
                onMouseLeave={() => setIsHovered(null)}>
                <div className="flex align-items-center gap-3 font-semibold py-3 px-5">
                    <i
                        className={`pi ${isHovered === item.taskName ? 'pi-arrows-alt' : 'pi-bars'} text-xl`}
                    />
                    <div className="flex px-3">
                        <div className="min-w-16 flex justify-center">{item.sequenceNumber}</div>
                        <Divider
                            layout={'vertical'}
                            pt={{
                                root: { className: 'py-0 !mx-4' }
                            }}
                        />
                        <div className="max-w-80 truncate">{item.taskName}</div>
                    </div>
                </div>
            </span>
        );
    };
    const getReorderBody = () => {
        return (
            <PrimeReorder<TaskListToReorderModel>
                reorderList={taskListToReorder.updatedList}
                itemTemplate={(item: TaskListToReorderModel) => reorderItemTemplate(item)}
                onChange={(list: TaskListToReorderModel[]) => {
                    const modifiedListWithSeqNumber = list.map((item, index) => ({
                        ...item,
                        sequenceNumber: index + 1
                    }));
                    setTaskListToReorder({
                        ...taskListToReorder,
                        updatedList: modifiedListWithSeqNumber
                    });
                }}
            />
        );
    };
    const dialogReorderTaskData: PrimeDialogModal = {
        isShowDialog: false,
        header: 'Reorder Task',
        body: getReorderBody(),
        buttonName: { primary: 'Save', secondary: 'Cancel' },
        actions: {
            onClose: () => setPrimeDialog({ ...primeDialog, isShowDialog: false }), // cross button at top
            onDialogClear: () => setPrimeDialog({ ...primeDialog, isShowDialog: false }), // close
            onDialogSubmit: () => saveTaskDetailsToReorder() // save
        },
        customClass: { dialogWidth: '35vw' }
    };
    const [primeDialog, setPrimeDialog] = useState<PrimeDialogModal>(dialogReorderTaskData);

    // side effects
    useEffect(() => {
        if (viewData?.headers?.stdPreviewType) {
            setDocumentType(viewData.headers.stdPreviewType);
        }
    }, [viewData]);

    useEffect(() => {
        primeDialog.isShowDialog &&
            setPrimeDialog({ ...dialogReorderTaskData, isShowDialog: true });
    }, [taskListToReorder.updatedList, isHovered]);

    return (
        <div className="pt-5">
            <PrimeDialogBox
                isShowDialog={primeDialog.isShowDialog}
                header={primeDialog.header}
                body={primeDialog.body}
                buttonName={primeDialog.buttonName}
                actions={primeDialog.actions}
                customClass={primeDialog.customClass}
            />
            {isNonIP &&
                isQuote &&
                activeIndex === BILLS_INVOICE_TABS.INVOICE &&
                (isThisStaffUser || isThisVendorUser) && (
                    <>
                        <div className="absolute right-14 top-2 z-10">
                            <button
                                className="btn button-primary-outline min-h-[2.43rem] h-[2.43rem] !font-medium"
                                data-testid="preview-button"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    setShowDropdown(!showDropdown);
                                }}>
                                {t('COMMON.PREVIEW')}
                                <div className="flex justify-end shrink-0 bg-transparent text-gray-600 dark:text-white/70 rounded-tr-lg rounded-br-lg px-1 w-8">
                                    <svg
                                        width="14"
                                        height="20"
                                        viewBox="0 0 14 14"
                                        fill="none"
                                        xmlns="http://www.w3.org/2000/svg"
                                        className="p-icon"
                                        aria-hidden="true">
                                        <path
                                            d="M7.01744 10.398C6.91269 10.3985 6.8089 10.378 6.71215 10.3379C6.61541 10.2977 6.52766 10.2386 6.45405 10.1641L1.13907 4.84913C1.03306 4.69404 0.985221 4.5065 1.00399 4.31958C1.02276 4.13266 1.10693 3.95838 1.24166 3.82747C1.37639 3.69655 1.55301 3.61742 1.74039 3.60402C1.92777 3.59062 2.11386 3.64382 2.26584 3.75424L7.01744 8.47394L11.769 3.75424C11.9189 3.65709 12.097 3.61306 12.2748 3.62921C12.4527 3.64535 12.6199 3.72073 12.7498 3.84328C12.8797 3.96582 12.9647 4.12842 12.9912 4.30502C13.0177 4.48162 12.9841 4.662 12.8958 4.81724L7.58083 10.1322C7.50996 10.2125 7.42344 10.2775 7.32656 10.3232C7.22968 10.3689 7.12449 10.3944 7.01744 10.398Z"
                                            fill="#1d8ade"></path>
                                    </svg>
                                </div>
                            </button>
                        </div>
                        <div className="absolute right-14 top-12 z-10 flex flex-col items-start justify-end ">
                            {showDropdown && (
                                <CustomPreviewTemplate templateData={previewTemplateData} />
                            )}
                        </div>
                    </>
                )}
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {(viewData?.requestTypeId === MODE.CREATE_QUOTE
                            ? t('COMMON.QUOTE') + ' - '
                            : t('COMMON.ORDER') + ' - ') +
                            (viewData?.headers?.requestNumber ?? 'Preview')}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() =>
                                utils.handleDownloadPngSvg(
                                    pdfUrl,
                                    (viewData?.requestTypeId === MODE.CREATE_QUOTE
                                        ? t('COMMON.QUOTE') + ' - '
                                        : t('COMMON.ORDER') + ' - ') +
                                        (viewData?.headers?.requestNumber ?? 'Preview')
                                )
                            }
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
            <div className="card z-0">
                <div className="card z-0">
                    {hasInvoiceTaskPermission && hasBillTaskPermission ? (
                        // Render TabView when both permissions are present
                        <TabView
                            pt={tabViewStyle}
                            activeIndex={activeIndex}
                            onTabChange={(e) => setActiveIndex(e.index)}>
                            {hasInvoiceTaskPermission && (
                                <TabPanel
                                    header={`${isThisContactUser ? t('COMMON.ITEMS') : t('ACCOUNTING.INVOICE_TASKS')}`}
                                    pt={getTabPanelPT(0)}>
                                    <div className="p-3">
                                        <InvoiceTasks
                                            {...{
                                                statusName,
                                                viewData,
                                                getOrderDetailsAPI,
                                                isNonIP,
                                                patentCountResponse,
                                                countryEditResponse,
                                                triggerGetInvoiceList
                                            }}
                                        />
                                    </div>
                                </TabPanel>
                            )}
                            {hasBillTaskPermission && (
                                <TabPanel header="Bill Tasks" pt={getTabPanelPT(1)}>
                                    <div className="p-3">
                                        <BillsTasks
                                            {...{
                                                statusName,
                                                getOrderDetailsAPI,
                                                patentCountResponse,
                                                countryEditResponse,
                                                isNonIP,
                                                rebuildOrderStatusList,
                                                taskSelection: {
                                                    selectedTasks: taskSelection.selectedTasks,
                                                    restrictedRowsToSelect:
                                                        taskSelection.restrictedRowsToSelect,
                                                    isAllTasksSelected:
                                                        taskSelection.isAllTasksSelected,
                                                    handleSelectedTasks,
                                                    handleSelectAllTasks,
                                                    updateRestrictedRowsToSelect
                                                }
                                            }}
                                        />
                                    </div>
                                </TabPanel>
                            )}
                            <TabPanel header="Summary" pt={getTabPanelPT(2)}>
                                <div className="p-3">
                                    <Summary {...{ statusName, getOrderDetailsAPI }} />
                                </div>
                            </TabPanel>
                        </TabView>
                    ) : (
                        // If only one permission is present, render the component directly without TabView
                        <>
                            {hasInvoiceTaskPermission && (
                                <InvoiceTasks
                                    {...{
                                        statusName,
                                        viewData,
                                        getOrderDetailsAPI,
                                        patentCountResponse,
                                        countryEditResponse,
                                        triggerGetInvoiceList
                                    }}
                                />
                            )}
                            {hasBillTaskPermission && (
                                <BillsTasks
                                    {...{
                                        statusName,
                                        getOrderDetailsAPI,
                                        patentCountResponse,
                                        countryEditResponse,
                                        rebuildOrderStatusList,
                                        taskSelection: {
                                            selectedTasks: taskSelection.selectedTasks,
                                            restrictedRowsToSelect:
                                                taskSelection.restrictedRowsToSelect,
                                            isAllTasksSelected: taskSelection.isAllTasksSelected,
                                            handleSelectedTasks,
                                            handleSelectAllTasks,
                                            updateRestrictedRowsToSelect
                                        }
                                    }}
                                />
                            )}
                        </>
                    )}
                </div>

                <div className="absolute right-[3px] top-[-2px] gap-2 flex items-center">
                    {!isThisFinanceUser &&
                        isSTDFlow &&
                        !isDirectOrder &&
                        activeIndex === BILLS_INVOICE_TABS.INVOICE && (
                            <PrimeButton
                                testid="reorder-button"
                                label={'Reorder Task'}
                                type="primary"
                                outlined={true}
                                className=""
                                disabled={false}
                                icon="pi pi-sort-alt-slash"
                                size="medium"
                                onClick={handleReorderTask}
                            />
                        )}
                    {activeIndex === BILLS_INVOICE_TABS.BILLS && isThisStaffUserExcludedFinance && (
                        <PrimeButton
                            testid="add-instruction-tasks-button"
                            label={t('TASKS.ADD_INSTRUCTIONS')}
                            type="primary"
                            outlined={false}
                            className=""
                            disabled={!taskSelection.selectedTasks?.length}
                            icon="pi pi-plus-circle"
                            size="medium"
                            onClick={() => triggerAddInstructionPopup()}
                        />
                    )}
                    {isShowCreateTaskButton() && handlerCreateTaskOnClick()}
                </div>
            </div>

            {/* Popup */}
            <InstructionPopup
                data-testid="BillsInvoiceInstructionPopup"
                id={'BillsInvoiceInstructionPopup'}
                title={popupConfig.title}
                onClose={() => popupOpenClose('BillsInvoiceInstructionPopup', false)}
                onClear={() => popupOpenClose('BillsInvoiceInstructionPopup', false)}
                onSubmit={() => handlerInstructionSubmitWrapper()}
                primaryButtonText={t('COMMON.ADD')}
                secondaryButtonText={t('COMMON.CLEAR')}
                isInstructionEmpty={instruction.content === ''} // if input is empty then disable the submit button
            >
                <div className="p-4 bg-neutral-300">
                    <textarea
                        data-testid={'SummaryInstructionPopupTextarea'}
                        className="max-h-14 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        id="summary-instruction-textarea"
                        placeholder={t('SUMMARY.POPUP.PLACEHOLDER')}
                        value={instruction.content ?? ''}
                        onChange={(e) => updateInstruction(e.target.value)}
                    />
                </div>
            </InstructionPopup>
        </div>
    );
};

export default BillsAndInvoices;
