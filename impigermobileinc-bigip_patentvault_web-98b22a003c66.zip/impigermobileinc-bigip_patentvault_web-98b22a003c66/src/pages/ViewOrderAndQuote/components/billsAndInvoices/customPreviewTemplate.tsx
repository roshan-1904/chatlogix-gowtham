import { RadioButton } from 'primereact/radiobutton';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { dropdownOptionStyles } from './billsAndInvoices';

interface TemplateDataType {
    orderId: number | null;
    documentList: { previewTypeId: string; previewTypeName: string }[] | null;
    currentDocumentType: string | null;
    updateCurrentDocumentType: (document: string) => void;
    download: (templateName: string, requestNo: number) => Promise<unknown>;
    visibility: { isShowPreviewIcon: boolean; isShowSaveButton: boolean };
    saveSelection?: () => Promise<void>;
}

const CustomPreviewTemplate: FC<{ templateData: TemplateDataType }> = ({ templateData }) => {
    const { t } = useTranslation();

    // handlers
    const handlePreviewSelection = (document: string) => {
        templateData.updateCurrentDocumentType(document);
    };
    const handleDownloadFile = (document: string) => {
        templateData.download(document, templateData.orderId ?? 0);
    };
    const handleSaveSelection = () => {
        templateData?.saveSelection?.();
    };

    return (
        <div
            className="z-100 bg-white shadow-lg top-[100%] left-0 w-auto"
            data-testid="preview-dropdown">
            <div className="py-3 px-7 flex border border-neutral-100/50 text-gray-400">
                <span className="text-lg font-medium">{'Documents'}</span>
            </div>
            <ul className="py-3 list-none m-0 font-medium">
                {templateData.documentList?.map((document, index) => (
                    <div key={index + 1} className="flex items-center">
                        <div
                            className={`${dropdownOptionStyles} gap-2`}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() => handlePreviewSelection(document?.previewTypeId)}>
                            <RadioButton
                                className="small-radio"
                                checked={
                                    templateData.currentDocumentType === document?.previewTypeId
                                }
                            />
                            <p>{t(document?.previewTypeName)}</p>
                        </div>
                        {templateData?.visibility.isShowPreviewIcon && (
                            <img
                                src="/images/svgs/i-viewEye-icon.svg"
                                alt="preview"
                                className="h-5 w-5 mr-3 cursor-pointer"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => {
                                    handleDownloadFile(document?.previewTypeId);
                                }}
                            />
                        )}
                    </div>
                ))}
            </ul>
            {templateData?.visibility.isShowSaveButton && (
                <div className="p-3 flex justify-end border border-neutral-100/50">
                    <button
                        onClick={handleSaveSelection}
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        className="btn button-primary font-medium rounded-md min-h-0 h-10">
                        <span className="font-medium">{t('COMMON.SAVE')}</span>
                    </button>
                </div>
            )}
        </div>
    );
};

export default CustomPreviewTemplate;
