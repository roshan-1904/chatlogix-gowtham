import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import { getTableData } from '../invoiceTasks/service/invoiceTasksService';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { useTranslation } from 'react-i18next';
import { taskTitleTemplate } from 'pages/taskManagement/tasksList/tasksList';
import { FilterMatchMode } from 'primereact/api';
import {
    GetSummaryListApiResponse,
    GrossMarginEligibleUpdateFields,
    SummaryDetails
} from './types/summary.type';
import upArrowIcon from 'assets/svgs/up-arrow.svg';
import downArrowIcon from 'assets/svgs/down-arrow.svg';
import { formatCurrency, isFinanceUser, showToastMessage } from 'core/utils/utils';
import { ColumnBodyOptions } from 'primereact/column';
import { Tooltip } from 'primereact/tooltip';
import { renderPercentageTemplate } from '../../header/header';

import { updateGrossMarginEligible } from '../summary/service/summaryTasksService';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';

interface SummaryProps {
    statusName: string;
    getOrderDetailsAPI: () => Promise<void>;
}

export const lowPercentageLogoTemplate = () => {
    return <img src={downArrowIcon} className="h-4 w-4 cursor-pointer" alt="down-arrow-icon" />;
};

export const upPercentageLogoTemplate = () => {
    return <img src={upArrowIcon} className="h-4 w-4 cursor-pointer" alt="down-arrow-icon" />;
};

const Summary: React.FC<SummaryProps> = ({ statusName, getOrderDetailsAPI }) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const { requestId } = useParams();
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });

    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisFinanceUser = isFinanceUser(loggedInUserRoleId);

    const [tableData, setTableData] = useState<GetSummaryListApiResponse>();
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [emptyMessage, setEmptyMessage] = useState<string>(' ');
    const NO_SUMMARY_FOUND = t('QUOTE_AND_ORDER.NO_SUMMARY_FOUND');

    const hasEditGlossMarginPermission: boolean =
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE);

    const handlePopConfirmConfirm = () => {};

    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        acceptLabel: '',
        rejectLabel: '',
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });

    const handleConfirmationCancel = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };

    const getSummaryList = async (body: RequestBody) => {
        try {
            const response: GetSummaryListApiResponse =
                await getTableData<GetSummaryListApiResponse>(body, requestId, false, true);
            setTableData(response);
            setPaginationInfo({
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.total / body.pageCount),
                totalRecords: response.total
            });
            if (!response?.orderSummary?.length) setEmptyMessage(NO_SUMMARY_FOUND);
        } catch (error) {
            console.error('Error in Companies info fetch:', error);
            setEmptyMessage(NO_SUMMARY_FOUND);
        }
    };

    const renderFooterContent = () => {
        const grandTotal: number = tableData?.orderSummary?.[0]?.marginGrandTotal ?? 0;
        const grossProfitPercentage: number =
            tableData?.orderSummary?.[0]?.grossMarginPercentage ?? 0;
        const grossProfitTooltip = tableData?.summaryToolTip || null;
        return (
            <div className="h-12 flex flex-row p-5 justify-end items-center">
                <Tooltip
                    target=".gross-profit-tooltip"
                    mouseTrack={false}
                    position="top"
                    content={grossProfitTooltip}
                    pt={{
                        root: { className: 'shadow-none ' },
                        text: { className: 'text-xs' }
                    }}
                />
                <span className="font-medium text-lg mr-4 font-barlow text-right text-[#181818] capitalize break-words">
                    {t('COMMON.GROSS_PROFIT')}
                </span>{' '}
                {grandTotal !== 0 && (
                    <img
                        src={grandTotal > 0 ? upArrowIcon : downArrowIcon}
                        className="h-4 w-4"
                        alt={`${grandTotal && grandTotal > 0 ? 'up' : 'down'}-arrow-icon`}
                    />
                )}
                <span className="break-words text-xl font-bold mx-1">{`$ ${formatCurrency(grandTotal)}`}</span>
                {renderPercentageTemplate(grossProfitPercentage)}
                {grossProfitTooltip && (
                    <i className="gross-profit-tooltip cursor-pointer pi pi-info-circle text-primary pl-2 text-[0.90rem] font-semibold" />
                )}
            </div>
        );
    };

    const taskIDTemplate = (rowData: SummaryDetails) => {
        const handleClick = () => {
            navigate(`/task-management/details/${rowData.taskId}/${rowData.id}`, {});
        };

        return (
            <div className="flex items-center">
                <button
                    className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer"
                    data-testid="task-id"
                    onClick={handleClick}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                    {rowData.taskNo}
                </button>
            </div>
        );
    };

    const amountFieldTemplate = (rowData: SummaryDetails, option: ColumnBodyOptions) => {
        const fieldName = option?.field as keyof SummaryDetails;
        const isMarginColumn = ['margin'].includes(fieldName);
        const isMarginLow = isMarginColumn && rowData?.margin < 0;

        let currencySymbol = '';
        if (fieldName === 'invoiceAmount') {
            currencySymbol = rowData?.requestCurrencySymbol;
        } else if (fieldName === 'billAmount') {
            currencySymbol = rowData?.amountVendorProfileCurrencySymbol;
        } else if (isMarginColumn) {
            currencySymbol =
                rowData?.requestCurrencySymbol || rowData?.amountVendorProfileCurrencySymbol || '';
        }

        const marginValue: number = (rowData[fieldName] as number) ?? 0;

        return (
            <div className="flex items-center justify-end w-full">
                <p className="flex items-center gap-1">
                    {isMarginColumn && (isMarginLow ? lowPercentageLogoTemplate() : <></>)}
                    {currencySymbol && <span className="mr-1">{currencySymbol}</span>}
                    <span>{formatCurrency(marginValue)}</span>
                </p>
            </div>
        );
    };

    const marginTemplate = (rowData: SummaryDetails) => {
        const isMarginLow = rowData.marginPercentage < 0;
        const margin = rowData.marginPercentage === 0 || rowData.marginPercentage;

        return margin ? (
            <span className="flex items-center justify-end">
                {isMarginLow ? lowPercentageLogoTemplate() : <></>}
                {rowData.marginPercentage}%
            </span>
        ) : (
            <span className="flex items-center justify-end">{'N/A'}</span>
        );
    };

    // template for toggle button in table
    const grossMarginToggleButton = (rowData: SummaryDetails) => {
        const getToggleText = (): string => {
            if (rowData.grossMarginEligible) {
                return t('COMMON.YES');
            } else {
                return t('COMMON.NO');
            }
        };
        const isToggleChecked = (): boolean => {
            return rowData.grossMarginEligible;
        };

        const handleGrossMarginEligible = (taskId: number, isActive: boolean) => {
            const errMsg = t(`QUOTE_AND_ORDER.ERROR_MESSAGE.GROSS_MARGIN_ELIGIBLE_UPDATE_FAILED`);
            const executeUpdate = async () => {
                try {
                    const record: GrossMarginEligibleUpdateFields = {
                        taskId,
                        isActive
                    };
                    const response = await updateGrossMarginEligible(record);
                    if (response) {
                        getSummaryList(requestBody);
                        await getOrderDetailsAPI();
                        showToastMessage({
                            message: t(
                                `QUOTE_AND_ORDER.SUCCESS_MESSAGE.GROSS_MARGIN_ELIGIBLE_UPDATE_SUCCESS`
                            ),
                            type: ToastType.SUCCESS
                        });
                    } else {
                        showToastMessage({
                            message: errMsg,
                            type: ToastType.ERROR
                        });
                    }

                    setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
                } catch (error) {
                    setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
                    showToastMessage({ message: errMsg, type: ToastType.ERROR });
                }
            };

            executeUpdate();
        };
        const handleToggleChange = () => {
            const isGrossMarginEligible = rowData.grossMarginEligible !== true;

            setShowConfirmationPopup({
                acceptLabel: t('COMMON.CONFIRM'),
                rejectLabel: t('COMMON.CANCEL'),
                visible: true,
                handlePopConfirmConfirm: () =>
                    handleGrossMarginEligible(rowData.taskId, isGrossMarginEligible),
                header: t('COMMON.CONFIRMATION_FOR_GROSS_MARGIN_ELIGIBLE_TITLE'),
                subHeader: '',
                description: t('COMMON.CONFIRMATION_FOR_GROSS_MARGIN_ELIGIBLE_MESSAGE')
            });
        };

        return (
            <>
                {hasEditGlossMarginPermission ? (
                    <div className="flex">
                        <div
                            key={rowData.taskId}
                            data-testid="summaryGrossMarginEligible"
                            className="flex items-center justify-between w-6/12 py-3 toggle_disable_State">
                            <input
                                type="checkbox"
                                className="toggle toggle-sm border-2"
                                style={{
                                    borderColor: isToggleChecked() ? '#1175C2' : '#A4A5A6',
                                    backgroundColor: isToggleChecked() ? '#1175C2' : '#A4A5A6'
                                }}
                                checked={isToggleChecked()}
                                onChange={handleToggleChange}
                                disabled={
                                    isThisFinanceUser || statusName.toUpperCase() === 'COMPLETED'
                                }
                            />
                            <div data-testid="summaryGrossMarginEligible-text" className="ml-2">
                                {getToggleText()}
                            </div>
                            <div className="flex ml-4">
                                <Tooltip
                                    id={`summary-gross-margin-tooltip-${rowData?.taskId}`}
                                    target={`.custom-target-gross-margin-icon-${rowData?.taskId}`}
                                    content={
                                        (rowData.grossMarginEligible ?? false)
                                            ? 'Non-Pass-Through'
                                            : 'Pass-Through'
                                    }
                                    position="bottom"
                                    mouseTrack={false}
                                    autoHide={false}
                                    pt={{ root: { className: 'shadow-none' } }}
                                />
                                <i
                                    className={`custom-target-gross-margin-icon-${rowData?.taskId} pi pi-info-circle text-primary cursor-pointer text-[1rem]`}
                                />
                            </div>
                        </div>
                    </div>
                ) : (
                    <div>{getToggleText()}</div>
                )}
            </>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskNo',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Link,
            body: taskIDTemplate,
            columnNumber: 0,
            frozen: true,
            alignFrozen: 'left',
            visibility: true
        },
        {
            field: 'taskName',
            header: 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: taskTitleTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'targetCountryFlagName',
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'status',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'invoiceAmount',
            header: 'Invoice Amount',
            sortable: true,
            filter: false,
            filterType: FilterType.Text,
            body: amountFieldTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'billAmount',
            header: 'Bill Amount',
            sortable: true,
            filter: false,
            filterType: FilterType.Text,
            body: amountFieldTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'grossMarginEligible',
            header: 'Gross Margin Eligible',
            sortable: true,
            filter: false,
            filterType: 'Dropdown',
            valueType: 'YesOrNo',
            body: (rowData: SummaryDetails) => grossMarginToggleButton(rowData),
            columnNumber: 0,
            visibility: true,
            filterDropDownOptions: [
                {
                    label: 'Yes',
                    value: 'true'
                },
                {
                    label: 'No',
                    value: 'false'
                }
            ]
        },
        {
            field: 'margin',
            header: 'Margin',
            sortable: true,
            filter: false,
            filterType: FilterType.Text,
            body: amountFieldTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'marginPercentage',
            header: 'Margin %',
            sortable: true,
            filter: false,
            filterType: FilterType.Text,
            body: marginTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            headerStyle: 'justify-end col-312',
            visibility: true
        }
    ];

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.TASK_MANAGEMENT,
        filters: {
            taskNo: { value: null, matchMode: FilterMatchMode.CONTAINS },
            sourcelanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetLanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetCountry: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            vendorName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            unit: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            taskName: { value: null, matchMode: FilterMatchMode.IN },
            taskStatus: { value: null, matchMode: FilterMatchMode.IN }
        },
        reOrderableColumns: true,
        title: '',
        emptyMessage,
        editTable: {
            editType: '',
            rowEditComplete() {},
            isRowEdit: true
        },
        localStorageKey: '',
        lazyLoad: false,
        columns: columnSchema,
        hideColumnSelector: true,
        customTableHeight: false
    };

    useEffect(() => {
        getSummaryList(requestBody);
    }, [requestBody, statusName]);

    return (
        <div className="grid grid-cols-1 gap-4 mt-3">
            <div className="m-w-full overflow-auto">
                {showConfirmationPopup.visible && (
                    <ConfirmationPopup
                        acceptLabel={showConfirmationPopup.acceptLabel}
                        rejectLabel={showConfirmationPopup.rejectLabel}
                        onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                        onCancel={() => handleConfirmationCancel()}
                        visible={showConfirmationPopup.visible}
                        headerText={showConfirmationPopup.header}
                        subHeaderText={showConfirmationPopup.subHeader}
                        description={showConfirmationPopup.description}
                    />
                )}
                <DataTableComponent
                    tableData={tableData?.orderSummary || []}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    handleFilter={setRequestBody}
                    toggleRowData={() => {}}
                    handlePagination={setRequestBody}
                    tablePaginationData={paginationInfo}
                    showPagination={true}
                    handleSort={setRequestBody}
                    showHeader={false}
                    footerContent={
                        tableData?.orderSummary && tableData?.orderSummary.length > 0
                            ? renderFooterContent
                            : undefined
                    }
                />
            </div>
        </div>
    );
};

export default Summary;
