import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
const _httpService = new HttpService();
const quoteURL = process.env.REACT_APP_QUOTE_BASE_URL ?? '';

/**
 * Sends a POST request to update the gross margin eligible for the Task.
 * @param record - The task informations.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
export const updateGrossMarginEligible = async <GrossMarginEligibleUpdateFields>(
    record: GrossMarginEligibleUpdateFields
): Promise<boolean> => {
    const apiUrl = `${quoteURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_GROSS_MARGIN_ELIGIBLE_IN_SUMMARY}`;
    try {
        const response = await _httpService.post<boolean, GrossMarginEligibleUpdateFields>(apiUrl,record);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};


const summaryTasksService = {
    updateGrossMarginEligible,
};

export default summaryTasksService;
