export interface SummaryDetails {
    id: number;
    billId: number;
    sourceLanguageId: number;
    orderRequestNumber: number;
    taskId: number;
    taskNo: string;
    taskName: string;
    sourceLanguage: string;
    targetLanguage: string;
    requestCurrencyName: string;
    requestCurrencySymbol: string;
    amountVendorProfileCurrency: string;
    amountVendorProfileCurrencySymbol: string;
    targetCountry: string;
    status: string;
    targetCountryFlagName: string;
    invoiceId: number;
    billAmount: number;
    invoiceAmount: number;
    margin: number;
    marginPercentage: number;
    marginGrandTotal: number;
    grossMarginPercentage: number;
    grossMarginEligible: boolean;
}

export interface GetSummaryListApiResponse {
    orderSummary: SummaryDetails[];
    summaryToolTip: string;
    total: number;
}

export interface GrossMarginEligibleUpdateFields {
    taskId: number;
    isActive: boolean;
}
