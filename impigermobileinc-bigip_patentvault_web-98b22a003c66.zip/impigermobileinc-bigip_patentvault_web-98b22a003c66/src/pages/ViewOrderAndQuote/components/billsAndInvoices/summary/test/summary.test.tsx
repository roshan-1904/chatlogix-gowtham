import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { BrowserRouter } from 'react-router-dom';
import Summary from '../summary';
import SummaryMockData from '../data/summary.mock.json';
import { getTableData } from '../../invoiceTasks/service/invoiceTasksService';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useParams: () => ({
        requestId: '6787'
    })
}));

jest.mock('../../invoiceTasks/service/invoiceTasksService');

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

describe('Summary Component(Bills & Invoice)', () => {
    const mockGetOrderDetailsAPI = jest.fn().mockResolvedValue(Promise.resolve());
    beforeEach(() => {
        (getTableData as jest.Mock).mockResolvedValue(SummaryMockData);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders Summary component', async () => {
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        expect(screen.getByText('COMMON.GROSS_PROFIT')).toBeInTheDocument();
        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(1);
        });
    });

    test('renders table with correct data', async () => {
        const { taskNo, taskName, sourceLanguage, targetLanguage } =
            SummaryMockData.orderSummary[0];
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(taskNo)).toBeInTheDocument();
            expect(screen.getByText(taskName)).toBeInTheDocument();
            expect(screen.getByText(sourceLanguage)).toBeInTheDocument();
            expect(screen.getByText(targetLanguage)).toBeInTheDocument();
        });
    });

    test('handles pagination', async () => {
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(SummaryMockData.orderSummary[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Last Page" button (>>)
        fireEvent.click(screen.getByLabelText('Last Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });

        // Simulate clicking the "First Page" button (<<)
        fireEvent.click(screen.getByLabelText('First Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(3);
        });
    });

    test('handles specific page link', async () => {
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(SummaryMockData.orderSummary[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Page 2" button
        fireEvent.click(screen.getByLabelText('Page 2'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles sorting', async () => {
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('R240711-17-71[3]-TRA-GER')).toBeInTheDocument();
        });

        fireEvent.click(screen.getByText('Task ID'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles error state', async () => {
        (getTableData as jest.Mock).mockRejectedValueOnce(new Error('Failed to fetch'));

        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_SUMMARY_FOUND')).toBeInTheDocument();
        });
    });

    test('renders footer content correctly', async () => {
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('COMMON.GROSS_PROFIT')).toBeInTheDocument();
            expect(screen.getByText('$ 43.20')).toBeInTheDocument();
            expect(screen.getByAltText('up-arrow-icon')).toBeInTheDocument();
        });
    });
    test('renders empty message when no data is available', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderSummary: [], total: 0 });
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_SUMMARY_FOUND')).toBeInTheDocument();
        });
    });

    test('renders footer with zero gross profit correctly', async () => {
        (getTableData as jest.Mock).mockResolvedValue({
            orderSummary: [{ marginGrandTotal: 0 }],
            total: 0
        });
        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.queryByAltText('up-arrow-icon')).not.toBeInTheDocument();
            expect(screen.queryByAltText('down-arrow-icon')).not.toBeInTheDocument();
        });
    });

    test('renders pagination buttons as disabled with no items', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderSummary: [], total: 0 });

        render(
            <BrowserRouter>
                <Summary getOrderDetailsAPI={mockGetOrderDetailsAPI} statusName={''} />
            </BrowserRouter>
        );

        await waitFor(() => {
            // Ensure no data is rendered
            expect(
                screen.queryByText(SummaryMockData.orderSummary[0]?.taskNo)
            ).not.toBeInTheDocument();

            // Check if pagination buttons are disabled
            expect(screen.getByLabelText('First Page')).toBeDisabled();
            expect(screen.getByLabelText('Last Page')).toBeDisabled();
            expect(screen.queryByLabelText('Page 2')).not.toBeInTheDocument();
        });
    });
});
