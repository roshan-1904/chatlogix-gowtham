export interface BillsBreakDownType {
    breakdownName: string;
    percentage: number;
    rate: number;
    wordCount: number;
    amount: number;
}
export interface BillTask {
    id: number;
    billId: number;
    sourceLanguageId: number;
    orderRequestNumber: number;
    grandTotal: number;
    taskId: number;
    taskNo: string;
    taskName: string;
    sourceLanguage: string;
    targetLanguage: string;
    targetCountry: string;
    quantity: number;
    status: string;
    orderStatusId: number;
    orderStatusName: string;
    requestCurrencyName: string;
    requestCurrencySymbol: string;
    blobFileName: string;
    fileType: string;
    targetCountryFlagName: string;
    showInQuote: string;
    fileSize: string;
    unit: string;
    fileName: string;
    vendorName: string;
    vendorId: number;
    uploadedOn: string;
    taskTypeId: number;
    documentId: number;
    documentType: number;
    unitId: number;
    billCurrency: number;
    taskRefId: number | null;
    fileId: number;
    requestCurrency: number;
    billStatusId: number;
    vendorCurrencyAmount: number;
    rate: number;
    rateLabelName: string;
    rateLabelDescription: string;
    fxRate: string;
    requestCurrencyAmount: number;
    amountVendorProfileCurrency: string;
    amountVendorProfileCurrencySymbol: string;
    isBreakdown: boolean;
    breakdownData: string;
    isBillable: boolean;
    billProcessedMethod?: string | null;
    children: BillsBreakDownType[];
    minimumCharge: number;
    taskDueDate?: string;
    field?: string;
    isVendorDocument?: boolean;
    hasUnapprovedTranslatedDocument?: boolean;
    currencyIsoCode?: string;
}

export interface GetBillsListApiResponse {
    total: number;
    orderBills: BillTask[];
}
