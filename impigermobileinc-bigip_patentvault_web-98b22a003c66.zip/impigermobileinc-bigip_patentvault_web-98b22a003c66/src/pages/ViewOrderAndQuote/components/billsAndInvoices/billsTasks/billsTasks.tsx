import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
    FilterType,
    RequestStatusEnum,
    TableTypes,
    ValueType
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { useTranslation } from 'react-i18next';
import { taskTitleTemplate, VendorModal } from 'pages/taskManagement/tasksList/tasksList';
import { Task, TaskDetailModel } from 'pages/taskManagement/types/tasks.types';
import taskManagementService from 'pages/taskManagement/service/taskManagement.service';
import NotificationStore, { ToastType } from 'core/store/notificationStore/notificationStore';
import userIcon from 'assets/images/user-icon.png';
import plusIcon from 'assets/svgs/plus-icon.svg';
import { FilterMatchMode } from 'primereact/api';
import BillTasksMock from './data/billsTasks.mock.json';
import {
    getTableData,
    getVendorList,
    updateBillsInvoiceFields
} from '../invoiceTasks/service/invoiceTasksService';
import { BillTask, GetBillsListApiResponse } from './types/billsTasks.type';
import { Dropdown } from 'primereact/dropdown';
import { EditableField, getStatusOptions } from '../invoiceTasks/invoiceTasks';
import { optionTemplate } from 'pages/taskManagement/ViewTask/viewTaskDetail';
import { filterDropDownStyle, venderDropdownStyle } from 'constants/styles.constant';
import { StatusType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { getStatusColor } from 'shared/dataTable/components/statusIndicator/statusIndicator';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import BillsBreakDown from './billsBreakDown';
import { DataTableExpandedRows } from 'primereact/datatable';
import {
    convertToValidNumber,
    formatCurrency,
    isFinanceUser,
    isStaffUser,
    isVendorUser,
    showToastMessage
} from 'core/utils/utils';
import { Tooltip } from 'primereact/tooltip';
import { InvoiceBillsUpdateFields } from '../invoiceTasks/types/invoice.types';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { Permissions } from 'constants/permissions';
import { END_POINT } from 'constants/endPoint';
import { CONFIRMATION_POPUP_REQUEST_TYPE_ID } from 'constants/app.constant';
import { ToggleSwitch } from 'pages/accounting/components/toggleSwitch/toggleSwitch';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { DateFieldTableCellEditor } from 'shared/dataTable/components/dateFieldTableCellEditor/dateFieldTableCellEditor';
import TaskUnitEdit from 'components/reuseComponents/taskUnitEdit';
import { TaskDropDown } from 'pages/users/types/users.types';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import { HandleStatusDescription } from 'pages/taskManagement/ViewTask/viewTaskDetailHelper';
import { TASK_STATUS } from 'pages/taskManagement/shared/taskManagementHelper';

export interface PopupContentInit {
    visible: boolean;
    header: string;
    subHeader: string;
    description: string | JSX.Element;
    statusId: number;
    taskId: string;
    statusName: string;
    requestFunctionType: string;
    data: string;
    acceptButtonLabel?: string;
    rejectButtonLabel?: string;
    vendorCurrencyAmount?: number;
    isBillable?: boolean;
}

const BillsTasks = ({
    statusName,
    getOrderDetailsAPI,
    rebuildOrderStatusList,
    patentCountResponse,
    countryEditResponse,
    isNonIP = false,
    taskSelection
}: {
    statusName: string;
    getOrderDetailsAPI?: () => Promise<void>;
    rebuildOrderStatusList?: () => void;
    patentCountResponse: any;
    countryEditResponse: any;
    isNonIP?: boolean;
    taskSelection?: {
        selectedTasks: BillTask[];
        restrictedRowsToSelect: BillTask[];
        isAllTasksSelected: boolean;
        handleSelectedTasks: (selectedTasks: BillTask[], taskList: BillTask[]) => void;
        handleSelectAllTasks: (selectAll: boolean, taskList: BillTask[]) => void;
        updateRestrictedRowsToSelect: (taskList: BillTask[]) => void;
    };
}) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const { requestId } = useParams();
    const [expandedRows, setExpandedRows] = useState<
        DataTableExpandedRows | Record<string, boolean>
    >({});
    const [vendorList, setVendorList] = useState<VendorModal[]>([]);
    const [statusList, setStatusList] = useState<StatusType[]>([]);
    const popupContentInit: PopupContentInit = {
        visible: false,
        header: t('COMMON.CONFIRMATION'),
        subHeader: '',
        description: t('COMMON.CONFIRMATION_STATUS'),
        statusId: 0,
        taskId: '',
        statusName: '',
        requestFunctionType: '',
        data: '',
        acceptButtonLabel: t('COMMON.YES'),
        rejectButtonLabel: t('COMMON.NO'),
        vendorCurrencyAmount: 0,
        isBillable: false
    };
    const [showPopup, setShowPopup] = useState(popupContentInit);
    const { visible, header, subHeader, description, taskId, statusId } = showPopup;
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: ''
    });
    const [groupingAbilities, setGroupingAbilities] = useState<TaskDropDown[]>([]);
    const [statusConfirmCheckList, setStatusConfirmCheckList] = useState({
        isDeliverablesReviewed: false,
        isBillingCalculationCorrect: false,
        isBillGenerationSkipped: false
    });

    const handleConfirmationCancel = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };

    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [tableData, setTableData] = useState<BillTask[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [emptyMessage, setEmptyMessage] = useState<string>(' ');
    const NO_BILLS_FOUND = t('QUOTE_AND_ORDER.NO_BILLS_FOUND');
    const { APPROVED, COMPLETED, PREPARING_QUOTE, WAITING_FOR_APPROVAL, CANCELED } =
        RequestStatusEnum;
    const isQuoteStatus = statusName === PREPARING_QUOTE || statusName === WAITING_FOR_APPROVAL;
    const isQuoteCompleted = statusName === COMPLETED;
    const hasEditBillTaskPermission = AuthStore.hasPermission(Permissions.EDIT_BILL_TASK);

    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUserExcludedFinance = isStaffUser(loggedInUserRoleId, true);
    const isThisFinanceUser = isFinanceUser(userDetails.userInfo.roleId);
    const isThisVendorUserExcludedFinance = isVendorUser(loggedInUserRoleId, {
        excludeFinance: true
    });

    const getBillsListWrapper = () => {
        getBillsList(requestBody).catch(() => console.error('Error fetching bills list'));
    };
    const getBillsList = async (body: RequestBody) => {
        try {
            const response: GetBillsListApiResponse = await getTableData<GetBillsListApiResponse>(
                body,
                requestId,
                true
            );
            setTableData(response.orderBills || []);
            if (response.orderBills?.length) {
                const restrictedRowsToSelect = response.orderBills.filter(
                    (bill) => bill?.status === APPROVED
                );
                taskSelection?.updateRestrictedRowsToSelect(restrictedRowsToSelect);
            }
            setPaginationInfo({
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.total / body.pageCount),
                totalRecords: response.total
            });
            if (!response?.orderBills?.length) setEmptyMessage(NO_BILLS_FOUND);
        } catch (error) {
            console.error('Error in Companies info fetch:', error);
            setEmptyMessage(NO_BILLS_FOUND);
        }
    };

    // Function to get Status List
    const getStatusList = async () => {
        try {
            const response = await taskManagementService.getStatusList<any[]>();
            if (response && response.length > 0) {
                setStatusList(response);
            } else {
                setStatusList([]);
            }
        } catch (error) {
            console.error(error);
        }
    };

    const updateBillsInlineFields = async (
        billId: number,
        fields: InvoiceBillsUpdateFields,
        toastMsg = { success: 'RATE_UPDATED_SUCCESSFULLY', error: 'RATE_UPDATED_FAILED' }
    ) => {
        const errMsg = t(`QUOTE_AND_ORDER.ERROR_MESSAGE.${toastMsg?.error}`);
        try {
            const response = await updateBillsInvoiceFields(billId, fields, true);
            if (response) {
                getBillsList(requestBody);
                getOrderDetailsAPI?.();
                showToastMessage({
                    message: t(`QUOTE_AND_ORDER.SUCCESS_MESSAGE.${toastMsg?.success}`),
                    type: ToastType.SUCCESS
                });
            } else {
                showToastMessage({
                    message: errMsg,
                    type: ToastType.ERROR
                });
            }
        } catch (error: any) {
            const errorMsgFromAPI = error?.response?.data?.Message;
            showToastMessage({
                message: errorMsgFromAPI ?? errMsg,
                type: ToastType.ERROR
            });
        }
    };

    const taskIDTemplate = (rowData: BillTask) => {
        const handleClick = () => {
            navigate(`/task-management/details/${rowData.taskId}/${rowData.id}`, {});
        };

        const isShowExpander =
            rowData?.isBreakdown &&
            rowData?.vendorId &&
            rowData?.vendorName &&
            rowData?.status !== CANCELED;

        return (
            <div className={`flex items-center ${isShowExpander ? '' : 'ml-6'}`}>
                {isShowExpander && expanderTemplate(rowData)}
                <button
                    className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer"
                    data-testid="task-id"
                    onClick={handleClick}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    tabIndex={0}>
                    {rowData.taskNo}
                </button>
            </div>
        );
    };
    const amountVendorCurrencyTemplate = (rowData: BillTask) => {
        const { vendorCurrencyAmount, amountVendorProfileCurrencySymbol } = rowData;
        const canEditVendorCurrencyAmount = false;
        const handleAmountSave = (newAmount: number) => {
            // Logic to save the updated amount
            if (vendorCurrencyAmount !== newAmount) {
                updateBillsInlineFields(
                    +rowData.billId || 0,
                    { amount: newAmount },
                    {
                        success: 'VENDOR_AMOUNT_UPDATED_SUCCESSFULLY',
                        error: 'VENDOR_AMOUNT_UPDATE_FAILED'
                    }
                );
            }
        };

        return (
            <div className="flex items-center justify-between gap-2 w-full">
                {!!rowData?.billProcessedMethod && (
                    <div className="flex items-center mt-0.5">
                        <Tooltip
                            id={`invoice-amount-tooltip-${rowData?.billId}`}
                            target={`.custom-target-icon-${rowData?.billId}`}
                            content={rowData?.billProcessedMethod ?? ''}
                            position="bottom"
                            mouseTrack={false}
                            autoHide={false}
                            pt={{ root: { className: 'shadow-none' } }}
                        />
                        <i
                            className={`custom-target-icon-${rowData?.billId} pi pi-info-circle text-primary cursor-pointer text-[1rem]`}
                        />
                    </div>
                )}
                <EditableField
                    fieldName="amountVendorProfileCurrency"
                    fieldValue={vendorCurrencyAmount || 0}
                    onSave={handleAmountSave}
                    currency={amountVendorProfileCurrencySymbol}
                    canEditFields={
                        !isFinanceUser(userDetails.userInfo.roleId) &&
                        canEditVendorCurrencyAmount &&
                        statusName !== COMPLETED &&
                        rowData?.status !== APPROVED
                    }
                />
            </div>
        );
    };
    const fxRateTemplate = (rowData: BillTask) => {
        return <span>{rowData.fxRate}</span>;
    };

    const amountTemplate = (rowData: BillTask) => {
        return (
            <span>{`${rowData?.requestCurrencySymbol || '$'} ${formatCurrency(+rowData?.requestCurrencyAmount || 0)}`}</span>
        );
    };
    const miChargeTemplate = (rowData: BillTask) => {
        const { minimumCharge, amountVendorProfileCurrencySymbol } = rowData;

        return (
            <EditableField
                fieldName="rate"
                fieldValue={minimumCharge || 0}
                currency={amountVendorProfileCurrencySymbol}
                onSave={() => {}}
                canEditFields={false}
            />
        );
    };
    const rateTemplate = (rowData: BillTask) => {
        const { rate, amountVendorProfileCurrencySymbol } = rowData;
        const handleRateSave = (newRate: number) => {
            // Logic to save the updated rate
            if (rate !== newRate) {
                updateBillsInlineFields(+rowData.billId || 0, {
                    rate: newRate
                });
            }
        };
        return hasEditBillTaskPermission && rowData.isBillable ? (
            <EditableField
                fieldName="rate"
                fieldValue={rate || 0}
                currency={amountVendorProfileCurrencySymbol}
                onSave={handleRateSave}
                canEditFields={statusName !== COMPLETED && rowData?.status !== APPROVED}
            />
        ) : (
            <span>
                {convertToValidNumber({
                    value: rate || 0,
                    decimalLength: 4,
                    renderAs: 'string'
                })}
            </span>
        );
    };
    const rateLabelNameTemplate = (rowData: BillTask) => {
        const { rateLabelName, rateLabelDescription } = rowData;

        return (
            <>
                {rateLabelName &&
                    rateLabelDescription?.trim() !== '' &&
                    rateLabelDescription !== '-' && (
                        <Tooltip
                            position="bottom"
                            target={'.rateLabelNameTooltip_' + rowData.billId}
                            content={rateLabelDescription}
                        />
                    )}
                <span className={`rateLabelNameTooltip_${rowData.billId}`}>
                    {rateLabelName || '-'}
                </span>
            </>
        );
    };

    const quantityTemplate = (rowData: BillTask) => {
        const { quantity } = rowData;
        const handleQuantitySave = (newQuantity: number) => {
            // Logic to save the updated quantity
            if (quantity !== newQuantity) {
                updateBillsInlineFields(
                    +rowData.billId || 0,
                    {
                        quantity: newQuantity
                    },
                    {
                        success: 'QUANTITY_UPDATED_SUCCESSFULLY',
                        error: 'QUANTITY_UPDATE_FAILED'
                    }
                );
            }
        };
        return hasEditBillTaskPermission && rowData.isBillable ? (
            <EditableField
                fieldName="quantity"
                fieldValue={quantity || 0}
                onSave={handleQuantitySave}
                canEditFields={statusName !== COMPLETED && rowData?.status !== APPROVED}
                canFormatFields={false}
            />
        ) : (
            <span>{quantity || 0}</span>
        );
    };

    const vendorNameTemplate = (task: Task) => {
        const vendorOptionTemplate = (option: VendorModal) => {
            return (
                <div className="border-b">
                    <div className="flex gap-2 pb-3 pt-1">
                        <img className="w-[16px] h-full pt-1" src={userIcon} alt="" />
                        <div className="flex flex-col gap-2 w-10/12">
                            <Tooltip
                                position="bottom"
                                target={'.vendorNameTooltip' + option.id}
                                content={option.name}></Tooltip>
                            <div
                                className={
                                    'vendorNameTooltip' + option.id + 'font-medium truncate w-full'
                                }>
                                {option.name}
                            </div>

                            <div className="flex items-center justify-between gap-1 text-sm">
                                <div className="text-neutral-200 flex gap-1">
                                    <span>{option.rate}</span>
                                    <span>{option.currencyIsoCode}</span>
                                </div>
                                <span>
                                    {(() => {
                                        const catLabel = option.cat ?? 'No';
                                        const rateLabel = option.rateLabelCode
                                            ? ` - ${option.rateLabelCode}`
                                            : '';
                                        return t('TASKS.CAT') + ' - ' + catLabel + rateLabel;
                                    })()}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            );
        };

        let vendorContent;
        if (task.vendorId && task.vendorId !== 0) {
            vendorContent = (
                <div className="m-1">
                    <div className="flex items-center">
                        <img src={userIcon} alt="" />
                        <span className={!task.vendorId ? 'text-[#1175C2] pl-2' : 'pl-2'}>
                            {task.vendorName}
                        </span>
                    </div>
                </div>
            );
        } else if (hasEditBillTaskPermission) {
            vendorContent = (
                <Dropdown
                    onChange={(event) => {
                        handleVendorAssignChange(task, event.value as VendorModal);
                    }}
                    disabled={isQuoteStatus || isQuoteCompleted}
                    options={vendorList}
                    optionLabel="name"
                    placeholder="Assign"
                    dropdownIcon={<img className="w-[19px]" src={plusIcon} alt="plus-icon" />}
                    optionValue=""
                    onClick={() => handleVendorAssignClickToGetListWrapper(task.taskId)}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    filter={true}
                    itemTemplate={vendorOptionTemplate}
                    filterPlaceholder="Search Vendor name"
                    pt={venderDropdownStyle}
                />
            );
        } else {
            vendorContent = '-';
        }

        return <>{vendorContent}</>;
    };
    const validateTaskDescription = (task: Task, assigneeInfo: VendorModal) => {
        const updatedShowPopupData = {
            ...showPopup,
            visible: true,
            header: t('TASKS.TITLE_CONFIRM_TASK_ASSIGN'),
            description: <p className="leading-5">{t('TASKS.WARNING_MSG.TASK_HAS_NO_DESC')}</p>,
            requestFunctionType: CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN_WITHOUT_DESC,
            data: JSON.stringify({ task, assigneeInfo })
        };
        setShowPopup(updatedShowPopupData);
    };
    const handleVendorAssignClickToGetListWrapper = (_taskId: number) => {
        handleVendorAssignClickToGetList(_taskId);
    };
    const handleVendorAssignClickToGetList = async (_taskId: number) => {
        try {
            const response: VendorModal[] = await getVendorList(_taskId);
            if (response) {
                // we don't have unique vendors in upcoming features.
                // const uniqueVendors = Array.from(
                //     new Map(response.map((vendor) => [vendor.id, vendor])).values()
                // );
                response.forEach((vendor) => {
                    vendor.isShow = true;
                });
                setVendorList(response);
            }
        } catch (error) {
            console.error('Error in handleVendorAssignClickToGetList(): ', error);
        }
    };
    const handleVendorAssignChange = async (task: Task, assigneeInfo: VendorModal) => {
        try {
            const assigneeId: number = assigneeInfo.id ?? 0;
            const payload = [{ taskId: task.taskId, assigneeId }];

            if (task.isInstructionAvailable === false && !task.proceedWithoutDesc) {
                validateTaskDescription(task, assigneeInfo);
                return;
            }

            /** vendor validation API call. if it's true trigger confirm popup, else just do the actual flow.
             if popup confirmed then do the same actual flow. */
            const isThisVendorReassigning: [{ isCanceled: boolean | null; taskId: string | null }] =
                await taskManagementService.validateVendorReassignment(payload);

            const vendorBreakDownId =
                vendorList.find(
                    (vendor) => vendor.vendorBreakDownId === assigneeInfo.vendorBreakDownId
                )?.vendorBreakDownId ?? 0;

            if (isThisVendorReassigning && isThisVendorReassigning[0].isCanceled === true) {
                // popup setup
                const updatedShowPopupData = {
                    ...showPopup,
                    visible: true,
                    description: (
                        <div>
                            <p className="leading-5">{t('TASKS.VENDOR_REASSIGN_CONFIRMATION')} </p>
                            <p className="leading-5">
                                {isThisVendorReassigning.map((item) => item.taskId).join(', ')}{' '}
                            </p>
                        </div>
                    ),
                    requestFunctionType:
                        CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN_VALIDATION,
                    data: JSON.stringify({ task, assigneeId: assigneeInfo.id, vendorBreakDownId })
                };
                setShowPopup(updatedShowPopupData);
            } else {
                triggerVendorChangeProcess(task.taskId, assigneeId, vendorBreakDownId);
            }
        } catch (error) {
            console.error('Error in handleUpdateVendorAssignValueChange(): ', error);
        }
    };
    const triggerVendorChangeProcess = (
        _taskId: number,
        assigneeId: number,
        vendorBreakDownId: number
    ) => {
        const selectedVendor = vendorList.find((vendor) => vendor.id === assigneeId);
        if (selectedVendor?.rate === 0 || selectedVendor?.rate === null) {
            // trigger confirmation popup
            setShowPopup({
                ...showPopup,
                visible: true,
                description: t('COMMON.CONFIRMATION_STATUS_WITHOUT_VENDOR_RATE'),
                requestFunctionType: CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN,
                data: JSON.stringify({ assigneeId, vendorBreakDownId }),
                taskId: String(_taskId)
            });
        } else {
            updateAssignee(_taskId, assigneeId, vendorBreakDownId);
        }
    };
    const updateAssignee = async (
        _taskId: number,
        assigneeId: number,
        vendorBreakDownId: number
    ) => {
        const payload = [{ taskId: _taskId, assigneeId, vendorBreakDownId }];

        try {
            const response = await taskManagementService.updateAssignee(payload);
            if (response) {
                NotificationStore.showAlert({
                    type: ToastType.SUCCESS,
                    message: t('TASK_MANAGEMENT.ASSIGN_VENDOR_MESSAGE')
                });
                getBillsList(requestBody);
                getOrderDetailsAPI?.();
                rebuildOrderStatusList?.();
            }
        } catch (error) {
            console.error(error);
        }
    };

    const rowExpansionTemplate = (data: BillTask) => {
        const quoteBaseUrl = process.env.REACT_APP_QUOTE_BASE_URL ?? '';
        const uploadUrl = `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.MEMOQ_FILE_UPLOAD}`;

        const isShowDeleteMemoQFile = data.breakdownData !== '' && data.breakdownData !== null;
        // If the task is approved, we don't allow to delete the breakdown file.
        const deleteMemoQFileUrl =
            isShowDeleteMemoQFile && data.status !== RequestStatusEnum.APPROVED
                ? `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.DELETE_BREAKDOWN_FILE}`
                : '';

        const isShowUploadButton = data.status !== RequestStatusEnum.APPROVED && !isThisFinanceUser;
        return (
            <div className="pl-14 w-2/4">
                {data?.isBreakdown && (
                    <BillsBreakDown
                        key={data.billId}
                        uploadUrl={uploadUrl}
                        deleteFileUrl={deleteMemoQFileUrl}
                        selectedRowData={data}
                        onUploaded={async () => await getBillsList(requestBody)}
                        getOrderDetailsAPI={getOrderDetailsAPI}
                        isShowUploadButton={isShowUploadButton}
                        breakdownType="bill"
                    />
                )}
            </div>
        );
    };

    const toggleRow = (data: BillTask, collapseCanceledRow: boolean = false) => {
        let expandedRowsCopy = { ...expandedRows };
        if (expandedRowsCopy[data.taskId] || collapseCanceledRow) {
            delete expandedRowsCopy[data.taskId];
        } else {
            // expandedRowsCopy[data.taskId] = true;
            expandedRowsCopy = { [data.taskId]: true };
        }
        setExpandedRows(expandedRowsCopy);
    };

    const expanderTemplate = (data: BillTask) => {
        return (
            <button
                type="button"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() => toggleRow(data)}
                className="p-link mr-1">
                <i
                    className={`text-primary pi pi-fw pi-chevron-${expandedRows[data.taskId] ? 'down' : 'right'} `}
                />
            </button>
        );
    };

    const updateTaskStatus = async (taskRequestId: string, taskStatusId: number) => {
        const errMsg = t('TASKS.TASK_STATUS_UPDATE_FAILED');
        try {
            const response = await taskManagementService.updateTaskStatus(
                taskRequestId,
                taskStatusId,
                undefined,
                statusConfirmCheckList.isDeliverablesReviewed,
                statusConfirmCheckList.isBillingCalculationCorrect,
                statusConfirmCheckList.isBillGenerationSkipped
            );

            if (showPopup?.statusName === CANCELED) {
                /** if the task is canceled, remove the 'expandable row icon'. 
                    But we should collapse the Break-Down area as well below the row. */
                const canceledRow = tableData.find((row) => row.taskId === +taskRequestId) ?? null;
                canceledRow && toggleRow(canceledRow, true);

                // if the task is canceled, we should update the status list to refresh.
                rebuildOrderStatusList?.();
                getOrderDetailsAPI?.();
            }

            if (response) {
                getBillsList(requestBody);
                showToastMessage({
                    message: t('TASKS.TASK_STATUS_UPDATE_SUCCESS'),
                    type: ToastType.SUCCESS
                });
            } else {
                showToastMessage({ message: errMsg, type: ToastType.ERROR });
            }
        } catch (error) {
            showToastMessage({ message: errMsg, type: ToastType.ERROR });
        }
    };

    const getGroupingAbilities = async () => {
        try {
            const response = await taskManagementService.getTaskAbilitiesType<TaskDropDown[]>();
            setGroupingAbilities(response);
        } catch (error) {
            console.error('Error fetching grouping abilities:', error);
        }
    };

    const handleGetUnitDropDownOptions = (taskTypeId: number) => {
        const matchedAbility = groupingAbilities.find((ability) => ability.id === taskTypeId);
        return (
            matchedAbility?.units.map((unit) => ({ label: unit.name, value: unit.unitId })) || []
        );
    };

    const handleFilter = async (id: number, selectedStatusName: string, rowData: BillTask) => {
        setStatusConfirmCheckList({
            isDeliverablesReviewed: false,
            isBillingCalculationCorrect: false,
            isBillGenerationSkipped: false
        });
        if (rowData.vendorId === 0 || rowData.vendorId === null) {
            showToastMessage({ message: t('TASKS.TASK_STATUS_ERROR'), type: ToastType.ERROR });
            return;
        }

        // Handle APPROVED status separately and return early
        if (selectedStatusName === APPROVED) {
            try {
                const taskDetails: TaskDetailModel = await taskManagementService.getTaskDetails(
                    String(rowData.taskId)
                );

                setShowPopup((prev) => ({
                    ...prev,
                    visible: true,
                    statusId: id,
                    statusName: selectedStatusName,
                    taskId: rowData.taskId.toString(),
                    requestFunctionType: CONFIRMATION_POPUP_REQUEST_TYPE_ID.TASK_STATUS_CHANGE,
                    description: (
                        <HandleStatusDescription
                            id={id}
                            service={taskDetails?.taskName}
                            sourceLanguage={taskDetails?.sourceLanguageName}
                            targetLanguage={taskDetails?.targetLanguageName}
                            country={taskDetails?.targetCountriesName}
                            vendorName={taskDetails?.vendorName}
                            quantity={taskDetails?.quantity as number}
                            rate={taskDetails?.rate as number}
                            unit={taskDetails?.unitName as string}
                            isVendorDocument={!taskDetails?.isVendorDocument}
                            hasUnapprovedTranslatedDocument={
                                taskDetails?.hasUnapprovedTranslatedDocument
                            }
                            currencyIsoCode={taskDetails?.currencyIsoCode}
                            vendorCurrencyAmount={taskDetails?.vendorCurrencyAmount}
                            isBillable={taskDetails?.isBillable}
                            handleConfirmChecklist={(
                                isDeliverablesReviewed,
                                isBillingCalculationCorrect,
                                isBillGenerationSkipped
                            ) => {
                                setStatusConfirmCheckList({
                                    isDeliverablesReviewed: isDeliverablesReviewed || false,
                                    isBillingCalculationCorrect:
                                        isBillingCalculationCorrect || false,
                                    isBillGenerationSkipped: isBillGenerationSkipped || false
                                });
                            }}
                        />
                    ),
                    acceptButtonLabel:
                        id === TASK_STATUS.APPROVED
                            ? taskDetails?.vendorCurrencyAmount === 0
                                ? t('TASK_MANAGEMENT.APPROVE_WITHOUT_BILL')
                                : t('COMMON.APPROVE')
                            : undefined,
                    rejectButtonLabel:
                        id === TASK_STATUS.APPROVED
                            ? taskDetails?.vendorCurrencyAmount === 0
                                ? t('TASK_MANAGEMENT.GO_BACK_TASK')
                                : t('COMMON.CANCEL')
                            : undefined,
                    header:
                        id === TASK_STATUS.APPROVED
                            ? taskDetails?.vendorCurrencyAmount === 0
                                ? taskDetails?.isBillable
                                    ? t('TASK_MANAGEMENT.APPROVE_WITH_ZERO_AMOUNT')
                                    : t('TASK_MANAGEMENT.APPROVE_NON_BILLABLE_TASK')
                                : t('TASK_MANAGEMENT.APPROVE_TASK_GENERATE_BILL')
                            : t('COMMON.CONFIRMATION'),
                    vendorCurrencyAmount: taskDetails?.vendorCurrencyAmount,
                    isBillable: taskDetails?.isBillable
                }));
            } catch (err) {
                console.error('Error fetching task details:', err);
            }
            return;
        }

        setShowPopup((prev) => ({
            ...prev,
            visible: true,
            statusId: id,
            statusName: selectedStatusName,
            taskId: rowData.taskId.toString(),
            requestFunctionType: CONFIRMATION_POPUP_REQUEST_TYPE_ID.TASK_STATUS_CHANGE
        }));
    };

    const statusTemplate = (data: BillTask) => {
        const taskStatus: string = data?.status;
        return (
            <div className="mr-2 uppercase">
                {hasEditBillTaskPermission ? (
                    <Dropdown
                        value={taskStatus}
                        onChange={(e: any) => {
                            handleFilter(
                                statusList?.find((item) => item?.name === e.value)?.id as number,
                                e.value as string,
                                data
                            );
                        }}
                        options={getStatusOptions(`${taskStatus}`, statusList)}
                        optionLabel="label"
                        itemTemplate={optionTemplate}
                        style={{ border: 'none' }}
                        pt={{
                            ...filterDropDownStyle,
                            root: {
                                className:
                                    filterDropDownStyle.root.className +
                                    (taskStatus
                                        ? ' ' +
                                          getStatusColor(taskStatus, TableTypes.TASK_MANAGEMENT)
                                        : '')
                            },
                            input: {
                                className: `p-0 text-sm ${getStatusColor(taskStatus, TableTypes.TASK_MANAGEMENT)}`
                            }
                        }}
                    />
                ) : (
                    <span>{taskStatus}</span>
                )}
            </div>
        );
    };

    const updateBillableTaskStatus = (rowData: BillTask): void => {
        const updatedRowData = { ...rowData, isBillable: !rowData.isBillable };
        taskManagementService
            .updateIsBillableTaskStatus(rowData.taskId, updatedRowData.isBillable)
            .then(() => {
                setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
                getBillsList(requestBody);
                getOrderDetailsAPI?.();
            })
            .catch(() => {
                setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
            });
    };

    const updateMarginEligibleStatus = (rowData: BillTask) => {
        setShowConfirmationPopup({
            visible: true,
            handlePopConfirmConfirm: () => updateBillableTaskStatus(rowData),
            header: t('COMMON.CONFIRMATION'),
            subHeader: '',
            description: t('COMMON.CONFIRMATION_FOR_STATUS_UPDATE', {
                status: rowData.isBillable ? t('TASKS.NON_BILLABLE') : t('TASKS.BILLABLE'),
                table_name: t('TASKS.TASK_MODE') + ' ' + rowData.taskNo
            })
        });
    };

    const isBillableTemplate = (rowData: BillTask) => {
        const isToggleEnabled =
            (isThisStaffUserExcludedFinance || isThisVendorUserExcludedFinance) &&
            !isQuoteCompleted &&
            rowData?.status !== APPROVED;

        return (
            <div className="flex items-center">
                <ToggleSwitch
                    onChange={() => updateMarginEligibleStatus(rowData)}
                    title=""
                    checked={rowData.isBillable ?? false}
                    valueText={rowData.isBillable ? t('COMMON.YES') : t('COMMON.NO')}
                    isToggleDisabled={!isToggleEnabled}
                />
            </div>
        );
    };

    const dateBodyTemplate = (rowData: BillTask, fieldName: string, minDate?: Date | null) => {
        return (
            <DateFieldTableCellEditor
                value={String(rowData[fieldName as keyof BillTask] ?? '')}
                fieldName={fieldName}
                id={String(rowData.billId)}
                minDate={minDate || null}
                responseIndicate={function (): void {
                    getBillsList(requestBody);
                }}
                isEditable={
                    (isThisStaffUserExcludedFinance || isThisVendorUserExcludedFinance) &&
                    rowData?.status !== APPROVED
                }
            />
        );
    };

    let columnNumber = 1;
    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskNo',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Link,
            body: taskIDTemplate,
            columnNumber: columnNumber++,
            frozen: true,
            alignFrozen: 'left',
            visibility: true
        },
        {
            field: 'taskName',
            header: 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: taskTitleTemplate,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'isBillable',
            header: 'Billable',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: isBillableTemplate,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'vendorName',
            header: 'Vendor',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: vendorNameTemplate,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'taskStatus',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: statusTemplate,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'sourceFileName',
            header: 'Source File',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: columnNumber++,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'targetCountryFlagName',
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'vendorReferenceNumber',
            header: 'Vendor Ref Number',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'taskDueDate',
            header: 'Task Due Date',
            sortable: true,
            filter: true,
            filterType: FilterType.Calendar,
            valueType: ValueType.Date,
            columnNumber: columnNumber++,
            visibility: true,
            body: (rowData: BillTask) => dateBodyTemplate(rowData, 'taskDueDate', new Date())
        },
        {
            field: 'unit',
            header: 'Unit',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true,
            body: (rowData: BillTask) => (
                <TaskUnitEdit
                    parentModule="BILLS_TASKS"
                    taskUnitId={rowData.unitId}
                    unitName={rowData.unit}
                    billID={rowData.billId}
                    catchUp={() => {
                        getBillsList(requestBody);
                        getOrderDetailsAPI?.();
                        showToastMessage({
                            message: t(`QUOTE_AND_ORDER.SUCCESS_MESSAGE.UNIT_UPDATED_SUCCESSFULLY`),
                            type: ToastType.SUCCESS
                        });
                    }}
                    handleParent={{
                        isFromParent: true,
                        dropdownOptions: handleGetUnitDropDownOptions(rowData.taskTypeId)
                    }}
                    isEditable={
                        (isThisStaffUserExcludedFinance || isThisVendorUserExcludedFinance) &&
                        rowData.status !== APPROVED &&
                        !!rowData.vendorId
                    }
                />
            )
        },
        {
            field: 'quantity',
            header: 'Quantity',
            sortable: true,
            filter: false,
            body: quantityTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'rate',
            header: 'Rate',
            sortable: true,
            filter: false,
            body: rateTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'rateLabelName',
            header: 'Rate Label Name',
            sortable: true,
            filter: true,
            body: rateLabelNameTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            visibility: true
        },
        {
            field: 'minimumCharge',
            header: 'Min. Charge',
            sortable: true,
            filter: false,
            body: miChargeTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            cellStyle: 'text-right',
            visibility: true
        },
        {
            field: 'amountVendorProfileCurrency',
            header: 'Amount (Vendor Currency)',
            sortable: true,
            filter: false,
            body: amountVendorCurrencyTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'fxRate',
            header: 'FX Rate',
            sortable: true,
            filter: false,
            body: fxRateTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'amount',
            header: 'Amount (USD)',
            sortable: true,
            filter: false,
            body: amountTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: columnNumber++,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        }
    ];

    // if isNonIP remove SourceFileName column in table
    if (!isNonIP) {
        columnSchema.splice(
            columnSchema.findIndex((col) => col.field === 'sourceFileName'),
            1
        );
    }

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.TASK_MANAGEMENT,
        filters: {
            taskNo: { value: null, matchMode: FilterMatchMode.CONTAINS },
            sourcelanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetLanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetCountry: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            vendorName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            unit: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            taskName: { value: null, matchMode: FilterMatchMode.IN },
            taskStatus: { value: null, matchMode: FilterMatchMode.IN }
        },
        reOrderableColumns: true,
        title: '',
        emptyMessage,
        editTable: {
            editType: '',
            rowEditComplete() {},
            isRowEdit: true
        },
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.ORDER_DETAILS_BILL_TASK,
        lazyLoad: false,
        columns: columnSchema,
        hideColumnSelector: true,
        customTableHeight: false,
        isEditColumn: false
    };

    useEffect(() => {
        getStatusList();
        getGroupingAbilities();
    }, []);

    useEffect(() => {
        getBillsList(requestBody);
    }, [requestBody, statusName, patentCountResponse, countryEditResponse]);

    const handleCancel = () => {
        setShowPopup({ ...popupContentInit });
    };

    const handleConfirm = () => {
        try {
            if (
                showPopup.requestFunctionType ===
                CONFIRMATION_POPUP_REQUEST_TYPE_ID.TASK_STATUS_CHANGE
            ) {
                setShowPopup({ ...popupContentInit });
                updateTaskStatus(taskId, statusId);
            } else if (
                showPopup.requestFunctionType === CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN
            ) {
                setShowPopup({ ...popupContentInit });
                const taskID = showPopup?.taskId;
                const data = JSON.parse(showPopup.data);
                const assignee = data.assigneeId;
                const vendorBreakDownId: number = data.vendorBreakDownId;

                updateAssignee(+taskID, +assignee, vendorBreakDownId);
            } else if (
                showPopup.requestFunctionType ===
                CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN_VALIDATION
            ) {
                setShowPopup({ ...popupContentInit });
                const data = JSON.parse(showPopup.data);
                const _taskId: number = data?.task?.taskId ?? null;
                const assigneeId: number = data.assigneeId;
                const vendorBreakDownId: number = data.vendorBreakDownId;

                triggerVendorChangeProcess(_taskId, assigneeId, vendorBreakDownId);
            } else if (
                showPopup.requestFunctionType ===
                CONFIRMATION_POPUP_REQUEST_TYPE_ID.VENDOR_ASSIGN_WITHOUT_DESC
            ) {
                setShowPopup({ ...popupContentInit });
                const data: { task: Task; assigneeInfo: VendorModal } = JSON.parse(showPopup.data);

                handleVendorAssignChange(
                    { ...data.task, proceedWithoutDesc: true },
                    data.assigneeInfo
                );
            }
        } catch (error) {
            console.error('Error in handleConfirm() in BillsTask: ', error);
        }
    };

    const registerFunctionsToStore = () => {
        /** register the functions on store while trigger the action buttons from footer component. */
        quoteOrderModuleStore.registerFunction('refreshBillTasksList', getBillsListWrapper);
    };
    const resetRegisteredFunctionsOnStore = () => {
        /** remove the registered function on store to avoid unwanted calls. */
        quoteOrderModuleStore.registerFunction('refreshBillTasksList', () => {});
    };
    useEffect(() => {
        registerFunctionsToStore();
        return () => {
            resetRegisteredFunctionsOnStore();
        };
    }, []);

    const isStatusConfirmValid = (): boolean => {
        if (showPopup.statusId === TASK_STATUS.APPROVED) {
            if ((showPopup.vendorCurrencyAmount || 0) > 0) {
                return (
                    statusConfirmCheckList.isDeliverablesReviewed &&
                    statusConfirmCheckList.isBillingCalculationCorrect
                );
            } else if ((showPopup.vendorCurrencyAmount || 0) === 0 && showPopup.isBillable) {
                return statusConfirmCheckList.isBillGenerationSkipped;
            }
        }
        return true;
    };

    return (
        <div className="grid grid-cols-1 gap-4 mt-3">
            {visible && (
                <ConfirmationPopup
                    onConfirm={handleConfirm}
                    onCancel={handleCancel}
                    acceptLabel={showPopup.acceptButtonLabel || undefined}
                    rejectLabel={showPopup.rejectButtonLabel || undefined}
                    headerText={header}
                    subHeaderText={subHeader}
                    {...{ visible, description }}
                    customWidth={
                        showPopup.statusId === TASK_STATUS.APPROVED
                            ? ' lg:!w-[30%] lg:!min-w-max md:!w-[40%] md:!min-w-max'
                            : undefined
                    }
                    acceptButtonDisabled={
                        showPopup.statusId === TASK_STATUS.APPROVED && !isStatusConfirmValid()
                    }
                />
            )}
            {showConfirmationPopup.visible && (
                <ConfirmationPopup
                    onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                    onCancel={() => handleConfirmationCancel()}
                    visible={showConfirmationPopup.visible}
                    headerText={showConfirmationPopup.header}
                    subHeaderText={showConfirmationPopup.subHeader}
                    description={showConfirmationPopup.description}
                />
            )}
            <DataTableComponent
                tableData={tableData ?? BillTasksMock?.orderBills ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={requestBody}
                handleFilter={setRequestBody}
                toggleRowData={() => {}}
                rowExpansionTemplate={rowExpansionTemplate}
                expandedRows={expandedRows}
                handlePagination={setRequestBody}
                tablePaginationData={paginationInfo}
                showPagination={true}
                handleSort={setRequestBody}
                showHeader={false}
                dataKey={'taskId'}
                selectableRows={isThisStaffUserExcludedFinance || isThisVendorUserExcludedFinance}
                selectedItems={taskSelection?.selectedTasks}
                restrictedRowsToSelect={taskSelection?.restrictedRowsToSelect}
                isAllSelected={taskSelection?.isAllTasksSelected}
                handleSelectedItems={(e: BillTask[]) =>
                    taskSelection?.handleSelectedTasks(e, tableData ?? [])
                }
                handleSelectAllItems={(e: boolean) =>
                    taskSelection?.handleSelectAllTasks(e, tableData ?? [])
                }
            />
        </div>
    );
};

export default BillsTasks;
