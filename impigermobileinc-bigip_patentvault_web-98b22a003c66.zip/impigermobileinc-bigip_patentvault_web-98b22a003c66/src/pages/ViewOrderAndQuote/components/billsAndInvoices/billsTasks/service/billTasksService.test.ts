import HttpService from 'core/interceptor/api.handler';

import billTasksService from './billTasksService';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getBillsBreakDownList', () => {
        const taskId = 1;
        const file = {};
        it('should fetch getBillsBreakDownList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await billTasksService.getBillsBreakDownList(taskId, file, '');
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(billTasksService.getBillsBreakDownList(taskId, file, '')).rejects.toThrow(
                mockError
            );
        });
    });
});
