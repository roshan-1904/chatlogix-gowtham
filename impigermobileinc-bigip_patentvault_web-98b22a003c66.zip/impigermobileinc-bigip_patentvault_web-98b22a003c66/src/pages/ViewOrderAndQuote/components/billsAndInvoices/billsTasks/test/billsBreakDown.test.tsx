import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { AxiosError, AxiosResponse } from 'axios';
import BillsBreakDown from '../billsBreakDown';
import { getBillsBreakDownList } from '../service/billTasksService';
import { showToastMessage } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import BillsMockData from '../data/billsTasks.mock.json';
import { BillTask } from '../types/billsTasks.type';
import { formatCurrency } from 'core/utils/utils';

// Mock the necessary modules and functions
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('../service/billTasksService');
jest.mock('pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper');

describe('BillsBreakDown Component', () => {
    // Extract mock data for testing
    const mockSelectedRowData: BillTask = {
        ...BillsMockData.orderBills[0],
        children: BillsMockData.orderBills[0].children,
        breakdownData: ''
    };

    const mockOnUploaded = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('renders component and table with data', () => {
        render(
            <BillsBreakDown
                selectedRowData={mockSelectedRowData}
                uploadUrl=""
                onUploaded={mockOnUploaded}
                deleteFileUrl={''}
                breakdownType="bill"
            />
        );

        // Check if the upload button is rendered
        expect(screen.getByTestId('upload-button')).toBeInTheDocument();

        // Check if the table is rendered with the correct data
        expect(screen.getByText('Repetition')).toBeInTheDocument();
        expect(screen.getByText('11%')).toBeInTheDocument();
        expect(screen.getByText('110.00')).toBeInTheDocument();
        expect(screen.getByText('1,080.00')).toBeInTheDocument();
        expect(screen.getByText('95-99%')).toBeInTheDocument();
        expect(screen.getByText('85-94%')).toBeInTheDocument();
        expect(screen.getByText('75-84%')).toBeInTheDocument();
        expect(screen.getByText('50-74%')).toBeInTheDocument();
        expect(screen.getByText('No Match')).toBeInTheDocument();
    });

    test('calculates total amount correctly', () => {
        render(
            <BillsBreakDown
                selectedRowData={mockSelectedRowData}
                uploadUrl=""
                onUploaded={mockOnUploaded}
                deleteFileUrl={''}
                breakdownType="bill"
            />
        );

        // Total amount from mock data
        const totalAmount: number = BillsMockData.orderBills[0].children.reduce(
            (total, breakdown) => total + Number(breakdown.amount || 0),
            0
        );

        // Check if the total amount is calculated and displayed correctly
        expect(screen.getByText(`$ ${formatCurrency(totalAmount)}`)).toBeInTheDocument();
    });

    test('handles file upload correctly', async () => {
        const mockFile = new File(['dummy content'], 'test.csv', { type: 'text/csv' });
        (getBillsBreakDownList as jest.Mock).mockResolvedValue(mockSelectedRowData.children);

        render(
            <BillsBreakDown
                selectedRowData={mockSelectedRowData}
                uploadUrl=""
                onUploaded={mockOnUploaded}
                deleteFileUrl={''}
                breakdownType="bill"
            />
        );

        // Simulate file upload
        fireEvent.change(screen.getByTestId('file-upload'), { target: { files: [mockFile] } });

        await waitFor(() => {
            expect(getBillsBreakDownList).toHaveBeenCalledWith(
                mockSelectedRowData.taskId,
                mockFile
            );
            expect(showToastMessage).toHaveBeenCalledWith(
                'File_UPLOAD.UPLOAD_SUCCESS_TOAST',
                'success'
            );
            expect(mockOnUploaded).toHaveBeenCalled();
        });
    });

    test('shows error message for invalid file type', () => {
        const mockFile = new File(['dummy content'], 'test.txt', { type: 'text/plain' });

        render(
            <BillsBreakDown
                selectedRowData={mockSelectedRowData}
                uploadUrl=""
                onUploaded={mockOnUploaded}
                deleteFileUrl={''}
                breakdownType="bill"
            />
        );

        // Simulate file upload with invalid file type
        fireEvent.change(screen.getByTestId('file-upload'), { target: { files: [mockFile] } });

        expect(showToastMessage).toHaveBeenCalledWith(
            'File_UPLOAD.INVALID_DOCUMENT_UPLOAD_CSV_REQUIRED',
            'error'
        );
    });

    test('shows error message on API failure', async () => {
        const mockFile = new File(['dummy content'], 'test.csv', { type: 'text/csv' });

        // Create a mock AxiosError object with required properties
        const mockError = new AxiosError('Error message', 'ERR_BAD_REQUEST', undefined, undefined, {
            data: { Message: 'API Error' }, // Custom error message
            status: 400,
            statusText: 'Bad Request',
            headers: {},
            config: {}
        } as AxiosResponse<unknown, any>);

        // Mock the function to reject with the mock error
        (getBillsBreakDownList as jest.Mock).mockRejectedValue(mockError);

        render(
            <BillsBreakDown
                selectedRowData={mockSelectedRowData}
                uploadUrl=""
                onUploaded={mockOnUploaded}
                deleteFileUrl={''}
                breakdownType="bill"
            />
        );

        // Simulate file upload
        fireEvent.change(screen.getByTestId('file-upload'), { target: { files: [mockFile] } });

        await waitFor(() => {
            // Check if the correct error message is shown
            expect(showToastMessage).toHaveBeenCalledWith('API Error', 'error');
        });
    });
});
