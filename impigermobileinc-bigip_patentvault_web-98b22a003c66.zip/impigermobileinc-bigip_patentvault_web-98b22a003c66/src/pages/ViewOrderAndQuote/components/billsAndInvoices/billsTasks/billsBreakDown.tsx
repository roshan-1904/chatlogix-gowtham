import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AxiosError } from 'axios';
import { FilterMatchMode } from 'primereact/api';
import { RequestStatusEnum, TableTypes } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import {
    convertToValidNumber,
    formatCurrency,
    isAdminUser,
    isProjectManagerUser
} from 'core/utils/utils';
import uploadIcon from 'assets/svgs/upload-icon.svg';
import { default as deleteIcon } from 'assets/images/delete-icon.svg';
import { showToastMessage } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import {
    getBillsBreakDownList,
    deleteMemoQFile,
    saveNoMatchWordCountValue
} from './service/billTasksService';
import { InvoiceData } from '../invoiceTasks/types/invoice.types';
import { BillTask, BillsBreakDownType } from './types/billsTasks.type';
import { EditableField } from '../invoiceTasks/invoiceTasks';
import { END_POINT } from 'constants/endPoint';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';

const { APPROVED } = RequestStatusEnum;
const quoteBaseUrl = process.env.REACT_APP_QUOTE_BASE_URL ?? '';
const noMatchWordCountUpdateUrl = `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_TASK_TRANSLATION_NO_MATCH_WORD_COUNT}`;
const BillsBreakDown: React.FC<{
    getOrderDetailsAPI?: () => Promise<void>;
    selectedRowData: BillTask | InvoiceData;
    onUploaded?: () => Promise<void>;
    uploadUrl: string;
    deleteFileUrl: string;
    isShowUploadButton?: boolean;
    isShowDeleteBreakdownFile?: boolean;
    breakdownType: 'bill' | 'invoice';
}> = ({
    selectedRowData,
    getOrderDetailsAPI,
    onUploaded = () => {},
    uploadUrl,
    deleteFileUrl,
    isShowUploadButton = true,
    isShowDeleteBreakdownFile = false,
    breakdownType
}) => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisAdminUser = isAdminUser(loggedInUserId);
    const isThisProjectManagerUser = isProjectManagerUser(loggedInUserId);

    isShowUploadButton = true; // show upload button by default
    isShowDeleteBreakdownFile = deleteFileUrl !== '';
    const { t } = useTranslation();
    const [fileInputKey, setFileInputKey] = useState(Date.now());
    const [billsBreakdownList, setBillsBreakdownList] = useState<BillsBreakDownType[]>(
        selectedRowData.children
    );

    const deleteBreakdownFile = async (taskId: number) => {
        try {
            await deleteMemoQFile(taskId, deleteFileUrl);
            showToastMessage(t('QUOTE_AND_ORDER.SUCCESS_DELETE_BREAKDOWN_FILE'), ToastType.SUCCESS);
            setBillsBreakdownList([]);
            onUploaded();
            getOrderDetailsAPI?.();
        } catch (e: unknown) {
            const errorMessage: string =
                e instanceof AxiosError && e.response?.data?.Message
                    ? e.response.data.Message
                    : t('QUOTE_AND_ORDER.FAILED_DELETE_BREAKDOWN_FILE');
            showToastMessage(errorMessage, ToastType.ERROR);
        }
    };

    const getBillsBreakDown = async (file: File, taskId: number) => {
        try {
            const response: BillsBreakDownType[] = await getBillsBreakDownList(
                taskId,
                file,
                uploadUrl
            );
            showToastMessage(t('File_UPLOAD.UPLOAD_SUCCESS_TOAST'), ToastType.SUCCESS);
            setBillsBreakdownList(response);
            onUploaded();
            getOrderDetailsAPI?.();
        } catch (e: unknown) {
            const errorMessage: string =
                e instanceof AxiosError && e.response?.data?.Message
                    ? e.response.data.Message
                    : t('File_UPLOAD.INVALID_DOCUMENT_UPLOAD');
            showToastMessage(errorMessage, ToastType.ERROR);
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, taskId: number) => {
        const file = event.target.files?.[0];
        setFileInputKey(Date.now());
        if (file) {
            // Check if file type is CSV or Excel-related MIME type
            const isCSV = file.type === 'text/csv' || file.type === 'application/vnd.ms-excel';

            // Optionally, check file extension as well
            const isCSVFile = file.name.toLowerCase().endsWith('.csv');

            if (isCSV || isCSVFile) {
                getBillsBreakDown(file, taskId);
            } else {
                showToastMessage(
                    t('File_UPLOAD.INVALID_DOCUMENT_UPLOAD_CSV_REQUIRED'),
                    ToastType.ERROR
                );
            }
        }
    };

    const renderUploadBtn = () => {
        return (
            <div className="absolute right-[3px] top-[-2px] gap-2 flex items-center">
                {isShowDeleteBreakdownFile && (
                    <div className="flex items-center justify-center ml -2">
                        <label
                            htmlFor={'delete-breakdown' + fileInputKey}
                            data-testid={'delete-breakdown' + fileInputKey}
                            className="btn btn-sm text-primary bg-white border-primary text-base"
                            onClick={() => {
                                deleteBreakdownFile(selectedRowData.taskId);
                            }}>
                            <img src={deleteIcon} alt="delete-icon" className="h-3.5 min-w-4" />
                            <span className="hidden sm:inline">
                                {t('COMMON.DELETE_BREAKDOWN_FILE')}{' '}
                            </span>
                        </label>
                    </div>
                )}
                {isShowUploadButton && (
                    <div className="flex items-center justify-center">
                        <label
                            htmlFor={'file-upload' + fileInputKey}
                            data-testid={'upload-button' + fileInputKey}
                            className="btn btn-sm text-primary bg-white border-primary">
                            <img src={uploadIcon} alt="upload-icon" />
                            <span className="hidden sm:inline">{t('File_UPLOAD.UPLOAD')}</span>
                        </label>
                        <input
                            key={fileInputKey}
                            id={'file-upload' + fileInputKey}
                            data-testid={'file-upload-' + fileInputKey}
                            type="file"
                            className="hidden"
                            accept=".csv"
                            onChange={(e) => {
                                handleFileChange(e, selectedRowData.taskId);
                            }}
                        />
                    </div>
                )}
            </div>
        );
    };

    const calculateTotalAmount = (invoiceItem: BillsBreakDownType[]) => {
        return invoiceItem.reduce((total, invoice) => {
            return total + Number(invoice?.amount || 0);
        }, 0);
    };

    useEffect(() => {
        setBillsBreakdownList(selectedRowData.children);
    }, [selectedRowData]);

    const wordCountTemplate = (rowData: BillsBreakDownType) => {
        function OnSave(newValue: number) {
            saveNoMatchWordCountValue(
                selectedRowData.taskId,
                newValue,
                noMatchWordCountUpdateUrl
            ).then(() => {
                setBillsBreakdownList([]);
                onUploaded();
                getOrderDetailsAPI?.();
            });
        }
        return rowData.breakdownName.toLowerCase() === 'no match' &&
            (isThisAdminUser || isThisProjectManagerUser) &&
            breakdownType === 'bill' &&
            selectedRowData.status !== APPROVED ? (
            <EditableField
                fieldName="wordCount"
                fieldValue={rowData.wordCount || 0}
                currency={''}
                onSave={OnSave}
                canEditFields={true}
                showRefreshIcon={false}
            />
        ) : (
            <span>{rowData.wordCount}</span>
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'breakdownName',
            header: 'Breakdown',
            sortable: true,
            filter: false,
            columnNumber: 1,
            visibility: true
        },
        {
            field: 'percentage',
            header: 'Percentage',
            sortable: true,
            filter: false,
            body(rowData: BillsBreakDownType) {
                return rowData?.percentage ? `${rowData?.percentage}%` : '-';
            },
            columnNumber: 2,
            visibility: true
        },
        {
            field: 'rate',
            header: 'Rate',
            sortable: true,
            filter: false,
            body: (rowData: BillsBreakDownType) =>
                convertToValidNumber({
                    value: rowData.rate || 0,
                    decimalLength: 4,
                    renderAs: 'string'
                }),
            columnNumber: 3,
            cellStyle: 'text-right',
            headerStyle: 'justify-end',
            visibility: true
        },
        {
            field: 'wordCount',
            header: 'Word Count',
            sortable: true,
            filter: false,
            columnNumber: 4,
            cellStyle: 'text-right',
            headerStyle: 'justify-end',
            visibility: true,
            body: wordCountTemplate
        },
        {
            field: 'amount',
            header: 'Amount',
            sortable: true,
            filter: false,
            body: (rowData: BillsBreakDownType) => formatCurrency(+rowData?.amount || 0),
            columnNumber: 5,
            cellStyle: 'text-right',
            headerStyle: 'justify-end',
            visibility: true
        }
    ];

    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.TASK_MANAGEMENT,
        filters: {
            taskNo: { value: null, matchMode: FilterMatchMode.CONTAINS },
            sourcelanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetLanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetCountry: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            vendorName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            unit: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            taskName: { value: null, matchMode: FilterMatchMode.IN },
            taskStatus: { value: null, matchMode: FilterMatchMode.IN }
        },
        reOrderableColumns: true,
        title: 'Breakdown',
        titleStyle: 'text-primary',
        headerCellStyle: '!bg-white !py-4',
        headerWrapperStyle: '!bg-neutral-800',
        emptyMessage: '',
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.BILL_BREAKDOWN_COLUMN_ORDERS + fileInputKey,
        showFilter: false,
        lazyLoad: false,
        columns: columnSchema,
        hideColumnSelector: true,
        tableCustomStyle: '!bg-neutral-800 rounded-lg p-1',
        buttonChildren: renderUploadBtn(),
        renderChildrenAlone: true,
        customTableHeight: false
    };
    return (
        <div className="!w-fit !min-w-[55%]">
            <DataTableComponent
                dataKey={'billTable_' + fileInputKey}
                isLazy={false}
                key={'billTable_' + fileInputKey}
                tableData={billsBreakdownList ?? []}
                tableDefinition={tableDefinition}
                tableRequestBodyData={{
                    searchModels: [],
                    sorting: {
                        propertyName: '',
                        value: ''
                    },
                    pageNo: 0,
                    pageCount: 0
                }}
                toggleRowData={() => {}}
            />
            {billsBreakdownList?.length > 0 && (
                <div className="flex justify-end mr-1">
                    <div className="w-fit mt-[-10px] min-w-[18.3%] bg-[#ECECEC] shadow-md p-4 px-2 flex justify-between items-center gap-2 mr-2.5">
                        <p className="text-base font-semibold">{t('COMMON.TOTAL')}</p>
                        <div className="flex items-center text-base font-semibold gap-2">
                            <p>
                                {`${'amountVendorProfileCurrencySymbol' in selectedRowData ? selectedRowData?.amountVendorProfileCurrencySymbol : ''}`}
                            </p>
                            <p>
                                {`${formatCurrency(calculateTotalAmount(billsBreakdownList || []))}`}
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BillsBreakDown;
