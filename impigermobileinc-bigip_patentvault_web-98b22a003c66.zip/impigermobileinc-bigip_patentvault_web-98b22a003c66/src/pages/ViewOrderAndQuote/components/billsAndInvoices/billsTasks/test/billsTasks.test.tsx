import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { BrowserRouter } from 'react-router-dom';
import BillsTasks from '../billsTasks';
import { getTableData, getVendorList } from '../../invoiceTasks/service/invoiceTasksService';
import taskManagementService from 'pages/taskManagement/service/taskManagement.service';
import BillsMockData from '../data/billsTasks.mock.json';
import { GetBillsListApiResponse } from '../types/billsTasks.type';
import { StatusType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';

// Mock necessary modules and functions
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useParams: () => ({
        requestId: '8031'
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

jest.mock('../../invoiceTasks/service/invoiceTasksService');
jest.mock('pages/taskManagement/service/taskManagement.service');
jest.mock('core/utils/utils');
jest.mock('components/confirmationPopup/confirmationPopup');
jest.mock('pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper');

describe('Bills Component(Bills & Invoice)', () => {
    const mockBillsData: GetBillsListApiResponse = {
        orderBills: BillsMockData.orderBills,
        total: BillsMockData.total || 0
    };
    const mockStatusList: StatusType[] = [
        {
            id: 9,
            name: 'Not Started',
            statusType: 3
        },
        {
            id: 10,
            name: 'Accepted',
            statusType: 3
        },
        {
            id: 11,
            name: 'Rejected',
            statusType: 3
        },
        {
            id: 12,
            name: 'In Progress',
            statusType: 3
        },
        {
            id: 28,
            name: 'Document Rejected',
            statusType: 3
        },
        {
            id: 13,
            name: 'On Hold',
            statusType: 3
        },
        {
            id: 14,
            name: 'Completed',
            statusType: 3
        },
        {
            id: 15,
            name: 'Approved',
            statusType: 3
        },
        {
            id: 16,
            name: 'Proposed',
            statusType: 3
        },
        {
            id: 17,
            name: 'In Review',
            statusType: 3
        }
    ];
    const mockVendorList = [
        { id: 1, name: 'Vendor A' },
        { id: 2, name: 'Vendor B' }
    ];

    beforeEach(() => {
        (getTableData as jest.Mock).mockResolvedValue(mockBillsData);
        (taskManagementService.getStatusList as jest.Mock).mockResolvedValue(mockStatusList);
        (getVendorList as jest.Mock).mockResolvedValue(mockVendorList);
    });

    test('renders bills component', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(1);
        });
    });

    test('renders component and table with cols', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );
        await waitFor(() => {
            expect(screen.getByText('Task ID')).toBeInTheDocument();
            expect(screen.getByText('Task/Abilities')).toBeInTheDocument();
            expect(screen.getByText('Vendor')).toBeInTheDocument();
            expect(screen.getByText('Rate')).toBeInTheDocument();
            expect(screen.getByText('Amount (Vendor Profile Currency)')).toBeInTheDocument();
        });
    });

    test('renders component and table with data', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );
        const { taskNo, taskName, sourceLanguage, targetLanguage } = mockBillsData.orderBills[0];

        // Wait for async data to load
        await waitFor(() => {
            [taskNo, taskName, sourceLanguage, targetLanguage].forEach((fields) => {
                expect(screen.getByText(fields)).toBeInTheDocument();
            });
        });
    });

    test.skip('expands and collapses row details', async () => {
        (getTableData as jest.Mock).mockResolvedValue(mockBillsData);
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Simulate expanding a row
        fireEvent.click(screen.getByTestId('bills-breakdown'));
        await waitFor(() => {
            expect(screen.getByText('Repetition')).toBeInTheDocument();
        });

        // Simulate collapsing a row
        fireEvent.click(screen.getByTestId('bills-breakdown'));
        await waitFor(() => {
            expect(screen.queryByText('Repetition')).not.toBeInTheDocument();
        });
    });

    test('handles pagination', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(mockBillsData?.orderBills?.[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Last Page" button (>>)
        fireEvent.click(screen.getByLabelText('Last Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });

        // Simulate clicking the "First Page" button (<<)
        fireEvent.click(screen.getByLabelText('First Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(3);
        });
    });

    test('handles specific page link', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(mockBillsData?.orderBills?.[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Page 2" button
        fireEvent.click(screen.getByLabelText('Page 2'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles sorting', async () => {
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('R240726-38-TRA-GER')).toBeInTheDocument();
        });

        fireEvent.click(screen.getByText('Task ID'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles error state', async () => {
        (getTableData as jest.Mock).mockRejectedValueOnce(new Error('Failed to fetch'));

        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_BILLS_FOUND')).toBeInTheDocument();
        });
    });

    test('renders empty message when no data is available', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderBills: [], total: 0 });
        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_BILLS_FOUND')).toBeInTheDocument();
        });
    });

    test('renders pagination buttons as disabled with no items', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderBills: [], total: 0 });

        render(
            <BrowserRouter>
                <BillsTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            // Ensure no data is rendered
            expect(
                screen.queryByText(mockBillsData?.orderBills?.[0]?.taskNo)
            ).not.toBeInTheDocument();

            // Check if pagination buttons are disabled
            expect(screen.getByLabelText('First Page')).toBeDisabled();
            expect(screen.getByLabelText('Last Page')).toBeDisabled();
            expect(screen.queryByLabelText('Page 2')).not.toBeInTheDocument();
        });
    });
});
