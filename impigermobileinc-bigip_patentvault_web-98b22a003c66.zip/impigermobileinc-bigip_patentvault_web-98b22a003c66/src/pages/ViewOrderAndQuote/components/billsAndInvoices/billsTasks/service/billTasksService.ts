import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';

// Define the quote URL from environment variable
const httpService = new HttpService();

const pvBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;

/**
 * getBillsBreakDownList function to get the bill breakdown items.
 * @param taskId - The taskID of the current bill item.
 * @param file - The file to be uploaded.
 * @returns {Promise<T>} A promise resolving to the Bills breakdown.
 */

export const getBillsBreakDownList = async <T>(
    taskId: number,
    file: any,
    apiUrl: string
): Promise<T> => {
    try {
        const response = await httpService.post<T, any>(apiUrl, { file, taskId }, {}, true);
        return response;
    } catch (error) {
        console.error('Error fetching bills breakdown list:', error);
        throw error;
    }
};

export const saveNoMatchWordCountValue = async <T>(
    taskId: number,
    value: number,
    apiUrl: string
): Promise<T> => {
    try {
        const response = await httpService.post<T, any>(apiUrl, {
            RequestTaskId: taskId,
            WordCount: value
        });
        return response;
    } catch (error) {
        console.error('Error fetching bills breakdown list:', error);
        throw error;
    }
};

export const deleteMemoQFile = async <T>(taskId: number, apiUrl?: string): Promise<T> => {
    try {
        const response = await httpService.delete<T>(apiUrl + `/${taskId}`, {}, true);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

const updateTaskDueDate = async <T>(
    billNo: number,
    payload: { taskDueDate: string }
): Promise<T> => {
    try {
        const response = await httpService.patch<T, typeof payload>(
            `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_BILLS_EDIT_DETAILS}/${billNo}`,
            payload
        );
        return response;
    } catch (error) {
        console.error('Error updating task due date:', error);
        throw error;
    }
};

const billTasksService = { getBillsBreakDownList, updateTaskDueDate };

export default billTasksService;
