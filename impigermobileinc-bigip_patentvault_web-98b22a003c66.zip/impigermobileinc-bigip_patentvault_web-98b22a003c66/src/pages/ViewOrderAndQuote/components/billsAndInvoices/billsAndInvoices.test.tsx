import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { BrowserRouter } from 'react-router-dom';
import BillsAndInvoices from './billsAndInvoices';
import AuthStore from 'core/store/authStore/authStore';

// Mocking modules
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useParams: () => ({
        requestId: '6787'
    })
}));

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

// Mock AuthStore
jest.mock('core/store/authStore/authStore', () => ({
    getUserInfo: jest.fn(() => ({
        userInfo: {
            userFullName: 'John Doe',
            role: 'Admin',
            roleId: 1,
            permissions: ['createtask']
        }
    })),
    logout: jest.fn(),
    hasPermission: jest.fn((permission) => permission === 'createtask')
}));

jest.mock('core/store/notificationStore/notificationStore', () => ({
    showAlert: jest.fn()
}));

describe('BillsAndInvoices Component', () => {
    const mockGetOrderDetailsAPI = jest.fn().mockResolvedValue(Promise.resolve());

    beforeEach(() => {
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: { roleId: 1 }
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders component with default props', () => {
        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Check tab headers
        expect(screen.getByText('Invoice Tasks')).toBeInTheDocument();
        expect(screen.queryByText('Bill Tasks')).toBeInTheDocument();
        expect(screen.queryByText('Summary')).toBeInTheDocument();
    });

    test('renders component with Vendor role', () => {
        // Mocking vendor role
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: { roleId: 7 }
        });

        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Check tab headers
        expect(screen.getByText('Invoice Tasks')).toBeInTheDocument();
        expect(screen.getByText('Bill Tasks')).toBeInTheDocument();
        expect(screen.queryByText('Summary')).toBeNull();
    });

    test('renders component with Staff role', () => {
        // Mocking staff role
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: { roleId: 2 }
        });

        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Check tab headers
        expect(screen.getByText('Invoice Tasks')).toBeInTheDocument();
        expect(screen.queryByText('Bill Tasks')).toBeInTheDocument();
        expect(screen.getByText('Summary')).toBeInTheDocument();
    });

    test('shows and hides dropdown', async () => {
        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Click to show dropdown
        fireEvent.click(screen.getByTestId('preview-button'));

        await waitFor(() => {
            expect(screen.getByText('Documents')).toBeVisible();
        });

        // Click to hide dropdown
        fireEvent.click(screen.getByTestId('preview-button'));

        await waitFor(() => {
            expect(screen.queryByTestId('preview-dropdown')).not.toBeInTheDocument();
        });
    });

    test('renders create task button with permission', () => {
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(true);
        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Check if create task button is rendered
        expect(screen.getByTestId('add-task-button')).toBeInTheDocument();
    });

    test('should not render create task button if no permission', () => {
        (AuthStore.hasPermission as jest.Mock).mockReturnValue(false);
        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Check if create task button is rendered
        expect(screen.queryByTestId('add-task-button')).not.toBeInTheDocument();
    });

    test('renders tab switching correctly', async () => {
        render(
            <BrowserRouter>
                <BillsAndInvoices
                    viewData={{}}
                    getOrderDetailsAPI={mockGetOrderDetailsAPI}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        // Switch to 'Bill Tasks' tab
        fireEvent.click(screen.getByText('Bill Tasks'));

        await waitFor(() => {
            const selectedTab = screen.getByRole('tab', { selected: true });
            expect(selectedTab).toHaveAttribute('aria-selected', 'true');
        });

        // Switch to 'Summary' tab
        fireEvent.click(screen.getByText('Summary'));

        await waitFor(() => {
            const selectedTab = screen.getByRole('tab', { selected: true });
            expect(selectedTab).toHaveAttribute('aria-selected', 'true');
        });
    });
});
