import HttpService from 'core/interceptor/api.handler';

import invoiceTasksService from './invoiceTasksService';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getTableData', () => {
        const requestBody = {
            searchModels: [{ propertyName: 'name', value: 'test' }],
            sorting: { propertyName: 'name', value: 'test' },
            pageNo: 1,
            pageCount: 10
        };
        const orderId = '';
        const getBillsList = false;
        const getSummaryList = false;
        it('should fetch getTableData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await invoiceTasksService.getTableData(
                requestBody,
                orderId,
                getBillsList,
                getSummaryList
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                invoiceTasksService.getTableData(requestBody, orderId, getBillsList, getSummaryList)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updateBillsInvoiceFields', () => {
        const id = 1;
        const requestBody = {
            rate: 1,
            amount: 1,
            quantity: 1
        };
        const updateBills = false;
        it('should fetch updateBillsInvoiceFields successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await invoiceTasksService.updateBillsInvoiceFields(
                id,
                requestBody,
                updateBills
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                invoiceTasksService.updateBillsInvoiceFields(id, requestBody, updateBills)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updateTaskDetailsInvoice', () => {
        const taskId = 1;
        const invoiceId = 1;
        it('should fetch getPatentDetails successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await invoiceTasksService.updateTaskDetailsInvoice(taskId, invoiceId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                invoiceTasksService.updateTaskDetailsInvoice(taskId, invoiceId)
            ).rejects.toThrow(mockError);
        });
    });
});
