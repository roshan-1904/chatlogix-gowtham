import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import taskManagementService from 'pages/taskManagement/service/taskManagement.service';
import { VendorModal } from 'pages/taskManagement/tasksList/tasksList';
import { RequestBody } from 'shared/dataTable/types/dataTable.types';
import {
    IDocumentFilesModel,
    InvoiceBillsUpdateFields,
    TaskInvoiceOrQuoteDataTypeToUpdate
} from '../types/invoice.types';

const _httpService = new HttpService();
const quoteURL = process.env.REACT_APP_QUOTE_BASE_URL ?? '';

export const getVendorList = async (taskName: number): Promise<VendorModal[]> => {
    try {
        const response = await taskManagementService.getAssigneeList<VendorModal[]>(taskName);

        if (response && Array.isArray(response)) return response;
        else return [];
    } catch (error) {
        console.error('Error fetching vendor list:', error);
        return [];
    }
};

/**
 * Get Invoice, Bills & Summary table data based on the given request body and order Id.

 * @param {RequestBody} requestBody - The request body.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
export const getTableData = async <T>(
    requestBody: RequestBody,
    orderId = '',
    getBillsList = false,
    getSummaryList = false
): Promise<T> => {
    const {
        ORDERS_AND_QUOTES_END_POINT: { GET_INVOICE_LIST, GET_BILLS_LIST, GET_SUMMARY_LIST }
    } = END_POINT;

    let endpoint = GET_INVOICE_LIST;

    if (getSummaryList) {
        endpoint = GET_SUMMARY_LIST;
    } else if (getBillsList) {
        endpoint = GET_BILLS_LIST;
    }

    const apiUrl = `${endpoint}/${orderId}`;

    try {
        const response = await _httpService.post<T, RequestBody>(
            apiUrl,
            requestBody,
            {},
            false,
            quoteURL
        );
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

/**
 * Sends a PATCH request to update the amount/rate fields in Invoice/Bills.
 * @param id - The ID of the Invoice/Bills to update
 * @param updateBills - Flag to update bills/Invoice
 * @returns {Promise<T>} A promise resolving to the updated Invoice/Bills.
 */
export const updateBillsInvoiceFields = async <T>(
    id: number,
    requestBody: InvoiceBillsUpdateFields,
    updateBills = false
): Promise<T> => {
    const {
        ORDERS_AND_QUOTES_END_POINT: { UPDATE_INVOICE_QUANTITY_RATE_FIELDS, UPDATE_BILLS_FIELDS }
    } = END_POINT;
    const apiUrl = `${quoteURL}${updateBills ? UPDATE_BILLS_FIELDS : UPDATE_INVOICE_QUANTITY_RATE_FIELDS}/${id}`;
    try {
        const response = await _httpService.patch<T, InvoiceBillsUpdateFields>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error updating fields:', error);
        throw error;
    }
};

/**
 * Sends a PATCH request to update the status of a Task detail page.
 * @param taskId - The task Id to update the take details show In Invoice column.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
export const updateTaskDetailsInvoice = async <T>(
    taskId: number,
    invoiceId: number
): Promise<T> => {
    const apiUrl = `${quoteURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_TASK_INVOICE_STATUS}/${taskId}/${invoiceId}`;
    try {
        const response = await _httpService.put<T, number>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

export const updateTaskDetailsQUote = async <T>(
    params: TaskInvoiceOrQuoteDataTypeToUpdate
): Promise<T> => {
    const apiUrl = `${quoteURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_TASK_INVOICE_AND_QUOTE_STATUS}`;
    try {
        const response = await _httpService.patch<T, TaskInvoiceOrQuoteDataTypeToUpdate>(
            apiUrl,
            params
        );
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

export const updateDocumentVendorInvoiceNumber = async <T>(
    url: string,
    params: IDocumentFilesModel
): Promise<T> => {
    try {
        const response = await _httpService.post<T, IDocumentFilesModel>(url, params);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

export const updateDeliveryDate = async <T>(date: string, id: string): Promise<T> => {
    try {
        const apiUrl = `${quoteURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_DELIVERY_DATE}/${id}`;
        const payload = { deliveryDate: date };
        const response = await _httpService.patch<T, { deliveryDate: string }>(apiUrl, payload);
        return response;
    } catch (error) {
        console.error('Error updating delivery date:', error);
        throw error;
    }
};
export const updateFilingDate = async <T>(date: string, id: string): Promise<T> => {
    try {
        const apiUrl = `${quoteURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_INVOICE_FILING_DATE}/${id}`;
        const payload = { filingDate: date };
        const response = await _httpService.patch<T, { filingDate: string }>(apiUrl, payload);
        return response;
    } catch (error) {
        console.error('Error updating delivery date:', error);
        throw error;
    }
};

const invoiceTasksService = {
    getVendorList,
    getTableData,
    updateBillsInvoiceFields,
    updateTaskDetailsInvoice,
    updateTaskDetailsQUote
};

export default invoiceTasksService;
