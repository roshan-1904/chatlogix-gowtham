import { BillsBreakDownType as InvoiceBreakDownType } from '../../billsTasks/types/billsTasks.type';
export interface InvoiceData {
    id: number;
    invoiceId: number;
    sourceLanguageId: number;
    orderRequestNumber: number;
    grandTotal: number;
    taskId: number;
    taskTypeId: number;
    documentId: number;
    unitId: number;
    taskNo: string;
    orderNumber: string;
    taskName: string;
    sourceLanguage: string;
    targetLanguage: string;
    targetCountry: string;
    targetCountryFlagName: string;
    status: string;
    taskStatus: string;
    vendorId: number;
    vendorName: string;
    unit: string;
    rateCurrency: string;
    quantity: number;
    baseCurrencyAmount: number;
    rate: number;
    showInQuote: string;
    showInInvoice: boolean;
    displayShowInInvoice: string;
    isAutoTask: boolean;
    fileName: string;
    documentType: number;
    fileId: number;
    taskRefId: number;
    uploadedOn: string;
    blobFileName: string;
    fileType: string;
    fileSize: string;
    requestCurrencyAmount: number;
    fxRate: string;
    requestCurrencySymbol: string;
    baseCurrencySymbol: string;
    requestCurrencyName: string;
    isBreakdown: boolean;
    isBillable: boolean;
    breakdownData: string;
    children: InvoiceBreakDownType[];
    invoiceProcessedMethod?: string;
}

export interface GetInvoiceListApiResponse {
    total: number;
    orderInvoice: InvoiceData[];
}

export interface InvoiceBillsUpdateFields {
    rate?: number;
    amount?: number;
    quantity?: number;
    unitId?: number;
}

export interface TaskInvoiceOrQuoteDataTypeToUpdate {
    taskId: number;
    isShowInQuoteUpdated: boolean | null;
    isShowInInvoiceUpdated: boolean | null;
    userSelectedValue: boolean;
}

export interface IDocumentFilesModel {
    hardCopyStatusId?: number | null;
    documentStatusId?: number | null;
    poAStatusId?: number | null;

    // Document fields
    documentId: number;
    fileName?: string | null;
    fileType?: string | null;
    fileSize?: string | null;
    orderId?: number | null;
    blobFileName?: string | null;
    documentType?: number | null;
    targetCountryId?: number | null;
    hardCopy?: boolean | null;
    expectedDeliveryDate?: Date | null;
    disPatchAddress?: string | null;
    vendorName?: string | null;
    vendorId?: number | null;
    vendorPhoneNumber?: string | null;
    vendorEmail?: string | null;
    userTypeId?: number | null;
    reCall?: boolean | null;
    fileId?: number | null;
    vendorInvoiceNumber?: string | null;
}

export interface DropdownOption {
    label: string;
    value: string;
    color: string;
    backgroundColor: string;
}

export interface PopupContent {
    visible: boolean;
    header: string;
    subHeader: string;
    description: string | JSX.Element;
    statusId: number;
    statusName: string;
    requestToFunction: number;
    data: string;
    confirmButtonLabel?: string;
    cancelButtonLabel?: string;
}
export interface InputValuesType {
    quantity: number | null;
    rate: number | null;
    targetLanguage: string | null;
    targetCountry: string | null;
    vendorReferenceNumber: string | null;
}
