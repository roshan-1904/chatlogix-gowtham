import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { BrowserRouter } from 'react-router-dom';
import InvoiceTasks from '../invoiceTasks';
import InvoiceMockData from '../data/invoiceTasks.mock.json';
import { getTableData } from '../../invoiceTasks/service/invoiceTasksService';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import { formatCurrency } from 'core/utils/utils';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useParams: () => ({
        requestId: '8167'
    })
}));

jest.mock('../../invoiceTasks/service/invoiceTasksService');

jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (str: string) => str,
        i18n: { changeLanguage: () => new Promise(() => {}) }
    }),
    initReactI18next: { type: '3rdParty', init: jest.fn() }
}));

describe('Invoice List(Bills & Invoice)', () => {
    beforeEach(() => {
        (getTableData as jest.Mock).mockResolvedValue(InvoiceMockData);
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    test('renders Invoice component', async () => {
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        expect(screen.getByText('SUMMARY.GRAND_TOTAL')).toBeInTheDocument();
        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(1);
        });
    });

    test('renders table with correct data', async () => {
        const { taskNo, requestCurrencyAmount, targetLanguage, targetCountry } =
            InvoiceMockData.orderInvoice[0];
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(taskNo)).toBeInTheDocument();
            expect(
                screen.getByText(`$ ${formatCurrency(requestCurrencyAmount || 0)}`)
            ).toBeInTheDocument();
            expect(screen.getByText(targetLanguage)).toBeInTheDocument();
            expect(screen.getByText(targetCountry)).toBeInTheDocument();
        });
    });

    test('handles pagination', async () => {
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(InvoiceMockData.orderInvoice?.[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Last Page" button (>>)
        fireEvent.click(screen.getByLabelText('Last Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });

        // Simulate clicking the "First Page" button (<<)
        fireEvent.click(screen.getByLabelText('First Page'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(3);
        });
    });

    test('handles specific page link', async () => {
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText(InvoiceMockData.orderInvoice?.[0]?.taskNo)).toBeInTheDocument();
        });

        // Simulate clicking the "Page 2" button
        fireEvent.click(screen.getByLabelText('Page 2'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles sorting', async () => {
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(
                screen.getByText(InvoiceMockData?.orderInvoice?.[0]?.taskNo)
            ).toBeInTheDocument();
        });

        fireEvent.click(screen.getByText('Task ID'));

        await waitFor(() => {
            expect(getTableData).toHaveBeenCalledTimes(2);
        });
    });

    test('handles error state', async () => {
        (getTableData as jest.Mock).mockRejectedValueOnce(new Error('Failed to fetch'));

        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_INVOICE_FOUND')).toBeInTheDocument();
        });
    });

    test('renders footer content correctly', async () => {
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('SUMMARY.GRAND_TOTAL')).toBeInTheDocument();
            expect(screen.getByText('$ 4,906.73')).toBeInTheDocument();
        });
    });

    test('renders empty message when no data is available', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderInvoice: [], total: 0 });
        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            expect(screen.getByText('QUOTE_AND_ORDER.NO_INVOICE_FOUND')).toBeInTheDocument();
        });
    });

    test('renders pagination buttons as disabled with no items', async () => {
        (getTableData as jest.Mock).mockResolvedValue({ orderInvoice: [], total: 0 });

        render(
            <BrowserRouter>
                <InvoiceTasks
                    statusName={RequestStatusEnum.TO_BE_PROCESSED}
                    getOrderDetailsAPI={() => Promise.resolve()}
                    patentCountResponse={true}
                    countryEditResponse={true}
                />
            </BrowserRouter>
        );

        await waitFor(() => {
            // Ensure no data is rendered
            expect(
                screen.queryByText(InvoiceMockData.orderInvoice?.[0]?.taskNo)
            ).not.toBeInTheDocument();

            // Check if pagination buttons are disabled
            expect(screen.getByLabelText('First Page')).toBeDisabled();
            expect(screen.getByLabelText('Last Page')).toBeDisabled();
            expect(screen.queryByLabelText('Page 2')).not.toBeInTheDocument();
        });
    });
});
