import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
    FilterType,
    RequestStatusEnum,
    TableTypes,
    ValueType,
    statusIndicators
} from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import {
    ColumnDefinition,
    DataTableDefinition,
    RequestBody,
    paginationData
} from 'shared/dataTable/types/dataTable.types';
import { useTranslation } from 'react-i18next';
import { taskTitleTemplate } from 'pages/taskManagement/tasksList/tasksList';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import refreshIcon from 'assets/svgs/refresh-icon.svg';
import { FilterMatchMode } from 'primereact/api';
import editBlueIcon from 'assets/images/editBlue.svg';
import {
    DropdownOption,
    GetInvoiceListApiResponse,
    InvoiceBillsUpdateFields,
    InvoiceData
} from './types/invoice.types';
import {
    convertToValidNumber,
    formatCurrency,
    isContactUser,
    isFinanceUser,
    isPMorAdminUser,
    isStaffUser,
    isVendorUser,
    showToastMessage
} from 'core/utils/utils';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { StatusType, ViewOrderType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import {
    getPMStatusOptions,
    vendorStatusOptions
} from 'pages/taskManagement/shared/taskManagementHelper';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { REGEX_CONST, SERVICE_TYPES, STATUS_MODE, YES_NO_STRING } from 'constants/app.constant';
import InvoiceBreakDown from '../billsTasks/billsBreakDown';
import { DataTableExpandedRows } from 'primereact/datatable';
import { DATA_STORAGE_KEYS } from 'constants/dataTable.constant';
import {
    getTableData,
    updateBillsInvoiceFields,
    updateTaskDetailsInvoice,
    updateTaskDetailsQUote
} from './service/invoiceTasksService';
import { Permissions } from 'constants/permissions';
import { END_POINT } from 'constants/endPoint';
import { DateFieldTableCellEditor } from 'shared/dataTable/components/dateFieldTableCellEditor/dateFieldTableCellEditor';
import { Tooltip } from 'primereact/tooltip';
import { InputFieldTemplate } from 'components/reuseComponents/constructField';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import FieldValue from 'components/inputs/fieldValue.label';
import { TaskDropDown } from 'pages/users/types/users.types';
import TaskUnitEdit from 'components/reuseComponents/taskUnitEdit';
import taskManagementService from 'pages/taskManagement/service/taskManagement.service';
import OverflowAnchorTagList from 'shared/dataTable/components/overflowAnchorTagList/overflowAnchorTagList';

export const getStatusOptions = (taskStatus: string, statusList: StatusType[]) => {
    const statusOptions =
        AuthStore.getUserInfo().userInfo.roleId === 7
            ? vendorStatusOptions(taskStatus, statusList)
            : getPMStatusOptions(taskStatus, statusList);
    const options: DropdownOption[] = statusOptions?.map((statusData: { name: string }) => ({
        label: statusData?.name,
        value: statusData?.name,
        ...statusIndicators(statusData?.name)
    }));
    return options;
};

export const EditableField = ({
    fieldName,
    fieldValue,
    onSave,
    currency,
    canEditFields = true,
    canFormatFields = true,
    showRefreshIcon = true
}: {
    fieldName: string;
    fieldValue: number;
    onSave: (fieldValue: number) => void;
    currency?: string | null;
    canEditFields?: boolean;
    canFormatFields?: boolean;
    showRefreshIcon?: boolean;
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [value, setValue] = useState<string>(fieldValue ? fieldValue.toString() : '');

    const handleEditClick = () => setIsEditing(true);
    const handleSaveClick = () => {
        setIsEditing(false);
        onSave(+value || 0);
    };
    const handleCancelClick = () => {
        setIsEditing(false);
        setValue(fieldValue.toString());
    };

    const handleChange = (updatedValue: string) => {
        const inputValue = updatedValue;

        // Validate input value: allow only numbers and up to 5 digits after the decimal
        if (REGEX_CONST.NUMERIC_WITH_DECIMALS.test(inputValue)) {
            setValue(inputValue);
        }
    };

    const getDecimalInfo = () => {
        let decimalInfo = { decimal: false, decimalLength: 0 };

        switch (fieldName) {
            case 'quantity':
                decimalInfo = { ...decimalInfo };
                break;
            case 'rate':
                decimalInfo = { decimal: true, decimalLength: 4 };
                break;
            case 'wordCount':
                decimalInfo = { decimal: false, decimalLength: 0 };
                break;
            // column name: total
            case 'amountRequestCurrency':
            case 'amountVendorProfileCurrency':
                decimalInfo = { decimal: true, decimalLength: 2 };
                break;
            default:
                break;
        }

        return decimalInfo;
    };

    useEffect(() => {
        if (value !== fieldValue.toString()) setValue(`${fieldValue}`);
    }, [fieldValue]);

    return (
        <div className="relative group w-full min-w-fit">
            {!isEditing ? (
                <div className={`flex items-center justify-${canFormatFields ? 'end' : 'start'}`}>
                    <div className="flex items-center">
                        <FieldValue
                            value={fieldValue || 0}
                            renderAs={'string'}
                            decimalLength={getDecimalInfo().decimalLength}
                            currency={currency}
                        />
                    </div>
                    {canEditFields && (
                        <div
                            className={`hidden group-hover:flex items-center ml-2 ${showRefreshIcon ? 'min-w-12' : 'min-w-6'}`}>
                            <button
                                onClick={handleEditClick}
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                                <img
                                    src={editBlueIcon}
                                    className="h-4 w-4 cursor-pointer mx-2"
                                    alt="edit-blue-icon"
                                />
                            </button>
                            {showRefreshIcon && (
                                <img
                                    src={refreshIcon}
                                    className="h-4 w-4 cursor-pointer"
                                    alt="refresh-icon"
                                />
                            )}
                        </div>
                    )}
                </div>
            ) : (
                canEditFields && (
                    <div className="flex items-center justify-end">
                        <label className="w-28">
                            <InputFieldTemplate
                                data={{
                                    fieldType: 'input',
                                    inputType: {
                                        type: 'number',
                                        isDecimal: getDecimalInfo().decimal,
                                        decimalLength: getDecimalInfo().decimalLength
                                    },
                                    value,
                                    fieldValue: null,
                                    fieldLabelName: null,
                                    placeholder: null,
                                    onChange: handleChange
                                }}
                            />
                        </label>
                        <button
                            type="button"
                            className="pi pi-times text-error cursor-pointer mx-1"
                            onClick={handleCancelClick}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        />
                        <button
                            type="button"
                            className="pi pi-check text-primary cursor-pointer mx-1"
                            onClick={handleSaveClick}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        />
                    </div>
                )
            )}
        </div>
    );
};

export const VendorInvoiceNumberEdit = ({
    fieldName,
    fieldValue,
    onSave,
    canEditFields = true,
    canFormatFields = true,
    showRefreshIcon = true,
    keyName = ''
}: {
    fieldName: string;
    fieldValue: string;
    onSave: (fieldValue: string) => void;
    canEditFields?: boolean;
    canFormatFields?: boolean;
    showRefreshIcon?: boolean;
    keyName?: string;
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [value, setValue] = useState<string>(fieldValue ? fieldValue.toString() : '');

    const handleEditClick = () => {
        setValue(fieldValue.toString());
        setIsEditing(true);
    };
    const handleSaveClick = () => {
        setIsEditing(false);
        onSave(value);
        setValue('');
    };
    const handleCancelClick = () => {
        setIsEditing(false);
        setValue(fieldValue.toString());
    };

    const handleChange = (updatedValue: string) => {
        const inputValue = updatedValue;

        // Validate input value: allow only numbers and up to 5 digits after the decimal
        if (REGEX_CONST.ALPHANUMERIC_AND_HYPHEN.test(inputValue)) {
            setValue(inputValue);
        }
    };

    useEffect(() => {
        if (value !== fieldValue.toString()) setValue(`${fieldValue}`);
    }, [fieldValue]);

    return (
        <div
            className="relative group w-full min-w-fit"
            data-test-id={`editable-text-field-${fieldName}-${keyName}`}>
            {!isEditing ? (
                <div className={`flex items-center justify-${canFormatFields ? 'end' : 'start'}`}>
                    <div className="flex items-center">
                        <OverflowAnchorTagList
                            tags={
                                fieldValue
                                    ? fieldValue.split(',').map((tag) => ({
                                          text: tag,
                                          value: tag
                                      }))
                                    : []
                            }
                        />
                    </div>
                    {canEditFields && (
                        <div className={`${showRefreshIcon ? 'min-w-12' : 'min-w-6'}`}>
                            <div className={`hidden group-hover:flex items-center ml-2 min-w-full`}>
                                <button
                                    onClick={handleEditClick}
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}>
                                    <img
                                        src={editBlueIcon}
                                        className="h-4 w-4 cursor-pointer mx-2"
                                        alt="edit-blue-icon"
                                    />
                                </button>
                                {showRefreshIcon && (
                                    <img
                                        src={refreshIcon}
                                        className="h-4 w-4 cursor-pointer"
                                        alt="refresh-icon"
                                    />
                                )}
                            </div>
                        </div>
                    )}
                </div>
            ) : (
                canEditFields && (
                    <div className="flex items-center w-full">
                        <InputFieldTemplate
                            data={{
                                fieldType: 'input',
                                inputType: {
                                    type: 'text'
                                },
                                value,
                                fieldValue: null,
                                fieldLabelName: null,
                                placeholder: null,
                                onChange: handleChange
                            }}
                        />
                        <button
                            type="button"
                            className="pi pi-check text-primary cursor-pointer mx-1 ml-2"
                            onClick={handleSaveClick}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        />
                        <button
                            type="button"
                            className="pi pi-times text-error cursor-pointer mx-1"
                            onClick={handleCancelClick}
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        />
                    </div>
                )
            )}
        </div>
    );
};

const InvoiceTasks = ({
    statusName,
    viewData,
    getOrderDetailsAPI,
    isNonIP = false,
    patentCountResponse,
    countryEditResponse,
    triggerGetInvoiceList
}: {
    statusName: string;
    viewData?: ViewOrderType;
    getOrderDetailsAPI: () => Promise<void>;
    isNonIP?: boolean;
    patentCountResponse: any;
    countryEditResponse: any;
    triggerGetInvoiceList?: () => void;
}) => {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [expandedRows, setExpandedRows] = useState<
        DataTableExpandedRows | Record<string, boolean>
    >({});
    const { requestId } = useParams();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const userRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(userRoleId);
    const isThisVendorUser = isVendorUser(userRoleId);
    const isThisContactUser = isContactUser(userRoleId);
    const isThisFinanceUser = isFinanceUser(userRoleId);
    const isThisPMorAdminUser = isPMorAdminUser(userRoleId);
    const isThisVendorUserExcludedFinance = isVendorUser(userRoleId, {
        excludeFinance: true
    });
    const { INVOICED, COMPLETED, APPROVED } = RequestStatusEnum;
    const [showPopup, setShowPopup] = useState({
        visible: false,
        header: t('COMMON.CONFIRMATION'),
        subHeader: '',
        description: t('COMMON.CONFIRMATION_STATUS'),
        statusid: 0,
        taskId: '',
        statusName: ''
    });
    const { visible, header, subHeader, description } = showPopup;
    const [requestBody, setRequestBody] = useState<RequestBody>({
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 1,
        pageCount: 10
    });
    const [tableData, setTableData] = useState<InvoiceData[]>([]);
    const [paginationInfo, setPaginationInfo] = useState<paginationData>();
    const [emptyMessage, setEmptyMessage] = useState<string>(' ');
    const NO_INVOICE_FOUND = t('QUOTE_AND_ORDER.NO_INVOICE_FOUND');
    const hasEditInvoiceTaskPermission = AuthStore.hasPermission(Permissions.EDIT_INVOICE_TASK);
    const statusId = viewData?.headers?.statusId;
    const isSTDFlow = viewData?.requestDetails?.category === 'other_translations';
    const isPreparingQuote = statusId === STATUS_MODE.PREPARING_QUOTE;
    const isCompletedORInvoiced = statusName === INVOICED || statusName === COMPLETED;
    const [groupingAbilities, setGroupingAbilities] = useState<TaskDropDown[]>([]);
    const isUPCOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;

    const getInvoiceListWrapper = () => {
        getInvoiceList(requestBody).catch(() => console.error('Error fetching invoice list'));
    };
    const getInvoiceList = async (body: RequestBody) => {
        try {
            const response: GetInvoiceListApiResponse =
                await getTableData<GetInvoiceListApiResponse>(body, requestId);
            setTableData(response.orderInvoice || []);
            setPaginationInfo({
                pageNo: body.pageNo,
                totalPages: Math.ceil(response.total / body.pageCount),
                totalRecords: response.total
            });
            if (!response?.orderInvoice?.length) {
                setEmptyMessage(NO_INVOICE_FOUND);
            }
        } catch (error) {
            console.error('Error in Companies info fetch:', error);
            setEmptyMessage(NO_INVOICE_FOUND);
        }
    };

    const rowExpansionTemplate = (data: InvoiceData) => {
        const quoteBaseUrl = process.env.REACT_APP_QUOTE_BASE_URL ?? '';
        let uploadUrl = `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.MEMOQ_FILE_UPLOAD}`;

        const isShowDeleteMemoQFile = data.breakdownData !== '' && data.breakdownData !== null;

        // If the invoice task status is completed. we don't allow to delete the breakdown file.
        const deleteBreakdownFileUrl =
            isShowDeleteMemoQFile && statusName !== INVOICED && statusName !== COMPLETED
                ? `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.DELETE_INVOICE_BREAKDOWN_FILE}`
                : '';

        const isShowUploadButton = !isCompletedORInvoiced && !isThisFinanceUser;

        if (isNonIP) {
            uploadUrl = `${quoteBaseUrl}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STANDARD_MEMOQ_FILE_UPLOAD}`;
        }
        return (
            <div className="pl-14 w-2/4">
                {data?.isBreakdown && (
                    <InvoiceBreakDown
                        uploadUrl={uploadUrl}
                        deleteFileUrl={deleteBreakdownFileUrl}
                        getOrderDetailsAPI={getOrderDetailsAPI}
                        selectedRowData={data}
                        onUploaded={async () => {
                            await getInvoiceList(requestBody);
                        }}
                        isShowUploadButton={isShowUploadButton}
                        breakdownType="invoice"
                    />
                )}
            </div>
        );
    };

    const toggleRow = (data: InvoiceData) => {
        const expandedRowsCopy = { ...expandedRows };
        if (expandedRowsCopy[data.taskId]) {
            delete expandedRowsCopy[data.taskId];
        } else {
            expandedRowsCopy[data.taskId] = true;
        }
        setExpandedRows(expandedRowsCopy);
    };

    const updateInvoiceInlineFields = async (
        invoiceId: number,
        fields: InvoiceBillsUpdateFields,
        toastMsg = { success: 'RATE_UPDATED_SUCCESSFULLY', error: 'RATE_UPDATED_FAILED' }
    ) => {
        const errMsg = t(`QUOTE_AND_ORDER.ERROR_MESSAGE.${toastMsg?.error}`);
        try {
            const response = await updateBillsInvoiceFields(invoiceId, fields);
            if (response) {
                getInvoiceList(requestBody);
                await getOrderDetailsAPI();
                showToastMessage({
                    message: t(`QUOTE_AND_ORDER.SUCCESS_MESSAGE.${toastMsg?.success}`),
                    type: ToastType.SUCCESS
                });
            } else {
                showToastMessage({
                    message: errMsg,
                    type: ToastType.ERROR
                });
            }
        } catch (error: any) {
            const errorMsgFromAPI = error?.response?.data?.Message;
            showToastMessage({
                message: errorMsgFromAPI ?? errMsg,
                type: ToastType.ERROR
            });
        }
    };

    // on clicking show in invoice toggle button
    const handleShowInInvoice = (taskId: number, invoiceId: number) => {
        const errMsg = t(`QUOTE_AND_ORDER.ERROR_MESSAGE.SHOW_INVOICE_FAILED`);
        const executeUpdate = async () => {
            try {
                const response = await updateTaskDetailsInvoice(taskId, invoiceId);
                if (response) {
                    getInvoiceList(requestBody);
                    await getOrderDetailsAPI();
                    showToastMessage({
                        message: t(`QUOTE_AND_ORDER.SUCCESS_MESSAGE.SHOW_INVOICE_SUCCESS`),
                        type: ToastType.SUCCESS
                    });
                } else {
                    showToastMessage({
                        message: errMsg,
                        type: ToastType.ERROR
                    });
                }
            } catch (error) {
                showToastMessage({ message: errMsg, type: ToastType.ERROR });
            }
        };

        executeUpdate();
    };
    const handleShowInQuote = async (taskId: number, updatedValue: boolean) => {
        const errMsg = t(`QUOTE_AND_ORDER.ERROR_MESSAGE.SHOW_QUOTE_FAILED`);
        try {
            const params = {
                taskId,
                isShowInQuoteUpdated: true,
                isShowInInvoiceUpdated: false, // always false for this listing page.
                userSelectedValue: updatedValue // this is what the value updated by user.
            };

            const response = await updateTaskDetailsQUote(params);
            if (response) {
                getInvoiceList(requestBody);
                await getOrderDetailsAPI();
                showToastMessage({
                    message: t(`QUOTE_AND_ORDER.SUCCESS_MESSAGE.SHOW_QUOTE_SUCCESS`),
                    type: ToastType.SUCCESS
                });
            } else {
                showToastMessage({
                    message: errMsg,
                    type: ToastType.ERROR
                });
            }
        } catch (error) {
            showToastMessage({ message: errMsg, type: ToastType.ERROR });
        }
    };

    const getGroupingAbilities = async () => {
        try {
            const response = await taskManagementService.getTaskAbilitiesType<TaskDropDown[]>();
            setGroupingAbilities(response);
        } catch (error) {
            console.error('Error fetching grouping abilities:', error);
        }
    };

    const handleUpdateUnitId = (unitId: number, rowData: InvoiceData) => {
        updateInvoiceInlineFields(
            rowData.invoiceId,
            {
                unitId
            },
            { success: 'UNIT_UPDATED_SUCCESSFULLY', error: 'UNIT_UPDATE_FAILED' }
        );
    };

    const expanderTemplate = (data: InvoiceData) => {
        return data?.isBreakdown ? (
            <button
                type="button"
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                onClick={() => toggleRow(data)}
                className="p-link mr-1">
                <i
                    className={`text-primary pi pi-fw pi-chevron-${expandedRows[data.taskId] ? 'down' : 'right'} `}
                />
            </button>
        ) : (
            <></>
        );
    };

    const taskIDTemplate = (rowData: InvoiceData) => {
        const handleClick = () => {
            navigate(`/task-management/details/${rowData.taskId}/${rowData.id}`, {});
        };

        return (
            <div className={`flex items-center`}>
                {expanderTemplate(rowData)}
                <button
                    className="underline decoration-[0.075rem] underline-offset-2 text-primary cursor-pointer"
                    data-testid="task-id"
                    onClick={handleClick}
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    tabIndex={0}>
                    {rowData.taskNo}
                </button>
            </div>
        );
    };

    const amountRequestCurrencyTemplate = (rowData: InvoiceData) => {
        const canEditRequestCurrencyAmount = false;
        const handleAmountSave = (newAmount: number) => {
            // Logic to save the updated amount
            if ((+rowData?.requestCurrencyAmount || 0) !== newAmount) {
                updateInvoiceInlineFields(
                    +rowData.invoiceId,
                    { amount: newAmount },
                    { success: 'AMOUNT_UPDATED_SUCCESSFULLY', error: 'AMOUNT_UPDATE_FAILED' }
                );
            }
        };

        return (
            <div className="flex items-center justify-between gap-2 w-full">
                {!!rowData?.invoiceProcessedMethod && (
                    <div className="flex items-center mt-0.5">
                        <Tooltip
                            id={`invoice-amount-tooltip-${rowData?.taskId}`}
                            target={`.custom-target-icon-${rowData?.taskId}`}
                            content={rowData?.invoiceProcessedMethod ?? ''}
                            position="bottom"
                            mouseTrack={false}
                            autoHide={false}
                            pt={{ root: { className: 'shadow-none' } }}
                        />
                        <i
                            className={`custom-target-icon-${rowData?.taskId} pi pi-info-circle text-primary cursor-pointer text-[1rem]`}
                        />
                    </div>
                )}
                <EditableField
                    fieldName={'amountRequestCurrency'}
                    fieldValue={+rowData.requestCurrencyAmount || 0}
                    currency={rowData?.requestCurrencySymbol}
                    onSave={handleAmountSave}
                    canEditFields={
                        canEditRequestCurrencyAmount &&
                        statusName !== COMPLETED &&
                        rowData?.showInInvoice === true // hide the editable field if showInInvoice is false
                    }
                />
            </div>
        );
    };

    const rateTemplate = (rowData: InvoiceData) => {
        const { rate, showInInvoice = false } = rowData;
        const handleRateSave = (newRate: number) => {
            // Logic to save the updated rate
            if (rate !== newRate) {
                updateInvoiceInlineFields(+rowData.invoiceId, {
                    rate: newRate
                });
            }
        };
        return hasEditInvoiceTaskPermission ? (
            <EditableField
                fieldName="rate"
                fieldValue={rate || 0}
                onSave={handleRateSave}
                canEditFields={
                    !isContactUser(userDetails.userInfo.roleId) &&
                    statusName !== COMPLETED &&
                    !!showInInvoice
                } // hide the editable field if showInInvoice is false
                // CM and CU can't edit the fields
            />
        ) : (
            <span>
                {convertToValidNumber({
                    value: rate || 0,
                    decimalLength: 4,
                    renderAs: 'string'
                })}
            </span>
        );
    };

    const quantityTemplate = (rowData: InvoiceData) => {
        const { quantity, showInInvoice = false } = rowData;
        const handleQuantitySave = (newQuantity: number) => {
            // Logic to save the updated quantity
            if (quantity !== newQuantity) {
                updateInvoiceInlineFields(
                    +rowData.invoiceId,
                    {
                        quantity: newQuantity
                    },
                    {
                        success: 'QUANTITY_UPDATED_SUCCESSFULLY',
                        error: 'QUANTITY_UPDATE_FAILED'
                    }
                );
            }
        };
        return hasEditInvoiceTaskPermission ? (
            <EditableField
                fieldName="quantity"
                fieldValue={quantity || 0}
                onSave={handleQuantitySave}
                canEditFields={
                    !isContactUser(userDetails.userInfo.roleId) &&
                    statusName !== COMPLETED &&
                    !!showInInvoice
                } // hide the editable field if showInInvoice is false
                // CM and CU can't edit the fields
                canFormatFields={false}
            />
        ) : (
            <span>{quantity || 0}</span>
        );
    };

    const fxRateTemplate = (rowData: InvoiceData) => {
        return <span>{rowData.fxRate}</span>;
    };

    const amountTemplate = (rowData: InvoiceData) => {
        return (
            <span>{`${rowData?.baseCurrencySymbol || '$'} ${formatCurrency(+rowData?.baseCurrencyAmount || 0)}`}</span>
        );
    };

    // template for toggle button in table
    const templateToggleButton = (rowData: InvoiceData, toggleName: string | null = null) => {
        const getToggleText = (): string => {
            if (toggleName === 'displayShowInInvoice') return rowData.displayShowInInvoice;
            else if (toggleName === 'showInQuote') return rowData.showInQuote;
            else return '--';
        };
        const isToggleChecked = (): boolean => {
            let isChecked: boolean = false;

            if (toggleName === 'displayShowInInvoice') {
                isChecked = rowData.showInInvoice;
            } else if (toggleName === 'showInQuote') {
                isChecked = rowData.showInQuote.toLowerCase() === YES_NO_STRING.YES;
            }
            return isChecked;
        };
        const isToggleDisabled = (): boolean => {
            let isDisabled: boolean = true; // default disabled

            if (toggleName === 'displayShowInInvoice') {
                isDisabled = isThisFinanceUser || statusName === COMPLETED; // [3000]
            } else if (toggleName === 'showInQuote') {
                isDisabled = isThisFinanceUser || !(rowData.isAutoTask === false && isNonIP); // [2258] Non-IP manual-tasks can be enable.
            }
            return isDisabled;
        };
        const handleToggleChange = () => {
            if (toggleName === 'displayShowInInvoice') {
                handleShowInInvoice(rowData.taskId, rowData.invoiceId);
            } else if (toggleName === 'showInQuote') {
                const showInQuoteValue = rowData.showInQuote.toLowerCase() !== YES_NO_STRING.YES;
                handleShowInQuote(rowData.taskId, showInQuoteValue);
            }
        };

        return (
            <div
                data-testid="detailsRightSection"
                className="flex items-center justify-between w-6/12 toggle_disable_State">
                <input
                    type="checkbox"
                    className="toggle toggle-sm border-2"
                    style={{
                        borderColor: isToggleChecked() ? '#1175C2' : '#A4A5A6',
                        backgroundColor: isToggleChecked() ? '#1175C2' : '#A4A5A6'
                    }}
                    checked={isToggleChecked()}
                    onChange={handleToggleChange}
                    disabled={isToggleDisabled()}
                />
                <text data-testid="label-text" className="pl-2">
                    {getToggleText()}
                </text>
            </div>
        );
    };

    const renderFooterContent = () => {
        return (
            <div className="h-12 flex flex-row p-5 justify-end items-center">
                <span className="font-medium text-lg mx-2 font-barlow text-right text-[#181818] capitalize break-words">
                    {t('SUMMARY.GRAND_TOTAL')}
                </span>{' '}
                <span className="break-words text-xl font-bold mx-2">
                    {`${tableData?.[0]?.requestCurrencySymbol || ''} ${formatCurrency(tableData?.[0]?.grandTotal || 0)}`}
                </span>
            </div>
        );
    };

    const getFilteredTableData = () => {
        /** do not show invoice list while 'Preparing Quote' only fr Contact-Users. */
        const list =
            tableData?.length > 0 && !(isPreparingQuote && isThisContactUser) ? tableData : [];
        return list;
    };

    const invoiceTaskInlineEditForDate = (rowData: any, field: string) => {
        const isInvoiceDateEditable =
            (isThisStaffUser || isThisVendorUser) &&
            !isThisFinanceUser &&
            rowData?.showInInvoice &&
            statusName !== INVOICED &&
            statusName !== COMPLETED;

        return (
            <DateFieldTableCellEditor
                value={rowData[field]}
                fieldName={field}
                id={rowData?.invoiceId}
                responseIndicate={function (): void {
                    getInvoiceList(requestBody);
                }}
                isEditable={isInvoiceDateEditable}
            />
        );
    };

    const handleGetUnitDropDownOptions = (taskTypeId: number) => {
        const matchedAbility = groupingAbilities.find((ability) => ability.id === taskTypeId);
        return (
            matchedAbility?.units.map((unit) => ({ label: unit.name, value: unit.unitId })) || []
        );
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'taskNo',
            header: 'Task ID',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Link,
            body: taskIDTemplate,
            columnNumber: 0,
            frozen: true,
            alignFrozen: 'left',
            visibility: true
        },
        {
            field: 'taskName',
            header: isContactUser(userRoleId) ? 'Service' : 'Task/Abilities',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            body: taskTitleTemplate,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'status',
            header: 'Status',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'sourceFileName',
            header: 'Source File',
            sortable: false,
            filter: false,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'sourceLanguage',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'targetLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'targetCountry',
            header: 'Target Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'targetCountryFlagName',
            columnNumber: 0,
            visibility: !isSTDFlow,
            userRightsForThisColumn: !isSTDFlow
        },
        {
            field: 'filingDeadline',
            header: 'Filing Deadline',
            sortable: true,
            filter: false,
            filterType: FilterType.Calendar,
            body: (rowData: any) => invoiceTaskInlineEditForDate(rowData, 'filingDeadline'),
            columnNumber: 0,
            visibility: !isSTDFlow,
            userRightsForThisColumn: !isSTDFlow
        },
        {
            field: 'deliveryDate',
            header: 'Delivery Date',
            sortable: true,
            filter: false,
            filterType: FilterType.Calendar,
            body: (rowData: any) => invoiceTaskInlineEditForDate(rowData, 'deliveryDate'),
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'unit',
            header: 'Unit',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            body: (rowData: InvoiceData) => (
                <TaskUnitEdit
                    parentModule="INVOICE_TASKS"
                    taskUnitId={rowData.unitId}
                    unitName={rowData.unit}
                    handleParent={{
                        isFromParent: true,
                        handleUpdate: (unitId) => handleUpdateUnitId(unitId, rowData),
                        dropdownOptions: handleGetUnitDropDownOptions(rowData.taskTypeId)
                    }}
                    isEditable={
                        (isThisPMorAdminUser || isThisVendorUserExcludedFinance) &&
                        rowData.status !== APPROVED
                    }
                />
            )
        },
        {
            field: 'quantity',
            header: 'Quantity',
            sortable: true,
            filter: false,
            body: quantityTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'rate',
            header: 'Rate',
            sortable: true,
            filter: false,
            body: rateTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'amountRequestCurrency',
            header: 'Total',
            sortable: true,
            filter: false,
            body: amountRequestCurrencyTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'fxRate',
            header: 'FX Rate',
            sortable: true,
            filter: false,
            body: fxRateTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'amount',
            header: 'Total (USD)',
            sortable: true,
            filter: false,
            body: amountTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            cellStyle: 'text-right',
            headerStyle: 'justify-end col-312',
            visibility: true
        },
        {
            field: 'showInQuote',
            header: 'Show in Quote',
            sortable: true,
            filter: false,
            body: (rowData: InvoiceData) => templateToggleButton(rowData, 'showInQuote'),
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'displayShowInInvoice',
            header: 'Show in Invoice',
            sortable: true,
            filter: false,
            body: (rowData: InvoiceData) => templateToggleButton(rowData, 'displayShowInInvoice'),
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        }
    ];

    if (isUPCOptOut) {
        columnSchema.splice(
            columnSchema.findIndex((col) => col.field === 'sourceLanguage'),
            1
        );
        columnSchema.splice(
            columnSchema.findIndex((col) => col.field === 'targetLanguage'),
            1
        );
    } else if (!isNonIP) {
        columnSchema.splice(
            columnSchema.findIndex((col) => col.field === 'sourceFileName'),
            1
        );
    }

    const cuColumns = isUPCOptOut
        ? ['taskName', 'targetCountry', 'filingDate', 'deliveryDate', 'status', 'taskStatus']
        : [
              'taskName',
              'sourceLanguage',
              'targetLanguage',
              'targetCountry',
              'filingDate',
              'deliveryDate',
              'status',
              'taskStatus'
          ];
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.TASK_MANAGEMENT,
        filters: {
            taskNo: { value: null, matchMode: FilterMatchMode.CONTAINS },
            sourcelanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetLanguage: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            targetCountry: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            vendorName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            unit: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
            taskName: { value: null, matchMode: FilterMatchMode.IN },
            taskStatus: { value: null, matchMode: FilterMatchMode.IN }
        },
        reOrderableColumns: true,
        title: '',
        emptyMessage,
        editTable: {
            editType: '',
            rowEditComplete() {},
            isRowEdit: true
        },
        localStorageKey: DATA_STORAGE_KEYS.DATA_TABLE.BILLS_AND_INVOICES,
        lazyLoad: false,
        columns: isContactUser(userRoleId)
            ? columnSchema?.filter((item) => cuColumns?.includes(item?.field))
            : columnSchema,
        hideColumnSelector: true,
        customTableHeight: false
    };

    const registerFunctionsToStore = () => {
        /** register the functions on store while trigger the action buttons from footer component. */
        quoteOrderModuleStore.registerFunction('refreshInvoiceTaskList', getInvoiceListWrapper);
    };
    const resetRegisteredFunctionsOnStore = () => {
        /** remove the registered function on store to avoid unwanted calls. */
        quoteOrderModuleStore.registerFunction('refreshInvoiceTaskList', () => {});
    };
    useEffect(() => {
        registerFunctionsToStore();
        getGroupingAbilities();
        return () => {
            resetRegisteredFunctionsOnStore();
        };
    }, []);

    useEffect(() => {
        getInvoiceList(requestBody);
    }, [requestBody, statusName, patentCountResponse, countryEditResponse, triggerGetInvoiceList]);

    const handleCancel = () => {
        setShowPopup({ ...showPopup, visible: false });
    };

    return (
        <div className="grid grid-cols-1 gap-4 mt-3">
            {visible && (
                <ConfirmationPopup
                    onConfirm={() => {
                        handleCancel();
                    }}
                    onCancel={handleCancel}
                    headerText={header}
                    subHeaderText={subHeader}
                    {...{ visible, description }}
                />
            )}
            <div className="m-w-full overflow-auto">
                <DataTableComponent
                    tableData={getFilteredTableData()}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={requestBody}
                    handleFilter={setRequestBody}
                    toggleRowData={() => {}}
                    handlePagination={setRequestBody}
                    tablePaginationData={paginationInfo}
                    showPagination={true}
                    handleSort={setRequestBody}
                    showHeader={false}
                    footerContent={
                        getFilteredTableData()?.length > 0 ? renderFooterContent : undefined
                    }
                    rowExpansionTemplate={rowExpansionTemplate}
                    expandedRows={expandedRows}
                    dataKey={'taskId'}
                />
            </div>
        </div>
    );
};

export default InvoiceTasks;
