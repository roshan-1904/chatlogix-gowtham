import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import CountryDetailsPage from './countryDetails';
import viewOrderAndQuoteData from '../../Mock/viewOrderAndQuote.mock.json';

const { countryDetailsData } = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('Header of view order/quote', () => {
    test('Check render of country details section in the view Order/Quote screen', () => {
        render(
            <CountryDetailsPage
                countryDetails={countryDetailsData}
                handleFilter={() => {}}
                sortHandler={() => {}}
                requestBody={{
                    searchModels: [],
                    sorting: {
                        propertyName: '',
                        value: ''
                    },
                    pageNo: 1,
                    pageCount: 10
                }}
                currencySymbol={'$'}
                category={''}
                service={''}
                viewData={{}}
                setCountryEditResponse={() => {}}
                countryEditResponse={true}
            />
        );
    });
});
