import { tabPanelPT } from 'constants/styles.constant';
import { ViewOrderType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { TabPanel, TabView } from 'primereact/tabview';
import { useEffect, useState } from 'react';
import EPOrNonUpList from './epOrNonUpList';
import NotAllowedIcon from 'assets/svgs/not-allowed-symbol.svg';
import { formatCurrency } from 'core/utils/utils';
import { t } from 'i18next';
import { SERVICE_TYPES, SERVICE_UNIQUE_NAME } from 'constants/app.constant';

export interface CountryAndLanguageDetailModel {
    sourceLanguageId: number | null;
    sourceLanguageName: string | null;
    countryId: number | null;
    languageId: number | null;
    countryName: string | null;
    officialLanguage: string | null;
    agencyFee: number;
    officialFee: number;
    translationFee: number;
    total: number;
    instantQuote: string | null;
    iconName: string | null;
    up: boolean | null;
    ep: boolean | null;
    isClaim: boolean | null;
    includeAgencyFee: boolean | null;
    includeOfficialFee: boolean | null;
    includeTranslationFee: boolean | null;
}
export interface CountryAndLanguageDetailsResponse {
    upList: CountryAndLanguageDetailModel[] | null;
    nonUpList: CountryAndLanguageDetailModel[] | null;
    epList: CountryAndLanguageDetailModel[] | null;
    claimsTranslationList: CountryAndLanguageDetailModel[] | null;
}

export interface CountryAndLanguageDetails extends CountryAndLanguageDetailsResponse {
    currencySymbol: string | null;
    viewData: ViewOrderType | null;
    setCountryEditResponse: any;
    countryEditResponse: boolean;
}
const tabViewStyle = {
    nav: {
        className: 'gap-4 border-0'
    }
};

const EpUpCountryDetailsPage = (context: CountryAndLanguageDetails) => {
    const [activeIndex, setActiveIndex] = useState<number>(0);
    useEffect(() => {
        if (context.claimsTranslationList && context.claimsTranslationList.length > 0) {
            setActiveIndex(0);
        } else if (context.upList && context.upList.length > 0) {
            setActiveIndex(1);
        } else {
            setActiveIndex(2);
        }
    }, [context.claimsTranslationList, context.upList, context.epList]);
    const [upTotal, setUpTotal] = useState<number>(0);
    const [nonUpTotal, setNonUpTotal] = useState<number>(0);
    const [epTotal, setEpTotal] = useState<number>(0);
    const [claims713Total, setClaims713Total] = useState<number>(0);
    const [requestCurrencySymbol, setRequestCurrencySymbol] = useState<string | null>(null);
    const [upListData, setUpListData] = useState<CountryAndLanguageDetailModel[] | null>(null);
    const getTabPanelPT = (index: number) => {
        return tabPanelPT(activeIndex === index, () => setActiveIndex(index));
    };

    const renderFooterContent = (amount: number) => {
        return (
            <div className="h-12 flex flex-row p-5 justify-end items-center">
                <span className="font-medium text-lg mx-2 font-barlow text-right text-[#181818] capitalize break-words">
                    {'Total'}
                </span>{' '}
                <span className="break-words text-xl font-bold mx-2" data-testid="totalAmount">
                    {`${requestCurrencySymbol || ''} ${formatCurrency(amount)}`}
                </span>
            </div>
        );
    };
    const InfoContent = () => {
        return (
            <div data-testid="patentWarningLabel" className="absolute right-8 z-10">
                <div className="w-fit flex justify-start items-center gap-2 text-sm px-2 p-1 bg-orange-50 border-2 rounded-md border-orange-100">
                    <i className="pi pi-info-circle text-yellow-500"></i>
                    <div className="flex md:whitespace-nowrap text-xxs !leading-5 md:!leading-4">
                        <div>{'Excluded fees are marked with this icon'}</div>
                    </div>
                    <div className="w-[0.8rem] h-[0.8rem] cursor-pointer">
                        <img src={NotAllowedIcon} alt="No Value" />
                    </div>
                </div>
            </div>
        );
    };

    const TotalAmount = (record: CountryAndLanguageDetailModel[] | null) => {
        if (!record) return 0;
        let total = 0;
        record.forEach((item) => {
            total += item.agencyFee || 0;
            total += item.officialFee || 0;
            total += item.translationFee || 0;
        });
        return total;
    };

    const prepareUpTableDate = (rows: CountryAndLanguageDetailModel[] | null) => {
        const is713_plus_translation_only =
            context.viewData?.requestDetails.serviceUniqueName ===
            SERVICE_UNIQUE_NAME.EP_713Claims_TranslationOnly_EP_UP;

        const response = rows?.reduce(
            (
                acc: {
                    agencyFee: CountryAndLanguageDetailModel[];
                    translationFee: CountryAndLanguageDetailModel[];
                },
                item: CountryAndLanguageDetailModel
            ) => {
                if (item.countryName !== '' && item.countryName !== null) {
                    if (!is713_plus_translation_only) {
                        acc.agencyFee.push(item);
                    }
                } else {
                    acc.translationFee.push(item);
                }
                return acc;
            },
            { agencyFee: [], translationFee: [] }
        );

        const countryNames = (rows ?? [])
            .filter((s) => s.countryName !== null && s.countryName !== '')
            .map((s) => s.countryName)
            .join(',');

        const upValue: CountryAndLanguageDetailModel = {
            sourceLanguageId: response?.agencyFee[0]?.sourceLanguageId ?? null,
            sourceLanguageName: response?.agencyFee[0]?.sourceLanguageName ?? null,
            languageId: response?.translationFee[0]?.languageId ?? null,
            countryId: response?.agencyFee[0]?.countryId ?? null,
            countryName: countryNames,
            officialLanguage: response?.translationFee[0]?.officialLanguage ?? null,
            agencyFee: response?.agencyFee[0]?.agencyFee ?? 0,
            officialFee: response?.agencyFee[0]?.officialFee ?? 0,
            translationFee: response?.translationFee[0]?.translationFee ?? 0,
            total: (response?.agencyFee[0]?.total ?? 0) + (response?.translationFee[0]?.total ?? 0),
            instantQuote: null,
            iconName: null,
            up: true,
            ep: null,
            isClaim: null,
            includeAgencyFee: null,
            includeOfficialFee: null,
            includeTranslationFee: null
        };
        setUpListData([upValue]);
        setUpTotal(TotalAmount([upValue]));
    };

    useEffect(() => {
        setRequestCurrencySymbol(context.viewData?.additionalInfo?.currencySymbol ?? null);
        if (context.upList && context.upList.length > 0) {
            prepareUpTableDate(context.upList);
            setNonUpTotal(TotalAmount(context.nonUpList));
        }
        if (context.epList && context.epList.length > 0) {
            setEpTotal(TotalAmount(context.epList));
        }
        setClaims713Total(TotalAmount(context.claimsTranslationList));
    }, [context]);

    const { claimsTranslationList, nonUpList, epList } = context;

    return (
        <div className="mt-2">
            <TabView
                pt={tabViewStyle}
                activeIndex={activeIndex}
                onTabChange={(e) => setActiveIndex(e.index)}>
                {claimsTranslationList && claimsTranslationList.length > 0 && (
                    <TabPanel
                        header="Claim Translation"
                        pt={getTabPanelPT(0)}
                        data-testId="claimTranslationTab">
                        <EPOrNonUpList
                            data-testId="claimsTranslationList"
                            tableRowData={claimsTranslationList ?? []}
                            title="71[3] Claims"
                            serviceType={'713Claims'}
                            currencySymbol={requestCurrencySymbol}
                            viewData={context.viewData}
                            setCountryEditResponse={context.setCountryEditResponse}
                            countryEditResponse={context.countryEditResponse}
                        />
                        {renderFooterContent(claims713Total)}
                    </TabPanel>
                )}
                {upListData && upListData.length > 0 && (
                    <TabPanel
                        header={t('SUMMARY.UP_NATIONAL_VALIDATIONS')}
                        pt={getTabPanelPT(1)}
                        data-testId="upNationalValidationTab">
                        {context.viewData?.requestDetails.category === 'european_patent' &&
                            context.viewData?.requestDetails.services ===
                                SERVICE_TYPES.translation_and_validation && <InfoContent />}
                        <EPOrNonUpList
                            data-testId="upList"
                            tableRowData={upListData ?? []}
                            title="UP"
                            serviceType={'UP'}
                            currencySymbol={requestCurrencySymbol}
                            viewData={context.viewData}
                            setCountryEditResponse={context.setCountryEditResponse}
                            countryEditResponse={context.countryEditResponse}
                        />
                        <EPOrNonUpList
                            data-testId="nonUpList"
                            tableRowData={nonUpList ?? []}
                            title="Non-UP"
                            serviceType={'Non-UP'}
                            currencySymbol={requestCurrencySymbol}
                            viewData={context.viewData}
                            setCountryEditResponse={context.setCountryEditResponse}
                            countryEditResponse={context.countryEditResponse}
                        />
                        {renderFooterContent(upTotal + nonUpTotal)}
                    </TabPanel>
                )}
                {epList && epList.length > 0 && (
                    <TabPanel
                        header={t('SUMMARY.NATIONAL_VALIDATION_ONLY')}
                        pt={getTabPanelPT(2)}
                        data-testId="epNationalValidationTab">
                        {context.viewData?.requestDetails.category === 'european_patent' &&
                            context.viewData?.requestDetails.services ===
                                SERVICE_TYPES.translation_and_validation && <InfoContent />}
                        <EPOrNonUpList
                            data-testId="epList"
                            tableRowData={epList}
                            title="National Validation"
                            serviceType={'EP'}
                            currencySymbol={requestCurrencySymbol}
                            viewData={context.viewData}
                            setCountryEditResponse={context.setCountryEditResponse}
                            countryEditResponse={context.countryEditResponse}
                        />
                        {renderFooterContent(epTotal)}
                    </TabPanel>
                )}
            </TabView>
        </div>
    );
};

export default EpUpCountryDetailsPage;
