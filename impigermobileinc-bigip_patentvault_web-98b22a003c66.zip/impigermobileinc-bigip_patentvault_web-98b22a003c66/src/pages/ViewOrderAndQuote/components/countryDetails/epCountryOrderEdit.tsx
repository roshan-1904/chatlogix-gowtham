import { SERVICE_TYPES, STATUS_MODE } from 'constants/app.constant';
import { previewDialogPopup } from 'constants/styles.constant';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import { showToastMessage } from 'core/utils/utils';
import { t } from 'i18next';
import EpCountryListing from 'pages/orders/selectCountry/ep/epCountryListing';
import { ViewOrderType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { Dialog } from 'primereact/dialog';
import { useRef, useState } from 'react';

interface EpCountryOrderEditProps {
    orderId: number;
    draftId: number;
    isUpOrder: boolean;
    isEPOrder: boolean;
    setCountryEditResponse: any;
    countryEditResponse: boolean;
    isNoEnglishTranslation: boolean;
    viewData: ViewOrderType | null;
}

const EpCountryOrderEdit = (props: EpCountryOrderEditProps) => {
    const [dialogVisible, setDialogVisible] = useState<boolean>();
    const listingRef = useRef<{ onSubmit: () => Promise<boolean> }>(null);
    const viewDataHeader = props.viewData?.headers;
    const restrictEdit =
        viewDataHeader?.statusId === STATUS_MODE.COMPLETED ||
        viewDataHeader?.statusId === STATUS_MODE.INVOICED ||
        viewDataHeader?.statusId === STATUS_MODE.CANCELED;

    const resetEpCountryListing = () => {
        const storeData = quoteOrderModuleStore.getData();
        const resetCountryList = {
            ...storeData.formData,
            selectCountryPageForEP: {}
        };
        quoteOrderModuleStore.updatePage('formData', resetCountryList);
    };

    const handleSubmit = async () => {
        if (listingRef.current) {
            const success = await listingRef.current.onSubmit();
            if (success) {
                setDialogVisible(false);
                showToastMessage({
                    type: ToastType.SUCCESS,
                    message: t('SELECT_COUNTRY.SUCCESS_MESSAGE')
                });
                props.setCountryEditResponse(!props.countryEditResponse);
            }
        }
    };

    return (
        <div data-testid="ep-country-order-edit">
            <Dialog
                visible={dialogVisible}
                onHide={() => setDialogVisible(false)}
                draggable={false}
                pt={{
                    ...previewDialogPopup,
                    root: {
                        className: previewDialogPopup.root.className + ' w-[80vw] absolute top-14'
                    },
                    header: {
                        className:
                            previewDialogPopup.header.className +
                            ' py-2.5 px-4 !rounded-md !rounded-b-none shadow shadow-neutral-100/70 relative'
                    },
                    footer: {
                        className: 'rounded-b-md py-2.5 px-4 shadow-inner shadow-neutral-100/60'
                    },
                    content: {
                        className:
                            previewDialogPopup.content.className +
                            ' min-h-[70vh] px-0 pb-0 !rounded-none'
                    }
                }}
                header={<h4 className="font-semibold">{t('SELECT_EP_COUNTRY.SELECT_COUNTRY')}</h4>}
                footer={
                    <div className="flex justify-end items-center gap-4">
                        <button
                            className="btn button-neutral h-10 min-h-10"
                            onClick={() => setDialogVisible(false)}>
                            {t('COMMON.CANCEL')}
                        </button>

                        <button
                            className="btn button-primary h-10 min-h-10"
                            onClick={() => {
                                handleSubmit();
                            }}>
                            {t('COMMON.SUBMIT')}
                        </button>
                    </div>
                }>
                <EpCountryListing
                    ref={listingRef}
                    orderEditMode={{
                        isOrderEdit: true,
                        orderId: props.orderId,
                        draftId: props.draftId,
                        isUpOrder: props.isUpOrder,
                        isNoEnglishTranslation: props.isNoEnglishTranslation,
                        isEPOrder: props.isEPOrder,
                        sourceLanguage: props.viewData?.requestDetails?.sourceLanguage || null,
                        hasOrderCostUpdated: props.viewData?.hasOrderCostUpdated || null
                    }}
                />
            </Dialog>
            {!restrictEdit &&
                props.viewData?.requestDetails?.services ===
                    SERVICE_TYPES.translation_and_validation && (
                    <button
                        className="btn button-primary-outline h-8 min-h-8"
                        onClick={() => {
                            resetEpCountryListing();
                            setDialogVisible(true);
                        }}>
                        {t('QUOTE_AND_ORDER.EDIT_COUNTRY')}
                    </button>
                )}
        </div>
    );
};

export default EpCountryOrderEdit;
