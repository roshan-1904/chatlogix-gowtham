import { LANGUAGE_ID, MODE, SERVICE_UNIQUE_NAME, STATUS_MODE } from 'constants/app.constant';
import { formatCurrency, isAdminUser, isProjectManagerUser } from 'core/utils/utils';
import { t } from 'i18next';
import { updateCountryFees } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { EditFieldInline } from 'pages/ViewOrderAndQuote/shared/editFieldHelper';
import { ResponseCountryList } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { v4 as uuidv4 } from 'uuid';
import { useEffect, useState } from 'react';
import { Tooltip } from 'primereact/tooltip';
import { tooltipStyle, translationFeeInputSwitchPT } from 'constants/styles.constant';
import NotAllowedIcon from 'assets/svgs/not-allowed-symbol.svg';
import { InputSwitch } from 'primereact/inputswitch';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';

type CountryDetailsProps = {
    countryDetails: ResponseCountryList | null;
    handleFilter: any;
    sortHandler: any;
    requestBody: any;
    currencySymbol: string;
    category: string;
    service: string;
    viewData: any;
    setCountryEditResponse: any;
    countryEditResponse: boolean;
};

const CountryDetailsPage = ({
    countryDetails,
    handleFilter,
    sortHandler,
    requestBody,
    currencySymbol,
    category,
    service,
    viewData,
    setCountryEditResponse,
    countryEditResponse
}: CountryDetailsProps) => {
    const requestId: number = viewData?.headers?.requestId;
    const statusId: number = viewData?.headers?.statusId;
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisAdminUser = isAdminUser(loggedInUserId);
    const isThisProjectManagerUser = isProjectManagerUser(loggedInUserId);
    const [tableRequestBody, setTableRequestBody] = useState(requestBody);
    const handleCancel = () => {
        setCountryEditResponse(!countryEditResponse);
    };
    const [countryTableData, setCountryTableData] = useState<any[]>(
        countryDetails?.orderViewCountryModel ?? []
    );

    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: '',
        acceptButtonDisabled: false,
        acceptLabel: 'Yes',
        rejectLabel: 'No',
        isShowAcceptButton: false,
        isShowRejectButton: false
    });
    const handleConfirmationCancel = () => {
        setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });
    };
    useEffect(() => {
        setCountryTableData(countryDetails?.orderViewCountryModel ?? []);
    }, [countryDetails]);

    function isChecked(rowData: any, field: any): boolean {
        return (rowData[field] as boolean) ?? false;
    }

    // editFieldTemplate function is used for inline edit of table cells
    // field params gets cell value
    const editFieldTemplate = (fieldValue: number, fieldName: string, rowData: any) => {
        const countryId = rowData?.countryId;
        const languageId = rowData?.languageId;

        const handleRateSave = async (newValue: number, isTranslationToggleChange?: boolean) => {
            setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });

            const updatedValue = newValue;
            let payload;
            const idKey = countryId !== 0 ? { countryId } : { countryId: 0, languageId };
            if (fieldName === 'agencyFee') {
                payload = {
                    agencyFee: updatedValue,
                    ...idKey
                };
            }
            if (fieldName === 'officialFee') {
                payload = {
                    officialFee: updatedValue,
                    ...idKey
                };
            }
            if (fieldName === 'translationFee' && isTranslationToggleChange !== true) {
                payload = {
                    translationFee: updatedValue,
                    ...idKey
                };
            }

            if (viewData.headers?.isUP === true) {
                payload = { ...payload, isUP: true };
            }
            if (viewData.headers?.isUP === true && fieldName === 'translationFee') {
                payload = { ...payload, isUP: true, languageId, countryId: 0 };
            }

            if (isTranslationToggleChange) {
                payload = {
                    isUserPreferredAiTranslation: newValue === 1 ? true : false,
                    ...idKey
                };
            }
            try {
                const response = await updateCountryFees(payload, requestId, true);
                if (response) {
                    setCountryEditResponse(!countryEditResponse);
                }
            } catch (error: any) {
                setShowConfirmationPopup({
                    ...showConfirmationPopup,
                    visible: true,
                    handlePopConfirmConfirm: () => void handleRateSave(newValue ? 1 : 0, true),
                    header: t('PV_SETTING.RATES.ERROR_MESSAGE.TRANSLATION_MODE_LOCKED'),
                    description: error?.response?.data?.Message,
                    rejectLabel: t('COMMON.CLOSE'),
                    isShowAcceptButton: false,
                    isShowRejectButton: true
                });
                return <></>;
            }
        };

        let includeFee: boolean = true;

        // Condition for ep claims+ translation only for avoid to show exclude icon
        if (
            viewData?.requestDetails.category === 'european_patent' &&
            viewData?.requestDetails.services === 'translation_only' &&
            fieldName === 'translationFee'
        ) {
            includeFee = true;
        } else {
            if (fieldName === 'agencyFee') {
                includeFee = rowData.includeAgencyFee ?? true;
            } else if (fieldName === 'translationFee') {
                includeFee = rowData.includeTranslationFee ?? true;
            } else if (fieldName === 'officialFee') {
                includeFee = rowData.includeOfficialFee ?? true;
            }
        }
        if (includeFee !== false) {
            return (
                <div className="flex items-center justify-between">
                    {fieldName === 'translationFee' &&
                        (statusId !== STATUS_MODE.PREPARING_QUOTE &&
                        statusId !== STATUS_MODE.WAITING_FOR_APPROVAL &&
                        (isThisAdminUser || isThisProjectManagerUser) &&
                        !(
                            statusId === STATUS_MODE.TO_BE_PROCESSED &&
                            category === 'european_patent' &&
                            service === 'translation_&_validation' &&
                            !viewData?.headers?.isClaims71_3
                        ) &&
                        rowData.isAiTranslationConfiguration === true ? (
                            <div className="translation-fee-cell flex">
                                <InputSwitch
                                    checked={isChecked(rowData, 'isUserPreferredAiTranslation')}
                                    pt={translationFeeInputSwitchPT}
                                    onChange={(e) => {
                                        setShowConfirmationPopup({
                                            ...showConfirmationPopup,
                                            visible: true,
                                            handlePopConfirmConfirm: () =>
                                                void handleRateSave(e.value ? 1 : 0, true),
                                            header: t('COMMON.CONFIRMATION'),
                                            description: t(
                                                'QUOTE_AND_ORDER.TRANSLATION_MODE_CHANGE_CONFIRMATION'
                                            ),
                                            rejectLabel: t('COMMON.NO'),
                                            acceptLabel: t('COMMON.YES'),
                                            isShowAcceptButton: true,
                                            isShowRejectButton: true
                                        });
                                    }}
                                />
                            </div>
                        ) : (
                            <div className="translation-fee-cell flex">
                                {rowData.isAiTranslationConfiguration === true && (
                                    <InputSwitch
                                        checked={isChecked(rowData, 'isUserPreferredAiTranslation')}
                                        pt={translationFeeInputSwitchPT}
                                        disabled={true}
                                    />
                                )}
                            </div>
                        ))}
                    <EditFieldInline
                        key={uuidv4()}
                        statusId={statusId}
                        fieldValue={fieldValue || 0}
                        currency={currencySymbol}
                        onSave={handleRateSave}
                        onCancel={handleCancel}
                    />
                </div>
            );
        } else {
            // setTooltipIndex(tooltipIndex + 1);
            return (
                <>
                    <div className="w-full flex justify-end">
                        <div className="w-fit">
                            <Tooltip
                                target={`#tooltip-target-${languageId}-${countryId}-${fieldName}`}
                                content="This fee is not included in the total"
                                position="left"
                                pt={tooltipStyle}
                            />
                            <img
                                id={`tooltip-target-${languageId}-${countryId}-${fieldName}`}
                                className="w-[0.8rem] h-[0.8rem] cursor-pointer"
                                src={NotAllowedIcon}
                                alt="No Value"
                            />
                        </div>
                    </div>
                </>
            );
            // }
        }
    };

    const agencyFeeTemplate = (rowData: any) => {
        const doNotRender = validateRowData(rowData);
        if (doNotRender) return null;

        const agencyFee = rowData?.agencyFee;
        return editFieldTemplate(agencyFee as number, 'agencyFee', rowData);
    };
    const officialFeeTemplate = (rowData: any) => {
        const doNotRender = validateRowData(rowData);
        if (doNotRender) return null;

        const officialFee = rowData?.officialFee;
        return editFieldTemplate(officialFee as number, 'officialFee', rowData);
    };
    const translationFeeTemplate = (rowData: any) => {
        const translationFee = rowData?.translationFee;
        return editFieldTemplate(translationFee as number, 'translationFee', rowData);
    };
    const totalTemplate = (rowData: any) => {
        return <span>{`${currencySymbol} ${formatCurrency(rowData?.total as number)}`}</span>;
    };

    const validateRowData = (country: any): boolean => {
        return (!country.countryId || country.countryId === 0) &&
            country.languageId === LANGUAGE_ID.ENGLISH
            ? true
            : false;
    };

    const columnSchema: ColumnDefinition[] = [
        {
            field: 'countryName',
            header: 'Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.FlagText,
            flagIconKey: 'iconName',
            columnNumber: 0,
            visibility: true,
            frozen: true,
            alignFrozen: 'left'
        },
        {
            field: 'sourceLanguageName',
            header: 'Source Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            columnNumber: 0,
            cellDataStyle: 'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
            visibility: true,
            handleNullValue: true
        },
        {
            field: 'instantQuote',
            header: 'Instant Country',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'officialLanguage',
            header: 'Target Language',
            sortable: true,
            filter: true,
            filterType: FilterType.Text,
            valueType: ValueType.Status,
            cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
            columnNumber: 0,
            visibility: true
        },
        {
            field: 'agencyFee',
            header: 'Agency Fee',
            sortable: true,
            filter: true,
            body: agencyFeeTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            cellStyle: 'text-right'
        },
        {
            field: 'officialFee',
            header: 'Official Fee',
            sortable: true,
            filter: true,
            body: officialFeeTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            cellStyle: 'text-right'
        },
        {
            field: 'translationFee',
            header: 'Translation Fee',
            sortable: true,
            filter: true,
            body: translationFeeTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            cellStyle: 'text-right'
        },
        {
            field: 'total',
            header: 'Total',
            sortable: true,
            filter: true,
            body: totalTemplate,
            filterType: FilterType.Text,
            valueType: ValueType.Text,
            columnNumber: 0,
            visibility: true,
            cellStyle: 'text-right'
        }
    ];

    const officialFee = ['officialFee'];
    const agencyAndOfficialFee = ['agencyFee', 'officialFee'];
    const translationFee = ['translationFee'];

    const hideAgencyAndOfficialFee =
        (category === 'patent_cooperation_treaty' && service === 'translation_only') ||
        (category === 'european_patent' && service === '71_3_claims') ||
        (category === 'european_patent' && service === 'translation_only') ||
        (category === 'paris_convention_treaty' && service === 'translation_only');
    const hideTranslationFee =
        (category === 'european_patent' && (service === 'recordal' || service === 'Renewals')) ||
        (category === 'patent_cooperation_treaty' &&
            (service === 'recordal' || service === 'annuities'));

    const getColumnScheme: () => ColumnDefinition[] = () => {
        if (
            // Quote Scenario only 71[3] Claims
            (viewData?.requestTypeId === MODE.CREATE_QUOTE &&
                viewData?.requestDetails?.serviceUniqueName ===
                    SERVICE_UNIQUE_NAME.EP_713Claims_EP_UP) ||
            // Order Scenario for 71[3] Claims
            (viewData?.requestTypeId === MODE.CREATE_ORDER &&
                viewData.headers?.isClaims71_3 === true)
        ) {
            const schema_713 = columnSchema.filter(
                (item) =>
                    item.field !== 'countryName' &&
                    item.field !== 'instantQuote' &&
                    item.field !== 'agencyFee' &&
                    item.field !== 'officialFee'
            );
            return schema_713;
        } else if (viewData?.headers?.isUP === true) {
            const schema = columnSchema.map((item) => {
                if (item.field === 'countryName') {
                    item.valueType = FilterType.MultiSelect;
                }
                return item;
            });
            return category === 'european_patent' && service === 'translation_only'
                ? schema?.filter((item) => !agencyAndOfficialFee?.includes(item.field))
                : schema?.filter((item) => !officialFee?.includes(item.field));
        } else {
            if (hideAgencyAndOfficialFee) {
                return columnSchema?.filter((item) => !agencyAndOfficialFee?.includes(item.field));
            } else if (hideTranslationFee) {
                return columnSchema?.filter((item) => !translationFee?.includes(item?.field));
            }
        }
        return columnSchema;
    };
    const tableDefinition: DataTableDefinition = {
        tableType: TableTypes.QUOTE_AND_ORDER,
        filters: {},
        reOrderableColumns: true,
        title: 'Table Header',
        emptyMessage: '',
        customTableHeight: false,
        editTable: {
            editType: '',
            rowEditComplete() {},
            isRowEdit: false
        },
        localStorageKey: '',
        columns: getColumnScheme()
        // buttonChildren: createOrderQuoteDropDown()
    };
    return (
        <div className="py-2 pb-3" data-testid="AddressInformation-Accordian">
            <div className=" grid grid-cols-1 md:grid-cols-1 gap-4 mt-3">
                <div className="m-w-full overflow-auto mb-5">
                    {showConfirmationPopup.visible && (
                        <ConfirmationPopup
                            onConfirm={showConfirmationPopup.handlePopConfirmConfirm}
                            onCancel={() => handleConfirmationCancel()}
                            visible={showConfirmationPopup.visible}
                            headerText={showConfirmationPopup.header}
                            subHeaderText={showConfirmationPopup.subHeader}
                            description={showConfirmationPopup.description}
                            acceptButtonDisabled={showConfirmationPopup.acceptButtonDisabled}
                            acceptLabel={showConfirmationPopup.acceptLabel}
                            rejectLabel={showConfirmationPopup.rejectLabel}
                            isShowAcceptButton={showConfirmationPopup.isShowAcceptButton}
                            isShowRejectButton={showConfirmationPopup.isShowRejectButton}
                        />
                    )}
                    <DataTableComponent
                        showPagination={false}
                        showHeader={false}
                        tableData={countryTableData}
                        tableDefinition={tableDefinition}
                        toggleRowData={() => {}}
                        dataKey="taskID"
                        tableRequestBodyData={tableRequestBody}
                        handleFilter={(e) => {
                            setTableRequestBody(e);
                            handleFilter(e);
                        }}
                        handleSort={(e) => {
                            setTableRequestBody(e);
                            sortHandler(e);
                        }}
                        handlePagination={setTableRequestBody}
                    />
                </div>
                <div className="h-12 flex flex-row p-5 justify-end">
                    <span className="text-xl">{t('COMMON.TOTAL')}</span>{' '}
                    <span className="break-words text-xl font-bold mx-2">{`${currencySymbol} ${countryDetails?.total && formatCurrency(countryDetails.total.toFixed(2))}`}</span>
                </div>
            </div>
        </div>
    );
};

export default CountryDetailsPage;
