import { ColumnDefinition, DataTableDefinition } from 'shared/dataTable/types/dataTable.types';
import { CountryAndLanguageDetailModel } from './epUpCountryDetails';

import { useEffect, useState } from 'react';
import { FilterType, TableTypes, ValueType } from 'shared/dataTable/constant/dataTable.constant';
import DataTableComponent from 'shared/dataTable/dataTable';
import { Tooltip } from 'primereact/tooltip';
import NotAllowedIcon from 'assets/svgs/not-allowed-symbol.svg';
import {
    formatCurrency,
    isAdminUser,
    isProjectManagerUser,
    showToastMessage
} from 'core/utils/utils';
import { FilterMatchMode } from 'primereact/api';
import { t } from 'i18next';
import { tooltipStyle, translationFeeInputSwitchPT } from 'constants/styles.constant';
import { LANGUAGE_ID, STATUS_MODE } from 'constants/app.constant';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { EditFieldInline } from 'pages/ViewOrderAndQuote/shared/editFieldHelper';
import {
    EPvalidateVendorAssignment,
    updateCountryFees
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { v4 as uuidv4 } from 'uuid';
import { ViewOrderType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { InputSwitch } from 'primereact/inputswitch';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';

interface NonUpListProps {
    tableRowData: CountryAndLanguageDetailModel[];
    title: string;
    serviceType: 'EP' | 'Non-UP' | 'UP' | '713Claims';
    currencySymbol?: string | null | undefined;
    viewData?: ViewOrderType | null;
    setCountryEditResponse: any;
    countryEditResponse: boolean;
}

const EPOrNonUpList: React.FC<NonUpListProps> = ({
    tableRowData,
    title,
    serviceType,
    currencySymbol,
    viewData,
    setCountryEditResponse,
    countryEditResponse
}) => {
    const [localFilterData, setLocalFilterData] = useState<any>({});
    const [columnSchema, setColumnSchema] = useState<ColumnDefinition[]>([]);
    const statusId: number = viewData?.headers?.statusId as number;

    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisAdminUser = isAdminUser(loggedInUserId);
    const isThisProjectManagerUser = isProjectManagerUser(loggedInUserId);

    const requestId = viewData?.headers.requestId as number;
    const handlePopConfirmConfirm = () => {};
    const [showConfirmationPopup, setShowConfirmationPopup] = useState({
        visible: false,
        handlePopConfirmConfirm,
        header: '',
        subHeader: '',
        description: '',
        acceptButtonDisabled: false,
        acceptLabel: 'Yes',
        rejectLabel: 'No',
        isShowAcceptButton: false,
        isShowRejectButton: false
    });
    function isChecked(rowData: any, field: any): boolean {
        return (rowData[field] as boolean) ?? false;
    }

    const handleCancel = () => {
        setCountryEditResponse(!countryEditResponse);
    };
    // editFieldTemplate function is used for inline edit of table cells
    // field params gets cell value
    const editFieldTemplate = (fieldValue: number, fieldName: string, rowData: any) => {
        const row = rowData;
        const countryId = rowData?.countryId;
        const languageId = rowData?.languageId;

        const ValidationAndSaveCountryToggleChange = async (newValue: boolean) => {
            const res = await EPvalidateVendorAssignment({
                countryId,
                isAiTranslationEnabled: newValue,
                orderId: requestId
            });
            if (res.isCountryRemovable === false) {
                setShowConfirmationPopup({
                    ...showConfirmationPopup,
                    visible: true,
                    handlePopConfirmConfirm: () => void handleRateSave(newValue ? 1 : 0),
                    header: t('PV_SETTING.RATES.ERROR_MESSAGE.TRANSLATION_MODE_LOCKED'),
                    description: t(
                        'QUOTE_AND_ORDER.ERROR_MESSAGE.COUNTRY_TRANSLATION_MODE_UPDATE_FAILED'
                    ),
                    acceptButtonDisabled: true,
                    rejectLabel: t('COMMON.CANCEL'),
                    acceptLabel: t('COMMON.YES'),
                    isShowAcceptButton: false,
                    isShowRejectButton: true
                });
            } else {
                handleRateSave(newValue ? 1 : 0);
            }
        };

        // Add a type for idKey that allows isUp
        type IdKeyType = { countryId: number; languageId?: number; isUp?: boolean };

        const handleRateSave = async (newValue: number) => {
            setShowConfirmationPopup({ ...showConfirmationPopup, visible: false });

            const updatedValue = newValue;
            let payload;
            let idKey: IdKeyType = countryId !== 0 ? { countryId } : { countryId: 0, languageId };
            if (
                serviceType === 'UP' &&
                languageId !== 0 &&
                fieldName === 'translationFee' &&
                row !== null
            ) {
                idKey = { countryId: 0, languageId, isUp: true };
            } else if (
                serviceType === 'UP' &&
                languageId !== 0 &&
                fieldName === 'agencyFee' &&
                row !== null
            ) {
                idKey = { countryId, languageId: 0, isUp: true };
            }
            if (fieldName === 'agencyFee') {
                payload = {
                    agencyFee: updatedValue,
                    ...idKey
                };
            }
            if (fieldName === 'officialFee') {
                payload = {
                    officialFee: updatedValue,
                    ...idKey
                };
            }
            if (fieldName === 'translationFee') {
                payload = {
                    translationFee: updatedValue,
                    ...idKey
                };
            }

            try {
                const response = await updateCountryFees(
                    payload,
                    viewData?.headers.requestId as number
                );
                if (response) {
                    setCountryEditResponse(!countryEditResponse);
                }
            } catch (error) {
                console.error(error);
                showToastMessage({
                    message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_COUNTRY_LIST'),
                    type: ToastType.ERROR
                });
            }
        };
        let includeFee: boolean = true;
        if (fieldName === 'agencyFee') {
            includeFee = rowData.includeAgencyFee ?? true;
        } else if (fieldName === 'translationFee') {
            includeFee = rowData.includeTranslationFee ?? true;
        } else if (fieldName === 'officialFee') {
            includeFee = rowData.includeOfficialFee ?? true;
        }
        if (includeFee !== false) {
            // return (
            //     <EditFieldInline
            //         key={uuidv4()}
            //         statusId={viewData?.headers.statusId as number}
            //         fieldValue={fieldValue || 0}
            //         currency={currencySymbol}
            //         onSave={handleRateSave}
            //         onCancel={handleCancel}
            //     />
            // );
            return (
                <div className="flex items-center justify-between">
                    <p>{rowData.isAiTranslationConfiguration}</p>
                    <p>{rowData.isAiTranslationConfiguration}</p>
                    {fieldName === 'translationFee' &&
                        (statusId !== STATUS_MODE.PREPARING_QUOTE &&
                        statusId !== STATUS_MODE.WAITING_FOR_APPROVAL &&
                        (isThisAdminUser || isThisProjectManagerUser) &&
                        rowData.isAiTranslationConfiguration === true ? (
                            <div className="translation-fee-cell flex">
                                <InputSwitch
                                    checked={isChecked(rowData, 'isUserPreferredAiTranslation')}
                                    pt={translationFeeInputSwitchPT}
                                    onChange={(e) => {
                                        setShowConfirmationPopup({
                                            ...showConfirmationPopup,
                                            visible: true,
                                            handlePopConfirmConfirm: () =>
                                                void ValidationAndSaveCountryToggleChange(e.value),
                                            header: t('COMMON.CONFIRMATION'),
                                            description: t(
                                                'QUOTE_AND_ORDER.TRANSLATION_MODE_CHANGE_CONFIRMATION'
                                            ),
                                            rejectLabel: t('COMMON.NO'),
                                            acceptLabel: t('COMMON.YES'),
                                            isShowAcceptButton: true,
                                            isShowRejectButton: true
                                        });
                                    }}
                                />
                            </div>
                        ) : (
                            <div className="translation-fee-cell flex">
                                {(rowData.isAiTranslationConfiguration === true ||
                                    rowData.isAiTranslationConfiguration === true) && (
                                    <InputSwitch
                                        checked={isChecked(rowData, 'isUserPreferredAiTranslation')}
                                        pt={translationFeeInputSwitchPT}
                                        disabled={true}
                                    />
                                )}
                            </div>
                        ))}
                    <EditFieldInline
                        key={uuidv4()}
                        statusId={statusId}
                        fieldValue={fieldValue || 0}
                        currency={viewData?.additionalInfo?.currencySymbol || currencySymbol}
                        onSave={handleRateSave}
                        onCancel={handleCancel}
                    />
                </div>
            );
        } else {
            return (
                <div className="w-full flex justify-end">
                    <div className="w-fit">
                        <Tooltip
                            target={`#tooltip-target-${languageId}-${countryId}-${fieldName}`}
                            content="This fee is not included in the total"
                            position="left"
                            pt={tooltipStyle}
                        />
                        <img
                            id={`tooltip-target-${languageId}-${countryId}-${fieldName}`}
                            className="w-[0.8rem] h-[0.8rem] cursor-pointer"
                            src={NotAllowedIcon}
                            alt="No Value"
                        />
                    </div>
                </div>
            );
        }
    };

    const agencyFeeTemplate = (rowData: any) => {
        const doNotRender = validateRowData(rowData);
        if (doNotRender) return null;

        const agencyFee = rowData?.agencyFee;
        return editFieldTemplate(agencyFee as number, 'agencyFee', rowData);
    };
    const officialFeeTemplate = (rowData: any) => {
        const doNotRender = validateRowData(rowData);
        if (doNotRender) return null;

        const officialFee = rowData?.officialFee;
        return editFieldTemplate(officialFee as number, 'officialFee', rowData);
    };
    const translationFeeTemplate = (rowData: any) => {
        const translationFee = rowData?.translationFee;
        return editFieldTemplate(translationFee as number, 'translationFee', rowData);
    };
    const totalTemplate = (rowData: any) => {
        return (
            <div className="w-full flex justify-end">
                <div className="w-fit"></div>
                <span>{`${viewData?.additionalInfo?.currencySymbol || currencySymbol} ${formatCurrency(rowData?.total as number)}`}</span>
            </div>
        );
    };

    const validateRowData = (country: any): boolean => {
        return (!country.countryId || country.countryId === 0) &&
            country.languageId === LANGUAGE_ID.ENGLISH
            ? true
            : false;
    };

    let columnNumber = 0;
    const Get713ClaimsSchema = (): ColumnDefinition[] => {
        return [
            {
                columnNumber: columnNumber++,
                field: 'sourceLanguageName',
                header: 'Source Language',
                cellDataStyle:
                    'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.Status,
                visibility: true
            },
            {
                columnNumber: columnNumber++,
                field: 'officialLanguage',
                header: 'Target Language',

                cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.Status,
                visibility: true
            },
            {
                columnNumber: columnNumber++,
                field: 'translationFee',
                header: 'Translation Fee',
                body: translationFeeTemplate,
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true
            },
            {
                columnNumber: columnNumber++,
                field: 'total',
                header: 'Total',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                body: totalTemplate
            }
        ];
    };
    let epColumnNumber = 0;
    const GetEPTableSchema = (): ColumnDefinition[] => {
        return [
            {
                columnNumber: epColumnNumber++,
                field: 'countryName',
                header: 'Country',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                frozen: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'sourceLanguageName',
                header: 'Source Language',
                cellDataStyle:
                    'text-golden-brown bg-cream-yellow border-soft-yellow border-[0.5px]',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.Status,
                visibility: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'officialLanguage',
                header: 'Target Language',
                cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.Status,
                visibility: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'agencyFee',
                header: 'Agency Fee',
                sortable: true,
                filter: true,
                body: agencyFeeTemplate,
                //  body: getRateColumnTemplate('agencyFee'),
                filterType: FilterType.Default,
                visibility: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'officialFee',
                header: 'Official Fee',
                body: officialFeeTemplate,
                // body: getRateColumnTemplate('officialFee'),
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'translationFee',
                header: 'Translation Fee',
                body: translationFeeTemplate,
                // body: getRateColumnTemplate('translationFee'),
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true
            },
            {
                columnNumber: epColumnNumber++,
                field: 'total',
                header: 'Total',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                body: totalTemplate
            }
        ];
    };
    const GetUPTableSchema = (): ColumnDefinition[] => {
        return [
            {
                columnNumber: 1,
                field: 'countryName',
                header: 'UP Countries',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.MultiSelect,
                visibility: true,
                className: '!w-[100px]',
                frozen: false
            },
            {
                columnNumber: 2,
                field: 'officialLanguage',
                header: 'Target Language',
                cellDataStyle: 'text-midnight-blue bg-pale-blue border-soft-blue border-[0.5px]',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: ValueType.Status,
                visibility: true,
                className: '!w-[100px]'
            },
            {
                columnNumber: 3,
                field: 'agencyFee',
                header: 'Agency Fee',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                body: agencyFeeTemplate,
                className: 'w-[100px]'
            },
            {
                columnNumber: 4,
                field: 'translationFee',
                header: 'Translation Fee',
                body: translationFeeTemplate,
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                className: 'w-[100px]'
            },
            {
                columnNumber: 5,
                field: 'total',
                header: 'Total',
                sortable: true,
                filter: true,
                filterType: FilterType.Default,
                valueType: 'Text',
                visibility: true,
                className: 'w-[100px]',
                body: totalTemplate
            }
        ];
    };
    const updatedColumnSchema = (): ColumnDefinition[] => {
        let schema: ColumnDefinition[] = [];
        if (serviceType === '713Claims') {
            schema = Get713ClaimsSchema();
        } else if (serviceType === 'UP') {
            if (
                viewData?.requestDetails.category === 'european_patent' &&
                viewData?.requestDetails.services === 'translation_only'
            ) {
                schema = GetUPTableSchema().filter((col) => col.field !== 'agencyFee');
            } else {
                schema = GetUPTableSchema();
            }
        } else {
            if (
                viewData?.requestDetails.category === 'european_patent' &&
                viewData?.requestDetails.services === 'translation_only'
            ) {
                schema = GetEPTableSchema().filter(
                    (col) => col.field !== 'agencyFee' && col.field !== 'officialFee'
                );
            } else {
                schema = GetEPTableSchema();
            }
        }
        setColumnSchema(schema);
        setLocalFilterData(generateFilterState(schema));

        return schema;
    };
    const generateFilterState = (columns: ColumnDefinition[]) => {
        const filterState: { [key: string]: { value: any; matchMode: FilterMatchMode } } = {};
        columns.forEach((column) => {
            if (column.filter) {
                filterState[column.field] = {
                    value: null, // initial value (can be updated as user interacts with the filter)
                    matchMode: FilterMatchMode.CONTAINS // default match mode
                };
            }
        });
        setLocalFilterData(filterState);
        return filterState;
    };

    const tableDefinition: DataTableDefinition = {
        lazyLoad: false,
        reOrderableColumns: true,
        tableType: TableTypes.BOTH_DECIDE_LATER_NON_UP_TABLE,
        title,
        emptyMessage: t('COMMON.NO_DATA_FOUND'),
        localStorageKey: 'non-up',
        hideColumnSelector: true,
        hideTableExport: false,
        filters: localFilterData,
        tableCustomStyle: 'p-0 !pt-0',
        columns: columnSchema,
        customTableHeight: false
    };

    useEffect(() => {
        updatedColumnSchema();
    }, [tableRowData]);

    const reqSorting = {
        searchModels: [],
        sorting: {
            propertyName: '',
            value: ''
        },
        pageNo: 0,
        pageCount: 0
    };
    return (
        <>
            {/* Tooltip binding */}

            <div className="grid grid-cols-1 gap-4 mt-3">
                <DataTableComponent
                    tableData={tableRowData}
                    tableDefinition={tableDefinition}
                    tableRequestBodyData={reqSorting}
                    toggleRowData={() => {}}
                    isLazy={false}
                    handleFilter={(e) => {
                        setLocalFilterData(e.filters);
                    }}
                />
            </div>
        </>
    );
};

export default EPOrNonUpList;
