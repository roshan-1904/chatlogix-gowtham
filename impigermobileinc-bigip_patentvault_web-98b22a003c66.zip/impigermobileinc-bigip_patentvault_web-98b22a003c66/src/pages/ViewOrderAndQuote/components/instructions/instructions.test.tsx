import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import InstructionsAndComments from './instructions';

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('Render the instrucion and comments section', () => {
    test('Check the render of instruction and comments', () => {
        const instructionPMData = {
            pmInstruction: {
                isEdit: false,
                isError: false,
                value: '',
                newValue: ''
            },
            pmCreatedAt: {
                isEdit: false,
                value: '2024-07-31T09:56:59.253'
            },
            cuInstruction: {
                isEdit: false,
                isError: false,
                value: '',
                newValue: ''
            },
            cuCreatedAt: {
                isEdit: false,
                value: '2024-07-31T09:56:59.253'
            }
        };
        render(
            <InstructionsAndComments
                instructionData={instructionPMData}
                instructionEditImageClick={() => {}}
                handleSaveAI={() => {}}
                handleCancelAI={() => {}}
                handleChange={() => {}}
                viewData={{}}
            />
        );
    });
});
