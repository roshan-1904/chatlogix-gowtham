import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import {
    formatDateWithTime,
    isContactUser,
    isStaffUser,
    isFinanceUser,
    isVendorUser
} from 'core/utils/utils';
import { useMemo } from 'react';
import edit from 'assets/images/editGrey.svg';
import { editActionsIcons } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import { InstructionType } from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { t } from 'i18next';
import { CATEGORY_TYPE, SERVICE_TYPES } from 'constants/app.constant';
import { Editor } from 'primereact/editor';

interface InstructionsAndCommentsProps {
    instructionData: InstructionType;
    instructionEditImageClick: any;
    handleSaveAI: (value1: string, value2: string) => void;
    handleCancelAI: (value1: string, value2: string) => void;
    handleChange: any;
    viewData: any;
    isEditable?: boolean;
}

interface CommentsBlockProps {
    commentTitle: string;
    fieldName: string;
    isEdit: boolean;
    inputValue?: string;
    section: string;
    isError: boolean;
    textValue: string;
    errorMessage: string;
    createdValue?: string | null;
    isRoleHasPermission: boolean;
    isDisclaimer?: boolean;
}

const InstructionsAndComments: React.FC<InstructionsAndCommentsProps> = ({
    instructionData,
    instructionEditImageClick,
    handleSaveAI,
    handleCancelAI,
    handleChange,
    viewData,
    isEditable
}) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisStaffUser = isStaffUser(loggedInUserRoleId);
    const isThisFinanceUser = isFinanceUser(loggedInUserRoleId);
    const isThisVendorUser = isVendorUser(loggedInUserRoleId);
    const isThisContactUser = isContactUser(loggedInUserRoleId);
    const isSTDFlow = viewData?.requestDetails?.category === CATEGORY_TYPE.other_translations;
    const isUPCOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;
    const commentsBlock = ({
        commentTitle,
        fieldName,
        isEdit = false,
        inputValue,
        section = '',
        isError = false,
        textValue = '',
        errorMessage = '',
        createdValue = null,
        isRoleHasPermission = false,
        isDisclaimer = false
    }: CommentsBlockProps) => (
        <div className="w-full p-2">
            <div className="flex">
                <span className="text-neutral-700 font-medium">{commentTitle}</span>
                {isRoleHasPermission && !isThisFinanceUser && (
                    <img
                        src={edit}
                        className="h-3 p-0 mx-3 color-neutral-700 cursor-pointer"
                        alt="edit-grey-icon"
                        onClick={() => instructionEditImageClick(fieldName)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                                instructionEditImageClick(fieldName);
                            }
                        }}
                        tabIndex={0}
                    />
                )}
            </div>
            <div
                className="flex flex-col w-full my-2 h-auto border-neutral-50 border-2 rounded-lg p-5"
                style={{ backgroundColor: '#9a9a9a1a' }}>
                {isEdit ? (
                    <div className="flex flex-col items-start">
                        <div className="flex w-full">
                            {fieldName !== 'customDisclaimer' ? (
                                <Editor
                                    value={inputValue}
                                    pt={{
                                        toolbar: {
                                            className:
                                                'bg-gray-100 rounded-tr-md rounded-tl-md border border-gray-300 box-border font-sans px-2 py-1'
                                        },
                                        root: {
                                            className: 'bg-white w-full'
                                        },
                                        formats: {
                                            className: 'inline-block align-middle mr-4'
                                        }
                                    }}
                                    onTextChange={(e) => handleChange(fieldName, e.htmlValue)}
                                    style={{
                                        maxHeight: '250px',
                                        minHeight: '70px',
                                        height: 'auto',
                                        overflow: 'auto'
                                    }}
                                />
                            ) : (
                                <textarea
                                    value={inputValue}
                                    className="w-full text-sm font-medium input input-bordered border-neutral-100 focus:border-neutral-100 focus:outline-none h-10 rounded-md border disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200"
                                    placeholder={`${isDisclaimer ? 'Enter Custom Disclaimer' : 'Enter Instruction and Comments'}`}
                                    onChange={(e) => handleChange(fieldName, e.target.value)}
                                    style={{ fontSize: 12, paddingTop: 5 }}
                                />
                            )}
                            {editActionsIcons(
                                handleSaveAI,
                                handleCancelAI,
                                fieldName,
                                section,
                                isError
                            )}
                        </div>
                        {isError && <ErrorLabel message={errorMessage} />}
                    </div>
                ) : (
                    <>
                        <div className="flex flex-col justify-center">
                            <Editor
                                readOnly
                                value={inputValue?.replace(/\n/g, '<br />')}
                                pt={{
                                    toolbar: {
                                        className: 'hidden'
                                    },
                                    root: {
                                        className: 'w-full'
                                    },
                                    content: {
                                        className: 'bg-white !border-0'
                                    },
                                    formats: {
                                        className: 'inline-block align-middle mr-4'
                                    }
                                }}
                                style={{
                                    maxHeight: '250px',
                                    minHeight: '70px',
                                    height: 'auto',
                                    overflow: 'auto'
                                }}
                            />
                            <span
                                className="font-medium h-20 hidden"
                                style={{
                                    lineHeight: 1.5,
                                    overflowY: 'auto'
                                }}
                                dangerouslySetInnerHTML={{
                                    __html: textValue
                                }}></span>
                        </div>
                        {createdValue && (
                            <div className="text-neutral-700 font-medium mt-2">
                                {formatDateWithTime(createdValue ?? '')}
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );

    return (
        <div className="py-3 pb-3" data-testid="AddressInformation-Accordion">
            <div className="w-full h-auto">
                <div className="">
                    <div className="w-8/12">
                        {commentsBlock({
                            commentTitle: t('INSTRUCTIONS_AND_COMMENTS.INSTRUCTION_COMMENTS'),
                            fieldName: 'cuInstruction',
                            isEdit: instructionData?.cuInstruction?.isEdit || false,
                            inputValue: instructionData?.cuInstruction?.newValue,
                            section: 'Instruction',
                            isError: instructionData?.cuInstruction?.isError || false,
                            textValue: instructionData?.cuInstruction?.value || '',
                            errorMessage: t('INSTRUCTIONS_AND_COMMENTS.ERROR_INSTRUCTION'),
                            createdValue: viewData?.instructionByContactUser?.updatedAt as string,
                            isRoleHasPermission:
                                (isSTDFlow && (isThisStaffUser || isThisVendorUser)) ||
                                (!!isEditable && isThisContactUser)
                        })}
                    </div>
                    <div className="w-8/12">
                        {(isThisStaffUser || isThisVendorUser) &&
                            commentsBlock({
                                commentTitle: t(
                                    'INSTRUCTIONS_AND_COMMENTS.INTERNAL_INSTRUCTION_COMMENTS'
                                ),
                                fieldName: 'pmInstruction',
                                isEdit: instructionData?.pmInstruction?.isEdit || false,
                                inputValue: instructionData?.pmInstruction?.newValue,
                                section: 'Instruction',
                                isError: instructionData?.pmInstruction?.isError || false,
                                textValue: instructionData?.pmInstruction?.value || '',
                                errorMessage: t(
                                    'INSTRUCTIONS_AND_COMMENTS.ERROR_INTERNAL_INSTRUCTION'
                                ),
                                createdValue: viewData?.instructionByProjectManager
                                    ?.updatedAt as string,
                                isRoleHasPermission:
                                    !!isEditable && (isThisStaffUser || isThisVendorUser)
                            })}
                    </div>
                    <div className="w-8/12">
                        {(isSTDFlow || isUPCOptOut) &&
                            (isThisStaffUser || isThisVendorUser) &&
                            commentsBlock({
                                commentTitle: t('INSTRUCTIONS_AND_COMMENTS.CUSTOM_DISCLAIMER'),
                                fieldName: 'customDisclaimer',
                                isEdit: instructionData?.customDisclaimer?.isEdit || false,
                                inputValue: instructionData?.customDisclaimer?.newValue,
                                section: 'Instruction',
                                isError: instructionData?.customDisclaimer?.isError || false,
                                textValue: instructionData?.customDisclaimer?.value || '',
                                errorMessage: t(
                                    'INSTRUCTIONS_AND_COMMENTS.ERROR_CUSTOM_DISCLAIMER'
                                ),
                                isRoleHasPermission:
                                    !!isEditable && (isThisStaffUser || isThisVendorUser),
                                isDisclaimer: true
                            })}
                    </div>
                </div>
                {/* {isThisStaffUser && (
                    <div className="pt-0 p-5">
                        <span
                            className="text-neutral-700 font-medium"
                            style={{ fontSize: '0.9rem' }}>
                            Summary Comments
                        </span>
                        <div className="mt-2 h-auto bg-primary-50 border-neutral-50 border-2 rounded-lg p-5">
                            <div className="flex flex-col justify-center">
                                <span
                                    className="font-medium h-20 "
                                    style={{
                                        fontSize: '1rem',
                                        lineHeight: 1.5,
                                        overflowY: 'auto'
                                    }}>
                                    {viewData?.instructionByProjectManager?.summaryComments}
                                </span>
                                <span
                                    className="text-neutral-700 font-medium mt-2"
                                    style={{ fontSize: '0.9rem' }}>
                                    {formatDateWithTime(instructionData?.cuCreatedAt?.value || '')}
                                </span>
                            </div>
                        </div>
                    </div>
                )} */}
            </div>
        </div>
    );
};

export default InstructionsAndComments;
