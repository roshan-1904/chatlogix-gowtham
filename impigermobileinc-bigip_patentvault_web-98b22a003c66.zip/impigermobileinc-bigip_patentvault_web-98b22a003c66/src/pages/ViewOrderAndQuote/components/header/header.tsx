import userIcon from 'assets/images/user-icon.svg';
import { Dropdown } from 'primereact/dropdown';
import { dropdownFilterStyles } from 'shared/dataTable/constant/dataTable.styles';
import company from 'assets/images/company.svg';
import {
    EPSaveAmountModel,
    InvoiceTaskStatusModal,
    OtherTasksModal,
    StatusType,
    TasksStatusListModal,
    ViewOrderType
} from 'pages/ViewOrderAndQuote/types/viewDetailsTypes';
import { getStatusDisabledOptions } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import viewOrderQuoteServices, {
    getPDFData,
    updateOrderStatus
} from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import NotificationStore, {
    notificationModel,
    ToastType
} from 'core/store/notificationStore/notificationStore';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { forwardRef, useImperativeHandle, useEffect, useMemo, useState } from 'react';
import { CATEGORY_TYPE, IP_NONIP, MODE, SERVICE_TYPES, STATUS_MODE } from 'constants/app.constant';
import OrdersAndQuotesService from 'pages/ordersAndQuotes/service/ordersAndQuotes.service';
import { useTranslation } from 'react-i18next';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import { useNavigate } from 'react-router-dom';
import { PATHS } from 'constants/routes.constant';
import upArrowIcon from 'assets/svgs/up-arrow.svg';
import downArrowIcon from 'assets/svgs/down-arrow.svg';
import utils, {
    formatCurrency,
    getWindowSize,
    isContactUser,
    isStaffUser,
    isVendorSpecialistUser,
    isVendorUser
} from 'core/utils/utils';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import { Dialog } from 'primereact/dialog';
import { Tooltip } from 'primereact/tooltip';
import RequestTypeIcon from 'assets/images/request-Type-icon.svg';
import { Permissions } from 'constants/permissions';
import { TabPanel, TabView } from 'primereact/tabview';
import { commonColumnStyle, commonTableStyle, tabPanelPT } from 'constants/styles.constant';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Checkbox } from 'primereact/checkbox';

interface DropdownOption {
    label: string;
    value: string;
    color: string;
    backgroundColor: string;
    disabled: boolean;
}

interface HeaderType {
    requestId?: number;
    requestNumber?: string;
    statusName?: string;
    statusId?: number;
    companyId?: number;
    companyName?: string;
    userId?: number;
    userName?: string;
    grandTotal?: number;
    serviceType?: string;
    grossProfitPercentage: number;
    isBothDecideLater?: boolean;
}

type PropType = {
    orderInsights: HeaderType;
    statusList: StatusType[];
    state: { id: number; requestNumber: string; statusName: string };
    requestNumber: string;
    dropDownValue: string;
    setDropDownValue: any;
    currencySymbol: string;
    requestType: string;
    setStatusResponse: any;
    viewData: any;
    isQuoteCreation: boolean;
    isRebuildOrderStatusList?: number;
    isStandardFlow?: boolean;
};

type popupDataInitModel = {
    visible: boolean;
    header: string;
    subHeader: string;
    description: string | JSX.Element;
    requestId: string;
    statusid: number;
    statusName: string;
    isConfirmed: boolean;
    acceptLabel?: string;
    rejectLabel?: string;
    isApprove?: boolean;
};

export const renderPercentageTemplate = (percentage: number) => {
    return (
        <span
            data-testid="grossProfitDetails"
            className="flex flex-row ml-2 text-[13px] bg-slate-200 py-[4px] px-[4px] rounded-md font-medium items-center">
            <img
                src={percentage > 0 ? upArrowIcon : downArrowIcon}
                className="h-4 w-4"
                alt={`${percentage > 0 ? 'up' : 'down'}-arrow-icon`}
            />

            <span className="flex flex-row mx-1">{percentage}%</span>
        </span>
    );
};

export const renderSaveAmountWithPercentageTemplate = (data: EPSaveAmountModel) => {
    return (
        // Client requested to hide the save amount, So adding hidden class temporarily
        <span className="hidden">
            <span
                data-testid="grossProfitDetails"
                className="inline-flex flex-row ml-2.5 text-[13px] py-[4px] px-[4px] rounded-md font-medium items-center  bg-warning">
                <i className={data.percentage > 0 ? 'pi pi-caret-down' : 'pi pi-caret-up'} />

                <span className="flex flex-row mx-1" data-testId="save-amount">
                    {formatCurrency(data.amount)}
                    {/* ({data.percentage.toFixed(2)})% */}
                </span>
            </span>
        </span>
    );
};
// methods the parent can call
export type ViewOrderAndQuoteHeaderRef = {
    approveOrCancelButtonClick: (isApprove: boolean) => void;
};

export const ViewOrderAndQuoteHeader = forwardRef<ViewOrderAndQuoteHeaderRef, PropType>(
    (
        {
            orderInsights,
            statusList,
            state,
            requestNumber,
            dropDownValue,
            setDropDownValue,
            currencySymbol,
            requestType,
            setStatusResponse,
            viewData,
            isQuoteCreation,
            isRebuildOrderStatusList,
            isStandardFlow = false
        }: PropType,
        ref
    ) => {
        const navigate = useNavigate();
        const { t } = useTranslation();
        const popupDataInit: popupDataInitModel = {
            visible: false,
            header: t('COMMON.CONFIRMATION'),
            subHeader: '',
            description: t('COMMON.CONFIRMATION_STATUS'),
            requestId: '',
            statusid: 0,
            statusName: '',
            isConfirmed: false,
            acceptLabel: t('COMMON.YES'),
            rejectLabel: t('COMMON.NO')
        };
        const [showPopup, setShowPopup] = useState<popupDataInitModel>(popupDataInit);
        const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
        const isQuoteToOrder = viewData?.headers?.isQuote === true;
        const isOrder = viewData?.requestTypeId === MODE.CREATE_ORDER;
        const [statusOptionList, setStatusOptionList] = useState<DropdownOption[]>([]);
        const loggedInUserRoleId = userDetails.userInfo.roleId;

        const isThisStaffUser = isStaffUser(loggedInUserRoleId);
        const isThisVendorUser = isVendorUser(loggedInUserRoleId);
        const isThisContactUser = isContactUser(loggedInUserRoleId);
        const isThisContactUserExcludedSalesRep = isContactUser(loggedInUserRoleId, true);
        const isThisV3User = isVendorSpecialistUser(loggedInUserRoleId);
        const isSTDFlow = viewData?.requestDetails?.category === CATEGORY_TYPE.other_translations;
        const isToBeProcessed = dropDownValue === RequestStatusEnum.TO_BE_PROCESSED;
        const isPreparingQuote = dropDownValue === RequestStatusEnum.PREPARING_QUOTE;
        const isWFA = dropDownValue === RequestStatusEnum.WAITING_FOR_APPROVAL;
        const currentStatusId: number | null = viewData?.headers?.statusId ?? null;
        const orderRequestId: number = viewData?.headers?.requestId;
        const [isUp, setIsUp] = useState<boolean | null>(true);
        const isUPCOptOut = viewData?.requestDetails?.services === SERVICE_TYPES.upc_opt_out;

        const handleDescriptionTemplate = (hasFessZero: boolean) => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="text-black/70">
                        <div>
                            {t('QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE1')}
                            <div className="font-medium text-black">
                                {t(
                                    'QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE2'
                                )}
                            </div>
                        </div>

                        <p className="mt-1 text-black">
                            {t('QUOTE_AND_ORDER.WARNING.EP_BOTH_DECIDE_LATER_CONFIRMATION_LINE3')}
                        </p>
                    </div>
                    <div className="border-t mt-2">
                        <div className="flex gap-2 mt-2 justify-center">
                            <div className="flex flex-col gap-1.5">
                                <label className="flex items-center gap-1.5 cursor-pointer leading-7">
                                    <input
                                        type="radio"
                                        name="isUpRadioButton"
                                        value="true"
                                        defaultChecked
                                        onChange={() => {
                                            setIsUp(true);
                                        }}
                                    />
                                    {t('SUMMARY.UP_NATIONAL_VALIDATIONS')}
                                    {claimsTotal() > 0 ? ` + ${t('SUMMARY.CLAIMS')}` : ''}
                                </label>
                                <label className="flex items-center gap-1.5 cursor-pointer leading-7">
                                    <input
                                        type="radio"
                                        name="isUpRadioButton"
                                        value="false"
                                        onChange={() => {
                                            setIsUp(false);
                                        }}
                                    />

                                    {t('SUMMARY.NATIONAL_VALIDATION_ONLY')}
                                    {claimsTotal() > 0 ? ` + ${t('SUMMARY.CLAIMS')}` : ''}
                                </label>
                            </div>
                            <div className="flex flex-col justify-start items-start [&>h4]:text-base [&>h4]:font-medium  gap-3">
                                <h4>
                                    {viewData?.additionalInfo.currencySymbol ?? ''}{' '}
                                    {formatCurrency((upTotal() ?? 0) + (claimsTotal() ?? 0))}
                                    {isThisStaffUser &&
                                        renderSaveAmountWithPercentageTemplate(
                                            calculateSaveAmount()
                                        )}
                                </h4>

                                <h4>
                                    {viewData?.additionalInfo?.currencySymbol}{' '}
                                    {formatCurrency((epTotal() ?? 0) + (claimsTotal() ?? 0))}
                                </h4>
                            </div>
                        </div>
                    </div>
                    {hasFessZero && (
                        <div className="flex justify-center">
                            <p className="bg-warning/40 border text-sm border-warning-200 w-fit p-1 rounded-md flex items-center gap-2">
                                <i className="pi pi-info-circle text-sm text-warning-200"></i>{' '}
                                {t('QUOTE_AND_ORDER.WARNING.COUNTY_HAS_ZERO_VALUES')}
                            </p>
                        </div>
                    )}
                </div>
            );
        };

        const optionTemplate = (option: DropdownOption) => {
            const isDisabled = option?.disabled;
            return (
                <div
                    style={{
                        color: isDisabled ? 'gray-500' : option.color,
                        backgroundColor: option.backgroundColor,
                        opacity: isDisabled ? '50%' : '100%'
                    }}
                    className={`px-3 p-1 mx-2 w-fit ${isDisabled ? 'disabled-option' : ''}`}>
                    <span className="font-semibold uppercase">{option.label}</span>
                </div>
            );
        };

        interface OptionsType {
            isAnyTaskAssignedToVendor?: boolean;
        }
        const options = ({
            isAnyTaskAssignedToVendor = false
        }: OptionsType = {}): DropdownOption[] => {
            const isStatusChangedFromOnHoldInQuoteMode =
                isQuoteCreation && currentStatusId === STATUS_MODE.ON_HOLD;

            const updatedStatusList = getStatusDisabledOptions({
                dropDownValue,
                statusList,
                currentStatusId,
                orderRequestId,
                isAnyTaskAssignedToVendor,
                isStatusChangedFromOnHoldInQuoteMode
            });

            return updatedStatusList;
        };

        // set status dropdown list
        const fetchUpdatedStatusList = async () => {
            const createDefaultOptions = () => {
                const updatedStatusList = options();
                setStatusOptionList(updatedStatusList);
            };

            try {
                if (currentStatusId === STATUS_MODE.ON_HOLD) {
                    // set options if status is 'on hold'
                    const checkAnyTasksAssignedToVendor: {
                        isAnyTaskAssignedToVendor: boolean | null;
                    } = await viewOrderQuoteServices.checkAnyTasksAssignedToVendor(+orderRequestId);

                    if (checkAnyTasksAssignedToVendor?.isAnyTaskAssignedToVendor === null) {
                        createDefaultOptions();
                    } else {
                        const updatedStatusList = options({
                            isAnyTaskAssignedToVendor:
                                checkAnyTasksAssignedToVendor?.isAnyTaskAssignedToVendor
                        });
                        setStatusOptionList(updatedStatusList); // updated status dropdown options list
                    }
                } else {
                    createDefaultOptions(); // set options if status isn't 'on hold'
                }
            } catch (error) {
                createDefaultOptions();
                console.error('Error in fetchUpdatedStatusList(): ', error);
            }
        };

        useEffect(() => {
            currentStatusId && fetchUpdatedStatusList();
        }, [viewData, isRebuildOrderStatusList]);

        interface StatusRequestChangeType {
            requestId: number;
            statusId: number;
            statusName: string;
            isConfirmed?: boolean;
            isApprove?: boolean;
        }
        const updateOrderQuoteStatus = async (params: StatusRequestChangeType) => {
            try {
                const {
                    requestId,
                    statusId,
                    statusName,
                    isConfirmed = false,
                    isApprove = false
                } = params;
                const isApproveQuote =
                    (currentStatusId === STATUS_MODE.PREPARING_QUOTE ||
                        currentStatusId === STATUS_MODE.WAITING_FOR_APPROVAL) &&
                    statusId === STATUS_MODE.TO_BE_PROCESSED;

                const response = isApproveQuote
                    ? await OrdersAndQuotesService.updateApproveQuote(requestId)
                    : await updateOrderStatus(requestId, statusId, isConfirmed);
                if (response) {
                    setDropDownValue(statusName);
                    setStatusResponse();

                    showToastMessage({
                        message: isApprove
                            ? t('QUOTE_AND_ORDER.QUOTE_APPROVED')
                            : t('QUOTE_AND_ORDER.ORDER_STATUS_UPDATES'),
                        type: ToastType.SUCCESS
                    });
                }
            } catch (error) {
                console.error(error);
                const errorMessage =
                    ((error as any).response?.data?.Message as string) ??
                    'Failed to update order status';
                showToastMessage({ message: errorMessage, type: ToastType.ERROR });
            }
        };

        const getStatusId = (value: string) => {
            return statusList?.find((item) => item?.name === value)?.id;
        };

        const handleStatusChange = async (
            reqId: string,
            statusId: number,
            statusname: string,
            isApprove?: boolean,
            isCancel?: boolean
        ) => {
            try {
                // COMPLETED
                if (
                    statusId === STATUS_MODE.COMPLETED &&
                    viewData?.additionalInfo?.requiredFields?.isPoNumber &&
                    !viewData?.additionalInfo?.poNumber
                ) {
                    showToastMessage({
                        message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.PO_NUMBER_REQUIRED'),
                        type: ToastType.ERROR
                    });
                    return;
                }

                // WAITING FOR APPROVAL
                if (
                    !isIP &&
                    statusId === STATUS_MODE.WAITING_FOR_APPROVAL &&
                    !viewData?.headers.stdPreviewType
                ) {
                    showToastMessage({
                        message: t(
                            'QUOTE_AND_ORDER.ERROR_MESSAGE.WARNING_EMPTY_PREVIEW_TEMPLATE_ON_STATUS_CHANGE'
                        ),
                        type: ToastType.ERROR
                    });
                    return;
                }

                let updatedShowPopup: popupDataInitModel = {
                    ...showPopup,
                    requestId: reqId,
                    statusid: statusId,
                    statusName: statusname,
                    description: isApprove
                        ? t('COMMON.CONFIRMATION_APPROVE')
                        : t('COMMON.CONFIRMATION_STATUS'),
                    isApprove
                };
                if (isCancel) {
                    updatedShowPopup = {
                        ...showPopup,
                        header: t('COMMON.CONFIRMATION_CANCEL_QUOTE_TITLE'),
                        requestId: reqId,
                        statusid: statusId,
                        statusName: statusname,
                        description: t('COMMON.CONFIRMATION_CANCEL_QUOTE'),
                        isApprove,
                        acceptLabel: t('COMMON.CONFIRM'),
                        rejectLabel: t('COMMON.CANCEL')
                    };
                }

                let hasFessZero = false;
                /** we have to show confirmation popup while user change status with '0' fees in countries.
                 *  Note: check only for these Status changes.
                 *  To achieve this we reuse the existing popup, and just change the desc only. */
                /** for STD flow they(BED) validate the Bills & Invoice tab fees. we have separate API for IP/Non-IP.
                 *  we have handled that in service file. */
                const isValidateTablesHaveFeesAsZero: boolean =
                    STATUS_MODE.WAITING_FOR_APPROVAL === statusId ||
                    STATUS_MODE.TO_BE_PROCESSED === statusId;
                if (isValidateTablesHaveFeesAsZero && isStandardFlow !== true) {
                    const checkCountryFeesHaveZeroFees: { hasZeroValues: boolean } | null =
                        await viewOrderQuoteServices.checkFeesHasZeroValues(+reqId);

                    if (checkCountryFeesHaveZeroFees?.hasZeroValues) {
                        hasFessZero = true;
                        updatedShowPopup.description = isStandardFlow
                            ? isApprove
                                ? t('COMMON.CONFIRMATION_APPROVE_WITH_ZERO_FEES_NON_IP')
                                : t('COMMON.CONFIRMATION_STATUS_WITH_ZERO_FEES_NON_IP', {
                                      statusLabelName: statusname
                                  })
                            : (viewData as ViewOrderType).headers.isBothDecideLater === true &&
                                statusId === STATUS_MODE.TO_BE_PROCESSED
                              ? handleDescriptionTemplate(
                                    checkCountryFeesHaveZeroFees?.hasZeroValues
                                )
                              : isApprove
                                ? isUPCOptOut
                                    ? t('COMMON.CONFIRMATION_APPROVE_TASK_WITH_ZERO_FEES')
                                    : t('COMMON.CONFIRMATION_APPROVE_WITH_ZERO_FEES_IP')
                                : isUPCOptOut
                                  ? t('COMMON.CONFIRMATION_STATUS_TASK_WITH_ZERO_FEES')
                                  : t('COMMON.CONFIRMATION_STATUS_WITH_ZERO_FEES_IP');
                    }
                }
                // IN-PROGRESS -> COMPLETED
                // confirmation about -> validation official fee / management
                const isValidationNeeded =
                    currentStatusId === STATUS_MODE.IN_PROGRESS &&
                    statusId === STATUS_MODE.COMPLETED;
                if (isValidationNeeded) {
                    const checkValidation: { message: string; isValid: boolean } | null =
                        await viewOrderQuoteServices.checkFeesValidation(+reqId);
                    if (checkValidation?.isValid) {
                        invoiceBillsDetailsPopup({ requestId: +reqId, updatedShowPopup });
                    } else if (checkValidation?.message) {
                        showToastMessage({
                            message: checkValidation.message,
                            type: ToastType.ERROR
                        });
                    }
                    return;
                }

                if (
                    orderInsights.isBothDecideLater === true &&
                    statusId === STATUS_MODE.TO_BE_PROCESSED
                ) {
                    updatedShowPopup.description = handleDescriptionTemplate(hasFessZero);
                    updatedShowPopup.acceptLabel = t('COMMON.CONFIRM');
                    updatedShowPopup.rejectLabel = t('COMMON.CANCEL');
                }

                setShowPopup({ ...updatedShowPopup, visible: true });
            } catch (error) {
                console.error('Error in handleStatusChange(): ', error);
            }
        };
        const invoiceBillsDetailsPopup = async (params: {
            requestId: number;
            updatedShowPopup: popupDataInitModel;
        }) => {
            const tasksStatusList: TasksStatusListModal =
                await viewOrderQuoteServices.checkTasksStatus(params.requestId);

            const isValidRes =
                (tasksStatusList?.invoiceTasks && tasksStatusList.invoiceTasks.length > 0) ||
                tasksStatusList?.otherTasks.approvedTaskCategory !== '' ||
                tasksStatusList?.otherTasks.nonBillableCategory !== '';
            // tasksStatusList?.otherTasks.unApprovedTaskCategory !== ''

            if (isValidRes) {
                const otherTasks: OtherTasksModal[] = [];
                Object.keys(tasksStatusList.otherTasks).forEach(
                    (key: keyof typeof tasksStatusList.otherTasks) => {
                        const taskDetails: OtherTasksModal = {
                            categoryName: getCategoryNames(key.toString()),
                            categoryKey: key.toString(),
                            taskIds: tasksStatusList.otherTasks[key]
                        };
                        if (taskDetails.taskIds !== '') {
                            otherTasks.push(taskDetails);
                        }
                    }
                );

                tasksStatusList.otherTasksList = otherTasks;
                setTasksStatusList(tasksStatusList);
                setTaskStatusVisible(true);

                // we use another "Details-Popup" for this condition.
                // just update/keep the details in this 'showPopup'.
                // because, we have to use this details in the payload, once details-popup confirmed.
                setShowPopup({ ...params.updatedShowPopup, visible: false });
            }
        };

        const getCategoryNames = (category: string) => {
            switch (category) {
                // case 'unApprovedTaskCategory':
                //     return 'Unapproved Tasks';
                case 'approvedTaskCategory':
                    return 'Approved Tasks';
                case 'nonBillableCategory':
                    return 'Non-Billable Tasks';
                default:
                    return '';
            }
        };

        const updateStatus = () => {
            updateOrderQuoteStatus({
                requestId: +showPopup.requestId,
                statusId: showPopup.statusid,
                statusName: showPopup.statusName,
                isConfirmed: showPopup.isConfirmed,
                isApprove: showPopup.isApprove
            });
            setShowPopup({ ...popupDataInit, visible: false });
        };

        // Order Type Component
        const OrderType = (orderType: string) => {
            if (orderType === '') return;
            let displayText = '';
            if (requestType === IP_NONIP.ip) {
                displayText = t('COMMON.IP');
            } else if (requestType === IP_NONIP.nonIp) {
                displayText = t('COMMON.NON_IP');
            }

            return (
                <span className="font-semibold" data-testid="header-request-type-text">
                    {displayText}
                </span>
            );
        };

        const [visible, setVisible] = useState<boolean>(false);
        const [taskStatusVisible, setTaskStatusVisible] = useState<boolean>(false);
        const [activeIndex, setActiveIndex] = useState(0);
        const [orderConfirmation, setOrderConfirmation] = useState(false);
        const [tasksStatusList, setTasksStatusList] = useState<TasksStatusListModal>();
        const [pdfUrl, setPdfUrl] = useState<string>('');
        const showToastMessage = (message: notificationModel) => {
            NotificationStore.showAlert(message);
        };
        const templateName = viewData?.requestDetails?.serviceUniqueName || '';
        const requestIdData = viewData?.headers?.requestId;
        const statusName = viewData?.headers?.statusName;
        const requestTypeName = viewData?.requestType;
        const isIP = requestTypeName === IP_NONIP.ip;
        const stdPreviewType = viewData?.stdPreviewType || null; // used '||' to restrict the empty string.

        const downloadPDF = async () => {
            try {
                if (isSTDFlow && !stdPreviewType) {
                    showToastMessage({
                        message: t(
                            'QUOTE_AND_ORDER.ERROR_MESSAGE.WARNING_EMPTY_PREVIEW_TEMPLATE_ON_PREVIEW_FILE'
                        ),
                        type: ToastType.ERROR
                    });
                    return null;
                }

                const response = await getPDFData(templateName as string, requestIdData as number);
                setPdfUrl(response);
                if (response) {
                    setVisible(true);
                }
            } catch (error) {
                showToastMessage({
                    message: t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'),
                    type: ToastType.ERROR
                });
                console.error('Error in downloadPDF()');
                return null;
            }
        };
        const otherTasksTemplate = (str: string) => {
            const taskIds = str.split(',');
            const template = (
                <div className="flex flex-wrap gap-1">
                    {taskIds.map((task, index) => (
                        <span
                            key={index + 1}
                            className="text-[#11334E] bg-[#E8F3FC] border-[#B0D7F4] border uppercase p-[0px] px-2 rounded-[3px] font-medium text-sm py-1 inline-block">
                            {task}
                        </span>
                    ))}
                </div>
            );

            return template;
        };
        const otherTasksColumnTemplate = (rowData: OtherTasksModal) => {
            return <div className="flex flex-row">{rowData.categoryName}</div>;
        };
        const isShowBillTasksTab = () => {
            const isShow: boolean =
                (tasksStatusList?.otherTasks &&
                    Object.values(tasksStatusList.otherTasks).length > 0 &&
                    Object.values(tasksStatusList.otherTasks).some(
                        (item) => item && item.trim() !== ''
                    )) ??
                false;

            return isShow;
        };

        const isShowEditButton = () => {
            const isShow: boolean =
                isQuoteToOrder &&
                (isThisStaffUser ||
                    isThisVendorUser ||
                    (isThisContactUser && (isPreparingQuote || isWFA))) &&
                !isToBeProcessed &&
                /** check permission */
                (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                    AuthStore.hasPermission(Permissions.EDIT_ORDER));

            return isShow;
        };

        const upTotal = (): number => {
            return viewData?.headers?.epUpGrandTotalModel?.upTotal ?? 0;
        };
        const claimsTotal = (): number => {
            return viewData?.headers?.epUpGrandTotalModel?.claimsTotal ?? 0;
        };
        const epTotal = (): number => {
            return viewData?.headers?.epUpGrandTotalModel?.epTotal ?? 0;
        };
        const calculateSaveAmount = (): EPSaveAmountModel => {
            const up: number = upTotal();
            const ep: number = epTotal();
            const amount = ep - up;
            const percentage = ((ep - up) / ep) * 100;
            return { amount, percentage };
        };

        const getTabPanelPT = (index: number) => {
            return tabPanelPT(activeIndex === index, () => setActiveIndex(index));
        };

        const approveEPQuote = async (isApprove: boolean) => {
            try {
                const response = await OrdersAndQuotesService.updateApproveQuote(
                    (viewData as ViewOrderType).headers.requestId,
                    isUp
                );
                if (response) {
                    showToastMessage({
                        message: isApprove
                            ? t('QUOTE_AND_ORDER.QUOTE_APPROVED')
                            : t('QUOTE_AND_ORDER.ORDER_STATUS_UPDATES'),
                        type: ToastType.SUCCESS
                    });
                    setStatusResponse();
                }
            } catch (error) {
                console.error(error);
                const errorMessage =
                    ((error as any).response?.data?.Message as string) ??
                    'Failed to update order status';
                showToastMessage({ message: errorMessage, type: ToastType.ERROR });
            }
        };
        const handlePopupConfirm = (isApprove: boolean) => {
            setShowPopup({ ...showPopup, visible: false });
            approveEPQuote(isApprove);
        };

        const approveButtonClick = (): void => {
            handleStatusChange(
                (viewData as ViewOrderType).headers.requestId + '',
                STATUS_MODE.TO_BE_PROCESSED,
                RequestStatusEnum.TO_BE_PROCESSED,
                true
            );
        };
        const cancelButtonClick = (): void => {
            handleStatusChange(
                (viewData as ViewOrderType).headers.requestId + '',
                STATUS_MODE.CANCELED,
                RequestStatusEnum.CANCELED,
                false,
                true
            );
        };

        const approveOrCancelButtonClick: (isApprove: boolean) => void = (isApprove) => {
            if (isApprove) approveButtonClick();
            else cancelButtonClick();
        };

        useImperativeHandle(ref, () => ({
            approveOrCancelButtonClick
        }));

        return (
            <div className="relative grid grid-cols-1 md:grid-cols-4 lg:grid-cols-none lg:grid-flow-col gap-4 temp p-3 items-center justify-between px-5 w-full bg-primary-50 border-neutral-50 border-2 rounded-lg">
                <Dialog
                    header={
                        <div className="w-full flex justify-between items-center">
                            {(viewData?.requestTypeId === MODE.CREATE_QUOTE
                                ? t('COMMON.QUOTE') + ' - '
                                : t('COMMON.ORDER') + ' - ') +
                                (viewData?.headers?.requestNumber ?? 'Preview')}
                            <i
                                className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                                onClick={() =>
                                    utils.handleDownloadPngSvg(
                                        pdfUrl,
                                        (viewData?.requestTypeId === MODE.CREATE_QUOTE
                                            ? t('COMMON.QUOTE') + ' - '
                                            : t('COMMON.ORDER') + ' - ') +
                                            (viewData?.headers?.requestNumber ?? 'Preview')
                                    )
                                }
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            />
                        </div>
                    }
                    visible={visible}
                    style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                    onHide={() => setVisible(false)}>
                    <iframe
                        src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                        style={{ width: '100%', minHeight: '80vh' }}
                    />
                </Dialog>

                <Dialog
                    data-testid={'manual-task-verification-dialog'}
                    visible={taskStatusVisible}
                    draggable={false}
                    pt={{
                        headerTitle: { className: 'w-full !font-semibold text-xl' },
                        header: { className: '!p-4 !rounded-md !rounded-b-none border-b' },
                        closeButton: { className: 'focus:shadow-none' },
                        root: { className: 'shadow-none' },
                        content: {
                            className: 'p-4'
                        },
                        footer: {
                            className: 'flex justify-between items-center gap-3 p-4 pt-0'
                        }
                    }}
                    header={
                        <h4 className="font-semibold">{t('QUOTE_AND_ORDER.CONFIRM_TASK_TITLE')}</h4>
                    }
                    footer={
                        <div className="flex justify-between w-full">
                            <div className="flex items-center gap-2">
                                <Checkbox
                                    data-testid={'manual-task-verification-checkbox'}
                                    value=""
                                    onChange={(e) => setOrderConfirmation(e.checked as boolean)}
                                    checked={orderConfirmation}
                                />
                                <label htmlFor="ingredient1">
                                    {t('QUOTE_AND_ORDER.CONFIRM_ORDER_STATUS')}
                                </label>
                            </div>
                            <div className="flex gap-2">
                                <button
                                    data-testid={'manual-task-verification-close'}
                                    className="btn button-neutral min-h-10 h-10"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => setTaskStatusVisible(false)}>
                                    {t('COMMON.CLOSE')}
                                </button>
                                <button
                                    data-testid={'manual-task-verification-confirm'}
                                    disabled={!orderConfirmation}
                                    className="btn button-primary min-h-10 h-10"
                                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                    onClick={() => {
                                        updateStatus();
                                        setTaskStatusVisible(false);
                                    }}>
                                    {t('COMMON.CONFIRM')}
                                </button>
                            </div>
                        </div>
                    }
                    className="w-full  md:max-w-[80vw] lg:max-w-[70vw] xl:max-w-[50vw] 2xl:max-w-[50vw]"
                    onHide={() => setTaskStatusVisible(false)}>
                    <div className="" data-testid={'manual-task-verification-tabView'}>
                        <TabView
                            pt={{
                                nav: {
                                    className: 'gap-4 border-0'
                                }
                            }}
                            activeIndex={activeIndex}
                            onTabChange={(e) => setActiveIndex(e.index)}>
                            <TabPanel
                                header={
                                    <div data-testid={'manual-task-verification-invoiceTab'}>
                                        <Tooltip
                                            target=".tooltip-tab-invoice-tasks"
                                            pt={{
                                                root: { className: 'max-w-[40rem] text-wrap' }
                                            }}>
                                            <span
                                                dangerouslySetInnerHTML={{
                                                    __html: t('QUOTE_AND_ORDER.INVOICE_TASKS_NOTE')
                                                }}
                                            />
                                        </Tooltip>
                                        <i
                                            className="tooltip-tab-invoice-tasks pi pi-info-circle font-semibold mr-2"
                                            data-pr-position="right"
                                            data-pr-at="right+5 top+7"
                                            data-pr-my="left center-2"
                                        />
                                        {t('ACCOUNTING.INVOICE_TASKS')}
                                    </div>
                                }
                                pt={getTabPanelPT(0)}>
                                <div className="">
                                    <DataTable
                                        pt={{
                                            ...commonTableStyle(false),
                                            wrapper: {
                                                style: { maxHeight: 'calc(100vh - 33rem)' }
                                            },
                                            paginator: {
                                                ...commonTableStyle(false).paginator,
                                                root: {
                                                    className: `${commonTableStyle(false).paginator.root.className} pt-10 relative`
                                                },
                                                end: {
                                                    className: 'absolute right-0 top-3'
                                                }
                                            }
                                        }}
                                        paginator={true}
                                        rows={10}
                                        rowsPerPageOptions={[5, 10, 20, 50]}
                                        scrollable
                                        scrollHeight={'calc(100vh - 20rem)'}
                                        value={tasksStatusList?.invoiceTasks}
                                        paginatorRight={
                                            tasksStatusList?.invoiceTasks &&
                                            tasksStatusList?.invoiceTasks?.length > 0 && (
                                                <div className="flex justify-between items-center gap-2 w-fit mt-[-10px] min-w-44 p-3 px-2 font-normal text-black">
                                                    <p className="font-semibold">Grand Total:</p>
                                                    <p>
                                                        {`${tasksStatusList?.invoiceTasks[0].requestCurrencySymbol || ''} ${formatCurrency(tasksStatusList?.invoiceTasks[0].grandTotal ?? null) || ''}`}
                                                    </p>
                                                </div>
                                            )
                                        }>
                                        <Column
                                            pt={commonColumnStyle()}
                                            field="taskId"
                                            header="Task ID"></Column>
                                        <Column
                                            pt={commonColumnStyle()}
                                            field="taskName"
                                            header="Task Description"
                                            body={(rowData: InvoiceTaskStatusModal) =>
                                                rowData.taskName || '-'
                                            }></Column>
                                        <Column
                                            pt={commonColumnStyle()}
                                            field="taskDescription"
                                            header="Lang/Country"
                                            body={(rowData: InvoiceTaskStatusModal) =>
                                                rowData.taskDescription || '-'
                                            }></Column>
                                        <Column
                                            pt={commonColumnStyle()}
                                            field="requestCurrencyAmount"
                                            body={(rowData: InvoiceTaskStatusModal) => {
                                                return `${rowData.requestCurrencySymbol || ''} ${
                                                    formatCurrency(rowData.requestCurrencyAmount) ||
                                                    ''
                                                }`;
                                            }}
                                            header="Total"></Column>
                                    </DataTable>
                                </div>
                            </TabPanel>
                            {isShowBillTasksTab() && (
                                <TabPanel
                                    header={
                                        <div data-testid={'manual-task-verification-othersTab'}>
                                            {t('ACCOUNTING.OTHER_TASKS')}
                                        </div>
                                    }
                                    pt={getTabPanelPT(1)}>
                                    <DataTable
                                        pt={commonTableStyle(false)}
                                        value={tasksStatusList?.otherTasksList}>
                                        <Column
                                            pt={{
                                                ...commonColumnStyle(),
                                                bodyCell: {
                                                    ...commonColumnStyle().bodyCell,
                                                    className: `${commonColumnStyle().bodyCell.className}`
                                                }
                                            }}
                                            field="categoryName"
                                            header="Task Category"
                                            body={(rowData: OtherTasksModal) => {
                                                return otherTasksColumnTemplate(rowData);
                                            }}></Column>
                                        <Column
                                            pt={commonColumnStyle()}
                                            field="taskIds"
                                            style={{ whiteSpace: 'normal' }}
                                            header="Task ID(s)"
                                            body={(rowData: OtherTasksModal) => {
                                                return otherTasksTemplate(rowData.taskIds ?? '');
                                            }}></Column>
                                    </DataTable>
                                </TabPanel>
                            )}
                        </TabView>
                    </div>
                </Dialog>

                {showPopup.visible ? (
                    <ConfirmationPopup
                        popupID="order-status-popup-order-details"
                        key={'order-status-popup-order-details'}
                        acceptLabel={showPopup.acceptLabel}
                        rejectLabel={showPopup.rejectLabel}
                        onConfirm={() => {
                            (viewData as ViewOrderType).headers.isBothDecideLater === true &&
                            showPopup.statusid === STATUS_MODE.TO_BE_PROCESSED
                                ? handlePopupConfirm(showPopup.isApprove || false)
                                : updateStatus();
                        }}
                        onCancel={() => {
                            setShowPopup({ ...popupDataInit, visible: false });
                            setOrderConfirmation(false);
                        }}
                        visible={showPopup.visible}
                        headerText={showPopup.header}
                        subHeaderText={showPopup.subHeader}
                        customWidth={
                            (viewData as ViewOrderType).headers.isBothDecideLater === true &&
                            showPopup.statusid === STATUS_MODE.TO_BE_PROCESSED
                                ? 'lg:!w-[30%] lg:!min-w-max'
                                : ' '
                        }
                        description={showPopup.description}
                    />
                ) : null}
                <div className="flex flex-col">
                    <span
                        className="font-semibold text-primary"
                        data-testid="order-id"
                        style={{ fontSize: '1rem' }}>
                        {orderInsights?.requestNumber || ''}
                        <span className="ml-2 bg-badgeBadge rounded-md font-medium px-2 py-1">
                            {orderInsights?.serviceType}
                        </span>
                    </span>

                    <div>
                        {orderInsights.isBothDecideLater === true && isQuoteCreation === true && (
                            <div className="mt-2 flex gap-2" data-testId="ep-up-totals">
                                <div className="[&>h5]:text-[1rem]">
                                    <h5>
                                        {t('SUMMARY.UP_NATIONAL_VALIDATIONS')}
                                        {claimsTotal() > 0 ? ` + ${t('SUMMARY.CLAIMS')}` : ''}
                                    </h5>
                                    <h5>
                                        {t('SUMMARY.NATIONAL_VALIDATION_ONLY')}
                                        {claimsTotal() > 0 ? ` + ${t('SUMMARY.CLAIMS')}` : ''}
                                    </h5>
                                </div>
                                <div className="[&>h4]:text-xl [&>h4]:font-semibold">
                                    <h4>
                                        {`${currencySymbol || ''} ${formatCurrency(upTotal() + claimsTotal()) || ''}`}
                                        {isThisStaffUser &&
                                            renderSaveAmountWithPercentageTemplate(
                                                calculateSaveAmount()
                                            )}
                                    </h4>
                                    <h4>
                                        {`${currencySymbol || ''} ${formatCurrency(epTotal() + claimsTotal()) || ''}`}
                                    </h4>
                                </div>
                            </div>
                        )}
                        {(isOrder || orderInsights.isBothDecideLater !== true) && (
                            <div className="h-12 flex flex-row py-5 items-center">
                                <span
                                    className=" text-xl font-semibold py-2"
                                    data-testId="grand-total">{`${currencySymbol || ''} ${formatCurrency(orderInsights?.grandTotal?.toFixed(2) || '') || ''}`}</span>

                                {!isThisContactUserExcludedSalesRep &&
                                    !isThisV3User &&
                                    !!orderInsights?.grossProfitPercentage &&
                                    !isNaN(orderInsights.grossProfitPercentage) &&
                                    renderPercentageTemplate(orderInsights.grossProfitPercentage)}
                            </div>
                        )}
                    </div>
                </div>
                <div className="flex items-center">
                    <img src={company} className="h-5 p-0 mr-3 my-1" />
                    <span
                        className="font-semibold "
                        data-testid="patent-right"
                        style={{ fontSize: '1rem' }}>
                        {orderInsights?.companyName}
                    </span>
                </div>
                <div className="flex items-center">
                    <img src={userIcon} className="h-5 p-0 mr-3 my-1" />
                    <span
                        className="font-semibold"
                        data-testid="header-user"
                        style={{ fontSize: '1rem' }}>
                        {orderInsights?.userName}
                    </span>
                </div>
                <div className="flex items-center">
                    <Tooltip
                        target=".header-request-type"
                        mouseTrack={false}
                        position="bottom"
                        content={t('QUOTE_AND_ORDER.REQUEST_TYPE')}
                        pt={{
                            root: { className: 'shadow-none ' },
                            text: { className: 'text-xs' }
                        }}
                    />
                    <img src={RequestTypeIcon} className="h-5 p-0 mr-3 my-1" />
                    <span
                        className="header-request-type font-semibold"
                        data-testid="header-request-type">
                        {requestType && OrderType(requestType)}
                    </span>
                </div>

                {dropDownValue && (
                    <div className="font-semibold justify-center items-center">
                        <Dropdown
                            data-testid={'header-status-dropdown'}
                            value={dropDownValue}
                            onChange={(e) => {
                                const statusId = getStatusId(e.value as string);
                                if (statusId !== undefined) {
                                    const requestId = state?.id || requestNumber;
                                    handleStatusChange(
                                        requestId as string,
                                        statusId,
                                        e.value as string
                                    );
                                }
                            }}
                            options={statusOptionList}
                            optionLabel={'label'}
                            itemTemplate={optionTemplate}
                            pt={{
                                ...dropdownFilterStyles,
                                root: {
                                    className: 'w-10/12 md:w-full'
                                },
                                input: {
                                    className: 'overflow-visible pr-1 pl-0'
                                },
                                trigger: {
                                    className: `w-auto ${!isThisStaffUser && !isThisVendorUser ? 'hidden' : ''}`
                                }
                            }}
                            style={{ border: 'none', fontSize: '1rem', background: 'none' }}
                            disabled={!isThisStaffUser && !isThisVendorUser}
                            className="uppercase"
                        />
                    </div>
                )}
                {isQuoteToOrder && isIP && statusName !== RequestStatusEnum.PREPARING_QUOTE && (
                    <div className="lg:hidden">
                        <button
                            className="btn button-primary-outline min-h-[2rem] h-[2rem] !font-medium w-18"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() => {
                                downloadPDF();
                            }}>
                            {t('COMMON.PREVIEW')}
                        </button>
                    </div>
                )}

                {isShowEditButton() && (
                    <div className="lg:hidden">
                        <button
                            data-testid="edit-order-button"
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                            onClick={() => {
                                navigate(
                                    `/${PATHS.ORDER_QUOTE}/${PATHS.EDIT}/${PATHS.SERVICE_TYPE}`
                                );
                            }}
                            className="btn btn-sm text-primary bg-white hover:bg-primary-200 hover:text-white absolute top-3 right-2 md:static">
                            <i className="pi pi-pencil"></i>
                            <span className="text-lg font-semibold">
                                {t(
                                    `QUOTE_AND_ORDER.${isSTDFlow ? 'EDIT_NON_IP_DETAILS' : 'EDIT_QUOTE'}`
                                )}
                            </span>
                        </button>
                    </div>
                )}
            </div>
        );
    }
);
