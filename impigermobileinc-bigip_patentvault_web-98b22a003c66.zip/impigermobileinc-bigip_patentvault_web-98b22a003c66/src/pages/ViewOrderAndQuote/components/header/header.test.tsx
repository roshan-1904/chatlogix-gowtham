import '@testing-library/jest-dom/extend-expect';
import { render, screen } from '@testing-library/react';
import viewOrderAndQuoteData from '../../Mock/viewOrderAndQuote.mock.json';
import { ViewOrderAndQuoteHeader } from './header';

const { orderInsightsData } = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

const statusList = [
    {
        id: 3,
        name: 'To be Processed',
        statusType: 2
    },
    {
        id: 4,
        name: 'In Progress',
        statusType: 2
    },
    {
        id: 5,
        name: 'Canceled',
        statusType: 2
    },
    {
        id: 6,
        name: 'On Hold',
        statusType: 2
    },
    {
        id: 7,
        name: 'Completed',
        statusType: 2
    },
    {
        id: 8,
        name: 'Invoiced',
        statusType: 2
    }
];

const state = {
    id: 4301,
    requestNumber: 'R-4043',
    statusName: 'Completed'
};

describe('Header of view order/quote', () => {
    test('Check render of header in the view Order/Quote screen', () => {
        render(
            <ViewOrderAndQuoteHeader
                orderInsights={orderInsightsData}
                statusList={statusList}
                state={state}
                requestNumber={'4404'}
                setDropDownValue={() => {}}
                dropDownValue={'To Be Processed'}
                currencySymbol={'$'}
                requestType=""
                setStatusResponse={() => {}}
                viewData={{}}
                isQuoteCreation={false}
            />
        );
    });

    test('Check the presence of header elements', () => {
        render(
            <ViewOrderAndQuoteHeader
                orderInsights={orderInsightsData}
                statusList={statusList}
                state={state}
                requestNumber={'4404'}
                setDropDownValue={() => {}}
                dropDownValue={'To Be Processed'}
                currencySymbol={'$'}
                requestType=""
                setStatusResponse={() => {}}
                viewData={{}}
                isQuoteCreation={false}
            />
        );
        expect(screen.getByTestId('order-id')).toBeDefined();
        expect(screen.getByTestId('patent-right')).toBeDefined();
        expect(screen.getByTestId('header-user')).toBeDefined();
        expect(screen.getByTestId('header-status-dropdown')).toBeDefined();

        // const editOrderButton = screen.getByTestId('edit-order-button');
        // expect(editOrderButton).toBeDefined();
        // fireEvent.click(editOrderButton);
    });
});
