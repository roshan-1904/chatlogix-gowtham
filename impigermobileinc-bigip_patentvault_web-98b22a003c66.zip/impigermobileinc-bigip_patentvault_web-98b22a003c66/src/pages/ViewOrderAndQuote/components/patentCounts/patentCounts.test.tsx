import { render, screen, waitFor } from '@testing-library/react';
import PatentCountsPage from './patentCounts';
const mockHandleChange = jest.fn();

describe('PatentCountsPage', () => {
    const defaultProps = {
        editInput: {
            abstractWordCount: { newValue: '100', value: '100' },
            descriptionWordCount: { newValue: '200', value: '200' }
        },
        handleChange: mockHandleChange,
        handleImageClick: jest.fn(), // Add handleImageClick property with a mock function
        viewData: {
            existingPatentCounts: {
                abstractWordCount: '100',
                descriptionWordCount: '200'
            }
        },
        requestDetails: {
            category: 'patent_cooperation_treaty',
            services: 'translation_only'
        },
        patentCountEdit: true,
        loggedInUserId: 1
    };

    const setup = (props = {}) => {
        const setupProps = { ...defaultProps, ...props };
        return render(<PatentCountsPage {...setupProps} />);
    };

    test('renders without crashing', () => {
        setup();
        expect(screen.getByTestId('AddressInformation-Accordian')).toBeInTheDocument();
    });

    test('renders the correct number of editable fields for translation_only service', () => {
        setup();
        waitFor(() => {
            expect(screen.getByDisplayValue('100')).toBeInTheDocument();
            expect(
                screen.getByPlaceholderText('PATENT_DETAILS.DESCRIPTION_WORD_COUNT')
            ).toBeInTheDocument();
        });
    });

    test('calls handleChange when text input value is changed', () => {
        setup();
        waitFor(() => {
            expect(mockHandleChange).toHaveBeenCalledWith('abstractWordCount', '150');
        });
    });

    test('calls handleChange when dropdown value is changed', () => {
        const props = {
            editInput: {
                estimatedSequenceListing: { newValue: 'Yes', value: 'Yes' }
            },
            requestDetails: {
                category: 'patent_cooperation_treaty',
                services: 'translation_only'
            }
        };
        setup(props);
        waitFor(() => {
            expect(mockHandleChange).toHaveBeenCalledWith('estimatedSequenceListing', 'No');
        });
    });

    test('renders error label when there is an error', () => {
        const props = {
            editInput: {
                abstractWordCount: { newValue: '100', value: '100', isError: true }
            }
        };
        setup(props);
        waitFor(() => {
            expect(screen.getByText(/PATENT_DETAILS.PATENT_ERROR/i)).toBeInTheDocument();
        });
    });

    test('displays correct static text when patentCountEdit is false', () => {
        const props = {
            patentCountEdit: false
        };
        setup(props);
        waitFor(() => {
            expect(screen.getByText('100')).toBeInTheDocument();
            expect(screen.getByText('200')).toBeInTheDocument();
        });
    });

    test('renders the correct message for "recordal" service', () => {
        const props = {
            requestDetails: {
                category: 'patent_cooperation_treaty',
                services: 'recordal'
            }
        };
        setup(props);
        waitFor(() => {
            expect(screen.getByText(/NO_PATENT_COUNTS/, { selector: 'div' })).toBeInTheDocument();
        });
    });
});
