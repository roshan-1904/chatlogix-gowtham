import validCount from 'assets/images/validCount.png';
import invalidCount from 'assets/images/invalidCount.svg';
import { renderLabel } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import ErrorLabel from 'components/reuseComponents/errorLabel';
import { t } from 'i18next';
import { Dropdown } from 'primereact/dropdown';
import { dropDownStyle } from 'constants/styles.constant';
import { CATEGORY_TYPE, ROLE, SERVICE_TYPES } from 'constants/app.constant';

type PatentCountsPageProps = {
    editInput: any;
    handleImageClick: any;
    handleChange: any;
    viewData: any;
    requestDetails: any;
    patentCountEdit: boolean;
    disablePatentFields?: { [key: string]: boolean };
    loggedInUserId: number;
};

const PatentCountsPage = ({
    editInput,
    handleChange,
    viewData,
    requestDetails,
    patentCountEdit,
    disablePatentFields,
    loggedInUserId
}: PatentCountsPageProps) => {
    const category = requestDetails?.category;
    const service = requestDetails?.services;
    const yesOrNoOptions = [
        { label: 'Yes', value: 'Yes' },
        { label: 'No', value: 'No' }
    ];

    const statusIcon = (value: boolean) => {
        const status = value ? (
            <img src={validCount} className="h-5 p-0 mx-3 my-1" />
        ) : (
            <img src={invalidCount} className="h-3.5 p-0 mx-3 my-1" />
        );
        return status;
    };

    const renderEditableField = (
        label: string,
        field: string,
        valueKey: string,
        isValidationIcon: boolean = true,
        isDropDown: boolean = false,
        isTextArea: boolean = false
    ) => {
        function dropDown(fieldName: string) {
            const isDropDownDisable = (): boolean => {
                /** for PM user, 'estimatedSequenceListing' should be editable. */
                const isPMUser: boolean =
                    loggedInUserId === ROLE.PROJECT_MANAGER.roleId ||
                    loggedInUserId === ROLE.VENDOR_PROJECT_MANAGER.roleId ||
                    loggedInUserId === ROLE.VENDOR_PROJECT_COORDINATOR.roleId;

                const isDisable: boolean =
                    fieldName === 'estimatedSequenceListing' &&
                    !isPMUser &&
                    (disablePatentFields?.estimatedSequenceListing ?? false);

                return isDisable;
            };

            return (
                <Dropdown
                    data-testid="selected-file-type"
                    value={editInput?.[field]?.newValue}
                    filter={false}
                    onChange={(e) => handleChange(field, e.value)}
                    options={yesOrNoOptions}
                    optionLabel="label"
                    disabled={isDropDownDisable()}
                    pt={{
                        ...dropDownStyle,
                        root: {
                            className:
                                'w-72 text-sm font-medium input input-bordered border-neutral-100  focus:outline-none h-10 rounded-md border disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200'
                        },
                        item: { className: 'hover:bg-primary-50' },
                        input: {
                            className: 'p-2'
                        }
                    }}
                    style={{ width: 200 }}
                />
            );
        }

        function text() {
            return (
                <input
                    value={editInput?.[field]?.newValue}
                    type="text"
                    className="w-72 text-sm font-medium input input-bordered border-neutral-100 focus:border-neutral-100 focus:outline-none h-10 rounded-md border disabled:bg-neutral-100 disabled:border-neutral-200"
                    placeholder={label}
                    onChange={(e) => handleChange(field, e.target.value)}
                    pattern="\d+(\.\d{1,5})?"
                    disabled={disablePatentFields?.[field] ?? false}
                />
            );
        }

        function textArea() {
            return (
                <textarea
                    data-testid={'CustomDisclaimerTextArea'}
                    className="shadow appearance-none border rounded w-full min-h-20 max-h-20 text-gray-700 leading-tight focus:outline-none focus:shadow-outline text-sm px-2 py-1"
                    id="summary-instruction-textarea"
                    placeholder={'Special Instructions'}
                    value={editInput?.[field]?.newValue || ''}
                    onChange={(e) => handleChange(field, e.target.value)}
                />
            );
        }

        const showStatusIcon =
            category !== CATEGORY_TYPE.paris_convention_treaty && field !== 'patentTitleWordCount';

        return (
            <div>
                <div className="flex">{renderLabel(label)}</div>
                {!patentCountEdit ? (
                    <div className="flex break-words font-medium">
                        {editInput?.[field]?.value ?? '-'}
                        {editInput?.[field]?.value &&
                            isValidationIcon &&
                            showStatusIcon &&
                            statusIcon(
                                editInput?.[field]?.value ===
                                    viewData?.existingPatentCounts?.[valueKey]
                            )}
                    </div>
                ) : (
                    <div className="flex items-center">
                        <div className="flex flex-col items-start">
                            <div className="flex">
                                {isDropDown && dropDown(field)}
                                {!isDropDown && !isTextArea && text()}
                                {isTextArea && textArea()}
                            </div>
                            {editInput?.[field]?.isError && (
                                <ErrorLabel
                                    message={`${t('PATENT_DETAILS.PATENT_ERROR')} ${label}`}
                                />
                            )}
                        </div>
                    </div>
                )}
            </div>
        );
    };

    function renderField() {
        if (category === CATEGORY_TYPE.patent_cooperation_treaty) {
            switch (service) {
                case SERVICE_TYPES.translation_only:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.ABSTRACT_WORD_COUNT'),
                                'abstractWordCount',
                                'abstractWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DESCRIPTION_WORD_COUNT'),
                                'descriptionWordCount',
                                'descriptionWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_DRAWINGS'),
                                'numberofDrawings',
                                'numberofDrawings'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_WORD_COUNT'),
                                'claimsWordCount',
                                'claimsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_PAGE_COUNT'),
                                'drawingsPageCount',
                                'drawingsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                        </>
                    );
                case SERVICE_TYPES.translation_and_filing:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.ABSTRACT_WORD_COUNT'),
                                'abstractWordCount',
                                'abstractWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DESCRIPTION_WORD_COUNT'),
                                'descriptionWordCount',
                                'descriptionWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_DRAWINGS'),
                                'numberofDrawings',
                                'numberofDrawings'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_WORD_COUNT'),
                                'claimsWordCount',
                                'claimsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_PAGE_COUNT'),
                                'drawingsPageCount',
                                'drawingsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_PRIORITY_APPLICATIONS'),
                                'numberofPriorityApplications',
                                'numberofPriorityApplications'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_CLAIMS'),
                                'numberofClaims',
                                'numberofClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_INDEPENDENT_CLAIMS'),
                                'numberofIndependentClaims',
                                'numberofIndependentClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATE_NUMBER_OF_TOTAL_PAGES'),
                                'estimatedNumberofTotalPages',
                                'estimatedNumberofTotalPages'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                        </>
                    );
                case SERVICE_TYPES.recordal:
                    return <>{t('PATENT_DETAILS.NO_PATENT_COUNTS')}</>;
                case SERVICE_TYPES.annuities:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_CLAIMS'),
                                'numberofClaims',
                                'numberofClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_INDEPENDENT_CLAIMS'),
                                'numberofIndependentClaims',
                                'numberofIndependentClaims'
                            )}
                        </>
                    );
                default:
                    break;
            }
        }
        if (category === CATEGORY_TYPE.paris_convention_treaty) {
            switch (service) {
                case SERVICE_TYPES.translation_only:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_DRAWINGS'),
                                'numberofDrawings',
                                'numberofDrawings'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_PAGE_COUNT'),
                                'drawingsPageCount',
                                'drawingsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.SPECIFICATION_WORD_COUNT'),
                                'specificationWordCount',
                                'specificationWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                        </>
                    );
                case SERVICE_TYPES.translation_and_filing:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_DRAWINGS'),
                                'numberofDrawings',
                                'numberofDrawings'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.SPECIFICATION_WORD_COUNT'),
                                'specificationWordCount',
                                'specificationWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_CLAIMS'),
                                'numberofClaims',
                                'numberofClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_INDEPENDENT_CLAIMS'),
                                'numberofIndependentClaims',
                                'numberofIndependentClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATE_NUMBER_OF_TOTAL_PAGES'),
                                'estimatedNumberofTotalPages',
                                'estimatedNumberofTotalPages'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.APPLICATION_CLAIMS_PRIORITY'),
                                'claimsPriority',
                                'claimsPriority',
                                false,
                                true,
                                false
                            )}
                        </>
                    );
                default:
                    break;
            }
        }
        if (category === CATEGORY_TYPE.european_patent) {
            switch (service) {
                case SERVICE_TYPES.claims:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_WORD_COUNT'),
                                'claimsWordCount',
                                'claimsWordCount'
                            )}
                        </>
                    );
                case SERVICE_TYPES.translation_only:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DESCRIPTION_WORD_COUNT'),
                                'descriptionWordCount',
                                'descriptionWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_WORD_COUNT'),
                                'claimsWordCount',
                                'claimsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.PATENT_WORD_COUNT'),
                                'patentTitleWordCount',
                                'patentTitleWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_PAGE_COUNT'),
                                'drawingsPageCount',
                                'drawingsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.SPECIAL_INSTRUCTIONS'),
                                'specialInstructions',
                                'specialInstructions',
                                false,
                                false,
                                true
                            )}
                        </>
                    );
                case SERVICE_TYPES.translation_and_validation:
                    return (
                        <>
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_WORD_COUNT'),
                                'drawingsWordCount',
                                'drawingsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DESCRIPTION_WORD_COUNT'),
                                'descriptionWordCount',
                                'descriptionWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_WORD_COUNT'),
                                'claimsWordCount',
                                'claimsWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.PATENT_WORD_COUNT'),
                                'patentTitleWordCount',
                                'patentTitleWordCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DRAWINGS_PAGE_COUNT'),
                                'drawingsPageCount',
                                'drawingsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.DESCRIPTION_PAGE_COUNT'),
                                'descriptionPageCount',
                                'descriptionPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.NUMBER_OF_CLAIMS'),
                                'numberofClaims',
                                'numberofClaims'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.CLAIMS_PAGE_COUNT'),
                                'claimsPageCount',
                                'claimsPageCount'
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.ESTIMATED_SEQUENCE_LISTING'),
                                'estimatedSequenceListing',
                                'estimatedSequenceListing',
                                false,
                                true,
                                false
                            )}
                            {renderEditableField(
                                t('PATENT_DETAILS.SPECIAL_INSTRUCTIONS'),
                                'specialInstructions',
                                'specialInstructions',
                                false,
                                false,
                                true
                            )}
                        </>
                    );
                case SERVICE_TYPES.recordal:
                    return <>{t('PATENT_DETAILS.NO_PATENT_COUNTS')}</>;
                case SERVICE_TYPES.renewals:
                    return <>{t('PATENT_DETAILS.NO_PATENT_COUNTS')}</>;
                default:
                    break;
            }
        }
    }

    return (
        <div className="py-3 pb-3" data-testid="AddressInformation-Accordian">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-7 mt-2">{renderField()}</div>
        </div>
    );
};

export default PatentCountsPage;
