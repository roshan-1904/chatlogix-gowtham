import '@testing-library/jest-dom/extend-expect';
import { render, screen } from '@testing-library/react';
import AdditionalInfoPage from './additionalInfo';
import viewOrderAndQuoteData from '../../Mock/viewOrderAndQuote.mock.json';

const { additionalInfoData } = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

describe('Header of view order/quote', () => {
    test('Check render of additional info section in the view Order/Quote screen', () => {
        render(
            <AdditionalInfoPage
                editInput={additionalInfoData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSave={() => {}}
                handleCancel={() => {}}
                companyId={1}
            />
        );
    });
    test('Check render of additional info section in the view Order/Quote screen', () => {
        render(
            <AdditionalInfoPage
                editInput={additionalInfoData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSave={() => {}}
                handleCancel={() => {}}
                companyId={1}
            />
        );

        expect(screen.getByTestId('contact-email-read')).toBeDefined();
        expect(screen.getByTestId('reference-no-read')).toBeDefined();
    });
});
