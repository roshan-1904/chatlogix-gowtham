import { t } from 'i18next';
import { showToastMessage } from 'pages/ViewOrderAndQuote/shared/viewOrderAndQuoteHelper';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { useEffect, useMemo, useState } from 'react';
import { getProjectManagersList } from 'pages/ViewOrderAndQuote/service/viewOrderQuoteService';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import companyDetailsService from 'pages/createOrderAndQuote/components/companyDetails/services/companyDetails.service';
import { isStaffUser, isVendorUser } from 'core/utils/utils';
import ConstructField from 'components/reuseComponents/constructField';
import { CurrencyList } from 'pages/pvsettings/subaccordions/types/pvsettings.types';

type PropType = {
    editInput: any;
    currencyList?: CurrencyList[];
    handleImageClick: (value: string) => void;
    handleChange: (value1: string, value2: string | number | string[]) => void;
    handleSave: (value1: string, value2: string) => void;
    handleCancel: (value1: string, value2: string) => void;
    companyId: number;
    statuses?: {
        isCompleted?: boolean;
        isInvoiced?: boolean;
        isPreparingQuote?: boolean;
        isToBeProcessed?: boolean;
        isWFA?: boolean;
    };
    isSTDFlow?: boolean;
};

type PMListType = {
    id: number;
    firstName: string;
    lastName: string;
    middleName: string;
    fullName: string;
    roleId: number;
};

const AdditionalInfoPage = ({
    editInput,
    currencyList,
    handleImageClick,
    handleChange,
    handleSave,
    handleCancel,
    companyId,
    statuses,
    isSTDFlow = false
}: PropType) => {
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const isThisStaffUser = isStaffUser(userDetails.userInfo.roleId);
    const isThisVendorUser = isVendorUser(userDetails.userInfo.roleId);
    const {
        isWFA = false,
        isPreparingQuote = false,
        isCompleted = false,
        isInvoiced = false
    } = statuses ?? {};
    const isCompletedORInvoiced = isCompleted || isInvoiced;

    const [allPM, setAllPM] = useState<PMListType[]>([]);
    const [companyUserList, setCompanyUserList] = useState<any>();

    // api
    const pmList = async () => {
        try {
            const response = await getProjectManagersList();
            setAllPM(response as PMListType[]);
        } catch (error) {
            showToastMessage('Error in fetching project managers list', ToastType.ERROR);
        }
    };

    const getCompanyUserList = async () => {
        try {
            const response = await companyDetailsService.getContactUserData(companyId);
            if (response) {
                setCompanyUserList(response);
            }
        } catch (error) {
            console.error(error);
            showToastMessage('Error in fetching contact user', ToastType.ERROR);
        }
    };

    useEffect(() => {
        pmList();
    }, []);
    useEffect(() => {
        getCompanyUserList();
    }, [companyId]);

    let pmOptions = allPM?.map((item: { id: number; fullName: string }) => {
        return { name: item.fullName, id: item.id };
    });
    const getPMNameList = (list: any[]) => {
        if (!list || list?.length === 0) return [];

        const pmNameList = list
            .filter((item) => item.name && typeof item.name === 'string')
            .map((item) => item.name);

        return pmNameList;
    };

    // Add inactive users also in the PM list
    if (editInput?.projectManagers?.value && pmOptions && pmOptions.length > 0) {
        const inactivePMs: { id: number; name: string }[] = editInput.projectManagers?.value.filter(
            (inActivePM: { id: number }) => !pmOptions.find((pm) => pm.id === inActivePM.id)
        );
        pmOptions = pmOptions.concat(inactivePMs);
    }

    let alsoDeliverToOptions = companyUserList?.map(
        (item: { id: number; fullName: string; email: string }) => {
            return { name: item.fullName, id: item.id, email: item.email };
        }
    );

    // Add inactive users also in the PM list
    if (
        editInput?.alsoDeliverTo?.value &&
        alsoDeliverToOptions &&
        alsoDeliverToOptions.length > 0
    ) {
        const inactiveUsers: string[] = editInput.alsoDeliverTo?.value.filter(
            (inActivePM: string) =>
                !alsoDeliverToOptions.find((pm: { email: string }) => pm.email === inActivePM)
        );

        const inactiveUsersList = inactiveUsers.map((item: string) => ({
            id: 0,
            email: item,
            name: item
        }));
        alsoDeliverToOptions = alsoDeliverToOptions.concat(inactiveUsersList);
    }

    return (
        <div className="py-3 pb-3" data-testid="AddressInformation-Accordion">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-7 mt-2">
                <ConstructField
                    data={{
                        isFieldHasEditability: false,
                        isFieldInEditMode: editInput?.contactEmail?.isEdit,
                        fieldType: 'input',
                        inputType: { type: 'email' },
                        fieldValue: editInput.contactEmail.value,
                        state: editInput.contactEmail.newValue,
                        fieldLabelName: t('ADDITIONAL_INFO.CONTACT_EMAIL'),
                        placeholder: 'Contact Email',
                        customClass: { fieldValueLabel: 'font-medium' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability: !isCompletedORInvoiced,
                        isFieldInEditMode: editInput?.alsoDeliverTo?.isEdit,
                        fieldType: 'dropdown',
                        inputType: { type: 'multiselect' },
                        fieldValue: editInput?.alsoDeliverTo?.value,
                        state: editInput?.alsoDeliverTo?.newValue,
                        moreInputInfo: {
                            select: {
                                options: alsoDeliverToOptions,
                                optionLabel: 'name',
                                optionValue: 'email',
                                isFilterEnabled: true
                            },
                            chips: {
                                isTemplateChips: true,
                                chipsContent: editInput?.alsoDeliverTo?.value
                            }
                        },
                        fieldLabelName: t('ADDITIONAL_INFO.ALSO_DELIVER_TO'),
                        placeholder: 'Select Deliver To',
                        actions: {
                            edit: () => handleImageClick('alsoDeliverTo'),
                            update: () => handleSave('alsoDeliverTo', 'AdditionalInfo'),
                            cancel: () => handleCancel('alsoDeliverTo', 'AdditionalInfo'),
                            onChange: (value: any) =>
                                handleChange('alsoDeliverTo', (value ?? null) as string)
                        },
                        customClass: { wrapperRow2: 'mt-1' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability: !isCompletedORInvoiced,
                        isFieldInEditMode: editInput?.cc?.isEdit,
                        fieldType: 'chips',
                        inputType: { type: 'others' },
                        fieldValue: editInput?.cc?.newValue,
                        state: editInput.cc.newValue,
                        moreInputInfo: {
                            chips: {
                                isTemplateChips: true,
                                chipsContent: editInput?.cc?.newValue
                            }
                        },
                        invalid: editInput?.cc?.isError,
                        errorMessage: t('ADDITIONAL_INFO.ERROR_CC'),
                        fieldLabelName: t('COMMON.CC'),
                        actions: {
                            edit: () => handleImageClick('cc'),
                            update: () => handleSave('cc', 'AdditionalInfo'),
                            cancel: () => handleCancel('cc', 'AdditionalInfo'),
                            onChange: (value: any) => handleChange('cc', (value ?? null) as string)
                        },
                        customClass: { wrapperRow2: 'mt-1' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability: !isCompletedORInvoiced,
                        isFieldInEditMode: editInput?.poNumber?.isEdit,
                        fieldType: 'input',
                        inputType: { type: 'text' },
                        fieldValue: editInput?.poNumber?.value,
                        state: editInput?.poNumber?.newValue,
                        fieldLabelName: t('ADDITIONAL_INFO.PO_NO'),
                        placeholder: 'PO Number',
                        actions: {
                            edit: () => handleImageClick('poNumber'),
                            update: () => handleSave('poNumber', 'AdditionalInfo'),
                            cancel: () => handleCancel('poNumber', 'AdditionalInfo'),
                            onChange: (value: any) =>
                                handleChange('poNumber', (value ?? null) as string)
                        },
                        customClass: { fieldValueLabel: 'font-medium' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability: !isCompletedORInvoiced,
                        isFieldInEditMode: editInput?.referenceNo?.isEdit,
                        fieldType: 'input',
                        inputType: { type: 'text' },
                        fieldValue: editInput?.referenceNo?.value,
                        state: editInput?.referenceNo?.newValue,
                        fieldLabelName: t('ADDITIONAL_INFO.REFERENCE_NUMBER'),
                        placeholder: 'Reference Number',
                        actions: {
                            edit: () => handleImageClick('referenceNo'),
                            update: () => handleSave('referenceNo', 'AdditionalInfo'),
                            cancel: () => handleCancel('referenceNo', 'AdditionalInfo'),
                            onChange: (value: any) =>
                                handleChange('referenceNo', (value ?? null) as string)
                        },
                        customClass: { fieldValueLabel: 'font-medium' },
                        invalid: editInput?.referenceNo?.isError,
                        errorMessage: editInput?.referenceNo?.errorMessage
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability:
                            !isCompletedORInvoiced && (isThisStaffUser || isThisVendorUser),
                        isFieldInEditMode: editInput?.projectManagers?.isEdit,
                        fieldType: 'dropdown',
                        inputType: { type: 'multiselect' },
                        fieldValue: editInput?.projectManagers?.value,
                        state: editInput?.projectManagers?.newValue,
                        moreInputInfo: {
                            select: {
                                options: pmOptions,
                                optionLabel: 'name',
                                optionValue: 'id',
                                isFilterEnabled: true
                            },
                            chips: {
                                isTemplateChips: true,
                                chipsContent: getPMNameList(
                                    editInput?.projectManagers?.value as any[]
                                )
                            }
                        },
                        fieldLabelName: t('COMMON.PROJECT_MANAGER'),

                        placeholder: 'Select Project Managers',
                        actions: {
                            edit: () => handleImageClick('projectManagers'),
                            update: () => handleSave('projectManagers', 'AdditionalInfo'),
                            cancel: () => handleCancel('projectManagers', 'AdditionalInfo'),
                            onChange: (value: any) =>
                                handleChange('projectManagers', (value ?? null) as string)
                        },
                        customClass: { wrapperRow2: 'mt-1' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability:
                            (isPreparingQuote || isWFA) &&
                            isSTDFlow &&
                            (isThisStaffUser || isThisVendorUser),
                        isFieldInEditMode: editInput?.requestCurrency?.isEdit,
                        fieldType: 'dropdown',
                        inputType: { type: 'select' },
                        fieldValue: editInput?.requestCurrency?.value,
                        state: editInput?.requestCurrency?.newValue,
                        moreInputInfo: {
                            select: {
                                options: currencyList ?? [],
                                optionLabel: 'currencyCode',
                                optionValue: 'currencyCode',
                                isFilterEnabled: true
                            }
                        },
                        fieldLabelName: t('ADDITIONAL_INFO.REQUEST_CURRENCY'),
                        placeholder: 'Select Request Currency',
                        actions: {
                            edit: () => handleImageClick('requestCurrency'),
                            update: () => handleSave('requestCurrency', 'AdditionalInfo'),
                            cancel: () => handleCancel('requestCurrency', 'AdditionalInfo'),
                            onChange: (value: any) =>
                                handleChange('requestCurrency', (value ?? null) as string)
                        },
                        customClass: { fieldValueLabel: 'font-medium' }
                    }}
                />
                <ConstructField
                    data={{
                        isFieldHasEditability: false,
                        isFieldInEditMode: editInput?.salesRepresentative?.isEdit,
                        fieldType: 'input',
                        inputType: { type: 'text' },
                        fieldValue: editInput?.salesRepresentative?.value,
                        state: editInput?.salesRepresentative?.newValue,
                        fieldLabelName: t('ADDITIONAL_INFO.SALES_REPRESENTATIVE'),
                        placeholder: 'Request Currency',
                        customClass: { fieldValueLabel: 'font-medium' }
                    }}
                />
            </div>
        </div>
    );
};

export default AdditionalInfoPage;
