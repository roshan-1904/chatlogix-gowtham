// #region  Imports
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { t } from 'i18next';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import {
    getPDFData,
    getRequestStatusList,
    getStandardDetails,
    getUploadedDocumentAndLanguagesList,
    updateAdditionalInfo,
    updateDateAndDeadline,
    updateInstruction,
    updateInternalDeadline,
    updatePatentTitle,
    updateRequestCurrency
} from './service/viewOrderQuoteService';
import {
    additionalInfoEditValidations,
    additionalInfoUpdateBody,
    handleAPIUpdate,
    updateStateOnCancel,
    dateAndDeadlineUpdateBody,
    instructionUpdateBody
} from './shared/viewOrderAndQuoteHelper';

import {
    InitDefaultStandardViewOrderType,
    StandardAccordionType,
    StandardDateAndDeadLinesEditInputs,
    StandardViewOrderType
} from './types/standardViewDetailsTypes';
import {
    AdditionalInfoInputs,
    HeaderType,
    InstructionType,
    RequestDetailsInputs,
    StatusType
} from './types/viewDetailsTypes';
import { DocumentDetailsResponse } from './types/standardViewDetailsTypes';
import { ViewOrderAndQuoteHeader, ViewOrderAndQuoteHeaderRef } from './components/header/header';
import { showToastMessage } from './shared/viewOrderAndQuoteHelper';
import { ToastType } from 'core/store/notificationStore/notificationStore';
import { IP_NONIP, MODE } from 'constants/app.constant';
import RequestDetailsPage from './components/requestDetails/requestDetails';
import StandardDocumentTabSection from './components/standardUploadedDocuments/StandardDocumentTabSection';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import utils, {
    getWindowSize,
    isContactUser,
    isSalesRep,
    isStaffUser,
    isVendorUser
} from 'core/utils/utils';
import BillsAndInvoices from './components/billsAndInvoices/billsAndInvoices';
import AdditionalInfoPage from './components/additionalInfo/additionalInfo';
import DateAndDeadlinesPage from './components/dateAndDeadlines/dateAndDeadlines';
import InstructionsAndComments from './components/instructions/instructions';
import quoteOrderModuleStore from 'core/store/orderQuoteStore/orderQuote.store';
import {
    QuoteOrderModuleStore,
    QuoteOrderModuleStoreInfo
} from 'core/store/orderQuoteStore/orderQuote.type.store';
import { Dialog } from 'primereact/dialog';
import { previewDialogPopup } from 'constants/styles.constant';
import { RequestStatusEnum } from 'shared/dataTable/constant/dataTable.constant';
import { Permissions } from 'constants/permissions';
import PrimeButton from 'components/buttons/primeButton';
import { CurrencyList } from 'pages/pvsettings/subaccordions/types/pvsettings.types';
import summaryService from 'pages/createOrderAndQuote/components/summary/services/summary.service';
import ConfirmationPopup from 'components/confirmationPopup/confirmationPopup';
import TopNavigationStep from 'components/reuseComponents/topNavigationStep/topNavigationStep';

interface PopupConfig {
    isShowPopup: boolean;
    header: string;
    description: string;
    requestToFunction: number;
    storeDataToUpdate: string;
}

// #endregion
const StandardDetails = () => {
    const navigate = useNavigate();
    const { requestId } = useParams();
    const { state } = useLocation();
    const userDetails: UserInfoModal = useMemo(() => AuthStore.getUserInfo(), []);
    const loggedInUserId = userDetails.userInfo.roleId;
    const isThisContactUser = isContactUser(loggedInUserId);
    const isThisStaffUser = isStaffUser(loggedInUserId);
    const isThisVendorUser = isVendorUser(loggedInUserId);

    const popupConfigInit: PopupConfig = {
        isShowPopup: false,
        header: 'Confirmation',
        description: '',
        requestToFunction: 0,
        storeDataToUpdate: ''
    };
    const [popupConfig, setPopupConfig] = useState(popupConfigInit);

    // #region  State Variables
    const [viewData, setViewData] = useState<StandardViewOrderType>(
        InitDefaultStandardViewOrderType
    );
    const isQuoteState = viewData?.requestTypeId === MODE.CREATE_QUOTE;
    const requestIdData = viewData?.headers?.requestId;
    const stdPreviewType = viewData?.headers.stdPreviewType;

    const [statusList, setStatusList] = useState<StatusType[]>([]);
    const [documentAndLanguagesList, setDocumentAndLanguagesList] =
        useState<DocumentDetailsResponse>();
    const [companyId, setCompanyId] = useState<number>(0);

    const [statusResponse, setStatusResponse] = useState<number>(0);
    const [documentRowValueChange, setDocumentRowValueChange] = useState<number>(0);
    const [dropDownValue, setDropDownValue] = useState(
        state?.statusName || viewData?.headers?.statusName
    );
    const isWFA = dropDownValue === RequestStatusEnum.WAITING_FOR_APPROVAL;
    const isCompleted = dropDownValue === RequestStatusEnum.COMPLETED;
    const isInvoiced = dropDownValue === RequestStatusEnum.INVOICED;
    const isPreparingQuote = viewData?.headers.statusName === RequestStatusEnum.PREPARING_QUOTE;
    const isQuoteToOrder = viewData?.headers?.isQuote === true;
    const isQuote = viewData?.requestTypeId === MODE.CREATE_QUOTE;
    const isOrder = viewData?.requestTypeId === MODE.CREATE_ORDER;
    const isShowServicesAccordion =
        isThisStaffUser || isThisVendorUser || (isThisContactUser && !isQuote);
    const [pdfUrl, setPdfUrl] = useState<string>('');
    const [visible, setVisible] = useState<boolean>(false);

    const [addInfoResponse, setAddInfoResponse] = useState<any>();
    const [dateDeadlineResponse, setDateDeadlineResponse] = useState<any>();
    const [instructionResponse, setInstructionResponse] = useState<any>();
    const [currencyList, setCurrencyList] = useState<CurrencyList[]>([]);

    const isQuoteCreation = viewData?.requestTypeId === MODE.CREATE_QUOTE;

    const [accordionActive, setAccordionActive] = useState<StandardAccordionType>({
        requestDetails: true,
        additionalInfo: false,
        uploadedDocuments: false,
        billsInvoice: false,
        dateAndDeadlines: false,
        instructions: false
    });
    const [requestDetailsInput, setRequestDetailsInput] = useState({
        patentTitle: {
            isEdit: false,
            isError: false,
            value: viewData?.requestDetails?.patentTitle,
            newValue: viewData?.requestDetails?.patentTitle
        }
    });
    const [additionalInfoInput, setAdditionalInfoInput] = useState({
        contactEmail: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.contactEmail,
            newValue: viewData?.additionalInfo?.contactEmail
        },
        alsoDeliverTo: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.alsoDeliverTo
                ? viewData?.additionalInfo?.alsoDeliverTo?.split(',')
                : [],
            newValue: viewData?.additionalInfo?.alsoDeliverTo
                ? viewData?.additionalInfo?.alsoDeliverTo?.split(',')
                : []
        },
        cc: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.cc ? viewData?.additionalInfo?.cc?.split(',') : [],
            newValue: viewData?.additionalInfo?.cc ? viewData?.additionalInfo?.cc?.split(',') : []
        },
        poNumber: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.poNumber,
            newValue: viewData?.additionalInfo?.poNumber,
            required: viewData?.additionalInfo?.requiredFields?.isPoNumber
        },
        referenceNo: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.referenceNumber,
            newValue: viewData?.additionalInfo?.referenceNumber
        },
        projectManagers: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.projectManagers,
            newValue: viewData?.additionalInfo?.projectManagers?.map((item) => item?.id)
        },
        requestCurrency: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.requestCurrency,
            newValue: viewData?.additionalInfo?.requestCurrency
        },
        salesRepresentative: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.salesRepresentative,
            newValue: viewData?.additionalInfo?.salesRepresentative
        },
        invoiceStatus: {
            isEdit: false,
            isError: false,
            value: viewData?.additionalInfo?.invoiceStatus,
            newValue: viewData?.additionalInfo?.invoiceStatus
        }
    });

    const [instructions, setInstructions] = useState<InstructionType>({
        pmInstruction: {
            isEdit: false,
            isError: false,
            value: viewData?.instructionByProjectManager?.instruction ?? '',
            newValue: viewData?.instructionByProjectManager?.instruction ?? ''
        },
        pmCreatedAt: {
            isEdit: false,
            value: viewData?.instructionByProjectManager?.createdAt ?? ''
        },
        cuInstruction: {
            isEdit: false,
            isError: false,
            value: viewData?.instructionByContactUser?.instruction ?? '',
            newValue: viewData?.instructionByContactUser?.instruction ?? ''
        },
        cuCreatedAt: { isEdit: false, value: viewData?.instructionByContactUser?.createdAt ?? '' },
        customDisclaimer: {
            isEdit: false,
            isError: false,
            value: viewData?.customDisclaimerSTD || '',
            newValue: viewData?.customDisclaimerSTD || ''
        }
    });
    const [dateAndDeadEditInput, setDateAndDeadEditInput] = useState({
        completedAt: { isEdit: false, value: viewData?.dateAndDeadLines?.completedAt },
        createdAt: { isEdit: false, value: viewData?.dateAndDeadLines?.createdAt },

        quoteTargetDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.quoteDatetime,
            newValue: viewData?.dateAndDeadLines?.quoteDatetime
        },
        requestDeliveryDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.requestedDeliveryDate,
            newValue: viewData?.dateAndDeadLines?.requestedDeliveryDate
        },
        internalDeliveryDate: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.internalDeliveryDate,
            newValue: viewData?.dateAndDeadLines?.internalDeliveryDate
        },
        turnAroundTime: {
            isEdit: false,
            isError: false,
            value: viewData?.dateAndDeadLines?.turnAroundTime,
            newValue: viewData?.dateAndDeadLines?.turnAroundTime
        }
    });
    const headerRef = useRef<ViewOrderAndQuoteHeaderRef>(null);
    // #endregion State Variables

    // #region  Functions
    const separatorLine = () => <span className=" font-medium text-primary mx-2">|</span>;
    function statusRerender() {
        setStatusResponse(statusResponse + 1);
    }
    function documentRowValueChangeEvent() {
        setDocumentRowValueChange(documentRowValueChange + 1);
    }

    // Request Details onchange and edit functions
    const handleEditRequestDetails = (fieldName: string) => {
        setRequestDetailsInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof RequestDetailsInputs],
                isEdit: true
            }
        }));
    };
    const handleChangeRequestDetails = (
        fieldName: string,
        newValue: string | number | string[]
    ) => {
        setRequestDetailsInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof RequestDetailsInputs],
                newValue,
                isError: !newValue
            }
        }));
    };

    // additional info edit handle
    const handleImageClickAdditionalInfo = (fieldName: string) => {
        setAdditionalInfoInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof AdditionalInfoInputs],
                isEdit: true
            }
        }));
    };
    const handleChangeAdditionalInfo = (
        fieldName: string,
        newValue: string | number | string[]
    ) => {
        setAdditionalInfoInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName as keyof AdditionalInfoInputs],
                newValue,
                isError: additionalInfoEditValidations(fieldName, newValue)
            }
        }));
    };

    // date and deadlines edit handle
    const handleOnChangeDateAndDeadline = (
        fieldName: keyof StandardDateAndDeadLinesEditInputs,
        value: string
    ) => {
        setDateAndDeadEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue: value || ''
            }
        }));
    };
    const handleImageClickDateAndDeadline = (
        fieldName: keyof StandardDateAndDeadLinesEditInputs
    ) => {
        setDateAndDeadEditInput((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                isEdit: true
            }
        }));
    };

    // Instructions edit handle
    const instructionEditImageClick = (fieldName: keyof InstructionType) => {
        setInstructions((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                isEdit: true
            }
        }));
    };
    const handleChangeInstruction = (fieldName: keyof InstructionType, value: string) => {
        setInstructions((prevState) => ({
            ...prevState,
            [fieldName]: {
                ...prevState[fieldName],
                newValue: value || '',
                isError: value ? false : true
            }
        }));
    };
    // #endregion Functions

    // #region API Calls
    const getStandardDetailsAPIWrapper = () => {
        getStandardDetailsAPI().catch((error) => {
            console.error(error);
        });
    };
    const getStandardDetailsAPI = async () => {
        if (requestId) {
            try {
                const response = await getStandardDetails<StandardViewOrderType>(requestId);
                setCompanyId(response?.headers?.companyId);
                setRequestDetailsInput((prevState) => ({
                    ...prevState,
                    patentTitle: {
                        isEdit: false,
                        isError: false,
                        value: response?.requestDetails.patentTitle,
                        newValue: response?.requestDetails.patentTitle
                    }
                }));
                setAdditionalInfoInput((prevState) => ({
                    ...prevState,
                    contactEmail: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.contactEmail,
                        newValue: response?.additionalInfo?.contactEmail
                    },
                    alsoDeliverTo: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.alsoDeliverTo
                            ? response?.additionalInfo?.alsoDeliverTo?.split(',')
                            : [],
                        newValue: response?.additionalInfo?.alsoDeliverTo
                            ? response?.additionalInfo?.alsoDeliverTo?.split(',')
                            : []
                    },
                    cc: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.cc
                            ? response?.additionalInfo?.cc?.split(',')
                            : [],
                        newValue: response?.additionalInfo?.cc
                            ? response?.additionalInfo?.cc?.split(',')
                            : []
                    },
                    poNumber: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.poNumber,
                        newValue: response?.additionalInfo?.poNumber,
                        required: response?.additionalInfo?.requiredFields?.isPoNumber
                    },
                    referenceNo: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.referenceNumber,
                        newValue: response?.additionalInfo?.referenceNumber
                    },
                    projectManagers: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.projectManagers,
                        newValue: response?.additionalInfo?.projectManagers?.map((item) => item?.id)
                    },
                    requestCurrency: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.requestCurrency,
                        newValue: response?.additionalInfo?.requestCurrency
                    },
                    salesRepresentative: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.salesRepresentative,
                        newValue: response?.additionalInfo?.salesRepresentative
                    },
                    invoiceStatus: {
                        isEdit: false,
                        isError: false,
                        value: response?.additionalInfo?.invoiceStatus,
                        newValue: response?.additionalInfo?.invoiceStatus
                    }
                }));

                setDateAndDeadEditInput((prevState) => ({
                    ...prevState,
                    completedAt: { isEdit: false, value: response?.dateAndDeadLines?.completedAt },
                    createdAt: { isEdit: false, value: response?.dateAndDeadLines?.createdAt },
                    quoteTargetDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.quoteDatetime,
                        newValue: response?.dateAndDeadLines?.quoteDatetime
                    },
                    requestDeliveryDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.requestedDeliveryDate,
                        newValue: response?.dateAndDeadLines?.requestedDeliveryDate
                    },
                    internalDeliveryDate: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.internalDeliveryDate,
                        newValue: response?.dateAndDeadLines?.internalDeliveryDate
                    },
                    turnAroundTime: {
                        isEdit: false,
                        isError: false,
                        value: response?.dateAndDeadLines?.turnAroundTime,
                        newValue: response?.dateAndDeadLines?.turnAroundTime
                    }
                }));

                setInstructions((prevState) => ({
                    ...prevState,
                    pmInstruction: {
                        isEdit: false,
                        isError: false,
                        value: response?.instructionByProjectManager?.instruction ?? '',
                        newValue: response?.instructionByProjectManager?.instruction ?? ''
                    },
                    pmCreatedAt: {
                        isEdit: false,
                        value: response?.instructionByProjectManager?.createdAt ?? ''
                    },
                    cuInstruction: {
                        isEdit: false,
                        isError: false,
                        value: response?.instructionByContactUser?.instruction ?? '',
                        newValue: response?.instructionByContactUser?.instruction ?? ''
                    },
                    cuCreatedAt: {
                        isEdit: false,
                        value: response?.instructionByContactUser?.createdAt ?? ''
                    },
                    customDisclaimer: {
                        isEdit: false,
                        isError: false,
                        value: response?.customDisclaimerSTD || '',
                        newValue: response?.customDisclaimerSTD || ''
                    }
                }));

                setViewData(response);

                setDropDownValue(response.headers.statusName);
            } catch (error) {
                console.error(error);
            }
        }
    };
    const getStatusList = async () => {
        try {
            const response = await getRequestStatusList<StatusType[]>();
            setStatusList(response);
        } catch (error) {
            console.error(error);
            showToastMessage(
                t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_REQUEST_STATUS_LIST'),
                ToastType.ERROR
            );
        }
    };
    const getCurrencyList = async () => {
        try {
            const list: CurrencyList[] = await summaryService.getCurrencyList();
            setCurrencyList(list);
        } catch (error) {
            console.error(error);
        }
    };
    const getDocumentAndLanguagesListWrapper = () => {
        getDocumentAndLanguagesList().catch((error) => {
            console.error(error);
        });
    };
    const getDocumentAndLanguagesList = async () => {
        if (requestId) {
            try {
                const response =
                    await getUploadedDocumentAndLanguagesList<DocumentDetailsResponse>(requestId);
                setDocumentAndLanguagesList(response);
            } catch (error) {
                console.error(error);
                showToastMessage(
                    t('QUOTE_AND_ORDER.ERROR_MESSAGE.GET_REQUEST_STATUS_LIST'),
                    ToastType.ERROR
                );
            }
        }
    };
    const redirectAccordion = (fieldName: any) => {
        setAccordionActive((prevState) => ({
            ...prevState,
            [fieldName]: true
        }));
    };
    const handleAccordion = (fieldName: keyof StandardAccordionType) => {
        setAccordionActive((prevState) => ({
            ...prevState,
            [fieldName]: !prevState[fieldName]
        }));
    };
    const submitPatentTitle = async () => {
        try {
            const response = await updatePatentTitle(
                { patentTitle: requestDetailsInput.patentTitle.newValue },
                requestId as string
            );
            if (response) getStandardDetailsAPI(); // refresh details
        } catch (error) {
            console.error(error);
        }
    };
    const submitRequestCurrency = async (currencyCode: string) => {
        try {
            const requestCurrencyId = currencyList.find(
                (item) => item.currencyCode === currencyCode
            )?.currencyId;

            if (!requestCurrencyId) throw new Error('Currency not found');

            const response = await updateRequestCurrency({
                orderId: +(requestId as string),
                requestCurrencyId
            });

            if (response) {
                getStandardDetailsAPI(); // refresh details
                quoteOrderModuleStore.invokeFunction('refreshInvoiceTaskList');
                quoteOrderModuleStore.invokeFunction('refreshBillTasksList');
            }
        } catch (error) {
            console.error(error);
        }
    };

    const handleSaveWrapper = (value1: string, value2: string) => {
        const result = handleSave(value1, value2);

        if (result instanceof Promise) {
            result.catch((err) => {
                console.error(err);
            });
        }
    };
    const handleSave = async (fieldName: string, section: string) => {
        if (fieldName === 'patentTitle') {
            submitPatentTitle();
            return;
        } else if (fieldName === 'requestCurrency') {
            confirmRequestCurrencyChange(additionalInfoInput.requestCurrency.newValue);
            return;
        }

        let body: any;
        let updateFunction: any;
        let setResponse: any;
        let setState: any;
        let stateValues: any;

        switch (section) {
            case 'AdditionalInfo':
                body = additionalInfoUpdateBody(fieldName, additionalInfoInput);
                updateFunction = updateAdditionalInfo;
                setResponse = setAddInfoResponse;
                setState = setAdditionalInfoInput;
                stateValues = additionalInfoInput;
                break;
            case 'DateAndDeadlines':
                body = dateAndDeadlineUpdateBody(fieldName, dateAndDeadEditInput, requestId);
                updateFunction =
                    fieldName !== 'internalDeliveryDate'
                        ? updateDateAndDeadline
                        : updateInternalDeadline;
                setResponse = setDateDeadlineResponse;
                setState = setDateAndDeadEditInput;
                stateValues = dateAndDeadEditInput;
                break;
            case 'Instruction':
                if (fieldName === 'cuInstruction') {
                    // The Field is contact user instruction, so, we should pass the hasPermission as false
                    // then only it will save in Instructions & Comments other wise  it saves in Internal Instructions & Comments
                    body = instructionUpdateBody(fieldName, instructions, false);
                } else {
                    body = instructionUpdateBody(
                        fieldName,
                        instructions,
                        isThisStaffUser || isThisVendorUser
                    );
                }
                updateFunction = updateInstruction;
                setResponse = setInstructionResponse;
                setState = setInstructions;
                stateValues = instructions;
                break;
            default:
                return;
        }

        if (requestId) {
            await handleAPIUpdate(
                updateFunction,
                body,
                requestId,
                setResponse,
                setState,
                stateValues,
                fieldName,
                !isQuoteState
            );
        }
    };
    const handleCancel = (fieldName: any, section: string) => {
        switch (section) {
            case 'RequestDetails':
                updateStateOnCancel(setRequestDetailsInput, requestDetailsInput, fieldName);
                break;
            case 'AdditionalInfo':
                updateStateOnCancel(setAdditionalInfoInput, additionalInfoInput, fieldName);
                break;
            case 'DateAndDeadlines':
                updateStateOnCancel(setDateAndDeadEditInput, dateAndDeadEditInput, fieldName);
                break;
            case 'Instruction':
                updateStateOnCancel(setInstructions, instructions, fieldName);
                break;
            default:
                break;
        }
    };
    // #endregion API Calls

    const setPreviewTypeModify = useCallback(() => {
        if (requestId) {
            getStandardDetailsAPI();
        } else {
            navigate('/orders-quotes');
        }
    }, []);

    // #region Use Effects
    useEffect(() => {
        if (requestId) {
            getStandardDetailsAPI();
            getStatusList();
            getDocumentAndLanguagesList();
        } else {
            navigate('/orders-quotes');
        }
    }, [
        requestId,
        statusResponse,
        addInfoResponse,
        dateDeadlineResponse,
        instructionResponse,
        documentRowValueChange
    ]);

    // quoteOrder store
    useEffect(() => {
        const setPrimaryIdForUpload = () => {
            const primaryId = viewData.requestDetails?.referenceNumber;

            if (!primaryId) return;
            const quoteOrderData: QuoteOrderModuleStore = quoteOrderModuleStore.getData();
            const updatedQuoteOrderInfo: QuoteOrderModuleStoreInfo = {
                ...quoteOrderData.info,
                primaryId: +primaryId
            };
            quoteOrderModuleStore.updatePage('info', updatedQuoteOrderInfo);
        };

        setPrimaryIdForUpload();
    }, [viewData.requestDetails.referenceNumber]);
    useEffect(() => {
        getCurrencyList();
        return () => {
            quoteOrderModuleStore.resetQuoteOrderStore();
        };
    }, []);

    const PdfPreviewDialog = () => {
        return (
            <Dialog
                header={
                    <div className="w-full flex justify-between items-center">
                        {(isQuoteState ? t('COMMON.QUOTE') + ' - ' : t('COMMON.ORDER') + ' - ') +
                            (viewData?.headers?.requestNumber ?? 'Preview')}
                        <i
                            className="pi pi-download mr-3 p-2 rounded-full text-base cursor-pointer !font-medium text-primary hover:bg-neutral-50"
                            onClick={() =>
                                utils.handleDownloadPngSvg(
                                    pdfUrl,
                                    (isQuoteState
                                        ? t('COMMON.QUOTE') + ' - '
                                        : t('COMMON.ORDER') + ' - ') +
                                        (viewData?.headers?.requestNumber ?? 'Preview')
                                )
                            }
                            onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        />
                    </div>
                }
                visible={visible}
                pt={previewDialogPopup}
                style={{ minWidth: '60vw', width: 'auto', maxWidth: '80vw', padding: '20px' }}
                onHide={() => setVisible(false)}>
                <iframe
                    src={`${pdfUrl}#toolbar=0&page=1&zoom=${getWindowSize()},1,1`}
                    style={{ width: '100%', minHeight: '80vh' }}
                />
            </Dialog>
        );
    };
    // Page sections
    const viewQuoteOrderRequestHeaderDetails = () => {
        return (
            <div className="md:py-1 mt-3" data-testid="view-order-header">
                <ViewOrderAndQuoteHeader
                    ref={headerRef}
                    orderInsights={viewData?.headers ?? ({} as HeaderType)}
                    statusList={statusList}
                    state={state}
                    requestNumber={requestId ?? ''}
                    setDropDownValue={setDropDownValue}
                    dropDownValue={dropDownValue}
                    currencySymbol={viewData?.additionalInfo?.currencySymbol ?? ''}
                    requestType={IP_NONIP.nonIp}
                    setStatusResponse={statusRerender}
                    viewData={viewData}
                    isStandardFlow={true}
                    isQuoteCreation={isQuoteCreation}
                />
            </div>
        );
    };

    const isShowApproveQuoteButton = () => {
        const isShow: boolean =
            isQuoteToOrder &&
            (isThisStaffUser || isThisVendorUser || isThisContactUser) &&
            isWFA &&
            // (isPreparingQuote || isWFA) &&
            // !isToBeProcessed &&

            /** check permission */
            (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                AuthStore.hasPermission(Permissions.EDIT_ORDER));

        return isShow;
    };

    const isShowCancelButton = () => {
        const isShow: boolean =
            isQuoteToOrder &&
            (isSalesRep(loggedInUserId) || isContactUser(loggedInUserId)) &&
            isWFA &&
            /** check permission */
            (AuthStore.hasPermission(Permissions.EDIT_QUOTE) ||
                AuthStore.hasPermission(Permissions.EDIT_ORDER));

        return isShow;
    };

    const downloadPDFWrapper = () => {
        downloadPDF().catch((error) => console.error(error));
    };
    const downloadPDF = async () => {
        try {
            if (!stdPreviewType) {
                showToastMessage(
                    t(
                        'QUOTE_AND_ORDER.ERROR_MESSAGE.WARNING_EMPTY_PREVIEW_TEMPLATE_ON_PREVIEW_FILE'
                    ),
                    ToastType.ERROR
                );
                return null;
            }

            const response = await getPDFData(stdPreviewType, requestIdData);
            if (response) {
                setPdfUrl(response);
                setVisible(true);
            }
        } catch (error) {
            showToastMessage(t('QUOTE_AND_ORDER.ERROR_MESSAGE.ERROR_PREVIEW_PDF'), ToastType.ERROR);
            console.error('Error in downloadPDF()');
            return null;
        }
    };
    const inlineNavigationLinkSection = () => {
        return (
            <div className="hidden md:block py-2.5">
                <div className="flex items-center px-3 py-2 w-full bg-white border-neutral-50 border-2 rounded-lg">
                    <a
                        className=" text-[1.083rem] font-medium text-primary mx-2"
                        href="#request-detail-container"
                        onClick={() =>
                            redirectAccordion('requestDetails')
                        }>{`${t('COMMON.REQUEST_DETAILS')}`}</a>
                    {separatorLine()}
                    <a
                        href="#additional-info-container"
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        className=" text-[1.083rem] font-medium text-primary mx-2"
                        onClick={() =>
                            redirectAccordion('additionalInfo')
                        }>{`${t('ADDITIONAL_INFO.TITLE')}`}</a>
                    {separatorLine()}
                    <a
                        className=" text-[1.083rem] font-medium text-primary mx-2"
                        href="#date-deadlines-container"
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        onClick={() => redirectAccordion('dateAndDeadlines')}>
                        {t('DATE_AND_DEADLINES.TITLE')}
                    </a>
                    {separatorLine()}
                    <a
                        href="#upload-document-container"
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        className=" text-[1.083rem] font-medium text-primary mx-2"
                        onClick={() =>
                            redirectAccordion('uploadedDocuments')
                        }>{`${t('QUOTE_AND_ORDER.UPLOAD_DOCUMENTS_AND_LANGUAGE_COMBINATIONS')}`}</a>
                    {separatorLine()}
                    <a
                        className=" text-[1.083rem] font-medium text-primary mx-2"
                        href="#instruction-comments-container"
                        onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                        onClick={() => redirectAccordion('instructions')}>
                        {t('COMMON.INSTRUCTIONS_AND_COMMENTS')}
                    </a>
                    {isShowServicesAccordion && (
                        <>
                            {separatorLine()}
                            <a
                                className=" text-[1.083rem] font-medium text-primary mx-2"
                                href="#bills-invoices-container"
                                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                                onClick={() => redirectAccordion('billsInvoice')}>
                                {!isThisContactUser
                                    ? t('QUOTE_AND_ORDER.BILLS_AND_INVOICE')
                                    : t('COMMON.SERVICES')}
                            </a>
                        </>
                    )}

                    <div className="hidden lg:flex lg:gap-3 ml-auto">
                        {isShowCancelButton() && (
                            <div className="hidden lg:inline ml-auto">
                                {
                                    <button
                                        className="btn border-secondary text-secondary hover:bg-secondary/5 hover:border-secondary h-9 min-h-9"
                                        onClick={() =>
                                            headerRef.current?.approveOrCancelButtonClick(false)
                                        }>
                                        {t('QUOTE_AND_ORDER.CANCEL_QUOTE')}
                                    </button>
                                }
                            </div>
                        )}

                        {isShowApproveQuoteButton() && (
                            <div className="hidden lg:inline ml-auto">
                                {
                                    <button
                                        className="btn button-primary h-9 min-h-9"
                                        onClick={() =>
                                            headerRef.current?.approveOrCancelButtonClick(true)
                                        }>
                                        {t('QUOTE_AND_ORDER.APPROVE_QUOTE')}
                                    </button>
                                }
                            </div>
                        )}
                        {isQuoteToOrder && !isPreparingQuote && (
                            <div className="hidden lg:inline ml-auto">
                                <PrimeButton
                                    testid="details-page-preview-button"
                                    label={t('COMMON.PREVIEW')}
                                    type="primary"
                                    outlined={true}
                                    size="medium"
                                    onClick={() => downloadPDFWrapper()}
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    };
    const requestDetailsSection = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="request-detail-container">
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('requestDetails')}
                    checked={accordionActive.requestDetails}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5 ">
                    <span className=" text-xl font-medium text-primary">
                        {t('COMMON.REQUEST_DETAILS')}
                    </span>
                </div>

                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                    <RequestDetailsPage
                        requestDetails={viewData?.requestDetails}
                        editInput={requestDetailsInput}
                        handleEdit={handleEditRequestDetails}
                        handleChange={handleChangeRequestDetails}
                        handleSave={handleSaveWrapper}
                        handleCancel={handleCancel}
                        category={viewData?.requestDetails.category ?? ''}
                        service={viewData?.requestDetails.service ?? ''}
                        viewData={viewData}
                    />
                </div>
            </div>
        );
    };
    const additionalInformationSection = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="additional-info-container">
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('additionalInfo')}
                    checked={accordionActive?.additionalInfo}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                    <span className=" text-xl font-medium text-primary">
                        {t('ADDITIONAL_INFO.TITLE')}
                    </span>
                </div>
                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                    <AdditionalInfoPage
                        editInput={additionalInfoInput}
                        currencyList={currencyList}
                        handleImageClick={handleImageClickAdditionalInfo}
                        handleChange={handleChangeAdditionalInfo}
                        handleSave={handleSaveWrapper}
                        handleCancel={handleCancel}
                        companyId={companyId ?? 0}
                        statuses={{ isCompleted, isInvoiced, isWFA, isPreparingQuote }}
                        isSTDFlow={true}
                    />
                </div>
            </div>
        );
    };
    const uploadDocumentSection = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="upload-document-container">
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('uploadedDocuments')}
                    checked={accordionActive?.uploadedDocuments}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                    <span className=" text-xl font-medium text-primary">
                        {t('QUOTE_AND_ORDER.UPLOAD_DOCUMENTS_AND_LANGUAGE_COMBINATIONS')}
                    </span>
                </div>

                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5  max-w-full overflow-auto">
                    <StandardDocumentTabSection
                        orderId={viewData.headers?.requestId}
                        primaryIdForAzureStorage={viewData.headers?.referenceFolderId}
                        requestType={viewData.requestType}
                        documentDetails={documentAndLanguagesList?.documentDetails ?? []}
                        blobUri={documentAndLanguagesList?.blobUri ?? ''}
                        documentRowValueChangeEvent={documentRowValueChangeEvent}
                        functions={{
                            getStandardDetailsAPI: () => getStandardDetailsAPIWrapper(),
                            getDocumentAndLanguagesList: () => getDocumentAndLanguagesListWrapper()
                        }}
                        flags={{
                            isCompleted,
                            isInvoiced,
                            isQuoteState,
                            isShowDeleteSectionButton: isShowDeleteSectionButton(),
                            isShowManageLanguageButton: isShowManageLanguageButton()
                        }}
                    />
                </div>
            </div>
        );
    };
    const billsAndInvoicesSection = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="bills-invoices-container">
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('billsInvoice')}
                    checked={accordionActive?.billsInvoice}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                    <span className=" text-xl font-medium text-primary">
                        {!isThisContactUser
                            ? t('QUOTE_AND_ORDER.BILLS_AND_INVOICE')
                            : t('COMMON.SERVICES')}
                    </span>
                </div>
                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                    <BillsAndInvoices
                        previewTypeModified={setPreviewTypeModify}
                        {...{ viewData }}
                        getOrderDetailsAPI={getStandardDetailsAPI}
                        patentCountResponse={true}
                        countryEditResponse={true}
                        isSTDFlow={true}
                    />
                </div>
            </div>
        );
    };
    const dateAndDeadLineSection = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="date-deadlines-container">
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('dateAndDeadlines')}
                    checked={accordionActive.dateAndDeadlines}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                    <span className=" text-xl font-medium text-primary">
                        {t('DATE_AND_DEADLINES.TITLE')}
                    </span>
                </div>
                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                    <DateAndDeadlinesPage
                        editInput={dateAndDeadEditInput}
                        handleImageClick={handleImageClickDateAndDeadline}
                        handleChange={handleOnChangeDateAndDeadline}
                        handleSaveAI={handleSaveWrapper}
                        handleCancelAI={handleCancel}
                        category={viewData.requestDetails.category}
                        service={viewData.requestDetails.service}
                        viewData={viewData}
                        contactUser={isThisContactUser}
                    />
                </div>
            </div>
        );
    };
    const InstructionAndComments = () => {
        return (
            <div
                className={`collapse collapse-arrow bg-white border-neutral-50 border-2 rounded-lg`}
                id="instruction-comments-container"
                key={'instruction-comments-container'}>
                <input
                    type="checkbox"
                    className="py-1 min-h-0"
                    name="my-accordion-2"
                    onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
                    onClick={() => handleAccordion('instructions')}
                    checked={accordionActive?.instructions}
                />
                <div className="collapse-title text-lg py-2.5 min-h-0 after:h-[11px] after:w-[11px] after:top-[1.7rem] after:right-[1.8rem] px-5">
                    <span className=" text-xl font-medium text-primary">
                        {t('COMMON.INSTRUCTIONS_AND_COMMENTS')}
                    </span>
                </div>
                <div className="collapse-content border-t-neutral-50 border-t-2 pb-0 px-5">
                    <InstructionsAndComments
                        instructionData={instructions}
                        instructionEditImageClick={instructionEditImageClick}
                        handleSaveAI={handleSaveWrapper}
                        handleCancelAI={handleCancel}
                        handleChange={handleChangeInstruction}
                        viewData={viewData}
                        isEditable={!isCompleted && !isInvoiced}
                    />
                </div>
            </div>
        );
    };
    // #endregion Page Sections Functions

    // config popup to trigger
    const confirmRequestCurrencyChange = (currencyCode: string) => {
        setPopupConfig({
            ...popupConfig,
            isShowPopup: true,
            description: t('QUOTE_AND_ORDER.WARNING.REQUEST_CURRENCY_CHANGE_CONFIRMATION'),
            requestToFunction: REQUEST_TO_FUNCTION.REQUEST_CURRENCY_CHANGE,
            storeDataToUpdate: JSON.stringify({ currencyCode })
        });
    };

    // handlers
    const isShowDeleteSectionButton = () => {
        const isMoreThanOneDoct =
            (documentAndLanguagesList?.documentDetails &&
                Array.isArray(documentAndLanguagesList.documentDetails) &&
                documentAndLanguagesList.documentDetails.length > 1) ??
            false;

        const isShow =
            isMoreThanOneDoct &&
            (!isThisContactUser || (isThisContactUser && isQuoteState === true));

        return isShow;
    };
    const isShowManageLanguageButton = () => {
        const isShow = !isThisContactUser || (isThisContactUser && isQuoteState === true);
        return isShow;
    };

    // popup
    const REQUEST_TO_FUNCTION = {
        REQUEST_CURRENCY_CHANGE: 1
    };
    const onPopupConfirmWrapper = () => {
        const onPopupConfirm = async () => {
            try {
                if (REQUEST_TO_FUNCTION.REQUEST_CURRENCY_CHANGE) {
                    const currencyCode: string = JSON.parse(
                        popupConfig.storeDataToUpdate
                    ).currencyCode;
                    await submitRequestCurrency(currencyCode);
                    setPopupConfig(popupConfigInit);
                }
            } catch (error) {
                console.error(error);
            }
        };

        onPopupConfirm().catch((error) => {
            console.error(error);
        });
    };
    const onPopupCancel = () => {
        setPopupConfig(popupConfigInit);
    };

    return (
        <>
            {popupConfig.isShowPopup && (
                <ConfirmationPopup
                    popupID="popupSTDDetailsPage"
                    visible={popupConfig.isShowPopup}
                    headerText={popupConfig.header}
                    description={popupConfig.description}
                    onConfirm={onPopupConfirmWrapper}
                    onCancel={onPopupCancel}
                />
            )}
            {PdfPreviewDialog()}
            <TopNavigationStep
                backNavigationPath="/orders-quotes"
                steps={[
                    {
                        label: t('COMMON.ORDERS_QUOTES'),
                        isCurrent: false,
                        isPrevious: true,
                        navigationPath: '/orders-quotes'
                    },
                    {
                        label: viewData?.headers?.requestNumber ?? '',
                        isCurrent: true,
                        isPrevious: false,
                        labelName: isOrder ? t('COMMON.ORDER') : t('COMMON.QUOTE'),
                        module: 'ORDER_QUOTE',
                        isCopyable: true
                    }
                ]}
            />
            <div data-testid="view-order-Page" className="px-4">
                {/*  Inline Navigation Links */}
                <div className="sticky top-0 z-[9] bg-neutral-bg-50">
                    {viewQuoteOrderRequestHeaderDetails()}
                    {inlineNavigationLinkSection()}
                </div>
                {/*  Inline Navigation Accordions */}
                <div className="w-full overflow-x-hidden overflow-scroll xl:max-h-[calc(100vh-230px)] 2xl:max-h-[calc(100vh-261px)] 4xl:max-h-[calc(100vh-305px)]">
                    <div>
                        <div className="grid gap-y-1 md:grid md:gap-y-2">
                            {requestDetailsSection()}
                            {additionalInformationSection()}
                            {dateAndDeadLineSection()}
                            {uploadDocumentSection()}
                            {InstructionAndComments()}
                            {isShowServicesAccordion && billsAndInvoicesSection()}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default StandardDetails;
