import '@testing-library/jest-dom/extend-expect';
import { render, screen } from '@testing-library/react';
import ViewOrderAndQuotePage from './viewOrderAndQuote';
import viewOrderAndQuoteData from './Mock/viewOrderAndQuote.mock.json';
import { ViewOrderAndQuoteHeader } from './components/header/header';
import RequestDetailsPage from './components/requestDetails/requestDetails';
import AdditionalInfoPage from './components/additionalInfo/additionalInfo';
import DateAndDeadlinesPage from './components/dateAndDeadlines/dateAndDeadlines';
import PatentCountsPage from './components/patentCounts/patentCounts';
import CountryDetailsPage from './components/countryDetails/countryDetails';
import InstructionsAndComments from './components/instructions/instructions';

const {
    requestDetailsData,
    additionalInfoData,
    dateAndDeadlinesData,
    patentCountsData,
    countryDetailsData,
    orderInsightsData
} = viewOrderAndQuoteData;

jest.mock('react-router-dom', () => {
    return {
        useNavigate: () => jest.fn(),
        useLocation: () => jest.fn(),
        useParams: () => jest.fn()
    };
});

jest.mock('i18next', () => {
    return {
        t: () => jest.fn()
    };
});

jest.mock('@azure/storage-blob', () => {
    return {
        BlobServiceClient: jest.fn()
    };
});

const statusList = [
    {
        id: 3,
        name: 'To be Processed',
        statusType: 2
    },
    {
        id: 4,
        name: 'In Progress',
        statusType: 2
    },
    {
        id: 5,
        name: 'Canceled',
        statusType: 2
    },
    {
        id: 6,
        name: 'On Hold',
        statusType: 2
    },
    {
        id: 7,
        name: 'Completed',
        statusType: 2
    },
    {
        id: 8,
        name: 'Invoiced',
        statusType: 2
    }
];

const state = {
    id: 4301,
    requestNumber: 'R-4043',
    statusName: 'Completed'
};

describe('The View Order/Quote screen', () => {
    test('Check render of the view Order/Quote screen', () => {
        render(<ViewOrderAndQuotePage></ViewOrderAndQuotePage>);
        expect(screen.getByTestId('view-order-page')).toBeDefined();
    });
});

describe('Header of view order/quote', () => {
    test('Check render of header in the view Order/Quote screen', () => {
        render(
            <ViewOrderAndQuoteHeader
                orderInsights={orderInsightsData}
                statusList={statusList}
                state={state}
                requestNumber={'4404'}
                setDropDownValue={() => {}}
                dropDownValue={'To Be Processed'}
                currencySymbol={'$'}
                requestType=""
                setStatusResponse={() => {}}
                viewData={{}}
                isQuoteCreation={false}
            />
        );
    });

    test('Check the presence of header elements', () => {
        render(
            <ViewOrderAndQuoteHeader
                orderInsights={orderInsightsData}
                statusList={statusList}
                state={state}
                requestNumber={'4404'}
                setDropDownValue={() => {}}
                dropDownValue={'To Be Processed'}
                currencySymbol={'$'}
                requestType=""
                setStatusResponse={() => {}}
                viewData={{}}
                isQuoteCreation={false}
            />
        );
        expect(screen.getByTestId('order-id')).toBeDefined();
        expect(screen.getByTestId('patent-right')).toBeDefined();
        expect(screen.getByTestId('header-user')).toBeDefined();
        expect(screen.getByTestId('header-status-dropdown')).toBeDefined();

        // const editOrderButton = screen.getByTestId('edit-order-button');
        // expect(editOrderButton).toBeDefined();
        // fireEvent.click(editOrderButton);
    });
});

describe('Request details section', () => {
    test.skip('Check render of request details section in the view Order/Quote screen', () => {
        render(
            <RequestDetailsPage
                requestDetails={requestDetailsData}
                category={''}
                service={''}
                viewData={{}}
            />
        );
    });

    test.skip('Check the presence of request details section fields screen', () => {
        render(
            <RequestDetailsPage
                requestDetails={requestDetailsData}
                category={''}
                service={''}
                viewData={{}}
            />
        );
        expect(screen.getByTestId('patent-title')).toBeDefined();
        expect(screen.getByTestId('category')).toBeDefined();
        expect(screen.getByTestId('service')).toBeDefined();
        expect(screen.getByTestId('patent-application-number')).toBeDefined();
        expect(screen.getByTestId('patent-publication-number')).toBeDefined();
        expect(screen.getByTestId('source-language')).toBeDefined();
        expect(screen.getByTestId('applicant-name')).toBeDefined();
    });
});

describe('Header of view order/quote', () => {
    test('Check render of additional info section in the view Order/Quote screen', () => {
        render(
            <AdditionalInfoPage
                editInput={additionalInfoData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSave={() => {}}
                handleCancel={() => {}}
                companyId={1}
            />
        );
    });
    test('Check render of additional info section in the view Order/Quote screen', () => {
        render(
            <AdditionalInfoPage
                editInput={additionalInfoData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSave={() => {}}
                handleCancel={() => {}}
                companyId={1}
            />
        );

        expect(screen.getByTestId('contact-email-read')).toBeDefined();
        // expect(screen.getByTestId('also-deliverTo-read')).toBeDefined();
        // expect(screen.getByTestId('po-no-read')).toBeDefined();
        expect(screen.getByTestId('reference-no-read')).toBeDefined();
    });
});

describe('Header of view order/quote', () => {
    test('Check render of date and deadlines section in the view Order/Quote screen', () => {
        render(
            <DateAndDeadlinesPage
                editInput={dateAndDeadlinesData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                handleSaveAI={() => {}}
                handleCancelAI={() => {}}
                category={''}
                service={''}
                viewData={''}
                contactUser={false}
            />
        );
    });
});

describe('Header of view order/quote', () => {
    test('Check render of patent counts section in the view Order/Quote screen', () => {
        render(
            <PatentCountsPage
                editInput={patentCountsData}
                handleImageClick={() => {}}
                handleChange={() => {}}
                viewData={[]}
                requestDetails={[]}
                patentCountEdit={false}
                loggedInUserId={1}
            />
        );
    });
});

describe('Header of view order/quote', () => {
    test('Check render of country details section in the view Order/Quote screen', () => {
        render(
            <CountryDetailsPage
                countryDetails={countryDetailsData}
                handleFilter={() => {}}
                sortHandler={() => {}}
                requestBody={{
                    searchModels: [],
                    sorting: {
                        propertyName: '',
                        value: ''
                    },
                    pageNo: 1,
                    pageCount: 10
                }}
                currencySymbol={'$'}
                category={''}
                service={''}
                viewData={{}}
                setCountryEditResponse={() => {}}
                countryEditResponse={true}
            />
        );
    });
});

describe('Render the instrucion and comments section', () => {
    test('Check the render of instruction and comments', () => {
        const instructionPMData = {
            pmInstruction: {
                isEdit: false,
                isError: false,
                value: '',
                newValue: ''
            },
            pmCreatedAt: {
                isEdit: false,
                value: '2024-07-31T09:56:59.253'
            },
            cuInstruction: {
                isEdit: false,
                isError: false,
                value: '',
                newValue: ''
            },
            cuCreatedAt: {
                isEdit: false,
                value: '2024-07-31T09:56:59.253'
            }
        };
        render(
            <InstructionsAndComments
                instructionData={instructionPMData}
                instructionEditImageClick={() => {}}
                handleSaveAI={() => {}}
                handleCancelAI={() => {}}
                handleChange={() => {}}
                viewData={{}}
            />
        );
    });
});
