import HttpService from 'core/interceptor/api.handler';

import viewOrderQuoteServices from './viewOrderQuoteService';

jest.mock('core/interceptor/api.handler');

describe('companiesService', () => {
    const mockError = new Error('Mock error');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('getOrderDetails', () => {
        const id = '2';
        it('should fetch getCompanyData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getOrderDetails(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getOrderDetails(id)).rejects.toThrow(mockError);
        });
    });

    describe('getCountryDetails', () => {
        const id = '1';
        const requestBody = {
            searchModels: [{ propertyName: 'name', value: '' }],
            sorting: { propertyName: 'name', value: '' },
            pageNo: 1,
            pageCount: 10
        };
        it('should fetch getContactUserData successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getCountryDetails(id, requestBody);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getCountryDetails(id, requestBody)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getRequestStatusList', () => {
        it('should fetch getRequestStatusList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getRequestStatusList();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getRequestStatusList()).rejects.toThrow(mockError);
        });
    });

    describe('updateOrderStatus', () => {
        const orderRequestId = 1;
        const orderStatusId = 1;
        it('should fetch getRequestStatusList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateOrderStatus(
                orderRequestId,
                orderStatusId
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateOrderStatus(orderRequestId, orderStatusId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('getRecalculate', () => {
        const orderRequestId = 1;
        it('should fetch getRequestStatusList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getRecalculate(orderRequestId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getRecalculate(orderRequestId)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('updateAdditionalInfo', () => {
        const body = {};
        const orderId = '1';
        it('should fetch getRequestStatusList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'put').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateAdditionalInfo(body, orderId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'put').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateAdditionalInfo(body, orderId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updateDateAndDeadline', () => {
        const body = {};
        const orderId = '1';
        it('should fetch getRequestStatusList successfully', async () => {
            jest.spyOn(HttpService.prototype, 'put').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateDateAndDeadline(body, orderId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'put').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateDateAndDeadline(body, orderId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updateInstruction', () => {
        const body = {};
        const orderId = '1';
        it('should fetch updateInstruction successfully', async () => {
            jest.spyOn(HttpService.prototype, 'put').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateDateAndDeadline(body, orderId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'put').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateDateAndDeadline(body, orderId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updatePatentCounts', () => {
        const body = {};
        const orderId = '1';
        it('should fetch updatePatentCounts successfully', async () => {
            jest.spyOn(HttpService.prototype, 'put').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updatePatentCounts(body, orderId);
            expect(result).toEqual([]);
        });
    });
    describe('updateCountryFees', () => {
        const body = {};
        const orderId = 1;
        it('should fetch updateCountryFees successfully', async () => {
            jest.spyOn(HttpService.prototype, 'patch').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateCountryFees(body, orderId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'patch').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.updateCountryFees(body, orderId)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getTaskId', () => {
        const orderId = 1;
        it('should fetch getTaskId successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getTaskId(orderId);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getTaskId(orderId)).rejects.toThrow(mockError);
        });
    });

    describe('getTaskDocumentStatus', () => {
        it('should fetch getTaskDocumentStatus successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getTaskDocumentStatus();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getTaskDocumentStatus()).rejects.toThrow(mockError);
        });
    });

    describe('updateTaskDocumentStatus', () => {
        const documentId = 1;
        const taskId = 1;
        const fileId = 1;
        const statusId = 1;
        const rejectionReason = null;
        it('should fetch getTaskDocumentStatus successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateTaskDocumentStatus(
                documentId,
                taskId,
                fileId,
                statusId,
                rejectionReason
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateTaskDocumentStatus(
                    documentId,
                    taskId,
                    fileId,
                    statusId,
                    rejectionReason
                )
            ).rejects.toThrow(mockError);
        });
    });

    describe('getFormalDocumentCountryList', () => {
        const id = 1;
        it('should fetch getTaskDocumentStatus successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getFormalDocumentCountryList(id);
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getFormalDocumentCountryList(id)).rejects.toThrow(
                mockError
            );
        });
    });

    describe('getFormalDocumentStatus', () => {
        it('should fetch getFormalDocumentStatus successfully', async () => {
            jest.spyOn(HttpService.prototype, 'get').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.getFormalDocumentStatus();
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'get').mockRejectedValueOnce(mockError);
            await expect(viewOrderQuoteServices.getFormalDocumentStatus()).rejects.toThrow(
                mockError
            );
        });
    });

    describe('poaDocumentReminderSend', () => {
        const documentId = 1;
        const fieldId = 1;
        it('should fetch poaDocumentReminderSend successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.poaDocumentReminderSend(
                documentId,
                fieldId
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.poaDocumentReminderSend(documentId, fieldId)
            ).rejects.toThrow(mockError);
        });
    });

    describe('updateStatusPublishToCustomer', () => {
        const documentId = 1;
        const fieldId = 1;
        const changeStatus = true;
        it('should fetch updateStatusPublishToCustomer successfully', async () => {
            jest.spyOn(HttpService.prototype, 'post').mockResolvedValue([]);
            const result = await viewOrderQuoteServices.updateStatusPublishToCustomer(
                documentId,
                fieldId,
                changeStatus
            );
            expect(result).toEqual([]);
        });

        it('should handle error while fetching request currency data', async () => {
            // Mock the get method to reject with the mock error
            jest.spyOn(HttpService.prototype, 'post').mockRejectedValueOnce(mockError);
            await expect(
                viewOrderQuoteServices.updateStatusPublishToCustomer(
                    documentId,
                    fieldId,
                    changeStatus
                )
            ).rejects.toThrow(mockError);
        });
    });
});
