import { END_POINT } from 'constants/endPoint';
import HttpService from 'core/interceptor/api.handler';
import {
    RequestBody,
    VendorAssignmentCheckRequestBody
} from 'shared/dataTable/types/dataTable.types';
import { AddInstructionData } from '../components/billsAndInvoices/billsAndInvoices';
import {
    ManageLanguageSaveModel,
    SaveTaskListToReorderModel,
    Task,
    ValidateTargetLanguageInputModel
} from '../types/standardViewDetailsTypes';

const pvBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
const quoteBaseURL = process.env.REACT_APP_QUOTE_BASE_URL;
const _httpService = new HttpService();

/**
 * getOrderDetails function to get order/quote details for the individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the detail data.
 */
export const getOrderDetails = async <T>(id: string, isUpcOptOut?: boolean): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER_SAVE}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_ORDERS_DETAILS}/${id}`;
    const upcOptOutApiUrl = `${pvBaseURL}/${END_POINT.ORDERS_AND_QUOTES_END_POINT.QUOTE_ORDER_UPC_DETAILS}/${id}`;

    try {
        const response = await _httpService.get<T>(isUpcOptOut ? upcOptOutApiUrl : apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * getOrderDetails for standard function to get order/quote standard details for the individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the detail data.
 */
export const getStandardDetails = async <T>(id: string): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_STANDARD_DETAILS}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * getCountryDetails function to get the coutries details for individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the countries data.
 */
export const getCountryDetails = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER_SAVE}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_COUNTRY_DETAILS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * getCountryDetails function to get the coutries details for individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the countries data.
 */
export const getEpUpCountryDetails = async <T>(id: string): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDER_SAVE}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_EP_UP_COUNTRY_LANGUAGE_LIST}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * getCountryDetails function to get the coutries details for individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the countries data.
 */
export const getLanguageDetails = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_LANGUAGE_DETAILS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * getCountryDetails function to get the coutries details for individual order/quote
 * @param id - The ID of the  Order/Quote to get order details.
 * @returns {Promise<T>} A promise resolving to the countries data.
 */
export const getUploadedDocumentAndLanguagesList = async <T>(id: string): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_DOCUMENT_AND_TASK_DETAILS}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetch table column definition based on the given page type.
 * @returns {Promise<T>} A promise resolving to the table column definition.
 */
export const getRequestStatusList = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_REQUEST_STATUS}/1,2`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Sends a PATCH request to update the status of a Order/Quote.
 * @param orderRequestId - The ID of the  Order/Quote to update.
 * @param orderStatusId - The new status of the  Order/Quote.
 * @returns {Promise<T>} A promise resolving to the table data.
 */
export const updateOrderStatus = async <T>(
    orderRequestId: number,
    orderStatusId: number,
    isConfirmed?: boolean
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER_SAVE}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_ORDER_AND_QUOTE_STATUS}/${orderRequestId}/${orderStatusId}?isConfirmed=${isConfirmed ?? false}`;
    try {
        const response = await _httpService.patch<T, null>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating status:', error);
        throw error;
    }
};

export const getRecalculate = async <T>(orderRequestId: number) => {
    const apiUrl = `${pvBaseURL}/order/summary/${orderRequestId}?isView=true`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error in recalculation:', error);
        throw error;
    }
};

export const updatePatentTitle = async (
    body: { patentTitle: string },
    orderId: string
): Promise<any> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STD_UPDATE_PATENT_TITLE}/${orderId}`;
    try {
        const response = await _httpService.put(apiUrl, body);
        return response;
    } catch (error) {
        console.error(`Error updating patent title :`, error);
        throw error;
    }
};
export const updateRequestCurrency = async (body: {
    orderId: number;
    requestCurrencyId: number;
}): Promise<any> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STD_UPDATE_REQUEST_CURRENCY}`;
    try {
        const response = await _httpService.put(apiUrl, body);
        return response;
    } catch (error) {
        console.error(`Error updating request currency :`, error);
        throw error;
    }
};

export const updateAdditionalInfo = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/additionalinfodetails/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error(`Error updating additional info section field :`, error);
        throw error;
    }
};

export const updateDateAndDeadline = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/dateanddeadlines/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error('Error updating date and deadline field :', error);
        throw error;
    }
};

export const updateInternalDeadline = async (body: any): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/update-internaldeliverydate`;
    try {
        const response = await _httpService.patch(apiurl, body);
        return response ? body?.internalDeliveryDate : null;
    } catch (error) {
        console.error('Error updating date and deadline field :', error);
        throw error;
    }
};

export const updateInstruction = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/instructions/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error('Error updating instruction and comments field :', error);
        throw error;
    }
};

export const updateStandardAdditionalInfo = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.STANDARD_ORDER_SAVE}/additionalinfodetails/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error(`Error updating additional info section field :`, error);
        throw error;
    }
};

export const updateStandardDateAndDeadline = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.STANDARD_ORDER_SAVE}/dateanddeadlines/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error('Error updating date and deadline field :', error);
        throw error;
    }
};

export const updateStandardInstruction = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.STANDARD_ORDER_SAVE}/instructions/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error('Error updating instruction and comments field :', error);
        throw error;
    }
};

export const updatePatentCounts = async (body: any, orderId: string): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/patentcounts/${orderId}`;
    try {
        const response = await _httpService.put(apiurl, body);
        return response;
    } catch (error) {
        console.error('Error updating Patent counts field :', error);
    }
};

// updateCountryFees function used to update the country table cell edit in order details screen.
export const updateCountryFees = async (
    body: any,
    orderId: number,
    disableErrorToast?: boolean
): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/updateCountryDetails/${orderId}`;
    try {
        const response = await _httpService.patch(
            apiurl,
            body,
            undefined,
            false,
            undefined,
            disableErrorToast || false
        );
        return response;
    } catch (error) {
        console.error(`Error updating countries field :`, error);
        throw error;
    }
};

// updateCountryFees function used to update the country table cell edit in order details screen.
export const EPvalidateVendorAssignment = async (
    body: VendorAssignmentCheckRequestBody
): Promise<any> => {
    const apiurl = `${pvBaseURL}${END_POINT.ORDER_SAVE}/validate-vendor-assignment/`;
    try {
        const response = await _httpService.post(apiurl, body);
        return response;
    } catch (error) {
        console.error(`Error validating vendor assignment :`, error);
        throw error;
    }
};

/**
 * Fetches the source documents for the given order/quote ID.
 * @param id - The ID of the  Order/Quote to get source documents.
 * @returns {Promise<T>} A promise resolving to the source documents data.
 */
export const getSourceDocuments = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_SOURCE_DOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching source documents:', error);
        throw error;
    }
};

/**
 * Fetches the filed documents for the given order/quote ID.
 * @param id - The ID of the  Order/Quote to get filed documents.
 * @returns {Promise<T>} A promise resolving to the filed documents data.
 */
export const getFiledDocuments = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FILED_DOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching filed documents:', error);
        throw error;
    }
};

/**
 * Fetches the task ID for the given order/quote ID.
 * @param id - The ID of the  Order/Quote to get task ID.
 * @returns {Promise<T>} A promise resolving to the task ID data.
 */
export const getTaskId = async <T>(id: number): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_TASK_ID}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

/**
 * Fetches the task document status for the given order/quote ID.
 * @returns {Promise<T>} A promise resolving to the task document status data.
 */
export const getTaskDocumentStatus = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_TASK_DOCUMENT_STATUS}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const getExecutedDocumentStatus = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_EXECUTED_DOCUMENT_STATUS}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateTaskDocumentStatus = async (
    documentId: number,
    taskId: number,
    fileId: number,
    statusId: number,
    rejectionForFiled: string | null
): Promise<any> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_TASK_DOCUMENT_STATUS}`;
    try {
        const payload = { taskId, documentId, fileId, statusId, rejectionForFiled };
        const response = await _httpService.patch(apiUrl, payload);
        return response;
    } catch (error) {
        console.error('Error updating task document status:', error);
        throw error;
    }
};

export const updateExecutedPOADocumentStatus = async (
    documentId: number,
    fileId: number,
    statusId: number
): Promise<any> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATED_EXECUTED_FORMAL_DOCUMENT}/${documentId}/${fileId}/${statusId}`;
    try {
        const response = await _httpService.patch(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating task document status:', error);
        throw error;
    }
};

export const getFormalDocuments = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FORMAL_DOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching formal documents:', error);
        throw error;
    }
};

export const getFormalDocumentCountryList = async <T>(id: number): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FORMAL_DOCUMENTS_COUNTRY_LIST}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching formal documents:', error);
        throw error;
    }
};

export const getFormalDocumentStatus = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FORMAL_DOCUMENT_STATUS}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateFormalDocumentStatus = async <T>(
    documentId: number,
    fileId: number,
    poaStatusId: number,
    reasonforRejection: string | null,
    rejectionDeliveryDate: string | null
): Promise<T> => {
    const formatDate = rejectionDeliveryDate ? new Date(rejectionDeliveryDate).toISOString() : '';

    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_FORMAL_DOCUMENT_STATUS}/${documentId}/${fileId}/${poaStatusId}?reasonforRejection=${reasonforRejection}&rejectionDeliveryDate=${formatDate}`;

    try {
        const response = await _httpService.patch<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating formal document status:', error);
        throw error;
    }
};

export const getFormalDocumentHardCopyStatus = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FORMAL_DOCUMENT_HARDCOPY_STATUS}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateFormalDocumentHardCopyStatus = async <T>(
    documentId: number,
    fileId: number,
    hardCopyStatusId: number,
    airwayNo?: string | null
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_FORMAL_DOCUMENT_HARDCOPY_STATUS}/${documentId}/${fileId}/${hardCopyStatusId}?AirwayNo=${airwayNo}`;
    try {
        const response = await _httpService.patch<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating formal document hard copy status:', error);
        throw error;
    }
};

export const getPDFData = async <T>(
    templateName: string,
    requestIdData: number,
    IsUp?: boolean,
    requestId?: number,
    isBothDecideLater?: boolean,
    isUPCOptOut?: boolean
) => {
    const isPreview: boolean = false;
    try {
        const apiUrl = `order/pdf/download?templateName=${templateName}&isPreview=${isPreview}`;
        const upcApiUrl = `upcoptout/upc-opt-out-requests/pdf/download/${requestIdData}?isPreview=${true}`;
        const orderSaveData = {
            referenceNo: requestIdData,
            IsUp,
            id: requestId,
            isBothDecideLater
        };

        const response = await _httpService.export<T, T>(
            isUPCOptOut ? upcApiUrl : apiUrl,
            isUPCOptOut ? ({} as T) : (orderSaveData as T),
            {},
            false,
            pvBaseURL
        );
        const fileUrl = window.URL.createObjectURL(
            new Blob([response as Blob], {
                type: 'application/pdf' // Set the correct MIME type for PDF
            })
        );
        return fileUrl;
    } catch (error) {
        console.error(`Error in download PDF template(): ${error}`);
        throw error;
    }
};

export const getProjectManagersList = async <T>(): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.PROJECT_MANAGER_LIST}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const poaDocumentReminderSend = async <T>(
    documentId: number,
    fileId: number
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.POA_DOCUMENT_REMINDER_SEND}/${documentId}/${fileId}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error sending POA document reminder:', error);
        throw error;
    }
};

export const getFinalDocuments = async <T>(id: string, requestBody: RequestBody): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_FINAL_DOCUMENT}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching final documents:', error);
        throw error;
    }
};

export const getStandardTranslatedDocuments = async <T>(
    orderId: string,
    requestBody: RequestBody
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_GET_TRANSLATED_DOCUMENT}/${orderId}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching final documents:', error);
        throw error;
    }
};

export const getExecutedFormalDocuments = async <T>(
    id: string,
    requestBody: RequestBody
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.EXECUTEDFORMALDOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching final documents:', error);
        throw error;
    }
};

export const getOrderCountries = async <T>(id: number): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_ORDER_COUNTIES_LIST}/${id}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const getCountryBasedTasks = async <T>(id: number, countryId: number): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_COUNTRY_TASK_LIST}/${id}/${countryId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateStatusPublishToCustomer = async <T>(
    documentId: number,
    fileId: number,
    changeStatus: boolean
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_STATUS_PUBLISH_TO_CUSTOMER}/${documentId}/${fileId}/${changeStatus}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error updating status publish to customer:', error);
        throw error;
    }
};

export const updateSTDStatusPublishToCustomer = async <T>(data: any): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_UPDATE_STATUS_PUBLISH_TO_CUSTOMER}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, data);
        return response;
    } catch (error) {
        console.error('Error updating status publish to customer:', error);
        throw error;
    }
};

export const checkFeesHasZeroValues = async (
    orderId: number
): Promise<{ hasZeroValues: boolean } | null> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.CHECK_FEES_VALIDATION_IP}/${orderId}`;

    try {
        const response = await _httpService.patch<{ hasZeroValues: boolean }, null>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error while checking country cost summary total: ', error);
        return null;
    }
};

export const checkFeesValidation = async <T>(orderId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.TASKMANAGEMENT_END_POINT.VALIDATE_ORDER_COMPLETE}?orderRequestId=${orderId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching fees validation:', error);
        throw error;
    }
};

export const checkAnyTasksAssignedToVendor = async <T>(orderId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.TASKMANAGEMENT_END_POINT.VALIDATE_ASSIGNED_TASKS_TO_VENDOR}?orderRequestId=${orderId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error while validate un-assigned task to vendor:', error);
        throw error;
    }
};

const standardPreview = async <T>(orderId: number, pdfTemplateId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}/${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_PREVIEW}${orderId}/${pdfTemplateId}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const checkTasksStatus = async <T>(orderId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.CHECK_TASKS_STATUS}/${orderId}`;

    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error while checking country cost summary total: ', error);
        return null as T;
    }
};

export const updateVendorInstructions = async <T>(instruction: AddInstructionData): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDER_SAVE}${END_POINT.ORDERS_AND_QUOTES_END_POINT.VENDOR_INSTRUCTION}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, instruction);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateShowToVendor = async <T>(rowData: Task): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STANDARD_ORDER_SHOW_TO_VENDOR}/${rowData.documentMappingId}/${!rowData.shownInvendor}`;
    try {
        const response = await _httpService.patch<T, any>(apiUrl, null);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const updateTaskShowToVendor = async <T>(data: any): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STANDARD_ORDER_DOCUMENT_SHOW_TO_VENDOR}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, data);
        return response;
    } catch (error) {
        console.error('Error fetching table column definition:', error);
        throw error;
    }
};

export const standardDeleteDocument = async <T>(id: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STANDARD_DELETE_DOCUMENT}?documentId=${id}`;

    try {
        const response = await _httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};
export const standardDeleteSection = async <T>(orderId: number, sectionId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STANDARD_DELETE_SECTION}/${orderId}/${sectionId}`;

    try {
        const response = await _httpService.delete<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

export const validateDeleteTargetLanguage = async <T>(
    data: ValidateTargetLanguageInputModel
): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STD_VALIDATE_DELETE_TARGET_LANGUAGE}`;
    try {
        const response = await _httpService.post<T, ValidateTargetLanguageInputModel>(apiUrl, data);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

export const manageLanguages = async <T>(data: ManageLanguageSaveModel): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.STD_MANAGE_LANGUAGES}`;
    try {
        const response = await _httpService.post<T, ManageLanguageSaveModel>(apiUrl, data);
        return response;
    } catch (error) {
        console.error('Error fetching table data:', error);
        throw error;
    }
};

export const getTaskDetailsToReorder = async <T>(orderId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_GET_TASK_TO_REORDER}/${orderId}`;
    try {
        const response = await _httpService.get<T>(apiUrl);
        return response;
    } catch (error) {
        console.error('Error while fetching tasks list to reorder: ', error);
        throw error;
    }
};
export const saveTaskDetailsToReorder = async <T>(data: SaveTaskListToReorderModel): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.STD_SAVE_TASK_TO_REORDER_LIST}`;
    try {
        const response = await _httpService.post<T, SaveTaskListToReorderModel>(apiUrl, data);
        return response;
    } catch (error) {
        console.error('Error while saving reorder task list: ', error);
        throw error;
    }
};

const updateBillsEditDetails = async <T>(billId: number, unitId: number): Promise<T> => {
    const apiUrl = `${quoteBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.UPDATE_BILLS_EDIT_DETAILS}/${billId}`;
    try {
        const response = await _httpService.patch<T, { unitId: number }>(apiUrl, {
            unitId
        });
        return response;
    } catch (error) {
        console.error('Error while updating bills edit details: ', error);
        throw error;
    }
};

export const getOfficialFilingReceiptDocuments = async <T>(
    id: string,
    requestBody: RequestBody
): Promise<T> => {
    const apiUrl = `${pvBaseURL}${END_POINT.ORDERS_AND_QUOTES_END_POINT.GET_OFFICIAL_FILING_RECEIPT_DOCUMENTS}/${id}`;
    try {
        const response = await _httpService.post<T, any>(apiUrl, requestBody);
        return response;
    } catch (error) {
        console.error('Error fetching official filing receipt documents:', error);
        throw error;
    }
};

const viewOrderQuoteServices = {
    getOrderDetails,
    getCountryDetails,
    getRequestStatusList,
    updateOrderStatus,
    updateAdditionalInfo,
    getRecalculate,
    updateDateAndDeadline,
    updatePatentCounts,
    updateCountryFees,
    getTaskDocumentStatus,
    updateTaskDocumentStatus,
    getFormalDocumentCountryList,
    getTaskId,
    getFormalDocumentStatus,
    poaDocumentReminderSend,
    updateStatusPublishToCustomer,
    checkFeesHasZeroValues,
    standardPreview,
    getExecutedFormalDocuments,
    getCountryBasedTasks,
    checkFeesValidation,
    checkAnyTasksAssignedToVendor,
    updateExecutedPOADocumentStatus,
    checkTasksStatus,
    updateVendorInstructions,
    getTaskDetailsToReorder,
    saveTaskDetailsToReorder,
    updateBillsEditDetails
};
export default viewOrderQuoteServices;
