import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ErrorPage from './errorPage';
import { BrowserRouter } from 'react-router-dom';

describe('<ErrorPage />', () => {
    test('it should mount', () => {
        render(
            <BrowserRouter>
                <ErrorPage />
            </BrowserRouter>
        );
        const errorPage = screen.getByTestId('ErrorPage');
        expect(errorPage).toBeInTheDocument();
    });
});
