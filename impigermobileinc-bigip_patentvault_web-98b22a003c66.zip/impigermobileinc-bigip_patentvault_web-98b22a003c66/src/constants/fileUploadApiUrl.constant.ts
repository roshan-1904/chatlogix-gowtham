export const QUOTE_ORDER_USER_MODULE = {
    UPLOAD_FILE: '/patentservice/savemultipledocumentsbysasuri?primaryId=',
    GET_FILE_LIST: '/patentservice/getuploadeddocuments/',
    DELETE_FILE: '/patentservice/deletedocumentupload',
    GET_DOCUMENT_TYPE: '/patentservice/getdocumentstypes/',
    UPDATE_DOCUMENT_TYPE: '/patentservice/updatedocumenttype',
    STD_GET_DOCUMENT_TYPE: '/standardOrder/getdocumentstypes/'
};

export const ORDER_QUOTE_MODULE = {
    GET_FILE_LIST: '/patentservice/order/documents/',
    REPLACE_EXISTING_FILE: '/order/updateformalexistingdocument',
    REPLACE_FILED_EXISTING_FILE: '/task/updateexistingdocument',
    REPLACE_STD_SOURCE_DOCUMENT: '/standardOrder/replaceDocument',
    UPDATE_VENDOR_INVOICE_NUMBER: '/standardOrder/updatevendorinvoicenumber'
};

export const TASK_MODULE = {
    UPLOAD_FILE: '/task/documentupload/',
    GET_FILE_LIST: '/task/documents/',
    GET_STANDARD_FILE_LIST: '/standardOrder/task/documents/',
    UPLOAD_STANDARD_FILE: '/standardOrder/documentUpload/'
};

export const VIEW_QUOTE_ORDER_MODULE = {
    UPLOAD_FILE: '/patentservice/savedocuments/order?primaryId='
};

export const FORMAL_DOCUMENT_MODULE = {
    UPLOAD_FILE: '/uploadformaldocuments'
};
