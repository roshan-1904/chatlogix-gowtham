import { STEPPER_DATA_TYPE } from 'pages/components/progressStepper/types/progressStepper.type';

export type ServiceTypesShortNames = 'PCT' | 'EP' | 'PC' | 'STD';

// IDs - Service and Category
export const SERVICE_TYPE_ID: { [key: string]: number } = {
    patent_cooperation_treaty: 1,
    european_patent: 2,
    paris_convention_treaty: 3,
    other_translations: 5
};
export const CATEGORY_TYPE_ID: { [key: number]: { [key: string]: number } } = {
    [SERVICE_TYPE_ID.patent_cooperation_treaty]: {
        translation_only: 6,
        'translation_&_filing': 7,
        recordal: 9,
        annuities: 10
    },
    [SERVICE_TYPE_ID.european_patent]: {
        '71_3_claims': 11,
        translation_only: 12,
        'translation_&_validation': 13,
        recordal: 15,
        Renewals: 16,
        upc_opt_out: 27
    },
    [SERVICE_TYPE_ID.paris_convention_treaty]: {
        translation_only: 17,
        'translation_&_filing': 18
    },
    [SERVICE_TYPE_ID.other_translations]: {
        patent_non_filing: 24
    }
};

// IDs - Stepper
export const STEPPER_TYPE_ID = {
    SELECT_SERVICE: 0,
    PATENT_AUTHENTICATION: 1,
    ADDITIONAL_INFORMATION: 2,
    PATENT_DETAILS: 3,
    SELECT_COUNTRY: 4,
    DOCUMENT_UPLOAD: 5,
    SUMMARY: 6,
    ORDER_QUOTE_DETAILS: 7,
    QO_DOCUMENT_UPLOAD: 8,
    LANGUAGE_SELECTION: 9,
    STD_UPLOAD_AND_SELECTION: 10
};
// Paths for Stepper
export const PATHS_FOR_STEPPER: { [key: number]: string } = {
    [STEPPER_TYPE_ID.SELECT_SERVICE]: 'service-type',
    [STEPPER_TYPE_ID.PATENT_AUTHENTICATION]: 'company-details',
    [STEPPER_TYPE_ID.ADDITIONAL_INFORMATION]: 'additional-info',
    [STEPPER_TYPE_ID.PATENT_DETAILS]: 'patent-details',
    [STEPPER_TYPE_ID.SELECT_COUNTRY]: 'select-country',
    [STEPPER_TYPE_ID.DOCUMENT_UPLOAD]: 'file-upload',
    [STEPPER_TYPE_ID.SUMMARY]: 'summary',
    [STEPPER_TYPE_ID.ORDER_QUOTE_DETAILS]: 'order-quote-details',
    [STEPPER_TYPE_ID.LANGUAGE_SELECTION]: 'language-selection',
    [STEPPER_TYPE_ID.QO_DOCUMENT_UPLOAD]: 'file-upload',
    [STEPPER_TYPE_ID.STD_UPLOAD_AND_SELECTION]: 'std-upload-selection'
};

export const STEPPER_DATA: { [key: string]: STEPPER_DATA_TYPE } = {
    PATENT_AUTHENTICATION: {
        stepperId: 1,
        stepperName: (params?: { name?: string }) => params?.name ?? 'Company & Authentication',
        stepperDesc: (params?: { description?: string }) =>
            params?.description ?? 'Requires Patent Number',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.PATENT_AUTHENTICATION]
    },
    ADDITIONAL_INFORMATION: {
        stepperId: 2,
        stepperName: 'Additional Information',
        stepperDesc: 'Additional Info Details',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.ADDITIONAL_INFORMATION]
    },
    PATENT_DETAILS: {
        stepperId: 3,
        stepperName: 'Patent Details',
        stepperDesc: 'Confirm Patent Information',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.PATENT_DETAILS]
    },
    SELECT_COUNTRY: {
        stepperId: 4,
        stepperName: 'Select Country',
        stepperDesc: 'Add Countries',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.SELECT_COUNTRY]
    },
    DOCUMENT_UPLOAD: {
        stepperId: 5,
        stepperName: 'Document Upload',
        stepperDesc: 'Optional',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.DOCUMENT_UPLOAD]
    },
    SUMMARY: {
        stepperId: 6,
        stepperName: 'Summary',
        stepperDesc: 'Finalize Order',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.SUMMARY]
    },
    ORDER_QUOTE_DETAILS: {
        stepperId: 7,
        stepperName: 'Order Quote Details',
        stepperDesc: 'Enter Order Quote Details',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.ORDER_QUOTE_DETAILS]
    },
    QO_DOCUMENT_UPLOAD: {
        stepperId: 8,
        stepperName: 'Document Upload',
        stepperDesc: 'Upload Document',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.QO_DOCUMENT_UPLOAD]
    },
    LANGUAGE_SELECTION: {
        stepperId: 9,
        stepperName: 'Language Selection',
        stepperDesc: 'Select Language',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.LANGUAGE_SELECTION]
    },
    STD_UPLOAD_AND_SELECTION: {
        stepperId: 10,
        stepperName: 'Document & Language',
        stepperDesc: 'Document Upload &<br /> Language Selection',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.STD_UPLOAD_AND_SELECTION]
    }
};

// for sample purpose only - not used any where
export const SAMPLE_STEPPER_DATA = [
    {
        stepperId: 1,
        stepperName: 'Patent Authentication',
        stepperDesc: 'Patent Authentication',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.PATENT_AUTHENTICATION]
    },
    {
        stepperId: 2,
        stepperName: 'Additional information',
        stepperDesc: 'Additional information',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.ADDITIONAL_INFORMATION]
    },
    {
        stepperId: 3,
        stepperName: 'Patent Details',
        stepperDesc: 'Patent Details',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.PATENT_DETAILS]
    },
    {
        stepperId: 4,
        stepperName: 'Select Country',
        stepperDesc: 'Select Country',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.SELECT_COUNTRY]
    },
    {
        stepperId: 5,
        stepperName: 'Document Upload',
        stepperDesc: 'Document Upload',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.DOCUMENT_UPLOAD]
    },
    {
        stepperId: 6,
        stepperName: 'Summary',
        stepperDesc: 'Summary',
        stepperPath: PATHS_FOR_STEPPER[STEPPER_TYPE_ID.SUMMARY]
    }
];
