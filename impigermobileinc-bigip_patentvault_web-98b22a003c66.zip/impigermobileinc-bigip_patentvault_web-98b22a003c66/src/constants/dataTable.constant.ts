import { RequestBody } from 'shared/dataTable/types/dataTable.types';

export const DATA_STORAGE_KEYS = {
    DATA_TABLE: {
        BILLING_COLUMN_ORDERS: 'billing_column_orders',
        TASKS_COLUMN_ORDERS: 'tasks_column_orders',
        REQUEST_CURRENCIES_ORDERS: 'request_currencies_orders',
        VENDOR_CURRENCIES_ORDERS: 'vendor_currencies_orders',
        LANGUAGES_COLUMN_ORDERS: 'languages_column_orders',
        UNITS_COLUMN_ORDERS: 'units_column_orders',
        IP_INSTRUCTION_DEADLINES_COLUMN_ORDERS: 'ip_instruction_deadlines_column_orders',
        PAYMENT_METHODS_COLUMN_ORDERS: 'payment_methods_column_orders',
        TAX_FORMS_COLUMN_ORDERS: 'tax_forms_column_orders',
        COMPANIES_COLUMN_ORDERS: 'companies_column_orders',
        QUOTE_ORDER_LIST: 'quote_order_orders',
        CONTACT_USER_LIST: 'contact_user_list',
        USERS_COLUMN_ORDERS: 'users_column_orders',
        LANGUAGE_SELECTION_COLUMN_ORDERS: 'language_selection_column_orders',
        VENDOR_RATES_LIST: 'vendor_rates_column_orders',
        SOURCE_DOCUMENT_COLUMN_ORDERS: 'source_document_column_orders',
        OFFICIAL_FILING_RECEIPTS_DOCUMENT_COLUMN_ORDERS:
            'official_filing_receipts_document_column_orders',
        VENDOR_INVOICES_DOCUMENT_COLUMN_ORDERS: 'vendor_invoices_document_column_orders',
        FILED_DOCUMENT_COLUMN_ORDERS: 'filed_document_column_orders',
        FORMAL_DOCUMENT_COLUMN_ORDERS: 'formal_document_column_orders',
        FILE_UPLOAD_COLUMN_ORDERS: 'file_upload_column_orders',
        MINIMUM_VENDOR_CHARGE: 'minimum_vendor_charge_column_orders',
        BREAKDOWNS_COLUMN_ORDERS: 'break_down_column_orders',
        RATE_LABELS_COLUMN_ORDER: 'rate_labels_column_orders',
        EPO_COLUMN_ORDER: 'epo_column_orders',
        BILLS_AND_INVOICES: 'bills_and_invoices',
        ACCOUNTING_BILLINGS_COLUMN_ORDERS: 'accounting_billings_column_orders',
        BILLINGS_DETAILS_SERVICES_COLUMN_ORDERS: 'billings_details_services_column_orders',
        ACCOUNTING_INVOICES_COLUMN_ORDERS: 'accounting_invoices_column_orders',
        ACCOUNTING_INVOICES_SERVICES_COLUMN_ORDERS: 'accounting_invoices_services_column_orders',
        TASK_DETAILS_COLUMN_ORDERS: 'task_details_column_orders',
        VENDOR_TASK_LIST: 'vendor_task_list',
        STD_LANGUAGE_COLUMN_ORDERS: 'std_language_column_orders',
        AR_ADJUSTMENTS_COLUMN_ORDERS: 'ar_adjustments_column_orders',
        AR_PAYMENTS_COLUMN_ORDERS: 'ar_payments_column_orders',
        AR_ADVANCES_COLUMN_ORDERS: 'ar_advances_column_orders',
        AP_PAYMENTS_COLUMN_ORDERS: 'ap_payments_column_orders',
        AP_ADJUSTMENTS_COLUMN_ORDERS: 'ap_adjustments_column_orders',
        AP_ADJUSTMENTS_DETAILS_COLUMN_ORDERS: 'ap_adjustments_details_column_orders',
        AR_ADJUSTMENTS_DETAILS_COLUMN_ORDERS: 'ar_adjustments_details_column_orders',
        AR_PAYMENTS_DETAILS_COLUMN_ORDERS: 'ar_payments_details_column_orders',
        AP_PAYMENTS_DETAILS_COLUMN_ORDERS: 'ap_payments_details_column_orders',
        EP_COUNTRY_COLUMN_ORDERS: 'ep_country_column_orders',
        BILL_BREAKDOWN_COLUMN_ORDERS: 'bill_breakdown_column_orders',
        ORDER_DETAILS_BILL_TASK: 'bill_task_order_details_column_orders',
        RATES: {
            pct: 'pct_rates_column_orders',
            pct_fre_ger: 'pct_rates_fre_ger_column_orders',
            claims: 'claims_rates_column_orders',
            ep: 'ep_rates_column_orders',
            ep_fre: 'ep_rates_fre_column_orders',
            ep_ger: 'ep_rates_ger_column_orders',
            upc: 'upc_rates_column_orders',
            pc: 'pc_rates_column_orders',
            companytranslations: 'company_translations_column_orders',
            viewCompanytranslations: 'company_translations_view_column_orders',
            vendortranslations: 'vendor_translations_column_orders'
        }
    },
    ROW_EDIT: 'row',
    GROUPED_TASKS: 'grouped_tasks',
    TASKS_LIST: 'tasks_list'
};
export const TABLE_POP_IDS = {
    CREATE_POPUP: {
        CREATING_BILLING_POPUP: 'create_billing_popup_modal',
        TASK_POPUP: 'task_popup_modal',
        REQUEST_CURRENCY_POPUP: 'request_currency_popup',
        VENDOR_CURRENCY_POPUP: 'vendor_currency_popup',
        LANGUAGES_POPUP: 'languages_popup_modal',
        UNITS_POPUP: 'units_popup_modal',
        IP_INSTRUCTION_DEADLINES_POPUP: 'ip_instruction_deadlines_popup_modal',
        PAYMENT_METHODS_POPUP: 'payment_methods_popup_modal',
        TAX_FORMS_POPUP: 'tax_forms_popup_modal',
        MINIMUM_CHARGE_POPUP: 'minimum_charge_modal',
        ADD_COUNTRY: 'pv_rates_add_country_popup_modal',
        VENDOR_RATE_POPUP: 'vendor_rate_popup_modal',
        EDIT_ADDRESS_INFORMATION_POPUP: 'edit_address_popup_modal',
        EDIT_FORMULA: 'pv_rates_edit_formula_popup_modal',
        COMPANY_TRANSLATIONS: 'pv_rates_company_translations',
        COMPANY_LOOKUP_INFORMATION_POPUP_ICON: 'company_lookup_information_popup_icon',
        COMPANY_LOOKUP_INFORMATION_POPUP_MODAL: 'company_lookup_information_popup_modal',
        EDIT_IP_RATES_FORMULA: 'edit_ip_rates_formula',
        EDIT_COMPANY_IP_RATES_FORMULA: 'edit_company_ip_rates_formula',
        MARK_AS_ACTIVE_POPUP: 'mark_as_active_popup_modal',
        VENDOR_USER_LOOKUP_INFORMATION_POPUP_ICON: 'vendor_user_lookup_information_popup_icon',
        VENDOR_USER_LOOKUP_INFORMATION_POPUP_MODAL: 'vendor_user_lookup_information_popup_modal',
        MANAGE_TASKS_POPUP: 'manage_tasks_popup_modal',
        MANAGE_STANDARD_LANGUAGE_POPUP: 'manage_standard_language_popup_modal',
        ENGLISH_TRANSLATION_FORMULA_POPUP: 'english_translation_formula_popup_modal'
    }
};

export const InitDefaultTableBody: RequestBody = {
    searchModels: [],
    sorting: {
        propertyName: '',
        value: ''
    },
    pageNo: 1,
    pageCount: 25
};
