export const SERVICE_TYPE = {};
