import { classNames } from 'primereact/utils';
export const dropDownStyle = {
    root: {
        className:
            'hover:border-primary font-medium border border-neutral-100 h-10 py-2 pl-4 pr-0 md:w-full items-center'
    },
    clearIcon: { className: 'relative right-auto top-auto m-auto ml-2' },
    emptyMessage: {
        className: 'px-4'
    },
    checkboxContainer: { className: 'w-4 h-4' },
    checkbox: { className: 'w-4 h-4 rounded-sm' },
    trigger: { className: 'px-1 w-8' },
    header: { className: 'p-0 rounded-none' },
    filterIcon: { className: 'hidden' },
    filterInput: {
        className: 'h-10 !rounded-none border-0 focus:outline-none focus:shadow-none'
    },
    panel: {
        className: 'border'
    },
    label: { className: '!p-0 text-sm' },
    item: { className: 'hover:bg-primary-50 py-3 w-full flex items-center !outline-0' },
    input: { className: 'p-0 truncate text-sm' }
};
export const filterDropDownStyle = {
    ...dropDownStyle,
    root: {
        className: dropDownStyle.root.className + ' bg-neutral-800 border-0'
    },
    panel: {
        className: 'border'
    },
    input: {
        className: dropDownStyle.input.className
    },
    header: { className: 'p-0 rounded-none' },
    headerCheckbox: {
        root: () => ({
            className: classNames('border-0')
        })
    },
    filtercontainer: { className: 'w-full' },
    checkboxContainer: { className: 'w-6 h-6' },
    checkbox: { className: 'w-6 h-6 rounded-lg' },
    closebutton: { className: 'shadow-none focus:shadow-none hover:bg-0' }
};

// input field styles
export const inputStyle =
    'w-full text-sm input input-bordered h-10 rounded-md border focus-within:outline-none border-neutral-100 focus:border-primary focus-within:border-primary disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200';
export const inputStyleNumber = {
    input: {
        root: {
            className:
                'w-full text-sm font-medium border-neutral-100 focus:border-primary focus:shadow-none h-10 rounded-md border disabled:bg-neutral-50 disabled:border-neutral-75 disabled:text-neutral-200'
        }
    }
};
export const inputStyleText = {
    root: {
        className:
            'w-full max-h-[12rem] text-sm font-medium border-neutral-100 focus:border-primary focus:shadow-none h-10 rounded-md border disabled:bg-neutral-200 disabled:border-neutral-200 disabled:text-neutral-200'
    }
};
export const inputTextArea = {
    root: {
        className: 'w-full'
    }
};

// customized input field styles
// export const inputStyleTaskDetails = {
//     ...inputStyleNumber,
//     input: {
//         root: {
//             className: inputStyleNumber.input.root.className + ' !w-56'
//         }
//     }
// };

export const summaryRequestCurrency = {
    ...dropDownStyle,
    root: {
        className:
            dropDownStyle.root.className +
            ' items-center justify-center !w-24 rounded-lg h-7 py-1 pr-1 pl-3'
    }
};
export const summaryLanguage = {
    ...dropDownStyle,
    root: {
        className:
            dropDownStyle.root.className +
            ' items-center justify-center !w-28 rounded-lg h-7 py-1 pr-1 pl-3'
    }
};
export const summaryGrandTotal = {
    ...dropDownStyle,
    root: {
        className:
            dropDownStyle.root.className +
            ' items-center justify-center !w-24 rounded-lg h-7 py-1 pr-1 pl-3'
    }
};

export const checkBoxStyle = {
    root: {
        className: 'rounded-md'
    },
    checkBox: {
        className: 'h-[1.15rem] rounded-md'
    },
    input: {
        className: 'rounded-md'
    }
};

export const tabViewPT = {
    nav: { className: 'border-none' }
};

export const tabPanelPT = (isActive: boolean = false, onClick?: () => void) => ({
    root: {
        className: 'p-2 border border-b border-l border-r border-primary-100/50'
    },
    headeraction: {
        className: 'p-0 border-0 !bg-transparent focus:shadow-none'
    },
    content: {
        className: 'p-2 border border-b border-l border-r border-primary-100/50'
    },
    header: {
        className:
            'relative cursor-pointer rounded-t-lg border border-b-0 px-4' +
            (isActive
                ? ' border-primary-100/50 bg-primary-light-50 after:bg-primary after:content-[""] after:absolute after:inset-x-0 after:top-[-1px] after:left-[50%] after:translate-x-[-50%] after:h-[4px] after:rounded-b-lg after:z-1 after:w-[80%]'
                : ' bg-neutral-200/10 border-neutral-200/10'),
        onClick
    },
    headertitle: {
        className: 'leading-[1.5rem] font-medium ' + (isActive ? 'text-primary' : 'text-black')
    }
});

export const customTableStyle = (customTableHeight = true) => ({
    wrapper: {
        className: `border-t-primary border-t-[0.2rem] ${customTableHeight ? 'tableCustomHeight' : 'tableCustomMaxHeight'}`,
        id: 'tableWrapper'
    },
    header: {
        className: 'p-0 text-title-header border-none headerCustomStyle'
    },
    thead: {
        className: 'bg-white'
    },
    headerRow: {
        className: 'bg-inherit'
    },
    table: {
        className: 'whitespace-nowrap mb-1'
    },
    bodyRow: {
        className: 'even:bg-neutral hover:bg-neutral-50'
    }
});

export const commonTableStyle = (customTableHeight = true) => ({
    header: {
        className: 'p-0 text-title-header border-none '
    },
    thead: {
        className: 'bg-white'
    },
    headerRow: {
        className: 'bg-inherit'
    },
    wrapper: {
        className: ` border-t-primary border-t-[0.2rem] min-h-[' + (scrollHeight) + '] ${customTableHeight ? 'tableCustomHeight' : 'tableCustomMaxHeight'}`
    },
    table: {
        className: 'whitespace-nowrap mb-1'
    },
    bodyCell: { className: 'py-2 border-x border-y border-neutral-100 text-base text-black' },
    bodyRow: {
        className: 'even:bg-neutral hover:bg-neutral-50'
    },
    paginator: {
        root: {
            className: 'px-0'
        },
        RPPDropdown: {
            root: {
                className: 'w-16 md:w-16 h-7 flex items-center rounded'
            },
            input: {
                className: 'text-xs'
            },
            trigger: {
                className: 'w-3 absolute right-3'
            },
            panel: {}
        },
        prevPageButton: {
            className: 'mr-2 h-12 flex items-center'
        },
        pages: {
            className: 'flex items-center'
        },
        pageButton: {
            className: 'h-7 min-w-[1.7rem] text-sm flex items-center rounded'
        },
        current: {
            className: 'mr-auto'
        }
    }
});

export const commonColumnStyle = () => ({
    headerCell: {
        className: `!border-0 text-neutral-200`
    },
    bodyCell: {
        className: `border-neutral-100 py-2 text-base text-black`
    },
    headerContent: {
        className: `font-medium text-neutral-1000`
    },
    sortIcon: {
        className: 'w-3 text-neutral-200'
    },
    headerFilterClearButton: {
        className: 'hidden'
    },
    headerTitle: {
        className: 'w-full'
    },
    filterInput: {
        className: `inlineFilter`
    }
});

export const venderDropdownStyle = {
    root: {
        className: ' !p-0 border-0 flex-row-reverse h-8 bg-transparent items-center text-[#1175C2]'
    },
    trigger: {
        className: 'w-8 mr-1'
    },
    wrapper: {
        className: 'border-0'
    },
    panel: {
        className: 'border-0 w-full md:w-[17rem] boxShadow rounded-md'
    },
    filterIcon: {
        className: 'left-3 text-neutral-200'
    },
    filterInput: {
        className:
            'pl-9 h-11 min-h-11 border-2 border-neutral-100 focus:border-neutral-100 !outline-0 focus:outline-0 hover:border-neutral-100 focus:shadow-none'
    },
    header: {
        className: 'bg-white border-0'
    },
    input: {
        className: 'pl-0 text-primary'
    },
    list: {
        className: 'pt-0'
    },
    item: {
        className: 'pb-0'
    }
};

export const previewDialogPopup = {
    mask: { className: '!items-start' },
    headerTitle: { className: 'w-full !font-semibold text-xl' },
    header: { className: 'py-4 !rounded-md !rounded-b-none' },
    closeButton: { className: 'focus:shadow-none' },
    content: { className: 'min-h-[80vh] !rounded-b-md' },
    root: { className: 'shadow-none' }
};

export const inputSwitchPT = {
    root: { className: 'w-12 h-6' },
    slider: { className: 'before:h-4 before:w-4' },
    input: { className: 'disabled:cursor-not-allowed !pointer-events-auto' }
};

export const translationFeeInputSwitchPT = {
    root: { className: 'w-12 h-6' },
    slider: {
        className:
            'before:h-5 before:w-5 !border before:!top-[49.5%] before:!left-[0.29rem] before:content-["AI"] before:text-[0.75rem] before:font-medium before:text-white before:flex before:justify-center before:items-center before:absolute before:leading-[1px] !border-black/20'
    }
};

export const checkBoxPT = {
    root: {
        className: 'h-[16px] rounded-md'
    },
    input: {
        className: 'h-[16px] rounded-md unchecked:bg-neutral-100/50'
    }
};

export const hoverDropdownStyle = {
    root: {
        className:
            '!h-7 hover:outline-primary focus:outline-primary hover:outline focus:outline outline-1  font-medium border-0  bg-inherit h-8 flex items-center'
    },
    item: {
        className: 'hover:bg-primary-50 py-1'
    },
    input: {
        className: '!block p-0 text-base pl-2'
    },
    trigger: {
        className: 'w-8'
    },
    wrapper: {
        className: '!w-56 border'
    }
};

export const tooltipStyle = {
    root: {
        className: 'shadow-none'
    }
};
