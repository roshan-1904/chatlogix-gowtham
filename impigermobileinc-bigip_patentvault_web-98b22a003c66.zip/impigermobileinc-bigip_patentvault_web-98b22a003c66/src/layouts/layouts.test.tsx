import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'; // for extended matchers like toBeInTheDocument
import Layout from './layout';
import { BrowserRouter as Router } from 'react-router-dom'; // Needed for <Outlet>

jest.mock('@azure/storage-blob', () => ({
    BlobServiceClient: jest.fn().mockReturnValue({
        getContainerClient: jest.fn(),
        listContainers: jest.fn()
    })
}));

describe('Layout Component', () => {
    test('renders Layout component correctly', () => {
        render(
            <Router>
                <Layout />
            </Router>
        );

        // Check if the HeaderMenu component is rendered
        waitFor(() => {
            expect(screen.getByTestId('HeaderMenu')).toBeInTheDocument();

            // Check if the ToastAlert component is rendered
            expect(screen.getByTestId('ToastAlert')).toBeInTheDocument();

            // Check if the FileUploadController component is rendered
            expect(screen.getByTestId('FileUploadController')).toBeInTheDocument();

            // Check if the Outlet is rendered
            expect(screen.getByTestId('Layout')).toBeInTheDocument();
        });
    });

    test('renders children components inside Outlet', () => {
        render(
            <Router>
                <Layout />
            </Router>
        );
    });
});
