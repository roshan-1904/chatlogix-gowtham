import { render, screen, fireEvent } from '@testing-library/react';
import HeaderMenu from './headerMenu';
import { BrowserRouter } from 'react-router-dom';
import AuthStore from 'core/store/authStore/authStore';
import { useMsal } from '@azure/msal-react';

jest.mock('core/store/authStore/authStore');
jest.mock('@azure/msal-react', () => ({
    useMsal: jest.fn()
}));

describe('HeaderMenu', () => {
    beforeEach(() => {
        (AuthStore.getUserInfo as jest.Mock).mockReturnValue({
            userInfo: {
                userFullName: 'John Doe',
                permissions: ['VIEW_DASHBOARD', 'VIEW_PROFILE'],
                role: 'Admin'
            }
        });

        (useMsal as jest.Mock).mockReturnValue({
            instance: {
                logoutRedirect: jest.fn()
            }
        });
    });

    test('renders the organization logo', () => {
        render(
            <BrowserRouter>
                <HeaderMenu />
            </BrowserRouter>
        );

        const logo = screen.getByTestId('organization-logo');
        expect(logo).toBeInTheDocument();
    });

    test('opens the sidebar when the menu icon is clicked', () => {
        render(
            <BrowserRouter>
                <HeaderMenu />
            </BrowserRouter>
        );

        const navbarIcon = screen.getByTestId('navbar-icon');
        fireEvent.click(navbarIcon);

        const sidebar = screen.getByTestId('sidebar');
        expect(sidebar).toBeInTheDocument();
    });

    test('opens the profile dropdown when the profile icon is clicked', () => {
        render(
            <BrowserRouter>
                <HeaderMenu />
            </BrowserRouter>
        );

        const profileDropdownToggle = screen.getByTestId('profileDropdownToggle');
        fireEvent.click(profileDropdownToggle);

        const profileDropdownContent = screen.getByTestId('profile-dropdown-content');
        expect(profileDropdownContent).toBeInTheDocument();
    });

    test('navigates to account settings when account settings is clicked', () => {
        const navigateMock = jest.fn();
        const location = { pathname: '/dashboard' };
        jest.mock('react-router-dom', () => ({
            useNavigate: () => navigateMock,
            useLocation: () => location
        }));

        render(
            <BrowserRouter>
                <HeaderMenu />
            </BrowserRouter>
        );

        const profileDropdownToggle = screen.getByTestId('profileDropdownToggle');
        fireEvent.click(profileDropdownToggle);
    });

    test('logs out the user when logout is clicked', () => {
        const logoutMock = jest.fn();
        const clearMock = jest.spyOn(Storage.prototype, 'clear');
        (useMsal as jest.Mock).mockReturnValue({
            instance: {
                logoutRedirect: logoutMock
            }
        });

        render(
            <BrowserRouter>
                <HeaderMenu />
            </BrowserRouter>
        );

        const profileDropdownToggle = screen.getByTestId('profileDropdownToggle');
        fireEvent.click(profileDropdownToggle);

        const logoutButton = screen.getByTestId('logout');
        fireEvent.click(logoutButton);

        expect(clearMock).toHaveBeenCalled();
        expect(AuthStore.logout).toHaveBeenCalled();
        expect(logoutMock).toHaveBeenCalled();
    });
});
