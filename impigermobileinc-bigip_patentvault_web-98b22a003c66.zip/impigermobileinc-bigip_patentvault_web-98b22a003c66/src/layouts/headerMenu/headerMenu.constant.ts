import { Permissions } from 'constants/permissions';
import { MenuItem } from './headerMenu';
import AuthStore, { UserInfoModal } from 'core/store/authStore/authStore';
import { isProjectManagerUser, isVendorSpecialistUser } from 'core/utils/utils';
import { ROLE } from 'constants/app.constant';

const getInfo = () => {
    const userDetails: UserInfoModal = AuthStore.getUserInfo();
    const loggedInUserRoleId = userDetails.userInfo.roleId;
    const isThisPMUser = isProjectManagerUser(loggedInUserRoleId);
    const isThisVendorSpecialistUser = isVendorSpecialistUser(loggedInUserRoleId);

    return { isThisPMUser, isThisVendorSpecialistUser };
};

export const generateHeaderMenu = (): MenuItem[] => {
    const staticMenuItems: MenuItem[] = [
        {
            menu: 'MENU.DASHBOARD',
            id: 1,
            permission: [Permissions.VIEW_DASHBOARD],
            path: ''
        },
        {
            menu: 'MENU.ORDERS_QUOTES',
            id: 2,
            permission: [Permissions.VIEW_QUOTE, Permissions.VIEW_ORDER],
            path: 'orders-quotes'
        },
        {
            menu: 'MENU.TASK_MANAGEMENT',
            id: 3,
            permission: [Permissions.VIEW_TASK],
            path: 'task-management'
        },
        {
            menu: 'MENU.COMPANIES',
            id: 4,
            permission: [Permissions.VIEW_COMPANIES],
            path: 'companies'
        },
        // Insert dynamic menu items after "MENU.COMPANIES"
        {
            menu: 'MENU.USERS',
            id: 6,
            permission: [
                Permissions.VIEW_CONTACT_PROFILE,
                Permissions.VIEW_STAFF_USER,
                Permissions.VIEW_VENDOR_USERS,
                Permissions.VIEW_V3_VENDOR_USERS_ONLY
            ],
            path: 'users'
        },
        {
            menu: 'MENU.TASKS',
            id: 7,
            permission: [Permissions.SETTING_VIEW_TASK],
            path: 'tasks',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.BILLING_TERMS',
            id: 8,
            permission: [Permissions.VIEW_BILLING_TERMS],
            path: 'billing-terms',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.REQUEST_CURRENCIES',
            id: 9,
            permission: [Permissions.VIEW_REQUEST_CURRENCIES],
            path: 'request-currencies',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.VENDOR_CURRENCIES',
            id: 10,
            permission: [Permissions.VIEW_VENDOR_CURRENCIES],
            path: 'vendor-currencies',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.LANGUAGES',
            id: 11,
            permission: [Permissions.VIEW_LANGUAGES],
            path: 'languages',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.UNITS',
            id: 12,
            permission: [Permissions.VIEW_UNIT],
            path: 'units',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.IP_INSTRUCTION_DEADLINES',
            id: 13,
            permission: [Permissions.VIEW_IP_INSTRUCTION_DEADLINES],
            path: 'ip-instruction-deadlines',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.PAYMENT_METHODS',
            id: 14,
            permission: [Permissions.VIEW_PAYMENT],
            path: 'payment-methods',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.TAX_FORMS',
            id: 15,
            permission: [Permissions.VIEW_TAX_FORMS],
            path: 'tax-forms',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.BREAKDOWNS',
            id: 17,
            permission: [Permissions.VIEW_BREAKDOWN],
            path: 'break-down',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.PV_SETTING',
            id: 19,
            permission: [Permissions.VIEW_IP_VAULT_SETTINGS],
            path: 'patent-vault-settings',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.RATE_LABELS',
            id: 20,
            permission: [Permissions.VIEW_RATE_LABELS],
            path: 'rate-labels',
            isMoreMenuIconItem: true
        },
        {
            menu: 'MENU.PATENT_DATABASES',
            id: 21,
            permission: [Permissions.VIEW_PATENT],
            path: 'patent-details',
            isMoreMenuIconItem: true,
            submenu: [
                {
                    title: 'MENU.EPO',
                    id: 311,
                    permission: [Permissions.VIEW_PATENT],
                    path: 'patent-details/epo'
                },
                {
                    title: 'MENU.WIPO',
                    id: 312,
                    permission: [Permissions.VIEW_PATENT],
                    path: 'patent-details/wipo',
                    disabled: true
                }
            ]
        }
    ];

    // Dynamic menu items based on permissions
    const permissionBasedMenuItems = getMenuItemsBasedOnPermissions();

    // Insert permission-based items at a specific index (e.g., after "MENU.COMPANIES" which is at index 4)
    const insertIndex = 5;
    staticMenuItems.splice(insertIndex, 0, ...permissionBasedMenuItems);

    return staticMenuItems;
};
const getMenuItemsBasedOnPermissions = (): MenuItem[] => {
    const menuItems: MenuItem[] = [];
    const { isThisPMUser, isThisVendorSpecialistUser } = getInfo();

    if (
        AuthStore.hasPermission(Permissions.VIEW_BILLS) &&
        AuthStore.hasPermission(Permissions.VIEW_INVOICE) &&
        (AuthStore.hasPermission(Permissions.VIEW_AR_PAYMENTS) ||
            AuthStore.hasPermission(Permissions.VIEW_AR_ADJUSTMENTS) ||
            AuthStore.hasPermission(Permissions.VIEW_AR_ADVANCES) ||
            AuthStore.hasPermission(Permissions.VIEW_AP_PAYMENTS) ||
            AuthStore.hasPermission(Permissions.VIEW_AP_ADJUSTMENTS) ||
            isThisPMUser)
    ) {
        menuItems.push({
            menu: 'MENU.ACCOUNTING',
            submenu: [
                {
                    title: 'MENU.ACCOUNTS_PAYABLE_AP',
                    id: 101,
                    permission: [Permissions.VIEW_BILLS],
                    path: '',
                    submenu: [
                        {
                            title: 'MENU.BILLS',
                            id: 103,
                            permission: [Permissions.VIEW_BILLS],
                            path: 'accounting/bills'
                        },
                        {
                            title: 'MENU.AP_PAYMENTS',
                            id: 108,
                            permission: [Permissions.VIEW_AP_PAYMENTS],
                            path: 'accounting/ap-payments'
                        },
                        {
                            title: 'MENU.AP_ADJUSTMENTS',
                            id: 109,
                            permission: [Permissions.VIEW_AP_ADJUSTMENTS],
                            path: 'accounting/ap-adjustments'
                        }
                    ]
                },

                {
                    title: 'MENU.ACCOUNTS_RECEIVABLE_AR',
                    id: 102,
                    permission: [Permissions.VIEW_INVOICE],
                    path: '',
                    submenu: [
                        {
                            title: 'MENU.INVOICES',
                            id: 104,
                            permission: [Permissions.VIEW_INVOICE],
                            path: 'accounting/invoices'
                        },
                        {
                            title: 'MENU.AR_PAYMENTS',
                            id: 105,
                            permission: [Permissions.VIEW_AR_PAYMENTS],
                            path: 'accounting/ar-payments'
                        },
                        {
                            title: 'MENU.AR_ADJUSTMENTS',
                            id: 106,
                            permission: [Permissions.VIEW_AR_ADJUSTMENTS],
                            path: 'accounting/ar-adjustments'
                        },
                        {
                            title: 'MENU.AR_ADVANCES',
                            id: 107,
                            permission: [Permissions.VIEW_AR_ADVANCES],
                            path: 'accounting/ar-advances'
                        }
                    ]
                }
            ],
            id: 18,
            permission: [Permissions.VIEW_BILLS, Permissions.VIEW_INVOICE],
            path: 'accounting'
        });
    } else {
        if (AuthStore.hasPermission(Permissions.VIEW_BILLS)) {
            menuItems.push({
                menu: 'MENU.BILLS',
                id: 20,
                permission: [Permissions.VIEW_BILLS],
                path: 'bills'
            });
        }
        if (AuthStore.hasPermission(Permissions.VIEW_INVOICE)) {
            menuItems.push({
                menu: 'MENU.INVOICES',
                id: 21,
                permission: [Permissions.VIEW_INVOICE],
                path: 'invoices'
            });
        }
        if (AuthStore.hasPermission(Permissions.VIEW_AP_PAYMENTS) && isThisVendorSpecialistUser) {
            menuItems.push({
                menu: 'MENU.PAYMENTS',
                id: 22,
                permission: [Permissions.VIEW_AP_PAYMENTS],
                path: 'payments'
            });
        }
    }

    if (
        AuthStore.hasPermission(Permissions.VIEW_PATENT) &&
        (AuthStore.getUserInfo().userInfo.roleId === ROLE.SALES_REP.roleId ||
            AuthStore.getUserInfo().userInfo.roleId === ROLE.VENDOR_SALES_REP.roleId)
    ) {
        menuItems.push({
            menu: 'MENU.PATENT_DATABASES',
            id: 310,
            permission: [Permissions.VIEW_PATENT],
            path: 'patent-details',
            submenu: [
                {
                    title: 'MENU.EPO',
                    id: 321,
                    permission: [Permissions.VIEW_PATENT],
                    path: 'patent-details/epo'
                },
                {
                    title: 'MENU.WIPO',
                    id: 322,
                    permission: [Permissions.VIEW_PATENT],
                    path: 'patent-details/wipo',
                    disabled: true
                }
            ]
        });
    }

    return menuItems;
};
