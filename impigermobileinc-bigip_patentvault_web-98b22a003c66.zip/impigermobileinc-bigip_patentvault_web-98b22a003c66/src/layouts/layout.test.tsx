import { render, screen } from '@testing-library/react';
import Layout from './layout';

// Mock components
jest.mock('./headerMenu/headerMenu', () => () => <div>HeaderMenu Mock</div>);
jest.mock('components/toast/toastAlert', () => () => <div>ToastAlert Mock</div>);
jest.mock('components/fileUpload/fileUploadController', () => () => (
    <div>FileUploadController Mock</div>
));
import { ReactElement, JSXElementConstructor } from 'react';
import { OutletProps } from 'react-router-dom';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    Outlet: jest.fn().mockReturnValue({ type: 'div', props: { children: 'Outlet Mock' } }) as (
        props: OutletProps
    ) =>
        | ReactElement<any, string | JSXElementConstructor<any>>
        | (null & { mockReturnValue?: any }),
    mockReturnValue: jest.fn()
}));

describe('Layout Component', () => {
    test('should render Layout with HeaderMenu, ToastAlert, FileUploadController, and Outlet', () => {
        render(<Layout />);
        expect(screen.getByTestId('Layout')).toBeInTheDocument();
        expect(screen.getByText('HeaderMenu Mock')).toBeInTheDocument();
        expect(screen.getByText('ToastAlert Mock')).toBeInTheDocument();
        expect(screen.getByText('FileUploadController Mock')).toBeInTheDocument();
    });
});
