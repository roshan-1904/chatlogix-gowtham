import { render, screen } from '@testing-library/react';
import App, { ErrorBoundary } from './App';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from 'core/configs/msalConfig';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import { router } from 'core/routes';
import { getToken } from 'core/interceptor/api.handler';

jest.mock('core/interceptor/api.handler', () => ({
    getToken: jest.fn(() => Promise.resolve('mockToken'))
}));

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    createBrowserRouter: jest.fn(() => jest.fn())
}));

jest.mock('@azure/msal-react', () => ({
    MsalProvider: jest.fn(({ children }) => <div>{children}</div>)
}));

describe('App Component', () => {
    it('renders without crashing', () => {
        const msalInstance = new PublicClientApplication(msalConfig);
        const routerConfig = createBrowserRouter(router);

        render(
            <MsalProvider instance={msalInstance}>
                <RouterProvider router={routerConfig} />
            </MsalProvider>
        );

        expect(screen.getByText(/Initial Load.../i)).toBeInTheDocument();
    });

    it('sets up token refresh interval', () => {
        jest.useFakeTimers();

        render(<App />);

        expect(getToken).not.toHaveBeenCalled();
        jest.advanceTimersByTime(1000 * 60 * 1); // Advance time by 1 minute
        expect(getToken).toHaveBeenCalled();
        jest.useRealTimers();
    });

    it('renders the ErrorBoundary component', () => {
        const msalInstance = new PublicClientApplication(msalConfig);
        const routerConfig = createBrowserRouter(router);

        render(
            <MsalProvider instance={msalInstance}>
                <div>
                    <ErrorBoundary>
                        <RouterProvider router={routerConfig} />
                    </ErrorBoundary>
                </div>
            </MsalProvider>
        );

        expect(screen.getByText(/Initial Load.../i)).toBeInTheDocument();
    });

    it('handles ErrorBoundary fallback correctly', () => {
        const msalInstance = new PublicClientApplication(msalConfig);

        const ErrorThrowingComponent = () => {
            throw new Error('Test error');
        };

        render(
            <MsalProvider instance={msalInstance}>
                <div>
                    <ErrorBoundary>
                        <ErrorThrowingComponent />
                    </ErrorBoundary>
                </div>
            </MsalProvider>
        );

        expect(screen.getByText(/Your error component/i)).toBeInTheDocument();
    });
});
