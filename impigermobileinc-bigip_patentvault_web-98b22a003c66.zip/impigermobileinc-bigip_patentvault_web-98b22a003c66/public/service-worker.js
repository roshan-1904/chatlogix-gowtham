/* eslint-disable */
// Exclude the service-worker.js file from ESLint's list of included files
self.addEventListener('fetch', (event) => {
    if (event.request.url.includes('.chunk.js')) {
        event.respondWith(
            fetch(event.request)
                .then((response) => {
                    // Check if the response status is 404 (Not Found)
                    if (response.status === 404) {
                        // Send 'force-reload' message to clients
                        clients.matchAll().then((clients) => {
                            clients.forEach((client) => client.postMessage('force-reload'));
                        });
                    }
                    return response;
                })
                .catch((error) => {
                    console.error('Fetch error:', error);
                    throw error;
                })
        );
    }
});
