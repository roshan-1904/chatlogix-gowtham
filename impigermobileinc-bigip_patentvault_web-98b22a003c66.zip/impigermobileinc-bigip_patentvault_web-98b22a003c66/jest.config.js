const tsconfig = require('./tsconfig.json');
const moduleNameMapper = require('tsconfig-paths-jest')(tsconfig);

const esModules = ['@azure/msal-react'].join('|');
module.exports = {
    collectCoverage: false,
    collectCoverageFrom: ['src/**/*.{js,jsx,ts,tsx}'],
    coverageDirectory: 'coverage',
    testEnvironment: 'jsdom',
    coverageReporters: ['html'],
    preset: 'ts-jest',
    setupFilesAfterEnv: ['<rootDir>/jest/jest.setup.js'],
    modulePathIgnorePatterns: [
        '<rootDir>/src/__mocks__', // Ignore __mocks__ folder directly under src
        '.*mocks/.*', // Ignore __mocks__ in any subdirectory
        '/constants/', // Ignore __mocks__ in any subdirectory
        '/constant/', // Ignore __mocks__ in any subdirectory
        '/types/', // Ignore __mocks__ in any subdirectory
        '.*\\.mock\\..*' // Ignore any file with .mock prefix
    ],
    moduleNameMapper: {
        '.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
            '<rootDir>/jest/__mocks__/fileMock.js',
        '\\.(css|less)$': '<rootDir>/jest/__mocks__/styleMock.js'
    },
    transform: {
        '^.+\\.(ts|tsx)$': 'ts-jest',
        '^.+\\.(js|jsx)$': 'babel-jest',
        '\\.js$': '<rootDir>/node_modules/babel-jest',
        '.+\\.(css|styl|less|sass|scss)$': 'jest-css-modules-transform',
        '^.+\\.(js|jsx|ts|tsx|mjs)$': 'babel-jest'
    },

    // An array of directory names to be searched recursively up from the requiring module's location
    moduleDirectories: ['node_modules', 'src'],

    // An array of file extensions your modules use
    moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json'],

    // Automatically reset mock state between every test
    resetMocks: true,

    // A list of paths to directories that Jest should use to search for files in
    roots: ['<rootDir>/src'],

    // The paths to modules that run some code to configure or set up the testing environment before each test
    setupFiles: ['dotenv/config'],

    // An array of regexp pattern strings that are matched against all source file paths, matched files will skip transformation
    transformIgnorePatterns: [`node_modules/(?!(${esModules}))`],

    // Whether to use watchman for file crawling
    watchman: true,

    extensionsToTreatAsEsm: ['.ts', '.tsx']
};
